/* RPLAY v2.42 cross-site compatibility diagnostics: offline only; no downloads or auth replay.
 * Inspired by standalone RPLAY Cross-Site Compatibility v0.1.0, rewritten for classic WebExtensions.
 * Raw media addresses exist only in ephemeral parsed objects, never in public reports. */
(function(root){'use strict';
const MAX_BYTES=2097152, MAX_SEGMENTS=10000;
function validUrl(text){if(typeof text!=='string'||text.length>16384||/[\x00-\x20\x7f]/.test(text))throw Error('INVALID_MEDIA_URL');let u;try{u=new URL(text);}catch{throw Error('INVALID_MEDIA_URL');}if(!['http:','https:'].includes(u.protocol)||u.username||u.password)throw Error('INVALID_MEDIA_URL');return u;}
function resolve(parent,ref){if(typeof ref!=='string'||ref.length>16384||!ref||/[\x00-\x20\x7f]/.test(ref))throw Error('INVALID_MEDIA_CHILD');return validUrl(new URL(ref,parent).href).href;}
function attributes(text){const out={};let i=0;while(i<text.length){while(i<text.length&&/[\s,]/.test(text[i]))i++;const s=i;while(i<text.length&&text[i]!=='='&&text[i]!==',')i++;if(text[i]!=='='){i++;continue;}const name=text.slice(s,i).trim();i++;let v='';if(text[i]==='"'){i++;const at=i;while(i<text.length&&text[i]!=='"')i++;v=text.slice(at,i);if(i>=text.length)throw Error('UNTERMINATED_HLS_ATTRIBUTE');i++;}else{const at=i;while(i<text.length&&text[i]!==',')i++;v=text.slice(at,i).trim();}if(name)out[name]=v;if(text[i]===',')i++;}return out;}
function safeNumber(text,where){if(!/^\d+$/.test(String(text)))throw Error('INVALID_'+where);const n=Number(text);if(!Number.isSafeInteger(n))throw Error('INVALID_'+where);return n;}
function range(text,prior,priorUrl,url){if(!text)return null;const m=/^(\d+)(?:@(\d+))?$/.exec(text);if(!m)throw Error('INVALID_HLS_RANGE');const length=safeNumber(m[1],'HLS_RANGE');const start=m[2]!==undefined?safeNumber(m[2],'HLS_RANGE'):(priorUrl===url?prior:null);if(start===null||!Number.isSafeInteger(start+length))throw Error('HLS_RANGE_NEEDS_PREVIOUS_RESOURCE');return {offset:start,length};}
function parseHLS(text,playlistUrl){const parent=validUrl(playlistUrl).href;if(typeof text!=='string'||new TextEncoder().encode(text).length>MAX_BYTES)throw Error('HLS_LIMIT_2_MIB');const lines=text.replace(/^\uFEFF/,'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);if(lines[0]!=='#EXTM3U')throw Error('BODY_NOT_HLS');
 const result={kind:'media',segments:[],variants:[],renditions:[],parts:0,targetDuration:null,mediaSequence:0,discontinuitySequence:0,skipCount:0,endList:false,encrypted:false,drm:false,skip:false,warnings:[],errors:[]};
 let seq=0,disc=0,nextDisc=false,nextGap=false,pendingVariant=null,pendingRange=null,priorEnd=0,priorURL=null,activeMap=null,method='NONE',keyformat='identity';
 for(const line of lines.slice(1)){
 if(line.startsWith('#EXT-X-STREAM-INF:')){result.kind='master';pendingVariant=attributes(line.slice(18));continue;}
 if(line.startsWith('#EXT-X-MEDIA:')){result.kind='master';const a=attributes(line.slice(13));result.renditions.push({type:a.TYPE||'',language:a.LANGUAGE||'',hasUri:!!a.URI});continue;}
 if(line.startsWith('#EXT-X-MEDIA-SEQUENCE:')){seq=safeNumber(line.slice(22),'MEDIA_SEQUENCE');result.mediaSequence=seq;continue;}
 if(line.startsWith('#EXT-X-DISCONTINUITY-SEQUENCE:')){disc=safeNumber(line.slice(30),'DISCONTINUITY_SEQUENCE');result.discontinuitySequence=disc;continue;}
 if(line.startsWith('#EXT-X-TARGETDURATION:')){result.targetDuration=safeNumber(line.slice(22),'TARGETDURATION');continue;}
 if(line.startsWith('#EXT-X-BYTERANGE:')){pendingRange=line.slice(17);continue;}
 if(line.startsWith('#EXT-X-MAP:')){const a=attributes(line.slice(11));activeMap=a.URI?{url:resolve(parent,a.URI),byRange:a.BYTERANGE||''}:null;continue;}
 if(line.startsWith('#EXT-X-KEY:')){const a=attributes(line.slice(11));method=a.METHOD||'UNKNOWN';keyformat=a.KEYFORMAT||'identity';if(method!=='NONE')result.encrypted=true;if(!['NONE','AES-128'].includes(method)||keyformat!=='identity')result.drm=true;continue;}
 if(line==='#EXT-X-DISCONTINUITY'){nextDisc=true;disc++;continue;}
 if(line==='#EXT-X-GAP'){nextGap=true;continue;}
 if(line==='#EXT-X-ENDLIST'){result.endList=true;continue;}
 if(line.startsWith('#EXT-X-SKIP:')){if(result.skip)throw Error('DUPLICATE_HLS_SKIP');const a=attributes(line.slice(12));const count=safeNumber(a['SKIPPED-SEGMENTS'],'HLS_SKIP');if(!Number.isSafeInteger(seq+count))throw Error('INVALID_HLS_SKIP');result.skip=true;result.skipCount=count;seq+=count;continue;}
 if(line.startsWith('#EXT-X-PART:')){result.parts++;continue;}
 if(line.startsWith('#'))continue;
 const u=resolve(parent,line);
 if(pendingVariant){result.variants.push({bandwidth:pendingVariant.BANDWIDTH||'',resolution:pendingVariant.RESOLUTION||'',hasUrl:true});pendingVariant=null;continue;}
 const byRange=range(pendingRange,priorEnd,priorURL,u);
 if(result.segments.length>=MAX_SEGMENTS)throw Error('HLS_SEGMENT_LIMIT');
 result.segments.push({sequence:seq++,disc,discontinuity:nextDisc,gap:nextGap,byRange,map:!!activeMap,method,keyformat});
 if(byRange){priorURL=u;priorEnd=byRange.offset+byRange.length;}else{priorURL=null;priorEnd=0;}
 nextDisc=false;nextGap=false;pendingRange=null;
 }
 if(pendingVariant)throw Error('HLS_MISSING_VARIANT_URI');
 if(result.kind==='media'&&!result.endList&&!(result.targetDuration>0))result.warnings.push('target duration missing');
 if(result.skip)result.warnings.push('LL-HLS delta skip: history may be incomplete');
 if(result.parts)result.warnings.push('LL-HLS parts: full-segment accounting only');
 if(result.encrypted)result.warnings.push(result.drm?'encrypted/protected stream: diagnostics only':'AES-128: diagnostics only, no key fetch');
 return result;
}
/* Bounded, read-only DASH MPD diagnostics. This deliberately does not resolve/fetch BaseURL,
 * segment templates, keys, XLink or external entities. No URL or attribute text is emitted. */
function parseDASH(text){
 if(typeof text!=='string'||new TextEncoder().encode(text).length>MAX_BYTES)throw Error('DASH_LIMIT_2_MIB');
 if(/<!DOCTYPE|<!ENTITY/i.test(text))throw Error('DASH_DTD_FORBIDDEN');
 let i=0,rootFound=false,finished=false,nodes=0,stack=[],periods=0,adaptations=0,representations=0,audio=0,video=0,other=0,
  contentProtection=0,segmentTemplates=0,segmentLists=0,segmentBases=0,baseUrls=0,segmentUrls=0,timelineEntries=0,timelineExpanded=0,
  indefiniteTimeline=false,remoteXlinks=0,manifestType='static',minimumUpdateSeconds=null,hasTimeShiftBuffer=false,hasAvailabilityStart=false,
  curAdapt=null;
 const warnings=[],representationsList=[];
 function safeTag(v,max=64){return typeof v==='string'&&!/https?:|\/{2}|[?&=\\]/i.test(v)?v.replace(/[^A-Za-z0-9_.,:+/-]/g,'').slice(0,max):'';}
 function safeNum(v){const n=Number(v);return Number.isFinite(n)&&n>0?n:0;}
 function fail(){throw Error('INVALID_DASH_XML');}
 function readAttrs(tag){let j=0,a=Object.create(null);const name=/^[A-Za-z_][A-Za-z0-9_.:-]*/.exec(tag);if(!name)fail();j=name[0].length;
  while(j<tag.length){while(/\s/.test(tag[j]||'')&&j<tag.length)j++;if(j===tag.length)break;
   const m=/^[A-Za-z_][A-Za-z0-9_.:-]*/.exec(tag.slice(j));if(!m)fail();const k=m[0];j+=k.length;
   while(j<tag.length&&/\s/.test(tag[j]))j++;if(tag[j]!=='=')fail();j++;while(j<tag.length&&/\s/.test(tag[j]))j++;
   const quote=tag[j++];if(quote!=="'"&&quote!=='\"')fail();const at=j;while(j<tag.length&&tag[j]!==quote)j++;
   if(j===tag.length)fail();const v=tag.slice(at,j++);if(/[<]/.test(v)||Object.hasOwn(a,k))fail();a[k]=v;
  }return {name:name[0].split(':').pop(),attrs:a};
 }
 function isoSeconds(v){const m=/^PT(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?$/.exec(v||'');if(!m||!m.slice(1).some(Boolean))return null;const n=Number(m[1]||0)*3600+Number(m[2]||0)*60+Number(m[3]||0);return Number.isFinite(n)&&n<=86400?n:null;}
 function nextTag(){const start=text.indexOf('<',i);if(start<0){if(text.slice(i).trim())fail();i=text.length;return null;}
  if(text.slice(i,start).trim()&&(!stack.length||finished))fail();
  if(text.startsWith('<!--',start)){const end=text.indexOf('-->',start+4);if(end<0)fail();i=end+3;return {skip:true};}
  if(text.startsWith('<?',start)){const end=text.indexOf('?>',start+2);if(end<0)fail();i=end+2;return {skip:true};}
  if(text.startsWith('<![CDATA[',start)){const end=text.indexOf(']]>',start+9);if(end<0||!stack.length)fail();i=end+3;return {skip:true};}
  if(text.startsWith('<!',start))fail();
  let end=start+1,quote='';for(;end<text.length;end++){const c=text[end];if(quote){if(c===quote)quote='';}else if(c==='\"'||c==="'")quote=c;else if(c==='>')break;}
  if(end>=text.length||quote)fail();i=end+1;return {raw:text.slice(start+1,end).trim()};
 }
 while(i<text.length){const tok=nextTag();if(!tok)break;if(tok.skip)continue;
  if(++nodes>20000)throw Error('DASH_NODE_LIMIT');const raw=tok.raw;
  if(raw.startsWith('/')){const closing=raw.slice(1).trim();if(!/^[A-Za-z_][A-Za-z0-9_.:-]*$/.test(closing)||!stack.length||stack.pop()!==closing)fail();if(closing.split(':').pop()==='AdaptationSet')curAdapt=null;if(!stack.length)finished=true;continue;}
  if(finished)fail();const selfClose=raw.endsWith('/'),body=selfClose?raw.slice(0,-1).trim():raw;
  const {name,attrs:a}=readAttrs(body);const full=/^[A-Za-z_][A-Za-z0-9_.:-]*/.exec(body)[0];
  if(!rootFound){if(name!=='MPD')throw Error('BODY_NOT_DASH');rootFound=true;manifestType=a.type==='dynamic'?'dynamic':'static';minimumUpdateSeconds=isoSeconds(a.minimumUpdatePeriod);hasTimeShiftBuffer=Object.hasOwn(a,'timeShiftBufferDepth');hasAvailabilityStart=Object.hasOwn(a,'availabilityStartTime');}
  else if(stack.length===0)fail();
  if(name==='Period')periods++;
  if(name==='AdaptationSet'){adaptations++;const kind=String(a.contentType||a.mimeType||'').toLowerCase();if(kind.includes('audio'))audio++;else if(kind.includes('video'))video++;else other++;curAdapt=selfClose?null:{contentType:safeTag(a.contentType,16),mimeType:safeTag(a.mimeType,32),codecs:safeTag(a.codecs,64),lang:safeTag(a.lang,16),frameRate:safeTag(a.frameRate,16),audioSamplingRate:safeNum(a.audioSamplingRate)};}
  if(name==='Representation'){representations++;if(representationsList.length<64){const ad=curAdapt||{},mime=safeTag(a.mimeType,32)||ad.mimeType||'',ct=safeTag(a.contentType,16)||ad.contentType||(mime.startsWith('audio')?'audio':mime.startsWith('video')?'video':'');representationsList.push({id:safeTag(a.id,32),contentType:ct,mimeType:mime,codecs:safeTag(a.codecs,64)||ad.codecs||'',width:safeNum(a.width),height:safeNum(a.height),frameRate:safeTag(a.frameRate,16)||ad.frameRate||'',bandwidth:safeNum(a.bandwidth),audioSamplingRate:safeNum(a.audioSamplingRate)||ad.audioSamplingRate||0,lang:safeTag(a.lang,16)||ad.lang||''});}}
  if(name==='ContentProtection')contentProtection++;
  if(name==='SegmentTemplate')segmentTemplates++;
  if(name==='SegmentList')segmentLists++;
  if(name==='SegmentBase')segmentBases++;
  if(name==='SegmentURL')segmentUrls++;
  if(name==='BaseURL')baseUrls++;
  if(name==='S'&&stack.some(x=>x.split(':').pop()==='SegmentTimeline')){
   timelineEntries++;const repeat=a.r===undefined?0:Number(a.r);
   if(!Number.isSafeInteger(repeat)||repeat< -1||repeat>1000000)throw Error('DASH_TIMELINE_LIMIT');
   if(repeat===-1)indefiniteTimeline=true;else timelineExpanded=Math.min(1000001,timelineExpanded+repeat+1);
  }
  if(Object.keys(a).some(k=>k.split(':').pop()==='href'&&/xlink/i.test(k)))remoteXlinks++;
  if(!selfClose){stack.push(full);if(stack.length>32)throw Error('DASH_DEPTH_LIMIT');}
 }
 if(!rootFound)throw Error('BODY_NOT_DASH');if(stack.length)throw Error('INVALID_DASH_XML');
 if(!periods)warnings.push('MPD contains no Period');
 if(manifestType==='dynamic'&&minimumUpdateSeconds===null)warnings.push('dynamic MPD: refresh schedule not established');
 if(indefiniteTimeline)warnings.push('negative timeline repetition: segment count unknown');
 if(contentProtection)warnings.push('ContentProtection present: no decryption or DRM bypass');
 if(remoteXlinks)warnings.push('external XLink references not fetched');
 return {kind:'dash',manifestType,periods,adaptations,representations,representationsList,audioAdaptations:audio,videoAdaptations:video,otherAdaptations:other,segmentTemplates,segmentLists,segmentBases,segmentUrls,baseUrls,timelineEntries,timelineExpanded,indefiniteTimeline,contentProtection,remoteXlinks,minimumUpdateSeconds,hasTimeShiftBuffer,hasAvailabilityStart,warnings,downloaded:false,recordingComplete:false,externalReferencesFetched:false};
}
function publicReport(parsed){if(!parsed)return null;const s=parsed.segments;return {kind:parsed.kind,variants:parsed.variants.length,renditions:parsed.renditions.length,segments:s.length,byteRanges:s.filter(x=>x.byRange).length,initMaps:s.filter(x=>x.map).length,discontinuities:s.filter(x=>x.discontinuity).length,explicitGaps:s.filter(x=>x.gap).length,parts:parsed.parts,mediaSequence:parsed.mediaSequence,endList:parsed.endList,encrypted:parsed.encrypted,drm:parsed.drm,deltaSkip:parsed.skip,skippedSegments:parsed.skipCount,warnings:[...parsed.warnings],errors:[...parsed.errors],downloaded:false,recordingComplete:false};}
function siteProfile(url){const u=validUrl(url),h=u.hostname.toLowerCase(),p=u.pathname;let site='generic',mode='observed-media-only';if(['nicovideo.jp','www.nicovideo.jp','sp.nicovideo.jp','nico.ms'].includes(h)){site='niconico-video';mode=p.startsWith('/watch/')?'vod-page':'page';}else if(h==='live.nicovideo.jp'||/^live\d+\.nicovideo\.jp$/.test(h)){site='niconico-live';mode=p.startsWith('/watch/')?'live-page':'page';}else if(['youtube.com','www.youtube.com','m.youtube.com','youtu.be'].includes(h)){site='youtube';mode='page';}else if(['twitch.tv','www.twitch.tv','player.twitch.tv'].includes(h)){site='twitch';mode='page';}return {site,mode,mediaUrlRequired:true,siteAuthNotReplayed:true};}
function diagnoseHTTP(status){if(status===401||status===403)return {code:'AUTH_OR_PERMISSION',retry:false};if(status===404||status===410)return{code:'MISSING_OR_EXPIRED',retry:false};if(status===429)return{code:'RATE_LIMIT',retry:false};if(status>=500&&status<=599)return{code:'TEMPORARY_SERVER_ERROR',retry:true};if(status>=200&&status<=299)return{code:'OK',retry:false};return{code:'HTTP_ERROR',retry:false};}
function createMonitor({maxSeen=20000}={}){if(!Number.isInteger(maxSeen)||maxSeen<10||maxSeen>100000)throw Error('INVALID_LEDGER_LIMIT');let key=null,last=null,seen=new Set(),order=[];return{
 reset(){key=null;last=null;seen.clear();order=[];},
 observe(url,parsed){const u=validUrl(url),stream=u.origin+u.pathname+u.search,continuityReset=key!==null&&stream!==key;if(stream!==key){key=stream;last=null;seen.clear();order=[];}if(!parsed||parsed.kind!=='media')return{state:'not-media',newSegments:0,duplicates:0,possibleMissing:0,explicitGaps:0,continuityReset,complete:false};let added=0,duplicates=0,possibleMissing=0,gaps=0;for(const s of parsed.segments){const id=s.disc+':'+s.sequence;if(seen.has(id)){duplicates++;continue;}seen.add(id);order.push(id);added++;if(s.gap)gaps++;if(last&&s.disc===last.disc&&s.sequence>last.sequence+1)possibleMissing+=s.sequence-last.sequence-1;if(!last||s.disc>last.disc||(s.disc===last.disc&&s.sequence>last.sequence))last={disc:s.disc,sequence:s.sequence};}
 while(order.length>maxSeen)seen.delete(order.shift());return{state:'observed-only',newSegments:added,duplicates,possibleMissing,explicitGaps:gaps,continuityReset,complete:false,downloaded:false};
 }};}
function suggestedReloadMs(parsed,changed){if(!parsed||parsed.endList||!(parsed.targetDuration>0))return null;return Math.ceil(parsed.targetDuration*(changed?1:0.5)*1000);}
const api={parseHLS,parseDASH,publicReport,siteProfile,diagnoseHTTP,createMonitor,suggestedReloadMs,validUrl};if(typeof module!=='undefined')module.exports=api;root.RspCrossSite=Object.assign({},root.RspCrossSite||{},api);
})(typeof globalThis!=='undefined'?globalThis:this);
