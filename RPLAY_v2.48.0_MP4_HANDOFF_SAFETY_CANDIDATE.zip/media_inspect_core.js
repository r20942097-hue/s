/* Local media candidate diagnostics and command template generator. No network, key fetch, or execution. */
(function(root){'use strict';
const LIMIT=2*1048576,fail=c=>{throw Error(c);};
function urlValue(value){if(typeof value!=='string'||!value||value.length>16384||/[\x00-\x20\x7f]/.test(value))fail('INVALID_HTTP_URL');let u;try{u=new URL(value);}catch{fail('INVALID_HTTP_URL');}if(!['http:','https:'].includes(u.protocol)||u.username||u.password)fail('INVALID_HTTP_URL');return u;}
function classifySite(url){
 const u=urlValue(url),h=u.hostname.toLowerCase(),p=u.pathname;
 let site='generic',mode='unknown';
 if(h==='www.nicovideo.jp'||h==='nicovideo.jp'||h==='sp.nicovideo.jp'||h==='nico.ms'){site='niconico-video';mode=/^\/watch\//.test(p)?'vod-page':'page';}
 else if(h==='live.nicovideo.jp'||/^live\d+\.nicovideo\.jp$/.test(h)){site='niconico-live';mode=/^\/watch\//.test(p)?'live-page':'page';}
 else if(h==='www.youtube.com'||h==='youtube.com'||h==='m.youtube.com'||h==='youtu.be'){site='youtube';mode='page';}
 else if(h==='www.twitch.tv'||h==='twitch.tv'||h==='player.twitch.tv'){site='twitch';mode='page';}
 else if(h==='rplay.live'||h==='www.rplay.live'){site='rplay';mode=/^\/live(?:\/|$)/.test(p)||u.searchParams.has('creatorOid')?'live-page':(/^\/play\//.test(p)?'vod-page':'page');}
 const path=p.toLowerCase();
 if(path.endsWith('.m3u8'))mode='hls';
 else if(path.endsWith('.mpd'))mode='dash';
 else if(path.endsWith('.mp4')||path.endsWith('.m4a'))mode='mp4';
 else if(path.endsWith('.ts')||path.endsWith('.m2ts'))mode='ts';
 return {site,mode,needsObservedMediaRequest:!['hls','dash','mp4','ts'].includes(mode),origin:u.origin};
}
function siteRequirements(siteProfile){
 if(siteProfile&&siteProfile.site==='niconico-live')return {session:'site-playback-dependent',connection:'may-require-websocket-heartbeat',capture:'observed-authorized-HLS-only'};
 if(siteProfile&&siteProfile.site==='niconico-video')return {session:'site-playback-dependent',connection:'vod',capture:'observed-authorized-media-only'};
 if(siteProfile&&siteProfile.site==='rplay')return {session:'site-playback-dependent',connection:siteProfile.mode==='live-page'?'live-hls':'vod-hls',capture:'observed-authorized-HLS-only'};
 return {session:'vary-by-site',connection:'observed',capture:'observed-authorized-media-only'};
}
function diagnoseResponse({status,contentType='',mediaType='',redirects=0}={}){
 const notes=[];let state='ok',retry=false;
 if(status===401||status===403){state='authorization-required';notes.push('署名期限・Cookie・Referer・Authorizationなど自身の視聴セッション条件を確認してください（秘密情報の外部出力はしません）');}
 else if(status===404||status===410){state='missing-or-expired';notes.push('URLの有効期限切れ、または配信終了の可能性があります。対象ページで再生して候補を再取得してください');}
 else if(status===429){state='rate-limited';notes.push('レート制限（429）です。Retry-Afterを尊重し、連続取得を控えてください');}
 else if(status>=500&&status<600){state='temporary-server-error';retry=true;notes.push('一時的なサーバーエラー（'+status+'）です');}
 else if(status<200||status>=300){state='http-error';}
 else if(redirects>8){state='redirect-loop';}
 const ct=String(contentType||'').toLowerCase().split(';')[0].trim();
 if(state==='ok'&&mediaType==='hls'&&ct&&!['application/vnd.apple.mpegurl','application/x-mpegurl','audio/mpegurl','audio/x-mpegurl','text/plain','application/octet-stream'].includes(ct))notes.push('Unexpected media content type');
 return {state,retry,notes};
}
function classify(url,mime=''){const u=urlValue(url);if(typeof mime!=='string'||mime.length>256||/[\r\n\x00]/.test(mime))fail('INVALID_MIME');const m=mime.split(';')[0].trim().toLowerCase(),path=u.pathname.toLowerCase(),ext=(/\.([a-z0-9]{1,8})$/.exec(path)||[])[1]||null;let type=null;if(['application/vnd.apple.mpegurl','application/x-mpegurl','audio/mpegurl','audio/x-mpegurl'].includes(m))type='hls';else if(m==='application/dash+xml')type='dash';else if(ext==='m3u8')type='hls';else if(ext==='mpd')type='dash';else if(m==='video/mp2t'||ext==='ts'||ext==='m2ts')type='ts';else if(m.startsWith('audio/')||['aac','m4a','mp3','opus','ogg','flac','wav'].includes(ext))type='audio';else if(m.startsWith('video/')||['mp4','flv','webm','mov','mkv'].includes(ext))type='video';return {type,ext,mime:m,candidateOnly:true,bodyVerified:false};}
function inspectHls(text){if(typeof text!=='string'||text.length>LIMIT||new TextEncoder().encode(text).length>LIMIT)fail('MANIFEST_LIMIT_2_MIB');if(!/^\uFEFF?#EXTM3U(?:\r?\n|$)/.test(text))fail('BODY_NOT_HLS');const lines=text.replace(/^\uFEFF/,'').split(/\r?\n/);let variants=0,segments=0,duration=0,maps=0,ranges=0,discontinuities=0,skip=0,parts=0,end=false,drm=false,programDateTimes=0,cueOut=0,cueIn=0,scte35=0,dateRanges=0;const encryption=new Set();for(const line of lines){if(line.startsWith('#EXT-X-STREAM-INF:'))variants++;if(line.startsWith('#EXTINF:')){const n=Number(line.slice(8).split(',')[0]);if(!Number.isFinite(n)||n<0)fail('INVALID_EXTINF');segments++;duration+=n;}if(line.startsWith('#EXT-X-KEY:')){const method=/(?:^|,)METHOD=([^,]+)/.exec(line.slice(11));const m=method&&['NONE','AES-128','SAMPLE-AES','SAMPLE-AES-CTR'].includes(method[1])?method[1]:'UNKNOWN';encryption.add(m);if(m==='SAMPLE-AES'||m==='SAMPLE-AES-CTR'||/KEYFORMAT="(?!identity")/i.test(line))drm=true;}if(line.startsWith('#EXT-X-MAP:'))maps++;if(line.startsWith('#EXT-X-BYTERANGE:'))ranges++;if(line==='#EXT-X-DISCONTINUITY')discontinuities++;if(line.startsWith('#EXT-X-SKIP:'))skip++;if(line.startsWith('#EXT-X-PART:'))parts++;if(line.startsWith('#EXT-X-PROGRAM-DATE-TIME:'))programDateTimes++;if(line.startsWith('#EXT-X-CUE-OUT'))cueOut++;if(line.startsWith('#EXT-X-CUE-IN'))cueIn++;if(line.startsWith('#EXT-X-SCTE35')||line.startsWith('#EXT-OATCLS-SCTE35'))scte35++;if(line.startsWith('#EXT-X-DATERANGE:'))dateRanges++;if(line==='#EXT-X-ENDLIST')end=true;}if(!Number.isFinite(duration))fail('INVALID_EXTINF');return {policy:'local_metadata_only_not_playback_validation',bodyVerified:true,syntaxFullyValidated:false,master:variants>0,variants,segments,durationSec:duration,maps,byteRanges:ranges,discontinuities,llHlsSkip:skip,llHlsParts:parts,programDateTimes,adMarkers:{cueOut,cueIn,scte35,dateRanges},ended:end,encryptionMethods:Array.from(encryption),drm,fetched:false,keysFetched:false};}
function quote(value,shell){if(typeof value!=='string'||value.includes('\0'))fail('INVALID_ARGUMENT');if(shell==='powershell')return "'"+value.replace(/'/g,"''")+"'";if(shell==='sh')return "'"+value.replace(/'/g,"'\"'\"'")+"'";fail('UNSUPPORTED_SHELL');}
function filename(value){if(typeof value!=='string'||value.length>512||/[\x00-\x1f\x7f]/.test(value))fail('INVALID_FILENAME');let n=value.normalize('NFC').replace(/[\\/:*?"<>|]/g,'_').replace(/^[. ]+|[. ]+$/g,'');if(!n)n='RPLAY_output.mp4';if(n.length>150)n=n.slice(0,146)+'.mp4';if(!/\.mp4$/i.test(n))n+='.mp4';if(/^(?:con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\.|$)/i.test(n))n='media_'+n;return n;}
function commands({url,referer='',userAgent='',output='RPLAY_output.mp4',shell='powershell',audioUrl=''}={}){urlValue(url);if(audioUrl)urlValue(audioUrl);if(referer)urlValue(referer);if(typeof userAgent!=='string'||userAgent.length>1024||/[\x00-\x1f\x7f]/.test(userAgent))fail('INVALID_HEADER');const file=filename(output),stem=file.replace(/\.mp4$/i,''),outPath=(shell==='powershell'?'.\\':'./')+file,q=v=>quote(v,shell),headers=[];if(referer)headers.push('Referer: '+referer);if(userAgent)headers.push('User-Agent: '+userAgent);const curl=[shell==='powershell'?'curl.exe':'curl','--location','--fail','--no-clobber'];for(const h of headers)curl.push('--header',q(h));curl.push('--output',q(stem+'.download'),'--url',q(url));const ff=['ffmpeg','-n'];if(referer)ff.push('-referer',q(referer));if(userAgent)ff.push('-user_agent',q(userAgent));ff.push('-i',q(url));if(audioUrl){if(referer)ff.push('-referer',q(referer));if(userAgent)ff.push('-user_agent',q(userAgent));ff.push('-i',q(audioUrl));}ff.push('-map',q('0:v?'),'-map',q(audioUrl?'1:a?':'0:a?'),'-c','copy',q(outPath));const nm=['N_m3u8DL-RE',q(url),'--save-name',q(stem),'--no-log','--live-real-time-merge','--live-pipe-mux'];for(const h of headers)nm.push('-H',q(h));const ytdlp=['yt-dlp','--no-overwrites','--hls-use-mpegts'];if(referer)ytdlp.push('--referer',q(referer));if(userAgent)ytdlp.push('--user-agent',q(userAgent));ytdlp.push('-o',q(outPath),q(url));const sl=['streamlink'];for(const h of headers)sl.push('--http-header',q(h));sl.push('-o',q(outPath),q(url),q('best'));const m3args=['"'+url+'"','--save-name "'+stem.replace(/["\\]/g,'_')+'"'];for(const h of headers)m3args.push('--header "'+h.replace(/"/g,'\\"')+'"');m3args.push('--live-real-time-merge','--live-pipe-mux');const m3param=m3args.join(' '),m3b64=typeof Buffer!=='undefined'?Buffer.from(m3param,'utf8').toString('base64'):btoa(unescape(encodeURIComponent(m3param)));return {shell,curl:curl.join(' '),ffmpeg:ff.join(' '),nm3u8dlRe:nm.join(' '),m3u8dlProtocol:'m3u8dl://'+m3b64,ytdlp:ytdlp.join(' '),streamlink:sl.join(' '),overwrite:false,executed:false,note:'curl 7.83以降で取得元の応答を.downloadへ保存します。ffmpegのMP4可否は入力コーデックによります。'};}
/** Pure decision: HTTP is the transport for HLS as well as single-file media.
 * A URL/MIME hint does not prove a server actually returns a media body.
 * Never return the supplied URL or any token-bearing playlist text. */
function transportDecision({url,mime='',body=''}={}){
 urlValue(url);
 if(typeof body!=='string'||body.length>LIMIT||new TextEncoder().encode(body).length>LIMIT)fail('MANIFEST_LIMIT_2_MIB');
 const guess=classify(url,mime),t=body.replace(/^\uFEFF/,'').trimStart(),hasBody=body.length>0;
 const hls=/^#EXTM3U(?:\r?\n|$)/.test(t);
 const dash=/^(?:<\?xml[^>]*>\s*)?<(?:[\w.-]+:)?MPD(?:\s|>)/i.test(t);
 const html=/^(?:<!doctype\s+html\b|<html[\s>])/i.test(t);
 const ext=guess.ext||'',ct=guess.mime;
 const fileSuffix=['mp4','m4a','webm','mp3','flac','wav','ogg','mov','mkv'].includes(ext)?ext:null;
 const directMime={'video/mp4':'mp4','audio/mp4':'m4a','video/webm':'webm','audio/webm':'webm','audio/mpeg':'mp3','audio/flac':'flac','audio/wav':'wav','audio/ogg':'ogg'};
 const directType=directMime[ct]||fileSuffix;
 const playlistHint=['m3u8','mpd'].includes(ext)||['hls','dash'].includes(guess.type);
 const conflict=!!directType&&playlistHint;
 let route='unknown',evidence='insufficient';
 if(html){route='not-media';evidence='html-body';}
 else if(hls){route='hls';evidence='playlist-body';}
 else if(dash){route='dash';evidence='mpd-body';}
 else if(hasBody){route='unknown';evidence='unrecognized-body';}
 else if(conflict){route='ambiguous';evidence='conflicting-hints';}
 else if(guess.type==='hls'){route='hls';evidence='mime-or-extension';}
 else if(guess.type==='dash'){route='dash';evidence='mime-or-extension';}
 else if(directType){route='http-file';evidence='mime-or-extension';}
 return {route,evidence,bodyVerified:hls||dash,mayRecordHls:route==='hls',mayDirectDownload:route==='http-file',suggestedExtension:route==='http-file'?directType:null,
  notice:'URL/MIMEだけでは配信形式・最高画質・録画成功は保証できません。HTTPファイル再開はRangeと同一ファイル性の検証が必要です。'};
}
/** Review only; caller must NEVER append on an unknown or changed entity. */
function httpResumeDecision({requestedFrom=0,status,contentRange='',oldEtag='',newEtag='',contentEncoding='identity'}={}){
 if(!Number.isSafeInteger(requestedFrom)||requestedFrom<0)fail('INVALID_OFFSET');
 if(!Number.isInteger(status))fail('INVALID_STATUS');
 if(requestedFrom===0)return {action:status===200?'new-file':'reject',reason:'fresh-download'};
 if(status===416)return {action:'stop',reason:'range-unsatisfiable'};
 if(status===200)return {action:'restart-new-file',reason:'server-ignored-range'};
 if(status!==206)return {action:'reject',reason:'unexpected-status'};
 if(String(contentEncoding||'identity').toLowerCase()!=='identity')return {action:'reject',reason:'encoded-range'};
 const m=/^bytes (\d+)-(\d+)\/(\d+)$/.exec(contentRange);
 if(!m)return {action:'reject',reason:'missing-or-invalid-content-range'};
 const start=Number(m[1]),end=Number(m[2]),total=Number(m[3]);
 if(!Number.isSafeInteger(total)||start!==requestedFrom||end<start||end>=total)return {action:'reject',reason:'range-mismatch'};
 const strong=s=>typeof s==='string'&&/^"[^"\r\n]+"$/.test(s);
 if(!strong(oldEtag)||oldEtag!==newEtag)return {action:'reject',reason:'entity-not-proven-same'};
 return {action:'append',reason:'verified-range-and-strong-etag',remainingBytes:end-start+1,totalBytes:total};
}
function httpFileCommands({url,output='RPLAY_output.mp4',shell='powershell',referer='',userAgent='',mime=''}={}){
 urlValue(url);if(referer)urlValue(referer);
 if(typeof userAgent!=='string'||userAgent.length>1024||/[\x00-\x1f\x7f]/.test(userAgent))fail('INVALID_HEADER');
 const decision=transportDecision({url,mime});
 if(decision.route!=='http-file')fail('DIRECT_HTTP_FILE_REQUIRED');
 const ext=decision.suggestedExtension||'mp4',base=output.replace(/\.(mp4|webm|m4a|mp3|ogg|wav|flac|mov|mkv)$/i,''),name=filename(base+'.mp4').replace(/\.mp4$/i,'.'+ext);
 const q=v=>quote(v,shell),args=[shell==='powershell'?'curl.exe':'curl','--fail','--no-clobber','--max-redirs','0'];
 if(referer)args.push('--header',q('Referer: '+referer));if(userAgent)args.push('--header',q('User-Agent: '+userAgent));
 args.push('--output',q(name),'--url',q(url));
 return {route:'http-file',command:args.join(' '),output:name,executed:false,verified:false,
  note:'HTTP直接ファイルの取得のみ。安全のためリダイレクトは自動追跡しません。--no-clobber は既存名を別名化する場合があります。検証前の追記再開はしません。'};
}
function downloadPlan(report){
 const kind=report.classification&&report.classification.type,h=report.hls,d=report.dash,sp=report.siteProfile;
 if(d)return{stage:d.manifestType==='dynamic'?'DASH_LIVE_DIAGNOSTICS':'DASH_VOD_DIAGNOSTICS',message:'MPD構造を検査しました。セグメント・認証条件・再生可否は未確認です。',requirements:['Period/RepresentationとSegmentTemplate/Timelineの継承を解析','外部参照・暗号化の有無を確認','取得・結合・デコードを別工程で検証'],verifiedDownload:false};
 if(kind!=='hls'&&!h){
  const isWatchPage=sp&&sp.site!=='generic'&&sp.needsObservedMediaRequest;
  return {stage:kind==='ts'?'LOCAL_TS_CONVERSION':kind==='dash'?'DASH_EXTERNAL_TOOL':'CANDIDATE_ONLY',message:kind==='ts'?'保存済みTSはTS→MP4変換へ。URL検出だけではファイル実体を検証できません。':kind==='dash'?'DASHはHLSとは別方式です。MPD対応ツールを検討してください。':isWatchPage?'視聴ページURL（'+sp.site+' / '+sp.mode+'）は直接のメディアURLではありません。ブラウザで再生し、検出したHLS候補リストから選択してください。':'URL/MIMEだけでは保存可否は未判定です。',verifiedDownload:false};
 }
 if(!h)return {stage:'PLAYLIST_REQUIRED',message:'HLS候補です。保存済みM3U8本文を入力してmaster/mediaを確認してください。',verifiedDownload:false};
 const requirements=[];if(h.master)requirements.push('画質variantを選び、そのmedia playlistを取得');else requirements.push('media playlistの順番でセグメントを取得・重複を除外');if(h.maps)requirements.push('EXT-X-MAPの初期化データを取得し、変更時は境界を管理');if(h.byteRanges)requirements.push('Range応答のContent-Rangeと長さを検証');if(h.encryptionMethods.some(m=>m!=='NONE'))requirements.push('暗号化方式と正規の鍵取得権限を確認。DRM対応を意味しません');if(h.llHlsSkip||h.llHlsParts)requirements.push('LL-HLSの差分/部分セグメントを通常HLSと同じ扱いにしない');if(h.adMarkers&&(h.adMarkers.cueOut||h.adMarkers.scte35||h.adMarkers.dateRanges))requirements.push('SCTE-35/CUE広告境界マーカーが含まれます。不連続境界・コーデック変化に注意');requirements.push('TSまたはfMP4を形式に応じて結合し、必要ならMP4へremux','保存完了・サイズ・ハッシュ・デコードを別々に検証');
 return {stage:h.master?'VARIANT_REQUIRED':h.ended?'VOD_SEGMENTS':'LIVE_WINDOW',message:h.master?'masterだけでは動画本体は保存できません。別音声の有無も確認します。':h.ended?'終了済みのmedia playlistです。セグメント欠落と音声を確認してください。':'ライブ候補です。プレイリストを適応間隔で更新し、古い窓から消えたセグメントは取得できない場合があります。',requirements,verifiedDownload:false,syntaxFullyValidated:false};
}
function safeReport({url,mime='',body=''}={}){const u=urlValue(url),kind=classify(url,mime),sp=classifySite(url),transfer=transportDecision({url,mime,body});
 const blocked=!!body&&!transfer.bodyVerified;
 const dash=!blocked&&transfer.route==='dash'&&transfer.bodyVerified?(root.RspCrossSite&&root.RspCrossSite.parseDASH?root.RspCrossSite.parseDASH(body):fail('DASH_PARSER_UNAVAILABLE')):null;
 const hls=!blocked&&transfer.route==='hls'&&transfer.bodyVerified?inspectHls(body):null;
 const report={schema:1,url:{origin:u.origin,queryOmitted:!!u.search,fragmentOmitted:!!u.hash,pathOmitted:true},siteProfile:{site:sp.site,mode:kind.type||sp.mode,needsObservedMediaRequest:!kind.type&&sp.needsObservedMediaRequest,requirements:siteRequirements(sp)},classification:kind,hls,dash,networkRequests:0,commandsIncluded:false,transfer};
 report.workflow=blocked?{stage:'BLOCKED',message:'目録でも完成動画でもない本文です。HTMLエラー・認証応答等を確認してください。',verifiedDownload:false}:downloadPlan(report);
 if(!blocked&&transfer.route==='http-file')report.workflow={stage:'HTTP_FILE_CANDIDATE',message:'HTTP直接ファイルの候補です。取得済み本体のサイズ・ハッシュ・デコードは未検証です。',verifiedDownload:false};
 return report;
}
const value={transportDecision,httpResumeDecision,httpFileCommands,downloadPlan,classify,classifySite,siteRequirements,diagnoseResponse,inspectHls,commands,safeReport,quote,filename,LIMIT};if(typeof module!=='undefined')module.exports=value;root.RspMediaInspect=value;
})(typeof globalThis==='undefined'?this:globalThis);
