# RPLAY v2.48.0 UNIFIED CANDIDATE

`v2.47.0` をベースに、**並行系統（ローカル v2.44.0）で実装されていた3モジュール**（`mp4_handoff.js` / `segment_store.js` / `preview_diag.js`）とその結線一式を統合し、結線回帰試験を追加した v2.48.0 統合候補版です。STATUS.md の未完項目「**BG停止後自動MP4**」を本版で完了しました。

## v2.48.0 の主な統合・改良内容

1. **BG録画停止後のMP4自動引渡し (`src/mp4_handoff.js` — v2.44.0並行系統から統合)**:
   - 録画停止・異常終了・ブラウザ再起動後にOPFS退避（`rsp_rec`）へ未完了のまま残ったTSパートをMP4へ自動変換し、保存台帳（export journal）へ引き渡す編成モジュールです。
   - 紀律は統合後も不変: **元TSは削除・変更しない（非破壊）**、**既定OFF**（`mp4AutoHandoff` 設定）、**単発実行**（変換中は新規録画を開始しない）、**秘密ゼロ**（URL/トークン等を証拠へ出力しない）。
   - 結線: `src/offscreen_post.js`（MP4_HANDOFF ホスト・bg-stop enqueue・`mp4-handoff.status` / `mp4-handoff.sweep` メッセージ）、`src/background.js`（起動時 sweep 呼び出し・handoff中のoffscreen保持ガード・`rec.start` への設定伝播）、`src/export_host.js`（`inFlightNames()` — 書き込み途中パートの変換対象除外）、両拡張のライブラリ事前読み込み（Chrome offscreen.html / Firefox manifest background.scripts）。
   - v2.39.0系統の `mp4Handover`（停止後の変換画面自動表示・手動案内）と**共存**します（dashboard に両方のトグル）。
2. **OPFS disk-backed segment store (`src/segment_store.js` — 段階設計 Stage 1 基盤)**:
   - OPFS上の名前空間ディレクトリへセグメント本体（`.bin`）とメタ（`.json`）をペア書き込みし、digest照合は fail-closed、容量/件数予算のLRU退避・pin・孤児清掃を持つ保存プリミティブです。
   - 取得経路・ネットワーク・URLは一切扱わないため、本版では録画経路へは未接続（今後の汎用取得段階設計 Stage 2 以降の土台）。ネットワーク API を参照しない構造を結線試験で固定しました。
3. **native preview環境要因の切分け (`src/preview_diag.js`)**:
   - 変換画面のMP4プレビューが再生できない要因を、環境（NO_DECODER / FROZEN_CLOCK）/ 操作（AUTOPLAY_BLOCKED）/ 内容（DECODE_ERROR）へ分類して表示します。診断は表示のみで、変換・保存・照合・ダウンロードの経路には影響しません。
   - `src/mp4_convert.html` / `src/mp4_convert.js` へ統合（`watchClock` による時計前進監視付き）。v2.39.0系統の「直近BG録画セッション（引渡し）」台帳表示と共存します。
4. **結線回帰試験 (`tests/test_v2480_integration_wiring.cjs` — 新規8件)**:
   - offscreen.html / Firefox manifest の読み込み順、MP4_HANDOFF ホスト結線の非破壊ガード、background の保持ガードと sweep 呼び出し、dashboard 設定契約（`mp4Handover` と `mp4AutoHandoff` の併存）、mp4_convert ページの両機能共存、segment_store の取得経路非結合、build/validate の派生コピー網羅を検査し、今後の改変で統合が静かに外れることを防ぎます。

## 自動テスト

**1050 / 1050 PASS**（Node.js 873件 + Python 177件）。内訳: v2.47.0 継承 988件 + v2.48.0 統合分 62件（モジュール単体54件 + 結線回帰8件）。

## 検証コマンド

```bash
python3 scripts/build.py
python3 scripts/validate.py --output-dir evidence/v248-current
python3 tests/check_request_context_http.py
python3 tests/check_cdn404_decode.py
node tests/check_recording_during_scan.cjs
```
