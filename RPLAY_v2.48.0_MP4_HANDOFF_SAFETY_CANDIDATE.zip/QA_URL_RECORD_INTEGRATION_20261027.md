# RPLAY URL録画・設定整合・連続性診断 候補

状態: CANDIDATE / NO_GO。実行バージョン番号は2.48.0のまま。旧版を上書きするリリースではない。
基準: RPLAY_v2.48.0_TRANSPORT_SELECTION_SAFETY_CANDIDATE.zip
SHA-256: ec6c54993e1d7e13e4946365d635ec2fbfb7f28ea6143ce2a8a06fabffdc68f8

## 変更
- 診断画面から既存URL録画の開始、停止、状態確認を操作。送信元は正規拡張の最上位診断画面またはDashboardに限定し、既存owner/session gateを利用。録画開始受付は保存完了を意味しない。
- 別音声URLを明示選択中の直接録画は拒否。マスターURLに戻すボタンを用意し、録画管理の追加音声設定を案内。マスターを入力した場合の別音声録画も設定・配信構造によって変わるため実成功を保証しない。
- URL録画開始時の recAudio / inheritQuery / splitMin / mp4AutoHandoff / bestQ を毎回明示。保存設定を有効にした場合は設定値を反映し、それ以外は安全側の初期値を指定。前セッションからの残留を防ぐ。
- 診断画面の最高画質候補の順序を既存録画エンジンの画素数→FPS→帯域に揃えた。画質と音声の最終的な取得成功は未保証。
- 連続性「診断」ではURLのクエリが変化したら過去の観測履歴を消去。異なる配信を同一視しないための保守的な扱いで、署名更新だけの場合にもリセットする。URLは内部メモリで比較し、報告には出力しない。実録画の継続処理やURL自動更新は変更しない。
- 前回のプレビュー停止検知テストを固定50ms待機からコールバック待ち＋タイムアウトに変更。前回全体試験の1失敗に対応した試験安定化であり、製品コードの不具合原因が確定したという意味ではない。

## 制限と判断
- 診断のCookieチェックは目録取得用で、録画セグメント取得に引き継がれない。Referer、Origin、Authorization、署名URLの期限更新も再現・自動更新を保証しない。
- DASH録画、HTTPファイルBG再開、字幕録画、選択済み外部音声URLの直接録画は追加していない。
- URL録画とRPLAY録画は現行ホストで同時1件。開始受付は映像・音声の成功、MP4出力、デコード完了、連続性を証明しない。
- Windows、Firefox/Floorp/Chromiumの実拡張・実サービス、1080pの有無、長時間、公式プレーヤー自動停止時の挙動は未検証。
- 古いQA文書とハッシュ台帳は当時の記録であり、このファイルが今回の変更範囲を示す。

## 調査に基づく次の優先事項
1. 独立音声の時刻同期と品質昇降時の境界を、取得・結合・全編デコードで検証。異なるRendition間のMedia Sequenceだけでは同期しない。RFC 8216 §6.3.2/6.3.4: https://www.rfc-editor.org/rfc/rfc8216.html
2. 保存先と衝突時の動作をFirefox/Chromium実機で確認。downloads.downloadのfilenameは既定Downloadsからの相対パスであり、他拡張の介入も考慮。https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/downloads/download / https://developer.chrome.com/docs/extensions/reference/api/downloads
3. 同名やタイトル中の区切り文字、ダウンロード重複の回帰を優先。cat-catchの公開リリース履歴に同種の修正がある: https://github.com/xifangczy/cat-catch/releases
4. 有効な配信URLの再取得、複数同時録画、実サイト認証・リダイレクト境界、保存先表示を段階的に検証。正規アクセスの範囲でのみ扱う。

## 今回の試験
- Node: tests/test_*.cjs 全体 920 PASS / 0 FAIL（テスト用ブラウザAPI・録画ホストの模擬を含む）。
- Python HLS HTTP重点: 4 PASS / 0 FAIL。Python unittest discover全体177 PASSは前回の実行結果であり、今回は再実行していない。
- 重点Node 130 PASS（URL録画・診断UI・画質音声・クロスサイト診断など）。全体試験と重複。
- 静的JS構文、生成コピーとZIP CRC・SHA-256を別途確認。実ブラウザ・実サービスでの受入試験は含まない。
