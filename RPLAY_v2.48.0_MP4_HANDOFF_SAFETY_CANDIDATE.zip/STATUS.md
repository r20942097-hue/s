# v2.48.0 状況 — 2026-10-27 JST

CANDIDATE_NO_GO / remote_published=false
完了:
- **並行系統（ローカル v2.44.0）3モジュールの統合**: `src/mp4_handoff.js`（BG停止後MP4自動引渡し・既定OFF・非破壊・秘密ゼロ・単発実行）、`src/segment_store.js`（OPFS disk-backed segment store Stage 1 — ペア書き込み・digest fail-closed・予算LRU退避・pin・孤児清掃）、`src/preview_diag.js`（native preview環境要因の切分け）を v2.47.0 ベースへ移植
- `mp4_handoff` の完全結線: offscreen_post（MP4_HANDOFF ホスト・bg-stop enqueue・status/sweep メッセージ）、background（起動時 sweep・handoff中のoffscreen保持ガード・dashboardDefaults 検証・`rec.start` 設定伝播）、export_host（`inFlightNames` — staging/stage_failed パートの変換除外）、Chrome offscreen.html / Firefox manifest background.scripts での変換ライブラリ事前読み込み
- v2.39.0系統の `mp4Handover`（変換画面自動表示）との共存 — dashboard_settings は両フラグを受け入れ、dashboard UI に両トグルを併設。`mp4_convert` は v2.39.0 のセッション台帳案内と preview_diag の診断表示を両方提供
- 結線回帰試験 `tests/test_v2480_integration_wiring.cjs`（8件）新規 — 読み込み順・非破壊ガード・設定契約・派生コピー網羅を固定し、統合の意図しない解除を防止
- v2.47.0 までの全機能（クラッシュ復帰パート引継ぎ、`--audit-files`、`--mux-audio`、途切れ防止パリティ、CrossSite Compatibility v0.1.0、fMP4 `0xFFFFFFFF` 正規化、multi-tool command generator、SCTE-35診断、URL録画、パート書込監査、creator meta、BG経由予約確認）を完全維持
- 自動テスト合計 **1050 / 1050 PASS**（Node.js 873件 + Python 177件）

維持: v2.47のクラッシュ復帰・保存後監査・2トラック結合・途切れ防止（JS/Python鏡像）、v2.47のCrossSite統合とfMP4継続時間正規化、v2.44の録画エラー・パート確定監査、v2.43のページ通信文脈。
未完: 汎用ブラウザ内動画DL、全サービスの認証再現。（**BG停止後自動MP4は v2.48.0 で完了** — 実機受入は未受入へ）
未受入: 実ブラウザCookie条件/実RPLAY/実Nico/Windows/2GiB/長時間/native preview進行/mp4AutoHandoff ON時の実変換。
