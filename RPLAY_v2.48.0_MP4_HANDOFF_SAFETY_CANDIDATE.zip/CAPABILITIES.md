# 機能範囲 v2.48.0

|項目|状態|
|---|---|
|署名URL|表示と取得を分離。実通信URL（絶対署名URL含む）を変更せず使う|
|ページ情報|request/tab/URL照合、Referer/Origin/UA・取得元・認証の有無をRAM保持|
|Cookie/Authorization値|未収集・未保存・未出力|
|Cookie利用|明示ON時のみブラウザのcredentials include、送信条件はブラウザ依存|
|Referer/UA|観測値をFFmpegコマンド欄へ反映。fetch強制ではない|
|親query継承|明示ON時、同一originかつ未署名の子URLへ不足キーのみraw付加。署名済み子URLは維持|
|Cross-Site診断|Nico/YouTube/Twitch/RPLAY視聴ページ判別、LL-HLS/BYTERANGE/暗号化診断、HTTP応答診断|
|録画継続・耐障害|JS/Python双方で一時M3U8破損猶予(2回)・転送寸断FIFO再試行・404猶予・パート単位の書込/順序監査(`partIntegrity`)|
|断点復帰パート保持|`persistSession` v2 / `resumeFromCrash` により再読込前の確定パート(`partsLog`・`checkpoint`)を最終JSON/結合リストへ引継ぎ|
|保存後デコード監査・2トラック結合|`rplay_dl.py --audit-files` による単体デコード監査、`rplay_join.py --mux-audio` による分離音声2トラックMP4結合|
|MP4変換・復旧|fMP4初期ヘッダ `0xFFFFFFFF` 継続時間を0へ正規化、復旧時 `verifyTs` 対応|
|BG停止後のMP4引渡し|手動案内（`mp4Handover`・変換画面自動表示）＋ 自動変換・台帳引渡し（`mp4AutoHandoff`・既定OFF・非破壊・単発実行・秘密ゼロ）の併存|
|preview環境診断|変換画面のMP4プレビュー失敗要因を環境/操作/内容へ分類表示（`preview_diag.js`・表示のみで保存経路に影響しない）|
|disk-backed segment store|OPFS保存プリミティブ Stage 1（ペア書き込み・digest fail-closed・予算LRU退避・pin・孤児清掃）。取得経路には未接続|
|全サービス認証/ブラウザ内汎用動画DL|未対応|
