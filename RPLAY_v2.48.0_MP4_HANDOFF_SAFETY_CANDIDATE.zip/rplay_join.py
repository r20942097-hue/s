"""Join ordered local recording parts through FFmpeg; keep every original.

No network acquisition, transcoding, credentials, or external Python packages.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import uuid


class JoinError(ValueError):
    pass


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def run(command, timeout):
    try:
        p = subprocess.run(command, capture_output=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise JoinError('JOIN_TIMEOUT') from None
    except OSError:
        raise JoinError('JOIN_TOOL_UNAVAILABLE') from None
    if p.returncode:
        raise JoinError('JOIN_MEDIA_TOOL_FAILED')
    if len(p.stdout) > 2 * 1048576:
        raise JoinError('JOIN_PROBE_LIMIT')
    return p.stdout


def probe(path):
    data = json.loads(run(['ffprobe', '-v', 'error', '-protocol_whitelist', 'file',
        '-show_streams', '-show_format', '-show_data', '-of', 'json', str(path)], 30))
    streams = [s for s in data.get('streams', []) if s.get('codec_type') in ('video', 'audio')]
    if not streams or any(not s.get('codec_name') for s in streams):
        raise JoinError('JOIN_NO_MEDIA')
    try:
        duration = float(data['format']['duration'])
    except (KeyError, ValueError, TypeError):
        raise JoinError('JOIN_DURATION_UNKNOWN') from None
    if not math.isfinite(duration) or duration <= 0:
        raise JoinError('JOIN_DURATION_UNKNOWN')
    keys = ('codec_type', 'codec_name', 'profile', 'width', 'height', 'pix_fmt',
            'sample_rate', 'channels', 'channel_layout', 'time_base', 'extradata')
    return {'duration': duration, 'signature': [{k: s.get(k) for k in keys} for s in streams]}


def local_parts(job, directory, allow_audio=False):
    if not isinstance(job, dict):raise JoinError('JOIN_BAD_JOB')
    if job.get('audioRendition') is not None and not isinstance(job.get('audioRendition'),dict):raise JoinError('JOIN_BAD_AUDIO')
    parts = job.get('parts')
    if not isinstance(parts, list) or not 1 <= len(parts) <= 4096:
        raise JoinError('JOIN_BAD_PARTS')
    if job.get('truncated') or job.get('incomplete'):
        raise JoinError('JOIN_INCOMPLETE_JOB')
    names, result = set(), []
    for entry in parts:
        if not isinstance(entry, dict):
            raise JoinError('JOIN_BAD_PART')
        name = entry.get('file')
        if (not isinstance(name, str) or not name or name in ('.', '..') or
                any(c in name for c in '/\\:') or any(ord(c) < 32 for c in name)):
            raise JoinError('JOIN_BAD_FILENAME')
        if name in names or (not allow_audio and entry.get('kind') == 'audio'):
            raise JoinError('JOIN_DUPLICATE_OR_AUDIO_PART')
        names.add(name)
        path = directory / name
        if path.is_symlink() or not path.is_file() or path.suffix.lower() not in ('.ts', '.mp4'):
            raise JoinError('JOIN_MISSING_OR_UNSUPPORTED_PART')
        size = path.stat().st_size
        if size <= 0 or ('bytes' in entry and entry['bytes'] != size):
            raise JoinError('JOIN_SIZE_MISMATCH')
        sha = digest(path)
        if entry.get('sha256') and entry['sha256'] != sha:
            raise JoinError('JOIN_HASH_MISMATCH')
        result.append((path, size, sha))
    return result


def join_parts(job, directory, output=None, timeout=600, metadata=None, mux_audio=False):
    directory = Path(directory).resolve()
    parts = local_parts(job, directory)
    audio_parts_raw = (job.get('audioRendition') or {}).get('parts') if isinstance(job.get('audioRendition'), dict) else None
    audio_parts = []
    if audio_parts_raw:
        if not mux_audio:
            raise JoinError('JOIN_SEPARATE_AUDIO_REQUIRES_MUX')
        audio_parts = local_parts({'parts': audio_parts_raw}, directory, allow_audio=True)
        video_names = {p.name for p, _, _ in parts}
        if any(ap.name in video_names for ap, _, _ in audio_parts):
            raise JoinError('JOIN_DUPLICATE_OR_AUDIO_PART')
    for executable in ('ffmpeg', 'ffprobe'):
        if not shutil.which(executable):
            raise JoinError('JOIN_TOOL_UNAVAILABLE')
    destination = Path(output).absolute() if output else directory / ('RPLAY_joined_' + uuid.uuid4().hex + '.mp4')
    if destination.suffix.lower() != '.mp4' or destination.exists() or destination.is_symlink():
        raise JoinError('JOIN_OUTPUT_EXISTS_OR_INVALID')
    if not destination.parent.is_dir():
        raise JoinError('JOIN_OUTPUT_DIRECTORY')
    total = sum(size for _, size, _ in parts) + sum(size for _, size, _ in audio_parts)
    if shutil.disk_usage(destination.parent).free < 2 * total + 64 * 1048576:
        raise JoinError('JOIN_INSUFFICIENT_SPACE')
    descriptions = [probe(path) for path, _, _ in parts]
    signature = descriptions[0]['signature']
    if any(d['signature'] != signature for d in descriptions[1:]):
        raise JoinError('JOIN_INCOMPATIBLE_STREAMS')
    expected_duration = sum(d['duration'] for d in descriptions)
    audio_descriptions = []
    expected_audio_duration = 0.0
    if audio_parts:
        audio_descriptions = [probe(path) for path, _, _ in audio_parts]
        audio_sig = audio_descriptions[0]['signature']
        if any(d['signature'] != audio_sig for d in audio_descriptions[1:]):
            raise JoinError('JOIN_INCOMPATIBLE_AUDIO_STREAMS')
        expected_audio_duration = sum(d['duration'] for d in audio_descriptions)
        if abs(expected_audio_duration - expected_duration) > max(1.5, expected_duration * .05):
            raise JoinError('JOIN_AUDIO_DURATION_MISMATCH')
    with tempfile.TemporaryDirectory(prefix='.rsp-join-', dir=destination.parent) as temporary:
        temporary = Path(temporary)
        listing = ['ffconcat version 1.0']
        for index, (path, _, sha) in enumerate(parts):
            # Stage a stable copy under generated safe names. Copying costs disk
            # space but prevents concurrent modification of source recordings.
            name = 'input%05d%s' % (index, path.suffix.lower())
            staged = temporary / name
            shutil.copyfile(path, staged)
            if digest(staged) != sha:
                raise JoinError('JOIN_INPUT_CHANGED')
            listing.append("file '" + name + "'")
        (temporary / 'inputs.ffconcat').write_text('\n'.join(listing) + '\n', encoding='ascii')
        audio_ffconcat = None
        if audio_parts:
            a_listing = ['ffconcat version 1.0']
            for index, (path, _, sha) in enumerate(audio_parts):
                name = 'audio%05d%s' % (index, path.suffix.lower())
                staged = temporary / name
                shutil.copyfile(path, staged)
                if digest(staged) != sha:
                    raise JoinError('JOIN_INPUT_CHANGED')
                a_listing.append("file '" + name + "'")
            audio_ffconcat = temporary / 'audio_inputs.ffconcat'
            audio_ffconcat.write_text('\n'.join(a_listing) + '\n', encoding='ascii')
        candidate = temporary / 'joined.mp4'
        tags = []
        for key, value in (metadata or {}).items():
            if not key.replace('_', '').isalnum() or len(key)>64 or '\x00' in str(value):
                raise JoinError('JOIN_BAD_METADATA')
            tags += ['-metadata', key + '=' + str(value)[:4096]]
        if audio_ffconcat is not None:
            run(['ffmpeg', '-nostdin', '-hide_banner', '-v', 'error', '-xerror',
                 '-protocol_whitelist', 'file', '-f', 'concat', '-safe', '1',
                 '-i', str(temporary / 'inputs.ffconcat'),
                 '-f', 'concat', '-safe', '1',
                 '-i', str(audio_ffconcat),
                 '-map', '0:v:0', '-map', '1:a:0',
                 '-c', 'copy', '-movflags', '+faststart+use_metadata_tags'] + tags + [str(candidate)], timeout)
        else:
            run(['ffmpeg', '-nostdin', '-hide_banner', '-v', 'error', '-xerror',
                 '-protocol_whitelist', 'file', '-f', 'concat', '-safe', '1',
                 '-i', str(temporary / 'inputs.ffconcat'), '-map', '0:v?', '-map', '0:a?',
                 '-c', 'copy', '-movflags', '+faststart+use_metadata_tags'] + tags + [str(candidate)], timeout)
        measured = probe(candidate)
        if abs(measured['duration'] - expected_duration) > max(1.0, expected_duration * .03):
            raise JoinError('JOIN_DURATION_MISMATCH')
        # Full decode is distinct from byte/hash verification and container probing.
        run(['ffmpeg', '-nostdin', '-v', 'error', '-xerror', '-protocol_whitelist', 'file',
             '-i', str(candidate), '-map', '0:v?', '-map', '0:a?', '-f', 'null', '-'], timeout)
        if not candidate.is_file() or candidate.stat().st_size == 0:
            raise JoinError('JOIN_EMPTY_OUTPUT')
        sha = digest(candidate)
        size = candidate.stat().st_size
        with open(candidate, 'rb') as stream:
            os.fsync(stream.fileno())
        # Race-safe no-overwrite publication; unsupported filesystems fail closed.
        try:
            os.link(candidate, destination)
        except OSError:
            raise JoinError('JOIN_PUBLISH_FAILED') from None
    res = {'status': 'JOINED_DECODE_VERIFIED', 'file': destination.name, 'bytes': size,
           'sha256': sha, 'parts': len(parts), 'duration': measured['duration'],
           'expectedDuration': expected_duration, 'originalsRetained': True,
           'streamCopy': True, 'provenance': 'local_probe_and_full_decode',
           'inputOrder': [path.name for path, _, _ in parts]}
    if audio_parts:
        res['audioMuxed'] = True
        res['audioParts'] = len(audio_parts)
        res['expectedAudioDuration'] = expected_audio_duration
        res['audioInputOrder'] = [path.name for path, _, _ in audio_parts]
    return res


def main():
    ap = argparse.ArgumentParser(description='RPLAY: saved TS/MP4 parts to one MP4 (originals retained)')
    ap.add_argument('job', nargs='?', help='join job JSON or recording info JSON')
    ap.add_argument('--files', nargs='+', help='explicit local TS/MP4 list in playback order')
    ap.add_argument('--directory', help='folder containing every listed part; default: job folder')
    ap.add_argument('--output', help='new .mp4 output path; never overwrites')
    ap.add_argument('--timeout', type=int, default=600)
    ap.add_argument('--mux-audio', dest='mux_audio', action='store_true',
                    help='mux separate audioRendition.parts with video parts into a 2-track MP4')
    args = ap.parse_args()
    if bool(args.job)==bool(args.files):ap.error('choose one job JSON or --files')
    if args.timeout<=0:ap.error('--timeout must be positive')
    try:
        if args.files:
            paths = [(Path(args.directory or '.') / name).absolute() for name in args.files]
            if any(p.is_symlink() for p in paths):raise JoinError('JOIN_MISSING_OR_UNSUPPORTED_PART')
            directory = paths[0].parent.resolve()
            if any(p.parent.resolve()!=directory for p in paths):raise JoinError('JOIN_DIFFERENT_DIRECTORIES')
            job = {'parts':[{'file':p.name,'bytes':p.stat().st_size} for p in paths]}
        else:
            source = Path(args.job)
            if source.stat().st_size > 2 * 1048576:
                raise JoinError('JOIN_JOB_LIMIT')
            job = json.loads(source.read_text(encoding='utf-8'))
            directory = args.directory or source.parent
        result = join_parts(job, directory, args.output, args.timeout, mux_audio=args.mux_audio)
    except (JoinError, OSError, ValueError, TypeError) as exc:
        code = str(exc) if isinstance(exc, JoinError) else 'JOIN_FAILED'
        print(json.dumps({'status': 'FAILED', 'code': code, 'originalsRetained': True}))
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
