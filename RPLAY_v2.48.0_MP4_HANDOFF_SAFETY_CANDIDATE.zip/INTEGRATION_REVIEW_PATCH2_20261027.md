# RPLAY v2.48.0 統合・追加検証（Transport Integration Patch 2）

作成日: 2026-10-27 / 状態: **CANDIDATE / NO_GO** / 元ZIP SHA-256: `42ccd622c844c3761b9529ff2f994d77dd5466d29b7dbf922caf40b33dd162a4`

## 原本の選択と差分

- 主系統：今回提供された `gjgyRPLAY_Stable_Player_v2.48.0_UNIFIED_CANDIDATE.zip`。ZIP CRC正常、1,989エントリ。
- HLS/HTTP方式判別の比較系統：前回の `RPLAY_Stable_Player_v2.48.0_HLS_HTTP_TRANSPORT_CANDIDATE_20261027.zip`。古い系統を全上書きせず、必要箇所を移植。
- 主系統の `mp4_handoff.js`、`segment_store.js`、`preview_diag.js`、`hls_transport.js`、`offscreen_pre.js`、`offscreen_post.js`、`part_io.js`、`export_host.js`、Dashboard保存・予約・リカバリ機能とCLI実行コードは変更しない。
- 編集した正規ソースは `src/media_inspect_core.js`、`src/media_inspect.js`、`src/media_catalog.js`、`src/media_inspect.html`。ビルドによりルートとFirefox/Chromium派生コピーを再生成。

## 今回実装

1. **HLS / DASH / HTTPファイル判別**：拡張子・Content-Typeを候補として扱い、目録本文 `#EXTM3U` / MPD の検証を優先。HTMLや不明本文、ヒント矛盾ではコマンド生成をブロック。診断報告は署名付きURLと本文を出さない。
2. **HTTP単一ファイル取得コマンド**：MP4 / WebM / MP3等は元の拡張子で `curl` を提案。HLS向けFFmpegをMP4に誤使用しない。`--no-clobber`、リダイレクト既定拒否、認証条件の自動転送なし。自動実行・動画変換なし。
3. **HTTP Range安全判定（純粋関数）**：206 / Content-Range / 強いETagの一致を前提に追記可否を判定。200 / 416 / 弱いETag / 圧縮応答 / 不明な範囲では追記しない。**これは診断・設計用関数であり、HTTP BGダウンロードへの直接接続は未実装。**
4. **画質と音声のペア選択**：Masterの解像度・FPS・帯域から最高候補を選ぶボタンを追加。`EXT-X-MEDIA` の `GROUP-ID` がvariantの `AUDIO` と一致する別音声だけを結び、他の音声を誤用しない。対象1080pが目録にない場合は生成・保証しない。
5. **古い目録の無効化**：取得中にURLが変われば結果を適用しない。取得後も無関係なURLに変更された場合は再取得を要求。

## 検証実績と制約

- Node全回帰：**907 PASS / 0 FAIL**（今回追加34件を含む）。`rplay2482_node_final.log` の実行結果。
- Python全回帰：一括試験は所定時間内に完了せず（**全件PASSとは記載しない**）。
- Python重点：`test_cli_http.py` 1件、`test_hls_media_http.py` 4件、`test_hls_503.py` 3件、`test_v2470_cli_vtt_cc_audit.py` 2件＝**10 PASS**。
- 元コードの変更有無とZIPハッシュは `INTEGRATION_DIFFERENCE_PATCH2.json` および `SHA256SUMS.json` で照合。
- 実ブラウザ・実RPLAY・ニコニコ・Windows・長時間BG・1080p実取得・自動MP4完了の実機試験は未実施。
- 公式プレーヤー自動停止による配信側の停止、および署名URL再取得の成否も実サイト未検証。

## 次の統合ゲート

1. HLS録画エンジンの動作ログでMaster→Variant→音声→保存完了の状態を監査（手動・予約BG双方）。
2. ブラウザ版の直接HTTP保存を新規経路として設計し、Range/ETagの純粋判定を再利用して部分ファイルを無条件に追記しない。
3. Firefox/Floorp/Chromiumで保存先・filename・衝突時のユニーク化・OPFS復旧と実ファイルの整合性を観測。
4. 長時間のMaster再取得時に1080pが加わる／消えるテストと独立音声の継続性を検証。

公式仕様: RFC 8216 (variant/rendition/sequenceの取り扱い)、MDN downloads.download (相対パスと conflictAction)、MDN Fetch credentials (同一オリジンとCookieポリシー)。
