"""v2.47.0 feature acceptance (hardening release):
1. CLI version pins 2.9.1 (banner / tool strings in info JSON and ledger).
2. acceptance_report (scripts/acceptance_report.py): local-only observation
   support for ACCEPTANCE.md A1-A15 — extracts info-JSON facts and evidence
   block presence without fabricating zeros.
3. Ledger stage-contract check (REQUESTED->FILE_WRITTEN->(BROWSER_DONE)->HASHED
   ->DECODED/CONTINUITY, no skipping / no disorder).
4. sha256 cross-check between ledger HASHED records and actual part files.
5. Secret-zero enforcement: URL values re-redacted to origin+path; a tripwire
   rejects any secret-looking query in the emitted report.
Pure local file processing — no network, VM-safe."""
import hashlib,json,pathlib,subprocess,sys,tempfile,unittest
import importlib.util
R=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('v291feat',R/'rplay_dl.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
_aspec=importlib.util.spec_from_file_location('v291acc',R/'scripts'/'acceptance_report.py')
acc=importlib.util.module_from_spec(_aspec);_aspec.loader.exec_module(acc)


def _sha(b):
    return hashlib.sha256(b).hexdigest()


def _info_fixture(with_blocks=True):
    info={
        "tool":"RPLAY Live Downloader (rplay_dl.py) v2.48.0",
        "creatorOid":"a"*24,
        "playlist":"https://rplay.example/live.m3u8?sig=SECRETSIGNATURE&key2=xyz",
        "accessMode":"member",
        "sourceKind":"abr",
        "startedAt":"2026-10-26T10:00:00+09:00",
        "endedAt":"2026-10-26T11:02:05+09:00",
        "durationSec":3725,
        "totalBytes":104857600,
        "segments":3600,
        "missingSuspect":2,
        "trackingResumes":1,
        "extinfMode":"rfc",
        "stats":{"missingRate":0.0005,"missingSuspect":2},
        "qaudit":{"verdict":"pass"},
        "avCorrelation":{"verdict":"pass","driftSec":0.1,"toleranceSec":0.5},
        "parts":[{"file":"RPLAY_%s_p1.ts" % ("a"*24),"bytes":104857600,"sha256":_sha(b"p1")}],
        "queueOrder":{"videoFifoViolations":0,"audioFifoViolations":0},
    }
    if with_blocks:
        info["generationRecovery"]={"video":{"staleResponses":1,"suspectedResets":0,
                                            "sequenceResets":0,"uriRotations":0,
                                            "contextSwitches":0,"lastKind":"stale"},
                                    "audio":{"staleResponses":0,"suspectedResets":0,
                                              "sequenceResets":0,"uriRotations":0,
                                              "contextSwitches":0}}
        info["fmp4Evidence"]={"video":{"mapDeclarations":2,"mapSwitches":1,
                                        "mapSwitchesWithoutDiscontinuity":0,
                                        "crossPollMapSwitches":0},
                              "audio":{"mapDeclarations":0,"mapSwitches":0,
                                        "mapSwitchesWithoutDiscontinuity":0,
                                        "crossPollMapSwitches":0}}
        info["llhlsEvidence"]={"videoIndicators":3,"audioIndicators":0}
        info["authEvidence"]={"mode":"localStorage-interceptor","tokenSource":"localStorage",
                              "refreshSource":None,"responseKey":None,
                              "classifications401":{"auth-expired":1},"key2Resolutions":2}
        info["canaryEvidence"]={"result":"ok","action":"warn_only"}
        info["sessionTrackingEvidence"]={"sameSessionResumes":1,"newSessionSplits":0,
                                          "thresholdSec":600}
        info["errorTaxonomyEvidence"]={"counts":{"network":1}}
        info["notificationEvidence"]={"sent":5,"failed":0,"rateLimited429":0}
        info["subtitleEvidence"]={"renditionCount":2,"variantsLinked":1,
                                  "policy":"observed_not_fetched"}
    # metadataEvidence は意図的に欠落させる(不在表示の検証用)
    return info


def _ledger_fixture():
    return {"tool":"rplay_dl.py v2.48.0","creatorOid":"a"*24,
            "startedAt":"2026-10-26T10:00:00+09:00",
            "parts":[
                {"file":"RPLAY_%s_p1.ts" % ("a"*24),"track":"video","status":"CONFIRMED_HASHED",
                 "stages":[{"stage":"REQUESTED","at":"2026-10-26T10:00:01+09:00"},
                           {"stage":"FILE_WRITTEN","at":"2026-10-26T11:00:00+09:00","bytes":104857600},
                           {"stage":"HASHED","at":"2026-10-26T11:00:01+09:00","sha256":_sha(b"p1")}]},
                {"file":"RPLAY_%s_p2.ts" % ("a"*24),"track":"video","status":"CONFIRMED_HASHED",
                 "stages":[{"stage":"REQUESTED","at":"2026-10-26T11:00:02+09:00"},
                           {"stage":"HASHED","at":"2026-10-26T11:30:00+09:00","sha256":_sha(b"tampered")},
                           {"stage":"FILE_WRITTEN","at":"2026-10-26T11:31:00+09:00"}]},
            ]}


class UnitV291Features(unittest.TestCase):
    def test_cli_version_pins_2_9_1(self):
        cli=(R/'rplay_dl.py').read_text(encoding='utf-8')
        self.assertIn('RPLAY Live Downloader v2.48.0 CANDIDATE',cli)
        self.assertIn('RPLAY Live Downloader (rplay_dl.py) v2.48.0',cli)
        self.assertEqual(cli.count('"tool": "rplay_dl.py v2.48.0"'),4)  # webhook/ledger/段階/orphan

    def test_report_basic_facts_and_placeholders(self):
        with tempfile.TemporaryDirectory() as d:
            dp=pathlib.Path(d)
            (dp/('RPLAY_%s_info.json' % ('a'*24))).write_text(
                json.dumps(_info_fixture(),ensure_ascii=False,indent=2),encoding='utf-8')
            rep=acc.build_report(dp)
            self.assertIn('acceptance_report.py v2.48.0',rep)
            self.assertIn('RPLAY Live Downloader (rplay_dl.py) v2.48.0',rep)
            self.assertIn('durationSec: 3725',rep)
            self.assertIn('totalBytes: 104857600',rep)
            self.assertIn('missingSuspect: 2',rep)
            self.assertIn('パート数: 1',rep)
            self.assertIn('qaudit: pass',rep)
            self.assertIn('avCorrelation: pass',rep)
            # 人間観察項目はプレースホルダー(虚偽を書かない)
            self.assertIn('確認待ち',rep)
            self.assertIn('再生確認',rep)

    def test_evidence_block_presence_and_absence(self):
        with tempfile.TemporaryDirectory() as d:
            dp=pathlib.Path(d)
            (dp/('RPLAY_%s_info.json' % ('a'*24))).write_text(
                json.dumps(_info_fixture(),ensure_ascii=False,indent=2),encoding='utf-8')
            rep=acc.build_report(dp)
            # 在ブロックは計数つきで列挙(A10/A15支援)
            self.assertIn('subtitleEvidence',rep)
            self.assertIn('renditionCount=2',rep)
            self.assertIn('observed_not_fetched',rep)
            self.assertIn('canaryEvidence',rep)
            self.assertIn('result=ok',rep)
            self.assertIn('fmp4Evidence',rep)
            self.assertIn('mapSwitches=1',rep)
            self.assertIn('sessionTrackingEvidence',rep)
            # 欠落ブロックは「不在」と記録(虚偽零なし・数値を捏造しない)
            self.assertIn('metadataEvidence',rep)
            self.assertIn('不在',rep)

    def test_secret_redaction_and_tripwire(self):
        with tempfile.TemporaryDirectory() as d:
            dp=pathlib.Path(d)
            (dp/('RPLAY_%s_info.json' % ('a'*24))).write_text(
                json.dumps(_info_fixture(),ensure_ascii=False,indent=2),encoding='utf-8')
            rep=acc.build_report(dp)
            # URL値はorigin+pathのみ(署名クエリは再秘匿される)
            self.assertIn('https://rplay.example/live.m3u8',rep)
            self.assertNotIn('SECRETSIGNATURE',rep)
            self.assertNotIn('key2=xyz',rep)
            self.assertNotIn('sig=',rep)
            # トリップワイヤー: 秘密疑いクエリが検出されたら報告しない
            self.assertEqual(acc.secret_tripwire(rep),[])
            bad='see https://x.example/a.m3u8?token=abc123 and ?jwt=zzz'
            self.assertTrue(len(acc.secret_tripwire(bad))>=2)

    def test_ledger_stage_contract(self):
        led=_ledger_fixture()
        # p1: 正常順序 → 違反なし / p2: HASHEDがFILE_WRITTENより前 → 順序違反
        v=acc.ledger_stage_violations(led)
        self.assertEqual(len(v),1)
        self.assertIn('RPLAY_%s_p2.ts' % ('a'*24),v[0])
        self.assertIn('HASHED',v[0])
        good={"parts":[{"file":"p.ts","track":"video","stages":[
            {"stage":"REQUESTED"},{"stage":"FILE_WRITTEN"},{"stage":"HASHED","sha256":"x"}]}]}
        self.assertEqual(acc.ledger_stage_violations(good),[])
        browser={"parts":[{"file":"p.ts","track":"video","stages":[
            {"stage":"REQUESTED"},{"stage":"FILE_WRITTEN"},{"stage":"BROWSER_DONE"},
            {"stage":"HASHED","sha256":"x"}]}]}
        self.assertEqual(acc.ledger_stage_violations(browser),[])
        # 段階欠落(HASHEDなし)は違反ではなくstatus側の問題として扱う(飛び越しのみ検知)
        nohashed={"parts":[{"file":"p.ts","track":"video","stages":[
            {"stage":"REQUESTED"},{"stage":"FILE_WRITTEN"}]}]}
        self.assertEqual(acc.ledger_stage_violations(nohashed),[])

    def test_sha256_crosscheck(self):
        with tempfile.TemporaryDirectory() as d:
            dp=pathlib.Path(d)
            (dp/('RPLAY_%s_p1.ts' % ('a'*24))).write_bytes(b'p1')
            (dp/('RPLAY_%s_p2.ts' % ('a'*24))).write_bytes(b'other')  # 破損(改竄)パート
            led=_ledger_fixture()
            rows=acc.sha256_crosscheck(led,dp)
            byfile={r['file']:r for r in rows}
            self.assertEqual(byfile['RPLAY_%s_p1.ts' % ('a'*24)]['result'],'一致')
            self.assertEqual(byfile['RPLAY_%s_p2.ts' % ('a'*24)]['result'],'不一致')
            # レポート本文にも反映される
            (dp/('RPLAY_%s_ledger.json' % ('a'*24))).write_text(
                json.dumps(led,ensure_ascii=False,indent=2),encoding='utf-8')
            rep=acc.build_report(dp)
            self.assertIn('一致',rep)
            self.assertIn('不一致',rep)

    def test_invalid_and_empty_inputs(self):
        # 空ディレクトリ: mainはexit 2(対象なし)・build_reportはValueError
        with tempfile.TemporaryDirectory() as d:
            dp=pathlib.Path(d)
            with self.assertRaises(ValueError):
                acc.build_report(dp)
            rc=acc.main(['--dir',d])
            self.assertEqual(rc,2)
        # 破損JSON: 読み込み失敗行を出し、他ファイルの処理は継続する
        with tempfile.TemporaryDirectory() as d:
            dp=pathlib.Path(d)
            (dp/'RPLAY_broken_info.json').write_text('{not json',encoding='utf-8')
            (dp/('RPLAY_%s_info.json' % ('a'*24))).write_text(
                json.dumps(_info_fixture(),ensure_ascii=False,indent=2),encoding='utf-8')
            rep=acc.build_report(dp)
            self.assertIn('読み込み失敗',rep)
            self.assertIn('durationSec: 3725',rep)
            rc=acc.main(['--dir',d])
            self.assertEqual(rc,0)


if __name__=='__main__':
    unittest.main()
