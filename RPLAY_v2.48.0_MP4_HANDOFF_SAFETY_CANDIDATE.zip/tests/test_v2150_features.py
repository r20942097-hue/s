"""v2.15.0 feature acceptance (7-branch unification + E2E disguised TS + query inheritance + rplay_join + acceptance_report):
1. CLI and acceptance_report.py version pins 2.15.0.
2. End-to-end integration of cat-catch disguised TS stripping + M3U8 query inheritance + discontinuity split + rplay_join.py decode-verified MP4 aggregation + acceptance_report.py observation draft generation with zero-secret tripwire.
Local HTTP and FFmpeg only — VM-safe."""
import http.server,threading,tempfile,pathlib,subprocess,sys,json,unittest

R=pathlib.Path(__file__).resolve().parents[1]


class V2150UnifiedE2E(unittest.TestCase):
    def test_version_pins_2_15_0(self):
        cli=(R/'rplay_dl.py').read_text(encoding='utf-8')
        self.assertIn('RPLAY Live Downloader v2.48.0 CANDIDATE',cli)
        self.assertIn('RPLAY Live Downloader (rplay_dl.py) v2.48.0',cli)
        acc=(R/'scripts'/'acceptance_report.py').read_text(encoding='utf-8')
        self.assertIn('acceptance_report.py v2.48.0',acc)

    def test_e2e_disguised_ts_query_inheritance_join_and_acceptance_report(self):
        with tempfile.TemporaryDirectory() as media_dir:
            mp=pathlib.Path(media_dir)
            for name,color in [('seg0.ts','red'),('seg1.ts','blue')]:
                subprocess.run([
                    'ffmpeg','-nostdin','-v','error',
                    '-f','lavfi','-i','color=c=%s:s=64x64:r=10'%color,
                    '-f','lavfi','-i','sine=frequency=440:sample_rate=48000',
                    '-t','1','-c:v','libx264','-preset','ultrafast','-pix_fmt','yuv420p',
                    '-c:a','aac','-f','mpegts',str(mp/name)
                ],check=True,timeout=20)
            png_prefix=b'\x89PNG\r\n\x1a\n'+b'\x11'*16
            seg0_disguised=png_prefix+(mp/'seg0.ts').read_bytes()
            seg1_disguised=png_prefix+(mp/'seg1.ts').read_bytes()
            playlist=(
                '#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:0\n'
                '#EXTINF:1,\nseg0.ts\n'
                '#EXT-X-DISCONTINUITY\n'
                '#EXTINF:1,\nseg1.ts\n'
                '#EXT-X-ENDLIST\n'
            )
            class H(http.server.BaseHTTPRequestHandler):
                def log_message(self,*a):pass
                def _send(s,code,body=b''):
                    s.send_response(code);s.send_header('Content-Length',str(len(body)));s.end_headers();s.wfile.write(body)
                def do_GET(s):
                    path,_,q=s.path.partition('?')
                    if path=='/api/live/play':
                        s._send(200,json.dumps({'streamState':'live','accessible':True,'allowAnonymous':True,'title':'Unified2150'}).encode());return
                    if path=='/live.m3u8':
                        s._send(200,playlist.encode());return
                    if path=='/seg0.ts':
                        if 'sig=SECRET_TOKEN_2150' not in q:s._send(403);return
                        s._send(200,seg0_disguised);return
                    if path=='/seg1.ts':
                        if 'sig=SECRET_TOKEN_2150' not in q:s._send(403);return
                        s._send(200,seg1_disguised);return
                    s._send(404)

            srv=http.server.ThreadingHTTPServer(('127.0.0.1',0),H)
            threading.Thread(target=srv.serve_forever,daemon=True).start()
            url='http://127.0.0.1:%d'%srv.server_port
            try:
                out_dir=mp/'rec'
                cmd=[
                    sys.executable,str(R/'rplay_dl.py'),'a'*24,
                    '--api',url+'/api',
                    '--m3u8',url+'/live.m3u8?sig=SECRET_TOKEN_2150',
                    '--inherit-query','--split-on-discontinuity',
                    '--mux','auto','--join-parts','auto',
                    '--no-follow','--no-flv','--info-json','--out',str(out_dir)
                ]
                p=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                info=json.loads(next(out_dir.glob('*_info.json')).read_text(encoding='utf-8'))
                self.assertEqual(info['aggregationEvidence']['status'],'JOINED_DECODE_VERIFIED')
                self.assertEqual(info['externalDownloaderEvidence']['tsDisguiseStrippedCount'],2)
                self.assertEqual(info['externalDownloaderEvidence']['tsDisguiseBytesTotal'],48)
                self.assertGreaterEqual(info['externalDownloaderEvidence']['queryInheritedCount'],2)
                self.assertNotIn('SECRET_TOKEN_2150',json.dumps(info))

                # Run acceptance_report.py on the recorded output directory
                rep_out=mp/'report.md'
                p_acc=subprocess.run(
                    [sys.executable,str(R/'scripts'/'acceptance_report.py'),'--dir',str(out_dir),'--out',str(rep_out)],
                    capture_output=True,text=True,timeout=20
                )
                self.assertEqual(p_acc.returncode,0,p_acc.stdout+p_acc.stderr)
                rep_txt=rep_out.read_text(encoding='utf-8')
                self.assertIn('acceptance_report.py v2.48.0',rep_txt)
                self.assertIn('JOINED_DECODE_VERIFIED',rep_txt)
                self.assertIn('tsDisguiseStrippedCount=2',rep_txt)
                self.assertNotIn('SECRET_TOKEN_2150',rep_txt)
            finally:
                srv.shutdown();srv.server_close()


if __name__=='__main__':
    unittest.main()
