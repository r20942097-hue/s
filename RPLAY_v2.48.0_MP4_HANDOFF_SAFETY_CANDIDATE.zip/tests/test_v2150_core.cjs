'use strict';
/* v2.15.0 core features (7-branch unification + GOP/PES-aligned streaming TS-to-fMP4 converter):
   1. Unified 2.15.0 version pin across userscript, Chrome/Firefox manifests, CLI, acceptance_report.py, rplay_join.py, recovery, and mp4_convert.
   2. M-01: splitTsGopAligned — splits MPEG-TS streams at exact video keyframe (PUSI=1, RAI=1) and audio PES (PUSI=1) boundaries with PAT+PMT injection so mux.js never flushes mid-PES or mid-GOP.
   3. M-02: convertStreamed — streams TS inputs up to 2 GiB (MAX_STREAM_INPUT) via bounded file.slice() windows (never calling full-file arrayBuffer()), producing frame-accurate and ADTS-identical fMP4 verified by FFmpeg -xerror and streaming SHA-256.
   4. M-03: Disguised TS support in MP4 converter — strips cat-catch PNG/GIF/BMP/JPEG/WEBP/ID3 headers before tsPlan and mux.js transmuxing.
   5. Full coexistence of v2.9.1 (rspBlobHoldMs), v2.10.0 AGGREGATE (recJoinJob/rplay_join.py), v2.10.0 UNIFIED (partContinuityEvidence), v2.11.0 (flush/continuousDisk), v2.12.0 (RecCheckpointStore/RspRecovery), v2.13.0 (RspSha256), v2.14.0 (RspMp4Convert), and cat-catch (C-01..C-03). */
const {test,before,after}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),vm=require('node:vm'),{spawnSync}=require('node:child_process'),crypto=require('node:crypto');
const ROOT=path.join(__dirname,'..');
const mp4Core=require('../src/mp4_convert_core.js'),hashing=require('../src/sha256.js');
const c=vm.createContext({console,Uint8Array,Uint32Array,DataView,ArrayBuffer});c.window=c;
vm.runInContext(fs.readFileSync(path.join(ROOT,'src/vendor/mux.min.js'),'utf8'),c);

let dir,whole;
function run(cmd,args){const r=spawnSync(cmd,args,{timeout:20000,maxBuffer:4*1048576});a.equal(r.status,0,r.stderr?.toString());return r.stdout;}
function frames(file){return run('ffmpeg',['-v','error','-i',file,'-map','0:v:0','-vsync','0','-f','framemd5','-']).toString().split('\n').filter(l=>l&&!l.startsWith('#')).map(l=>l.split(',').at(-1).trim());}
function adts(file){return run('ffmpeg',['-v','error','-i',file,'-map','0:a:0','-c','copy','-f','adts','-']);}

before(()=>{
  dir=fs.mkdtempSync(path.join(os.tmpdir(),'rsp-v2150-'));
  whole=path.join(dir,'whole.ts');
  run('ffmpeg',['-v','error','-f','lavfi','-i','testsrc2=s=160x90:r=25:d=8','-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=8','-c:v','libx264','-preset','medium','-g','50','-c:a','aac','-f','mpegts',whole]);
});
after(()=>fs.rmSync(dir,{recursive:true,force:true}));

test('v2.15.0 version pin: userscript @version, both manifests, CLI strings, join & acceptance tools, recovery & mp4_convert',()=>{
  const us=fs.readFileSync(path.join(ROOT,'rplay-stable-player.user.js'),'utf8');
  a.match(us,/\/\/ @version\s+2\.48\.0/);
  for(const ext of ['rplay-stable-player-extension','rplay-stable-player-extension-firefox']){
    const m=JSON.parse(fs.readFileSync(path.join(ROOT,ext,'manifest.json'),'utf8'));
    a.equal(m.version,'2.48.0',ext);
    if(ext.endsWith('-firefox')) a.equal(Object.hasOwn(m,'version_name'),false,'Firefox must omit unsupported version_name'); else a.equal(m.version_name,'2.48.0 CANDIDATE',ext+' version_name');
  }
  const cli=fs.readFileSync(path.join(ROOT,'rplay_dl.py'),'utf8');
  a.match(cli,/RPLAY Live Downloader v2\.48\.0 CANDIDATE/);
  a.match(cli,/rplay_dl\.py v2\.48\.0/);
  a.match(cli,/\(rplay_dl\.py\) v2\.48\.0/);
  for(const f of ['rplay_join.py','recovery.html','recovery_core.js','sha256.js','mp4_convert.html','mp4_convert_core.js']){
    a.ok(fs.existsSync(path.join(ROOT,f)),f+' must exist at root');
  }
});

test('v2.15.0 splitTsGopAligned: splits MPEG-TS at video keyframe (PUSI+RAI) and audio PES boundaries with zero frame or audio loss',()=>{
  a.equal(typeof mp4Core.splitTsGopAligned,'function');
  const raw=new Uint8Array(fs.readFileSync(whole));
  const chunks=mp4Core.splitTsGopAligned(raw,50000);
  a.ok(chunks.length>=4,'8s TS with 4 GOPs (~258KB) must split into 4 GOP-aligned chunks at 50KB target');
  for(const ch of chunks){
    a.equal(ch.length%188,0);
    // Every GOP chunk must be a valid standalone TS starting with PAT+PMT
    const plan=mp4Core.tsPlan(ch);
    a.equal(plan.audio,true);
  }
});

test('v2.15.0 convertStreamed: streams TS via bounded file.slice() reads (forbidding full arrayBuffer) and matches FFmpeg framemd5 & ADTS audio',async()=>{
  a.equal(typeof mp4Core.convertStreamed,'function');
  a.equal(mp4Core.MAX_STREAM_INPUT,2048*1048576);
  const rawBuf=fs.readFileSync(whole);
  const blob=new Blob([rawBuf]);
  let maxSlice=0,sliceReads=0;
  const slicedHandle={
    name:'streamed.ts',
    isSameEntry:async()=>false,
    getFile:async()=>({
      size:blob.size,
      slice(start,end){
        const len=Math.max(0,Math.min(end,blob.size)-start);
        maxSlice=Math.max(maxSlice,len);
        sliceReads++;
        return blob.slice(start,end);
      },
      arrayBuffer(){throw Error('FULL_ARRAYBUFFER_FORBIDDEN');}
    })
  };
  let stored=null,pending=[];
  const dest={
    isSameEntry:async h=>h===dest,
    getFile:async()=>stored,
    createWritable:async()=>({
      write:async b=>pending.push(new Uint8Array(b)),
      close:async()=>{stored=new Blob(pending);},
      abort:async()=>{pending=[];}
    })
  };
  const res=await mp4Core.convertStreamed({
    inputs:[slicedHandle],
    destination:dest,
    muxjs:c.muxjs,
    hashing,
    sliceBytes:64*1024,
    chunkTargetBytes:50000
  });
  a.equal(res.confirmed,true);
  a.equal(res.audio,true);
  a.ok(res.chunksProcessed>=4,'must process multiple GOP-aligned chunks');
  a.ok(sliceReads>=4,'must read via bounded file.slice() calls');
  a.ok(maxSlice<=64*1024,'slice read size must respect sliceBytes cap');
  const outMp4=path.join(dir,'streamed.mp4');
  fs.writeFileSync(outMp4,Buffer.from(await stored.arrayBuffer()));
  a.equal(res.sha256,crypto.createHash('sha256').update(fs.readFileSync(outMp4)).digest('hex'));
  run('ffmpeg',['-v','error','-xerror','-i',outMp4,'-f','null','-']);
  a.deepEqual(frames(outMp4),frames(whole));
  a.deepEqual(adts(outMp4),adts(whole));
});

test('v2.15.0 convertStreamed strips cat-catch PNG/GIF disguise header from TS input before transmuxing to fMP4',async()=>{
  const rawBuf=fs.readFileSync(whole);
  const pngHeader=Buffer.from([0x89,0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A,...Buffer.alloc(24,0x42)]);
  const disguisedBuf=Buffer.concat([pngHeader,rawBuf]);
  const blob=new Blob([disguisedBuf]);
  const handle={name:'disguised.ts',isSameEntry:async()=>false,getFile:async()=>blob};
  let stored=null,pending=[];
  const dest={
    isSameEntry:async h=>h===dest,
    getFile:async()=>stored,
    createWritable:async()=>({
      write:async b=>pending.push(new Uint8Array(b)),
      close:async()=>{stored=new Blob(pending);},
      abort:async()=>{pending=[];}
    })
  };
  const res=await mp4Core.convertStreamed({
    inputs:[handle],
    destination:dest,
    muxjs:c.muxjs,
    hashing,
    stripDisguise:true
  });
  a.equal(res.confirmed,true);
  a.equal(res.disguiseStrippedBytes,32);
  const outMp4=path.join(dir,'disguised_converted.mp4');
  fs.writeFileSync(outMp4,Buffer.from(await stored.arrayBuffer()));
  run('ffmpeg',['-v','error','-xerror','-i',outMp4,'-f','null','-']);
  a.deepEqual(frames(outMp4),frames(whole));
});

test('v2.15.0 7-branch full integration check in userscript and extensions',()=>{
  const source=fs.readFileSync(path.join(ROOT,'rplay-stable-player.user.js'),'utf8');
  a.match(source,/function rspBlobHoldMs\(/);
  a.match(source,/function rspDelayedBlobRelease\(/);
  a.match(source,/class RecCheckpointStore\b/);
  a.match(source,/RspSha256\.hashBlob\(/);
  a.match(source,/function recJoinJob\(/);
  a.match(source,/async saveJoinJob\(\)/);
  a.match(source,/function rspPartContinuityEvidence\(/);
  a.match(source,/continuousDisk\(\)/);
  a.match(source,/function rspBuildM3u8dlExport\(/);
});
