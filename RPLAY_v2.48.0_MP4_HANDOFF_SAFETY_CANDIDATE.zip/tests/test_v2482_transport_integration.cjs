'use strict';
const test=require('node:test'),a=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const M=require('../src/media_inspect_core.js'),C=require('../src/media_catalog.js'),H=require('../src/hls_transport.js');
const url='https://livestream.example.invalid/live/xx_abrud/index.m3u8?token=KEEP_SECRET';
const cases=[
 ['HLS extension is a candidate only',()=>{const r=M.transportDecision({url});a.equal(r.route,'hls');a.equal(r.bodyVerified,false);a.equal(r.mayDirectDownload,false);} ],
 ['validated HLS body wins over MP4 extension',()=>a.equal(M.transportDecision({url:'https://cdn.invalid/v.mp4',body:'#EXTM3U\n#EXTINF:5,\nx.ts'}).route,'hls')],
 ['MPD without extension is recognized',()=>a.equal(M.transportDecision({url:'https://cdn.invalid/get?id=9',body:'<?xml version="1.0"?><MPD type="static"/>'}).route,'dash')],
 ['HTML response blocks MP4 suffix',()=>a.equal(M.transportDecision({url:'https://cdn.invalid/a.mp4',body:'<html>unauthorized</html>'}).route,'not-media')],
 ['MIME versus extension conflict blocked',()=>a.equal(M.transportDecision({url,mime:'video/mp4'}).route,'ambiguous')],
 ['unknown body blocks hinted HLS',()=>a.equal(M.transportDecision({url,body:'403 forbidden'}).route,'unknown')],
 ['no extension no MIME is unknown',()=>a.equal(M.transportDecision({url:'https://cdn.invalid/get'}).route,'unknown')],
 ['token absent from report',()=>a.equal(JSON.stringify(M.transportDecision({url})).includes('KEEP_SECRET'),false)],
 ['direct MP4 command does not remux',()=>{const p=M.httpFileCommands({url:'https://cdn.invalid/x.mp4',output:'file.mp4'});a.match(p.command,/^curl.exe /);a.match(p.command,/--no-clobber/);a.equal(p.command.includes('ffmpeg'),false);a.equal(p.output,'file.mp4');}],
 ['WebM output has WebM suffix',()=>a.equal(M.httpFileCommands({url:'https://cdn.invalid/a.webm'}).output,'RPLAY_output.webm')],
 ['HTTP MP3 does not claim MP4',()=>a.equal(M.httpFileCommands({url:'https://cdn.invalid/a.mp3',output:'out.mp4'}).output,'out.mp3')],
 ['HLS cannot be direct single-file',()=>a.throws(()=>M.httpFileCommands({url}),/DIRECT_HTTP_FILE_REQUIRED/)],
 ['DASH cannot be direct single-file',()=>a.throws(()=>M.httpFileCommands({url:'https://cdn.invalid/manifest.mpd'}),/DIRECT_HTTP_FILE_REQUIRED/)],
 ['Reject URL credentials',()=>a.throws(()=>M.transportDecision({url:'https://name:password@cdn.invalid/a.mp4'}),/INVALID_HTTP_URL/)],
 ['Reject injected User-Agent',()=>a.throws(()=>M.httpFileCommands({url:'https://cdn.invalid/a.mp4',userAgent:'x\r\nCookie: secret'}),/INVALID_HEADER/)],
 ['Valid 206 with same strong ETag',()=>a.equal(M.httpResumeDecision({requestedFrom:500,status:206,contentRange:'bytes 500-999/1000',oldEtag:'"v1"',newEtag:'"v1"'}).action,'append')],
 ['Reject shifted Content-Range',()=>a.equal(M.httpResumeDecision({requestedFrom:500,status:206,contentRange:'bytes 0-999/1000',oldEtag:'"v1"',newEtag:'"v1"'}).action,'reject')],
 ['Reject ETag changed',()=>a.equal(M.httpResumeDecision({requestedFrom:500,status:206,contentRange:'bytes 500-999/1000',oldEtag:'"v1"',newEtag:'"v2"'}).action,'reject')],
 ['Reject weak ETag',()=>a.equal(M.httpResumeDecision({requestedFrom:500,status:206,contentRange:'bytes 500-999/1000',oldEtag:'W/"v1"',newEtag:'W/"v1"'}).action,'reject')],
 ['Reject unknown content encoding',()=>a.equal(M.httpResumeDecision({requestedFrom:500,status:206,contentRange:'bytes 500-999/1000',oldEtag:'"v1"',newEtag:'"v1"',contentEncoding:'gzip'}).action,'reject')],
 ['200 on resume restarts new file only',()=>a.equal(M.httpResumeDecision({requestedFrom:500,status:200}).action,'restart-new-file')],
 ['416 stops without append',()=>a.equal(M.httpResumeDecision({requestedFrom:500,status:416}).action,'stop')],
 ['Fresh 200 is new file',()=>a.equal(M.httpResumeDecision({requestedFrom:0,status:200}).action,'new-file')],
 ['Reject bad offset',()=>a.throws(()=>M.httpResumeDecision({requestedFrom:-10,status:206}),/INVALID_OFFSET/)],
];
for(const [name,fn] of cases)test(name,fn);
const master='#EXTM3U\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="english",NAME="eng",DEFAULT=YES,URI="eng.m3u8"\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="japanese",NAME="jpn",DEFAULT=YES,URI="jp.m3u8"\n#EXT-X-STREAM-INF:BANDWIDTH=1400000,RESOLUTION=1280x720,FRAME-RATE=60,AUDIO="english"\n720.m3u8\n#EXT-X-STREAM-INF:BANDWIDTH=3200000,RESOLUTION=1920x1080,FRAME-RATE=30,AUDIO="japanese"\n1080.m3u8';
const base='https://cdn.invalid/master.m3u8?secret=opaque';
test('Highest resolution selected and matching audio, not unrelated default',()=>{const r=C.manifest(master,base,H);const best=C.bestVariant(r),sound=C.pairVariantAudio(r,best);a.equal(best.resolution,'1920x1080');a.equal(sound.name,'jpn');a.equal(sound.groupId,'japanese');});
test('Same resolution prioritizes frame rate over bitrate',()=>{const r=C.manifest('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=5000000,RESOLUTION=1920x1080,FRAME-RATE=30\na.m3u8\n#EXT-X-STREAM-INF:BANDWIDTH=4500000,RESOLUTION=1920x1080,FRAME-RATE=60\nb.m3u8',base,H);a.match(C.bestVariant(r).url,/b\.m3u8/);});
test('No 1080p does not hallucinate higher quality',()=>{const r=C.manifest('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=2200000,RESOLUTION=1280x720\n720.m3u8',base,H);a.equal(C.bestVariant(r).resolution,'1280x720');a.equal(C.pairVariantAudio(r,C.bestVariant(r)),null);});
test('Missing audio group cannot attach unrelated audio',()=>{const r=C.manifest(master.replace('AUDIO="japanese"','AUDIO="missing"'),base,H);a.equal(C.pairVariantAudio(r,C.bestVariant(r)),null);});
test('HLS candidate report adds nonsecret decision',()=>{const r=M.safeReport({url});a.equal(r.transfer.route,'hls');a.equal(JSON.stringify(r).includes('KEEP_SECRET'),false);});
test('UI highest button changes video and corresponding audio',async()=>{const nodes=new Map();function element(){return{value:'',checked:false,textContent:'',disabled:false,children:[],events:{},addEventListener(n,f){this.events[n]=f;},replaceChildren(){this.children=[]},appendChild(v){this.children.push(v)}}};const field=id=>{if(!nodes.has(id))nodes.set(id,element());return nodes.get(id)};const ctx=vm.createContext({document:{getElementById:field,createElement:element,createTextNode:t=>({textContent:t})},location:{hash:''},navigator:{},AbortController,addEventListener(){},RspMediaInspect:M,RspMediaCatalog:{...C,load:async(u)=>({body:master,rows:C.manifest(master,u,H)})}});vm.runInContext(fs.readFileSync(path.join(__dirname,'../src/media_inspect.js'),'utf8'),ctx);field('url').value=base;await field('loadManifest').onclick();field('bestVariant').events.click();a.match(field('url').value,/1080\.m3u8/);a.match(field('audioUrl').value,/jp\.m3u8/);a.equal(field('command').value,'');});
test('UI refuses HLS FFmpeg command on single MP4',()=>{const nodes=new Map();function e(){return{value:'',textContent:'',addEventListener(n,f){this[n]=f}}};const field=id=>{if(!nodes.has(id))nodes.set(id,e());return nodes.get(id)};const ctx=vm.createContext({document:{getElementById:field},location:{hash:''},navigator:{},addEventListener(){},RspMediaInspect:M,RspMediaCatalog:C});vm.runInContext(fs.readFileSync(path.join(__dirname,'../src/media_inspect.js'),'utf8'),ctx);field('url').value='https://cdn.invalid/file.webm';field('filename').value='RPLAY_output.mp4';field('shell').value='powershell';field('generate').click();a.match(field('command').value,/curl.exe/);a.equal(field('command').value.includes('ffmpeg -n'),false);a.match(field('command').value,/RPLAY_output\.webm/);});

test('HTML error in diagnostic is blocked without leaking content',()=>{const r=M.safeReport({url:'https://cdn.invalid/a.mp4?secret=TOKEN',body:'<html>PAYLOAD_PRIVATE</html>'});a.equal(r.workflow.stage,'BLOCKED');a.equal(JSON.stringify(r).includes('PAYLOAD_PRIVATE'),false);a.equal(JSON.stringify(r).includes('TOKEN'),false);});
test('Direct file diagnostic explicitly says unverified',()=>{const r=M.safeReport({url:'https://cdn.invalid/file.mp4?sig=PRIVATE'});a.equal(r.workflow.stage,'HTTP_FILE_CANDIDATE');a.equal(r.workflow.verifiedDownload,false);a.equal(JSON.stringify(r).includes('PRIVATE'),false);});
test('Direct HTTP command refuses automatic cross-site redirects',()=>{const r=M.httpFileCommands({url:'https://cdn.invalid/file.mp4'});a.equal(r.command.includes('--location'),false);a.match(r.note,/リダイレクト/);});
