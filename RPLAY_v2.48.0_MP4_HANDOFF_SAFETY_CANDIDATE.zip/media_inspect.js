'use strict';
const field=id=>document.getElementById(id),value=id=>field(id).value;
field('inspect').addEventListener('click',()=>{try{field('result').textContent=JSON.stringify(RspMediaInspect.safeReport({url:value('url'),mime:value('mime'),body:value('body')}),null,2);}catch(e){field('result').textContent=e.message;}});
field('generate').addEventListener('click',()=>{field('command').value='';try{const transfer=RspMediaInspect.transportDecision({url:value('url'),mime:value('mime'),body:value('body')});if(transfer.route==='http-file'){const direct=RspMediaInspect.httpFileCommands({url:value('url'),mime:value('mime'),output:value('filename'),shell:value('shell'),referer:value('referer'),userAgent:value('agent')});field('command').value='# HTTP直接ファイルの保存（変換なし / 自動実行しません）\n'+direct.command;field('copy-status').textContent=direct.note;return;}if(transfer.route==='dash'){field('copy-status').textContent='DASHはMPD解析/専用CLIを使用してください。この画面ではHLS用FFmpegコマンドを生成しません。';return;}if(transfer.route!=='hls'){field('copy-status').textContent='動画形式が未確認、またはURL・MIME・本文が矛盾しています。先に取得形式を確認してください。';return;}const c=RspMediaInspect.commands({url:value('url'),referer:value('referer'),userAgent:value('agent'),output:value('filename'),shell:value('shell'),audioUrl:value('audioUrl')});field('command').value='# '+c.shell+' / 自動実行しません\n'+c.ffmpeg+'\n\n# 応答をそのまま取得（MP4変換ではありません）\n'+c.curl+(c.nm3u8dlRe?'\n\n# N_m3u8DL-RE（ライブ・分割ストリーム向け）\n'+c.nm3u8dlRe:'')+(c.m3u8dlProtocol?'\n\n# cat-catch互換プロトコルURI\n'+c.m3u8dlProtocol:'')+(c.ytdlp?'\n\n# yt-dlp（MPEG-TS維持）\n'+c.ytdlp:'')+(c.streamlink?'\n\n# streamlink（ライブストリーム向け）\n'+c.streamlink:'');field('copy-status').textContent=c.note;}catch(e){field('copy-status').textContent=e.message;}});
field('copy').addEventListener('click',async()=>{if(!value('command'))return;try{await navigator.clipboard.writeText(value('command'));field('copy-status').textContent='コピーしました。シェルとURL内の秘密情報を確認してください。';}catch(e){field('command').select();field('copy-status').textContent='選択した文字列をCtrl+Cでコピーしてください。';}});


let manifestController=null,lastManifestRows=[],lastManifestSource=null;
// User edits invalidate the association between a master, its variants and audio.
// Never carry an old signed audio URL or command into a different selection.
field('url').addEventListener('input',()=>{if(manifestController)manifestController.abort();lastManifestRows=[];lastManifestSource=null;field('variantList').replaceChildren();field('audioUrl').value='';field('mime').value='';field('body').value='';field('command').value='';field('manifestStatus').textContent='URLを変更しました。必要に応じて目録を再取得してください。';});
for(const id of ['audioUrl','mime','body','referer','agent','filename','shell'])field(id).addEventListener('input',()=>{field('command').value='';});
field('cancelManifest').onclick=()=>{if(manifestController)manifestController.abort();lastManifestRows=[];lastManifestSource=null;};
field('loadManifest').onclick=async()=>{if(manifestController)return;const ctl=manifestController=new AbortController();field('loadManifest').disabled=true;field('cancelManifest').disabled=false;field('variantList').replaceChildren();lastManifestRows=[];lastManifestSource=null;field('manifestStatus').textContent='目録を取得中…（動画・鍵は取得しません）';try{const selected=value('url');const isDash=/\.mpd(?:[?#]|$)/i.test(selected)||/dash\+xml/i.test(value('mime'));const r=isDash?await RspMediaCatalog.loadDASH(selected,{signal:ctl.signal,useCookies:field('useCookies').checked===true}):await RspMediaCatalog.load(selected,{signal:ctl.signal,useCookies:field('useCookies').checked===true,inheritQuery:field('manifestQuery').checked===true});if(ctl.signal.aborted||value('url')!==selected)return;lastManifestRows=r.rows;lastManifestSource=selected;field('body').value=r.body;field('result').textContent=JSON.stringify(RspMediaInspect.safeReport({url:selected,body:r.body}),null,2);for(const row of r.rows){const line=document.createElement('div');line.appendChild(document.createTextNode(row.kind+' / '+row.label+(row.audioGroup?' / 音声group '+row.audioGroup:'')+' '));if(row.kind==='subtitles'){line.appendChild(document.createTextNode('字幕（録画コマンドへの組込みは未対応）'));field('variantList').appendChild(line);continue;}const b=document.createElement('button');b.textContent='このURLを選ぶ';b.onclick=()=>{if(!lastManifestSource||!([lastManifestSource,...lastManifestRows.filter(r=>r.kind==='variant').map(r=>r.url)].includes(value('url')))){field('manifestStatus').textContent='URLが変わりました。目録を再取得してください。';return;}if(row.kind==='audio'){const selectedVariant=lastManifestRows.find(r=>r.kind==='variant'&&r.url===value('url'));if(!selectedVariant||!selectedVariant.audioGroup||selectedVariant.audioGroup!==row.groupId){field('manifestStatus').textContent='先に映像を選び、その映像に対応する音声グループを選択してください。';return;}}field(row.kind==='audio'?'audioUrl':'url').value=row.url;if(row.kind==='variant'){field('mime').value='application/vnd.apple.mpegurl';const track=RspMediaCatalog.pairVariantAudio(lastManifestRows,row);field('audioUrl').value=track?track.url:'';}field('body').value='';field('command').value='';field('manifestStatus').textContent='候補URLを選択しました。必要なら目録を取得、または保存コマンドを生成してください。別音声URLを選ぶと保存コマンドで2入力を指定します。';};line.appendChild(b);field('variantList').appendChild(line);}field('manifestStatus').textContent=isDash?'DASH MPDを取得・構造診断しました。セグメント取得なし。':r.rows.length+'候補。目録のみ取得済み。動画保存は未実行。';}catch(e){const m=/^HTTP_(\d{3})$/.exec(String(e&&e.message||'')),st=m?Number(m[1]):0,diag=st&&typeof RspMediaInspect.diagnoseResponse==='function'?RspMediaInspect.diagnoseResponse({status:st}):null;const extra=/HTTP_40[13]/.test(e.message)?'。署名期限・Cookie・Referer・Authorizationなどページの取得条件を確認してください。Cookie送信ONだけでは同じ条件を再現できない場合があります。':(diag&&diag.notes&&diag.notes.length?'。'+diag.notes[0]:'');field('manifestStatus').textContent=ctl.signal.aborted?'目録取得を中止しました':'目録取得失敗: '+e.message+extra;}finally{if(ctl.signal.aborted)field('manifestStatus').textContent='目録取得を中止しました';manifestController=null;field('loadManifest').disabled=false;field('cancelManifest').disabled=true;}};
field('bestVariant').addEventListener('click',()=>{if(!lastManifestSource||!([lastManifestSource,...lastManifestRows.filter(r=>r.kind==='variant').map(r=>r.url)].includes(value('url')))){field('manifestStatus').textContent='URLが変わりました。目録を再取得してから画質を選択してください。';return;}const best=RspMediaCatalog.bestVariant(lastManifestRows);if(!best){field('manifestStatus').textContent='目録に画質Variantがありません。1080pの提供は確認できません。';return;}const audio=RspMediaCatalog.pairVariantAudio(lastManifestRows,best);field('url').value=best.url;field('mime').value='application/vnd.apple.mpegurl';field('audioUrl').value=audio?audio.url:'';field('body').value='';field('command').value='';field('manifestStatus').textContent='目録上の最高画質候補 '+best.resolution+(best.frameRate?' '+best.frameRate+'fps':'')+(audio?' / 別音声を対応付け':' / 別音声なし、または不明')+'。実取得できる画質の保証ではありません。';});
field('restoreMaster').addEventListener('click',()=>{if(!lastManifestSource||!lastManifestRows.some(r=>r.kind==='variant')){field('manifestStatus').textContent='マスター目録を先に取得してください。';return;}field('url').value=lastManifestSource;field('audioUrl').value='';field('mime').value='application/vnd.apple.mpegurl';field('body').value='';field('command').value='';field('manifestStatus').textContent='マスターURLに戻しました。録画管理の追加音声設定も確認してください。';});
if(typeof chrome!=='undefined'&&chrome.runtime&&location.hash){chrome.runtime.sendMessage({type:'media.candidate.get',id:decodeURIComponent(location.hash.slice(1))}).then(r=>{if(r&&r.ok){field('url').value=r.url;if(r.mediaType==='dash')field('mime').value='application/dash+xml';if(r.mediaType&&r.mediaType!=='hls')field('manifestStatus').textContent=r.mediaType.toUpperCase()+'候補です。DASHのMPD本文も取得・構造診断できます（セグメントは取得しません）。';const c=r.context||{};if(c.referer)field('referer').value=c.referer;crossSiteSourceURL=c.pageUrl||c.referer||'';if(c.userAgent)field('agent').value=c.userAgent;let page='取得元ページ情報なし';try{page=new URL(c.pageUrl||c.referer).origin;}catch(e){}field('pageContext').textContent='実通信URLを保持 / '+page+' / Referer '+(c.referer?'取得済み':'未取得')+' / Cookie '+(c.cookieObserved?'利用を観測':'未観測')+' / Authorization '+(c.authorizationObserved?'利用を観測（値は未収集）':'未観測')+'。取得条件を確認してから目録を取得してください。';}else field('manifestStatus').textContent='候補は失効しました。管理画面で再確認してください。';}).catch(()=>{});}
addEventListener('pagehide',()=>{if(manifestController)manifestController.abort();});

/* Cross-site diagnostics is isolated from existing recording/manifest transport. */
let crossSiteMonitor=null;
let crossSiteSourceURL='';
if(typeof RspCrossSite!=='undefined'&&field('crossSiteInspect')){
 crossSiteMonitor=RspCrossSite.createMonitor();
 field('crossSiteInspect').addEventListener('click',()=>{try{
  const url=value('url'),body=value('body');const p=RspCrossSite.siteProfile(crossSiteSourceURL||url);
  const source=crossSiteSourceURL?'observed-page-context':'candidate-url-only';
  const dash=body&&(/^<\?xml\b|^<(?:[A-Za-z_][\w.-]*:)?MPD(?:\s|>)/i.test(body.trimStart())||/\.mpd(?:[?#]|$)/i.test(url))?RspCrossSite.parseDASH(body):null;
  const parsed=body&&!dash?RspCrossSite.parseHLS(body,url):null;
  const report={site:p,observedSourceHint:source,media:parsed?RspCrossSite.publicReport(parsed):null,dash,continuity:parsed?crossSiteMonitor.observe(url,parsed):null,notice:'No media bytes downloaded; protected streams not decrypted; browser authentication not replayed'};
  field('crossSiteReport').textContent=JSON.stringify(report,null,2);
 }catch(e){field('crossSiteReport').textContent='解析失敗: '+e.message;} });
}

// Only extension-owned inspector messages reach the existing URL session gate.
let directBusy=false;
if(field('directRecord'))field('directRecord').addEventListener('click',async()=>{
 if(directBusy)return;
 try{
  if(typeof chrome==='undefined'||!chrome.runtime||!chrome.runtime.sendMessage)throw Error('拡張機能の診断画面で使用してください。');
  const url=value('url').trim(),decision=RspMediaInspect.transportDecision({url,mime:value('mime'),body:value('body')});
  if(decision.route!=='hls')throw Error('HLS候補を指定してください。形式が不明または矛盾する場合は目録を確認してください。');
  if(value('audioUrl').trim())throw Error('別音声URLの直接指定は未対応です。マスターURLを選び直し、録画管理で追加音声を有効にしてください。');
  directBusy=true;field('directStatus').textContent='録画開始を要求中…';
  const result=await chrome.runtime.sendMessage({type:'url.start',payload:{url,label:''}});
  if(!result||!result.ok)throw Error('開始できませんでした: '+String(result&&result.error||'no-reply'));
  field('directStatus').textContent='録画開始を受け付けました。保存完了は録画管理で確認してください。';
 }catch(e){field('directStatus').textContent=e.message;}finally{directBusy=false;}
});
if(field('directStop'))field('directStop').addEventListener('click',async()=>{
 if(directBusy)return;directBusy=true;try{const result=await chrome.runtime.sendMessage({type:'url.stop'});if(!result||!result.ok)throw Error('停止できませんでした: '+String(result&&result.error||'no-reply'));field('directStatus').textContent='停止を受け付けました。保存処理の完了を録画管理で確認してください。';}catch(e){field('directStatus').textContent=e.message;}finally{directBusy=false;}
});

if(field('directRefresh'))field('directRefresh').addEventListener('click',async()=>{
 try{const s=await chrome.runtime.sendMessage({type:'monitor.status'});if(!s||!s.ok)throw Error('状態を取得できませんでした。');
  const state=s.draining?'保存処理中':s.recording?(s.state==='STANDBY'?'配信の再開を待機中':'録画中'):'録画していません';
  field('directStatus').textContent=state+(s.recording||s.draining?(s.urlSession?'（URL録画）':'（RPLAY録画）'):'')+'。保存完了や各パートの詳細は録画管理で確認してください。';
 }catch(e){field('directStatus').textContent=e.message;}
});
