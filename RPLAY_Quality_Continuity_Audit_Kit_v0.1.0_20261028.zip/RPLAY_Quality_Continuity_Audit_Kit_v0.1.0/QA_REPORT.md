# QA Report 2026-10-28

- Baseline source available: v2.42.2 ZIP, CRC PASS, extracted in isolated working directory. No changes to original archive.
- Baseline targeted subset: 40/40 PASS (`node --test tests/test_v2410_media_catalog.cjs tests/test_v2420_request_context.cjs tests/test_cross_site_integration.cjs`).
- Independent kit automated tests: `npm test` on Node v22.16.0: 34/34 PASS, 0 FAIL (fresh run).
- Prior v2.49/v2.50 ZIPs: NOT_AVAILABLE; no source-level merge claimed.
- Browser integration in actual Firefox/Floorp/Chromium: NOT_RUN.
- RPLAY actual network recording, server/CDN behavior, 1080p availability and saved MP4: NOT_RUN.
- Windows user machine: NOT_RUN.
- Security: only synthetic example.invalid/example.test URLs used; no request transmitted.
- Release: NO_GO, integration candidate only.

- Source compatibility probe: PASS (`node scripts/compare_to_existing.cjs /mnt/data/rplay_work/rplay-stable-player-v2.42.2/src`); existing `media_catalog.manifest()` still produces expected separate audio and variant URLs, without changing original source.
