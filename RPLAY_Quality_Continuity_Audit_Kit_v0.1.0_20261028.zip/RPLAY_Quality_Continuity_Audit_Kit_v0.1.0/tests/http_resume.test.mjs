import {test} from 'node:test';import assert from 'node:assert/strict';
import {contentRange,verifyTransfer as v} from '../src/http_resume.mjs';
test('Content-Range validates bounds and requires integer values',()=>{
 assert.deepEqual(contentRange('bytes 200-299/500'),{start:200,end:299,total:500});
 for(const x of ['bytes 200-100/500','bytes 200-501/500','bytes -1-200/500','bytes 0-10/5','bytes 0-10/1e3','bytes 99999999999999999-999999999999999999/*'])assert.throws(()=>contentRange(x));
});
test('contiguous 206 append accepted',()=>assert.deepEqual(v({storedBytes:100,receivedBytes:50,rangeRequested:true,status:206,contentRangeHeader:'bytes 100-149/200'}),{action:'APPEND',newLength:150,remaining:50,reason:'CONTIGUOUS_206'}));
test('mismatched, truncated or overlapping 206 rejected',()=>{
 for(const [range,n] of [['bytes 101-150/200',50],['bytes 99-148/200',50],['bytes 100-149/200',49],['bytes 100-149/200',60]])
  assert.equal(v({storedBytes:100,receivedBytes:n,rangeRequested:true,status:206,contentRangeHeader:range}).action,'REJECT');
});
test('Range ignored 200 restarts; never append',()=>assert.deepEqual(v({storedBytes:100,receivedBytes:300,rangeRequested:true,status:200}).action,'RESTART_FROM_ZERO'));
test('with no request, only new 200 allowed',()=>{
 assert.equal(v({storedBytes:0,receivedBytes:300,rangeRequested:false,status:200}).action,'WRITE_NEW');
 assert.equal(v({storedBytes:10,receivedBytes:300,rangeRequested:false,status:200}).action,'REJECT');
});
test('ETag changed / If-Range mismatch forces safe restart',()=>{
 for(const opts of [{previousETag:'"a"',responseETag:'"b"'},{previousETag:'"a"',ifRange:'"b"'}])
 assert.equal(v({storedBytes:100,receivedBytes:10,rangeRequested:true,status:206,contentRangeHeader:'bytes 100-109/200',...opts}).action,'RESTART_FROM_ZERO');
});
test('weak If-Range validators are never accepted for resumed appends',()=>{assert.equal(v({storedBytes:100,receivedBytes:10,rangeRequested:true,status:206,contentRangeHeader:'bytes 100-109/200',previousETag:'W/"v"',ifRange:'W/"v"'}).action,'RESTART_FROM_ZERO');});
test('encoded range cannot be appended with uncertain byte semantics',()=>assert.equal(v({storedBytes:100,receivedBytes:10,rangeRequested:true,status:206,contentEncoding:'gzip',contentRangeHeader:'bytes 100-109/200'}).reason,'CONTENT_ENCODING_UNSAFE'));
test('416 only prompts hash when local byte count equals authoritative length',()=>{
 assert.equal(v({storedBytes:100,receivedBytes:0,rangeRequested:true,status:416,contentRangeHeader:'bytes */100'}).action,'VERIFY_LOCAL_HASH');
 assert.equal(v({storedBytes:80,receivedBytes:0,rangeRequested:true,status:416,contentRangeHeader:'bytes */100'}).action,'REJECT');
});
test('status errors, unsafe lengths do not mark save success',()=>{
 for(const s of [403,404,500,503])assert.equal(v({storedBytes:0,receivedBytes:0,rangeRequested:true,status:s}).action,'REJECT');
 assert.equal(v({storedBytes:-1,receivedBytes:20,rangeRequested:false,status:200}).action,'REJECT');
});
