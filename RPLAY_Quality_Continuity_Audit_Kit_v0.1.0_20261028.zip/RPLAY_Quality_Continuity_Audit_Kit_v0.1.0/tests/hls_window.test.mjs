import {test} from 'node:test';import assert from 'node:assert/strict';
import {snapshot,compareWindows} from '../src/hls_window.mjs';
const p=(first,count,extra='')=>`#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-MEDIA-SEQUENCE:${first}\n${extra}\n`+Array.from({length:count},(_,i)=>`#EXTINF:6,\nseg${i}.ts`).join('\n');
test('overlap and following windows have no definite gap',()=>{
 assert.deepEqual([snapshot(p(100,3)).first,snapshot(p(100,3)).lastExclusive],[100,103]);
 assert.equal(compareWindows(snapshot(p(100,3)),snapshot(p(102,3))).state,'NO_DEFINITE_WINDOW_GAP');
 assert.equal(compareWindows(snapshot(p(100,3)),snapshot(p(103,3))).lostSegments,0);
});
test('gap when next first exceeds last seen',()=>{
 assert.deepEqual(compareWindows(snapshot(p(100,3)),snapshot(p(105,3))),{state:'MANIFEST_SEQUENCE_GAP_POTENTIAL_LOSS',lostSegments:2});
});
test('playlist rewind is not silently treated as continuity',()=>assert.equal(compareWindows(snapshot(p(100,3)),snapshot(p(98,3))).state,'SEQUENCE_REWIND'));
test('LL-HLS delta skip is not counted as complete normal HLS',()=>assert.equal(compareWindows(snapshot(p(100,3)),snapshot(p(102,3,'#EXT-X-SKIP:SKIPPED-SEGMENTS=2'))).state,'UNSAFE_DELTA_PLAYLIST'));
test('part tags result in warning',()=>assert.equal(compareWindows(snapshot(p(100,3)),snapshot(p(103,3,'#EXT-X-PART:DURATION=0.2,URI="p.m4s"'))).warning,'PARTS_NOT_TRACKED'));
test('discontinuity sequence rollback is a distinct error',()=>assert.equal(compareWindows(snapshot(p(100,3,'#EXT-X-DISCONTINUITY-SEQUENCE:4')),snapshot(p(103,3,'#EXT-X-DISCONTINUITY-SEQUENCE:3'))).state,'DISCONTINUITY_REWIND'));
test('master lists are rejected',()=>assert.throws(()=>snapshot('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=2000\nhi.m3u8')));
test('invalid sequence and oversized inputs rejected',()=>{assert.throws(()=>snapshot(p(100,1).replace(':100',':bad')));assert.throws(()=>snapshot('#EXTM3U\n'+'a'.repeat(2097152)));});
