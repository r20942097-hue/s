import {test} from 'node:test';
import assert from 'node:assert/strict';
import {checkURL,attrs,parseMaster,auditMaster,compareAudits} from '../src/quality_audit.mjs';
const base='https://cdn.example.test/private/master.m3u8?sig=TOP_SECRET';
const master=`#EXTM3U
#EXT-X-VERSION:6
#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="main",NAME="日本語,主音声",LANGUAGE="ja",DEFAULT=YES,AUTOSELECT=YES,URI="aud/jp.m3u8?sig=own"
#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="main",NAME="English",LANGUAGE="en",DEFAULT=NO,URI="aud/en.m3u8"
#EXT-X-STREAM-INF:BANDWIDTH=2200000,RESOLUTION=1280x720,FRAME-RATE=59.940,CODECS="avc1.4d401f,mp4a.40.2",AUDIO="main"
720p.m3u8?key=child
#EXT-X-STREAM-INF:BANDWIDTH=4500000,RESOLUTION=1920x1080,FRAME-RATE=29.970,CODECS="avc1.640028,mp4a.40.2",AUDIO="main"
1080p.m3u8?key=distinct
#EXT-X-STREAM-INF:BANDWIDTH=8000000,RESOLUTION=1920x1080,FRAME-RATE=59.940,CODECS="avc1.64002a,mp4a.40.2",AUDIO="main"
1080p60.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=96000,CODECS="mp4a.40.2"
audio_only.m3u8
`;
test('attrs preserves commas in quoted values',()=>assert.equal(attrs('BANDWIDTH=3,NAME="日本語,主音声"').NAME,'日本語,主音声'));
test('attrs refuses malformed and duplicate keys',()=>{for(const x of ['NAME="unterminated','A=1,A=2','??=3','A="a"B=2'])assert.throws(()=>attrs(x));});
test('HTTP-only URL policy disallows credentials, whitespace, scripting protocols',()=>{for(const x of ['data:x','javascript:foo','https://u:p@host/a','https://x/a\r\nInjected:bad','file:///tmp/a'])assert.throws(()=>checkURL(x));});
test('signed child URLs preserved and parent signature not inherited by default',()=>{
 const x=parseMaster(master,base);
 assert.equal(x.variants[0].url,'https://cdn.example.test/private/720p.m3u8?key=child');
 assert.equal(x.variants[2].url,'https://cdn.example.test/private/1080p60.m3u8');
 assert.equal(x.audio[0].url,'https://cdn.example.test/private/aud/jp.m3u8?sig=own');
});
test('video ranking chooses 1080p60 over 1080p30 and 720p60, excludes audio only',()=>{
 const r=auditMaster(master,base);assert.equal(r.totalVariants,4);assert.equal(r.videoVariants,3);assert.equal(r.quality1080,'ADVERTISED_UNVERIFIED');assert.deepEqual([r.selection.height,r.selection.fps,r.selection.index],[1080,59.94,2]);
 assert.equal(r.selection.matchedAudioCount,2);
});
test('reports never expose signed URL path or query',()=>{
 const r=auditMaster(master,base),body=JSON.stringify(r);
 assert.ok(!body.includes('TOP_SECRET')&&!body.includes('key=')&&!body.includes('1080p60.m3u8')&&!body.includes('private'));
 assert.equal(r.verifiedDownload,false);assert.equal(r.networkRequests,0);
});
test('1080 advertised is not verified availability',()=>{const r=auditMaster(master,base);assert.equal(r.selection.claimedAvailable,false);});
test('2160p does not imply an exact 1080p rendition',()=>{const m='#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=10000000,RESOLUTION=3840x2160,CODECS="avc1.640028"\n4k.m3u8';const r=auditMaster(m,base);assert.equal(r.atLeast1080Advertised,true);assert.equal(r.quality1080,'NOT_ADVERTISED_OR_UNKNOWN');});
test('unsafe audio attribute text cannot leak into sanitized report',()=>{const t=master.replace('日本語,主音声','PRIVATE_CREDENTIAL_VALUE');assert.equal(JSON.stringify(auditMaster(t,base)).includes('PRIVATE_CREDENTIAL_VALUE'),false);});
test('unknown resolution never asserts 1080',()=>{
 const r=auditMaster('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=4000,CODECS="avc1.640028"\nx.m3u8',base);
 assert.equal(r.quality1080,'NOT_ADVERTISED_OR_UNKNOWN');assert.equal(r.videoVariants,1);assert.ok(r.warnings.includes('UNKNOWN_VIDEO_RESOLUTION'));
});
test('no known video codec or resolution does not mistake audio-only for highest video',()=>{
 const r=auditMaster('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=97000,CODECS="mp4a.40.2"\na.m3u8',base);
 assert.equal(r.videoVariants,0);assert.equal(r.selection,null);
});
test('bad missing group flagged but not falsely remapped',()=>{
 const s='#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=10,RESOLUTION=1920x1080,AUDIO="missing"\nv.m3u8';
 assert.deepEqual(auditMaster(s,base).warnings,['UNRESOLVED_AUDIO_GROUP']);
});
test('missing variant URI, invalid resolution, zero bandwidth format rejected',()=>{
 for(const s of ['#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=3', '#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=3,RESOLUTION=xx\na.m3u8','#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=bad\na.m3u8','#EXTM3U\n#EXT-X-STREAM-INF:RESOLUTION=1920x1080\na.m3u8'])assert.throws(()=>parseMaster(s,base));
});
test('large master and oversized list rejected',()=>{
 assert.throws(()=>parseMaster('#EXTM3U\n'+('a'.repeat(2*1024*1024)),base),/LIMIT/);
 const s='#EXTM3U\n'+Array.from({length:129},(_,i)=>`#EXT-X-STREAM-INF:BANDWIDTH=10,RESOLUTION=640x360\nv${i}.m3u8`).join('\n');
 assert.throws(()=>parseMaster(s,base),/TOO_MANY/);
});
test('snapshots compare 1080 advertised fluctuation without treating as delivery proof',()=>{
 const a=auditMaster(master,base);const b=auditMaster(master.replaceAll('1920x1080','1280x720'),base),x=compareAudits(a,b);
 assert.equal(x.before1080,'ADVERTISED_UNVERIFIED');assert.equal(x.after1080,'NOT_ADVERTISED_OR_UNKNOWN');assert.equal(x.masterRepresentationChanged,true);
});
test('cannot inject unusual URL through URI line',()=>{
 assert.throws(()=>parseMaster('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=3,RESOLUTION=1x1\njavascript:alert(1)',base));
});
