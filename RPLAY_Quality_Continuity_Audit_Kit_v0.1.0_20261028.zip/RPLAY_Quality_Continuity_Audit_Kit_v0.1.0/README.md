# RPLAY Quality & Continuity Audit Kit 0.1.0

**2026-10-28 / independent development candidate, not RPLAY v2.51.**

Latest RPLAY v2.49.0/v2.50.0 attachment bytes were not retrievable in this execution environment. The only source used for read-only compatibility testing was Library original `RPLAY_Stable_Player_v2.42.2_DASH_CROSSSITE_CANDIDATE(1).zip` SHA-256 `47e484e6604464c671f17149f83f9fdd318356149d9646f398acd6691493050b`.

This ZIP contains only new, independently implemented audit source and synthetic tests. It **does not** replace or upgrade RPLAY itself or contain the v2.50 code. The original extension, Windows settings, real saves and user profiles were not modified.

## Modules

- `src/quality_audit.mjs`: parse a supplied local HLS multivariant playlist and derive a deterministic video quality rank and separate audio correspondence. Distinguishes *advertised* 1080p from verified delivery and 2160p from an exact 1080p rendition. Signature-bearing URLs are held in `parseMaster` only for the in-memory caller; do not persist or log `parseMaster` output. Only `auditMaster` returns a redacted report (numeric/boolean/enumeration fields). No network calls. No automatic fallback to a 720p variant without user policy.
- `src/http_resume.mjs`: reject invalid/misaligned/truncated 206 `Content-Range`, reject non-identity Content-Encoding and mismatched validators, never append a 200 response to existing bytes, hold `416` completion for separate local hash verification. Evaluates response metadata; does not perform saving, networking or final file integrity checks.
- `src/hls_window.mjs`: compare two full HLS media-playlist snapshots and flag sequence-window gaps, delta skip / partial-segment caveats and discontinuity rewind. **A playlist gap is not proof of a damaged recording**; confirm against actual segment ledger. It does not fetch, decrypt or record content.

## How to run

```bash
npm test
# Optional read-only integration probe against independently extracted known RPLAY src:
node scripts/compare_to_existing.cjs /path/to/rplay-stable-player-v2.42.2/src
```

Node.js >=20, no third-party packages; never calls a remote site. Useful as a preflight regression pack for adapting these modules to **v2.50 only after that exact source archive is available and diffed**.

## Integration sequence (not performed)

1. Compute SHA-256 and inspect v2.50 ZIP entries and `src/media_catalog.js`, HTTP recorder and backup code. Compare v2.42.2 baseline; treat v2.50 as authoritative, do not roll back newer capture/recovery/MP4 logic.
2. Add a metadata-only quality audit path to the existing media inspector. Avoid exposing signed query strings in list/report/log/backup. Keep raw URLs only in authorized command or fetch context. Verify AUDIO group matching before mapping separate audio to an output.
3. Add strict response verification to the resume writer *before* appending any bytes. Preserve original file on failure. Verify bytes written, close semantics, output hashes and full decode separately; never call a diagnostic PASS a saved recording.
4. Add HLS manifest continuity checks to the existing session ledger, avoiding duplicate independent ledgers. Replay reconnect, master changes and discontinuity in synthetic fixtures.
5. Run full v2.50 build, Firefox/Floorp and Chromium integration, long duration playback/recording, actual authorized stream test and Windows disk/sleep/resume as separate gates. Do not mark release GO from this kit.

## Explicit boundaries

No license bypass, DRM circumvention, URL guessing, unauthenticated access promises, headless user session cloning, or auto-harvesting credentials. Signed URLs may expire; metadata cannot prove a 1080p rendition was playable or that FFmpeg can mux a media stream. Do not send raw signed URLs to external telemetry.
