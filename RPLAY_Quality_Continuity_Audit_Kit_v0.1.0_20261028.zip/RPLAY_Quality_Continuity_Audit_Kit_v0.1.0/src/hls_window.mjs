/* Sliding-window continuity preflight. No media/network operations. */
export function snapshot(text) {
 if (typeof text!=='string'||new TextEncoder().encode(text).length>2*1024*1024) throw Error('PLAYLIST_LIMIT');
 const lines=text.replace(/^\uFEFF/,'').split(/\r?\n/).map(x=>x.trim());
 if (lines[0]!=='#EXTM3U') throw Error('INVALID_HLS');
 let first=0,discontinuity=0,count=0,hasSkip=false,hasParts=false,end=false,hasMaster=false;
 for(const l of lines.slice(1)) {
   if(l.startsWith('#EXT-X-MEDIA-SEQUENCE:')){const n=l.slice(22);if(!/^\d+$/.test(n)||!Number.isSafeInteger(Number(n)))throw Error('BAD_SEQUENCE');first=Number(n);}
   if(l.startsWith('#EXT-X-DISCONTINUITY-SEQUENCE:')){const n=l.slice(30);if(!/^\d+$/.test(n)||!Number.isSafeInteger(Number(n)))throw Error('BAD_DISCONTINUITY');discontinuity=Number(n);}
   if(l.startsWith('#EXTINF:'))count++;
   if(l.startsWith('#EXT-X-SKIP:'))hasSkip=true;
   if(l.startsWith('#EXT-X-PART:'))hasParts=true;
   if(l==='#EXT-X-ENDLIST')end=true;
   if(l.startsWith('#EXT-X-STREAM-INF:'))hasMaster=true;
 }
 if(hasMaster) throw Error('NOT_MEDIA_PLAYLIST');
 if(!Number.isSafeInteger(first+count))throw Error('BAD_SEQUENCE');
 return {first,lastExclusive:first+count,segments:count,discontinuity,hasSkip,hasParts,end};
}
export function compareWindows(before,after) {
 if(!before||!after)throw Error('MISSING_WINDOW');
 if(before.hasSkip||after.hasSkip)return {state:'UNSAFE_DELTA_PLAYLIST',lostSegments:null};
 if(after.first<before.first)return {state:'SEQUENCE_REWIND',lostSegments:null};
 if(after.discontinuity<before.discontinuity)return {state:'DISCONTINUITY_REWIND',lostSegments:null};
 const missed=Math.max(0,after.first-before.lastExclusive);
 if(missed)return {state:'MANIFEST_SEQUENCE_GAP_POTENTIAL_LOSS',lostSegments:missed};
 return {state:'NO_DEFINITE_WINDOW_GAP',lostSegments:0,newSegments:Math.max(0,after.lastExclusive-Math.max(before.lastExclusive,after.first)),
   discontinuitySequenceAdvanced:after.discontinuity>before.discontinuity,warning:after.hasParts?'PARTS_NOT_TRACKED':null};
}
