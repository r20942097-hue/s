/* Strict offline response-append guard. Never append an unverified range. */
function integer(v) {return Number.isSafeInteger(v) && v >= 0;}
export function contentRange(raw) {
  if (typeof raw!=='string') throw Error('BAD_CONTENT_RANGE');
  const m = /^bytes (\d+)-(\d+)\/(\d+|\*)$/.exec(raw.trim());
  if (!m) throw Error('BAD_CONTENT_RANGE');
  const start=Number(m[1]), end=Number(m[2]), total=m[3]==='*'?null:Number(m[3]);
  if (![start,end].every(integer) || end<start || (total!==null && (!integer(total)||end>=total))) throw Error('BAD_CONTENT_RANGE');
  return {start,end,total};
}
export function verifyTransfer({storedBytes,rangeRequested,status,contentRangeHeader='',receivedBytes,
  contentEncoding='identity',previousETag='',responseETag='',ifRange=''}={}) {
  if (![storedBytes,receivedBytes].every(integer)) return {action:'REJECT',reason:'INVALID_LENGTH'};
  if (!['','identity'].includes(String(contentEncoding).toLowerCase())) return {action:'REJECT',reason:'CONTENT_ENCODING_UNSAFE'};
  if (previousETag && responseETag && previousETag!==responseETag) return {action:'RESTART_FROM_ZERO',reason:'ENTITY_CHANGED'};
  if (ifRange && (/^W\//.test(ifRange) || (previousETag && ifRange!==previousETag))) return {action:'RESTART_FROM_ZERO',reason:'IF_RANGE_MISMATCH'};
  if (rangeRequested) {
    if (status===200) return {action:'RESTART_FROM_ZERO',reason:'SERVER_IGNORED_RANGE'};
    if (status===416) {
      const m=/^bytes \*\/(\d+)$/.exec(contentRangeHeader);
      const total=m?Number(m[1]):NaN;
      return integer(total)&&total===storedBytes?{action:'VERIFY_LOCAL_HASH',reason:'SERVER_RANGE_EXHAUSTED'}:{action:'REJECT',reason:'UNSATISFIABLE_RANGE'};
    }
    if (status!==206) return {action:'REJECT',reason:'UNEXPECTED_HTTP_STATUS'};
    let r;try{r=contentRange(contentRangeHeader);}catch{return {action:'REJECT',reason:'BAD_CONTENT_RANGE'};}
    if (r.start!==storedBytes || r.end-r.start+1!==receivedBytes || (r.total!==null && storedBytes+receivedBytes>r.total))
      return {action:'REJECT',reason:'RANGE_NOT_CONTIGUOUS_OR_TRUNCATED'};
    return {action:'APPEND',newLength:storedBytes+receivedBytes,remaining:r.total===null?null:r.total-storedBytes-receivedBytes,reason:'CONTIGUOUS_206'};
  }
  if (storedBytes!==0) return {action:'REJECT',reason:'APPEND_WITHOUT_RANGE'};
  if (status!==200) return {action:'REJECT',reason:'UNEXPECTED_HTTP_STATUS'};
  return {action:'WRITE_NEW',newLength:receivedBytes,reason:'FULL_200'};
}
