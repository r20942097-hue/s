/* RPLAY quality audit: deterministic, offline-only and metadata-only.
   Raw URLs remain in caller-owned memory; reports never serialize raw paths/queries. */
const LIMIT = 2 * 1024 * 1024;
const MAX_VARIANTS = 128;
export function checkURL(value, base) {
  if (typeof value !== 'string' || !value || value.length > 16384 || /[\x00-\x20\x7f]/.test(value)) throw Error('INVALID_URL');
  let u; try {u = new URL(value, base);} catch {throw Error('INVALID_URL');}
  if (!['http:', 'https:'].includes(u.protocol) || u.username || u.password) throw Error('INVALID_URL');
  return u.href;
}
export function attrs(raw) {
  const out = Object.create(null);
  let i = 0;
  while (i < raw.length) {
    while (raw[i] === ',' || raw[i] === ' ') i++;
    if (i >= raw.length) break;
    const k = /^[A-Za-z0-9-]+/.exec(raw.slice(i));
    if (!k || raw[i + k[0].length] !== '=') throw Error('INVALID_ATTRIBUTES');
    const key = k[0]; i += key.length + 1;
    let value;
    if (raw[i] === '"') {
      const end = raw.indexOf('"', i + 1);
      if (end === -1) throw Error('INVALID_ATTRIBUTES');
      value = raw.slice(i + 1, end); i = end + 1;
    } else {
      const end = raw.indexOf(',', i);
      value = raw.slice(i, end < 0 ? raw.length : end).trim(); i = end < 0 ? raw.length : end;
    }
    if (!value || Object.hasOwn(out, key) || (i < raw.length && raw[i] !== ',')) throw Error('INVALID_ATTRIBUTES');
    out[key] = value;
  }
  return out;
}
function uint(s, fallback = 0) { if (s === undefined) return fallback; if (!/^[0-9]+$/.test(s)) throw Error('INVALID_NUMBER'); const n = Number(s); if (!Number.isSafeInteger(n)) throw Error('INVALID_NUMBER'); return n; }
function resolution(s) {
  if (s === undefined) return null;
  const m = /^(\d{1,5})x(\d{1,5})$/.exec(s);
  if (!m || !Number(m[1]) || !Number(m[2])) throw Error('INVALID_RESOLUTION');
  return {width:Number(m[1]), height:Number(m[2])};
}
function fps(s) { if (s === undefined) return null; if (!/^\d{1,3}(?:\.\d{1,3})?$/.test(s) || !(Number(s)>0)) throw Error('INVALID_FPS'); return Number(s); }
function hasVideo(codecString='') { return /(?:^|,)(?:avc1|avc3|hvc1|hev1|av01|vp09|vp9|dvh1|dvhe|mp4v)(?:[.,]|$)/i.test(codecString); }
export function parseMaster(text, base) {
  checkURL(base);
  if (typeof text !== 'string' || new TextEncoder().encode(text).length > LIMIT) throw Error('MANIFEST_LIMIT');
  const lines = text.replace(/^\uFEFF/,'').split(/\r?\n/).map(x=>x.trim());
  if (lines[0] !== '#EXTM3U') throw Error('INVALID_HLS');
  const variants = [], audio = [], warnings = [];
  let pending = null;
  for (const line of lines.slice(1)) {
    if (!line) continue;
    if (line.startsWith('#EXT-X-STREAM-INF:')) {
      if (pending) throw Error('VARIANT_MISSING_URI');
      pending = attrs(line.slice('#EXT-X-STREAM-INF:'.length));
      if (!('BANDWIDTH' in pending)) throw Error('MISSING_BANDWIDTH');
    } else if (line.startsWith('#EXT-X-MEDIA:')) {
      const a = attrs(line.slice('#EXT-X-MEDIA:'.length));
      if (a.TYPE === 'AUDIO' && a['GROUP-ID']) {
        audio.push({group:a['GROUP-ID'], language:a.LANGUAGE||null, name:a.NAME||null,
          isDefault:a.DEFAULT==='YES', muxed:!a.URI,
          // Only internal use; not exposed in summaries.
          url:a.URI?checkURL(a.URI,base):null});
      }
    } else if (!line.startsWith('#') && pending) {
      const r=resolution(pending.RESOLUTION), b=uint(pending.BANDWIDTH);
      variants.push({url:checkURL(line,base), bandwidth:b, averageBandwidth:uint(pending['AVERAGE-BANDWIDTH'],0)||null,
        width:r?.width??null,height:r?.height??null,fps:fps(pending['FRAME-RATE']),codecs:pending.CODECS||null,
        audioGroup:pending.AUDIO||null,video:!!r||hasVideo(pending.CODECS||''),knownResolution:!!r});
      pending=null;
      if (variants.length > MAX_VARIANTS) throw Error('TOO_MANY_VARIANTS');
    } else if (!line.startsWith('#') && !pending) {
      warnings.push('UNEXPECTED_URI_IGNORED');
    }
  }
  if (pending) throw Error('VARIANT_MISSING_URI');
  if (!variants.length) warnings.push('NO_MASTER_VARIANTS');
  for (const v of variants) if (v.audioGroup && !audio.some(a=>a.group===v.audioGroup)) warnings.push('UNRESOLVED_AUDIO_GROUP');
  if (variants.some(v=>v.video && !v.knownResolution)) warnings.push('UNKNOWN_VIDEO_RESOLUTION');
  // No implicit query inheritance: a child with its own signature stays byte-for-byte URL-resolved.
  return {variants,audio,warnings:[...new Set(warnings)],fetched:false,playbackVerified:false};
}
export function auditMaster(text,base) {
  const m=parseMaster(text,base);
  const ranked = m.variants.filter(v=>v.video).sort((a,b)=>(b.width??0)*(b.height??0)-(a.width??0)*(a.height??0) || (b.fps??0)-(a.fps??0) || b.bandwidth-a.bandwidth);
  const best=ranked[0]??null;
  const availability=ranked.some(v=>v.height===1080 && v.knownResolution)?'ADVERTISED_UNVERIFIED':'NOT_ADVERTISED_OR_UNKNOWN';
  return {schema:1,classification:'hls_master_metadata',totalVariants:m.variants.length,videoVariants:ranked.length,
    audioRenditions:m.audio.length,quality1080:availability,atLeast1080Advertised:ranked.some(v=>(v.height??0)>=1080),
    selection:best?{width:best.width,height:best.height,fps:best.fps,bandwidth:best.bandwidth,
      hasAudioGroup:!!best.audioGroup,matchedAudioCount:m.audio.filter(a=>a.group===best.audioGroup).length,
      // Index reflects original master; applications must explicitly resolve selection from parseMaster, not a report URL.
      index:m.variants.indexOf(best),claimedAvailable:false}:null,
    warnings:m.warnings,networkRequests:0,redirectsFollowed:false,keysFetched:false,verifiedDownload:false};
}
export function compareAudits(previous,current) {
  if (previous.schema!==1 || current.schema!==1) throw Error('INVALID_REPORT');
  return {before1080:previous.quality1080,after1080:current.quality1080,
    masterRepresentationChanged:JSON.stringify(previous.selection)!==JSON.stringify(current.selection),
    interpretation:'Only snapshots of advertised variants; no CDN fetch or playback was performed.'};
}
