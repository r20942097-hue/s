// Optional: read-only compatibility smoke with any extracted RPLAY source root.
// Usage: node scripts/compare_to_existing.cjs /absolute/path/to/RPLAY/src
'use strict';
const path=require('node:path'),assert=require('node:assert/strict');
const root=process.argv[2];if(!root){console.error('Usage: node scripts/compare_to_existing.cjs /path/to/RPLAY/src');process.exit(2);}
const legacy=require(path.resolve(root,'media_catalog.js'));
const hls=require(path.resolve(root,'hls_transport.js'));
const manifest='#EXTM3U\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="j",NAME="main",URI="ja.m3u8?own=sig"\n#EXT-X-STREAM-INF:BANDWIDTH=5000000,RESOLUTION=1920x1080,AUDIO="j"\nvideo.m3u8?auth=x\n';
const rows=legacy.manifest(manifest,'https://example.invalid/master.m3u8?auth=parent',hls);
assert.equal(rows.length,2);assert.equal(rows.find(x=>x.kind==='video').url,'https://example.invalid/video.m3u8?auth=x');
assert.equal(rows.find(x=>x.kind==='audio').url,'https://example.invalid/ja.m3u8?own=sig');
console.log('PASS: existing master parser contract preserved; quality audit is opt-in and standalone.');
