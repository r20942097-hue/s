# RPLAY v2.48.0 UNIFIED CANDIDATE

`v2.44.0` をベースに、`EXISTING_TOOL_RESEARCH_AND_PART_COMMIT_v2.42.4.md` の残課題（Priority #2 / Priority #4）および Python CLI の録画途切れ防止パリティを実装・検証した v2.48.0 統合候補版です。

## v2.48.0 の主な改善・統合内容

1. **クラッシュ/再読み込み復帰時の確定パート・チェックポイント証拠引継ぎ (`src/part_io.js` / `src/player.user.js`, Priority #2)**:
   - `Recorder.persistSession()` (v2スキーマ) および `Recorder.closePart()` / `AudioRecorder.closePart()` にて、確定保存された映像・音声パートの台帳（`file`, `bytes`, `segments`, `sha256`, `ledgerStatus`, `partIntegrity.checkpoint` 等）をURL・秘密情報ゼロの `recSanitizePersistedParts()` でサニタイズして永続化します（最大48KiB境界保護付き）。
   - タブの再読み込みやクラッシュ後に `Recorder.resumeFromCrash(s)` で録画を再開した際、中断前に保存完了していたパート群が `partsLog` / `_joinParts` に引き継がれ、最終的な `_info.json` および `_join_*.json` から前半パートが欠落しないようになりました。
2. **保存済みローカルファイルの単体デコード品質監査 (`rplay_dl.py --audit-files`, Priority #4)**:
   - ブラウザ録画後や別環境で保存した `.ts` / `.mp4` ファイル群に対し、配信URLやクリエイターID不要で `python3 rplay_dl.py --audit-files <part1.ts> [audio-p1.ts ...]` を実行できるようになりました。
   - `ffprobe` によるパケット単位のPTS/DTS単調性監査、`ffmpeg` による全編デコード検査（`qaudit_part`）、および映像・分離音声間の実デコード時間相関（`qaudit_av_correlation`）を実行し、`provenance: "decoded"` のJSONレポートと終了コード（全合格=`0` / 異常検出=`2`）を返します。
3. **分離音声パートの2トラック無劣化MP4結合 (`rplay_join.py --mux-audio`)**:
   - `audioRendition.parts` を含む結合ジョブに対し、既定では従来の fail-closed（`JOIN_SEPARATE_AUDIO_REQUIRES_MUX`）を厳守しつつ、`--mux-audio`（または `join_parts(..., mux_audio=True)`）を明示指定した場合に映像concatと音声concatを `-map 0:v:0 -map 1:a:0 -c copy` で無劣化2トラックMP4へ結合し、継続時間検証と全編デコード検証を行います。
4. **Python CLI (`rplay_dl.py`) の録画途切れ防止パリティ (`src/hls_transport.py` / `src/cli.py`)**:
   - ブラウザ側 `v2.44.0` で導入した①アクティブ録画中の一時的不完全プレイリスト応答（`REC_TRANSIENT_PARSE_ERRORS`）最大2回猶予、②音声トラックの一時404単発猶予、③セグメント取得時の転送寸断（`HLS_BODY_LENGTH` / `HLS_RANGE_LENGTH` / `HLS_EMPTY_BODY`）に対するFIFO先頭保持リトライを Python CLI にも完全鏡像実装し、`_info.json` に `playlistParseGraceEvidence` および `segmentTransferRetryEvidence` を出力します。

## 検証コマンド

```bash
python3 scripts/build.py
python3 scripts/validate.py --output-dir /tmp/v245_ev
python3 tests/check_request_context_http.py
python3 tests/check_cdn404_decode.py
node tests/check_recording_during_scan.cjs
```
