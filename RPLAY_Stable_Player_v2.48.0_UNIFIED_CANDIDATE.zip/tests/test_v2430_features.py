"""v2.48.0 Python feature & parity tests:
1. MPEG-2 PSI CRC-32 (mpeg2_crc32 / hls_audit_psi) validation and tampering detection.
2. WebVTT validation (hls_validate_webvtt) and boundary-cue deduplication (hls_merge_webvtt_segments).
3. Local static server (scripts/serve_mp4.py) allowlist for media_inspect dependencies (hls_transport.js, media_catalog.js, cross_site_compat.js).
"""
import importlib.util
import pathlib
import subprocess
import tempfile
import unittest

R = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('cli_v2430', R / 'rplay_dl.py')
cli = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cli)


class V2430PythonParityTests(unittest.TestCase):
    def test_psi_audit_and_crc_tampering_detection(self):
        with tempfile.TemporaryDirectory() as tmp:
            ts_path = pathlib.Path(tmp) / 'av.ts'
            subprocess.run([
                'ffmpeg', '-nostdin', '-v', 'error',
                '-f', 'lavfi', '-i', 'testsrc2=s=160x90:r=25:d=1',
                '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=48000:duration=1',
                '-c:v', 'libx264', '-preset', 'ultrafast', '-c:a', 'aac',
                '-f', 'mpegts', str(ts_path)
            ], check=True, timeout=20)
            raw = ts_path.read_bytes()
            plan = cli.hls_audit_psi(raw)
            self.assertTrue(plan['audio'])
            corrupted = bytearray(raw)
            for at in range(0, len(corrupted), 188):
                pid = ((corrupted[at + 1] & 31) << 8) | corrupted[at + 2]
                if pid == 4096 and (corrupted[at + 1] & 0x40):
                    p = at + 4
                    if corrupted[at + 3] & 0x20:
                        p += 1 + corrupted[p]
                    sec = p + 1 + corrupted[p]
                    corrupted[sec + 5] ^= 0x02
                    break
            with self.assertRaisesRegex(ValueError, 'TS_PSI_CRC'):
                cli.hls_audit_psi(bytes(corrupted))

    def test_webvtt_validation_and_deduplicating_merge(self):
        vtt1 = "WEBVTT\nX-TIMESTAMP-MAP=MPEGTS:90000,LOCAL:00:00:00.000\n\n00:00:00.000 --> 00:00:02.000\nLine 1\n\n00:00:02.000 --> 00:00:04.000\nShared Line\n"
        vtt2 = "WEBVTT\n\n00:00:02.000 --> 00:00:04.000\nShared Line\n\n00:00:04.000 --> 00:00:06.000\nLine 3\n"
        merged = cli.hls_merge_webvtt_segments([vtt1, vtt2])
        self.assertEqual(merged['cuesMerged'], 3)
        self.assertEqual(merged['duplicatesRemoved'], 1)
        self.assertEqual(merged['timestampMap'], 'MPEGTS:90000,LOCAL:00:00:00.000')
        self.assertIn('Line 1', merged['text'])
        self.assertIn('Line 3', merged['text'])
        with self.assertRaisesRegex(ValueError, 'WEBVTT_HEADER'):
            cli.hls_validate_webvtt("NOT_WEBVTT\n00:00:00.000 --> 00:00:01.000\nBad\n")


if __name__ == '__main__':
    unittest.main()
