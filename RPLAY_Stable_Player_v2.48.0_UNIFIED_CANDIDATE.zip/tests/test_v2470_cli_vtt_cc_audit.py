#!/usr/bin/env python3
"""v2.48.0 tests: CLI --merge-vtt WebVTT subtitle segment merger and --audit-files MPEG-TS CC audit."""
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RPLAY_DL = ROOT / "rplay_dl.py"


def make_ts_packet(pid: int, cc: int, payload_byte: int = 0xFF) -> bytes:
    b0 = 0x47
    b1 = (pid >> 8) & 0x1F
    b2 = pid & 0xFF
    b3 = 0x10 | (cc & 0x0F)  # payload only
    return bytes([b0, b1, b2, b3]) + bytes([payload_byte]) * 184


class TestV2470CliVttAndCcAudit(unittest.TestCase):
    def test_merge_vtt_cli_success_and_overwrite_refusal(self):
        with tempfile.TemporaryDirectory() as td:
            td_path = Path(td)
            s1 = td_path / "seg1.vtt"
            s2 = td_path / "seg2.vtt"
            out_vtt = td_path / "merged.vtt"

            s1.write_text(
                "WEBVTT\n"
                "X-TIMESTAMP-MAP=MPEGTS:900000,LOCAL:00:00:00.000\n\n"
                "00:00:01.000 --> 00:00:03.000\n"
                "Hello world\n\n"
                "00:00:03.000 --> 00:00:05.000\n"
                "Boundary cue\n",
                encoding="utf-8",
            )
            s2.write_text(
                "WEBVTT\n"
                "X-TIMESTAMP-MAP=MPEGTS:900000,LOCAL:00:00:00.000\n\n"
                "00:00:03.000 --> 00:00:05.000\n"
                "Boundary cue\n\n"
                "00:00:05.000 --> 00:00:07.000\n"
                "Second segment cue\n",
                encoding="utf-8",
            )

            proc = subprocess.run(
                [sys.executable, str(RPLAY_DL), "--merge-vtt", str(s1), str(s2), "--vtt-out", str(out_vtt)],
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(proc.returncode, 0, msg=proc.stderr + proc.stdout)
            data = json.loads(proc.stdout)
            self.assertTrue(data["ok"])
            self.assertEqual(data["schema"], "rplay-vtt-merge/v1")
            self.assertEqual(data["segmentsMerged"], 2)
            self.assertEqual(data["cuesMerged"], 3)
            self.assertEqual(data["duplicatesDropped"], 1)
            self.assertEqual(data["outputFile"], "merged.vtt")
            self.assertTrue(out_vtt.is_file())
            merged_content = out_vtt.read_text(encoding="utf-8")
            self.assertEqual(merged_content.count("Boundary cue"), 1)
            self.assertIn("Second segment cue", merged_content)

            # Second run with same --vtt-out must fail closed (no overwrite)
            proc2 = subprocess.run(
                [sys.executable, str(RPLAY_DL), "--merge-vtt", str(s1), "--vtt-out", str(out_vtt)],
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(proc2.returncode, 2)
            data2 = json.loads(proc2.stdout)
            self.assertFalse(data2["ok"])
            self.assertEqual(data2["reason"], "WEBVTT_OUTPUT_EXISTS")

    def test_audit_files_includes_continuity_counter_audit_for_ts(self):
        with tempfile.TemporaryDirectory() as td:
            ts_path = Path(td) / "sample_cc.ts"
            # Generate a valid TS file using ffmpeg if available, or synthetic packets
            pkts = b"".join(make_ts_packet(0x100, cc % 16) for cc in range(12))
            ts_path.write_bytes(pkts)

            proc = subprocess.run(
                [sys.executable, str(RPLAY_DL), "--audit-files", str(ts_path)],
                capture_output=True,
                text=True,
                check=False,
            )
            data = json.loads(proc.stdout)
            self.assertEqual(len(data["files"]), 1)
            f_entry = data["files"][0]
            self.assertEqual(f_entry["file"], "sample_cc.ts")
            self.assertIn("continuityCounterAudit", f_entry)
            cc_ev = f_entry["continuityCounterAudit"]
            self.assertEqual(cc_ev["packets"], 12)
            self.assertEqual(cc_ev["forwardJumps"], 0)
            self.assertEqual(cc_ev["duplicates"], 0)
            self.assertTrue(cc_ev["continuityOk"])


if __name__ == "__main__":
    unittest.main()
