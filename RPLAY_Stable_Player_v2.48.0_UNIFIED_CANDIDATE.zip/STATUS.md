# v2.48.0 状況 — 2026-10-27 JST

CANDIDATE_NO_GO / remote_published=false
完了:
- クラッシュ/リロード復帰時の確定済みパート履歴・チェックポイント証拠引継ぎ（`recSanitizePersistedParts` + `persistSession` v2 + `resumeFromCrash` 統合、Priority #2 完了）
- 保存後ローカルファイル単体での実メディア品質監査CLIモード（`rplay_dl.py --audit-files <FILE...>`：ffprobe PTS/DTS単調性・ffmpeg全編デコード・2トラックAV実時間相関をライブ通信なしでJSON出力、Priority #4 完了）
- 分離音声パート（`audioRendition.parts`）と映像パートの2トラック無劣化MP4結合モード（`rplay_join.py --mux-audio`：既定のfail-closed契約 `JOIN_SEPARATE_AUDIO_REQUIRES_MUX` を維持したまま明示指定時に2入力concat+copy結合・全編デコード検証）
- Python CLI (`rplay_dl.py` / `src/hls_transport.py`) の耐障害・途切れ防止パリティ統合（録画中の一時的不完全M3U8応答 `REC_TRANSIENT_PARSE_ERRORS` 最大2回猶予・音声トラック一時404猶予・セグメント転送寸断 `REC_TRANSIENT_TRANSFER_ERRORS` のFIFO先頭保持リトライと数値証拠出力）
- v2.44.0 までの全機能（パート単位の書込監査 `rspPartCommit` + `partSequenceRange`、URL録画 `urlMode`、CrossSite Compatibility v0.1.0、fMP4 `0xFFFFFFFF` 継続時間正規化、TS `verifyTs` 復旧、WebVTT結合）を完全維持
- 自動テスト合計 **991 / 991 PASS**（Node.js 812件 + Python 179件）

維持: v2.44の録画エラー・途切れ防止（JS/Python双方のM3U8一時破損猶予・転送寸断FIFO再試行・パート確定監査）、v2.43のCrossSite統合とfMP4継続時間正規化、v2.42のページ通信文脈。
未完: 汎用ブラウザ内動画DL、全サービスの認証再現、BG停止後自動MP4。
未受入: 実ブラウザCookie条件/実RPLAY/実Nico/Windows/2GiB/長時間/native preview進行。
