'use strict';
/* v2.37.0 core features (cat-catch 3rd wave — N-01..N-04 + packaging regression guard):
   1. N-01: software AES-128-CBC decryptor (decryptCbc/removePkcs7Padding) adapted from
      cat-catch lib/m3u8-decrypt.js (hls.js AESDecryptor lineage). Verified against NIST
      SP 800-38A CBC-AES128 known answers, WebCrypto cross-check (encrypt via
      crypto.subtle → software decrypt must reproduce the original bytes), and strict
      PKCS7 fail-closed padding validation.
   2. N-02: CLI AES-128 acquisition — Python hls_parse(allow_aes128=True) carries
      keyUri/keyIvHex per segment; SAMPLE-AES gets an explicit classification; the JS
      transport parse stays fail-closed (no key retrieval in the browser transport).
   3. N-03: TS continuity-counter audit (auditCc/mergeCcEvidence/ccEvidence) per
      ISO/IEC 13818-1 2.4.3.2 with a byte-for-byte cross-language mirror (JS vs Python
      on identical synthetic packets, including merged evidence and perPid truncation).
   4. Packaging regression guard: rplay_join.py must exist at the tree root and be
      byte-identical to src/join_parts.py (v2.15.0 shipped without it). */
const {test,before,after}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),vm=require('node:vm'),{spawnSync}=require('node:child_process'),crypto=require('node:crypto');
const ROOT=path.join(__dirname,'..');
const H=require('../src/hls_transport.js');

/* NIST SP 800-38A F.2.5 CBC-AES128.Decrypt */
const NIST_KEY=Buffer.from('2b7e151628aed2a6abf7158809cf4f3c','hex');
const NIST_IV=Buffer.from('000102030405060708090a0b0c0d0e0f','hex');
const NIST_CT=Buffer.from('7649abac8119b246cee98e9b12e9197d5086cb9b507219ee95db113a917678b273bed6b8e3c1743b7116e69e222295163ff1caa1681fac09120eca307586e1a7','hex');
const NIST_PT=Buffer.from('6bc1bee22e409f96e93d7e117393172aae2d8a571e03ac9c9eb76fac45af8e5130c81c46a35ce411e5fbc1191a0a52eff69f2445df4f9b17ad2b417be66c3710','hex');

function tsPacket(cc,pid,opts={}){
  const b=new Uint8Array(188);b[0]=0x47;
  b[1]=((opts.tei?0x80:0x00)|0x40|((pid>>8)&0x1f))&0xff;
  b[2]=pid&0xff;
  b[3]=((opts.afc===undefined?1:opts.afc)<<4)|(cc&0xf);
  return b;
}

before(()=>{});
after(()=>{});

/* ---------- 1. Version pin + packaging regression guard ---------- */
test('v2.37.0 version pin: userscript @version, both manifests, CLI strings, acceptance/build tools',()=>{
  const us=fs.readFileSync(path.join(ROOT,'rplay-stable-player.user.js'),'utf8');
  a.match(us,/\/\/ @version\s+2\.45\.0/);
  for(const ext of ['rplay-stable-player-extension','rplay-stable-player-extension-firefox']){
    const m=JSON.parse(fs.readFileSync(path.join(ROOT,ext,'manifest.json'),'utf8'));
    a.equal(m.version,'2.45.0',ext);
    if(ext.endsWith('-firefox')) a.equal(Object.hasOwn(m,'version_name'),false,'Firefox must omit unsupported version_name'); else a.equal(m.version_name,'2.45.0 CANDIDATE',ext+' version_name');
  }
  const cli=fs.readFileSync(path.join(ROOT,'rplay_dl.py'),'utf8');
  a.match(cli,/RPLAY Live Downloader v2\.45\.0 CANDIDATE/);
  a.match(cli,/rplay_dl\.py v2\.45\.0/);
  a.match(cli,/\(rplay_dl\.py\) v2\.45\.0/);
  a.match(cli,/--dec-key/);
  const acc=fs.readFileSync(path.join(ROOT,'scripts','acceptance_report.py'),'utf8');
  a.match(acc,/acceptance_report\.py v2\.45\.0/);
});

test('v2.37.0 packaging regression guard: rplay_join.py exists at root and equals src/join_parts.py (v2.15.0 shipped without it)',()=>{
  const root=path.join(ROOT,'rplay_join.py');
  a.ok(fs.existsSync(root),'rplay_join.py must exist at tree root (validate.py runtime list and join_recording.cmd reference it)');
  const lib=fs.readFileSync(path.join(ROOT,'src','join_parts.py'));
  a.equal(Buffer.from(lib).equals(fs.readFileSync(root)),true,'rplay_join.py must be the build.py copy of src/join_parts.py');
  const sums=JSON.parse(fs.readFileSync(path.join(ROOT,'SHA256SUMS.json'),'utf8'));
  a.ok('rplay_join.py' in sums,'rplay_join.py must be covered by SHA256SUMS.json');
});

/* ---------- 2. N-01: software AES-128-CBC decryptor ---------- */
test('v2.37.0 N-01 decryptCbc: NIST SP 800-38A CBC-AES128 known answer (raw, padding disabled)',()=>{
  a.equal(typeof H.decryptCbc,'function');
  const out=Buffer.from(H.decryptCbc(NIST_KEY,NIST_IV,NIST_CT,{padding:false}));
  a.equal(out.equals(NIST_PT),true,'software decrypt must reproduce the NIST plaintext byte-for-byte');
});

test('v2.37.0 N-01 decryptCbc: WebCrypto cross-check (encrypt with crypto.subtle, decrypt with software)',async()=>{
  for(const size of [16,32,188,376,1000,4096]){
    const plain=new Uint8Array(size);
    for(let i=0;i<size;i++)plain[i]=(i*7+3)&0xff;
    const k=await crypto.subtle.importKey('raw',NIST_KEY,{name:'AES-CBC'},false,['encrypt']);
    const ct=new Uint8Array(await crypto.subtle.encrypt({name:'AES-CBC',iv:NIST_IV},k,plain));
    const got=Buffer.from(H.decryptCbc(new Uint8Array(NIST_KEY),new Uint8Array(NIST_IV),ct));
    a.equal(got.equals(Buffer.from(plain)),true,'size '+size+': software decrypt must match WebCrypto plaintext (PKCS7 removed)');
  }
});

test('v2.37.0 N-01 removePkcs7Padding: strict PKCS7 validation fails closed',()=>{
  a.equal(typeof H.removePkcs7Padding,'function');
  // The NIST vector's last byte is 0x10 (16) but the previous 15 bytes are not 0x10 → must reject
  a.throws(()=>H.decryptCbc(NIST_KEY,NIST_IV,NIST_CT),/HLS_DECRYPT_PADDING/,'unpadded data must not pass strict PKCS7');
  for(const n of [1,7,16]){
    const buf=new Uint8Array(32).fill(0x41);
    for(let i=32-n;i<32;i++)buf[i]=n;
    a.equal(H.removePkcs7Padding(buf).length,32-n,'valid padding n='+n);
  }
  for(const [name,mut] of [['zero',b=>{b[31]=0;}],['17',b=>{b[31]=17;}],['non-uniform',b=>{b[31]=4;b[29]=4;b[30]=3;}]]){
    const buf=new Uint8Array(32).fill(0x41);mut(buf);
    a.throws(()=>H.removePkcs7Padding(buf),/HLS_DECRYPT_PADDING/,name+' padding must be rejected');
  }
});

test('v2.37.0 N-01 decryptCbc: fail-closed argument validation',()=>{
  a.throws(()=>H.decryptCbc(Buffer.alloc(15),NIST_IV,NIST_CT),/HLS_DECRYPT_KEY/,'key must be 16 bytes');
  a.throws(()=>H.decryptCbc(NIST_KEY,Buffer.alloc(15),NIST_CT),/HLS_DECRYPT_IV/,'iv must be 16 bytes');
  a.throws(()=>H.decryptCbc(NIST_KEY,NIST_IV,Buffer.alloc(31)),/HLS_DECRYPT_BLOCK_SIZE/,'data must be a positive multiple of 16');
  a.throws(()=>H.decryptCbc(NIST_KEY,NIST_IV,Buffer.alloc(0)),/HLS_DECRYPT_BLOCK_SIZE/,'empty data must be rejected');
  a.throws(()=>H.decryptCbc(NIST_KEY,NIST_IV,NIST_CT.subarray(0,31)),/HLS_DECRYPT_BLOCK_SIZE/,'truncated ciphertext must be rejected');
});

test('v2.37.0 N-01 VodDl decryptSeg falls back to software AES when crypto.subtle is unavailable (aesFallbackEvidence)',async()=>{
  const us=fs.readFileSync(path.join(ROOT,'rplay-stable-player.user.js'),'utf8');
  const start=us.indexOf('    async decryptSeg(data, seg) {');
  a.ok(start>0,'decryptSeg must exist in the userscript');
  const end=us.indexOf('\n    }\n',start);
  const dedent=s=>s.replace(/^ {4}/gm,'');
  const fnSrc=dedent(us.slice(start,end+7));
  const key16=new Uint8Array(NIST_KEY),iv16=new Uint8Array(NIST_IV);
  // Build a real PKCS7 ciphertext via WebCrypto: plain 1000 bytes → 1016 encrypted
  const plainData=new Uint8Array(1000);for(let i=0;i<1000;i++)plainData[i]=i&0xff;
  const wk=await crypto.subtle.importKey('raw',NIST_KEY,{name:'AES-CBC'},false,['encrypt']);
  const ct=new Uint8Array(await crypto.subtle.encrypt({name:'AES-CBC',iv:NIST_IV},wk,plainData));
  // No crypto at all → fallback path
  const ctx=vm.createContext({Promise,Uint8Array,console,HLS:H}); // no crypto binding
  vm.runInContext('globalThis.decryptSeg='+fnSrc.replace('async decryptSeg(data, seg) {','async function __decryptSeg(data, seg) {')+';',ctx);
  const self={keys:{'https://cdn/key':key16},ivFor:()=>iv16,log:()=>{}};
  const got=await vm.runInContext('decryptSeg',ctx).call(self,new Uint8Array(ct),{key:{uri:'https://cdn/key'},seq:5});
  a.equal(Buffer.from(got).equals(Buffer.from(plainData)),true,'software fallback must reproduce the WebCrypto plaintext');
  a.equal(self._aesFallback.attempts,1);
  a.equal(self._aesFallback.webcryptoOk,0);
  a.equal(self._aesFallback.softwareSuccesses,1);
  a.equal(self._aesFallback.lastReason,'webcrypto:unavailable');
  // WebCrypto available path stays primary
  const self2={keys:{'https://cdn/key':key16},ivFor:()=>iv16,log:()=>{}};
  const ctx2=vm.createContext({Promise,Uint8Array,console,HLS:H,crypto});
  vm.runInContext('globalThis.decryptSeg2='+fnSrc.replace('async decryptSeg(data, seg) {','async function __decryptSeg(data, seg) {')+';',ctx2);
  const got2=await vm.runInContext('decryptSeg2',ctx2).call(self2,new Uint8Array(ct),{key:{uri:'https://cdn/key'},seq:6});
  a.equal(Buffer.from(got2).equals(Buffer.from(plainData)),true,'WebCrypto path still primary when available');
  a.equal(self2._aesFallback.webcryptoOk,1);
  a.equal(self2._aesFallback.softwareSuccesses,0);
  a.equal(self2._aesFallback.attempts,1);
});

test('v2.37.0 N-01 aesFallbackEvidence and continuityCounterEvidence are wired into the recorder info JSON',()=>{
  const us=fs.readFileSync(path.join(ROOT,'rplay-stable-player.user.js'),'utf8');
  a.match(us,/aesFallbackEvidence:/);
  a.match(us,/continuityCounterEvidence:/);
  a.match(us,/HLS\.ccEvidence\(this\._hlsCcAudit\)/);
});

/* ---------- 3. N-02: CLI parse allow_aes128 (Python) — JS stays fail-closed ---------- */
test('v2.37.0 N-02 JS transport parse stays fail-closed for encrypted playlists (no key retrieval in browser transport)',()=>{
  const pl='#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-KEY:METHOD=AES-128,URI="https://cdn/key",IV=0x000102030405060708090a0b0c0d0e0f\nseg0.ts\n#EXT-X-ENDLIST\n';
  a.throws(()=>H.parse(pl,'https://cdn/live.m3u8'),/HLS_ENCRYPTED_UNSUPPORTED/);
  a.throws(()=>H.parse('#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-KEY:METHOD=SAMPLE-AES,URI="k"\nseg0.ts\n'),/HLS_ENCRYPTED_UNSUPPORTED/);
});

test('v2.37.0 N-02 Python hls_parse(allow_aes128=True): keyUri/keyIvHex per segment, explicit SAMPLE-AES/MAP classification',()=>{
  const pl=(key,iv)=>'#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:10\n#EXT-X-KEY:METHOD=AES-128,URI="'+key+'"'+(iv?',IV='+iv:'')+'\nseg0.ts\nseg1.ts\n#EXT-X-KEY:METHOD=NONE\nseg2.ts\n#EXT-X-ENDLIST\n';
  const py=(code)=>{const r=spawnSync('python3',['-c',code],{cwd:ROOT,encoding:'utf8'});a.equal(r.status,0,r.stderr);return JSON.parse(r.stdout);};
  const out=py(
    "import importlib.util,json,pathlib\n"+
    "spec=importlib.util.spec_from_file_location('x',pathlib.Path('rplay_dl.py'))\n"+
    "m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)\n"+
    "pl="+JSON.stringify(pl('https://cdn/key?token=t','0x000102030405060708090a0b0c0d0e0f'))+"\n"+
    "p=m.hls_parse(pl,'https://cdn/live.m3u8',allow_aes128=True)\n"+
    "print(json.dumps(p['segments']))");
  a.equal(out.length,3);
  a.equal(out[0]['keyUri'],'https://cdn/key?token=t');
  a.equal(out[0]['keyIvHex'],'0x000102030405060708090a0b0c0d0e0f');
  a.equal(out[1]['keyUri'],'https://cdn/key?token=t');
  a.equal('keyUri' in out[2],false,'METHOD=NONE clears the key for following segments');
  a.equal(out[0]['sequence'],10);
  // Default (no key supplied) stays fail-closed
  const rej=spawnSync('python3',['-c',
    "import importlib.util,pathlib\n"+
    "spec=importlib.util.spec_from_file_location('x',pathlib.Path('rplay_dl.py'))\n"+
    "m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)\n"+
    "try:\n m.hls_parse("+JSON.stringify(pl('https://cdn/key',null))+",'https://cdn/live.m3u8')\n print('NO_THROW')\nexcept ValueError as e:\n print(str(e))"],
    {cwd:ROOT,encoding:'utf8'});
  a.equal(rej.status,0,rej.stderr);
  a.equal(rej.stdout.trim(),'HLS_ENCRYPTED_UNSUPPORTED');
  // SAMPLE-AES explicit classification
  const sample=spawnSync('python3',['-c',
    "import importlib.util,pathlib\n"+
    "spec=importlib.util.spec_from_file_location('x',pathlib.Path('rplay_dl.py'))\n"+
    "m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)\n"+
    "try:\n m.hls_parse('#EXTM3U\\n#EXT-X-TARGETDURATION:1\\n#EXT-X-KEY:METHOD=SAMPLE-AES,URI=\"k\"\\nseg.ts\\n','https://c/l',allow_aes128=True)\n print('NO_THROW')\nexcept ValueError as e:\n print(str(e))"],
    {cwd:ROOT,encoding:'utf8'});
  a.equal(sample.stdout.trim(),'HLS_SAMPLE_AES_UNSUPPORTED');
  // Encrypted MAP stays rejected even with allow_aes128
  const encmap=spawnSync('python3',['-c',
    "import importlib.util,pathlib\n"+
    "spec=importlib.util.spec_from_file_location('x',pathlib.Path('rplay_dl.py'))\n"+
    "m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)\n"+
    "try:\n m.hls_parse('#EXTM3U\\n#EXT-X-TARGETDURATION:1\\n#EXT-X-KEY:METHOD=AES-128,URI=\"k\"\\n#EXT-X-MAP:URI=\"i.mp4\"\\nseg.m4s\\n','https://c/l',allow_aes128=True)\n print('NO_THROW')\nexcept ValueError as e:\n print(str(e))"],
    {cwd:ROOT,encoding:'utf8'});
  a.equal(encmap.stdout.trim(),'HLS_ENCRYPTED_MAP_UNSUPPORTED');
});

/* ---------- 4. N-03: TS continuity-counter audit ---------- */
test('v2.37.0 N-03 auditCc: continuity/duplicate/forward/backward/no-payload/reserved/TEI classification',()=>{
  a.equal(typeof H.auditCc,'function');
  // ok, ok, jump(+2 → 1 lost), ok
  let s=H.auditCc(Buffer.concat([tsPacket(5,0x100),tsPacket(6,0x100),tsPacket(8,0x100),tsPacket(9,0x100)]));
  a.equal(s.packets,4);a.equal(s.pids,1);a.equal(s.payloadPackets,4);
  a.equal(s.continuityOk,2);a.equal(s.forwardJumps,1);a.equal(s.lostPacketEstimate,1);a.equal(s.maxSingleJump,1);
  a.equal(s.perPid[0x100].lost,1);
  // duplicate allowed once, backward jump counted
  s=H.auditCc(Buffer.concat([tsPacket(5,0x100),tsPacket(5,0x100),tsPacket(3,0x100),tsPacket(4,0x100)]));
  a.equal(s.continuityOk,1);a.equal(s.duplicates,1);a.equal(s.backwardJumps,1);
  // afc=2 no payload: no increment expected; afc=0 reserved counted separately
  s=H.auditCc(Buffer.concat([tsPacket(5,0x100,{afc:1}),tsPacket(5,0x100,{afc:2}),tsPacket(6,0x100,{afc:1}),tsPacket(7,0x100,{afc:0})]));
  a.equal(s.noPayloadPackets,1);a.equal(s.afcReserved,1);a.equal(s.continuityOk,1);
  // TEI counted, multiple PIDs tracked independently
  s=H.auditCc(Buffer.concat([tsPacket(0,0x0,{tei:true}),tsPacket(3,0x1fff),tsPacket(4,0x1fff)]));
  a.equal(s.teiPackets,1);a.equal(s.pids,2);a.equal(s.continuityOk,1);
  // wrap-around 15→0 is a normal +1
  s=H.auditCc(Buffer.concat([tsPacket(15,0x100),tsPacket(0,0x100)]));
  a.equal(s.continuityOk,1);a.equal(s.backwardJumps,0);
  // non-TS input returns zeroed audit
  s=H.auditCc(Buffer.alloc(100));
  a.equal(s.packets,0);
});

test('v2.37.0 N-03 cross-language parity: JS auditCc/mergeCc/ccEvidence === Python hls_audit_cc/merge/evidence on identical bytes',()=>{
  const parts=[];
  for(let i=0;i<50;i++)parts.push(tsPacket((2*i)%16,0x100));       // every other → fwd jumps
  for(let i=0;i<30;i++)parts.push(tsPacket(i%16,0x11));            // clean run with wrap
  parts.push(tsPacket(9,0x11,{afc:2}));                            // no payload
  parts.push(tsPacket(9,0x11,{afc:0}));                            // reserved
  parts.push(tsPacket(3,0x22,{tei:true}));                         // TEI + distinct PID
  for(let i=0;i<10;i++)parts.push(tsPacket(i,0x22));
  const data=Buffer.concat(parts);
  const jsSeg=H.auditCc(new Uint8Array(data));
  const jsAcc=H.mergeCcEvidence(H.mergeCcEvidence(H.emptyCcAudit(),jsSeg),jsSeg); // two identical segments
  const jsEv=H.ccEvidence(jsAcc);
  const bin=path.join(os.tmpdir(),'rsp_cc_parity_'+process.pid+'.bin');
  fs.writeFileSync(bin,data);
  try{
    const r=spawnSync('python3',['-c',
      "import importlib.util,json,pathlib,os\n"+
      "spec=importlib.util.spec_from_file_location('x',pathlib.Path('rplay_dl.py'))\n"+
      "m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)\n"+
      "data=open(os.environ['CC_BIN'],'rb').read()\n"+
      "seg=m.hls_audit_cc(data)\n"+
      "acc=m.hls_merge_cc(m.hls_merge_cc(m.hls_empty_cc(),seg),seg)\n"+
      "ev=m.hls_cc_evidence(acc)\n"+
      "print(json.dumps({'seg':seg,'ev':ev},sort_keys=True))"],
      {cwd:ROOT,encoding:'utf8',env:Object.assign({},process.env,{CC_BIN:bin})});
    a.equal(r.status,0,r.stderr);
    const pyOut=JSON.parse(r.stdout);
    a.deepEqual(jsSeg,pyOut.seg,'per-segment audit must match across languages');
    a.deepEqual(jsEv,pyOut.ev,'merged evidence must match across languages (incl. perPid sort)');
  }finally{fs.rmSync(bin,{force:true});}
  // perPid capped at 16 with truncation flag
  const many=Buffer.concat(Array.from({length:20},(_,i)=>tsPacket(1,(0x100+i)%8192)));
  const ev=H.ccEvidence(H.mergeCcEvidence(H.emptyCcAudit(),H.auditCc(many)));
  a.equal(ev.perPid.length,16);
  a.equal(ev.perPidTruncated,true);
  a.deepEqual(ev.perPid.map(e=>e.pid),ev.perPid.map(e=>e.pid).sort((x,y)=>x-y).sort((x,y)=>y-x)&&ev.perPid.map(e=>e.pid),'perPid sorted by packets desc');
});

test('v2.37.0 N-03 fetchItem hooks cc audit for plain TS (owner._hlsCcAudit accumulation)',async()=>{
  // Serve one valid TS segment over data: URL-less fetch mock
  const seg=Buffer.concat([tsPacket(0,0x100),tsPacket(1,0x100)]);
  const owner={queue:[],seen:new Set(),_hlsGeneration:0,splitOnDiscontinuity:()=>false,stopped:false,partOpen:false,pushData:async()=>{}};
  owner._hlsTransfer={async request(){return {status:200,bytes:new Uint8Array(seg)};}};
  const item={name:'x.ts',tries:0,hls:{uri:'https://cdn/seg0.ts',range:null,map:null,gap:false,sequence:1,discontinuity:0,duration:1,programDateTimeMs:null,epoch:1}};
  const res=await H.fetchItem(owner,item);
  a.ok(res.bytes,'fetchItem must return the validated TS');
  const ev=H.ccEvidence(owner._hlsCcAudit);
  a.equal(ev.segmentsAudited,1);
  a.equal(ev.packets,2);
  a.equal(ev.continuityOk,1);
  a.equal(ev.perPid[0].pid,0x100);
});

if(require.main===module)console.log('test_v2160_core loaded');
