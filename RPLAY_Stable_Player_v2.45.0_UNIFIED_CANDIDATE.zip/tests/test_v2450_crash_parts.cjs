const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const HLS = require(path.join(root, 'src/hls_transport.js'));
const PartCommit = vm.runInNewContext(fs.readFileSync(path.join(root, 'src/part_commit_core.js'), 'utf8') + '\nrspPartCommit;', {});
const Sha256 = vm.runInNewContext(fs.readFileSync(path.join(root, 'src/sha256.js'), 'utf8') + '\nRspSha256;', {});

function validTsChunk(seq = 0, packets = 2) {
  const buf = new Uint8Array(188 * packets);
  for (let i = 0; i < packets; i++) {
    buf[i * 188] = 0x47;
    buf[i * 188 + 1] = 0x01;
    buf[i * 188 + 2] = 0x00;
    buf[i * 188 + 3] = 0x10 | ((seq + i) & 0x0f);
  }
  return buf;
}

function loadRecorderContext(fetchImpl) {
  const s = fs.readFileSync(path.join(root, 'rplay-stable-player.user.js'), 'utf8');
  const partIoStart = s.indexOf('function recTrackSave');
  const partIoEnd = s.indexOf('// Recovery uses committed chunks alongside', partIoStart);
  const partIoHelper = s.slice(partIoStart, partIoEnd);
  const start = s.indexOf('async function recFetchDescriptor');
  const end = s.indexOf('/* ==== RSP RECORDING CORE', start);
  const code = partIoHelper + '\n' + s.slice(start, end);
  const savedJsons = [];
  const storage = new Map();
  let partCounter = 0;
  const ctx = {
    HLS,
    rspPartCommit: PartCommit,
    RspSha256: Sha256,
    fetch: fetchImpl,
    TextDecoder,
    TextEncoder,
    Uint8Array,
    URL,
    Set,
    Map,
    Math,
    Date,
    Promise,
    Error,
    Number,
    String,
    Object,
    Array,
    Blob: class { constructor(parts) { this.text = parts.join(''); } },
    JSON,
    console,
    setTimeout: (fn) => { fn(); return 1; },
    clearTimeout: () => {},
    setInterval: () => 1,
    clearInterval: () => {},
    CDN_BASE: 'https://cdn.example/',
    API_BASE: 'https://api.example',
    TITLEC: { base: 'StreamTitle' },
    REC_TICK_MS: 10,
    REC_POLL_MS: 10,
    REC_POLL_JITTER_MS: 0,
    REC_END_STALL_MS: 60000,
    REC_STALL_GIVE_UP_MS: 60000,
    REC_STANDBY_FAST_MS: 10,
    REC_STANDBY_SLOW_MS: 10,
    REC_STANDBY_WARM_SEC: 60,
    REC_STANDBY_API_MS: 10,
    REC_STANDBY_SCHED_MS: 10,
    REC_SCHED_WARM_BEFORE_MS: 10,
    REC_SEG_MAX_TRIES: 3,
    REC_SEG_TIMEOUT_MS: 50,
    REC_API_TIMEOUT_MS: 50,
    REC_REQ_MIN_GAP_MS: 0,
    REC_404_STANDBY: 3,
    REC_404_GIVE_UP: 5,
    REC_403_COOLDOWN_MS: 10,
    REC_429_BASE_MS: 10,
    REC_429_MAX_MS: 20,
    REC_FILE_CAP_BYTES: 1048576,
    REC_SPLIT_MIN_DEFAULT: 0,
    REC_QUEUE_WARN_MS: 60000,
    REC_QUALITY_RESCAN_MS: 60000,
    REC_MASTER_FAILOVER_N: 2,
    REC_AUDIO_OFFSET_MS_MIN: 0,
    REC_AUDIO_OFFSET_MS_MAX: 0,
    REC_AUDIO_OFFSET_MIN_MS: 0,
    REC_AUDIO_OFFSET_SPAN_MS: 0,
    REC_AUDIO_STALL_MS: 60000,
    REC_SESSION_KEY: 'rsp_rec_session',
    REC_SESSION_STALE_MS: 60000,
    RECENV: {
      download: (blob, name) => savedJsons.push({ name, obj: blob && blob.text ? JSON.parse(blob.text) : null }),
      storageGet: (k, d) => storage.has(k) ? storage.get(k) : d,
      storageSet: (k, v) => storage.set(k, v),
      storageDel: (k) => storage.delete(k),
      saveJson: (obj, name) => savedJsons.push({ name, obj: JSON.parse(obj) }),
      setTitle: () => {},
      notify: () => {},
      onUnload: () => {},
      offUnload: () => {},
      recoveredParts: () => [],
      sessionEnded: () => Promise.resolve(),
      autoPolicy: async () => ({ verdict: 'allowed' })
    },
    RecPartSink: class {
      constructor(name, dir, ext) {
        this.name = name;
        this.ext = ext;
        this.bytes = 0;
        this.hash = new Sha256.Sha256();
      }
      push(u8) { this.bytes += u8.byteLength; this.hash.update(u8); }
      async flush() {}
      continuousDisk() { return true; }
      async close() {
        return {
          confirmed: true,
          stage: 'FILE_CLOSED',
          bytes: this.bytes,
          hashHex: this.hash.digest(),
          checkpoint: { chunks: 1, committedBytes: this.bytes, status: 'complete' }
        };
      }
    },
    recFileName: (_tpl, _vars, def) => {
      partCounter++;
      return def.replace('_now_', `_now${partCounter}_`);
    },
    safeName: (x) => x,
    stampNow: () => 'now',
    pad2: (n) => String(n).padStart(2, '0'),
    recSaveBlob: (blob, _dir, name) => {
      savedJsons.push({ name, obj: blob && blob.text ? JSON.parse(blob.text) : null });
      return Promise.resolve({ confirmed: true, stage: 'FILE_CLOSED' });
    },
    idbAddSession: async () => {},
    recLedgerStage: (entry, stage, extra) => {
      if (!entry.stages) entry.stages = [];
      entry.stages.push({ stage, ...(extra || {}) });
    },
    recLedgerStatus: () => 'verified_local',
    recHlsReloadMs: () => 10,
    recRetryAfterMs: () => 0,
    recRedactUrl: (u) => (u ? u.split('?')[0] : ''),
    recJoinJob: (owner) => {
      const parts = owner._joinParts && owner._joinParts.length ? owner._joinParts : (owner.partsLog || []);
      return {
        schema: 'rsp.join.v1',
        tool: 'RPLAY Stable Player v2.45.0',
        truncated: !!owner._joinTruncated,
        incomplete: !!((owner.segFails || 0) + (owner.gapCount || 0) + (owner.failedSaves || 0)),
        parts: parts.map((p) => ({ file: p.file, bytes: p.bytes, ...(p.sha256 ? { sha256: p.sha256 } : {}) }))
      };
    },
    resolveMemberLive: async () => null,
    memberHintText: () => '',
    memberFailHint: () => '',
    refreshPlayCandidates: async () => [],
    liveStreamState: async () => ({}),
    liveBaseLabel: () => 'CDN',
    rspSourceCandidates: () => ['https://cdn.example/live.m3u8'],
    probeLiveApiState: async () => null,
    fetchUpcomingSchedule: async () => null,
    resolveScheduleInfo: async () => null,
    fetchSchedulesFor: async () => ({ items: [] }),
    pickBestVariant: (v) => v[0] || null,
    pickBestAudioRendition: () => null,
    parseM3u8Variants: () => [],
    parseM3u8AudioRenditions: () => [],
    recRecoveryEvidence: () => undefined,
    recSubtitleEvidence: () => undefined,
    rspParseStreamStartSec: () => null,
    rspSessionTrackingEvidence: () => undefined,
    rspErrorTaxonomyEvidence: () => undefined,
    rspPartContinuityEvidence: () => undefined,
    rspBuildM3u8dlExport: () => ({}),
    rspExternalDownloaderEvidence: () => undefined,
    createTicker: () => ({ stop: () => {} }),
    createTsVerifier: () => ({ usingWorker: () => false, check: async () => ({ ok: true }) })
  };
  vm.createContext(ctx);
  vm.runInContext(code + '\nthis.Recorder = Recorder; this.recSanitizePersistedParts = recSanitizePersistedParts;', ctx);
  return { Recorder: ctx.Recorder, recSanitizePersistedParts: ctx.recSanitizePersistedParts, savedJsons, storage };
}

function makeUi() {
  const logs = [];
  return {
    logs,
    log: (m) => logs.push(m),
    recState: () => {},
    recUpdate: () => {},
    recBytes: () => {},
    setQualityList: () => {},
    getSelectedQuality: () => 'best',
    isBestQuality: () => false,
    isFollow: () => false,
    getSplitMinutes: () => 0,
    infoJsonChecked: () => true,
    getFilenameTpl: () => '',
    isRecAudio: () => true,
    isInheritQuery: () => false,
    isSplitOnDiscontinuity: () => false
  };
}

test('v2.45.0 Priority #2: recSanitizePersistedParts filters URLs/paths and preserves partIntegrity + checkpoint receipt', () => {
  const { recSanitizePersistedParts } = loadRecorderContext(async () => ({ status: 200 }));
  const raw = [
    {
      file: 'RPLAY_creator_20261027_010000_p1.ts',
      ext: 'ts',
      bytes: 1880,
      segments: 5,
      startedAt: '2026-10-27T01:00:00.000Z',
      endedAt: '2026-10-27T01:00:10.000Z',
      saveState: 'FILE_CLOSED',
      hashState: 'hashed',
      sha256: 'a'.repeat(64),
      ledgerStatus: 'committed',
      structureValidated: true,
      partIntegrity: {
        status: 'COMMITTED_NO_DETECTED_GAP',
        acceptedSegments: 5,
        checkpoint: { committedBytes: 1880, chunks: 1 }
      }
    },
    { file: 'https://evil.example/p2.ts', ext: 'ts', bytes: 1880 },
    { file: '../secret.ts', ext: 'ts', bytes: 1880 },
    { file: 'empty.ts', ext: 'ts', bytes: 0 }
  ];
  const clean = recSanitizePersistedParts(raw);
  assert.equal(clean.length, 1);
  assert.equal(clean[0].file, 'RPLAY_creator_20261027_010000_p1.ts');
  assert.equal(clean[0].sha256, 'a'.repeat(64));
  assert.equal(clean[0].resumedFromPriorRun, true);
  assert.deepEqual(clean[0].partIntegrity.checkpoint, { committedBytes: 1880, chunks: 1 });
});

test('v2.45.0 Priority #2: Recorder.persistSession and resumeFromCrash preserve completed parts[] and join job continuity across crash/reload', async () => {
  let seq = 10;
  const { Recorder, savedJsons, storage } = loadRecorderContext(async (u) => {
    const url = String(u);
    if (url.includes('.m3u8')) {
      const s = seq++;
      const body = `#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:${s}\n#EXTINF:2.0,\nseg${s}.ts\n`;
      return new Response(body, { status: 200 });
    }
    return new Response(validTsChunk(seq, 2), { status: 200 });
  });

  // 1. Pre-crash recorder records part 1 and closes it before browser reload/crash
  const ui1 = makeUi();
  const rec1 = new Recorder('0123456789abcdef01234567', ui1);
  rec1.recording = true;
  rec1.stopped = false;
  rec1.state = 'RUN';
  rec1._skipBacklog = false;

  await rec1.pollPlaylist();
  await rec1.drain();
  assert.equal(rec1.segTotal, 1);
  await rec1.closePart();

  // Verify session in storage now includes the committed part 1 with sha256 and partIntegrity.checkpoint
  const rawSession = storage.get('rsp_rec_session');
  assert.ok(rawSession, 'session should be persisted to storage');
  const parsedSession = JSON.parse(rawSession);
  assert.equal(parsedSession.v, 2);
  assert.equal(parsedSession.partsLog.length, 1);
  assert.equal(parsedSession.partsLog[0].segments, 1);
  assert.equal(parsedSession.partsLog[0].saveState, 'FILE_CLOSED');
  assert.ok(parsedSession.partsLog[0].sha256);
  assert.deepEqual(parsedSession.partsLog[0].partIntegrity.checkpoint, { chunks: 1, committedBytes: 376, status: 'complete', source: 'chunk_hash_verified_at_checkpoint' });

  // 2. Post-crash recorder resumes from persisted session, records part 2, and stops
  const ui2 = makeUi();
  const rec2 = new Recorder('0123456789abcdef01234567', ui2);
  rec2.resumeFromCrash(parsedSession);
  await rec2._resumeReady;

  // Poll next segment (after backlog skip) and drain into part 2
  await rec2.pollPlaylist();
  await rec2.drain();
  await rec2.stop(false);
  assert.equal(rec2.partsLog.length, 2);

  // Both part 1 (from before reload) and part 2 (after reload) must appear in _info.json and _join_*.json!
  const infoJson = savedJsons.find((x) => x.name && !x.name.includes('_join_'));
  const joinJson = savedJsons.find((x) => x.name && x.name.includes('_join_'));
  assert.ok(infoJson && infoJson.obj, '_info.json should be saved');
  assert.ok(joinJson && joinJson.obj, '_join_*.json should be saved when 2 parts exist across crash resume');
  assert.equal(infoJson.obj.parts.length, 2);
  assert.equal(infoJson.obj.parts[0].resumedFromPriorRun, true);
  assert.equal(infoJson.obj.parts[0].partIntegrity.sinkReceipt, 'file_closed_and_readback');
  assert.equal(infoJson.obj.parts[1].partIntegrity.sinkReceipt, 'file_closed_and_readback');
  assert.equal(joinJson.obj.parts.length, 2);
  assert.equal(joinJson.obj.parts[0].file, infoJson.obj.parts[0].file);
  assert.equal(joinJson.obj.parts[1].file, infoJson.obj.parts[1].file);
});
