# Generated into the standalone CLI by scripts/build.py. No external dependencies.
HLS_LIMIT = 32 * 1048576
HLS_URI_CACHE_MAX = 4096  # v2.5.0: generation-recovery URI identity cache bound
# v2.6.0(P2): LL-HLS系タグの安全側方針 — 差分playlist(EXT-X-SKIP)は専用コードで拒否、
# PRELOAD-HINT/SERVER-CONTROL等は取得も再生もしないが計数証拠として記録する。
LLHLS_INDICATOR_TAGS = ('#EXT-X-SERVER-CONTROL:', '#EXT-X-PRELOAD-HINT:',
                        '#EXT-X-RENDITION-REPORT:', '#EXT-X-PART:', '#EXT-X-PART-INF:')
# v2.45.0: Cross-language resilience parity with JS HLS transport
REC_TRANSIENT_PARSE_ERRORS = ('HLS_BAD_PLAYLIST', 'HLS_BAD_TARGET', 'HLS_DANGLING_TAG', 'HLS_DANGLING_RANGE', 'HLS_BAD_EXTINF')
REC_TRANSIENT_TRANSFER_ERRORS = ('HLS_BODY_LENGTH', 'HLS_RANGE_LENGTH', 'HLS_EMPTY_BODY')


def hls_uri_key(d):
    # v2.5.0: immutable-data identity (path + byte range; signature query excluded
    # on purpose so refreshed signatures still dedup to the same media object).
    return d['uri'].split('?')[0].split('#')[0] + ('|' + json.dumps(d['range'], sort_keys=True) if d['range'] else '')


def hls_part_boundary(d, split_on_discontinuity=False):
    # v2.12.0: MPEG-TS(mapなし)は188バイトパケット毎にPAT/PMT/PCRを持つ自己同期ストリームのため、
    # EXT-X-DISCONTINUITYで細切れに分割せず単一ファイルへ連続追記する(Video DownloadHelper /
    # Streamlink / yt-dlp / cat-catch と同一方針)。fMP4(mapあり)は初期化セグメント整合のため境界分割を維持。
    if d.get('map'):
        return json.dumps([d['epoch'], d['discontinuity'], d['map']], sort_keys=True)
    return json.dumps(['ts', d['epoch'], d['discontinuity'] if split_on_discontinuity else 0])

def hls_uint(value):
    if not re.fullmatch(r'[0-9]+', value) or int(value) > 9007199254740991:
        raise ValueError('HLS_BAD_INTEGER')
    return int(value)

def hls_attrs(value):
    result = {}
    while value:
        m = re.match(r'([A-Z0-9-]+)=("[^"]*"|[^,]*)(,|$)', value)
        if not m or m[1] in result:
            raise ValueError('HLS_BAD_ATTRIBUTES')
        result[m[1]] = m[2][1:-1] if m[2].startswith('"') else m[2]
        value = value[m.end():]
        if m[3] and not value:
            raise ValueError('HLS_BAD_ATTRIBUTES')
    return result

def hls_url(raw, base, inherit_query=False):
    if not isinstance(raw, str) or raw != raw.strip() or any(ord(c)<32 or ord(c)==127 for c in raw):
        raise ValueError('HLS_BAD_URL')
    value = urllib.parse.urljoin(base, raw)
    u = urllib.parse.urlsplit(value)
    if u.scheme not in ('http', 'https') or not u.hostname or u.username or u.password:
        raise ValueError('HLS_BAD_URL')
    u = u._replace(fragment='')
    if inherit_query:
        try:
            b = urllib.parse.urlsplit(base)
            if b.query and (u.scheme, u.netloc) == (b.scheme, b.netloc):
                u_q = urllib.parse.parse_qsl(u.query, keep_blank_values=True)
                u_keys = {k for k, _ in u_q}
                for k, v in urllib.parse.parse_qsl(b.query, keep_blank_values=True):
                    if k not in u_keys:
                        u_q.append((k, v))
                        u_keys.add(k)
                u = u._replace(query=urllib.parse.urlencode(u_q))
        except Exception:
            pass
    return urllib.parse.urlunsplit(u)

def hls_range(raw, previous, uri, is_map=False):
    if raw is None:
        return None
    m = re.fullmatch(r'([0-9]+)(?:@([0-9]+))?', raw)
    if not m:
        raise ValueError('HLS_BAD_RANGE')
    length = hls_uint(m[1])
    if not 0 < length <= HLS_LIMIT:
        raise ValueError('HLS_RANGE_LIMIT')
    if m[2] is not None:
        offset = hls_uint(m[2])
    else:
        if is_map or not previous or previous['uri'] != uri or not previous['range']:
            raise ValueError('HLS_IMPLICIT_RANGE')
        offset = sum(previous['range'].values())
    if offset + length - 1 > 9007199254740991:
        raise ValueError('HLS_RANGE_LIMIT')
    return {'offset': offset, 'length': length}

def hls_parse(text, base, mode='legacy', inherit_query=False, allow_aes128=False):
    # v2.5.0: mode='legacy' (default) keeps pre-v2.5 input compatibility — a media
    # segment URI without a preceding EXTINF is counted as a diagnostic and accepted.
    # mode='rfc' rejects it (RFC 8216 4.3.2.1: EXTINF REQUIRED per media segment).
    # v2.12.0(C-02): inherit_query=True appends base playlist query params to same-origin URIs.
    # v2.37.0(N-02): allow_aes128=True accepts METHOD=AES-128 playlists when the caller
    # supplies a decryption key (segments carry keyUri/keyIvHex). SAMPLE-AES* stays
    # rejected (HLS_SAMPLE_AES_UNSUPPORTED) and encrypted EXT-X-MAP stays rejected
    # (HLS_ENCRYPTED_MAP_UNSUPPORTED) — fMP4 init segments are never decrypted.
    # Default allow_aes128=False keeps the pre-2.16 fail-closed behavior byte-for-byte.
    if not isinstance(text, str) or len(text) > 2*1048576 or not re.match(r'^\ufeff?#EXTM3U(?:\r?\n|$)', text):
        raise ValueError('HLS_BAD_PLAYLIST')
    seq, disc, target, init, encrypted, br, gap, previous, end = 0, 0, 0, None, False, None, False, None, False
    key_uri = key_iv = None
    seen_seq=seen_disc=seen_target=seen_version=False
    pending_duration=pending_clock=None
    segments = []
    # v2.6.0(P1): fMP4初期化セグメント(EXT-X-MAP)の宣言証拠。切替はパート境界で
    # 分割して初期化セグメント混在を防止済み。DISCONTINUITY無しの切替は品質
    # リスクの計数証拠とする(拒否はしない — 仕様上は合法だが破損疑いの指標)。
    map_decls=map_switches=map_switch_no_disc=0
    disc_since_seg=True
    # v2.6.0(P2): LL-HLS指標タグの計数(PRELOAD-HINTは取得しない)
    llhls_tags=0
    query_inherited=0
    for line in text.lstrip('\ufeff').splitlines():
        rawline = line
        line = line.strip()
        if line and not line.startswith('#') and rawline != line: raise ValueError('HLS_BAD_URL')
        if line.startswith('#EXT-X-VERSION:'):
            if seen_version: raise ValueError('HLS_BAD_VERSION')
            seen_version=True
            hls_uint(line[15:])
        if line.startswith('#EXT-X-STREAM-INF:'):
            raise ValueError('HLS_EXPECT_FULL_MEDIA')
        if line.startswith('#EXT-X-SKIP:'):
            # v2.6.0(P2): 差分playlistは鍵計算が成り立たないため専用コードで拒否
            raise ValueError('HLS_LLHLS_SKIP')
        if line.startswith(LLHLS_INDICATOR_TAGS):
            llhls_tags += 1
        if line == '#EXT-X-I-FRAMES-ONLY':
            raise ValueError('HLS_IFRAMES_UNSUPPORTED')
        if line.startswith('#EXT-X-MEDIA-SEQUENCE:'):
            if segments or seen_seq: raise ValueError('HLS_BAD_SEQUENCE')
            seen_seq=True
            seq = hls_uint(line[22:])
        elif line.startswith('#EXT-X-DISCONTINUITY-SEQUENCE:'):
            if segments or seen_disc: raise ValueError('HLS_BAD_SEQUENCE')
            seen_disc=True
            disc = hls_uint(line[30:])
        elif line == '#EXT-X-DISCONTINUITY':
            disc += 1
            disc_since_seg = True
        elif line.startswith('#EXT-X-TARGETDURATION:'):
            if seen_target or segments: raise ValueError('HLS_BAD_TARGET')
            seen_target=True
            target = hls_uint(line[22:])
            if not target: raise ValueError('HLS_BAD_TARGET')
        elif line.startswith('#EXTINF:'):
            if end or pending_duration is not None: raise ValueError('HLS_BAD_EXTINF')
            value=line[8:].split(',')[0]
            if not re.fullmatch(r'(?:[0-9]+(?:\.[0-9]+)?|\.[0-9]+)',value): raise ValueError('HLS_BAD_EXTINF')
            pending_duration=float(value)
            if not math.isfinite(pending_duration) or not 0 < pending_duration <= 86400: raise ValueError('HLS_BAD_EXTINF')
        elif line.startswith('#EXT-X-PROGRAM-DATE-TIME:'):
            if end or pending_clock is not None: raise ValueError('HLS_BAD_PROGRAM_DATE_TIME')
            value=line[25:]
            if not re.fullmatch(r'[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,3})?(?:Z|[+-][0-9]{2}:[0-9]{2})',value):raise ValueError('HLS_BAD_PROGRAM_DATE_TIME')
            try:
                import datetime
                pending_clock=int(datetime.datetime.fromisoformat(value.replace('Z','+00:00')).timestamp()*1000)
            except (ValueError,OverflowError):raise ValueError('HLS_BAD_PROGRAM_DATE_TIME')
            if abs(pending_clock)>9007199254740991:raise ValueError('HLS_BAD_PROGRAM_DATE_TIME')
        elif line.startswith('#EXT-X-KEY:'):
            a = hls_attrs(line[11:])
            if not a.get('METHOD'): raise ValueError('HLS_BAD_KEY')
            if a['METHOD'] == 'NONE':
                encrypted = False; key_uri = key_iv = None
            elif a['METHOD'] == 'AES-128' and allow_aes128:
                encrypted = True
                if not a.get('URI'): raise ValueError('HLS_BAD_KEY')
                if a.get('IV') and not re.fullmatch(r'0[xX][0-9a-fA-F]{32}', a['IV']):
                    raise ValueError('HLS_BAD_KEY_IV')
                key_uri = a.get('URI'); key_iv = a.get('IV')
            elif a['METHOD'].startswith('SAMPLE-AES'):
                # v2.37.0(N-02): explicit classification instead of generic rejection
                raise ValueError('HLS_SAMPLE_AES_UNSUPPORTED')
            elif allow_aes128:
                # v2.37.0(N-02): unknown methods must not silently pass unencrypted
                raise ValueError('HLS_BAD_KEY')
            else:
                encrypted = True
        elif line.startswith('#EXT-X-MAP:'):
            if encrypted and allow_aes128: raise ValueError('HLS_ENCRYPTED_MAP_UNSUPPORTED')
            if encrypted: raise ValueError('HLS_ENCRYPTED_UNSUPPORTED')
            a = hls_attrs(line[11:])
            if not a.get('URI'): raise ValueError('HLS_BAD_MAP')
            plain_map = hls_url(a['URI'], base, False)
            uri = hls_url(a['URI'], base, True) if inherit_query else plain_map
            if inherit_query and uri != plain_map:
                query_inherited += 1
            new_map = {'uri': uri, 'range': hls_range(a.get('BYTERANGE'), None, uri, True)}
            map_decls += 1
            if init is not None and init != new_map:
                map_switches += 1
                if not disc_since_seg:
                    map_switch_no_disc += 1
            init = new_map
        elif line.startswith('#EXT-X-BYTERANGE:'):
            if br is not None: raise ValueError('HLS_BAD_RANGE')
            br = line[17:]
        elif line == '#EXT-X-GAP': gap = True
        elif line == '#EXT-X-ENDLIST':
            if end: raise ValueError('HLS_DUPLICATE_ENDLIST')
            end = True
        elif line and not line.startswith('#'):
            if end: raise ValueError('HLS_SEGMENT_AFTER_ENDLIST')
            if encrypted and not allow_aes128: raise ValueError('HLS_ENCRYPTED_UNSUPPORTED')
            if len(segments) >= 4096: raise ValueError('HLS_SEGMENT_LIMIT')
            if mode == 'rfc' and pending_duration is None: raise ValueError('HLS_EXTINF_REQUIRED')
            plain_uri = hls_url(line, base, False)
            uri = hls_url(line, base, True) if inherit_query else plain_uri
            if inherit_query and uri != plain_uri:
                query_inherited += 1
            item = {'uri':uri, 'range':hls_range(br,previous,uri), 'map':init, 'gap':gap, 'sequence':seq+len(segments), 'discontinuity':disc, 'duration':pending_duration, 'programDateTimeMs':pending_clock}
            # v2.37.0(N-02): AES-128 key/IV assignment rides on each segment descriptor
            if key_uri is not None:
                item['keyUri'] = hls_url(key_uri, base, bool(inherit_query))
                item['keyIvHex'] = key_iv
            if max(item['sequence'],disc)>9007199254740991: raise ValueError('HLS_BAD_INTEGER')
            segments.append(item);previous=item;br=None;gap=False;pending_duration=pending_clock=None
            disc_since_seg = False
    if br is not None: raise ValueError('HLS_DANGLING_RANGE')
    if pending_duration is not None or pending_clock is not None or gap: raise ValueError('HLS_DANGLING_TAG')
    if not target: raise ValueError('HLS_BAD_TARGET')
    if any(x['duration'] is not None and int(x['duration']+0.5)>target for x in segments): raise ValueError('HLS_DURATION_OVER_TARGET')
    return {'sequence':seq,'target':target,'endList':end,'segments':segments,
            'queryInherited':query_inherited,
            'fmp4':{'mapDeclarations':map_decls,'mapSwitches':map_switches,
                    'mapSwitchesWithoutDiscontinuity':map_switch_no_disc},
            'llhls':{'indicatorTags':llhls_tags}}

def hls_timing_evidence(parsed, tolerance_ms=500):
    # Wall clock statements in M3U8 are diagnostic, not decoded presentation timestamps.
    result=dict(provenance='manifest_declared_only',segments=len(parsed['segments']),explicitAnchors=0,checkedIntervals=0,suspectedGapIntervals=0,suspectedOverlapIntervals=0,maxAbsDeviationMs=0,unmeasuredIntervals=0,missingExtinf=0,declaredGaps=0,discontinuityBoundaries=0)
    anchor=None;elapsed=0;complete=False;previous_disc=None
    for d in parsed['segments']:
        if d.get('duration') is None:result['missingExtinf']+=1
        if d['gap']:result['declaredGaps']+=1
        if previous_disc is not None and previous_disc!=d['discontinuity']:
            result['discontinuityBoundaries']+=1;anchor=None;complete=False;elapsed=0
        previous_disc=d['discontinuity']
        if d.get('programDateTimeMs') is not None:
            result['explicitAnchors']+=1
            if anchor is not None:
                if complete:
                    delta=d['programDateTimeMs']-(anchor+elapsed)
                    result['checkedIntervals']+=1
                    result['maxAbsDeviationMs']=max(result['maxAbsDeviationMs'],abs(delta))
                    if delta>tolerance_ms:result['suspectedGapIntervals']+=1
                    elif delta< -tolerance_ms:result['suspectedOverlapIntervals']+=1
                else:result['unmeasuredIntervals']+=1
            anchor=d['programDateTimeMs'];elapsed=0;complete=True
        if anchor is not None:
            if d.get('duration') is None:complete=False
            else:elapsed+=d['duration']*1000
    return result

def hls_enqueue(owner, parsed, base, audio=False, skip=False):
    # v2.5.0: playlist generation recovery. Each poll is classified with evidence
    # before any queue mutation:
    #   initial  — first playlist for this context
    #   progress — normal forward window (or no-change poll)
    #   stale    — sequence rewound AND every segment path was already recorded in
    #              this context: a re-served old playlist. Nothing is re-enqueued and
    #              the epoch is NOT advanced, so already-written media is never
    #              duplicated into a new part.
    #   reset    — sequence rewound with at least one unknown path: a legitimate new
    #              generation (new live session). Epoch advances; known paths are
    #              still filtered out because live segment objects are immutable.
    #   rotation — sequence numbers collide with already-seen keys while every path
    #              is new: an encoder restart reusing sequence numbers. Treated as a
    #              new generation instead of silently dropping the new media.
    #   context  — playlist origin/path changed: new source, cache reset.
    # Old segments are never deleted on a guess; the only skipping rule is
    # "this exact immutable data was already recorded in this context".
    pre = 'a_' if audio else ''
    state = getattr(owner, '_hls_'+pre+'state', {})
    u = urllib.parse.urlsplit(base);context = (u.scheme,u.netloc,u.path)
    uris = state.get('uris')
    if uris is None:
        uris = {}
    keys = [hls_uri_key(d) for d in parsed['segments']]
    known_n = sum(1 for k in keys if k in uris)
    has_first = 'first' in state
    rewind = has_first and parsed['sequence'] < state['first']
    same_context = state.get('context') == context
    kind = 'progress'
    if not has_first or state.get('context') is None:
        kind = 'initial'
    elif not same_context:
        kind = 'context'
    elif rewind and keys:
        kind = 'stale' if known_n == len(keys) else 'reset'
    fresh = kind in ('initial','context','reset')
    epoch = state.get('epoch',0) + int(fresh)
    seen, queue = getattr(owner,pre+'seen'), getattr(owner,pre+'queue')
    def key(d): return (epoch,d['discontinuity'],d['sequence'],json.dumps(d['range'],sort_keys=True))
    unseen = [d for d in parsed['segments'] if key(d) not in seen]
    if kind == 'progress' and has_first and same_context and not unseen and keys and known_n == 0:
        # Same sequence numbers already recorded but every path is new — the encoder
        # restarted and reused sequence numbers. Without this the new media would be
        # silently dropped as "already seen".
        kind = 'rotation'; fresh = True; epoch = state.get('epoch',0) + 1
        unseen = [d for d in parsed['segments'] if key(d) not in seen]
    if uris:
        # Immutable-path filter: never re-record data already captured (this session
        # or restored from --segindex) — applies to progress, stale, reset and rotation
        # alike. Signature query changes and stale re-serves cannot duplicate media.
        unseen = [d for d in unseen if hls_uri_key(d) not in uris]
    incoming = [] if skip else [d for d in unseen if not d['gap']]
    if len(queue)+len(incoming)>4096: raise ValueError('HLS_QUEUE_LIMIT')
    timing = hls_timing_evidence(parsed)
    missing = max(0,parsed['sequence']-state.get('last',parsed['sequence'])-1) if not fresh else 0
    for d in unseen:
        seen.add(key(d));missing += int(d['gap'] and not skip)
    for k in keys:
        uris[k] = True
    if len(uris) > HLS_URI_CACHE_MAX:
        for k in list(uris)[:len(uris)-HLS_URI_CACHE_MAX]:
            del uris[k]
    queue.extend({'name':d['uri'],'base':'','tries':0,'hls':dict(d,epoch=epoch)} for d in incoming)
    rec = state.get('recovery')
    if rec is None:
        rec = {'staleResponses':0,'suspectedResets':0,'sequenceResets':0,'uriRotations':0,'contextSwitches':0,'lastKind':kind,'lastSequence':None}
    if kind == 'stale': rec['staleResponses'] += 1
    elif kind == 'reset': rec['sequenceResets'] += 1
    elif kind == 'rotation': rec['uriRotations'] += 1
    elif kind == 'context': rec['contextSwitches'] += 1
    rec['lastKind'] = kind; rec['lastSequence'] = parsed['sequence'] if keys else None
    # v2.6.0(P1/P2): fMP4 MAP宣言とLL-HLS指標タグの証拠を文脈単位で累積
    fmp4_ev = state.get('fmp4')
    if fmp4_ev is None:
        fmp4_ev = {'mapDeclarations':0,'mapSwitches':0,'mapSwitchesWithoutDiscontinuity':0,
                   'crossPollMapSwitches':0,'crossPollMapSwitchesWithoutDiscontinuity':0}
    _f = parsed.get('fmp4') or {}
    for _k in ('mapDeclarations','mapSwitches','mapSwitchesWithoutDiscontinuity'):
        fmp4_ev[_k] = int(fmp4_ev.get(_k) or 0) + int(_f.get(_k) or 0)
    # v2.6.0(P1): poll間のMAP切替(同一世代の継続中に初期化セグメントが変わった)。
    # playlist内で切替が見える場合は上の宣言計数、別playlistにまたがる場合はここで計上。
    if kind == 'progress' and keys:
        _first = parsed['segments'][0]
        _mk = json.dumps(_first['map'], sort_keys=True) if _first['map'] is not None else None
        _prev = state.get('ev_map_key')
        if _mk is not None and _prev is not None and _mk != _prev:
            fmp4_ev['crossPollMapSwitches'] = int(fmp4_ev['crossPollMapSwitches'] or 0) + 1
            if _first['discontinuity'] == state.get('ev_map_disc'):
                fmp4_ev['crossPollMapSwitchesWithoutDiscontinuity'] = int(fmp4_ev['crossPollMapSwitchesWithoutDiscontinuity'] or 0) + 1
    if keys:
        _last = parsed['segments'][-1]
        state['ev_map_key'] = json.dumps(_last['map'], sort_keys=True) if _last['map'] is not None else None
        state['ev_map_disc'] = _last['discontinuity']
    state['fmp4'] = fmp4_ev
    state['llhlsIndicators'] = int(state.get('llhlsIndicators') or 0) + int((parsed.get('llhls') or {}).get('indicatorTags') or 0)
    q_inh = int(parsed.get('queryInherited') or 0)
    state['queryInherited'] = int(state.get('queryInherited') or 0) + q_inh
    if not audio:
        owner._hls_query_inherited = getattr(owner, '_hls_query_inherited', 0) + q_inh
    # 'first' follows the incoming window start except for stale re-serves, where
    # keeping the higher watermark lets repeated stale responses stay detectable.
    new_first = state['first'] if (kind == 'stale' and has_first) else parsed['sequence']
    state.update(context=context,epoch=epoch,first=new_first,uris=uris,recovery=rec)
    if parsed['segments']:state['last']=parsed['segments'][-1]['sequence'] if fresh else max(state.get('last',0),parsed['segments'][-1]['sequence'])
    setattr(owner,'_hls_'+pre+'state',state)
    setattr(owner,'_hls_'+pre+'timing',timing)
    setattr(owner,'_hls_'+pre+'recovery',rec)
    if len(seen)>30000:
        # Ordered sequence identity, never evict queued work.
        recent = sorted(seen,key=lambda k:(k[0],k[2]))[-12000:];seen.clear();seen.update(recent)
    return len(incoming),missing

def hls_strip_disguised_ts(data):
    """v2.12.0(C-01): cat-catch "数据预处理" (TS image/header disguise stripping).
    先頭にPNG/GIF/BMP/JPEG/WEBP/ID3ヘッダが偽装付与されたMPEG-TSセグメントから
    188バイト境界の0x47同期バイト列を検出して先頭偽装バイトを除去する。
    既知の偽装ヘッダ以外の任意破損データは除去せずHLS_BAD_TSで拒否する(fail-closed維持)。"""
    if not data:
        return data, 0, None
    magic = None
    if data.startswith(b'\x89PNG\r\n\x1a\n'):
        magic = 'png'
    elif data.startswith((b'GIF87a', b'GIF89a')):
        magic = 'gif'
    elif data.startswith(b'BM'):
        magic = 'bmp'
    elif data.startswith(b'\xff\xd8\xff'):
        magic = 'jpeg'
    elif len(data) >= 12 and data[:4] == b'RIFF' and data[8:12] == b'WEBP':
        magic = 'webp'
    elif data.startswith(b'ID3'):
        magic = 'id3'
    if not magic:
        return data, 0, None
    max_scan = min(len(data) - 188, 4096)
    for off in range(1, max_scan + 1):
        if data[off] == 0x47 and (len(data) - off) % 188 == 0:
            if all(data[i] == 0x47 for i in range(off + 188, len(data), 188)):
                return data[off:], off, magic
    return data, 0, magic

def hls_validate(data, kind):
    if not data: raise ValueError('HLS_EMPTY_BODY')
    if kind == 'ts':
        if len(data) % 188 or data[0] != 0x47:
            clean, stripped, _magic = hls_strip_disguised_ts(data)
            if stripped > 0:
                data = clean
        if len(data)%188 or any(data[i]!=0x47 for i in range(0,len(data),188)): raise ValueError('HLS_BAD_TS')
    else:
        at=0;boxes=[]
        while at<len(data):
            if len(data)-at<8: raise ValueError('HLS_BAD_MP4')
            size=int.from_bytes(data[at:at+4],'big');header=8
            if size==1:
                if len(data)-at<16: raise ValueError('HLS_BAD_MP4')
                size=int.from_bytes(data[at+8:at+16],'big');header=16
            elif size==0: size=len(data)-at
            if size<header or at+size>len(data): raise ValueError('HLS_BAD_MP4')
            boxes.append(data[at+4:at+8]);at+=size
        required = (b'ftyp',b'moov') if kind=='init' else (b'moof',b'mdat')
        if not all(b in boxes for b in required): raise ValueError('HLS_BAD_'+kind.upper())
    return data

def hls_request(owner, descriptor, limit=HLS_LIMIT):
    headers={'User-Agent':owner.ua,'Accept-Encoding':'identity'}
    br=descriptor.get('range')
    if br: headers['Range']='bytes=%d-%d'%(br['offset'],br['offset']+br['length']-1)
    try:
        with urllib.request.urlopen(urllib.request.Request(descriptor['uri'],headers=headers),timeout=SEG_TIMEOUT_S) as r:
            if (br and r.status!=206) or (not br and r.status!=200): raise ValueError('HLS_RANGE_STATUS')
            if r.headers.get('Content-Encoding','identity').lower()!='identity': raise ValueError('HLS_ENCODING_UNSUPPORTED')
            if br:
                m=re.fullmatch(r'bytes ([0-9]+)-([0-9]+)/([0-9]+|\*)',r.headers.get('Content-Range',''))
                if not m or int(m[1])!=br['offset'] or int(m[2])!=br['offset']+br['length']-1 or (m[3]!='*' and int(m[3])<=int(m[2])): raise ValueError('HLS_CONTENT_RANGE')
            cl=r.headers.get('Content-Length')
            if cl is not None and (not cl.isascii() or not cl.isdigit() or int(cl)>limit): raise ValueError('HLS_BODY_LIMIT')
            chunks=[];size=0;deadline=time.monotonic()+SEG_TIMEOUT_S
            while True:
                if time.monotonic()>deadline: raise TimeoutError('HLS_TIMEOUT')
                chunk=r.read1(min(65536,limit+1-size))
                if not chunk: break
                size+=len(chunk)
                if size>limit or (br and size>br['length']): raise ValueError('HLS_BODY_LIMIT')
                chunks.append(chunk)
            if cl is not None and size!=int(cl): raise ValueError('HLS_BODY_LENGTH')
            if br and size!=br['length']: raise ValueError('HLS_RANGE_LENGTH')
            return r.status,b''.join(chunks),0
    except urllib.error.HTTPError as e:
        status,ra=e.code,retry_after_ms(e.headers.get('Retry-After'))
        e.close();return status,None,ra

# ------------------------------------------------------------------ v2.37.0(N-01/N-02): AES-128-CBC
def hls_remove_pkcs7(data):
    """PKCS7(RFC 5652 6.3)厳密検証付き除去。WebCrypto/opensslの成功時セマンティクスと
    同一に揃える(不正パディングはfail-closed)。"""
    if not data: raise ValueError('HLS_DECRYPT_PADDING')
    n = data[-1]
    if not 1 <= n <= 16 or n > len(data): raise ValueError('HLS_DECRYPT_PADDING')
    if any(b != n for b in data[-n:]): raise ValueError('HLS_DECRYPT_PADDING')
    return data[:-n]

_OPENSSL_BIN = None
_OPENSSL_CHECKED = False

def hls_openssl_bin():
    """openssl実ファイルの有無を一度だけ確認しキャッシュする(任意高速バックエンド)。"""
    global _OPENSSL_BIN, _OPENSSL_CHECKED
    if not _OPENSSL_CHECKED:
        _OPENSSL_CHECKED = True
        import shutil
        _OPENSSL_BIN = shutil.which('openssl')
    return _OPENSSL_BIN

def hls_aes128_cbc_decrypt(key, iv, data, backend='auto'):
    """AES-128-CBC復号(HLSセグメント1本分)。PKCS7厳密検証。
    backend='auto': openssl(サブプロセス・数百MB/s)があれば優先、無ければ純Python。
    backend='python': 純Python実装(~0.3-1MB/s・正確性はNIST KATとJS/opensslとクロス検証)。
    どちらのバックエンドもAES-CBCの決定性によりバイト一致する(試験で常時検証)。"""
    if not isinstance(key, (bytes, bytearray)) or len(key) != 16: raise ValueError('HLS_DECRYPT_KEY')
    if not isinstance(iv, (bytes, bytearray)) or len(iv) != 16: raise ValueError('HLS_DECRYPT_IV')
    if not data or len(data) % 16: raise ValueError('HLS_DECRYPT_BLOCK_SIZE')
    if backend in ('auto', 'openssl') and hls_openssl_bin():
        try:
            import subprocess
            p = subprocess.run([hls_openssl_bin(), 'enc', '-d', '-aes-128-cbc', '-nopad',
                                '-K', key.hex(), '-iv', iv.hex()],
                               input=bytes(data), capture_output=True, timeout=120)
            if p.returncode == 0 and len(p.stdout) == len(data):
                return hls_remove_pkcs7(p.stdout)
            raise ValueError('HLS_DECRYPT_TOOL_FAILED')
        except (OSError, subprocess.TimeoutExpired):
            if backend == 'openssl': raise ValueError('HLS_DECRYPT_TOOL_FAILED')
    return hls_remove_pkcs7(hls_aes128_cbc_decrypt_py(key, iv, data))

def hls_aes128_cbc_decrypt_py(key, iv, data):
    """純Python AES-128-CBC復号(cat-catch lib/m3u8-decrypt.js/hls.js AESDecryptorと同一の
    等価逆暗号をTテーブル駆動で移植。NIST SP 800-38A KATとJS実装・opensslとクロス検証)。"""
    sbox, inv_sbox, sub_mix0, sub_mix1, sub_mix2, sub_mix3, inv_sub_mix0, inv_sub_mix1, inv_sub_mix2, inv_sub_mix3 = _hls_aes_tables()
    d = _hls_aes_gf_tables()
    # 復号鍵スケジュール(等価逆暗号: ラウンド鍵にはInvMixColumnsのみ適用)
    ks = [int.from_bytes(key[i*4:i*4+4], 'big') for i in range(4)]
    rcon = [0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36]
    for i in range(4, 44):
        t = ks[i-1]
        if i % 4 == 0:
            t = ((t << 8) | (t >> 24)) & 0xffffffff
            t = (sbox[(t >> 24) & 0xff] << 24) | (sbox[(t >> 16) & 0xff] << 16) | (sbox[(t >> 8) & 0xff] << 8) | sbox[t & 0xff]
            t ^= rcon[i // 4] << 24
        ks.append((ks[i-4] ^ t) & 0xffffffff)
    iks = [0] * 44
    for r in range(44):
        ks_row = 44 - r
        t = ks[ks_row] if (r & 3) else ks[ks_row - 4]
        if r < 4 or ks_row <= 4:
            iks[r] = t
        else:
            # cat-catch/hls.jsの合成: invSubMix0[sbox[b]] == InvMixColumns(b)
            iks[r] = inv_sub_mix0[sbox[(t >> 24) & 0xff]] ^ inv_sub_mix1[sbox[(t >> 16) & 0xff]] ^ \
                     inv_sub_mix2[sbox[(t >> 8) & 0xff]] ^ inv_sub_mix3[sbox[t & 0xff]]
    i_v = int.from_bytes(iv, 'big')
    prev = i_v  # CBC: 初回ブロックはIV、以降は直前の暗文ブロックをXOR
    out = bytearray()
    for at in range(0, len(data), 16):
        block = int.from_bytes(data[at:at+16], 'big')
        iw0 = (block >> 96) & 0xffffffff; iw1 = (block >> 64) & 0xffffffff
        iw2 = (block >> 32) & 0xffffffff; iw3 = block & 0xffffffff
        # cat-catchのs-wiring: s0=iw0, s1=iw3, s2=iw2, s3=iw1
        s0 = iw0 ^ iks[0]; s1 = iw3 ^ iks[1]; s2 = iw2 ^ iks[2]; s3 = iw1 ^ iks[3]
        w = [s0, s1, s2, s3]
        for rnd in range(1, 10):
            s0, s1, s2, s3 = w
            w = [
                inv_sub_mix0[(s0 >> 24) & 0xff] ^ inv_sub_mix1[(s1 >> 16) & 0xff] ^ inv_sub_mix2[(s2 >> 8) & 0xff] ^ inv_sub_mix3[s3 & 0xff] ^ iks[rnd*4],
                inv_sub_mix0[(s1 >> 24) & 0xff] ^ inv_sub_mix1[(s2 >> 16) & 0xff] ^ inv_sub_mix2[(s3 >> 8) & 0xff] ^ inv_sub_mix3[s0 & 0xff] ^ iks[rnd*4+1],
                inv_sub_mix0[(s2 >> 24) & 0xff] ^ inv_sub_mix1[(s3 >> 16) & 0xff] ^ inv_sub_mix2[(s0 >> 8) & 0xff] ^ inv_sub_mix3[s1 & 0xff] ^ iks[rnd*4+2],
                inv_sub_mix0[(s3 >> 24) & 0xff] ^ inv_sub_mix1[(s0 >> 16) & 0xff] ^ inv_sub_mix2[(s1 >> 8) & 0xff] ^ inv_sub_mix3[s2 & 0xff] ^ iks[rnd*4+3],
            ]
        s0, s1, s2, s3 = w
        t0 = (inv_sbox[(s0 >> 24) & 0xff] << 24) ^ (inv_sbox[(s1 >> 16) & 0xff] << 16) ^ (inv_sbox[(s2 >> 8) & 0xff] << 8) ^ inv_sbox[s3 & 0xff] ^ iks[40]
        t1 = (inv_sbox[(s1 >> 24) & 0xff] << 24) ^ (inv_sbox[(s2 >> 16) & 0xff] << 16) ^ (inv_sbox[(s3 >> 8) & 0xff] << 8) ^ inv_sbox[s0 & 0xff] ^ iks[41]
        t2 = (inv_sbox[(s2 >> 24) & 0xff] << 24) ^ (inv_sbox[(s3 >> 16) & 0xff] << 16) ^ (inv_sbox[(s0 >> 8) & 0xff] << 8) ^ inv_sbox[s1 & 0xff] ^ iks[42]
        t3 = (inv_sbox[(s3 >> 24) & 0xff] << 24) ^ (inv_sbox[(s0 >> 16) & 0xff] << 16) ^ (inv_sbox[(s1 >> 8) & 0xff] << 8) ^ inv_sbox[s2 & 0xff] ^ iks[43]
        # 出力s-wiring: t0,t3,t2,t1 ^ CBC前ブロック(初回はIV)
        plain = ((t0 ^ (prev >> 96)) << 96) | ((t3 ^ ((prev >> 64) & 0xffffffff)) << 64) | \
                ((t2 ^ ((prev >> 32) & 0xffffffff)) << 32) | (t1 ^ (prev & 0xffffffff))
        out += (plain & ((1 << 128) - 1)).to_bytes(16, 'big')
        prev = block
    return bytes(out)

_AES_TABLES = None

def _hls_aes_tables():
    """cat-catch initTableと同一の導出(一度だけ生成・キャッシュ)。"""
    global _AES_TABLES
    if _AES_TABLES is not None: return _AES_TABLES
    d = _hls_aes_gf_tables()
    sbox = [0]*256; inv_sbox = [0]*256
    sub_mix0 = [0]*256; sub_mix1 = [0]*256; sub_mix2 = [0]*256; sub_mix3 = [0]*256
    inv_sub_mix0 = [0]*256; inv_sub_mix1 = [0]*256; inv_sub_mix2 = [0]*256; inv_sub_mix3 = [0]*256
    x = 0; xi = 0
    for _ in range(256):
        sx = xi ^ (xi << 1) ^ (xi << 2) ^ (xi << 3) ^ (xi << 4)
        sx = (sx >> 8) ^ (sx & 0xff) ^ 0x63
        sbox[x] = sx; inv_sbox[sx] = x
        x2 = d[x]; x4 = d[x2]; x8 = d[x4]
        t = (d[sx] * 0x101) ^ (sx * 0x1010100)
        sub_mix0[x] = ((t << 24) | (t >> 8)) & 0xffffffff
        sub_mix1[x] = ((t << 16) | (t >> 16)) & 0xffffffff
        sub_mix2[x] = ((t << 8) | (t >> 24)) & 0xffffffff
        sub_mix3[x] = t & 0xffffffff
        t = (x8 * 0x1010101) ^ (x4 * 0x10001) ^ (x2 * 0x101) ^ (x * 0x1010100)
        inv_sub_mix0[sx] = ((t << 24) | (t >> 8)) & 0xffffffff
        inv_sub_mix1[sx] = ((t << 16) | (t >> 16)) & 0xffffffff
        inv_sub_mix2[sx] = ((t << 8) | (t >> 24)) & 0xffffffff
        inv_sub_mix3[sx] = t & 0xffffffff
        if not x:
            x = xi = 1
        else:
            x = x2 ^ d[d[d[x8 ^ x2]]]
            xi ^= d[d[xi]]
    _AES_TABLES = (sbox, inv_sbox, sub_mix0, sub_mix1, sub_mix2, sub_mix3,
                   inv_sub_mix0, inv_sub_mix1, inv_sub_mix2, inv_sub_mix3)
    return _AES_TABLES

_GF_TABLES = None

def _hls_aes_gf_tables():
    global _GF_TABLES
    if _GF_TABLES is None:
        d = [ (i << 1) ^ 0x11b if i >= 128 else (i << 1) for i in range(256) ]
        _GF_TABLES = d
    return _GF_TABLES

# ------------------------------------------------------------------ v2.37.0(N-03): TS cc監査
def hls_audit_cc(data):
    """ISO/IEC 13818-1 2.4.3.2 連続性カウンタ監査(hls_transport.js auditCcと完全鏡像)。
    監査のみで非破壊: セグメント廃棄は一切行わない。"""
    seg = {'segmentsAudited':0,'bytesAudited':0,'packets':0,'pids':0,'payloadPackets':0,'noPayloadPackets':0,
           'afcReserved':0,'teiPackets':0,'continuityOk':0,'duplicates':0,'forwardJumps':0,'backwardJumps':0,
           'lostPacketEstimate':0,'maxSingleJump':0,'perPid':{},'perPidTruncated':False}
    if not data or len(data) < 188 or len(data) % 188: return seg
    seg['packets'] = len(data) // 188
    state = {}
    distinct = 0
    for at in range(0, len(data), 188):
        b1 = data[at+1]; b2 = data[at+2]; b3 = data[at+3]
        pid = ((b1 & 0x1f) << 8) | b2
        afc = (b3 >> 4) & 3
        cc = b3 & 0xf
        if b1 & 0x80: seg['teiPackets'] += 1
        st = state.get(pid)
        if st is None:
            st = state[pid] = {'lastCc': -1, 'packets':0,'payload':0,'ok':0,'dup':0,'fwd':0,'back':0,'lost':0}
            distinct += 1
        st['packets'] += 1
        if afc == 0:
            seg['afcReserved'] += 1; continue
        if afc == 2:
            seg['noPayloadPackets'] += 1; continue
        seg['payloadPackets'] += 1; st['payload'] += 1
        if st['lastCc'] < 0:
            st['lastCc'] = cc; continue
        delta = (cc - st['lastCc']) & 0xf
        if delta == 1:
            seg['continuityOk'] += 1; st['ok'] += 1
        elif delta == 0:
            seg['duplicates'] += 1; st['dup'] += 1
        elif delta < 8:
            seg['forwardJumps'] += 1; st['fwd'] += 1
            lost = delta - 1
            seg['lostPacketEstimate'] += lost; st['lost'] += lost
            if lost > seg['maxSingleJump']: seg['maxSingleJump'] = lost
        else:
            seg['backwardJumps'] += 1; st['back'] += 1
        st['lastCc'] = cc
    seg['pids'] = distinct
    for pid, st in state.items():
        seg['perPid'][pid] = {'pid':pid,'packets':st['packets'],'payload':st['payload'],'ok':st['ok'],
                              'dup':st['dup'],'fwd':st['fwd'],'back':st['back'],'lost':st['lost']}
    return seg

_CC_SUM_KEYS = ('packets','pids','payloadPackets','noPayloadPackets','afcReserved','teiPackets',
                'continuityOk','duplicates','forwardJumps','backwardJumps','lostPacketEstimate')

def hls_merge_cc(acc, seg):
    if acc is None: acc = hls_empty_cc()
    acc['segmentsAudited'] += 1
    acc['bytesAudited'] += seg['packets'] * 188
    for k in _CC_SUM_KEYS: acc[k] += seg.get(k) or 0
    if seg['maxSingleJump'] > acc['maxSingleJump']: acc['maxSingleJump'] = seg['maxSingleJump']
    for pid, s in seg['perPid'].items():
        dst = acc['perPid'].get(pid)
        if dst is None:
            dst = acc['perPid'][pid] = {'pid':pid,'packets':0,'payload':0,'ok':0,'dup':0,'fwd':0,'back':0,'lost':0}
        for k in ('packets','payload','ok','dup','fwd','back','lost'): dst[k] += s[k]
    return acc

def hls_empty_cc():
    acc = {'segmentsAudited':0,'bytesAudited':0,'perPid':{}}
    for k in _CC_SUM_KEYS: acc[k] = 0
    acc['maxSingleJump'] = 0
    return acc

def hls_cc_evidence(acc):
    if acc is None: return None
    per_pid = sorted(acc['perPid'].values(), key=lambda e: (-e['packets'], e['pid']))[:16]
    return {'segmentsAudited':acc['segmentsAudited'],'bytesAudited':acc['bytesAudited'],
            **{k: acc[k] for k in _CC_SUM_KEYS},
            'maxSingleJump':acc['maxSingleJump'],
            'perPid':per_pid,'perPidTruncated':len(acc['perPid']) > 16}

# ------------------------------------------------------------------ v2.17.0(U-02): MPEG-2 PSI CRC-32 & multi-packet PAT/PMT audit
def mpeg2_crc32(data):
    """ISO/IEC 13818-1 MPEG-2 PSI CRC-32 (mp4_convert_core.js psiCrc と完全鏡像)。"""
    crc = 0xffffffff
    for byte in data:
        crc ^= (byte << 24) & 0xffffffff
        for _ in range(8):
            if crc & 0x80000000:
                crc = ((crc << 1) ^ 0x04c11db7) & 0xffffffff
            else:
                crc = (crc << 1) & 0xffffffff
    return crc & 0xffffffff


def hls_audit_psi(data, allow_discontinuity=False):
    """v2.17.0(U-02): MPEG-TS PSI (PAT/PMT) section reassembly and CRC-32 verification
    (mp4_convert_core.js tsPlan と完全鏡像)。"""
    if not data or len(data) % 188:
        raise ValueError('TS_ALIGNMENT')
    pmt = None
    plan = None
    program = None
    cc = {}
    pending = {}

    def process_section(pid, section):
        nonlocal pmt, plan, program
        if mpeg2_crc32(section) != 0:
            raise ValueError('TS_PSI_CRC')
        length = len(section)
        table = section[0]
        if (section[1] & 0xf0) != 0xb0 or (section[5] & 1) == 0 or section[6] != 0 or section[7] != 0:
            raise ValueError('TS_PSI_HEADER')
        if pid == 0:
            if table != 0 or length < 12 or (length - 12) % 4 != 0:
                raise ValueError('TS_PAT')
            programs = []
            for p in range(8, length - 4, 4):
                num = (section[p] << 8) | section[p + 1]
                if num:
                    programs.append({'number': num, 'pid': ((section[p + 2] & 31) << 8) | section[p + 3]})
            if len(programs) != 1 or programs[0]['pid'] in (0, 8191):
                raise ValueError('TS_MULTI_PROGRAM')
            if pmt is not None and (pmt != programs[0]['pid'] or program != programs[0]['number']):
                raise ValueError('TS_PROGRAM_CHANGE')
            pmt = programs[0]['pid']
            program = programs[0]['number']
        else:
            if table != 2 or length < 16 or program != ((section[3] << 8) | section[4]):
                raise ValueError('TS_PMT')
            streams = []
            end = length - 4
            descriptors = ((section[10] & 15) << 8) | section[11]
            p = 12 + descriptors
            if p > end:
                raise ValueError('TS_PMT')
            while p < end:
                if p + 5 > end:
                    raise ValueError('TS_PMT')
                stype = section[p]
                sid = ((section[p + 1] & 31) << 8) | section[p + 2]
                sz = ((section[p + 3] & 15) << 8) | section[p + 4]
                if stype not in (0x1b, 0x0f, 0x15):
                    raise ValueError('TS_CODEC_UNSUPPORTED')
                if stype != 0x15:
                    streams.append([stype, sid])
                p += 5 + sz
                if p > end:
                    raise ValueError('TS_PMT')
            if len([s for s in streams if s[0] == 0x1b]) != 1 or len([s for s in streams if s[0] == 0x0f]) > 1:
                raise ValueError('TS_TRACKS_UNSUPPORTED')
            if len({s[1] for s in streams}) != len(streams):
                raise ValueError('TS_TRACKS_UNSUPPORTED')
            streams.sort(key=lambda x: x[0])
            next_sig = json.dumps(streams, separators=(',', ':'))
            if plan and next_sig != plan['signature']:
                raise ValueError('TS_TRACK_CHANGE')
            v_pid = [s[1] for s in streams if s[0] == 0x1b][0]
            a_list = [s[1] for s in streams if s[0] == 0x0f]
            a_pid = a_list[0] if a_list else -1
            plan = {
                'signature': next_sig,
                'audio': any(s[0] == 0x0f for s in streams),
                'videoPid': v_pid,
                'audioPid': a_pid,
                'pmtPid': pmt,
                'program': program
            }

    def add_section_bytes(pid, chunk):
        buf = bytearray(pending.get(pid, b''))
        pos = 0
        while pos < len(chunk):
            if not buf and chunk[pos] == 0xff:
                if any(b != 0xff for b in chunk[pos:]):
                    raise ValueError('TS_PSI_STUFFING')
                break
            if len(buf) < 3:
                n = min(3 - len(buf), len(chunk) - pos)
                buf.extend(chunk[pos:pos + n])
                pos += n
                if len(buf) < 3:
                    break
            section_length = ((buf[1] & 15) << 8) | buf[2]
            total = 3 + section_length
            if section_length > 1021 or total < 12:
                raise ValueError('TS_PSI_LENGTH')
            n = min(total - len(buf), len(chunk) - pos)
            if n:
                buf.extend(chunk[pos:pos + n])
                pos += n
            if len(buf) == total:
                process_section(pid, bytes(buf))
                buf = bytearray()
        pending[pid] = bytes(buf)

    for at in range(0, len(data), 188):
        if data[at] != 0x47 or (data[at + 1] & 0x80) or (data[at + 3] & 0xc0):
            raise ValueError('TS_INVALID_OR_SCRAMBLED')
        pid = ((data[at + 1] & 31) << 8) | data[at + 2]
        control = (data[at + 3] >> 4) & 3
        if not control:
            raise ValueError('TS_ADAPTATION')
        payload = at + 4
        disc = False
        if control & 2:
            alen = data[payload]
            if payload + 1 + alen > at + 188:
                raise ValueError('TS_ADAPTATION')
            if alen and (data[payload + 1] & 0x80):
                if not allow_discontinuity:
                    raise ValueError('TS_DISCONTINUITY')
                disc = True
            payload += 1 + alen
        if not (control & 1) or pid == 8191:
            continue
        counter = data[at + 3] & 15
        if not disc and pid in cc and counter != ((cc[pid] + 1) & 15):
            raise ValueError('TS_PACKET_GAP')
        cc[pid] = counter
        if pid != 0 and pid != pmt:
            continue
        if payload >= at + 188:
            continue
        fragment = data[payload:at + 188]
        if data[at + 1] & 0x40:
            pointer = fragment[0]
            if 1 + pointer > len(fragment):
                raise ValueError('TS_PSI_POINTER')
            prefix = fragment[1:1 + pointer]
            buf = pending.get(pid, b'')
            if buf:
                if not prefix:
                    raise ValueError('TS_PSI_INCOMPLETE')
                add_section_bytes(pid, prefix)
                if pending.get(pid, b''):
                    raise ValueError('TS_PSI_INCOMPLETE')
            elif prefix and any(x != 0xff for x in prefix):
                raise ValueError('TS_PSI_POINTER')
            add_section_bytes(pid, fragment[1 + pointer:])
        elif pending.get(pid, b''):
            add_section_bytes(pid, fragment)

    if not plan:
        raise ValueError('TS_PMT_REQUIRED')
    for buf in pending.values():
        if buf:
            raise ValueError('TS_PSI_INCOMPLETE')
    return plan


# ------------------------------------------------------------------ v2.17.0(U-04): WebVTT validation & merge
_WEBVTT_TIMING_RE = re.compile(r'^(?:(?:\d{2,}:)?\d{2}:\d{2}\.\d{3})\s+-->\s+(?:(?:\d{2,}:)?\d{2}:\d{2}\.\d{3})(?:[ \t].*)?$')


def hls_validate_webvtt(text):
    """v2.17.0(U-04): WebVTT subtitle segment validation (hls_transport.js validateWebVtt と完全鏡像)。"""
    if not isinstance(text, str):
        raise ValueError('WEBVTT_HEADER')
    clean = text.lstrip('\ufeff').replace('\r\n', '\n').replace('\r', '\n')
    blocks = re.split(r'\n{2,}', clean)
    header = (blocks[0] if blocks else '').strip()
    if not re.match(r'^WEBVTT(?:[ \t\n]|$)', header):
        raise ValueError('WEBVTT_HEADER')
    timestamp_map = None
    for line in header.split('\n')[1:]:
        if line.startswith('X-TIMESTAMP-MAP='):
            timestamp_map = line[16:].strip()
    cues = []
    for raw in blocks[1:]:
        raw = raw.strip()
        if not raw or raw.startswith(('NOTE', 'STYLE', 'REGION')):
            continue
        lines = raw.split('\n')
        timing_idx = -1
        cue_id = None
        if _WEBVTT_TIMING_RE.match(lines[0]):
            timing_idx = 0
        elif len(lines) >= 2 and _WEBVTT_TIMING_RE.match(lines[1]):
            cue_id = lines[0]
            timing_idx = 1
        if timing_idx < 0:
            raise ValueError('WEBVTT_BAD_CUE')
        timing = lines[timing_idx].strip()
        payload = '\n'.join(lines[timing_idx + 1:]).strip()
        if not payload:
            continue
        cues.append({'id': cue_id, 'timing': timing, 'payload': payload})
    return {'valid': True, 'timestampMap': timestamp_map, 'cues': cues}


def hls_merge_webvtt_segments(segments):
    """v2.17.0(U-04): Deduplicating multi-segment WebVTT cue merge (hls_transport.js mergeWebVttSegments と完全鏡像)。"""
    if not isinstance(segments, list) or not segments:
        raise ValueError('WEBVTT_EMPTY')
    seen = set()
    merged = []
    duplicates_removed = 0
    timestamp_map = None
    for seg in segments:
        v = hls_validate_webvtt(seg)
        if timestamp_map is None and v['timestampMap']:
            timestamp_map = v['timestampMap']
        for cue in v['cues']:
            key = cue['timing'] + '\n' + cue['payload']
            if key in seen:
                duplicates_removed += 1
                continue
            seen.add(key)
            merged.append(cue)
    head = ('WEBVTT\nX-TIMESTAMP-MAP=' + timestamp_map) if timestamp_map else 'WEBVTT'
    body = '\n\n'.join(((c['id'] + '\n') if c['id'] else '') + c['timing'] + '\n' + c['payload'] for c in merged)
    text = (head + '\n\n' + body + '\n') if body else (head + '\n')
    return {
        'segmentsProcessed': len(segments),
        'cuesMerged': len(merged),
        'duplicatesRemoved': duplicates_removed,
        'timestampMap': timestamp_map,
        'text': text
    }
