# QA Report — RPLAY Stable Player v2.45.0 (UNIFIED CANDIDATE)

- **Version**: `2.45.0`
- **Status**: `CANDIDATE_NO_GO` (local automated Node + Python + FFmpeg/ffprobe E2E verification passed; real RPLAY live stream, real Windows environment, and long-hour browser endurance remain untested)
- **Date (JST)**: `2026-10-27`
- **Shared Core SHA-256**: `71d0ac98f157032710fec8cd4a1bc619f3ee385c8173aaffb6998a71bcbb5bce` (5 copies byte-identical across `src/player.user.js`, `rplay-stable-player.user.js`, Chrome/Firefox `content.js`, and Chrome/Firefox `offscreen.js`)
- **Automated Test Counts**: **978 / 978 PASS** (**805 Node.js tests** + **173 Python unittest tests**)

## 1. Key Improvements in v2.45.0

1. **Priority #2 — Crash-Resilient `parts[]` & Checkpoint Receipt Persistence (`src/part_io.js`, `src/player.user.js`)**:
   - Added `recSanitizePersistedParts(list)` in `src/part_io.js` to validate and sanitize up to 128 completed part entries (`file`, `ext`, `bytes`, `segments`, `startedAt`, `endedAt`, `saveState`, `hashState`, `sha256`, `ledgerStatus`, `structureValidated`, `stages`, `partIntegrity`) with zero URLs/secrets and a 48 KiB serialized size bound.
   - Updated `Recorder.persistSession()` (schema `v: 2`) and `Recorder.closePart()` / `AudioRecorder.closePart()` so completed parts and their checkpoint receipts are immediately persisted to `REC_SESSION_KEY` (`rsp_rec_session`).
   - Updated `Recorder.resumeFromCrash(s)` to restore `partsLog`, `_joinParts`, `filesSaved`, and `audio.partsLog` from the persisted session so pre-crash parts are never lost from the final `_info.json` or `_join_*.json`.
   - Updated `loadSavedSession(id)` to accept both schema `v: 1` and `v: 2`.
2. **Priority #4 — Explicit Post-Save Media Audit (`--audit-files`) & Two-Track Audio Mux (`--mux-audio`)**:
   - Added `--audit-files FILE [FILE ...]` to `src/cli.py` (`rplay_dl.py`) to run `qaudit_part` (ffprobe PTS/DTS monotonicity + full ffmpeg decode) and `qaudit_av_correlation` directly on saved local files without requiring a live stream or creator OID.
   - Added `--mux-audio` (`mux_audio=True`) to `src/join_parts.py` (`rplay_join.py`) to concatenate and mux separate `audioRendition.parts` alongside video `parts` into a single 2-track MP4 (`-map 0:v:0 -map 1:a:0 -c copy`) verified by full decode, while keeping the default `mux_audio=False` fail-closed (`JOIN_SEPARATE_AUDIO_REQUIRES_MUX`).
3. **Cross-Language Python CLI Resilience Parity (`src/hls_transport.py`, `src/cli.py`)**:
   - Brought `src/cli.py` (`rplay_dl.py`) to full parity with the `v2.44.0` JS resilience improvements:
     - Active-stream transient playlist parse grace (`REC_TRANSIENT_PARSE_ERRORS` up to 2 consecutive polls when `seg_total > 0` / `a_seg_total > 0`).
     - Active-stream single HTTP 404 grace on the audio playlist (`a_c404 < 2`).
     - FIFO head-of-line retry for transient segment transfer truncation (`REC_TRANSIENT_TRANSFER_ERRORS`: `HLS_BODY_LENGTH`, `HLS_RANGE_LENGTH`, `HLS_EMPTY_BODY`).
     - Exposed `playlistParseGraceEvidence` and `segmentTransferRetryEvidence` in `save_info()`.

## 2. Verification Summary

- `python3 scripts/build.py`: PASS (`shared_core_sha256`: `71d0ac98f157032710fec8cd4a1bc619f3ee385c8173aaffb6998a71bcbb5bce`)
- `python3 scripts/validate.py --output-dir /tmp/v245_ev`: PASS (`805` Node tests + `173` Python tests = `978` total tests PASS)
- `python3 tests/check_request_context_http.py`: PASS
- `python3 tests/check_cdn404_decode.py`: PASS
- `node tests/check_recording_during_scan.cjs`: PASS (`2 / 2` subtests)
