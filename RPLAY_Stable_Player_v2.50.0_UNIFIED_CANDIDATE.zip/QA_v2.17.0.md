# QA v2.17.0 — 統合・MP4ストリーミング強化

2026-10-26 JST / CANDIDATE_NO_GO。

## 実行結果

- **451件 PASS / 0 FAIL**。Node.js 289、Python 162。前回統合版の記録424件から27件増加（音声時刻版から7件、新規stream15件、UI5件）。
- 両manifest、JS構文、5つの録画コア、再ビルドのランタイムバイト一致を確認。
- MP4・復旧・SHA関連7モジュールについて、src→root/Chrome/Firefoxの21コピーを直接バイト照合。
- 証拠: evidence/v217-current/VALIDATION.json、node.log、python.log。旧evidenceは各版の履歴。

## MP4検証の実体

| 対象 | 結果と限界 |
|---|---|
| 通常TS・HLS複数ファイル | FFmpeg生成H.264/AAC、ADTSバイト一致・映像framemd5一致・FFmpeg decode成功 |
| 音声先頭と開始原点 | ultrafast 4秒/8秒、先頭AAC含む全ADTS一致、MP4開始0付近・長さ差0.2秒以内 |
| 小さいGOP分割 | 8秒入力を7個以上のチャンクで変換し、音声・映像一致 |
| 64MiB超 | 実65MiB入力、1MiB以下のslice、全体arrayBuffer禁止、音声・映像一致。短いTSにnullパケットを付加した容量試験 |
| 時刻折返し | 95440秒のoffsetから始まる8秒素材で33bit境界を通過、全音声・映像一致、長さ約8秒。26時間連続運転の試験ではない |
| 保持上限 | 次キーフレームのない入力が32MiB上限を超え、明示エラー・writer.abort、以前のモック出力維持 |
| 入力検査 | 不正TS/CRC/CC/後続不正ファイル/同一入力の別名/切断読込みを拒否 |
| 入力変化 | 先行検査後の同サイズPESバイト変化をSHA-256で検出し、保存確定前に中止 |
| 出力異常 | 書込み失敗、中止、同サイズ読戻し破損を拒否。確定後の破損検出は自動復元しない |
| UI | 自然順・非対応API・検査中中止・ピッカー取消・失敗表示、5件のDOM/APIモック |

## 未実施と残課題

ローカルChromium実行体はなく、実ブラウザの今回の検証は未実施。旧AUDIO_TIMELINE版のChromium記録を今回の実績に加算していません。Windows、実OSピッカー・保存API、実拡張導入、RPLAY、長時間録画/変換、2GiB実メディアは未確認。2GiBは設定上の入力上限です。

任意の破損PES/NAL/AACの完全検出・復旧、別音声同期、録画中MP4直接出力、DRM、一般的なMP4プレイヤー互換性は保証していません。詳細はMP4_GUIDE_v2.17.0.md、受入はACCEPTANCE.md A25。
