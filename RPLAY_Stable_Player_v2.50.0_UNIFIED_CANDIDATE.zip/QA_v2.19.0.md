# v2.19.0 QA

2026-10-26 JST / CANDIDATE_NO_GO。

**500件PASS / 0 FAIL**（Node 338、Python 162）。前版476件から24件追加。5録画コア一致・再ビルドランタイム一致・7モジュール21派生コピー一致・manifest/JS構文PASS。

## 出力異常の注入

正常な4秒TSから生成したmux出力のAACを1バイト変更しました。前版では元/出力とも189フレームでconfirmed=trueでしたが、AAC圧縮データは入力と異なります。新版ではMP4_AAC_PAYLOAD_HASH_MISMATCHで確定前に拒否します。これは異常注入試験で、実サービスで自然発生した事故の記録ではありません。

同じ総バイト数のサンプル境界変更、mdat外/負offset、巨大count、不正表、余剰mdat、zero/wrong duration、flags、AVC長/ヘッダー、sdtp、track clock、sequence、1tick超の重なりも拒否。両APIのabortと未確定を確認しました。1tickだけの音声重なりは補正・記録し、AACデータhash一致を別途確認。legacy APIの同サイズ入力変化とprecommitキャンセルも検証しました。

## 合成メディアの再検証

| 条件 | 入力bytes | AACフレーム | 音声tick補正回数 | 最大補正ticks | AV開始差の変化 秒 |
|---|---:|---:|---:|---:|---:|
| 120秒 / 44100Hz / 2ch | 6,897,532 | 5,169 | 4 | 1 | -0.00002100 |
| 120秒 / 48000Hz / 1ch | 5,948,884 | 5,626 | 0 | 0 | 0.00000000 |
| 50秒 / 48000Hz / 2ch | 77,606,776 | 2,345 | 0 | 0 | 0.00000000 |

全条件で入力/出力AAC圧縮サンプルhash一致、ADTSバイト一致、映像framemd5一致、FFmpeg -xerrorデコードPASS。読込みは1MiB以下の実ディスク用Nodeアダプターです。50秒素材は12Mbps CBR H.264の320x180/25fpsで、filler NALを含む合成素材です。任意の高精細実配信の試験やピークRAM測定ではありません。

## 範囲と証拠

evidence/v219-current/VALIDATION.json、node.log、python.log、MEDIA_MATRIX.json、AAC_PAYLOAD_BEFORE_AFTER.json。旧evidenceは各記載版の履歴です。

mp4IntegrityEvidence.fullDecode=false。監査対象は同梱mux.js 6.3.0が生成する契約です。esds/avcC全意味検査や入力映像との全内容照合、AAC CRC、本番での全デコードは未実施。実RPLAY・Windows・実ブラウザ/OSファイルAPI・数時間/2GiBも未検証です。
