# TS→MP4 v2.22.0 操作・仕様

## Firefoxでの使用

1. rplay-stable-player-extension-firefox/manifest.json を一時アドオンとして読み込みます。既存版の拡張とRPLAYタブは再読み込みしてください。
2. パネルの「TSをMP4へ変換」を開き、通常のファイル選択でTSを選びます。
3. 名前順と上下ボタンで表示順を確認し「MP4へ変換」を押します。
4. 全入力の検査、Worker変換、出力のサイズ/SHA-256照合が完了したら「MP4をダウンロード」を押します。
5. 拡張画面ではブラウザの完了とサイズ一致まで表示します。ダウンロード先のSHA-256をユーザー環境で読み直す機能ではありません。
6. 一時MP4は手動で削除するまで保持されます。再読み込み後は「照合して保存」で全体SHA-256を再照合して保存できます。

ブラウザの標準ダウンロードボタンがどのフォルダへ保存するかはFirefoxの設定に従います。元TSは一切削除しません。

## 拡張を使わない方法

Windowsは open_mp4_converter.cmd を実行。Python 3が必要です。
コマンド: python3 scripts/serve_mp4.py

127.0.0.1のローカルサーバーが変換画面と必要な8アセットだけを提供します。TSを送信するHTTPアップロードはありません。
端末を開いたまま、表示されたURLをFirefoxで開きます。停止はCtrl+C。file://でのHTML直開きはWorker制限で動作しない場合があります。
通常のHTTP画面ではダウンロード完了をブラウザAPIで監視できないため、保存結果は未確認と表示します。

## 出力と復元

出力は再エンコードしないfragmented MP4。拡張/通常ページのWorkerで処理し、UIスレッドの長い同期変換を避けます。
Firefoxの直接ファイル保存APIには依存せず、File入力を読み取り専用として扱い、ランダムIDの新規OPFSジョブへ出力します。
OPFSはブラウザ内の一時領域で、通常のPC保存フォルダとは別です。ブラウザのデータ削除・容量不足・プライベート環境などで使えない/失われる場合があります。
完成後だけ、サイズ/ハッシュ/作成時刻/音声検査件数を含むschema1 receiptを保存します。復元時はファイルサイズと全体ハッシュを再検証します。
中断でreceiptがない/無効なジョブも一覧に表示し、ユーザーが明示的に削除できます。処理中ジョブはWeb Locksにより別画面からの削除を拒否します。
ダウンロード完了後にも自動削除しません。保存結果を確認して不要な一時MP4を手動削除してください。

## 保存経路

|環境|入力|出力|完了判定|
|---|---|---|---|
|Firefox拡張|通常のFile選択|OPFS→ブラウザDL|一時MP4 SHA-256＋DL完了/サイズ。実ダウンロード先hashは自動読取不可|
|FirefoxローカルHTTP|通常のFile選択|OPFS→downloadリンク|一時MP4 SHA-256。保存先完了はユーザー確認|
|直接保存APIがあるブラウザ|ネイティブhandle|指定先へWorkerで直接保存|クローズ後のサイズ/SHA-256読戻し|
|OPFS APIがない環境|通常のFile選択|上限付きメモリBlob→DL|メモリBlob照合。再読み込みで消失|

直接保存でclose後に読戻し失敗した場合、以前の出力先内容の自動復元はできません。重要な既存MP4を保存先に選ばないでください。元TSの同一handleへの上書きは拒否します。

## 制限

- H.264映像1トラックと、同じTSにあるAAC音声0/1トラック。映像のみも対応。
- 1入力2GiB、4096入力まで。今回の実Firefox最大入力は77,520,108 bytesで、2GiB境界や合計数TBを実証したものではありません。
- OPFSなしの場合は入力合計64MiB/出力128MiBまで。入力2GiBの表示上限とは別の制限です。
- 内部TSのGOP保持32MiB・MP4キュー128MiB制限は総プロセスRAMの保証ではありません。ブラウザ自身のBlob/キャッシュ等もあります。
- 同一設定・連続タイムラインのTSパートを表示順に結合します。独立配信の時刻リセット、コーデック変更、単一セットを超えるSPS/PPSは拒否される場合があります。
- PESをまたぐAACフレーム、別ファイルの音声合成、HEVC/AV1への対応やトランスコードは未実装。安全チェックを緩めずに拒否します。
- 入力のサイズ/内容変更、音声payload不一致、出力sample table/範囲/時計/codecの不整合で停止。詳細はv2.20ガイドも参照。
- プレビューはブラウザのH.264/AACデコーダーに依存します。変換・ハッシュ照合と、実際の再生/音声同期の合格は別です。

## 参考資料

https://developer.mozilla.org/en-US/docs/Web/API/File_API
https://developer.mozilla.org/en-US/docs/Web/API/File_System_API/Origin_private_file_system
https://developer.mozilla.org/en-US/docs/Web/API/FileSystemFileHandle/createSyncAccessHandle
https://bugzilla.mozilla.org/show_bug.cgi?id=1930240
https://firefox-source-docs.mozilla.org/testing/geckodriver/Usage.html

API可用性は実Firefox 158.0.1でも確認。参考資料だけで動作合格とは判定していません。
