# 配信一覧・BG録画・新旧プレイヤー最適化

## コードで確認した新旧差分

「新旧」は既存コードのBytePlus/IVS基盤と、v2.20→v2.21の動作差として扱っています。実サイトの新旧UIビルドは取得・比較できていません。

|対象|v2.20|v2.21|
|---|---|---|
|一覧取得順|公開curationが先、403でログインAPIに到達しない|ログイン済み一覧が先。成功すれば公開走査不要|
|一覧の更新|既知配信の匿名probe、ログイン一覧は再取得しない|ログイン一覧を毎更新取得し、一覧を置換|
|空一覧の自動更新|空のまま更新されない|取得済み空一覧も更新|
|レスポンス|入れ子1段、一部で配信_idを配信者IDと誤認|最大4段、明示的creatorOid/creatorのIDのみ|
|通信失敗|既知ライブも削除|前回結果を維持し通信エラーを併記|
|閉じる|走査が裏で継続|公開fetchをabort、予約要求を開始しない。進行中ログインAPIは既存timeoutまで終了待ち、結果は反映しない|
|再生源|BytePlus→旧CDN→IVS、成功probe URLがtransportへ反映されない|基盤フラグに従う現行URL→他方のURL→旧CDN、成功probeを実再生に使用|
|BG表示|件数中心|ファイル別容量/状態/トラックと配信への導線|
|パネル|外側の一覧CSS変数が未定義|一覧の配色を定義、検索/並び順/スクロール/フォーカスを追加|

限定URL・手動指定を最優先とする契約は継続。useBytePlusStream=trueならBytePlus、それ以外はplayUrlを先に試します。これは既存コードのliveBaseLabelと整合させた方針で、現行RPLAYのAPI契約を実通信で確定した主張ではありません。

## BG保存状態

最新100件を表示。直近セッションのvideo/audioパートと、永続DL台帳の最新100件を組み合わせます。
OPFS_STAGEDは一時退避で、ダウンロード完了ではありません。verifiedはブラウザの完了とサイズ一致で、デコード検証ではありません。
停止後のフォルダ保存パート一覧はBGホストのメモリ保持で、拡張プロセス終了後は消えます。DL台帳は再起動後も復元します。
権限引き継ぎ・停止操作は従来のsession/epoch制御を継続。録画は同時1配信です。

## 検索した資料と適用

- MDN Page Visibility API: https://developer.mozilla.org/en-US/docs/Web/API/Page_Visibility_API
  非表示タブではタイマーが抑制されるため、一覧の自動更新は可視時のみ。録画ホストとは別に扱う。
- MDN Background scripts: https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/Background_scripts
  Chrome offscreenとFirefox event-pageの既存経路を維持し、両routerのモック統合試験を追加。
- RPLAY公式ユーザーガイド: https://rplaylive.gitbook.io/rplay-userguide/howtouse/content
  公式メイン/LIVE/チャンネルに配信導線があることを確認。私的APIの現在のレスポンス形状や新旧プレイヤー内部仕様の裏付けには使わない。

追加の優先課題: 実APIレスポンスの秘密を除いたfixture採取、実Firefox/Chrome UI、認証切替・配信終了・権限切替を含む実配信確認。現行APIが未対応の形状なら、一覧の完全復旧はまだ断定できません。
