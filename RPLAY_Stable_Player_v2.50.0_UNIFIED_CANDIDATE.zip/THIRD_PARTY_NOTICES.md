# 同梱ライブラリ・ソースの通知

hls.min.jsとflv.min.jsはユーザー添付v2.1.0原本から無変更で継承しました。バイトの識別は`DEPENDENCIES.json`に記録しています。

- hls.js：内部版1.7.3。`licenses/hls.js-LICENSE.txt`、Apache-2.0全文を同梱。
- flv.js：内部版1.6.2。`licenses/flv.js-LICENSE.txt`を同梱。
- flv.js内es6-promise：既存の著作権コメントを保持し、`licenses/es6-promise-LICENSE.txt`を同梱。
- hls.js内regenerator-runtime：既存の著作権コメントを保持し、`licenses/regenerator-runtime-LICENSE.txt`を同梱。

取得URLとライセンスファイルのSHA-256は`licenses/SOURCES.json`。プレイヤー/CLIはユーザー提供原本の改修物です。ユーザー提供コードについて新しい第三者向け再ライセンスを付与したものではありません。外部ツールの本体を一括コピーする変更は今回行っていません。

## v2.14.0追加

mux.js 6.3.0を無変更で同梱。Apache-2.0ライセンス全文はlicenses/mux.js-LICENSE.txt。取得元・npm配布物のintegrityはlicenses/mux.js-SOURCE.json、同梱JSのSHA-256はDEPENDENCIES.json。元の著作権・ライセンスコメントを保持。

## v2.16.0追加

ソフトウェアAES-128-CBC復号器(src/hls_transport.js `decryptCbc`/`removePkcs7Padding`、
src/hls_transport.py `hls_aes128_cbc_decrypt_py`)は、cat-catch (MIT License、
 licenses/cat-catch-LICENSE.txt 参照) が同梱する lib/m3u8-decrypt.js と同一系譜の
hls.js AESDecryptor (Apache-2.0) で用いられる**公開アルゴリズム
(等価逆暗号・Tテーブル駆動)に基づく独立実装**です。アップストリームのコードを
逐語コピーしたものではありません。相違点: AES-128専用・PKCS7厳密検証(RFC 5652 §6.3)
・エラーコード分類。正確性はNIST SP 800-38A既知答・WebCrypto・opensslとの
バイト一致試験で常時検証しています(test_v2160_core.cjs / test_v2160_features.py)。
