# Cross-Site Compatibility v0.1.0 統合および改善点の検索結果 — v2.43.0

## 1. 添付5アーカイブの監査結果

| アーカイブ名 | SHA-256 | 役割・監査結果 |
|---|---|---|
| `RPLAY_Stable_Player_v2.42.0_UNIFIED_CANDIDATE.zip` | `b81b435c3991f36d91153f58d0de65c71e6cc8f8f3d9143f8e9d174bcab18aaf` | 最新主幹ベース。ただしFFmpeg 5.1系＋Node 18環境で5つのテストファイル（計12テスト）の失敗と `validate.py` の180秒タイムアウトを検出・修正 |
| `RPLAY_CrossSite_Compatibility_v0.1.0_INTEGRATION_CANDIDATE.zip` | `dea5f6f92095b298c0e500024e35653d8a127c4a4b47bec39b2406472498ccb5` | v2.42.0不在セッションで作られた単体パッチキット（7モジュール・5合成fixture・56試験）。本v2.43.0でPhase 1統合を完了 |
| `RPLAY_Stable_Player_v2.23.0_UNIFIED_CANDIDATE.zip` | `65dee4ebb9b4fa223f9828d8b66cf10d9a709abc488de1b0fdc7ac38c0b0519d` | 別系統フォーク。`normalizeInitHeaderDurations`（fMP4 `0xFFFFFFFF` 継続時間修正）、`verifyTs`、WebVTT検証/結合、Python PSI CRC監査を抽出・統合 |
| `RPLAY_Stable_Player_v2.37.0_UNIFIED_CANDIDATE.zip` | `4febd51e59f072cf370eb99e8c49e8302ba9a1410cc104156fc07d578fdd706a` | v2.39.0〜v2.42.0で統合済み（BG自動開始制御・共通JSON取得） |
| `RPLAY_Stable_Player_v2.38.0_UNIFIED_CANDIDATE.zip` | `ab753cd828c821086531820e60f303b4e8b50581b0bff1e37873ef8cdacf007f` | v2.39.0〜v2.42.0で統合済み（配信者名metadata・BG経由外部予約巡回） |

## 2. 検索・特定された改善点と修正内容

1. **[重大修正] 断片化MP4 (`moov`) の `0xFFFFFFFF` 継続時間による24.8時間誤表示バグ (`src/mp4_convert_core.js`)**:
   - **原因**: `mux.js` 6.3.0 は継続時間未指定時に `mvhd`・`tkhd`・`mdhd` の duration フィールドへ `0xFFFFFFFF` (`4294967295`) を書き込む。FFmpeg 5.1.9 (`ffprobe`) では48kHz音声トラックの `4294967295 / 48000 = 89478.485313` 秒（約24.8時間）がコンテナ全体の duration として採用され、`test_mp4_convert.cjs`, `test_v2170_stream.cjs`, `test_v2180_media.cjs` が失敗していた。
   - **改善**: `normalizeInitHeaderDurations` を統合し、初期セグメントの `mvhd` / `tkhd` / `mdhd` の `0xFFFFFFFF` を ISO/IEC 14496-12 の断片化MP4規約に従い `0` に正規化。これにより全変換テストで正確な実尺（4.02秒 / 8.00秒 / 50秒 / 120秒）が報告されることを確認。
2. **[重大修正] Node 18 / VM文脈での `crypto.randomUUID` 参照エラー (`src/media_catalog.js`)**:
   - **原因**: `media_catalog.js` の `id=()=>crypto.randomUUID()` がグローバル `crypto` のみに依存しており、Node 18 CommonJS や `vm.createContext` 経由の呼び出しで `ReferenceError: crypto is not defined` が発生し、`test_v2410_media_catalog.cjs` と `test_v2420_request_context.cjs` の計7件が失敗していた。
   - **改善**: `root.crypto.randomUUID` → `crypto.randomUUID` → `require('node:crypto').randomUUID` の安全なフォールバック関数 `defaultUuid()` を実装。
3. **[修正] ローカル変換サーバー (`scripts/serve_mp4.py`) のスクリプト404欠落と `BrokenPipeError`**:
   - **原因**: `v2.41.0` で `media_inspect.html` に `<script src="hls_transport.js">` と `<script src="media_catalog.js">` が追加された際、`scripts/serve_mp4.py` の `ALLOWED` セットが更新されておらず、ローカルサーバー経由で診断画面を開くと404になっていた。またクライアント側が早期切断した際に `BrokenPipeError` トレースバックが発生していた。
   - **改善**: `ALLOWED` に `hls_transport.js`, `media_catalog.js`, `cross_site_compat.js` を追加し、`do_GET` / `do_HEAD` で `(BrokenPipeError, ConnectionResetError)` を安全に捕捉。
4. **[機能統合・改善] Cross-Site Compatibility v0.1.0 の統合と強化 (`src/cross_site_compat.js`, `src/media_catalog.js`, `src/media_inspect_core.js`)**:
   - **親クエリ継承の改善**: `v2.42.0` の `media_catalog.manifest` は子URLにクエリが1つでもある場合（例: `720p.m3u8?quality=high`）に親クエリを一切継承しなかったが、`resolveMediaURI` 方式に統一し、「同一originかつ署名キーを持たない子URL」であれば既存の子クエリを保持したまま不足する親クエリだけをraw形式で追記するよう改善（署名済み子URLと別originは完全不変）。
   - **不正パーセントエンコード耐性とヘッダサニタイズ**: `url-policy` のクエリキー解析で不正な `%` 列があっても `URIError` でクラッシュしない `decodeKeySafe` を導入。`capture-context` でも制御文字や `user:password@` を含む不正URLヘッダを排除。
   - **サイト別視聴ページ検出とHTTP応答診断**: `RspMediaInspect.safeReport` に `siteProfile`（`niconico-video`, `niconico-live`, `youtube`, `twitch`, `rplay`, `generic`）を追加し、視聴ページURLを直接入力した際の誘導メッセージと HTTP 401/403/404/410/429/5xx 診断ノートを統合。
5. **[機能統合] 復旧時TS同期検査 (`verifyTs`)・WebVTT検証結合・検証スイートtimeout調整**:
   - `src/recovery_core.js` に `verifyTs: true` オプション、`src/hls_transport.js` / `src/hls_transport.py` に `validateWebVtt` / `mergeWebVttSegments` および `hls_audit_psi` を統合。
   - `scripts/validate.py` のサブプロセスタイムアウトを 180秒→360秒へ引き上げ、2コア環境でも全Node試験（651件）が安定完走するよう改善。
