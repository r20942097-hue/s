# RPLAY v2.42.3 QA / acceptance

Date: 2026-10-27 JST. Source: v2.42.2 candidate ZIP. Status: **CANDIDATE / NO_GO**.

- Node.js all regression: see `VALIDATION_v2.42.3.json` for exact finished run; new writer audit cases included.
- Python regression: 165/165 PASS, existing CLI unmodified.
- Writer audit new targeted: 10/10 PASS; generated-browser actual video/audio VM tests and failure injection.
- All mirrored script copies reproduced using `scripts/build.py`. Browser manifests are same v2.42.3; Firefox has no `version_name`.
- Archive integrity: SHA256SUMS.json records every included source, ZIP CRC checked on release build.

Not evidence of actual browser extension install, Nico Video/Nico Live session handshake, signed-URL renewal in real sites, DASH download, authorization bypass, 24-hour stream continuity, persisted-file integrity, or full playback/decode. No test is counted as such.

### New quality distinction

Manifest-observed, fetched, pushData-accepted, part-committed, and decoded are distinct states. In this version only pushData-accepted is incrementally traced. The original part sink counters may record save status separately but cannot be inferred from new audit counters.
