@echo off
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
 py -3 scripts\serve_mp4.py %*
 exit /b
)
python scripts\serve_mp4.py %*
