# v2.19.0 MP4変換・整合性検査

操作と入力条件はv2.18.0から継承します。録画完了後、mp4_convert.htmlでTSを選び、順序を確認して別のMP4へ保存してください。保存確定前の中止や検査失敗はwriter.abort()します。確定後の読戻し失敗では既に保存先が置換されている場合があり、自動復元は行いません。

## 音声の照合

先行検査でADTSから取り出した各AAC圧縮サンプルに4バイトbig-endian長を付け、連続してSHA-256に入力します。変換後はMP4サンプル表を監査し、対応するmdat範囲に対して同じ処理を行います。入力1本ごとに照合するため、数が同じでもデータ/順序/サンプル境界が違えば拒否します。ADTSヘッダーと、存在する場合の2バイトCRCはraw AAC照合から除きます。CRC自体は検証しません。

mediaIntegrityEvidenceのaacPayloadHashVerifiedとaacPayloadHashAlgorithm、mp4IntegrityEvidenceの監査数・サイズ・時刻補正回数を返します。画面には音声フレーム数と音声データ照合済みを表示します。

## MP4出力契約

任意のMP4を読み取る一般的な検証器ではありません。同梱の変更していないmux.js 6.3.0が生成する形式に限定します。

- moof/mdatの対、moof内のmfhd/traf、tfhd/tfdt/trun等の個数と長さ。
- tfhd=0x3a、音声trun=0x301、映像trun=0xf01の契約とサンプル表サイズ。
- data_offsetが隣接mdat先頭を指し、全サンプルサイズがmdat内に収まり、余剰/不足の参照がないこと。
- サンプル長/継続時間が正、AAC継続時間1024、video sample内の4バイトNAL長と基本NALヘッダー/VCL有無。
- トラックごとのdecode時間範囲とsequenceの前進。UInt32 sequenceの折返しは前進差で扱います。
- 映像クロック90000、音声クロックが入力ADTSのサンプルレートに一致すること。

ライブラリ更新時は、出力契約と回帰試験も見直す必要があります。未知の出力を推測して通す方式にはしていません。

## 音声時刻の1 tick補正

44.1kHzの120秒素材で、90kHz系のPES時刻から換算した次fragmentが、直前fragmentの終了より1音声tick早くなるケースを検出しました。音声の負方向の重なりが1 tickだけなら次fragmentのtfdtを直前の終了へ揃えます。44.1kHzの1 tickは約22.7μsです。映像または2 tick以上の重なりはMP4_DECODE_OVERLAPで拒否します。正方向の時間差を一律に削除しません。

mp4IntegrityEvidenceのaudioClockAdjustments/maxAudioClockAdjustmentTicks/totalAudioClockAdjustmentTicksに回数と適用量を記録します。データの追加・削除はせず、AACサンプルhashは別途照合します。この限定的な補正は、任意の同期異常の修復を保証しません。

## 制限

1入力2GiB・最大4096本、H.264映像1トラック/同じTSのAAC最大1トラック、既定8MiB読込み/16MiB目安区切り/保持TS32MiB上限を継承します。ブラウザ全体のピークRAM上限を意味しません。互換convert APIは64MiBまでです。

AACのPES跨ぎ・複数raw_data_block・PCE・構成変更等は引き続き拒否します。H.264全RBSP/slice構文、出力esds/avcC等の全意味整合、映像内容の入力/出力ハッシュ、AAC CRC、圧縮データのデコードによる入力正常性判定は未実装です。音声の内容保持を、元音声が破損していないとの保証と混同しないでください。

実RPLAY・Windows・実ブラウザ/OS保存・数時間/2GiB・全プレイヤー互換性は未検証です。CANDIDATE_NO_GOを維持します。
