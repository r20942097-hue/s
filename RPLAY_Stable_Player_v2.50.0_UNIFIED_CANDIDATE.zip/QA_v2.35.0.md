# v2.35.0 QA

追加5件: 旧形式snapshot正規化、同時commitの片方拒否、stale/不正データ上書き拒否、locks非対応/未読込拒否、更新/空一覧削除。ブラウザ追加1件はstorageが別更新された後の保存拒否と再読込（実Web Locks）。既存の名前解決はAPI mockで実サービス受入ではない。
Linux/headless/使い捨てprofileで試験のみsandbox調整。native preview進行は未合格。dashboard/html/js/creator_registryの全派生コピーも検証対象へ追加。

全回帰662件PASS（Node497/Python165）。Firefox32 PASS/1 BLOCKED。追加9件を含む。登録競合保護5件とHLS工程診断4件を追加検証。ブラウザruntimeは単体試験対象の展開候補と同じコード。最終包装はCRC/全hash台帳を確認。
