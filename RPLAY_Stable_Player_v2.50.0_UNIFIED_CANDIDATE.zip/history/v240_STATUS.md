# v2.40.0 状況 — 2026-10-27 JST

CANDIDATE_NO_GO / remote_published=false
完了: 外部予約の進捗・中止、API本文/待機への取消伝播、画面終了時取消と10秒リース、先行取消、遅延結果抑止、録画停止と巡回の並行確認。
継承: v2.39統合機能と保存/変換/復旧。
未完: BG認証供給の独立設計、全開始経路policy統一、停止後MP4自動引渡し、汎用HLS URLのブラウザ内録画。
未受入: 実RPLAY/Windows/現行Firefox・Floorpの実ブラウザ/2GiB/長時間/native preview時間進行。
