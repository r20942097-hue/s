# v2.42.0 状況 — 2026-10-27 JST

CANDIDATE_NO_GO / remote_published=false
完了: 元署名URLの保持試験、実通信ページ情報のallowlist収集/照合、Referer/UAのコマンド欄反映、認証利用有無の表示、明示Cookieモード、同一origin/queryなし子URLだけの親query継承。
維持: v2.41の録画連続性改善と候補リスト、v2.40の予約取消等。
未完: 汎用ブラウザ内動画DL、全サービスの認証再現、BG停止後自動MP4。
未受入: 実ブラウザCookie条件/実RPLAY/Windows/2GiB/長時間/native preview進行。
