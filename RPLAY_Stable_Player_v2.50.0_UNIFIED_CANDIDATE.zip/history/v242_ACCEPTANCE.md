# 現行受入 v2.42.0

CANDIDATE / NO_GO。旧手順はhistory/v241_ACCEPTANCE.md。
1. 拡張版/OS/ブラウザ/ZIP hash/日時を記録。
2. ページ実通信URLの署名・パラメータ順/重複/escapeと、取得URL・生成コマンドを照合。
3. Referer/Origin/UA・取得元・Cookie/Authorization有無の観測。request/tab/URL違いで情報を混ぜない。値を保存/ログ出力しない。
4. Cookie OFF/ON、SameSite/分離/redirect、401/403を環境別に確認。ONだけで認証再現済みとは扱わない。
5. query継承OFF/ON、同origin空queryだけ継承、独自署名と別originを変更しない。
6. 既存の録画/変換/復旧/予約取消、実RPLAY/Windows/2GiB/長時間/native preview受入を継続。

fixture Cookieは実ブラウザCookie受入の代用としない。秘密を証拠へ転記しない。
