# RPLAY Stable Player v2.8.0 — 実受入チェックリスト（ACCEPTANCE）

2026-10-26更新(v2.8.0向け更新)。対象: v2.8.0 CANDIDATE(Chrome/Firefox拡張・userscript・CLI)。
この文書は開発計画P0「実受入準備」の成果物であり、**モック試験のPASSを実受入に
含めない**ための手順・観察記録の雛形を定める。実機で以下を完走するまで
製品は CANDIDATE / NO_GO のまま(GO判定は別承認)。

v2.7.0では認証系(canary・authEvidence・refresh-token実測)の観察点を追加した
(A8拡張・A11〜A13)。CLIの--refresh-token実測は開発計画v2.7.0のP2
(Refresh-Token実測・フェーズ0)に対応する。

## 0. 受入の原則(全項目共通)

1. **1観察=1記録**: 以下の各テンプレートに行単位で追記する。事後まとめ書きはしない。
2. **失敗も記録**: 再試行で成功しても最初の失敗行を消さずに残す(日時と再試行結果を追記)。
3. **署名なしURL**: 記録にURLを書くときは `origin+path` のみ(情報JSONの秘匿規則と同一)。
4. **秘密の一括持ち込み禁止**: 拡張の設定・トークン・鍵を受入記録に転記しない。
5. **版の固定**: 受入開始時にZIPのSHA256を記録し、途中で差し替えない。
6. **1項目=1環境**: 同じ環境で複数項目を連続実施するときは、項目間でブラウザープロファイルを
   使い回さない(汚染を避ける)。ただし「プロファイル再利用」自体を検証したい項目(6)を除く。

## 1. 拡張ロード手順(Chrome系)

1. `chrome://extensions` を開き、デベロッパーモードを有効化する。
2. 「パッケージ化されていない拡張機能を読み込む」で
   `rplay-stable-player-extension/` を指定する。
3. 拡張カードのID・バージョン(2.8.0)を観察記録T1に記録する。
4. `chrome://extensions/?errors=<id>` を開き、読込直後のエラーが0件であることを確認する。
5. RPLAYの配信ページを開き、RPLAY Stable Playerパネルが表示されるまでを記録する。
6. Service Worker(background)がACTIVEであること、オフスクリーン文書が
   録画開始時に生成されることを確認する(chrome://extensions の詳細 → Service Worker)。

## 2. 拡張ロード手順(Firefox)

1. `about:debugging#/runtime/this-firefox` を開く。
2. 「一時的なアドオンを読み込む…」で
   `rplay-stable-player-extension-firefox/manifest.json` を選択する。
3. アドオンID・バージョン(2.8.0)と署名なし(一時的)である旨を記録する。
4. コンソール(`about:debugging` → 調べる)に読込直後のエラーが0件であることを確認する。
5. RPLAYの配信ページでパネル表示・録画UIが機能することを確認する。

## 3. 受入項目と合格基準

| # | 項目 | 合格基準 | 記録 |
|---|---|---|---|
| A1 | 拡張ロード(Chrome/Firefox) | §1/§2手順を完走・読込直後エラー0件 | T1 |
| A2 | OPFS保存 | 録画1分以上・保存パートのバイト数=UI表示・再読込後にdownloadで再取得可 | T2 |
| A3 | Download API代替(OPFS不可時) | フォルダ選択なしモードでダウンロード確定・`DOWNLOAD_REQUESTED`段階の記録 | T2 |
| A4 | パート分割と ledger.json | 複数パート・各パートのsha256が情報JSONと一致・段階順序が契約どおり | T3 |
| A5 | タブ消滅耐性 | 録画中にタブを閉じる/クラッシュ→再読込→「追跡再開」で録画済みpart重複ゼロ | T4 |
| A6 | 長時間耐久(≥3時間) | heartbeat状のUI表示が継続・メモリー使用量が単調増加していない・パート切替正常 | T5 |
| A7 | 実RPLAYで公開配信録画 | TS/fMP4両形態・欠落率と漏れ数を記録・再生確認(全体を視聴して途切れ確認) | T6 |
| A8 | 実RPLAYで会員限定(自分の権限のみ) | key2/JWT再取得・401自動回復の観察(権限の無い配信は対象にしない) | T6 |
| A9 | CLI実RPLAY受入 | 停止時ledger/情報JSON/qaudit verdict・avCorrelation(音声両録画時)の記録 | T7 |
| A10 | 証拠ブロック実機確認 | fmp4Evidence/llhlsEvidence/generationRecovery/authEvidence/canaryEvidenceが情報JSONに存在し虚偽零がない | T3 |
| A11 | canary実機観察 | live/play応答形状canaryがokであること・shape_change時は警告ログで録画継続すること | T6 |
| A12 | CLI --refresh-token実測(フェーズ0) | 実RPLAYのrefresh-token APIで短命JWT取得・応答鍵を実測してauthEvidenceのresponseKeyと照合・秘密がログ/情報JSONに出ないこと | T7 |
| A13 | MP4メタデータ実機確認 | --mux mp4で生成したMP4をffprobe -show_entries format_tagsで確認(rplay_metadata_version=1・creator_oid・未知値は埋まっていないこと) | T7 |
| A14 | v2.8.0 offscreen証拠・Butter再試行・セッション追跡確認 | BG録画後の情報JSONにauthEvidence/canaryEvidence/sessionTrackingEvidence/errorTaxonomyEvidenceが出力され秘密が含まれないこと | T3/T6 |
| A15 | 字幕レンディション観察(v2.9.0) | 実配信のmaster playlistにEXT-X-MEDIA TYPE=SUBTITLESがあれば情報JSONのsubtitleEvidenceにrenditionCount/variantsLinked/言語が記録され、URI値が出力されず字幕playlistが取得されないこと。無ければ証拠ブロックが出ない(虚偽零なし) | T3/T6 |

## 4. 観察記録テンプレート

### T1 ロード観察
```
日時:            (JST)
環境:            OS / ブラウザー / バージョン
成果物SHA256:    
拡張ID:          
バージョン表示:  
読込直後のエラー: (0件 / 内容)
パネル表示まで:   秒
所見:            
```

### T2 保存観察(OPFS/Download)
```
日時:            開始 - 終了
モード:          OPFS / Download API代替
録画時間:        分
パート数:        
1パートあたり:    bytes / seg数
sha256照合:       UI値 vs 再計算値(一致/不一致)
再取得:          (成功/失敗 + 所見)
所見:            
```

### T3 ledger/証拠ブロック観察
```
日時:            
ledgerファイル:   
パート毎段階:     (例: REQUESTED→FILE_WRITTEN→HASHED→...)
最終status:      
fmp4Evidence:     mapDeclarations= mapSwitches= noDisc= crossPoll=
llhlsEvidence:    indicatorTags=
generationRecovery: stale= reset= rotation= context=
queueOrder:       violations=
所見:            
```

### T4 タブ消滅観察
```
日時:            
消滅方法:        (タブを閉じた / ブラウザークラッシュ / OS再起動)
復帰所要:        秒
復帰前パート:    
復帰後パート:    
重複バイト:      0 であること(新旧パートのsha256比較)
所見:            
```

### T5 長時間観察(3時間毎に1行)
```
経過h | パート数 | 総bytes | 漏れ数 | UI表示 | メモリー(MB) | 所見
  3   |          |         |        |        |              |
  6   |          |         |        |        |              |
```

### T6 実RPLAY観察
```
配信種別:        公開 / 会員(自分の権限)
形態:            TS / fMP4
画質:            
録画時間:        
欠落率:          (情報JSON stats.missingRate)
漏れ数:          missingSuspect
世代復旧:        stale= reset= rotation= context=
再生確認:        全編視聴(途切れ箇所: なし/時刻)
所見:            
```

### T7 CLI実機観察
```
OS:              
python:          
ffmpeg/ffprobe:  
コマンド:        (署名なしでURL部分はorigin+pathのみ記録)
exit code:       
ledger verdict:  
qaudit verdict:  
avCorrelation:    (音声両録画時のみ — drift/許容/verdict)
所見:            
```

## 5. 判定プロトコル

- 全項目(A1〜A10)が基準を満たした場合のみ「実機受入PASS」を記録する。
- 一部でも満たさない項目がある場合、受入はPASSとせず、失敗項目・再現手順・
  記録(T1〜T7)を添えて次版の入力とする。
- GO判定(公開・GitHub反映)は本チェックリストのPASSとは別の承認であり、
  本文中のいかなる表現もGOの代わりにしない。

### A16 TS細切れ防止・単一ファイル継続とPaywall検出の観察（v2.10.0）
- 既定設定（分割分数 `0`）で録画を開始し、`#EXT-X-DISCONTINUITY` が発生する配信でも `.ts` ファイルが細切れに分割されず単一パートとして継続記録されることを確認する。
- 情報JSONの `partContinuityEvidence` に `splitMinutes: 0`、`discontinuityMergedCount` が記録されていることを確認する。
- CLIで複数パートが発生した際、`--concat-parts auto` により `_merged.mp4`（または `_merged.ts`）が生成され、`partsConcatenated` と `concatOutput` が記録されることを確認する。

### A21 ソフトウェアAES-128フォールバックの観察（v2.16.0・N-01）
- `crypto.subtle` が利用可能な通常環境でAES-128暗号化VODを取得し、これまで通り
  WebCrypto経路で復号されること（`aesFallbackEvidence` が情報JSONに**出ない**か、
  `webcryptoOk` が増えるのみ）を確認する。
- 非セキュアコンテキスト等で `crypto.subtle` が欠落した環境を用意した場合、
  復号が完了し、情報JSONの `aesFallbackEvidence` に `webcrypto:unavailable` 理由と
  `softwareSuccesses` が記録されることを確認する。
- 復号済みTS/fMP4が公式プレイヤーの再生と同一内容であること（全編視聴）を確認する。

### A22 CLI AES-128取得の観察（v2.16.0・N-02）
- 視聴権限のある会話のAES-128暗号化VODに対し、`--dec-key auto`（または
  `--dec-key-file`）でCLI取得を実行し、復号済みTSが生成されることを確認する。
- 権限の無いVODに対しては `HLS_DEC_KEY_DENIED`（403分類）で明示停止し、
  TSが1バイトも書き込まれないことを確認する。
- 情報JSONの `decryptionEvidence` に `keySource` / `segmentsDecrypted` /
  `approxMbps` が記録され、**鍵値が全出力に現れない**ことを確認する（ゼロシークレット）。
- 純Pythonバックエンド（`--dec-backend python`）の実測速度を所見に記録する
  （目安 ~1MB/s・大容量はopenssl autoを推奨）。

### A23 TS連続性カウンタ監査の観察（v2.16.0・N-03）
- 通常配信の録画後、情報JSONの `continuityCounterEvidence` に
  `segmentsAudited` が録画セグメント数と一致し、`lostPacketEstimate=0` 付近である
  ことを確認する。
- 上流障害時（セグメント欠落が検出された録画）に `forwardJumps` /
  `lostPacketEstimate` が増加し、**録画自体は継続する**（監査は非破壊）ことを確認する。

### A24 配布整合の観察（v2.16.0・回帰防止）
- 配布ZIPを展開し、`rplay_join.py` がroot直下に存在し、`join_recording.cmd` との
  組み合わせが動作することを確認する（v2.15.0では同梱漏れがあった）。
- `scripts/validate.py` の PACKAGE_HASHES_PASS の件数が添付の `SHA256SUMS.json`
  エントリ数と一致することを確認する。

### A25 v2.17.0 MP4統合版の実機受入（未実施）
- 実OSファイル選択・保存と、入力/保存先同一指定の拒否を確認。
- 64MiB超、長時間、2GiB近傍、高ビットレートの実メディアで検査・変換・中止・再生・シークを観察。
- 同一TS内AACの先頭、継ぎ目、末尾、映像との相対時刻を確認。
- 低空き容量・保存失敗・確定後照合失敗の扱いを確認。確定後の失敗は自動ロールバックしない。
- 今回の65MiB nullパディング試験と8秒時刻折返し試験を、長時間受入の代用にしない。

### A26 v2.18.0 PES/AAC保全・実機受入（未実施）
- 実録画の正常TSが先行検査を通り、画面のAACフレーム数が入力/出力で一致することを確認。
- TSパケット境界で末尾切断した試験コピーが保存前に拒否され、元録画が保持されることを確認。
- 未対応なPES跨ぎAACを黙って通過させない。エラーで拒否したものを破損修復済みと扱わない。
- 実OS保存、長時間/2GiB、実配信のAV同期・シーク・先頭/末尾を確認。合成120秒や77.6MBの結果は代用しない。

### A27 v2.19.0 音声データ/MP4構造照合（実機未実施）
- 実録画のAACデータ照合済み表示、フレーム数、mp4IntegrityEvidenceを確認。
- 1 audio tick補正の回数を記録し、長時間/2GiBで相対同期・シーク・末尾を確認。合成120秒を長時間の代用にしない。
- 表/offset/サンプル内容の異常を確定前に拒否し、元TSを維持することを確認。
- 完全な入力正常性・MP4全準拠・全デコードの保証ではない。保存確定後の検証失敗は自動復元しない。

### A28 v2.20.0 Firefox警告とコーデック整合（改修後の実機未実施）
- Firefox用manifest.jsonを指定して読み込み、version_name警告の有無と表示versionを観察。
- 実録画のチャンネル/レート/映像寸法と変換結果を確認。未対応profile/parameter set変更を黙って通さない。
- 検査中止と確定済み保存の扱い、実OSファイルAPI、長時間同期・シークを観察。合成素材の結果を実配信受入の代用にしない。

## A29 v2.21 配信一覧・BGリスト・源選択

559自動試験PASS。UIとブラウザAPIはモック、公式新旧UI/現行RPLAY API/実ブラウザのacceptanceは未完。CANDIDATE_NO_GO維持。UI_IMPROVEMENTS_v2.21.0.md と QA_v2.21.0.md参照。

## A30 v2.22 TS/MP4とFirefox

576自動試験PASS。実Firefox158.0.1/Linux/headless一時拡張:21 PASS/1 BLOCKED（プレビュー再生進行）。実DLサイズ・試験側の出力SHA・FFmpeg全デコード・複数TS・Worker中止/残骸/排他を確認。Windows/実RPLAY/2GiB/長時間未検証。CANDIDATE_NO_GO維持。

## A31 v2.23 整理・ルート/probe・メディア診断

添付4点をSHAで照合。主ベースv2.22を保持し独立実装。全回帰597件構成、Firefox27項目（26 PASS/1 BLOCKED）。実RPLAY/Windows/2GiB/長時間の受入は残るためCANDIDATE_NO_GO維持。QA_v2.23.0.md参照。
