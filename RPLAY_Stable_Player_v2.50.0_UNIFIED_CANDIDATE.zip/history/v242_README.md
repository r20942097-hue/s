# RPLAY v2.42.0 CANDIDATE

署名付きURLは一覧表示で伏せるだけで、実通信URLをそのままRAMへ保持し、目録取得と保存コマンドへ変更せず渡します。v2.41でも署名を取得経路から除去していません。

今回、ページの実通信条件を確認する仕組みを追加しました。onBeforeSendHeadersと応答をrequestId/tabId/URLで照合し、Referer・Origin・User-Agent、取得元document/origin URL、Cookie/Authorizationの利用有無を記録します。Cookie/Authorizationの値や任意ヘッダを保存・コマンド出力しません。応答前の情報は最大200件/60秒、候補は既存上限とTTLでRAMだけに保持します。

候補選択時に取得元origin・ヘッダ取得状況・認証利用有無を表示し、観測済みReferer/User-Agentをコマンド用入力へ反映します。ブラウザfetchでRefererやOriginを強制する機能ではありません。Authorization利用を観測していても値は収集しないため、Cookie利用だけでは認証条件を再現できません。

## 取得の選択肢

- ブラウザのCookieを使って目録取得: 既定OFF。ONではcredentials includeで対象URLへのブラウザ認証情報利用を要求。CookieのSameSite/分離/ブラウザ設定等により送信されない場合があります。Cookieを手動抽出して別のホストへコピーする機能ではありません。redirectは引き続きerrorで停止します。
- 親クエリ継承: 既定OFF。必要な場合のみON。同一originかつクエリのない子URLに限り、親のraw queryをそのまま付加。クエリの順序・重複・escapeを保ち、既にqueryがある子URLと別originは変更しません。親の署名が子URLにも有効とは限りません。
- 401/403: URL署名期限、Cookie、Referer、Authorizationなど取得条件を確認する案内を表示。期限切れURLは対象ページで再取得してください。

目録取得の2MiB/8秒/中止、HLSリスト・画質/別音声選択、FFmpegコマンド、録画404猶予・quality lock、予約/設定/復旧は維持。汎用動画本体のブラウザ内DLや、全サイトの認証再現は未実装です。

PAGE_CONTEXT_v2.42.0.mdとQA_v2.42.0.mdを参照。実RPLAY・実ブラウザ・Windows・2GiB・長時間は未受入。CANDIDATE_NO_GO維持。
