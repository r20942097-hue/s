# 現行受入 v2.41.0

CANDIDATE / NO_GO。元手順history/v240_ACCEPTANCE.md。
1. 候補版SHA256/OS/ブラウザ版を固定、webRequest追加を反映して拡張を再読込。
2. HTTPS HLSページで候補を検出、URL/MIME・重複・タブ移動/閉鎖・再起動時の消去を確認。一覧/遷移先URL/永続storageへ署名値を出さない。
3. 候補選択→目録取得→variantとaudioリスト→2入力コマンド生成。取得中止、8秒timeout、2MiB超、無効URL、redirect/認証失敗を記録。
4. 一時404→同順取得・同一TS保存、永続404/410→限度後欠落を記録。データ後の自動畫質昇格を抑制し、消失fallbackは維持。
5. 実RPLAY/Windows/2GiB/長時間・AV同期・途中シーク・末尾・復旧・native preview進行を確認。ローカル4秒decodeを長時間受入に代用しない。
6. 予約取消/進捗・設定制御等の既存受入を継続。

VM/mock/local HTTPと実サービス/実ブラウザを区別。現時点で未受入をPASSへ変更しない。
