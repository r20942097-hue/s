# v2.41.0 状況 — 2026-10-27 JST

CANDIDATE_NO_GO / remote_published=false
完了: HTTPSの一時HLS候補リスト、明示目録取得・中止、画質/別音声候補、2入力FFmpegコマンド、録画404猶予再試行、データ書込後の自動畫質昇格抑制。
継承: 予約進捗/中止、設定制御、TS保存/変換/復旧。
未完: 汎用動画のブラウザ内DL、BG停止後の自動MP4、BG認証供給の独立設計。
未受入: 実RPLAY/現行実ブラウザ/Windows/2GiB/長時間/native preview進行。
