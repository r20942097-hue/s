# v2.39.0 状況

CANDIDATE_NO_GO / 2026-10-27 JST / remote_published=false

完了: v2.38機能保持＋このチャットv2.37の自動開始制御統合、設定読込5秒timeout、予約ID重複除外・有効日時・保持500件。
未完: 外部予約の進捗/取消、録画開始を必要としない正規のBG認証供給、全開始経路のpolicy統一、停止後MP4自動引渡し、汎用URLのブラウザ内録画。
未受入: 実RPLAY/Windows/Firefox/Floorp現行実拡張/2GiB/長時間/native preview進行。旧証拠のPASSを現行へ転記しない。
