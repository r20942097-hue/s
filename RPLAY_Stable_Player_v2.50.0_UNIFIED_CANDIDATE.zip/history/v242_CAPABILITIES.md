# 機能範囲 v2.42.0

|項目|状態|
|---|---|
|署名URL|表示と取得を分離。実通信URLを変更せず使う|
|ページ情報|request/tab/URL照合、Referer/Origin/UA・取得元・認証の有無をRAM保持|
|Cookie/Authorization値|未収集・未保存・未出力|
|Cookie利用|明示ON時のみブラウザのcredentials include、送信条件はブラウザ依存|
|Referer/UA|観測値をFFmpegコマンド欄へ反映。fetch強制ではない|
|親query継承|明示ON時、同一origin/queryなし子URLだけ。独自子queryは維持|
|目録上限・取消・候補リスト・録画継続|既存契約を継承|
|全サービス認証/ブラウザ内汎用動画DL|未対応|
