# Development Handoff — RPLAY Stable Player v2.50.0 (`CANDIDATE_NO_GO`)

## 1. Release Overview
- **Artifact**: `RPLAY_Stable_Player_v2.50.0_UNIFIED_CANDIDATE.zip`（zip sha256 `a0ac02a9…`・4.44MB・2132ファイル）
- **Version**: `2.50.0` (`CANDIDATE_NO_GO`)
- **Base**: v2.49.0 統合ベース（1077/1077 PASS・本リリース前に再パッケージ・クリーンルーム再検証済み）
- **Validation**: `1101 / 1101` 自動テスト（`922` Node.js + `179` Python）+ 共有コア `9f91f07d…`（5コピー一致）+ rebuild byte identity PASS

## 2. New in `v2.50.0` — segment_store Stage 3（明示取得の本番結線）
Stage 2 エンジン（`RspSegmentAcquire`・22テスト）を、設計書 `GENERIC_DISK_BACKED_DESIGN_v2.44.0.md` の Stage 3 に従って本番メッセージ経路へ結線した。紀律は Stage 0..2 と完全不変（**既定OFF・明示候補のみ・fail-closed・ゼロシークレット・非破壊**）。

### 2.1 新規モジュール `src/acquire_host.js`（束縛層）
| 関心事 | 実装 |
|---|---|
| 保存 | 実 `RspSegmentStore`（OPFS `rsp_seg/acquire/`・`.bin`+`.json` ペア・sha256 digest 検証は読み戻し時 fail-closed） |
| 通信 | 境界つき fetch アダプタ — プレイリスト2MiB / セグメント16MiB 上限・`credentials:'omit'`（観測資格情報を送らない）・タイムアウト・外部 signal 中断連動 |
| 解析 | `hls_transport.parse`（legacy モード・録画系と同一の受容範囲）をエンジン契約へ映射（`sequence`/`gap`/`discontinuity`/`discontinuitySequence`/`endList`） |
| 台帳 | OPFS `rsp_seg/acquire_ledger/state.json`（64KiB上限・segment sweep の孤児清掃対象外の別名前空間・best-effort永続化） |
| 復帰 | `bootRestore()` — 台帳+store メタから `restore()` し paused で復元。URL は台帳に無いため再開は候補の再選択が必要（ゼロシークレット契約） |

### 2.2 offscreen ホスト（`src/offscreen_post.js`）
- `acquire.start / continue / cancel / status / list / residue / discard / bootRestore` の8ケースを追加
- ホストは遅延束縛（初回の acquire メッセージで `RspAcquireHost.create`）— **毎メッセージ `SET.segmentAcquire===true` を再判定**し、OFF なら一様に `{ok:false,error:'ACQUIRE_DISABLED'}`
- 応答は engine の publicStatus / residue のみ（URL・トークンを含まない・engine の zeroSecretScan 契約）

### 2.3 BG ルータ（`src/background.js`）
- `acquire.*` は **dashboard 送信者のみ**（`fromDashboard` ガード）
- `start/continue` の入口は `mediaCatalog.get(candidateId)` の**観測候補のみ** — 候補の `mediaType==='hls'` ガード、失効は `CANDIDATE_EXPIRED`、フラグOFFは `ACQUIRE_DISABLED`
- URL は `toOffscreen({type:'acquire.start',payload:{id,playlistUrl}})` の**一回の引渡し**にのみ使う（応答・台帳・policy に残らない）

### 2.4 dashboard（`dashboard.html` / `dashboard.js` / `dashboard_settings.js`）
- `segmentAcquire` トグル（既定OFF・説明文つき）— 設定検証・伝播・実効policy列挙（`external.segmentAcquire`）に追加
- 候補一覧の HLS 行に「候補を取得（明示）」ボタン（フラグON時のみ表示）
- 取得ジョブパネル（`acquireSection`・フラグON時のみ表示）: 状態/セグメント数/バイト数・取消・再開（候補再選択）・残存確認・状態破棄 — **最大8件の境界表示**

### 2.5 テスト `tests/test_v2500_acquire_wiring.cjs`（24件）
- 機能（実 store・実パーサ・モック fetch/OPFS）: 既定OFF fail-closed 8操作・明示取得 happy path・ゼロシークレット走査（status/residue）・HTTP_403/404/500 の `HTTP_xxx` 可視化と残存保護・2MiB/16MiB 上限 fail-closed・取消（ゲート制御）と残存列挙・再起動復元+候補再選択継続・`NO_LEDGER`・入力検証・パーサアダプタ映射・digest 改竄検知（`SEGMENT_DIGEST_MISMATCH`）
- 結線契約（ソース表明）: offscreen_pre の SET 既定/適用/検証配列・offscreen_post の8ケース+遅延束縛+`RspSha256.Sha256`・BG の dashboard ガード/候補解決/HLS型ガード/伝播/policy 列挙・dashboard_settings 正規化・dashboard UI・preload 順序（Chrome offscreen.html / Firefox manifest・`sha256.js → segment_store.js → segment_acquire.js → acquire_host.js → offscreen.js`）・build/validate 派生コピー網羅
- BG ルータ vm 試験: フラグOFF拒否（中継なし）・非dashboard送信者拒否・`CANDIDATE_EXPIRED`・非HLS拒否・HLS候補の1回中継（明示 `rsp-host` ターゲット）・id 形状検証

## 3. Version Pins
- マニフェスト2件・userscript `@version`・`rplay_dl.py v2.50.0` 文字列群・`rplay_join.py v2.50.0`・`acceptance_report.py v2.50.0`・build/validate/package_release 出力 → 全て `2.50.0`
- レンジピン2形式（`|49|50)\.0` と `|49\.0|50\.0)`）7ファイル拡張・`test_v291_core` の migration literal + 列挙ピン更新・完全一致ピン（test_v2150_core / test_v2160_core / test_v2422_dash / test_v2424_part_commit / test_v2450_crash_parts / test_v2150_features / test_v291_features）更新
- `test_v2380_start_policy` の実効policy期待値へ `segmentAcquire:null` を追加・`test_v2480_integration_wiring` のフラグ一覧表明を拡張
- 履歴コメント（`v2.49.0:` 等）は規約通り保持

## 4. Remaining Unverified Boundaries (`CANDIDATE_NO_GO`)
- 実 live-service 耐久・実 Chrome 拡張インストール・Windows ネイティブ FS は container simulation の外（`ACCEPTANCE.md` に基づく人間受入が必要）
- `mp4AutoHandoff` ON パス（A-11）・`segment_acquire` の実ネットワーク取得（A-13）は未受入
- 取得セグメントの**組立・変換・保存は本版では未配線**（disk に残るのみ・既存変換経路への接続が次の実装範囲）

## 5. Suggested Next Steps
- `ACCEPTANCE.md` 項目（A-10 / A-11 / A-12 / A-13）を実ブラウザで実施
- 取得セグメントの組立: store の `.bin` 列を sequence 順に連結し、既存 `RspMp4Convert` / 無劣化連結経路へ引き渡す（録画系と同一の変換・照合・受入経路・専用経路を作らない）
- 完了後: 取得ジョブの進捗イベントを `rec.event` 系へ統一し、export journal 経由の保存（blob URL は永続化しない）へ接続
