# v2.29.0

creator_registry.jsを生成userscriptへ埋込、dashboardへscriptで追加。IDだけstorage.localに保存、background registry.listは既存RPLAY top frame判定下で参照のみ。予約とpoolに合流。秘密URLを台帳へ保存しない。手入力お気に入りはrsp_fav。
次: 任意の名前URL→公式ID解決、登録IDの名前キャッシュ、キャッシュ手動無効化、予約一覧の中断/直列化、外部からの予約API表示。現在の登録は予約自動録画ではない。
