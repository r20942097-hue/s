# RPLAY開発統合台帳（2026-10-25 / v2.7.0）

## コンポーネント・責務の境界

| 系統 | 作業基準 | 所有責務 | 統合許可範囲 | 状態 |
|---|---|---|---|---|
| Stable Player | 2.7.0 CANDIDATE(統合) | 手動プレイヤー、手動ブラウザー録画、単体Python CLI | HLS状態契約、診断仕様 | NO_GO |
| Public Profile Auto Recorder | 1.22.0 CANDIDATE | 公開プロフィール監視・ブラウザ自動録画、最大12（既定2） | 通信予算・保存監査の独立契約 | NO_GO(今回変更なし・境界を文書化) |
| Universal Live Watcher | GitHub `r20942097-hue/faaff` | FFmpeg長時間録画、起動監視、SQLiteと復旧 | API/JSONイベント（コード合体しない） | 変更なし・HEAD未固定 |
| Media Download Tools | 系統独立 | 権限がある終了済みVOD、メディアQA | 検証メタデータとffprobe結果 | 変更なし |

## v2.6.0からの引継ぎ（実施状況の書き換え）

| v2.6.0計画の残課題 | v2.7.0での扱い |
|---|---|
| P0 実機受入の実施(ACCEPTANCE.md A1〜A10) | **未実施のままP0維持**。本環境では実Chrome/Firefox/Windows/実RPLAYに接続できないため、v2.7.0でも実施できず観察手順のみ拡充(認証系の観察点を追加)。ユーザー実施待ち |
| P1 LL-HLS全件形式の実配信評価 | 未実施(実配信が必要)。代替として合成全件形式試験をv2.6.0で実施済み。実配信評価はP1のまま次版へ |
| P2 avCorrelationの実RPLAY較正 | 未実施(実配信が必要)。許容値(2%/0.5s)は合成較正のまま。次版へ |
| P2 Auto Recorder側の証拠ブロック対応 | 未実施(独立契約のため相手系統のコードは編集しない)。境界文書のまま次版へ |
| P3 長時間耐久・Windows・実RPLAY受入 | 未実施。ACCEPTANCE.md A6〜A9のまま |

## v2.7.0の実施記録（2026-10-25確定）

- 全自動試験: Node160 + Python102 = 262 PASS・再ビルド5コア一致
  (shared_core_sha256 0c7d858a…)・クリーン展開再検証PASS。
- 試験資産: rsp_v270_tests.json / rsp_v270_validation.json / evidence/。
- 版ずれ修正: manifest version_name(2.5.0のまま)・情報JSON tool文字列(v2.5.0の
  まま)を2.7.0へ統一。版ピン試験で恒久固定。
- 残された非対称: offscreen/backgroundホストの拡張録画ではauthEvidenceが
  未中継(STATE.authStats未設定なら証拠ブロック自体を出さない)。次版候補。

## v2.7.0の目標（一文）

**外部調査で判明した認証・通知・メタデータの最適要素を、実機を要しない範囲で証拠駆動の形で Stable Player 両コアへ取り込み、サイト変化への追従力を構造的に上げる。**

## v2.7.0で実施した要件（追加提案A-01〜A-08の採用）

- **A-01 Refresh-Token移行の段階実装（最優先・P1）** — 実装:
  フェーズ1〜3相当。CLIに `--refresh-token SPEC`（値直接 / `env:VAR` / `file:PATH` の三種供給）
  と `--user-oid OID`（requestorOid補完）を追加。短命JWTの更新ループ
  （expのleeway 300秒前に再取得・失敗は3回再試行・指数バックオフ）。
  `--token` との優先順位契約: 明示指定の `--token` が一次、`--refresh-token` は
  併用時の401時自動切替先。認証の回避は行わない（自分の資格のみ・権限の
  ない配信にはアクセスしない）。応答鍵(jwt/token/…)は形状証拠として記録。
- **A-02 auth_store抽象とauthEvidence証拠ブロック（P1）** — 実装:
  `AuthStore`（供給源=手動指定のみ・環境変数・ファイル読み取りを含む供給分離）
  と401分類(invalid_or_expired / switched_to_refresh / refreshed / refresh_failed /
  no_credentials)を契約化。`authEvidence`（認証方式・供給源種別・更新試行回数・
  更新成功回数・401分類計数・key2再解決回数・応答鍵・秘密は含まない）を
  情報JSON・ledgerへ統合。userscript側は RspAuth に authEvidence を追加し
  CLIと同形式（鏡像）で記録。
- **A-03 サイト更新検知のcanary化（P1）** — 実装:
  live/play 応答形状のcanary検証（既知鍵との照合 → ok / shape_change / unreachable）。
  shape_change時は警告ログのみで安全側継続（録画を止めない）。`canaryEvidence`
  として観察鍵一覧（公開鍵のみ・URL秘匿規則適用）を情報JSONへ記録。
  両コア鏡像。
- **A-04 通知の豊富化（P2）** — 実装:
  webhookイベント種別を拡充（既存 start/part/audio_part/end に加え
  auth_failed・save_error・capacity_warning・merge_completed）。
  全イベントに level(info/warn/error) と ts(ISO) を追加。429応答の
  Retry-After退避を尊重。`notificationEvidence`（イベント別計数・429遭遇回数）
  を情報JSONへ記録。ペイロード契約（秘密の完全除去）は維持。
- **A-05 MP4メタデータタグの導入（P2）** — 実装:
  `--mux auto|mp4` 時の TS→MP4 リマックスと2トラックmuxに
  rplay_metadata_version=1互換タグ（creator_oid・recording_started_at・
  stream_start_time・title・artist）を埋め込み。**未知の値は埋めない契約**
  （分かる値だけ埋める）。`metadataEvidence`（埋め込みタグ鍵一覧・検証手段）
  を情報JSONへ記録。ffprobeによる確認手順を試験に組込み。
- **A-07 合成APIリグレッション（P1・試験資産）** — 実装:
  ローカルHTTPサーバーで login 相当の refresh-token エンドポイント・
  live/play 形状・401→更新→再試行のフローを模した合成試験
  （test_v270_auth.py・test_v270_features.py）を追加。依存API形状を
  試験として固定（サイト更新時に差分として変化が可視化される）。
- **A-08 証拠ブロックの拡張（横断）** — 実装:
  v2.6.0の証拠体系（generationRecovery・fmp4Evidence・llhlsEvidence・
  avCorrelation）に authEvidence・canaryEvidence・notificationEvidence・
  metadataEvidence を同形式（虚偽零・出所明示・URL秘匿）で追加。

## 次に着手する実装順（順序を固定）

| 優先 | 作業 | Done基準 | 注意点 |
|---|---|---|---|
| P0 | 実機受入の実施 | ACCEPTANCE.md A1〜A10を完走・観察記録T1〜T7を埋める | 外部環境を勝手にGOにしない。v2.7.0でauthEvidence/canaryEvidence/metadataEvidenceの観察点を追加 |
| P1 | LL-HLS全件形式の実配信評価 | 実LL-HLS源で指標タグ計数と録画継続を観察 | SKIPが来ない前提の検証で満足しない |
| P2 | avCorrelationの実RPLAY較正 | 実配信の実測drift分布で許容値(2%/0.5s)を再評価 | 合成メディアだけの較正で固定しない |
| P2 | Refresh-Token実測（フェーズ0） | 実RPLAYで静的JWT可否・refresh-token応答鍵を実測 | 合成試験の応答鍵候補は非公式情報。実測で鍵を確定してからauthEvidenceの記録鍵を更新する |
| P2 | Auto Recorder側の証拠ブロック対応 | 独立契約のままfmp4Evidence等のスキーマ適合 | 予算カウンタの共有をしない |
| P3 | 長時間耐久・Windows・実RPLAY受入 | ACCEPTANCE.mdのA6〜A9 | GO判定は別承認 |

## 試験方針（v2.7.0追加分）

- テストファースト: 本実装より先に新規試験（AuthStore単位・canary・webhook・
  メタデータ・userscript鏡像）を書き、失敗を確認してから実装した
  （初回実行: auth 15試験中4失敗+11エラー・features 11試験中3失敗+8エラー・
  core 6試験版不一致 — 実装後に全PASS）。
- VMセーフ: 全新規試験はローカルHTTPサーバー（127.0.0.1の一時ポート）と
  一時ディレクトリのみで動作。実ネットワーク・実RPLAY・実ブラウザに依存しない。
- 両コア鏡像: authEvidence・canaryEvidenceの情報JSON形式はCLIとuserscriptで
  同一構造（相互言語比較試験 test_v270_core.cjs で固定）。
- 閾値: v2.7.0の全自動試験は Node160 + Python102 = **262 PASS**
  （v2.6.0の230件+32件）。scripts/validate.pyの閾値を160/102に固定。

## 再開プロトコル

1. 進行中のWorkまたはLibraryに新しい成果物がある場合、まず読み取り専用で原本一覧・SHAを比較する。
2. 変更競合があればbranch/candidateを分ける。Stable版や現行配布物を上書きしない。
3. 保存処理・録画制御・HLSコアの生成元を編集し、生成物を手編集しない。
4. JS/Python/FFmpeg回帰、生成ファイル一致、ZIP内のハッシュ、クリーン展開再試験を終えて候補版を作る。
5. GitHub/Store配布や公開判定GOは別承認。実機未検証のまま完了扱いにしない。
