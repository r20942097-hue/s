(function(root,factory){const api=factory(typeof module==='object'&&module.exports?require('./sha256.js'):root.RspSha256);if(typeof module==='object'&&module.exports)module.exports=api;else root.RspRecovery=api;})(globalThis,function(hashing){
 'use strict';
 function validate(j,folder){
  if(!j||![1,2].includes(j.schema)||j.status!=='active'||!['ts','mp4'].includes(j.ext)||typeof j.file!=='string'||j.file.length>240||/[\\/\u0000-\u001f]/.test(j.file)||!j.file.endsWith('.'+j.ext)||folder!==j.file+'.checkpoint')throw Error('INVALID_JOURNAL');
  if(!Array.isArray(j.parts)||!j.parts.length||j.parts.length>4096||!Number.isSafeInteger(j.committedBytes))throw Error('INVALID_PARTS');
  let sum=0;for(let i=0;i<j.parts.length;i++){const p=j.parts[i];if(p.file!=='chunk-'+String(i+1).padStart(8,'0')+'.bin'||!Number.isSafeInteger(p.bytes)||p.bytes<=0)throw Error('INVALID_CHUNK');if(j.schema===2&&!/^[0-9a-f]{64}$/.test(p.sha256||''))throw Error('INVALID_HASH');sum+=p.bytes;if(!Number.isSafeInteger(sum))throw Error('INVALID_SIZE');}
  if(sum!==j.committedBytes)throw Error('INVALID_SIZE');return j;
 }
 async function inspect(dir,options={}){
  const journalHandle=await dir.getFileHandle('journal.json');const file=await journalHandle.getFile();if(file.size>2*1048576)throw Error('JOURNAL_LIMIT');
  const j=validate(JSON.parse(await file.text()),dir.name);const chunks=[];
  for(const p of j.parts){const handle=await dir.getFileHandle(p.file);const file=await handle.getFile();if(file.size!==p.bytes)throw Error('CHUNK_SIZE_MISMATCH');if(j.schema===2&&options.verify!==false&&await hashing.hashBlob(file)!==p.sha256)throw Error('CHUNK_HASH_MISMATCH');chunks.push({handle,file});}
  return {journal:j,chunks,journalHandle};
 }
 async function recover(dir,destination,original,progress=()=>{},options={}){
  const snapshot=await inspect(dir);
  for(const h of [snapshot.journalHandle,...snapshot.chunks.map(c=>c.handle),...(original?[original]:[])]){
   if(typeof destination.isSameEntry!=='function')throw Error('IDENTITY_CHECK_UNAVAILABLE');
   if(await destination.isSameEntry(h))throw Error('SOURCE_OVERWRITE_REFUSED');
  }
  const verifyTs=!!(options&&options.verifyTs)&&snapshot.journal.ext==='ts';
  if(verifyTs&&snapshot.journal.committedBytes%188!==0)throw Error('RECOVERY_BAD_TS');
  let writer;let bytes=0,tsRem=0;const copiedHash=new hashing.Sha256();
  try{
   writer=await destination.createWritable();
   for(let i=0;i<snapshot.chunks.length;i++){
    const c=snapshot.chunks[i],partHash=new hashing.Sha256();
    for(let at=0;at<c.file.size;at+=1048576){
     const b=await c.file.slice(at,at+1048576).arrayBuffer();
     const data=new Uint8Array(b);
     if(verifyTs){
      const firstOff=tsRem===0?0:188-tsRem;
      for(let p=firstOff;p<data.length;p+=188)if(data[p]!==0x47)throw Error('RECOVERY_BAD_TS');
      tsRem=(tsRem+data.length)%188;
     }
     await writer.write(b);copiedHash.update(data);partHash.update(data);bytes+=b.byteLength;progress(bytes,snapshot.journal.committedBytes);
    }
    if(snapshot.journal.schema===2&&partHash.digest()!==snapshot.journal.parts[i].sha256)throw Error('CHUNK_HASH_MISMATCH');
   }
   await writer.close();writer=null;
   if((await destination.getFile()).size!==snapshot.journal.committedBytes)throw Error('RECOVERY_SIZE_MISMATCH');
   const sha256=await hashing.hashBlob(await destination.getFile());if(sha256!==copiedHash.digest())throw Error('RECOVERY_HASH_MISMATCH');
   const out={bytes,sha256,sourceIntegrity:snapshot.journal.schema===2?'sha256':'size_only',confirmed:true,decoded:false};
   if(verifyTs){out.tsVerified=true;out.tsPackets=bytes/188;}
   return out;
  }catch(e){if(writer)try{await writer.abort();}catch(ignore){}throw e;}
 }
 return {validate,inspect,recover};
});
