# v2.40.0 引継ぎ

schedule host: _bgSchedJob、AbortController、requestId、完了数、lease timer。statusは一致IDのleaseを更新。cancelは一致IDだけabort、開始前取消は有効60秒/100件Mapで保持。controlQueueには入れない。
BG router: dashboardだけschedules.status/cancelを中継、32桁hexを検査。scanはrequestIdをpayloadへ引継ぎ。
BG authedJson→共通JSON signal、fetchSchedulesFor第2引数signalを追加。bgSchedWaitはabort時timer/listenerを解放。finallyでlease・busyを解放。
dashboard: UUID、1秒poll（同時1要求）、中止/pagehide、metadata await後ガード、遅延結果抑止、finally cleanup。

次: 実サービスfixture・実ブラウザ受入。UI監視が遅れるとリース取消となる仕様を評価。BG認証供給を録画と切り離す設計、停止後MP4自動引渡し、汎用HLSを段階実装。
