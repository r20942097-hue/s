# v2.26.0 QA

追加4件: 再探索HTML/終了拒否、master child HTTP、2MiB cancellation、stop late adoption。全回帰結果は evidence/v226-current。Firefox結果は evidence/firefox-v226。旧版証拠は履歴。

最終ZIPはCRC・全SHA台帳を検査し、包装後に追加した証拠/資料以外の全ファイルを試験済み展開ツリーとバイト照合。独立再包装も同一SHAを確認。FirefoxもZIP展開ツリーから再試験済み。
