#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RPLAY Live Downloader (rplay_dl.py) — ログイン不要・ブラウザ不要・標準ライブラリのみ

RPLAYのライブ配信を保存する単一ファイルの候補版。v2.3.1はローカルHTTPで検証済み。
実RPLAYの現在のAPI・アクセス条件・長時間録画は未検証。TSと非暗号化fMP4に対応。
v1.8.0: --token(自分のJWT)で視聴権限のある会員限定配信にも対応、
--wait-scheduleで配信予約の開始を待って自動録画。
v1.9.0: master playlistから最高画質バリアントを自動選択(解像度→fps→帯域、
yt-dlpの既定ソート・streamlink/N_m3u8DL-RE踏襲)、録画中の画質昇格
(master定期再走査)・バリアント消失時の次画質フォールバック、
解決済みバリアントの直接ポーリング(master再取得を省略しリクエスト半減)。
v1.10.0: --config(設定ファイルJSON)、--mux(録画後のffmpegストリームコピーで
MP4化 — 再エンコードなしの無劣化リマックス)、--name-tpl(保存ファイル名
テンプレート)、情報JSONに統計(欠落率/再接続/基盤切替/画質)を拡張。
v1.11.0: --audio-only(音声レンディションのみ録画)/--audio-both(映像+音声の
両TS並行録画)、2トラックmux(映像TS+音声TS→無劣化MP4)。ポッドキャスト的
な音声単独利用と、音声トラックを分離したいワークフローに対応。
v1.12.0: --discover(ライブ探索 — 配信者を固定せず、公式フロントと同一の
公開APIだけでライブ中の配信を探索)/--discover --watch(定期的に再走査し
新規ライブを通知)/--json(機械可読出力)。録画の堅牢化として429応答の
Retry-After(RFC9110)を指数バックオフより優先、EXT-X-GAP(内容欠損)と
EXT-X-BYTERANGE(部分範囲)のセグメントを取得せず欠落として数える防御を追加。
v2.1.1: 排他的なパート作成・非上書き確定・確定後サイズ/ハッシュ照合・保存失敗時終了コード2。
v2.3.1: Range/Content-Range照合、MAP初期化データ、fMP4、本文サイズ制限、
シーケンス単位の重複排除、停止世代の保護。暗号化HLSは明示的に拒否。
孤立.partは未検証として保持し、自動確定しません。
v2.5.0: 2つのv2.4.0系統の統合 + P1/P2実装(開発計画どおり):
  - 運用堅牢化を移植統合(別系統v2.4.0バンドルから): stop-file(.rplay_stop)・
    heartbeat.json+--healthcheck・--min-free-mb/--min-free-inodes(保守ガード述語
    guard_low+二重確認)・--segindex(URI鍵永続化・再起動重複防止)・--webhook・
    標準入力対象読込
  - P1 EXTINFモード分離(--extinf-mode legacy|rfc): 既定legacyは未宣言を診断計数
    (missingExtinf)して継続。rfcはRFC 8216 4.3.2.3どおり拒否。両モード別試験
  - P1 プレイリスト世代復旧: 各pollをinitial/progress/stale/reset/rotation/context
    で分類し数値証拠(info JSON generationRecovery)として記録。旧playlist再配信
    (stale)は重複録画せず、正当なsequence resetは新世代として録画。推測で
    旧セグメントを削除しない(不変path重複排除のみ)
  - P1 実メディア品質監査(--qaudit auto|no): 停止時にffprobeでPTS/DTS単調性・
    timebase・フレーム/サンプル構成・全編デコードエラーを実測。PDT宣言値との
    一致だけでは品質合格扱いにしない(証拠はprovenance:decoded)
  - P1 保存確定イベント契約: <out>/RPLAY_<ID>_ledger.jsonに各パートの
    REQUESTED→FILE_WRITTEN→HASHED→DECODED/CONTINUITY段階を実測時刻付きで記録。
    段階を飛ばしてSUCCESS扱いにしない(ブラウザー段階はCLIでは適用外と明示)
  - P2 URL秘密の非出力: 情報JSON・ログ・webhookから署名/key2クエリを除去
    (origin+pathのみ)。segindexはpath+range鍵で秘密をディスクに残さない
  - P2 FIFO shadow証拠: キュー登録順と取得順の一致を実測(info JSON queueOrder)
  - P2 孤立part台帳(sha256付き・報告のみ)・ENOSPC/EDQUOTの区別記録
v2.6.0: 開発計画v2.6.0のP1/P2/P0を実装:
  - P1 fMP4複数MAP監査: EXT-X-MAP宣言数・切替回数・DISCONTINUITY無し切替を
    数値証拠(info JSON fmp4Evidence)として記録。MAP切替はパート境界分割で
    初始化セグメント混在を防止(従来からの挙動を証拠化・両HLSコア鏡像)
  - P1 分離音声PTS相関のqaudit統合: 映像/音声トラックの実デコード時間
    (durationTs×timebase)を集計し、ドリフト量・許容逸脱(driftRatio)を
    avCorrelationとしてledger/情報JSONへ記録(原点同期はmux後再生で最終確認)
  - P2 LL-HLS安全側仕様: EXT-X-SKIP(差分playlist)はHLS_LLHLS_SKIPで拒否、
    EXT-X-PRELOAD-HINT/SERVER-CONTROL等は取得せず計数証拠(llhlsEvidence)のみ
  - P0 実受入準備: ACCEPTANCE.md(実Chrome/Firefox/Windows受入手順・観察記録)
    と COMMUNICATION_BUDGET_BOUNDARY.md(Auto Recorderとの境界設計)を同梱
v2.7.0: 開発計画v2.7.0(追加提案A-01〜A-08の採用)を実装:
  - A-01/A-02 認証の段階移行とauth_store抽象: --refresh-token(値直接/env:変数名/
    file:パスの三種供給)と--user-oid(requestorOid補完)を追加。AuthStoreが
    短命JWTの更新ループ(expのleeway 300秒前に再取得・失敗3回再試行)と401分類
    (no_credentials/invalid_or_expired/refreshed/refresh_failed)を契約化。
    --token(明示指定)が一次で、401時だけ--refresh-tokenへ自動切替+1回再試行
    (公式interceptorと同一戦略・連打しない)。認証の回避は行わない(自分の資格のみ)
  - A-02 authEvidence証拠ブロック: 認証方式・供給源種別・更新試行回数・成功/失敗・
    401分類計数・key2再解決回数・応答鍵(形状証拠)を情報JSON/ledgerへ記録。
    秘密(トークン値)は一切含めない(userscriptのRspAuthと同形式鏡像)
  - A-03 サイト更新検知のcanary化: live/play応答形状を既知鍵と照合し
    ok/shape_change/unreachableに分類。shape_changeは警告ログのみで安全側継続
    (録画を止めない)。canaryEvidenceとして観察鍵一覧(値は出さない)を記録
  - A-04 通知の豊富化: webhookイベントにauth_failed/save_error/capacity_warning/
    merge_completedを追加。全イベントにlevel(info/warn/error)とts(ISO)を付与し、
    429応答のRetry-After退避を尊重。notificationEvidenceでイベント別計数を記録
  - A-05 MP4メタデータタグ: --mux auto|mp4時のリマックス/2トラックmuxに
    rplay_metadata_version=1互換タグ(creator_oid/title/artist/
    recording_started_at等)を埋め込み。未知の値は埋めない契約。
    metadataEvidenceで埋め込みタグ鍵一覧を記録(ffprobe確認手順を試験に組込み)
  - A-07 合成APIリグレッション: 認証フロー(refresh-token・live/play形状・401→更新→
    再試行)をローカルHTTP合成試験として固定(実ネットワーク不要)
v2.8.0: 開発計画v2.8.0(rplay_watcher v0.5.0知見統合 & offscreen証拠対称化)を実装:
  - W-01 Butter署名自動付与・M3U8 403再試行: AES-128-CBC Butter署名生成(WebCryptoと
    完全バイト一致・360秒バケットキャッシュ)をCLI/offscreenにも実装し、M3U8が403を
    返した際にButterヘッダ付きで1回自動再試行(authEvidence.butterSentへ記録)
  - W-02 streamStartTime 10分(600秒)閾値セッション追跡: live/playのstreamStartTimeを
    監視し、600秒以内の変化は同一配信の瞬断復帰(same_session_resumed)、600秒超は
    新配信枠(new_session_split)としてsessionTrackingEvidenceへ記録
  - W-03 4層ErrorKind分類: SOURCE(5xx)/NETWORK(接続・timeout)/AUTH(401/403)/
    PLATFORM(429)/COMPATIBILITY(暗号化・LL-HLS SKIP等)/INTERNAL(書込失敗)を
    errorTaxonomyEvidenceへ記録
  - W-04 拡張offscreen/backgroundホストのauthEvidence/canaryEvidence対称化
v2.9.0: 開発計画v2.9.0(A-09字幕対応 第一段階「観測と証拠」)を実装:
  - A-09 parse_subtitle_renditions/subtitle_evidence_block: master playlistの
    #EXT-X-MEDIA(TYPE=SUBTITLES)を観測・計数しsubtitleEvidenceへ記録。
    字幕playlistは取得しない(observed_not_fetched)・URI値は秘匿(hasUriのみ)・
    未知属性は埋め込まない(固定鍵集合)。未取得では証拠ブロックを出さない
v2.11.0: 開発計画v2.11.0(TS細切れ防止 & Video DownloadHelper/Streamlink/rplay_watcher v0.5.2知見統合):
  - W-05 MPEG-TS EXT-X-DISCONTINUITY連続追記: TSセグメントはDISCONTINUITYで細切れ分割せず
    単一パートへ連続追記(既定、--split-on-discontinuityで従来分割可)。fMP4は境界分割を維持
  - W-06 分割既定値0化 & 複数パート自動結合(--concat-parts): --split-minの既定値を0(時間分割なし・
    容量上限まで単一ファイル継続)へ変更。複数パート発生時もffmpeg concat demuxerで単一MP4/TSへ
    無劣化結合(--concat-parts auto|mp4|ts|no)しpartContinuityEvidenceへ記録
  - W-07 セグメントHTTP 503 Retry-After対応(v2.7.1パッチ統合) & Master 200 / Media 404
    paywall_blocked検出(rplay_watcher v0.5.2知見)

【使い方】
  python rplay_dl.py <配信URLまたはクリエイターID> [オプション]

  例:
    python rplay_dl.py https://rplay.live/live/6a9a5cf47c2509cb88f8fd40
    python rplay_dl.py 6a9a5cf47c2509cb88f8fd40 --out D:\\rec --split-min 30
    python rplay_dl.py <URL> --token <自分のJWT>          (会員限定: 視聴権限がある場合のみ)
    python rplay_dl.py <URL> --token <自分のJWT> --wait-schedule   (予約開始を待って自動録画)
    python rplay_dl.py --discover                         (ライブ探索 — ライブ中の一覧を表示)
    python rplay_dl.py --discover --json                  (機械可読出力)
    python rplay_dl.py --discover --watch 120             (2分間隔で再走査し新規ライブを通知)

【主なオプション】
  --out DIR        保存先フォルダ(既定: ./rplay_dl/<ID>)
  --once           録画せず配信状態を確認して終了
  --no-backlog     開始時にプレイリストへ残る過去セグメント(最大約20分)を取得しない
  --split-min N    この分数でファイルを自動分割(既定20、0で無効)
  --max-size-mb N  このMB数でファイルを自動分割(既定600)
  --no-follow      配信終了で終了する(既定: 追跡待機して次の配信を自動録画)
  --standby-min N  追跡待機をN分で打ち切り終了(既定0=無期限)
  --no-flv         HLS不通時のFLV代替録画を無効化
  --max-hours N    最大録画時間(時間)。0で無効(既定0)
  --info-json      停止時にパート一覧・統計の情報JSONを保存
  --ua STR         User-Agent指定(既定: RPLAY-LiveDL/1.0)
  --m3u8 URL / --flv URL / --api URL   エンドポイント手動指定(試験・カスタム用)
  --token JWT      自分のRPLAY JWT(ブラウザでログイン後、F12→localStorageの
                   _AUTHORIZATION_)。指定すると視聴権限のある会員限定配信を
                   録画できる(401時は自動で再読込案内・鍵は自動更新)。認証の回避
                   ではない — 自分が視聴できる配信のみを扱う
  --wait-schedule  配信予約(live/schedules)を監視し、開始時刻に自動録画(--tokenが必要)
  --first-variant  最高画質でなくmasterの先頭バリアント(サーバー指定順)を使用
                   (既定: 最高画質を自動選択し、昇格/フォールバックも有効)
  --audio-only     音声レンディション(URI付きEXT-X-MEDIA)のみを録画(音声TS)
  --audio-both     映像+音声の両TSを並行録画(音声はaudio-*.tsに別保存)。停止時に
                   映像TS+音声TSの両方がある場合、2トラックの無劣化MP4を自動生成
                   (ffmpeg -c copy。--mux no で無効)

【cron連携(予約録画の定期実行)】
  crontab例: 毎日21:50に起動し予約開始まで待機→自動録画→MP4化まで一括:
    50 21 * * * cd /path/to/dir && /usr/bin/python3 rplay_dl.py <URL> \
      --token <自分のJWT> --wait-schedule --mux auto --out /rec >> /rec/cron.log 2>&1
  ※ --tokenは自分自身のJWT。JWTは短命のため長期運用では定期的な再取得が必要
   (期限切れ時はツールが401で明示し、認証の回避は行いません)。

【設定ファイル(--config 設定.json)】
  JSONで既定値を定義できる(コマンドライン引数が優先)。キーはロングオプション名
  (--なし、_ と - は同一視。例: "out", "split-min", "name-tpl", "info-json", "mux"):
    { "out": "./rplay_dl/<ID>", "split-min": 30,
      "name-tpl": "{creator}_{date}_{quality}_{part}", "mux": "auto" }

【保存ファイル名テンプレート(--name-tpl)】
  {date} {time} {creator} {title} {quality} {part} {ext} を置換。
  OSで禁止される文字は自動除去。未指定時は従来命名(RPLAY_<ID>_<時刻>_pN.ext)。

【サーバーへの配慮(設計方針)】
  - プレイリスト取得は配信のTARGETDURATION基準×0.6(4〜10秒)を±10%ジッタ付きで
    (公式プレイヤーと同程度の負荷。機械的な等間隔アクセスを回避)
  - セグメント取得はステータス厳密分類: 404/410=廃棄済み→即断念、
    403=60秒待機、429=30秒からの指数バックオフ(最大300秒)、5xx=時間差再試行
  - リクエスト開始間隔の下限250ms、セグメント1件ごとに15秒タイムアウト
  - TS書込順序を厳密保証(失敗しても後続を先に書かない)

【注意】
  個人利用を想定。認証の回避機能はありません(権限の無い配信は403で明示して
  終了します)。--tokenは自分自身のログイン会話を使うだけの機能です。
  レート制限を受けたらツールの指示に従いお待ちください。
"""
import argparse
import base64
import errno
import http.client
import math
import subprocess
import tempfile
from pathlib import Path
import uuid
import gzip
import hashlib
import json
import os
import random
import re
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

CDN_BASE = "https://livestream.rplay.live/live/"
API_BASE = "https://api.rplay.live"
UA_DEFAULT = "RPLAY-LiveDL/1.12 (personal archival; public endpoint)"

# v1.7.0: 公式フロントエンドと同一形状のヘッダ(Platform-Type) — はじかれない対策
HDR_API = {"Origin": "https://rplay.live", "Referer": "https://rplay.live/", "Platform-Type": "rplay"}
HDR_M3U8 = {"Referer": "https://rplay.live/"}

POLL_MIN_MS, POLL_MAX_MS, POLL_TARGET_FACTOR, JITTER = 4000, 10000, 0.6, 0.1
STANDBY_MS = 20000
SEG_MAX_TRIES = 8
SEG_TIMEOUT_S = 15
REQ_MIN_GAP_S = 0.25
CD403, CD429_BASE, CD429_MAX = 60, 30, 300

# v1.12.0: Retry-After(RFC9110 §10.2.3)準拠 — 429/503のサーバー指定待機を
# 指数バックオフより優先して尊重する(1〜300秒に丸める。既存の退避上限と一致)
def retry_after_ms(hdr_value):
    if not hdr_value:
        return 0
    try:
        n = int(str(hdr_value).strip())
        return min(max(n, 1), 300) * 1000
    except (TypeError, ValueError):
        pass
    try:
        import datetime
        import email.utils as _eu
        dt = _eu.parsedate_to_datetime(str(hdr_value).strip())
        d = (dt - datetime.datetime.now(dt.tzinfo)).total_seconds()
        if d > 0:
            return min(max(int(d) + 1, 1), 300) * 1000
    except Exception:
        pass
    return 0
END_STALL_S = 90
FLV_COOLDOWN_S = 30

# v2.5.0: 運用堅牢化(別系統v2.4.0バンドルから移植・統合)
HB_INTERVAL_S = 15      # heartbeat.jsonの書込間隔(秒・壁時計)
STALE_HB_S = 120       # --healthcheckが「新鮮」とみなす上限(秒)
DISK_CHECK_S = 30       # ディスク空き容量の点検間隔(秒)
DISK_CONFIRM_N = 2      # 連続して低と判定したら停止する回数(二重確認)
SEGINDEX_MAX = 5000    # segindexに保持するURI鍵上限(古い順に破棄)
ORPHAN_HASH_MAX = 16   # 孤立part台帳でハッシュを計算する件数上限


def _atomic_write_json(path, obj):
    """v2.5.0: 原子的JSON書込(監視プロセスが部分JSONを読まない)"""
    tmp = str(path) + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass


def guard_low(value, threshold):
    """v2.5.0(移植): 保守的ガード述語(別系統rplay_stable v1.19.2 test_guard_lowの
    移植+堅牢化)。True=低(危険)/False=安全。
    - 測定不能(None)は危険側 — v1.19.2の中核発想を継承
    - NaNは危険側(v1.19.2では比較が常にFalseになり安全側の誤判定)
    - 非数値・threshold異常・内部例外も危険側"""
    try:
        if value is None:
            return True
        v = float(value)
        if v != v:  # NaN
            return True
        return v <= float(threshold)
    except (TypeError, ValueError, OverflowError):
        return True


def free_mb(path):
    """v2.5.0(移植): pathのFS空き容量(MB)。測定不能はNone(不明=危険扱い)"""
    import shutil
    try:
        return shutil.disk_usage(str(path)).free / (1024.0 * 1024.0)
    except Exception:
        return None


def free_inodes(path):
    """v2.5.0(移植): 空きinode数(POSIXのみ・statvfs)。非対応OS/失敗はNone"""
    if not hasattr(os, "statvfs"):
        return None
    try:
        s = os.statvfs(str(path))
        return float(s.f_favail if s.f_favail > 0 else s.f_free)
    except Exception:
        return None


def heartbeat_fresh(path, max_age_sec=STALE_HB_S):
    """v2.5.0(移植): heartbeat.jsonの鮮度判定 → (新鮮?, ts)"""
    try:
        with open(path, "r", encoding="utf-8") as f:
            ts = float(json.load(f).get("ts") or 0)
        return (time.time() - ts) <= max_age_sec, ts
    except Exception:
        return False, 0.0


def webhook_post(url, event, payload=None, wait=False, level="info"):
    """v2.5.0(移植)/v2.7.0(A-04): イベント通知(--webhook)。送信はスレッド(録画を止めない)。
    3回再試行・8秒タイムアウト・429応答のRetry-After退避を優先(上限30秒)。
    失敗しても録画には影響しない。wait=True(endイベント)は非daemonスレッドで
    確実に送信を待つ。v2.7.0: level(info/warn/error)とts(ISO)を全イベントへ付与し、
    notificationEvidence用の配送計数を記録する(秘密は一切含めない)。"""
    if not url:
        return
    _notif_bump_event(event, level)

    def _go():
        body = json.dumps({"event": event, "tool": "rplay_dl.py v2.50.0", "level": level,
                           "ts": iso(time.time()), **(payload or {})}).encode("utf-8")
        for attempt in range(3):
            delay = 0.3 * (2 ** attempt)
            try:
                req = urllib.request.Request(
                    url, data=body, method="POST",
                    headers={"Content-Type": "application/json", "User-Agent": UA_DEFAULT})
                with urllib.request.urlopen(req, timeout=8) as r:
                    if 200 <= r.status < 300:
                        _notif_bump("sent")
                        return
            except urllib.error.HTTPError as e:
                ra = 0
                if e.code == 429:  # v2.7.0(A-04): 退避を優先(呼びすぎない)
                    _notif_bump("rateLimited429")
                    try:
                        ra = retry_after_ms(e.headers.get("Retry-After")) if e.headers else 0
                    except Exception:
                        ra = 0
                try:
                    e.close()
                except Exception:
                    pass
                if ra:
                    delay = max(delay, min(ra, 30000) / 1000.0)
            except Exception:
                pass
            if attempt < 2:
                time.sleep(delay)
        _notif_bump("failed")

    threading.Thread(target=_go, daemon=not wait).start()


_NOTIF_LOCK = threading.Lock()
_NOTIF_STATS = {"events": {}, "lastEvent": None, "rateLimited429": 0, "sent": 0, "failed": 0}


def _notif_bump(key):
    """v2.7.0(A-04): notificationEvidence用の配送計数(内部用)。"""
    with _NOTIF_LOCK:
        _NOTIF_STATS[key] = _NOTIF_STATS.get(key, 0) + 1


def _notif_bump_event(event, level):
    """v2.7.0(A-04): イベント発生の計数(送信成否とは独立・呼び出し時点)。"""
    with _NOTIF_LOCK:
        ev = _NOTIF_STATS["events"]
        ev[event] = ev.get(event, 0) + 1
        _NOTIF_STATS["lastEvent"] = {"event": event, "level": level, "ts": iso(time.time())}


def notification_stats(reset=False):
    """v2.7.0(A-04): webhook配送計数のスナップショット(notificationEvidence用)。
    reset=Trueは試験用の初期化。証拠にはイベント種別と回数のみを含む(秘密なし)。"""
    with _NOTIF_LOCK:
        if reset:
            _NOTIF_STATS.update({"events": {}, "lastEvent": None,
                                 "rateLimited429": 0, "sent": 0, "failed": 0})
        snap = dict(_NOTIF_STATS)
        snap["events"] = dict(_NOTIF_STATS["events"])
        snap["provenance"] = "webhook_delivery_counters"
        return snap


def redact_url(u):
    """v2.5.0(P2): 診断出力用URL秘匿 — クエリ(署名/key2)とフラグメントを除去し
    origin+pathだけを残す。RAM内の取得経路は変更しない(出力のみの変換)。"""
    if not u:
        return u
    try:
        p = urllib.parse.urlsplit(str(u))
        return urllib.parse.urlunsplit((p.scheme, p.netloc, p.path, "", ""))
    except Exception:
        return str(u)


# ---- v2.7.0(A-01/A-02): 認証資格の供給と更新(auth_store抽象) ----
# ---- v2.8.0(W-01/W-02/W-03): Butter署名生成・streamStartTime 10分閾値追跡・4層ErrorKind分類 ----
BUTTER_KEY = b"S%M@#H#B(!@()a2@"              # 16 bytes
BUTTER_SALT = b"QWI@(!WAS)Dj1AA(!@*DJ#@$@~1)P"  # 29 bytes
_BUTTER_ORIGIN_17 = b"https://rplay.live"[:17]  # WebCrypto版(BUTTER_SALT.length + 17 + ts.length)と完全一致
_BUTTER_CACHE = {"bucket": -1, "hex": ""}


def generate_butter_token(now_s=None):
    """v2.8.0(W-01): RPLAYフロントエンド/userscriptと完全バイト一致のAES-128-CBC Butter署名(128桁hex)。
    360秒(6分)バケット単位でキャッシュする。"""
    t = float(time.time() if now_s is None else now_s)
    bucket = int(t // 360)
    if now_s is None and _BUTTER_CACHE["bucket"] == bucket and _BUTTER_CACHE["hex"]:
        return _BUTTER_CACHE["hex"]
    ts_bytes = str(bucket).encode("utf-8")
    iv = ts_bytes.rjust(16, b"0")[:16]
    clear = BUTTER_SALT + _BUTTER_ORIGIN_17 + ts_bytes
    pad_len = 16 - (len(clear) % 16)
    padded = clear + bytes([pad_len] * pad_len)
    hex_out = ""
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        cipher = Cipher(algorithms.AES(BUTTER_KEY), modes.CBC(iv))
        enc = cipher.encryptor()
        ct = enc.update(padded) + enc.finalize()
        hex_out = ct.hex()
    except Exception:
        import subprocess
        p = subprocess.run(
            ["openssl", "enc", "-aes-128-cbc", "-nopad", "-K", BUTTER_KEY.hex(), "-iv", iv.hex()],
            input=padded, capture_output=True, timeout=5)
        if p.returncode == 0 and p.stdout:
            hex_out = p.stdout.hex()
    if now_s is None and hex_out:
        _BUTTER_CACHE["bucket"] = bucket
        _BUTTER_CACHE["hex"] = hex_out
    return hex_out


def parse_stream_start_sec(val):
    """v2.8.0(W-02): streamStartTime / startedAt (ISO文字列・秒/ミリ秒数値)をエポック秒(float)に正規化。"""
    if val is None or val == "":
        return None
    if isinstance(val, (int, float)) and not isinstance(val, bool):
        v = float(val)
        if not math.isfinite(v) or v <= 0:
            return None
        return float(int(v // 1000)) if v > 1e11 else float(int(v))
    s = str(val).strip()
    if not s:
        return None
    if re.fullmatch(r"\d+(\.\d+)?", s):
        v = float(s)
        return float(int(v // 1000)) if v > 1e11 else float(int(v))
    try:
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return float(int(dt.timestamp()))
    except Exception:
        return None


def classify_session_change(prev_val, next_val, threshold_sec=600):
    """v2.8.0(W-02): streamStartTimeの変化を10分(600秒)閾値で分類(userscript rspClassifySessionChangeと完全鏡像)。"""
    th = int(threshold_sec) if isinstance(threshold_sec, (int, float)) and threshold_sec > 0 else 600
    p = parse_stream_start_sec(prev_val)
    n = parse_stream_start_sec(next_val)
    if p is None and n is None:
        return {"changed": False, "gapSec": None, "classification": "unknown", "thresholdSec": th}
    if p is None and n is not None:
        return {"changed": False, "gapSec": 0, "classification": "initial", "thresholdSec": th}
    if p is not None and n is None:
        return {"changed": False, "gapSec": None, "classification": "unknown", "thresholdSec": th}
    gap = int(abs(n - p))
    if gap == 0:
        return {"changed": False, "gapSec": 0, "classification": "unchanged", "thresholdSec": th}
    return {
        "changed": True,
        "gapSec": gap,
        "classification": ("same_session_resumed" if gap <= th else "new_session_split"),
        "thresholdSec": th,
    }


def session_tracking_evidence(tracker):
    """v2.8.0(W-02): sessionTrackingEvidence証拠ブロック(情報JSON/ledger用)。"""
    t = tracker or {}
    return {
        "initialStreamStartSec": t.get("initialStreamStartSec"),
        "latestStreamStartSec": t.get("latestStreamStartSec"),
        "thresholdSec": int(t.get("thresholdSec") or 600),
        "sameSessionResumes": int(t.get("sameSessionResumes") or 0),
        "newSessionSplits": int(t.get("newSessionSplits") or 0),
        "transitions": list(t.get("transitions") or [])[:20],
        "provenance": "stream_start_time_10min_threshold",
    }


def error_taxonomy_evidence(counts):
    """v2.8.0(W-03): rplay_watcher v0.5.0 ErrorKind 4層分類に基づくerrorTaxonomyEvidence証拠ブロック。"""
    c = counts or {}
    norm = {
        "SOURCE": int(c.get("SOURCE") or 0),
        "NETWORK": int(c.get("NETWORK") or 0),
        "AUTH": int(c.get("AUTH") or 0),
        "PLATFORM": int(c.get("PLATFORM") or 0),
        "COMPATIBILITY": int(c.get("COMPATIBILITY") or 0),
        "INTERNAL": int(c.get("INTERNAL") or 0),
    }
    return {
        "counts": norm,
        "recoverableCount": norm["SOURCE"] + norm["NETWORK"] + norm["AUTH"],
        "sourceFailureCount": norm["SOURCE"],
        "provenance": "rplay_watcher_error_kind_v050",
    }


def detect_paywall_blocked(master_status, media_status):
    """v2.11.0(W-07): rplay_watcher v0.5.2知見 — Master playlistが200を返しつつ
    Media playlist(バリアント)が404または403を返す非対称応答は有料壁(paywall_blocked)として検出。
    userscript rspDetectPaywallBlocked と完全鏡像。"""
    try:
        return int(master_status) == 200 and int(media_status) in (404, 403)
    except (TypeError, ValueError):
        return False


def part_continuity_evidence(c):
    """v2.11.0(W-05/W-06): TS細切れ防止・単一ファイル継続の証拠ブロック(userscript rspPartContinuityEvidence と完全鏡像)。"""
    o = c or {}
    return {
        "splitMinutes": int(o.get("splitMinutes") or 0),
        "maxSizeMb": int(o.get("maxSizeMb") or 600),
        "splitOnDiscontinuity": bool(o.get("splitOnDiscontinuity")),
        "discontinuityMergedCount": int(o.get("discontinuityMergedCount") or 0),
        "discontinuitySplitCount": int(o.get("discontinuitySplitCount") or 0),
        "sameSessionStandbyContinuations": int(o.get("sameSessionStandbyContinuations") or 0),
        "partsConcatenated": int(o.get("partsConcatenated") or 0),
        "concatOutput": (str(o.get("concatOutput")) if o.get("concatOutput") else None),
        "provenance": "vdh_coapp_and_streamlink_ts_continuity_v2100",
    }


def build_m3u8dl_export(url, save_name="RPLAY_stream", headers=None, live_real_time_merge=True):
    """v2.15.0(C-03): cat-catch "调用m3u8DL下载" 互換の m3u8dl:// カスタムプロトコルURIと
    N_m3u8DL-RE コマンドライン文字列を生成する(userscript rspBuildM3u8dlExport と完全鏡像)。"""
    u = str(url or "").strip()
    sname = re.sub(r'["\\]', "_", str(save_name or "RPLAY_stream"))
    hdrs = headers if isinstance(headers, dict) else {}
    h_keys = sorted(k for k, v in hdrs.items() if v is not None and str(v) != "")
    args = ['"%s"' % u, '--save-name "%s"' % sname]
    for k in h_keys:
        v = str(hdrs[k]).replace('"', '\\"')
        args.append('--header "%s: %s"' % (k, v))
    if live_real_time_merge:
        args.append("--live-real-time-merge")
        args.append("--live-pipe-mux")
    param_str = " ".join(args)
    b64 = base64.b64encode(param_str.encode("utf-8")).decode("ascii")
    return {
        "protocolUri": "m3u8dl://" + b64,
        "command": "N_m3u8DL-RE " + param_str,
        "targetUrl": (u.split("?")[0].split("#")[0] if u else None),
        "saveName": sname,
        "headerKeys": h_keys,
        "liveRealTimeMerge": bool(live_real_time_merge),
    }


def external_downloader_evidence(exp, stats=None):
    """v2.15.0(C-01/C-02/C-03): cat-catch知見(TS偽装ヘッダ除去・クエリ継承・m3u8dl連携)の
    ゼロ秘密証拠ブロック(userscript rspExternalDownloaderEvidence と完全鏡像)。"""
    e = exp or {}
    s = stats or {}
    raw_target = str(e.get("targetUrl") or e.get("url") or "")
    clean_target = raw_target.split("?")[0].split("#")[0] if raw_target else None
    h_keys = sorted(str(k) for k in (e.get("headerKeys") or []))
    return {
        "protocolScheme": "m3u8dl",
        "targetUrl": clean_target,
        "saveName": (str(e["saveName"]) if e.get("saveName") else None),
        "headerKeys": h_keys,
        "liveRealTimeMerge": bool(e.get("liveRealTimeMerge", True)),
        "tsDisguiseStrippedCount": int(s.get("tsDisguiseStrippedCount") or 0),
        "tsDisguiseBytesTotal": int(s.get("tsDisguiseBytesTotal") or 0),
        "queryInheritedCount": int(s.get("queryInheritedCount") or 0),
        "provenance": "cat_catch_m3u8dl_and_preprocessor_v2120",
    }


AUTH_JWT_KEYS = ("jwt", "token", "accessToken", "authorization")


def parse_secret_spec(spec):
    """v2.7.0(A-01): 秘密の供給指定を解析 → (値, 供給源種別)。
    形式: 値直接 / env:<環境変数名> / file:<パス>。空指定は ('','')。
    読み取り失敗(変数未定義・ファイル不在)は空値を返し、供給源種別だけ残す
    (起動時に警告して録画は続行 — 秘密を例外やログへ出さない)。"""
    s = (spec or "").strip()
    if not s:
        return "", ""
    if s.startswith("env:"):
        name = s[4:].strip()
        return (os.environ.get(name, "") or ""), "env"
    if s.startswith("file:"):
        fp = s[5:].strip()
        try:
            with open(fp, "r", encoding="utf-8") as f:
                return f.read().strip(), "file"
        except Exception:
            return "", "file"
    return s, "value"


def jwt_expiry(jwt_s):
    """v2.7.0(A-01): JWTのpayloadが主張するexpを返す(検証なし・読めなければ0)。
    leeway判定のための参考値であって検証手段ではない。値(秘密)は返さない。"""
    try:
        parts = str(jwt_s).split(".")
        if len(parts) < 2:
            return 0.0
        pad = parts[1] + "=" * (-len(parts[1]) % 4)
        payload = json.loads(base64.urlsafe_b64decode(pad).decode("utf-8", "replace"))
        return float(payload.get("exp") or 0)
    except Exception:
        return 0.0


def _jwt_oid_claim(jwt_s):
    """v2.7.0(A-01): JWT payloadのoid主張(userscriptと同候補)。24桁hexのみ採用。"""
    try:
        parts = str(jwt_s).split(".")
        if len(parts) < 2:
            return ""
        pad = parts[1] + "=" * (-len(parts[1]) % 4)
        payload = json.loads(base64.urlsafe_b64decode(pad).decode("utf-8", "replace"))
        for k in ("oid", "userOid", "userId", "_id"):
            v = payload.get(k)
            if isinstance(v, str) and re.fullmatch(r"[0-9a-f]{24}", v):
                return v
        sub = payload.get("sub")
        if isinstance(sub, str) and re.fullmatch(r"[0-9a-f]{24}", sub):
            return sub
    except Exception:
        pass
    return ""


class AuthStore:
    """v2.7.0(A-01/A-02): 認証資格の供給・更新・401分類の契約。
    供給源: --token(静的JWT・明示指定で一次) / --refresh-token(値/env/file)。
    更新契約: refresh-token APIで短命JWTを取得し、expのleeway(300秒)前に再取得。
    失敗はMAX_ATTEMPTS回再試行(指数バックオフ)し、60秒クールダウンで連打を防ぐ。
    401分類: no_credentials / invalid_or_expired / refreshed / refresh_failed。
    認証の回避は行わない(自分の資格のみ・権限の無い配信にはアクセスしない)。
    秘密(トークン値)はevidence()にもログにも一切出さない。"""

    LEEWAY_S = 300.0
    MAX_ATTEMPTS = 3
    REFRESH_COOLDOWN_S = 60.0

    def __init__(self, api_base, http_fn=None, log_fn=None, token="",
                 refresh_spec="", user_oid=""):
        self.api = (api_base or "").rstrip("/")
        self._http = http_fn
        self.log = log_fn or (lambda msg: None)
        self.token = (token or "").strip()
        self.refresh_value, self.refresh_source = parse_secret_spec(refresh_spec)
        self.user_oid = (user_oid or "").strip()
        if self.token and self.refresh_value:
            self.mode = "token+refresh"
        elif self.token:
            self.mode = "static-token"
        elif self.refresh_value:
            self.mode = "refresh-token"
        else:
            self.mode = "none"
        # 状態(秘密は除く計数のみを証拠化)
        self._jwt = self.token
        self._jwt_exp = jwt_expiry(self.token) if self.token else 0.0
        self._jwt_from = "static" if self.token else ""
        self.switched = False
        self.refresh_attempts = 0
        self.refresh_successes = 0
        self.refresh_failures = 0
        self.refresh_key = ""
        self._classes = {}
        self.key2_resolutions = 0
        self.butter_sends = 0
        self._last_refresh_fail_at = 0.0
        self._sleep = time.sleep

    # ---- 更新ループ ----
    def _do_refresh_http(self):
        url = self.api + "/rplay/account/refresh-token"
        headers = {"User-Agent": UA_DEFAULT, "Content-Type": "application/json",
                   **dict(HDR_API), "Refresh-Token": self.refresh_value}
        if self._jwt:
            headers["Authorization"] = self._jwt
        if self._http is not None:
            return self._http(url, 8, headers, method="POST", data=b"{}")
        req = urllib.request.Request(url, data=b"{}", method="POST", headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=8) as r:
                limit = 1048576
                chunks = []
                size = 0
                while True:
                    chunk = r.read1(min(65536, limit + 1 - size))
                    if not chunk:
                        break
                    size += len(chunk)
                    if size > limit:
                        break
                    chunks.append(chunk)
                return r.status, b"".join(chunks), 0
        except urllib.error.HTTPError as e:
            code = e.code
            try:
                e.close()
            except Exception:
                pass
            return code, None, 0
        except Exception:
            return 0, None, 0

    def _parse_refresh_response(self, st, body):
        """応答→(jwt, 応答鍵)。鍵候補は形状証拠として記録する(実測で確定させる)。"""
        if st != 200 or not body:
            return "", ""
        try:
            j = json.loads(body.decode("utf-8", "replace"))
        except Exception:
            return "", ""
        if not isinstance(j, dict):
            return "", ""
        for k in AUTH_JWT_KEYS:
            v = j.get(k)
            if isinstance(v, str) and v.strip() and v.count(".") >= 2:
                return v.strip(), k
        return "", ""

    def refresh_now(self):
        """refresh-token APIで短命JWTを再取得(MAX_ATTEMPTS回・指数バックオフ)。"""
        for attempt in range(self.MAX_ATTEMPTS):
            self.refresh_attempts += 1
            st, body, _ra = self._do_refresh_http()
            jwt, key = self._parse_refresh_response(st, body)
            if jwt:
                self.refresh_successes += 1
                self._jwt = jwt
                self._jwt_exp = jwt_expiry(jwt)
                self._jwt_from = "refreshed"
                self.refresh_key = key
                self.log("認証トークンを更新しました(refresh-token・供給源:%s)" % self.refresh_source)
                return True
            self.refresh_failures += 1
            self._last_refresh_fail_at = time.time()
            self._sleep(0.2 * (2 ** attempt))
        self.log("トークン更新に失敗(refresh-token・%d回試行) — 既存の資格で継続します" % self.MAX_ATTEMPTS)
        return False

    def ensure_jwt(self):
        """現在有効なJWTを返す(必要なら更新)。leeway前に再取得する契約。"""
        if self.mode == "none":
            return ""
        if self._jwt and self._jwt_exp <= 0:
            return self._jwt          # exp不明の静的JWTはそのまま使う(更新しない)
        if self._jwt and (self._jwt_exp - time.time()) > self.LEEWAY_S:
            return self._jwt          # 十分新鮮
        if self.refresh_value:
            if self._jwt or self.mode in ("refresh-token", "token+refresh"):
                if self.refresh_now():
                    return self._jwt
        return self._jwt               # 更新失敗/不能時は既存値(呼び側が401を分類)

    # ---- 401分類 ----
    def note_401(self, context="api"):
        """401応答の分類(計数のみ・秘密は出さない)。戻り値: 分類コード。
        refresh資格がある場合は即座に更新を試み、成功なら次の呼び出しは新JWT。"""
        if self.mode == "none":
            return self._bump("no_credentials")
        if self.refresh_value:
            cooled = (time.time() - self._last_refresh_fail_at) >= self.REFRESH_COOLDOWN_S
            if self._jwt_from == "static":
                self.switched = True
            if cooled and self.refresh_now():
                return self._bump("refreshed")
            if not cooled:
                return self._bump("refresh_failed")
            return self._bump("refresh_failed")
        return self._bump("invalid_or_expired")

    def _bump(self, code):
        self._classes[code] = self._classes.get(code, 0) + 1
        return code

    def note_key2(self):
        """key2再解決の成功計数(authEvidence.key2Resolutions)。"""
        self.key2_resolutions += 1

    def note_butter(self):
        """v2.8.0(W-01): Butter署名ヘッダ送出の計数(authEvidence.butterSent)。"""
        self.butter_sends = getattr(self, "butter_sends", 0) + 1

    def requestor_params(self):
        """APIクエリのrequestor補完(ログイン時相当)。--user-oid優先、無ければJWT主張。"""
        oid = self.user_oid or _jwt_oid_claim(self._jwt)
        return {"requestorOid": oid, "loginType": "rplay"} if oid else {}

    def evidence(self):
        """v2.7.0(A-02): authEvidence証拠ブロック。秘密(トークン値)は含まない。"""
        return {
            "mode": self.mode,
            "tokenSource": ("cli" if self.token else None),
            "refreshSource": (self.refresh_source or None),
            "userOidSupplied": bool(self.user_oid),
            "switchedToRefresh": bool(self.switched),
            "refreshAttempts": self.refresh_attempts,
            "refreshSuccesses": self.refresh_successes,
            "refreshFailures": self.refresh_failures,
            "responseKey": (self.refresh_key or None),
            "classifications401": dict(self._classes),
            "key2Resolutions": self.key2_resolutions,
            "butterSent": bool(getattr(self, "butter_sends", 0) > 0),
            "provenance": "auth_store_counters",
            "note": "秘密(トークン値)は含まない。responseKeyはrefresh-token応答の形状証拠"
                    "(応答鍵は実測P-02で確定させる)",
        }


# ---- v2.7.0(A-03): サイト更新検知のcanary ----
CANARY_EXPECTED_KEYS = ("bytePlusPlaybackUrl", "playUrl", "streamState", "accessible",
                        "tierHashes", "useRplayStreamServer", "allowAnonymous", "title")


def canary_check(info):
    """v2.7.0(A-03): live/play応答形状のcanary検証 → 辞書。
    result: 'ok'(既知鍵あり) / 'shape_change'(辞書だが既知鍵ゼロ) / 'unreachable'。
    観察するのは鍵の一覧のみ(値・秘密は出さない)。userscriptのrspCanaryCheckと鏡像。"""
    if not isinstance(info, dict) or not info:
        return {"result": "unreachable", "observedKeys": [], "knownKeys": []}
    observed = [str(k) for k in info.keys()]
    known = [k for k in observed if k in CANARY_EXPECTED_KEYS]
    return {"result": ("ok" if known else "shape_change"),
            "observedKeys": sorted(observed)[:24],
            "knownKeys": sorted(known)}


def canary_evidence(res):
    """v2.7.0(A-03): canaryEvidence証拠ブロック(情報JSON用)。"""
    return {"result": res["result"], "observedKeys": res["observedKeys"],
            "knownKeys": res["knownKeys"], "checkedAt": iso(time.time()),
            "action": "warn_only",
            "provenance": "live_play_response_shape"}


def segindex_load(path):
    """v2.5.0: 前回保存した既知URI鍵(path+range・署名を含まない)を読込。
    署名クエリを除いた鍵なので、再起動時に鍵が更新されても同一セグメントを
    重複取得しない(旧実装の完全URL照合よりも安定)。"""
    try:
        with open(path, "r", encoding="utf-8") as f:
            d = json.load(f)
        return ([str(u) for u in (d.get("seen") or [])][:SEGINDEX_MAX],
                [str(u) for u in (d.get("audioSeen") or [])][:SEGINDEX_MAX])
    except Exception:
        return [], []


def segindex_save(path, seen_iter, aseen_iter):
    segindex = {"seen": list(seen_iter)[-SEGINDEX_MAX:],
                "audioSeen": list(aseen_iter)[-SEGINDEX_MAX:]}
    _atomic_write_json(path, segindex)


def seg_key(item):
    """v2.5.0: 書込済みセグメントの永続鍵 — hls_uri_keyと同一規則
    (URLから署名クエリ/フラグメントを除いた全体+byte range)。ディスクに秘密を残さない。"""
    d = item.get("hls") if isinstance(item, dict) else None
    if d and d.get("uri"):
        return hls_uri_key(d)
    raw = (item.get("base", "") + item.get("name", "")) if isinstance(item, dict) else str(item or "")
    return raw.split("?")[0].split("#")[0]


def ffprobe_tool():
    import shutil
    return shutil.which("ffprobe")


def ffmpeg_tool():
    import shutil
    return shutil.which("ffmpeg")


def _ffrun(cmd, timeout):
    import subprocess
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except Exception:
        return None


def _timebase_seconds(tb):
    """ffprobeのtime_base("1/90000"形式)を秒換算する。不正値はNone。"""
    try:
        if isinstance(tb, str) and "/" in tb:
            n, d = tb.split("/", 1)
            n, d = float(n), float(d)
            return (n / d) if d else None
        return float(tb) if tb is not None else None
    except (TypeError, ValueError, ZeroDivisionError):
        return None


def qaudit_part(path, log=None):
    """v2.5.0(P1)/v2.6.0(P1): 保存パート1本の実メディア品質監査(ffprobe/ffmpeg)。
    マニフェスト宣言値(PDT/EXTINF)ではなく、実際にデコードした証拠で判定する:
    - ストリーム構成(codec/timebase/開始PTS/長さ/フレーム数・音声サンプルレート)
    - v2.6.0: ストリーム毎の実デコード時間(durationTs×timebase→durationSec)と
      パート代表値(decodedDurationSec) — 分離音声との相関(qaudit_av_correlation)
      の入力証拠
    - PTS/DTS単調性(減少=破損の証拠。前方ジャンプ=不連続の記録)
    - ffmpeg全編デコードのエラーライン(最大5件まで記録)
    verdict: pass / decode_errors / pts_regression / probe_failed
    ※「PDT上の一致だけでは品質合格にしない」(開発計画P1のDone基準)。"""
    import subprocess
    out = {"file": os.path.basename(path), "bytes": 0, "provenance": "decoded",
           "streams": [], "packets": {}, "decodeErrors": [], "verdict": "probe_failed"}
    try:
        out["bytes"] = os.path.getsize(path)
    except OSError:
        return out
    fp = ffprobe_tool()
    if not fp:
        out["verdict"] = "ffprobe_unavailable"
        return out
    r = _ffrun([fp, "-v", "error", "-print_format", "json", "-show_streams", "-show_format", path], 120)
    if r is None or r.returncode != 0 or not r.stdout.strip():
        if r is not None and r.stderr:
            out["probeError"] = r.stderr.strip()[:200]
        return out
    try:
        j = json.loads(r.stdout)
    except ValueError:
        return out
    fmt = j.get("format") or {}
    out["formatDurationSec"] = round(float(fmt.get("duration") or 0), 3)
    for st in (j.get("streams") or []):
        e = {"index": st.get("index"), "codecType": st.get("codec_type"),
             "codec": st.get("codec_name"), "timeBase": st.get("time_base")}
        try:
            e["startPts"] = int(st.get("start_pts") or 0)
            e["durationTs"] = int(st.get("duration_ts") or 0)
        except (TypeError, ValueError):
            pass
        tb = _timebase_seconds(st.get("time_base"))
        if tb and isinstance(e.get("durationTs"), int) and e["durationTs"] > 0:
            e["durationSec"] = round(e["durationTs"] * tb, 3)
        if st.get("codec_type") == "video":
            e["width"], e["height"] = st.get("width"), st.get("height")
            e["avgFrameRate"] = st.get("avg_frame_rate")
            try:
                e["nbFrames"] = int(st.get("nb_frames") or 0)
            except (TypeError, ValueError):
                e["nbFrames"] = None
        elif st.get("codec_type") == "audio":
            e["sampleRate"] = st.get("sample_rate")
            e["channels"] = st.get("channels")
        out["streams"].append(e)
    # v2.6.0(P1): パート代表の実デコード時間(ストリーム最大値。無ければformat値)
    durs = [s.get("durationSec") for s in out["streams"] if isinstance(s.get("durationSec"), (int, float)) and s["durationSec"] > 0]
    if durs:
        out["decodedDurationSec"] = round(max(durs), 3)
    elif out["formatDurationSec"]:
        out["decodedDurationSec"] = out["formatDurationSec"]
    # パケット単位のPTS/DTS単調性(減少だけを破損証拠にする)
    r = _ffrun([fp, "-v", "error", "-print_format", "json", "-show_packets",
                "-show_entries", "packet=stream_index,pts_time,dts_time", path], 300)
    if r is not None and r.returncode == 0 and r.stdout.strip():
        try:
            pk = json.loads(r.stdout).get("packets") or []
            last = {}
            for p in pk:
                si = p.get("stream_index")
                for field in ("pts_time", "dts_time"):
                    v = p.get(field)
                    if v is None:
                        continue
                    try:
                        v = float(v)
                    except (TypeError, ValueError):
                        continue
                    k = (si, field)
                    if k in last and v < last[k] - 1e-9:
                        st_key = str(si)
                        agg = out["packets"].setdefault(st_key, {"count": 0, "nonMonotonicPts": 0, "nonMonotonicDts": 0})
                        agg["nonMonotonicDts" if field == "dts_time" else "nonMonotonicPts"] += 1
                    last[k] = v
            for p in pk:
                si = str(p.get("stream_index"))
                agg = out["packets"].setdefault(si, {"count": 0, "nonMonotonicPts": 0, "nonMonotonicDts": 0})
                agg["count"] += 1
        except ValueError:
            pass
    ff = ffmpeg_tool()
    if ff:
        r = _ffrun([ff, "-v", "error", "-i", path, "-f", "null", "-"], 600)
        if r is not None and r.stderr:
            # rc=0でもエラーラインは品質証拠として記録する(全編デコード監査)
            out["decodeErrors"] = [ln for ln in r.stderr.splitlines() if ln.strip()][:5]
    non_mono = sum((v.get("nonMonotonicPts") or 0) + (v.get("nonMonotonicDts") or 0) for v in out["packets"].values())
    if out["decodeErrors"]:
        out["verdict"] = "decode_errors"
    elif non_mono:
        out["verdict"] = "pts_regression"
    elif out["streams"]:
        out["verdict"] = "pass"
    return out

OID_RE = re.compile(r"([0-9a-f]{16,40})")


def qaudit_av_correlation(parts, tolerance_ratio=0.02, absolute_floor_s=0.5):
    """v2.6.0(P1): 分離音声レンディションと映像の実デコード時間相関。
    qaudit_partが実測したパート毎のdecodedDurationSecをトラック単位で集計し、
    量の整合(drift)を証拠化する:
    - 判定は実デコード証拠(provenance=decoded)のみ — 両トラックの証拠が
      揃わない場合はinsufficientとして相関を主張しない
    - PTS原点はトラック毎に独立しているため、原点差ではなく「量」で比較する
      (同期の最終確認は2トラックmux後の再生で行う — ここでは量の整合のみ主張)
    - verdict: pass / av_drift_suspect / insufficient
    """
    sums = {"video": 0.0, "audio": 0.0}
    counts = {"video": 0, "audio": 0}
    for e in parts or []:
        track = e.get("track") or "video"
        qa = e.get("qualityAudit") or {}
        if track not in sums or qa.get("provenance") != "decoded":
            continue
        dur = qa.get("decodedDurationSec")
        if isinstance(dur, (int, float)) and dur > 0:
            sums[track] += float(dur)
            counts[track] += 1
    result = {"provenance": "decoded", "videoParts": counts["video"], "audioParts": counts["audio"]}
    if not counts["video"] or not counts["audio"]:
        result["verdict"] = "insufficient"
        result["note"] = "両トラックの実デコード時間証拠が揃わないため相関判定しない"
        return result
    drift = sums["audio"] - sums["video"]
    tol = max(tolerance_ratio * sums["video"], absolute_floor_s)
    result.update({
        "videoDurationSec": round(sums["video"], 3),
        "audioDurationSec": round(sums["audio"], 3),
        "driftSec": round(drift, 3),
        "driftRatio": (round(drift / sums["video"], 4) if sums["video"] else None),
        "toleranceSec": round(tol, 3),
        "verdict": ("pass" if abs(drift) <= tol else "av_drift_suspect"),
        "note": "分離音声との実デコード時間相関(量の整合)。原点同期はmux後再生で最終確認",
    })
    return result

# v1.9.0: 画質選択(最高画質)の定数
QUALITY_RESCAN_S = 300      # master再走査(画質昇格チェック)の間隔
QUALITY_FALLBACK_S = 30     # バリアント消失時フォールバックの節流

# v1.11.0: 音声レンディション録画の定数(映像と同一ポリシー・カウンタは独立)
A_OFFSET_MIN_MS, A_OFFSET_MAX_MS = 300, 500  # 映像ループ開始からの要求オフセット
A_STALL_S = 90                                # 新音声セグメント停止90秒で停止


def remux_mp4(ts_path, log, ctx=None):
    """TS→MP4へストリームコピー(-c copy)で無劣化リマックス(N_m3u8DL-REのmuxer相当)。
    再エンコードを行わないため画質は無劣化のまま。失敗時はTSのまま残す。
    v2.7.0(A-05): ctx(分かる値のみ)をrplay_metadata_version=1互換タグとして埋め込む。
    未知の値は埋めない(契約)。"""
    import shutil
    import subprocess
    ff = shutil.which("ffmpeg")
    if not ff:
        log("ffmpegが見つからずMP4化をスキップ(TSのまま保存)")
        return False
    out = ts_path[:-3] + ".mp4"
    try:
        r = subprocess.run([ff, "-y", "-loglevel", "error", "-i", ts_path,
                            "-c", "copy", "-movflags", "+faststart+use_metadata_tags"] +
                           mp4_metadata_args(ctx) + [out],
                           capture_output=True, text=True, timeout=1800)
        if r.returncode == 0 and os.path.exists(out) and os.path.getsize(out) > 0:
            log("MP4へリマックス(無劣化・ストリームコピー): %s (%.1fMB) タグ%d種" % (
                os.path.basename(out), os.path.getsize(out) / 1048576,
                len(mp4_metadata_tags(ctx))))
            return True
        log("ffmpegリマックス失敗(%s) — TSのまま保存" % ((r.stderr or "").strip()[:90] or "rc=%d" % r.returncode))
    except Exception as e:
        log("ffmpegリマックス失敗(%s) — TSのまま保存" % e)
    return False


# ---- v2.7.0(A-05): MP4メタデータタグ(rplay_metadata_version=1互換) ----
MP4_METADATA_VERSION = 1
MP4_TAG_MAP = (("creator_oid", "creatorOid"), ("stream_oid", "streamOid"),
               ("stream_start_time", "streamStartedAt"),
               ("recording_started_at", "recordingStartedAt"),
               ("title", "title"), ("artist", "artist"))


def mp4_metadata_tags(ctx):
    """v2.7.0(A-05): 埋め込むタグ鍵の一覧。未知の値は埋めない(常にversionは入る)。"""
    tags = ["rplay_metadata_version"]
    for tag, key in MP4_TAG_MAP:
        if (ctx or {}).get(key):
            tags.append(tag)
    return tags


def mp4_metadata_args(ctx):
    """v2.7.0(A-05): ffmpeg -metadata引数群。分かる値だけを埋める(未知値は省く)。"""
    args = []
    key_by_tag = dict(MP4_TAG_MAP)
    for tag in mp4_metadata_tags(ctx):
        if tag == "rplay_metadata_version":
            value = str(MP4_METADATA_VERSION)
        else:
            value = str((ctx or {}).get(key_by_tag.get(tag)) or "")
        args += ["-metadata", "%s=%s" % (tag, value)]
    return args


def metadata_evidence(events):
    """v2.7.0(A-05): metadataEvidence証拠ブロック(情報JSON用)。
    埋め込み結果のタグ鍵一覧を記録(値の検証はffprobe手順=試験側)。"""
    files = [{"file": (e or {}).get("file"), "tags": (e or {}).get("tags", [])}
             for e in (events or [])]
    return {"embedded": any(f["tags"] for f in files),
            "version": MP4_METADATA_VERSION,
            "files": files,
            "provenance": "ffmpeg_metadata_args",
            "note": "未知の値は埋めない契約(分かる値だけ)。埋め込み結果はffprobe "
                    "-show_entries format_tagsで確認する手順を試験に組込み済み"}


def mux_two_track(video_ts, audio_ts, out_path, log, ctx=None):
    """v1.11.0: 映像TS+音声TSの2トラックmux(ffmpeg -c copy・無劣化)。
    片方でも失敗した場合はTSのまま残す(映像/音声の単独ファイルで利用可)。
    v2.7.0(A-05): ctx(分かる値のみ)をrplay_metadata_version=1互換タグとして埋め込む。"""
    import shutil
    import subprocess
    ff = shutil.which("ffmpeg")
    if not ff:
        log("ffmpegが見つからず2トラックmuxをスキップ(TSのまま保存)")
        return False
    try:
        r = subprocess.run([ff, "-y", "-loglevel", "error", "-i", video_ts, "-i", audio_ts,
                            "-map", "0:v:0", "-map", "1:a:0", "-c", "copy",
                            "-movflags", "+faststart+use_metadata_tags"] +
                           mp4_metadata_args(ctx) + [out_path],
                           capture_output=True, text=True, timeout=1800)
        if r.returncode == 0 and os.path.exists(out_path) and os.path.getsize(out_path) > 0:
            log("2トラックMP4を生成(映像+音声・無劣化): %s (%.1fMB)" % (
                os.path.basename(out_path), os.path.getsize(out_path) / 1048576))
            return True
        log("2トラックmux失敗(%s) — TSのまま保存" % ((r.stderr or "").strip()[:90] or "rc=%d" % r.returncode))
    except Exception as e:
        log("2トラックmux失敗(%s) — TSのまま保存" % e)
    return False


def concat_media_parts(part_paths, out_path, log, ctx=None, mode="auto"):
    """v2.11.0(W-06): Video DownloadHelper CoApp(vdhcoapp)およびN_m3u8DL-REの知見に基づく
    複数パート無劣化結合。
    - mode="ts" または ffmpeg不在かつ全入力が.tsかつ出力が.tsの場合はバイナリ連結(MPEG-TSは
      188バイトパケット境界が保たれていればそのまま連結可能)。
    - それ以外は ffmpeg concat demuxer (-f concat -safe 0 -i list.txt -c copy) で無劣化結合し、
      MP4出力時は rplay_metadata_version=1 タグと +faststart を付与する。"""
    import shutil
    import subprocess
    paths = [p for p in (part_paths or []) if p and os.path.exists(p) and os.path.getsize(p) > 0]
    if len(paths) < 2:
        return False
    ff = shutil.which("ffmpeg")
    if mode == "ts" or (not ff and out_path.lower().endswith(".ts") and all(p.lower().endswith(".ts") for p in paths)):
        try:
            with open(out_path, "wb") as out_f:
                for p in paths:
                    with open(p, "rb") as in_f:
                        shutil.copyfileobj(in_f, out_f, length=1048576)
            if os.path.exists(out_path) and os.path.getsize(out_path) > 0:
                log("複数TSパートを単一TSへ無劣化バイナリ結合(%d本): %s (%.1fMB)" % (
                    len(paths), os.path.basename(out_path), os.path.getsize(out_path) / 1048576))
                return True
        except Exception as e:
            log("TSバイナリ結合失敗(%s)" % e)
            return False
    if not ff:
        log("ffmpegが見つからずパート結合をスキップ")
        return False
    list_path = out_path + ".concat_list.txt"
    try:
        with open(list_path, "w", encoding="utf-8") as lf:
            for p in paths:
                abs_p = os.path.abspath(p).replace("'", "'\\''")
                lf.write("file '%s'\n" % abs_p)
        cmd = [ff, "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", list_path, "-c", "copy"]
        if out_path.lower().endswith(".mp4"):
            cmd += ["-movflags", "+faststart+use_metadata_tags"] + mp4_metadata_args(ctx)
        cmd.append(out_path)
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
        if r.returncode == 0 and os.path.exists(out_path) and os.path.getsize(out_path) > 0:
            log("複数パートを単一ファイルへ無劣化結合(%d本→1本): %s (%.1fMB)" % (
                len(paths), os.path.basename(out_path), os.path.getsize(out_path) / 1048576))
            return True
        log("ffmpeg concat結合失敗(%s)" % ((r.stderr or "").strip()[:90] or "rc=%d" % r.returncode))
    except Exception as e:
        log("ffmpeg concat結合失敗(%s)" % e)
    finally:
        try:
            if os.path.exists(list_path):
                os.unlink(list_path)
        except OSError:
            pass
    return False


def cli_part_name(tpl, ctx, def_name):
    """v1.10.0: 保存ファイル名テンプレート({date}{time}{creator}{title}{quality}{part}{ext})。
    OS禁止文字は自動除去し、空になった場合は従来命名へフォールバック。"""
    t = (tpl or "").strip()
    if not t:
        return def_name
    name = (t.replace("{date}", ctx["date"]).replace("{time}", ctx["time"])
             .replace("{creator}", safe_name(ctx["creator"]))
             .replace("{title}", safe_name(ctx["title"]))
             .replace("{quality}", safe_name(ctx["quality"]))
             .replace("{part}", str(ctx["part"])).replace("{ext}", ctx["ext"]))
    name = re.sub(r'[\/:*?"<>|\x00-\x1f]', "", name).strip()
    if not name:
        return def_name
    if not name.lower().endswith("." + ctx["ext"]):
        name += "." + ctx["ext"]
    return name


def parse_m3u8_attrs(s):
    """HLS属性リストの解析(引用符付き対応) → dict"""
    out = {}
    for m in re.finditer(r'([A-Z0-9-]+)=("[^"]*"|[^,]*)', s):
        v = m.group(2)
        if v.startswith('"') and v.endswith('"'):
            v = v[1:-1]
        out[m.group(1)] = v
    return out


def parse_variants(txt, base):
    """master playlist(#EXT-X-STREAM-INF)の解析 → variant辞書のリスト"""
    out = []
    lines = txt.splitlines()
    for i, line in enumerate(lines):
        s = line.strip()
        if not s.startswith("#EXT-X-STREAM-INF:"):
            continue
        attrs = parse_m3u8_attrs(s[len("#EXT-X-STREAM-INF:"):])
        uri = ""
        for j in range(i + 1, len(lines)):
            t = lines[j].strip()
            if not t:
                continue
            if t.startswith("#"):
                if t.startswith("#EXT-X-STREAM-INF:"):
                    break
                continue
            uri = t
            break
        if not uri:
            continue
        res = str(attrs.get("RESOLUTION", "")).split("x")
        v = {
            "url": urllib.parse.urljoin(base, uri),
            "bw": int(attrs.get("BANDWIDTH") or 0),
            "width": int(res[0]) if len(res) > 0 and res[0].isdigit() else 0,
            "height": int(res[1]) if len(res) > 1 and res[1].isdigit() else 0,
            "fps": float(attrs.get("FRAME-RATE") or 0),
            "codecs": attrs.get("CODECS", ""),
            "audioGroup": attrs.get("AUDIO", ""),
            "subsGroup": attrs.get("SUBTITLES", ""),  # v2.9.0(A-09): 字幕グループ結合属性
        }
        v["bwEff"] = int(attrs.get("AVERAGE-BANDWIDTH") or 0) or v["bw"]
        out.append(v)
    return out


def parse_audio_groups(txt, base):
    """v1.11.0: master playlistの#EXT-X-MEDIA(TYPE=AUDIO)解析 → 音声グループ辞書。
    戻り値: {gid: {name, channels, count, uri, bw}}。URI属性と帯域
    (AVERAGE-BANDWIDTH優先・無ければBANDWIDTH)を解析し、同一グループに
    複数URI(言語違い等)がある場合は帯域最大の1つを採用する。"""
    out = {}
    for i, line in enumerate(txt.splitlines()):
        s = line.strip()
        if not s.startswith("#EXT-X-MEDIA:"):
            continue
        attrs = parse_m3u8_attrs(s[len("#EXT-X-MEDIA:"):])
        if str(attrs.get("TYPE", "")).upper() != "AUDIO":
            continue
        gid = attrs.get("GROUP-ID", "")
        if not gid:
            continue
        g = out.setdefault(gid, {"name": "", "channels": "", "count": 0, "uri": "", "bw": 0})
        if not g["name"] and attrs.get("NAME"):
            g["name"] = attrs["NAME"]
        if attrs.get("CHANNELS"):
            g["channels"] = attrs["CHANNELS"]
        uri = attrs.get("URI", "")
        if uri:
            bw = int(attrs.get("AVERAGE-BANDWIDTH") or 0) or int(attrs.get("BANDWIDTH") or 0) or 0
            if not g["uri"] or bw > g["bw"]:
                g["bw"] = bw
                g["uri"] = urllib.parse.urljoin(base, uri)
        g["count"] += 1
    return out


def parse_subtitle_renditions(txt):
    """v2.9.0(A-09): master playlistの#EXT-X-MEDIA(TYPE=SUBTITLES)解析 →
    字幕レンディション辞書のリスト。観測のみで字幕playlistは取得しない。
    URI値は秘匿し取得可否(hasUri)のみ記録(URL秘匿契約)。
    未知の属性は埋め込まない(固定鍵集合のみ・A-05未知値非埋込契約の継承)。"""
    out = []
    for line in txt.splitlines():
        s = line.strip()
        if not s.startswith("#EXT-X-MEDIA:"):
            continue
        attrs = parse_m3u8_attrs(s[len("#EXT-X-MEDIA:"):])
        if str(attrs.get("TYPE", "")).upper() != "SUBTITLES":
            continue
        gid = attrs.get("GROUP-ID", "")
        if not gid:
            continue
        out.append({
            "groupId": gid,
            "name": attrs.get("NAME", ""),
            "language": attrs.get("LANGUAGE", ""),
            "assocLanguage": attrs.get("ASSOC-LANGUAGE", ""),
            "default": str(attrs.get("DEFAULT", "")).upper() == "YES",
            "autoselect": str(attrs.get("AUTOSELECT", "")).upper() == "YES",
            "forced": str(attrs.get("FORCED", "")).upper() == "YES",
            "hasUri": bool(attrs.get("URI", "")),
        })
    return out


def subtitle_evidence(renditions, variants):
    """v2.9.0(A-09): 字幕レンディション観測の証拠ブロック(情報JSON用)。
    字幕playlist・セグメントは取得しない(観測と計数のみの安全側契約)。
    policy=observed_not_fetched を契約として明記する。"""
    rends = list(renditions or [])
    gids = set((r or {}).get("groupId", "") for r in rends)
    gids.discard("")
    linked = 0
    for v in (variants or []):
        sg = (v or {}).get("subsGroup", "")
        if sg and sg in gids:
            linked += 1
    return {
        "renditions": rends,
        "renditionCount": len(rends),
        "variantsLinked": linked,
        "policy": "observed_not_fetched",
        "provenance": "master_playlist_ext_x_media",
        "note": "字幕レンディションは観測と計数のみ(字幕playlist取得はしない)。"
                "URI値は秘匿しhasUriのみ記録",
    }


def subtitle_evidence_block(master_txt, variants):
    """v2.9.0(A-09): master playlist取得済み(非空)のときのみ証拠ブロックを出す。
    未取得(None/'')はNone(虚偽のゼロを担造しない・A-08契約の継承)。"""
    if not master_txt:
        return None
    return subtitle_evidence(parse_subtitle_renditions(master_txt), variants)


def pick_best_variant(variants, dead=None):
    """最高画質バリアントの選択(解像度面積→fps→帯域の辞書式比較)。
    dead: 消失したURLの集合(除外)。yt-dlpの既定ソート(res>fps>br)踏襲。"""
    pool = [v for v in variants if not (dead and v["url"] in dead)]
    if not pool:
        return None
    return max(pool, key=lambda v: (v["width"] * v["height"], v["fps"], v["bwEff"]))


def quality_label(v):
    if not v:
        return ""
    s = ("%dp" % v["height"]) if v["height"] else "音声"
    if v["fps"]:
        s += "%d" % round(v["fps"])
    if v["bwEff"]:
        s += "(%.1fMbps)" % (v["bwEff"] / 1000000.0) if v["bwEff"] >= 1000000 else "(%dkbps)" % round(v["bwEff"] / 1000.0)
    return s


def is_better_variant(cand, cur):
    """昇格判定: 解像度/fpsが上なら昇格。同解像度同fpsは帯域30%増のみ(チャタリング防止)"""
    if not cand or not cur:
        return False
    px_c, px_cur = cand["width"] * cand["height"], cur["width"] * cur["height"]
    if px_c != px_cur:
        return px_c > px_cur
    if cand["fps"] != cur["fps"]:
        return cand["fps"] > cur["fps"]
    return cand["bwEff"] > cur["bwEff"] * 1.3


def now_ms():
    return int(time.time() * 1000)


def stamp():
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def iso(t):
    return datetime.fromtimestamp(t, tz=timezone.utc).astimezone().isoformat(timespec="seconds")


def safe_name(s):
    s = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "", str(s or "")).strip().replace(" ", "_")
    return s[:40] or "live"


def hls_reload_ms(target, changed, jitter=None):
    td = target if isinstance(target,(int,float)) and math.isfinite(target) and target>0 else 9
    if jitter is None: jitter = random.random()*0.1
    j = max(0,min(0.1,jitter)) if isinstance(jitter,(int,float)) and math.isfinite(jitter) else 0
    return math.ceil(td*1000*(1 if changed else 0.5)*(1+j))


# RSP_HLS_PY_MODULE

class Dl:
    def __init__(self, a):
        self.oid = a.oid
        self.out_dir = a.out
        self.m3u8_custom = a.m3u8 or ""
        self.flv_url = a.flv or (CDN_BASE + self.oid + "_abrhd.flv?creatorId=" + self.oid +
                                 "&resolution=hd&abr_pts=-800")
        self.api = a.api or API_BASE
        self.ua = a.ua
        self.follow = not a.no_follow
        self.flv_ok = not a.no_flv
        self.backlog = not a.no_backlog
        self.best_q = not getattr(a, "first_variant", False)  # v1.9.0: 最高画質(既定ON)
        self.split_min = a.split_min
        self.cap = a.max_size_mb * 1024 * 1024
        self.standby_limit = a.standby_min * 60000
        self.max_hours = a.max_hours
        self.info_json = a.info_json
        # v1.8.0: 自分のJWT(--token)と配信予約待機(--wait-schedule)
        # ※ --tokenは「ユーザー自身がログインして得たJWT」を使うだけの機能であり、
        #   視聴権限のある配信のみを扱う(認証の回避・権限の偽装は行わない)
        self.token = (a.token or "").strip()
        # v2.7.0(A-01/A-02): 認証資格の供給と更新(auth_store抽象)。--token(明示)が
        # 一次で、401時だけ--refresh-token(値/env:/file:)へ自動切替する。
        # 認証の回避は行わない(自分の資格のみ・権限の無い配信にはアクセスしない)
        self.auth = AuthStore(
            self.api,
            http_fn=(lambda u, t, h, method="GET", data=None:
                      self.http(u, t, headers=h, method=method, data=data)),
            log_fn=self.log,
            token=self.token,
            refresh_spec=(getattr(a, "refresh_token", "") or ""),
            user_oid=(getattr(a, "user_oid", "") or ""))
        if self.auth.mode in ("refresh-token", "token+refresh") and not self.auth.refresh_value:
            self.log("警告: --refresh-tokenの供給を読み込めませんでした(変数/ファイル確認) — "
                     "認証なしで続行します")
        self.wait_sched = bool(a.wait_schedule) and bool(self.token or self.auth.refresh_value)
        # v2.7.0(A-03): live/play応答形状のcanary結果(情報JSON canaryEvidence用)
        self._canary = None
        # v2.8.0(W-02/W-03): streamStartTime 10分閾値追跡 & 4層ErrorKind分類
        self._session_tracker = {"initialStreamStartSec": None, "latestStreamStartSec": None,
                                 "thresholdSec": 600, "sameSessionResumes": 0,
                                 "newSessionSplits": 0, "transitions": []}
        self._err_taxonomy = {"SOURCE": 0, "NETWORK": 0, "AUTH": 0,
                              "PLATFORM": 0, "COMPATIBILITY": 0, "INTERNAL": 0}
        self._use_butter_m3u8 = False
        self.split_on_discontinuity = bool(getattr(a, "split_on_discontinuity", False))
        self.concat_parts = getattr(a, "concat_parts", "no") or "no"
        self._disc_merged = 0
        self._disc_split = 0
        self._same_session_continuations = 0
        self._parts_concatenated = 0
        self._concat_output = None
        self.inherit_query = bool(getattr(a, "inherit_query", False))
        self.join_parts_mode = getattr(a, "join_parts", "auto") or "auto"
        self.mux_audio_parts = bool(getattr(a, "mux_audio_parts", False))
        self._ts_disguise_stripped = 0
        self._ts_disguise_bytes = 0
        self._hls_query_inherited = 0
        self.part_boundary_evidence = {}
        self.aggregate_evidence = {"status": "NOT_REQUESTED"}
        # v2.37.0(N-02): AES-128復号取得(--dec-key系)。鍵そのものは記録しない(ゼロシークレット)
        self._dec_key_uris = set()
        self._dec_keys = {}
        self._dec_evidence = {"enabled": False, "keySource": None, "keyCount": 0,
                              "segmentsDecrypted": 0, "segmentsFailed": 0,
                              "bytesDecrypted": 0, "elapsedMs": 0.0,
                              "segmentsByBackend": {"openssl": 0, "python": 0}}
        self._dec_key_source = None
        self._cc_audit = None  # v2.37.0(N-03): TS連続性カウンタ監査の累積
        self._load_dec_key(a)
        self.dec_backend = getattr(a, "dec_backend", "auto") or "auto"
        # v2.7.0(A-05): MP4メタデータ埋め込み記録(metadataEvidence用)
        self._meta_events = []
        # v2.7.0(A-04): auth_failed通知の節流(60秒・呼びすぎない)
        self._auth_fail_notified_at = 0.0
        # v1.10.0: ファイル名テンプレートとMP4リマックス(--mux auto|mp4|no)
        self.name_tpl = (getattr(a, "name_tpl", "") or "").strip()
        self.mux = getattr(a, "mux", "auto")
        # v1.11.0: 音声レンディション録画(--audio-only / --audio-both)
        self.audio_only = bool(getattr(a, "audio_only", False))
        self.audio_mode = self.audio_only or bool(getattr(a, "audio_both", False))
        if self.audio_only:
            self.flv_ok = False  # FLV代替は映像に音声多重 → 音声単独録画と矛盾するため無効
        os.makedirs(self.out_dir, exist_ok=True)
        # v1.7.0: 詮索と源管理
        self.live_info = None
        self.live_m3u8 = ""          # 生きたと確認したHLS源
        self.variant_url = ""        # master→variantの解決結果
        self._src_at = 0             # 源再探査の最終時刻(60秒節流)
        # v1.9.0: 画質選択(最高画質)
        self.master_url = ""         # master playlistのURL(media playlist源では空)
        self.variants = []           # 最後に取得したmasterのバリアント一覧
        self.sel_variant = None      # 録画中のバリアント(画質)
        self.quality_txt = ""        # 表示用(例: 1080p60(8.5Mbps))
        self.quality_upgrades = 0    # 録画中の画質昇格回数
        self.dead_variants = set()   # 消失したバリアントURL(フォールバック除外)
        self._q_up_at = 0            # 最終の画質昇格チェック時刻
        self._q_fb_at = 0            # 最終のバリアントフォールバック時刻
        # v1.8.0: 限定解決と予約
        self.member_playlist = ""    # 限定playlist(key2認証)
        self._member_cache = None
        self._member_at = 0
        self._member_try_at = 0      # 非member時の限定解決試行(5分節流)
        self._member_retry_at = 0    # 録画中の鍵更新再解決(90秒節流)
        self._sched_oid = None
        self._sched_at = 0
        self._sched_item = None
        self._sched_last = None
        self._sched_notify = None
        # 状態
        self.state = "IDLE"          # IDLE / RUN / STANDBY
        self.medium = "ts"           # ts / flv
        self.seen = set()
        self.queue = []
        self.target_dur = 0
        self.last_poll = 0
        self.cur_poll_ms = 3000
        self.last_standby = 0
        self.pl_backoff = 0
        self.seg_backoff = 0
        self.c429 = 0
        self.c404 = 0
        self.last_new = 0.0
        self.last_req = 0.0
        self.started = time.time()
        self.file_started = time.time()
        self.part_open = False
        self.part_index = 0
        self.part_name = ""
        self.part_ext = "ts"
        self.fh = None
        self.bytes_part = 0
        self.bytes_total = 0
        self.seg_part = 0
        self.seg_total = 0
        self.seg_fails = 0
        self.gaps = 0
        self.byterange_skipped = 0  # v1.12.0
        self._gap_warned = False
        self._br_warned = False
        self.resumes = 0
        self.parts_log = []
        self.pending_end = None
        self._playlist_body = None
        self._playlist_uri = None
        self.flv_last_fail = 0
        self.flv_resp = None
        self.flv_running = False
        self.wlock = threading.Lock()
        self.last_seq = -1
        self.last_dis = None
        self.standby_since = now_ms()
        self._skip_backlog = False
        self._spd = []
        self.speed_win = []
        # セグメント取得間隔の累計(情報JSONのstats用 — 映像pushで更新)
        self._seg_iv_n = 0
        self._seg_iv_sum = 0.0
        self._seg_iv_last = 0.0
        # v1.10.0: 統計(情報JSONのstats block用)
        self.poll_count = 0
        self.src_switches = 0
        self.quality_fallbacks = 0
        # v1.11.0: 音声レンディション録画の状態(映像と独立のカウンタ/バッファ)
        self.master_txt = ""         # 最後に取得したmaster playlist原文(音声解析用)
        self.audio_label = ""        # 音声トラック表示(例: 256k(2ch))
        self.a_uri = ""              # 音声m3u8のURL(URI付きEXT-X-MEDIAから解決)
        self.a_group = ""
        self.a_bw = 0
        self.a_running = False
        self.a_stop_reason = ""      # '' | 404 | stall | resolve | off
        self.a_dead_uri = ""         # 同一URIの自動再開を禁止(セッション内)
        self._hls_a_state={}
        self.a_seen = set()
        self.a_queue = []
        self.a_last_seq = -1
        self.a_target_dur = 0
        self.a_last_poll = 0
        self.a_cur_poll_ms = 3000
        self.a_backoff = 0
        self.a_c429 = 0
        self.a_c404 = 0
        self._bad_playlist_consec = 0
        self._bad_playlist_total = 0
        self._bad_playlist_recovered = 0
        self._a_bad_playlist_consec = 0
        self._a_bad_playlist_total = 0
        self._a_bad_playlist_recovered = 0
        self._transient_transfer_retries = 0
        self._transient_transfer_recovered = 0
        self._a_transient_transfer_retries = 0
        self._a_transient_transfer_recovered = 0
        self.a_start_at = 0          # 要求オフセット(映像ループ開始から0.3〜0.5秒)
        self.a_last_new = 0.0
        self.a_part_open = False
        self.a_part_index = 0
        self.a_part_name = ""
        self.a_fh = None
        self.a_bytes_part = 0
        self.a_bytes_total = 0
        self.a_seg_total = 0
        self.a_seg_fails = 0
        self.a_file_started = 0.0
        self.audio_parts_log = []
        self.part_tmp_path = ""
        self.part_hasher = None
        self.a_part_tmp_path = ""
        self.a_part_hasher = None
        self.recovered_orphans = []
        self.save_errors = []
        self._failed_media = set()
        # v2.5.0: 運用堅牢化(別系統v2.4.0バンドルから移植・統合)
        self.stop_file = os.path.join(self.out_dir, ".rplay_stop")
        self.hb_path = os.path.join(self.out_dir, "heartbeat.json")
        self.min_free_mb = float(getattr(a, "min_free_mb", 512) or 0)
        self.min_free_inodes = float(getattr(a, "min_free_inodes", 0) or 0)
        self._ino_supported = hasattr(os, "statvfs")
        self.webhook = (getattr(a, "webhook", "") or "").strip()
        self.segindex_on = bool(getattr(a, "segindex", False))
        self.segindex_path = os.path.join(
            self.out_dir, "RPLAY_%s_segindex.json" % safe_name(self.oid))
        self._si_written = {}    # 書込済みセグメントのURI鍵(挿入順・dict)
        self._si_awritten = {}   # 音声側
        self._si_saved_at = 0.0
        self._hb_at = 0.0
        self._disk_at = 0.0
        self._disk_low_n = 0       # 連続低判定カウンタ(二重確認)
        self._last_free_mb = None  # 最終測定値(info JSON)
        self._last_free_inodes = None
        self._ino_low_n = 0
        # v2.5.0(P1): EXTINF検証モード(--extinf-mode legacy|rfc)
        self.extinf_mode = (getattr(a, "extinf_mode", "legacy") or "legacy").strip().lower()
        if self.extinf_mode not in ("legacy", "rfc"):
            self.extinf_mode = "legacy"
        self.ad_keyword = (getattr(a, "ad_keyword", "") or "").strip()
        self._ad_keyword_re = None
        if self.ad_keyword:
            try:
                self._ad_keyword_re = re.compile(self.ad_keyword)
            except re.error as exc:
                raise SystemExit("--ad-keyword: 無効な正規表現です (%s)" % exc)
        # v2.5.0(P1): 品質監査(--qaudit auto|no — ffprobeがあれば実施)
        self.qaudit = (getattr(a, "qaudit", "auto") or "auto").strip().lower()
        if self.qaudit not in ("auto", "no"):
            self.qaudit = "auto"
        # v2.5.0(P1): 保存確定イベント契約の台帳(ledger.json — 段階を飛ばさない)
        self.ledger_path = os.path.join(
            self.out_dir, "RPLAY_%s_ledger.json" % safe_name(self.oid))
        self.ledger = {"tool": "rplay_dl.py v2.50.0", "creatorOid": self.oid,
                       "startedAt": iso(time.time()),
                       "contract": "REQUESTED->FILE_WRITTEN->BROWSER_DONE->HASHED->DECODED/CONTINUITY",
                       "browserStageApplicable": False, "browserStageReason": "cli",
                       "parts": []}
        self._ledger_by_name = {}
        # v2.5.0(P2): 取得キューのFIFO shadow証拠(順序不変の実測)
        self._ord = 0
        self._ord_max = -1
        self._fifo_violations = 0
        self._ord_a = 0
        self._ord_a_max = -1
        self._fifo_a_violations = 0
        # v2.5.0: 孤立part台帳(sha256付き・報告のみ)
        self._final_done = False

    # ---- v2.5.0: 運用堅牢化(移植+統合) ----
    def hb_write(self):
        """heartbeat.json(監視/HEALTHCHECK用の生存通知 — 原子的書込)"""
        if getattr(self, "hb_path", None) is None:
            return
        try:
            _atomic_write_json(self.hb_path, {
                "ts": time.time(), "tool": "rplay_dl.py v2.50.0",
                "creatorOid": self.oid, "state": self.state, "medium": self.medium,
                "seg": self.seg_total, "bytes": self.bytes_total,
                "parts": self.saved_n(), "audioSeg": self.a_seg_total,
                "resumes": self.resumes, "pid": os.getpid(),
                "saveErrors": len(self.save_errors),
                "lastNewAgo": (round(time.time() - self.last_new, 1) if self.last_new else None),
            })
        except Exception:
            pass

    def segindex_flush(self):
        """既知URI鍵の永続化(60秒節流)"""
        if not getattr(self, "segindex_on", False):
            return
        now_t = time.time()
        if now_t - self._si_saved_at < 60:
            return
        self._si_saved_at = now_t
        try:
            segindex_save(self.segindex_path, self._si_written.keys(), self._si_awritten.keys())
        except Exception:
            pass

    def disk_guard(self):
        """ディスク空き容量ガード — 保守判定+二重確認。低(None含む)と判定したら
        即時再測定し、2回連続で低のときだけ安全停止(一時的なstat失敗や瞬間的な
        低下で録画を打ち切らない)"""
        free = free_mb(self.out_dir)
        self._last_free_mb = free
        if self.min_free_mb <= 0 or not guard_low(free, self.min_free_mb):
            self._disk_low_n = 0
            return True
        free2 = free_mb(self.out_dir)
        cur = free2 if free2 is not None else free
        self._last_free_mb = cur
        self._disk_low_n += 1
        if guard_low(free2, self.min_free_mb) or self._disk_low_n >= DISK_CONFIRM_N:
            webhook_post(getattr(self, "webhook", ""), "capacity_warning", {  # v2.7.0(A-04)
                "creatorOid": self.oid, "kind": "disk_free_mb",
                "freeMb": (round(cur, 1) if cur is not None else None),
                "minFreeMb": self.min_free_mb, "action": "stop"}, level="warn")
            self.stop("ディスク空き容量不足(%s < %.0fMB)" % (
                "不明" if cur is None else "%.0fMB" % cur, self.min_free_mb))
            return False
        if self._disk_low_n == 1:
            webhook_post(getattr(self, "webhook", ""), "capacity_warning", {  # v2.7.0(A-04)
                "creatorOid": self.oid, "kind": "disk_free_mb",
                "freeMb": (round(cur, 1) if cur is not None else None),
                "minFreeMb": self.min_free_mb, "action": "recheck_continue"}, level="warn")
            self.log("警告: ディスク空き容量が一時的に低下/不明(再測定で%.0fMB — 継続します)" % (free2 or 0))
        return True

    def inode_guard(self):
        """空きinode枯渇ガード(POSIX・opt-in)。非対応OSは監視対象外。"""
        if self.min_free_inodes <= 0 or not self._ino_supported:
            return True
        n = free_inodes(self.out_dir)
        if n is None:
            n2 = free_inodes(self.out_dir)
            if n2 is None:
                self.stop("ディスク空きinode不足(測定不能が継続)")
                return False
            n = n2
        self._last_free_inodes = n
        if not guard_low(n, self.min_free_inodes):
            self._ino_low_n = 0
            return True
        n2 = free_inodes(self.out_dir)
        self._last_free_inodes = n2 if n2 is not None else n
        self._ino_low_n += 1
        if guard_low(n2, self.min_free_inodes) or self._ino_low_n >= DISK_CONFIRM_N:
            webhook_post(getattr(self, "webhook", ""), "capacity_warning", {  # v2.7.0(A-04)
                "creatorOid": self.oid, "kind": "free_inodes",
                "freeInodes": (n2 if n2 is not None else None),
                "minFreeInodes": self.min_free_inodes, "action": "stop"}, level="warn")
            self.stop("ディスク空きinode不足(%s <= %.0f)" % (
                "不明" if n2 is None else "%.0f" % n2, self.min_free_inodes))
            return False
        if self._ino_low_n == 1:
            self.log("警告: 空きinodeが一時的に低下/不明(再測定で%.0f — 継続します)" % (n2 or 0))
        return True

    # ---- v2.5.0(P1): 保存確定イベント契約の台帳 ----
    def ledger_part(self, name, track, segments=0):
        """パート台帳エントリの取得(無ければ作成 — REQUESTED段階から開始)。
        __new__構築の最小インスタンス(単体試験)ではNoneを返して台帳を省略する。"""
        if getattr(self, "ledger_path", None) is None:
            return None
        by = getattr(self, "_ledger_by_name", None)
        if by is None:
            by = {}
            self._ledger_by_name = by
        led = getattr(self, "ledger", None)
        if led is None:
            led = {"tool": "rplay_dl.py v2.50.0", "parts": []}
            self.ledger = led
        key = (track, name)
        entry = by.get(key)
        if entry is None:
            entry = {"file": name, "track": track, "stages": [], "status": "unknown"}
            led.setdefault("parts", []).append(entry)
            by[key] = entry
        return entry

    def ledger_stage(self, entry, stage, **detail):
        """段階を実測時にのみ追記し、同段階の二重記録を避ける。
        状態を飛ばしてSUCCESS扱いにしない(各段階は発生した順で記録される)。"""
        if entry is None:
            return
        if entry["stages"] and entry["stages"][-1]["stage"] == stage:
            return
        rec = {"stage": stage, "at": iso(time.time())}
        rec.update(detail)
        entry["stages"].append(rec)
        try:
            _atomic_write_json(self.ledger_path, getattr(self, "ledger", {}))
        except Exception:
            pass

    def ledger_set_status(self, entry):
        """SUCCESSは適用可能な全段階が実測された場合のみ(飛ばし無し)。"""
        if entry is None:
            return
        names = [s["stage"] for s in entry["stages"]]
        if "FILE_WRITTEN" not in names:
            entry["status"] = "failed_pending_write"
            return
        hashed = "HASHED" in names
        decoded = "DECODED/CONTINUITY" in names
        audit_verdict = entry.get("auditVerdict")
        if hashed and decoded and audit_verdict == "pass":
            entry["status"] = "SUCCESS_DECODED_CONTINUOUS"
        elif hashed and decoded:
            entry["status"] = "AUDIT_" + str(audit_verdict or "unknown")
        elif hashed:
            entry["status"] = "CONFIRMED_HASHED"
        else:
            entry["status"] = "CONFIRMED_UNHASHED"

    def run_qaudit(self):
        """v2.5.0(P1): 停止時に全パートの実メディア品質監査を実施。
        DECODED/CONTINUITY段階の証拠源。ffprobe不在時は段階を付けず
        「未監査」を明示する(成功扱いにしない)。"""
        parts = getattr(self, "ledger", {}).get("parts", [])
        if getattr(self, "qaudit", "auto") == "no":
            for entry in parts:
                entry["decodeAudit"] = "disabled"
            return
        if not ffprobe_tool():
            for entry in parts:
                entry["decodeAudit"] = "ffprobe_unavailable"
            self.log("品質監査: ffprobeが見つからず — DECODED/CONTINUITY段階なしで確定(未監査として記録)")
            return
        audited = 0
        for entry in parts:
            track = entry.get("track")
            logs = self.audio_parts_log if track == "audio" else self.parts_log
            match = [p for p in logs if p.get("file") == entry.get("file")]
            if not match or entry.get("auditVerdict") is not None:
                continue
            path = os.path.join(self.out_dir, entry.get("file") or "")
            if not os.path.exists(path):
                entry["decodeAudit"] = "file_missing"
                continue
            result = qaudit_part(path, self.log)
            entry["auditVerdict"] = result.get("verdict")
            entry["qualityAudit"] = result
            self.ledger_stage(entry, "DECODED/CONTINUITY",
                              verdict=result.get("verdict"), provenance="decoded")
            audited += 1
        for entry in parts:
            self.ledger_set_status(entry)
        # v2.6.0(P1): 分離音声との実デコード時間相関 — 両トラックの証拠が揃うときだけ
        corr = qaudit_av_correlation(getattr(self, "ledger", {}).get("parts", []))
        if corr["verdict"] != "insufficient":
            getattr(self, "ledger", {})["avCorrelation"] = corr
            self.av_correlation = corr
            self.log("映像/音声実時間相関(qaudit): drift=%.3fs (許容%.3fs) — %s" % (
                corr.get("driftSec", 0.0), corr.get("toleranceSec", 0.0), corr["verdict"]))
        try:
            _atomic_write_json(self.ledger_path, getattr(self, "ledger", {}))
        except Exception:
            pass
        if audited:
            self.log("品質監査(ffprobe): %dパート — 実デコード証拠をledger/情報JSONへ記録" % audited)

    # ---- 基础 ----
    def log(self, msg):
        print("[%s] %s" % (datetime.now().strftime("%H:%M:%S"), msg), flush=True)
        self.status_clear()

    def api_headers(self):
        """v1.8.0/v2.7.0: 認証付きAPIヘッダ(公式interceptorと同一形状)。
        v2.7.0: AuthStore経由 — refresh-token指定時はleeway前に短命JWTを更新する。
        --token指定時のみAuthorization(静的JWT優先・401時だけ切替)。"""
        h = dict(HDR_API)
        try:
            jwt = self.auth.ensure_jwt() if getattr(self, "auth", None) is not None else ""
        except Exception:
            jwt = ""
        if not jwt:
            jwt = self.token or ""
        if jwt:
            h["Authorization"] = jwt
        return h

    def status_clear(self):
        if sys.stdout.isatty():
            sys.stdout.write("\r" + " " * 110 + "\r")
            sys.stdout.flush()

    def status(self):
        if not sys.stdout.isatty():
            return
        if self.state == "STANDBY":
            t = "⏸追跡中 経過%s 保存%d本" % (fmt_dur(now_ms() - int(self.started * 1000)), self.saved_n())
        else:
            t = "%s(%s) 経過%s %dseg %.1fMB %.1fMB/s part%d 保存%d本%s%s" % (
                self.state, self.medium, fmt_dur(now_ms() - int(self.started * 1000)),
                self.seg_total, self.bytes_total / 1048576, self.speed_mbs(),
                self.part_index + (1 if self.part_open else 0), self.saved_n(),
                (" a音声%dseg" % self.a_seg_total) if self.a_running or self.a_seg_total else "",
                " 漏れ%d" % (self.seg_fails + self.gaps) if (self.seg_fails or self.gaps) else "")
        sys.stdout.write("\r" + t[:110].ljust(110))
        sys.stdout.flush()

    def saved_n(self):
        return len(self.parts_log)

    def speed_mbs(self):
        t = time.time()
        self.speed_win = [s for s in self.speed_win if t - s[0] <= 30]
        self.speed_win.append((t, self.bytes_total))
        if len(self.speed_win) < 2:
            return 0.0
        a, b = self.speed_win[0], self.speed_win[-1]
        dt = b[0] - a[0]
        return max(0.0, (b[1] - a[1]) / 1048576 / dt) if dt > 0 else 0.0

    def http(self, url, timeout, headers=None, method="GET", data=None):
        """GET/POST → (status, bytes|None, retry_after_ms)。例外はstatus=0扱い。
        v1.12.0: 429/503応答のRetry-Afterヘッダ(RFC9110)をミリ秒で返す(無ければ0)
        v2.7.0: method/data指定に対応(refresh-token APIのPOST用)"""
        req = urllib.request.Request(url, data=data, method=method,
                                     headers={"User-Agent": self.ua, **(headers or {})})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                limit=2*1048576;chunks=[];size=0;deadline=time.monotonic()+timeout
                while True:
                    if time.monotonic()>deadline:raise TimeoutError('HTTP_BODY_TIMEOUT')
                    chunk=r.read1(min(65536,limit+1-size))
                    if not chunk:break
                    size+=len(chunk)
                    if size>limit:raise ValueError('HTTP_BODY_LIMIT')
                    chunks.append(chunk)
                return r.status,b''.join(chunks),0
        except urllib.error.HTTPError as e:
            ra = retry_after_ms(e.headers.get("Retry-After")) if e.headers else 0
            e.close()
            return e.code, None, ra
        except Exception:
            return 0, None, 0

    def api_get(self, url, timeout=8):
        """v2.7.0(A-01/A-02): 認証付きAPI GET。401はAuthStoreで分類し、更新に成功した
        場だけ1回だけ再試行する(公式interceptorと同一戦略・連打しない)。
        終端分類(invalid_or_expired/refresh_failed/no_credentials)はauth_failed通知
        (60秒節流)を出し、呼び側の処理は変えない(安全側・録画を止めない)。"""
        st, body, ra = self.http(url, timeout, headers=self.api_headers())
        if st == 401 and getattr(self, "auth", None) is not None:
            code = self.auth.note_401(url)
            if code == "refreshed":
                st, body, ra = self.http(url, timeout, headers=self.api_headers())
            if code in ("invalid_or_expired", "refresh_failed", "no_credentials"):
                now_t = time.time()
                if now_t - getattr(self, "_auth_fail_notified_at", 0.0) >= 60.0:
                    self._auth_fail_notified_at = now_t
                    self.log("認証失敗(%s) — %s" % (code,
                             "--tokenを最新のJWTに更新するか --refresh-token を指定してください"
                             if code != "no_credentials" else "視聴権限が必要な場合は資格を指定してください"))
                    webhook_post(getattr(self, "webhook", ""), "auth_failed", {
                        "creatorOid": self.oid, "classification": code}, level="error")
        return st, body, ra

    # ---- v2.8.0(W-01/W-02/W-03): Butter再試行・streamStartTime追跡・ErrorKind計数 ----
    def _note_err_kind(self, kind):
        tax = getattr(self, "_err_taxonomy", None)
        if tax is None:
            tax = {"SOURCE": 0, "NETWORK": 0, "AUTH": 0, "PLATFORM": 0, "COMPATIBILITY": 0, "INTERNAL": 0}
            self._err_taxonomy = tax
        if kind in tax:
            tax[kind] = tax.get(kind, 0) + 1

    def _note_stream_start(self, info):
        if not isinstance(info, dict) or not info:
            return
        raw = info.get("streamStartTime") or info.get("startedAt")
        sec = parse_stream_start_sec(raw)
        if sec is None:
            return
        tr = getattr(self, "_session_tracker", None)
        if tr is None:
            tr = {"initialStreamStartSec": None, "latestStreamStartSec": None,
                  "thresholdSec": 600, "sameSessionResumes": 0,
                  "newSessionSplits": 0, "transitions": []}
            self._session_tracker = tr
        if tr["initialStreamStartSec"] is None:
            tr["initialStreamStartSec"] = sec
            tr["latestStreamStartSec"] = sec
            return
        cls = classify_session_change(tr["latestStreamStartSec"], sec, tr.get("thresholdSec", 600))
        tr["latestStreamStartSec"] = sec
        if cls["changed"]:
            if cls["classification"] == "same_session_resumed":
                tr["sameSessionResumes"] += 1
                self._same_session_continuations = getattr(self, "_same_session_continuations", 0) + 1
            elif cls["classification"] == "new_session_split":
                tr["newSessionSplits"] += 1
            tr["transitions"].append({
                "gapSec": cls["gapSec"],
                "classification": cls["classification"],
                "at": iso(time.time()),
            })

    def _m3u8_http(self, url, timeout=6):
        hdrs = dict(HDR_M3U8)
        if getattr(self, "_use_butter_m3u8", False):
            bt = generate_butter_token()
            if bt:
                hdrs["Butter"] = bt
                if getattr(self, "auth", None) is not None and getattr(self.auth, "butter_sends", 0) == 0:
                    self.auth.note_butter()
        st, body, ra = self.http(url, timeout, headers=hdrs)
        if st == 403 and not hdrs.get("Butter"):
            Dl._note_err_kind(self, "AUTH")
            bt = generate_butter_token()
            if bt:
                if getattr(self, "auth", None) is not None:
                    self.auth.note_butter()
                st2, body2, ra2 = self.http(url, timeout, headers={**hdrs, "Butter": bt})
                if st2 == 200 and body2:
                    self._use_butter_m3u8 = True
                    return st2, body2, ra2
        if st >= 500:
            Dl._note_err_kind(self, "SOURCE")
        elif st == 0:
            Dl._note_err_kind(self, "NETWORK")
        elif st in (401, 403):
            Dl._note_err_kind(self, "AUTH")
        elif st == 429:
            Dl._note_err_kind(self, "PLATFORM")
        return st, body, ra

    # ---- v1.7.0: 詮索(live/play)と新旧基盤の多段源 ----
    def scent(self):
        """live/playを探査し現行の配信基盤URLを取得(未ログインでも可)。
        応答: bytePlusPlaybackUrl(BytePlus abr master) / playUrl(AWS IVS) 等。
        v2.7.0(A-03): 応答形状のcanary検証を併せて行い、形状変化は警告のみで
        安全側継続(録画を止めない)。結果は_canaryへ保持(canaryEvidence用)。"""
        self.live_info = None
        q = {"creatorOid": self.oid}
        try:
            q.update(self.auth.requestor_params())
        except Exception:
            pass
        st, body, _ra = self.api_get(self.api + "/live/play?" + urllib.parse.urlencode(q), 8)
        if st == 200 and body:
            try:
                self.live_info = json.loads(body.decode("utf-8", "replace"))
            except Exception:
                self.live_info = None
        if self.live_info:
            Dl._note_stream_start(self, self.live_info)
        self._canary = canary_check(self.live_info)
        if self._canary["result"] == "shape_change":
            self.log("警告: live/playの応答形状が既知鍵と一致しません(canary: shape_change) — "
                     "サイト更新の可能性。録画は続行します(詮索結果のみ利用)")
        elif self._canary["result"] == "unreachable":
            self.log("詮索(live/play)応答なし(canary: unreachable) — 手動URL/従来源で続行します")
        return self.live_info

    def resolve_member(self, why):
        """v1.8.0: 限定配信(会員限定)の解決 — 自分のトークン(--token)で視聴権限が
        認められた場合のみ。live/play(権限確認) → live/key2(authKey) →
        /live/stream/playlist.m3u8?key2= の3段。権限がなければ明示して終了
        (認証の回避・権限の偽装は行わない)。解決結果は60秒キャッシュ。
        v2.7.0: api_get経由で401分類・key2再解決をauthEvidenceへ計上。"""
        if not self.token and not (getattr(self, "auth", None) and self.auth.refresh_value):
            return None
        now = now_ms()
        if self._member_cache and now - self._member_at < 60000:
            return self._member_cache
        q = {"creatorOid": self.oid}
        try:
            q.update(self.auth.requestor_params())
        except Exception:
            pass
        st, body, _ra = self.api_get(self.api + "/live/play?" + urllib.parse.urlencode(q), 8)
        info = {}
        if st == 200 and body:
            try:
                info = json.loads(body.decode("utf-8", "replace")) or {}
            except Exception:
                info = {}
        if not info:
            self.log("限定解決(%s): live/play応答なし(%s) — 自動で再試行します" % (why, st))
            return None
        stt = info.get("streamState")
        if stt and stt not in ("live",):
            self.log("限定解決: 配信は%s — 開始を待機します" % stt)
            self._member_at = now
            return None
        if not info.get("accessible"):
            free = bool((info.get("tierHashes") or {}).get("free"))
            self.log("限定解決: この配信への視聴権限がありません(%s)" %
                     ("無料プラン加入限定 — プランに加入すると録画できます" if free else "プラン加入/鍵/チケットが必要"))
            self._member_at = now
            return None
        key2 = ""
        st, body, _ra = self.api_get(self.api + "/live/key2?" + urllib.parse.urlencode(q), 8)
        if st == 200 and body:
            try:
                key2 = (json.loads(body.decode("utf-8", "replace")) or {}).get("authKey", "") or ""
            except Exception:
                key2 = ""
        if key2 and getattr(self, "auth", None) is not None:
            self.auth.note_key2()  # v2.7.0(A-02): key2再解決の成功計数
        elif st == 401:
            self.log("限定解決: トークンが無効です(401) — --tokenを最新のJWTに更新するか "
                     "--refresh-token を指定してください")
            self._member_at = now
            return None
        elif st == 403:
            self.log("限定解決: key2が403 — この配信への視聴権限がありません")
            self._member_at = now
            return None
        url = (self.api + "/live/stream/playlist.m3u8?creatorOid=" + self.oid +
               (("&key2=" + urllib.parse.quote(key2)) if key2 else ""))
        st, body, _ra = self._m3u8_http(url + "&_rsp=" + str(now_ms()), 6)
        if st != 200:
            self.log("限定解決: 限定playlist取得失敗(%s) — 自動で再試行します" % st)
            return None
        self.member_playlist = url
        self._member_cache = url
        self._member_at = now
        self.log("限定配信を解決(key2認証%s) — 自分のトークンで視聴権限のあるplaylistです" % ("" if key2 else " / 鍵なし"))
        return url

    def schedule_info(self):
        """v1.8.0: 配信予約の取得(--tokenが必要。未ログイン/401等はNone)。
        応答形状の差を吸収し、直近の予約1件 {title, scheduledAt(秒)} を返す。"""
        now = now_ms()
        ttl = 60000 if self._sched_item else 20000
        if self._sched_oid == self.oid and now - self._sched_at < ttl:
            return self._sched_item
        self._sched_oid, self._sched_at = self.oid, now
        st, body, _ra = self.api_get(self.api + "/live/schedules?creatorOid=" + self.oid, 8)
        if st != 200 or not body:
            self._sched_item = None
            return None
        try:
            j = json.loads(body.decode("utf-8", "replace"))
        except Exception:
            self._sched_item = None
            return None
        arr = j if isinstance(j, list) else None
        if arr is None and isinstance(j, dict):
            for k in ("schedules", "items", "list", "data", "results"):
                if isinstance(j.get(k), list):
                    arr = j[k]
                    break
            if arr is None and (j.get("scheduledAt") or j.get("startsAt") or j.get("startAt")):
                arr = [j]
        best, best_t = None, float("inf")
        now_s = time.time()
        for it in (arr or []):
            if not isinstance(it, dict):
                continue
            raw = (it.get("scheduledAt") or it.get("startsAt") or it.get("startAt") or
                   ((it.get("live") or {}).get("scheduledAt") if isinstance(it.get("live"), dict) else None))
            t = 0.0
            if isinstance(raw, (int, float)):
                t = float(raw) * 1000.0 if raw < 1e12 else float(raw)
            elif isinstance(raw, str):
                try:
                    t = datetime.fromisoformat(raw.replace("Z", "+00:00")).timestamp() * 1000.0
                except Exception:
                    t = 0.0
            ts = t / 1000.0
            if ts > now_s - 1800 and ts < best_t:
                best_t = ts
                best = {"title": it.get("title") or it.get("name") or "", "scheduledAt": ts}
        self._sched_item = best
        return best

    def hls_candidates(self):
        """HLS源候補(優先順): 限定(key2) > 手動上書き > bytePlus abr(新判明) > 従来<id>.m3u8(旧) > IVS"""
        cands = []
        if self.member_playlist:
            cands.append(self.member_playlist)
        if self.m3u8_custom:
            cands.append(self.m3u8_custom)
        info = self.live_info or {}
        if info.get("bytePlusPlaybackUrl"):
            cands.append(info["bytePlusPlaybackUrl"])
        cands.append(CDN_BASE + self.oid + ".m3u8")
        if info.get("playUrl"):
            cands.append(info["playUrl"])
        return cands

    def playlist_url(self):
        """実際に使うplaylist源(限定解決済み>生きたと確認済み>候補の先頭)"""
        if self.member_playlist:
            return self.member_playlist
        return self.live_m3u8 or self.hls_candidates()[0]

    def resolve_variant(self, txt, base):
        """master playlist→最高画質バリアントのURL(v1.9.0: 解像度→fps→帯域)。
        副作用: self.variants/sel_variant/quality_txt を更新"""
        self.master_txt = txt  # v1.11.0: 音声グループ解析用に原文を保持
        self.variants = parse_variants(txt, base)
        if not self.variants:
            return None
        best = pick_best_variant(self.variants, self.dead_variants) if self.best_q else self.variants[0]
        if not best:
            return None
        self.sel_variant = best
        self.quality_txt = quality_label(best)
        return best["url"]

    # ---- プレイリスト ----
    def reset_quality_state(self):
        """v1.9.0: 基盤切替/再開時に画質状態をリセット"""
        self.master_url = ""
        self.variant_url = ""
        self.variants = []
        self.sel_variant = None
        self.quality_txt = ""
        self.dead_variants.clear()
        self._q_up_at = 0
        self._q_fb_at = 0

    def apply_variant_switch(self, next_url, why):
        """バリアント切替(画質昇格/消失フォールバック共通):
        現パートを区切って保存(画質が混在するファイルを作らない)し、
        新バリアントのライブエッジから継続(既存ウィンドウは重複防止で除外)"""
        if self.part_open and self.bytes_part > 0:
            self.close_part()
        self.variant_url = next_url
        self._skip_backlog = True
        self.last_seq = -1
        self.log(why)

    def maybe_quality_upgrade(self):
        """master定期再走査: より高い画質が出現していれば昇格(下げはしない)"""
        if not self.master_url or not self.best_q:
            return
        if now_ms() - self._q_up_at < QUALITY_RESCAN_S * 1000:
            return
        self._q_up_at = now_ms()
        try:
            st, body, _ra = self.http(self.master_url + "?_rsp=" + str(now_ms()), 6, headers=HDR_M3U8)
            if st != 200 or not body:
                return
            self.master_txt = body.decode("utf-8", "replace")  # v1.11.0: 音声解析用
            variants = parse_variants(body.decode("utf-8", "replace"), self.master_url)
            if not variants:
                return
            self.variants = variants
            best = pick_best_variant(variants, self.dead_variants)
            if not best or not self.sel_variant:
                return
            if best["url"] != self.variant_url and is_better_variant(best, self.sel_variant):
                frm = self.quality_txt
                self.sel_variant = best
                self.quality_txt = quality_label(best)
                self.quality_upgrades += 1
                self.dead_variants.clear()
                self.apply_variant_switch(best["url"],
                    "画質を昇格: %s → %s — パートを区切って新しい画質で録画を続行します" % (frm or "不明", self.quality_txt))
                self.sync_audio_source()  # v1.11.0: AUDIO属性が変わったら音声も追従再解決
        except Exception:
            pass

    def fallback_variant(self, dead_url):
        """バリアント消失(404/410)時: masterから次の画質へフォールバック。
        戻り値: 切替先のバリアント(切替不可ならNone)"""
        if not self.master_url or not self.best_q:
            return None
        if now_ms() - self._q_fb_at < QUALITY_FALLBACK_S * 1000:
            return None
        self._q_fb_at = now_ms()
        try:
            st, body, _ra = self.http(self.master_url + "?_rsp=" + str(now_ms()), 6, headers=HDR_M3U8)
            if st != 200 or not body:
                return None
            self.dead_variants.add(dead_url)
            self.master_txt = body.decode("utf-8", "replace")  # v1.11.0: 音声解析用
            variants = parse_variants(body.decode("utf-8", "replace"), self.master_url)
            if not variants:
                return None
            self.variants = variants
            best = pick_best_variant(variants, self.dead_variants)
            if not best or best["url"] == dead_url:
                return None
            frm = self.quality_txt
            self.sel_variant = best
            self.quality_txt = quality_label(best)
            self.apply_variant_switch(best["url"],
                "バリアントが消失(404) → 次の画質へフォールバック: %s → %s — 録画を継続します" % (frm or "不明", self.quality_txt))
            self.sync_audio_source()  # v1.11.0: AUDIO属性が変わったら音声も追従再解決
            return best
        except Exception:
            return None
    # ---- 音声レンディション録画(v1.11.0) ----
    def sync_audio_source(self):
        """選択variantのAUDIO属性から音声m3u8のURIを(再)解決する。
        グループが同一なら継続、URIが変わったら再解決(画質昇格時の追従含む)。"""
        if not self.audio_mode or not self.sel_variant:
            return
        groups = parse_audio_groups(self.master_txt or "", self.master_url or "")
        gid = (self.sel_variant or {}).get("audioGroup", "")
        g = groups.get(gid)
        if not g or not g.get("uri"):
            if self.a_running:
                self.a_running = False
                self.a_stop_reason = "resolve"
                self.log("音声グループのURIが解決できません — 音声録画を停止(映像は継続)")
            return
        if self.a_running and self.a_uri == g["uri"]:
            return
        if not self.a_running and g["uri"] == self.a_dead_uri:
            return  # 欠落済みURIの自動再開はしない
        was = self.a_running
        if self.a_part_open:
            self.close_audio_part()
        self.a_uri, self.a_group = g["uri"], gid
        self.a_bw = g.get("bw", 0)
        label = g.get("name") or gid
        if g.get("channels"):
            label += "(%s)" % g["channels"]
        self.audio_label = label
        self._hls_a_state={}
        self.a_seen = set()
        self.a_queue = []
        self.a_last_seq = -1
        self.a_target_dur = 0
        self.a_cur_poll_ms = 3000
        self.a_backoff = 0
        self.a_c429 = 0
        self.a_running = True
        self.a_stop_reason = ""
        # 要求オフセット(0.3〜0.5秒): 映像との同時リクエストを避け1セッションに近似
        self.a_start_at = now_ms() + random.randint(A_OFFSET_MIN_MS, A_OFFSET_MAX_MS)
        self.a_last_new = time.time()
        self.log("%s: %s%s %dkbps — audio-*.tsとして並行保存" % (
            "音声源を再解決" if was else "音声トラックの録画を開始",
            label, "" if not self.a_group else "(group=%s)" % self.a_group, self.a_bw // 1000 if self.a_bw else 0))

    def audio_poll(self, now):
        self.a_last_poll = now
        st, body, _ra = self.http(self.a_uri + ("&" if "?" in self.a_uri else "?") + "_rsp=" + str(now), 6, headers=HDR_M3U8)
        if self.state == "IDLE":
            return
        if st == 200 and body:
            self.a_c429 = 0
            self.a_c404 = 0
            try:
                parsed=hls_parse(body.decode('utf-8','replace'),self.a_uri,getattr(self,'extinf_mode','legacy'),getattr(self,'inherit_query',False))
                n_before=len(self.a_queue)
                added,missing=hls_enqueue(self,parsed,self.a_uri,audio=True)
                for _item in self.a_queue[n_before:]:
                    self._ord_a = getattr(self, "_ord_a", 0) + 1
                    _item["_ord"] = self._ord_a
            except ValueError as e:
                code = str(e)
                if code in REC_TRANSIENT_PARSE_ERRORS and getattr(self, "a_seg_total", 0) > 0:
                    self._a_bad_playlist_consec = getattr(self, "_a_bad_playlist_consec", 0) + 1
                    self._a_bad_playlist_total = getattr(self, "_a_bad_playlist_total", 0) + 1
                    if self._a_bad_playlist_consec <= 2:
                        self.log("音声プレイリストの一時的不完全応答(%s %d/2) — 次周期に再確認します" % (code, self._a_bad_playlist_consec))
                        return
                self._protocol_error(code,audio=True);return
            if getattr(self, "_a_bad_playlist_consec", 0) > 0:
                self._a_bad_playlist_recovered = getattr(self, "_a_bad_playlist_recovered", 0) + 1
                self._a_bad_playlist_consec = 0
            if parsed['target']: self.a_target_dur=parsed['target']
            self.a_last_seq=parsed['sequence'];self.a_seg_fails+=missing
            if added:self.a_last_new=time.time()
            changed = getattr(self,"_audio_playlist_body",None) != body or getattr(self,"_audio_playlist_uri",None) != self.a_uri
            self._audio_playlist_body,self._audio_playlist_uri = body,self.a_uri
            self.a_cur_poll_ms = hls_reload_ms(self.a_target_dur,changed)
        elif st in (404, 410):
            if st == 404 and getattr(self, "a_seg_total", 0) > 0:
                self.a_c404 = getattr(self, "a_c404", 0) + 1
                if self.a_c404 < 2:
                    self.log("音声m3u8の一時404(1/2) — 次周期に再確認します")
                    return
            self.a_running = False
            self.a_stop_reason = "404"
            self.a_dead_uri = self.a_uri
            self.log("音声m3u8が%d — レンディション欠落とみなし音声録画を停止(映像は継続・自動再開なし)" % st)
        elif st == 403:
            self.a_backoff = now_ms() + CD403 * 1000
            self.log("音声m3u8が403 — %d秒待機後に1回再解決を試みます" % CD403)
        elif st == 429:
            self.a_c429 += 1
            ms = _ra or min(CD429_BASE * (2 ** (self.a_c429 - 1)), CD429_MAX) * 1000  # v1.12.0: RA優先
            self.a_backoff = now_ms() + ms
            self.log("音声m3u8が429 — %d秒待機します(音声のみ・映像は継続)%s" % (
                ms // 1000, "(Retry-After指定)" if _ra else ""))

    def audio_fetch_seg(self, item):
        if "hls" in item:return self._fetch_hls(item,audio=True)
        wait = REQ_MIN_GAP_S - (time.time() - self.last_req)
        if wait > 0:
            time.sleep(wait)
        self.last_req = time.time()
        data, retry, settled = None, False, False
        for attempt in range(2):
            item["tries"] += 1
            st, body, _ra = self.http(item["base"] + item["name"], SEG_TIMEOUT_S)
            if st == 200 and body:
                if len(body) > 188 and body[0] == 0x47:
                    data = body
                else:
                    self.a_seg_fails += 1
                    self.log("不正な音声セグメント(同期バイト不一致): ...%s" % item["name"][-28:])
                settled = True
                break
            if st in (404, 410):
                self.a_seg_fails += 1
                self.log("音声セグメント消失(廃棄済み): ...%s" % item["name"][-28:])
                settled = True
                break
            if st == 403:
                self.a_seg_fails += 1
                self.a_backoff = now_ms() + CD403 * 1000
                self.log("音声セグメントが403 — %d秒待機します" % CD403)
                settled = True
                break
            if st == 429:
                self.a_c429 += 1
                ms = _ra or min(CD429_BASE * (2 ** (self.a_c429 - 1)), CD429_MAX) * 1000  # v1.12.0: RA優先
                self.a_backoff = now_ms() + ms
                self.log("音声セグメントが429 — %d秒待機します(音声のみ)" % (ms // 1000))
                item["tries"] -= 1
                retry = True
                settled = True
                break
            if attempt == 0:
                time.sleep(0.7 * max(1, item["tries"]))
        if not settled and data is None:
            retry = True
        return data, retry

    def audio_drain(self, limit=3):
        n = 0
        while self.a_queue and self.a_running and self.state == "RUN":
            if now_ms() < self.a_backoff:
                return
            item = self.a_queue.pop(0)
            # v2.5.0(P2): 音声キューのFIFO shadow
            _ord = item.get("_ord")
            if _ord is not None:
                _mx = getattr(self, "_ord_a_max", -1)
                if _ord < _mx:
                    self._fifo_a_violations = getattr(self, "_fifo_a_violations", 0) + 1
                self._ord_a_max = max(_mx, _ord)
            data, retry = self.audio_fetch_seg(item)
            if data:
                if not self._append_hls(item,data,audio=True):return
                self.a_seg_total += 1
                if getattr(self, "segindex_on", False):
                    si = getattr(self, "_si_awritten", None)
                    if si is None:
                        si = {}
                        self._si_awritten = si
                    si[seg_key(item)] = True
            if retry:
                if item["tries"] < SEG_MAX_TRIES:
                    self.a_queue.insert(0, item)  # 順序厳密
                    return
                self.a_seg_fails += 1
                self.log("音声セグメント取得断念(%d回): ...%s" % (item["tries"], item["name"][-28:]))
            n += 1
            if n >= limit:
                return  # 映像ループを飽させない(残りは次tick)

    def audio_tick(self):
        """メインループから毎回呼ぶ(音声のポーリング/取得/停止判定)。例外は内部吸収。"""
        if not self.audio_mode or self.state != "RUN" or self.medium != "ts" or not self.a_running:
            return
        now = now_ms()
        if now < self.a_start_at:
            return  # 要求オフセット(0.3〜0.5秒)
        if now < self.a_backoff:
            return
        if now - self.a_last_poll >= self.a_cur_poll_ms:
            self.audio_poll(now)
            if self.state == "IDLE":
                return
        self.audio_drain()
        if not self.a_queue and (time.time() - self.a_last_new) > A_STALL_S:
            self.a_running = False
            self.a_stop_reason = "stall"
            self.log("音声セグメントが%d秒間停止 — 音声録画を停止(映像は継続)" % A_STALL_S)
        self.audio_maybe_split()

    def ensure_audio_part(self):
        if self.a_part_open:
            return
        if self.state == "IDLE":
            return
        t0 = time.localtime()
        self.a_part_ext=getattr(self,"a_media_format","ts")
        def_name = "RPLAY_%s_%s_audio-p%d.%s" % (safe_name(self.oid), stamp(), self.a_part_index + 1,self.a_part_ext)
        self.a_part_name = cli_part_name(self.name_tpl, {
            "date": "%04d%02d%02d" % (t0.tm_year, t0.tm_mon, t0.tm_mday),
            "time": "%02d%02d%02d" % (t0.tm_hour, t0.tm_min, t0.tm_sec),
            "creator": self.oid,
            "title": ((self.live_info or {}).get("title") or ""),
            "quality": ((self.audio_label + "_audio") if self.audio_label else "audio"),
            "part": self.a_part_index + 1, "ext": self.a_part_ext,
        }, def_name)
        if self.name_tpl and self.a_part_index == 0:
            self.log("音声のファイル名テンプレート: %s" % self.name_tpl)
        self.a_part_name = self._unique_media_name(self.a_part_name)
        # v2.5.0(P1): 音声パートも同一契約でREQUESTEDから記録
        _led = self.ledger_part(self.a_part_name, "audio")
        self.ledger_stage(_led, "REQUESTED", segments=0, track="audio")
        self.a_part_open = True
        self.a_bytes_part = 0
        self.a_file_started = time.time()
        fd, self.a_part_tmp_path = tempfile.mkstemp(prefix=self.a_part_name + ".", suffix=".part", dir=self.out_dir)
        self.a_part_hasher = hashlib.sha256()
        self.a_fh = os.fdopen(fd, "wb")

    def push_audio(self, u8):
        self.ensure_audio_part()
        if self.a_fh:
            try:
                if self.a_fh.write(u8) != len(u8):
                    raise OSError("short write")
            except OSError as e:
                self._failed_media.add("audio")
                eno = getattr(e, "errno", None)
                self._save_error("audio",self.a_part_name,
                                 "MEDIA_WRITE_ENOSPC" if eno == errno.ENOSPC else
                                 ("MEDIA_WRITE_QUOTA" if eno == errno.EDQUOT else "MEDIA_WRITE_FAILED"))
                return
            if self.a_part_hasher:
                self.a_part_hasher.update(u8)
            self.a_bytes_part += len(u8)
            self.a_bytes_total += len(u8)

    def close_audio_part(self):
        return self._close_media_part(audio=True)

    def audio_maybe_split(self):
        if not self.a_part_open:
            return
        min_ok = self.split_min > 0 and (time.time() - self.a_file_started) >= self.split_min * 60
        if min_ok or self.a_bytes_part >= self.cap:
            self.log("自動分割(音声): %.1fMB を保存(%d本目)" % (self.a_bytes_part / 1048576, self.a_part_index + 1))
            self.close_audio_part()

    def poll_interval_ms(self, changed=True):
        return hls_reload_ms(self.target_dur,changed)

    def _playlist_get(self, url):
        self._last_media_start = now_ms()
        return self._m3u8_http(url + ("&" if "?" in url else "?") + "_rsp=" + str(now_ms()), 6)

    def poll_playlist(self):
        self.poll_count += 1  # v1.10.0: 統計
        if now_ms() < self.pl_backoff:
            return
        self.last_poll = now_ms()
        base = self.playlist_url()
        st, body = None, None
        # v1.9.0: 解決済みバリアントの直接ポーリング(master再取得を省略 — リクエスト半減。
        # masterは画質昇格チェック(maybe_quality_upgrade)でのみ定期再走査)
        cached_variant = self.best_q and self.master_url == base and self.variant_url
        if cached_variant:
            eff_base = self.variant_url
            st, body, _ra = self._playlist_get(eff_base)
            if st in (404, 410):
                fb = self.fallback_variant(eff_base)
                if fb:
                    eff_base = fb["url"]
                    st, body, _ra = self._playlist_get(eff_base)
        else:
            eff_base = base
            st, body, _ra = self._playlist_get(base)
            if st == 200 and body:
                txt0 = body.decode("utf-8", "replace")
                if "#EXT-X-STREAM-INF" in txt0:
                    # master playlist → 最高画質バリアントへ一段降りて取得(BytePlus abr/IVSの実形)
                    self.master_url = base
                    v = self.resolve_variant(txt0, base)
                    if v:
                        if self.variant_url != v:
                            self.variant_url = v
                            self.log("master playlist → バリアント解決: %s" % redact_url(v))  # v2.5.0(P2): 署名を出力しない
                            self.log("画質: %s を選択%s" % (
                                self.quality_txt,
                                "(最高・候補%d件: %s)" % (len(self.variants),
                                    " / ".join(quality_label(x) for x in self.variants[:6])) if len(self.variants) > 1 else ""))
                        self.sync_audio_source()  # v1.11.0: 音声レンディションの解決/再解決
                        eff_base = v
                        st, body, _ra = self._playlist_get(v)
                        if st in (404, 410):
                            fb = self.fallback_variant(v)
                            if fb:
                                eff_base = fb["url"]
                                st, body, _ra = self._playlist_get(eff_base)
                            elif detect_paywall_blocked(200, st):
                                Dl._note_err_kind(self, "AUTH")
                                self.log("バリアント%d(master 200 → paywall_blocked: 有料壁/権限不足の可能性)" % st)
                    else:
                        self.log("master playlistだがバリアントが解決できません — 次回再確認")
                        return
                elif self.master_url == base:
                    # 源がmedia playlistに戻った(基盤切替後など) → 画質状態をリセット
                    self.reset_quality_state()
        if st in (401, 403):
            self.pl_backoff = now_ms() + CD403 * 1000
            self.log("プレイリスト%s — アクセス制限の可能性。%d秒待機します" % (st, CD403))
            if self.member_playlist:
                # v1.8.0: 録画中の限定playlist 401/403 → 鍵(key2)を更新して再解決(90秒節流)
                if now_ms() - self._member_retry_at > 90000:
                    self._member_retry_at = now_ms()
                    self.log("限定プレイリストが制限されました — 鍵(key2)とトークンを更新して再解決します")
                    self._member_cache = None
                    if self.resolve_member("鍵更新"):
                        self.pl_backoff = 0
                        self.log("限定配信を再解決(鍵更新) → 同じplaylistで録画を継続します")
            elif self.token and now_ms() - self._member_try_at > 300000:
                # 限定配信(会員限定)の可能性: 自分のトークンで解決を試みる(5分節流)
                self._member_try_at = now_ms()
                if self.resolve_member("%s確認" % st):
                    self.pl_backoff = 0
            elif not self.token:
                self.log("会員限定の可能性 — 視聴権限がある場合は --token <自分のJWT> で録画できます(ブラウザ拡張でも可)")
            return
        if st == 429:
            self.c429 += 1
            ms = _ra or min(CD429_BASE * (2 ** (self.c429 - 1)), CD429_MAX) * 1000  # v1.12.0: RA優先
            self.pl_backoff = now_ms() + ms
            self.log("レート制限(429) — サーバー負荷配慮で%d秒待機します%s" % (
                ms // 1000, "(Retry-After指定)" if _ra else ""))
            return
        self.c429 = 0
        if st in (404, 410):
            self.c404 += 1
            if self.c404 == 2:
                self.log("プレイリスト404 — 配信終了/切替の可能性")
                # 基盤切替(BytePlus→IVS等)の可能性: 源の再探査を一度だけ試す
                if self.refresh_source("404確認"):
                    self.c404 = 0
                    self.reset_quality_state()
                    return
            limit = 3 if self.follow else 4
            if self.c404 >= limit:
                self.pending_end = "プレイリスト404×%d" % self.c404
            return
        self.c404 = 0
        if st != 200 or body is None:
            return  # 5xx/ネットワーク: 一時障害扱い
        txt = body.decode("utf-8", "replace")
        try:
            parsed=hls_parse(txt,eff_base,getattr(self,'extinf_mode','legacy'),getattr(self,'inherit_query',False),allow_aes128=getattr(self,'_dec_key_source',None) is not None)
            skip=self.audio_only or self._skip_backlog
            n_before=len(self.queue)
            added,missing=hls_enqueue(self,parsed,eff_base,skip=skip)
            for _item in self.queue[n_before:]:
                self._ord = getattr(self, "_ord", 0) + 1
                _item["_ord"] = self._ord
        except ValueError as e:
            code = str(e)
            if code == 'HLS_ENCRYPTED_UNSUPPORTED' and getattr(self,'_dec_key_source',None) is None:
                self.log('AES-128暗号化HLSです — v2.37.0の --dec-key / --dec-key auto / --dec-key-file / --dec-key-env で復号取得できます')
            if code in REC_TRANSIENT_PARSE_ERRORS and getattr(self, "seg_total", 0) > 0:
                self._bad_playlist_consec = getattr(self, "_bad_playlist_consec", 0) + 1
                self._bad_playlist_total = getattr(self, "_bad_playlist_total", 0) + 1
                if self._bad_playlist_consec <= 2:
                    self.log("プレイリストの一時的不完全応答(%s %d/2) — 停止せず次周期に再取得します" % (code, self._bad_playlist_consec))
                    return
            self._protocol_error(code);return
        if getattr(self, "_bad_playlist_consec", 0) > 0:
            self._bad_playlist_recovered = getattr(self, "_bad_playlist_recovered", 0) + 1
            self._bad_playlist_consec = 0
        self._skip_backlog=False
        if parsed['target']:self.target_dur=parsed['target']
        changed=getattr(self,'_playlist_body',None)!=txt or getattr(self,'_playlist_uri',None)!=eff_base
        self._playlist_body,self._playlist_uri=txt,eff_base
        self.last_poll=getattr(self,'_last_media_start',self.last_poll)
        self.cur_poll_ms=self.poll_interval_ms(changed);self.last_seq=parsed['sequence'];self.gaps+=missing
        if added or (skip and parsed['segments']):self.last_new=time.time()
        if parsed['endList']:self.pending_end='ENDLIST(正常終了)'

    def _protocol_error(self, code, audio=False):
        Dl._note_err_kind(self, "COMPATIBILITY")
        self.protocol_errors=getattr(self,'protocol_errors',[])+[code]
        self.log('HLSデータを採用せず: '+code)
        if audio:
            self.a_running=False;self.a_stop_reason=code;self.close_audio_part()
        else:self.stop(code)

    def _fetch_hls(self,item,audio=False):
        pre='a_' if audio else ''
        wait=REQ_MIN_GAP_S-(time.time()-self.last_req)
        if wait>0:time.sleep(wait)
        self.last_req=time.time();item['tries']+=1
        d=item['hls'];state=getattr(self,'_hls_'+pre+'state',{})
        try:
            init=None
            if d['map']:
                key=json.dumps(d['map'],sort_keys=True)
                if state.get('map_key')==key:init=state['map_bytes']
                else:
                    st,init,ra=hls_request(self,d['map'],8*1048576)
                    if init is not None:
                        hls_validate(init,'init');state.update(map_key=key,map_bytes=init)
                    else:return self._hls_status(item,st,ra,audio)
            st,data,ra=hls_request(self,d)
            if data is None:return self._hls_status(item,st,ra,audio)
            # v2.37.0(N-02): AES-128復号(平文化してから偽装剥離/検証へ)
            if d.get('keyUri'):
                data=self._dec_segment(data,d,audio)
            if not d['map'] and data and (len(data)%188 or data[0]!=0x47):
                clean_d,stripped_n,_magic=hls_strip_disguised_ts(data)
                if stripped_n>0:
                    data=clean_d
                    if not audio:
                        self._ts_disguise_stripped=getattr(self,'_ts_disguise_stripped',0)+1
                        self._ts_disguise_bytes=getattr(self,'_ts_disguise_bytes',0)+stripped_n
            data=hls_validate(data,'fragment' if d['map'] else 'ts')
            # v2.37.0(N-03): TS連続性カウンタ監査(監査のみ・非破壊)
            if not d['map'] and data and len(data)%188==0 and data[0]==0x47:
                self._cc_audit=hls_merge_cc(self._cc_audit,hls_audit_cc(data))
            item['_init']=init
            item['_boundary']=hls_part_boundary(d,getattr(self,'split_on_discontinuity',False))
            setattr(self,'_hls_'+pre+'state',state)
            if item.get('_transient_retry'):
                item.pop('_transient_retry', None)
                if audio:
                    self._a_transient_transfer_recovered = getattr(self, '_a_transient_transfer_recovered', 0) + 1
                else:
                    self._transient_transfer_recovered = getattr(self, '_transient_transfer_recovered', 0) + 1
            return data,False
        except ValueError as e:
            code = str(e)
            if code in REC_TRANSIENT_TRANSFER_ERRORS and item.get('tries', 0) < SEG_MAX_TRIES:
                item['_transient_retry'] = True
                if audio:
                    self._a_transient_transfer_retries = getattr(self, '_a_transient_transfer_retries', 0) + 1
                    self.a_backoff = now_ms() + 500
                else:
                    self._transient_transfer_retries = getattr(self, '_transient_transfer_retries', 0) + 1
                    self.seg_backoff = now_ms() + 500
                self.log('HLS一時転送寸断(%s %d/%d) — 先頭保持で再取得します' % (code, item['tries'], SEG_MAX_TRIES))
                return None,True
            setattr(self,pre+'seg_fails',getattr(self,pre+'seg_fails')+1)
            self.log('HLSデータを採用せず: '+code);return None,False
        except (OSError,TimeoutError,urllib.error.URLError,http.client.HTTPException):return None,True

    # ---- v2.37.0(N-02): AES-128復号取得(ゼロシークレット: 鍵値は一切記録しない) ----
    def _load_dec_key(self, a):
        spec=(getattr(a,"dec_key","") or "").strip()
        fpath=(getattr(a,"dec_key_file","") or "").strip()
        env=(getattr(a,"dec_key_env","") or "").strip()
        if sum(bool(x) for x in (spec,fpath,env))>1:
            raise SystemExit("--dec-key/--dec-key-file/--dec-key-envは同時に指定できません")
        self._dec_key_source=None
        if fpath:
            raw=Path(fpath).read_bytes()
            hexs=raw.decode("ascii","replace").strip()
            if re.fullmatch(r'[0-9a-fA-F]{32}',hexs):self._dec_fixed=bytes.fromhex(hexs)
            elif len(raw)==16:self._dec_fixed=bytes(raw)
            else:raise SystemExit("--dec-key-file: 32桁hexテキストまたは16バイトの鍵ファイルが必要です")
            self._dec_key_source="file"
        elif env:
            val=(os.environ.get(env,"") or "").strip()
            if not re.fullmatch(r'[0-9a-fA-F]{32}',val):
                raise SystemExit("--dec-key-env: 環境変数%sに32桁hexがありません"%env)
            self._dec_fixed=bytes.fromhex(val)
            self._dec_key_source="env"
        elif spec:
            if spec=="auto":
                self._dec_fixed=None;self._dec_key_source="auto"
            else:
                if not re.fullmatch(r'[0-9a-fA-F]{32}',spec):
                    raise SystemExit("--dec-key: 32桁hexまたは'auto'を指定してください")
                self._dec_fixed=bytes.fromhex(spec)
                self._dec_key_source="arg"
        if self._dec_key_source:
            self._dec_evidence["enabled"]=True
            self._dec_evidence["keySource"]=self._dec_key_source
            self.log("AES-128復号: 有効(鍵供給=%s・バックエンド=%s・鍵値は記録しません)" % (
                self._dec_key_source, getattr(a,"dec_backend","auto") or "auto"))

    def _ensure_dec_key(self, uri):
        if self._dec_key_source in ("arg","file","env"):
            self._dec_key_uris.add(uri)
            return self._dec_fixed
        k=self._dec_keys.get(uri)
        if k is None:
            k=self._fetch_dec_key(uri)
            self._dec_keys[uri]=k
        self._dec_key_uris.add(uri)
        return k

    def _fetch_dec_key(self, uri):
        # 公式プレイヤーと同一のヘッダ(要求者を示すヘッダ+ageアンチボット乱数)
        headers={"User-Agent":self.ua,
                 "rplay-private-content-requestor":(getattr(self.auth,"user_oid","") or "not-logged-in"),
                 "age":str(random.randint(1,4999))}
        for attempt in range(3):
            try:
                req=urllib.request.Request(uri,headers=headers)
                with urllib.request.urlopen(req,timeout=15) as r:
                    b=r.read(64)
                if len(b)==16:return b
                raise ValueError('HLS_DECRYPT_KEY')
            except urllib.error.HTTPError as e:
                e.close()
                if e.code==403:
                    self.log('鍵リクエストが403 — この動画への視聴権限がありません')
                    raise ValueError('HLS_DEC_KEY_DENIED') from None
                if e.code==429:
                    time.sleep(min(CD429_BASE*(2**attempt),CD429_MAX))
                    continue
                last=e.code
            except (OSError,TimeoutError):
                last=0
            time.sleep(0.5*(attempt+1))
        raise ValueError('HLS_DEC_KEY_UNAVAILABLE')

    def _dec_iv(self, d):
        hx=d.get('keyIvHex')
        if hx:
            return bytes.fromhex(hx[2:] if hx[:2].lower()=='0x' else hx)
        # IV属性が無い場合はメディアシーケンス番号(64bit big-endian・userscript ivForと同一)
        return int(d.get('sequence') or 0).to_bytes(16,'big')

    def _dec_segment(self, data, d, audio=False):
        ev=self._dec_evidence
        try:
            key=self._ensure_dec_key(d['keyUri'])
            iv=self._dec_iv(d)
            backend=self.dec_backend
            if backend=='auto':
                backend='openssl' if hls_openssl_bin() else 'python'
            t0=time.perf_counter()
            plain=hls_aes128_cbc_decrypt(key,iv,data,backend=backend)
            el=(time.perf_counter()-t0)*1000.0
            ev['keyCount']=len(self._dec_key_uris)
            ev['segmentsDecrypted']+=1
            ev['bytesDecrypted']+=len(data)
            ev['elapsedMs']=round(ev['elapsedMs']+el,1)
            ev['segmentsByBackend'][backend]=ev['segmentsByBackend'].get(backend,0)+1
            return plain
        except ValueError as e:
            ev['keyCount']=len(self._dec_key_uris)
            ev['segmentsFailed']+=1
            raise  # 外側の_fetch_hlsのValueError分類へ(リトライ無意味な復号失敗として扱う)

    def _dec_evidence_block(self):
        ev=getattr(self,"_dec_evidence",None)
        if not ev or not ev.get("enabled"):return None
        el=ev["elapsedMs"]
        return {"enabled":True,"method":"AES-128","keySource":ev["keySource"],
                "keyCount":ev["keyCount"],
                "segmentsDecrypted":ev["segmentsDecrypted"],"segmentsFailed":ev["segmentsFailed"],
                "bytesDecrypted":ev["bytesDecrypted"],"elapsedMs":el,
                "approxMbps":(round(ev["bytesDecrypted"]*8/el/1000,2) if el>0 else 0),
                "segmentsByBackend":ev["segmentsByBackend"],
                "zeroSecret":"decryption-key-never-recorded"}

    def _hls_status(self,item,status,ra,audio):
        pre='a_' if audio else ''
        if status==429:
            attr=pre+'c429';count=getattr(self,attr)+1;setattr(self,attr,count)
            ms=ra or min(CD429_BASE*(2**min(count-1,16)),CD429_MAX)*1000
            setattr(self,'a_backoff' if audio else 'seg_backoff',now_ms()+ms);item['tries']-=1
            return None,True
        if status==503 and ra:setattr(self,'a_backoff' if audio else 'seg_backoff',now_ms()+ra)
        if status>=500 or status==0:return None,True
        if status==403:setattr(self,'a_backoff' if audio else 'seg_backoff',now_ms()+CD403*1000)
        setattr(self,pre+'seg_fails',getattr(self,pre+'seg_fails')+1)
        return None,False

    def _append_hls(self,item,data,audio=False):
        if self.state!='RUN' or (audio and not self.a_running):return False
        pre='a_' if audio else ''
        push=self.push_audio if audio else self.push
        if 'hls' not in item:push(data);return True
        boundary=item['_boundary'];attr='_hls_'+pre+'boundary'
        if not audio:
            d_hls=item['hls'];disc_key=(d_hls.get('epoch',0),d_hls.get('discontinuity',0))
            prev_disc=getattr(self,'_hls_last_disc_key',None)
            if getattr(self,pre+'part_open') and prev_disc is not None and prev_disc!=disc_key:
                if getattr(self,attr,None)!=boundary:
                    self._disc_split=getattr(self,'_disc_split',0)+1
                else:
                    self._disc_merged=getattr(self,'_disc_merged',0)+1
            self._hls_last_disc_key=disc_key
        if getattr(self,pre+'part_open') and getattr(self,attr,None)!=boundary:
            evidence=getattr(self,"part_boundary_evidence",{})
            label="audio_hls_boundary" if audio else "video_hls_boundary"
            evidence[label]=evidence.get(label,0)+1;self.part_boundary_evidence=evidence
            (self.close_audio_part if audio else self.close_part)()
        if self.state!='RUN':return False
        setattr(self,pre+'media_format','mp4' if item['hls']['map'] else 'ts');setattr(self,attr,boundary)
        if not getattr(self,pre+'part_open') and item.get('_init'):push(item['_init'])
        if self.state!='RUN':return False
        push(data);return self.state=='RUN'

    # ---- セグメント取得(ステータス厳密分類・順序厳密) ----
    def fetch_seg(self, item):
        if "hls" in item:return self._fetch_hls(item)
        wait = REQ_MIN_GAP_S - (time.time() - self.last_req)
        if wait > 0:
            time.sleep(wait)
        self.last_req = time.time()
        data, retry, settled = None, False, False
        for attempt in range(2):
            item["tries"] += 1
            st, body, _ra = self.http(item["base"] + item["name"], SEG_TIMEOUT_S)
            if st == 200 and body:
                if len(body) > 188 and body[0] == 0x47:
                    data = body
                else:
                    self.seg_fails += 1
                    self.log("不正セグメント(同期バイト不一致): ...%s" % item["name"][-28:])
                settled = True
                break
            if st in (404, 410):
                self.seg_fails += 1
                self.log("セグメント消失(廃棄済み): ...%s" % item["name"][-28:])
                settled = True
                break
            if st == 403:
                self.seg_fails += 1
                self.seg_backoff = now_ms() + CD403 * 1000
                self.log("アクセス制限(403) — %d秒待機します" % CD403)
                settled = True
                break
            if st == 429:
                self.c429 += 1
                ms = _ra or min(CD429_BASE * (2 ** (self.c429 - 1)), CD429_MAX) * 1000  # v1.12.0: RA優先
                self.seg_backoff = now_ms() + ms
                self.log("レート制限(429) — サーバー負荷配慮で%d秒待機します%s" % (
                    ms // 1000, "(Retry-After指定)" if _ra else ""))
                item["tries"] -= 1
                retry = True
                settled = True
                break
            # 5xx/0/タイムアウト → 時間差で再試行
            if attempt == 0:
                time.sleep(0.7 * max(1, item["tries"]))
        if not settled and data is None:
            retry = True  # 2回とも失敗(5xx/ネットワーク) → 再試行継続
        return data, retry

    def drain(self):
        while self.queue and self.state == "RUN":
            if now_ms() < self.seg_backoff:
                return
            item = self.queue.pop(0)
            # v2.5.0(P2): FIFO shadow — 取得順が登録順と一致する事実を実測する
            _ord = item.get("_ord")
            if _ord is not None:
                _mx = getattr(self, "_ord_max", -1)
                if _ord < _mx:
                    self._fifo_violations = getattr(self, "_fifo_violations", 0) + 1
                    self.log("警告: セグメント取得順が登録順を遡りました(ord=%d < max=%d)" % (_ord, _mx))
                self._ord_max = max(_mx, _ord)
            data, retry = self.fetch_seg(item)
            if data:
                if not self._append_hls(item,data):return
                self.seg_part += 1
                self.seg_total += 1
                if getattr(self, "segindex_on", False):  # v2.5.0: 書込済み鍵を記録(再起動時の重複防止)
                    si = getattr(self, "_si_written", None)
                    if si is None:
                        si = {}
                        self._si_written = si
                    si[seg_key(item)] = True
            if retry:
                if item["tries"] < SEG_MAX_TRIES:
                    self.queue.insert(0, item)  # 順序厳密: 先頭に戻す(後続を先に書かない)
                    return
                self.seg_fails += 1
                self.log("セグメント取得断念(%d回): ...%s" % (item["tries"], item["name"][-28:]))

    # ---- パート入出力 ----
    def ensure_part(self):
        if self.part_open:
            return
        if self.state == "IDLE":
            return  # 停止済み — 新規パートを作らない
        self.part_ext = "flv" if self.medium == "flv" else getattr(self,"media_format","ts")
        t0 = time.localtime()
        def_name = "RPLAY_%s_%s_p%d.%s" % (safe_name(self.oid), stamp(), self.part_index + 1, self.part_ext)
        self.part_name = cli_part_name(self.name_tpl, {
            "date": "%04d%02d%02d" % (t0.tm_year, t0.tm_mon, t0.tm_mday),
            "time": "%02d%02d%02d" % (t0.tm_hour, t0.tm_min, t0.tm_sec),
            "creator": self.oid,
            "title": ((self.live_info or {}).get("title") or ""),
            "quality": self.quality_txt or "",
            "part": self.part_index + 1, "ext": self.part_ext,
        }, def_name)
        if self.name_tpl and self.part_index == 0:
            self.log("ファイル名テンプレート: %s" % self.name_tpl)
        self.part_name = self._unique_media_name(self.part_name)
        # v2.5.0(P1): 保存確定イベント契約 — REQUESTED段階(パート生成)から記録
        _led = self.ledger_part(self.part_name, "video")
        self.ledger_stage(_led, "REQUESTED", segments=0, track="video")
        self.part_open = True
        self.bytes_part = 0
        self.seg_part = 0
        self.file_started = time.time()
        fd, self.part_tmp_path = tempfile.mkstemp(prefix=self.part_name + ".", suffix=".part", dir=self.out_dir)
        self.part_hasher = hashlib.sha256()
        self.fh = os.fdopen(fd, "wb")

    def recover_orphan_parts(self):
        """Report candidates only; never promote/delete unowned or unvalidated data.
        v2.5.0(P2): sha256とmtimeを含む孤立part台帳(orphan_ledger.json)を原子書込。
        昇格・削除は行わない(人間の判断を待つ)。ハッシュ計算は件数を限定して
        起動を遅らせない。"""
        self.recovered_orphans = []
        hashed = 0
        for path in sorted(Path(self.out_dir).glob("RPLAY_*.part")):
            if path.is_symlink() or not path.is_file():
                continue
            try:
                st = path.stat()
            except OSError:
                continue
            rec = {"file":path.name,"bytes":st.st_size,"mtime":iso(st.st_mtime),
                   "status":"unverified_partial"}
            if hashed < ORPHAN_HASH_MAX and st.st_size > 0:
                try:
                    h = hashlib.sha256()
                    with open(path,"rb") as f:
                        for chunk in iter(lambda: f.read(1048576), b""):
                            h.update(chunk)
                    rec["sha256"] = h.hexdigest()
                    hashed += 1
                except OSError:
                    pass
            self.recovered_orphans.append(rec)
        if self.recovered_orphans:
            try:
                _atomic_write_json(os.path.join(self.out_dir, "orphan_ledger.json"),
                                   {"tool":"rplay_dl.py v2.50.0",
                                    "policy":"report_only_no_promotion",
                                    "foundAt":iso(time.time()),
                                    "parts":self.recovered_orphans})
            except Exception:
                pass
            self.log("未検証の部分ファイル%d件を保持（自動確定しません — orphan_ledger.jsonへ記録）" % len(self.recovered_orphans))

    @staticmethod
    def _unique_media_name(name):
        stem, ext = os.path.splitext(os.path.basename(name))
        return stem[:130] + "_" + uuid.uuid4().hex + ext

    def _save_error(self, track, name, code):
        Dl._note_err_kind(self, "INTERNAL")
        if not hasattr(self, "save_errors"):
            self.save_errors = []
        self.save_errors.append({"track":track,"file":os.path.basename(name),"code":code})
        self.state = "IDLE"
        self.log("保存失敗: %s — %s（部分ファイルを保持）" % (os.path.basename(name), code))
        webhook_post(getattr(self, "webhook", ""), "save_error", {  # v2.7.0(A-04)
            "creatorOid": getattr(self, "oid", ""), "track": track,
            "file": os.path.basename(name), "code": code}, level="error")

    def _close_media_part(self, audio=False):
        pre = "a_" if audio else ""
        attr = lambda n: getattr(self, pre + n)
        if not attr("part_open"):
            return True
        setattr(self, pre+"part_open", False)
        name, tmp, fh = attr("part_name"), attr("part_tmp_path"), attr("fh")
        size = attr("bytes_part")
        track = "audio" if audio else "video"
        try:
            if track in getattr(self,"_failed_media",set()):
                raise OSError("earlier write failed")
            if fh is None:
                raise OSError("missing writable")
            fh.flush()
            os.fsync(fh.fileno())
            fh.close()
            setattr(self, pre+"fh", None)
            if not size:
                os.unlink(tmp)
                # v2.5.0(P1): 空パートは失敗ではない — REQUESTED台帳項目を除去
                by = getattr(self, "_ledger_by_name", None) or {}
                ent = by.pop((track, name), None)
                led = getattr(self, "ledger", None)
                if ent is not None and led is not None and ent in led.get("parts", []):
                    led["parts"].remove(ent)
                return True
            if os.path.islink(tmp) or not os.path.isfile(tmp) or os.path.getsize(tmp) != size:
                raise OSError("staging size mismatch")
            with open(tmp,"rb") as check:
                actual = hashlib.file_digest(check,"sha256").hexdigest()
            digest = attr("part_hasher").hexdigest()
            if actual != digest:
                raise OSError("staging hash mismatch")
            final = os.path.join(self.out_dir,name)
            # Atomic no-overwrite publication on filesystems supporting hardlinks.
            # Unsupported FS fails closed; do not replace an existing file.
            os.link(tmp, final)
            temp_retained = False
            try:
                os.unlink(tmp)
            except OSError:
                temp_retained = True
            entry = {"file":name,"ext":getattr(self,"a_part_ext","ts") if audio else self.part_ext,"bytes":size,
                     "sha256":digest,"startedAt":iso(attr("file_started")),"endedAt":iso(time.time()),
                     "status":"committed","tempRetained":temp_retained}
            if audio:
                entry["kind"] = "audio"
                self.audio_parts_log.append(entry)
            else:
                entry["segments"] = self.seg_part
                self.parts_log.append(entry)
            # v2.5.0(P1): 保存確定イベント契約 — FILE_WRITTEN→HASHED(実測順)
            _led = self.ledger_part(name, "audio" if audio else "video")
            self.ledger_stage(_led, "FILE_WRITTEN", bytes=size, nonOverwrite=True)
            self.ledger_stage(_led, "HASHED", sha256=digest)
            self.ledger_set_status(_led)
            if not audio:
                self.segindex_flush()  # v2.5.0: パート確定のたびに既知鍵を永続化
            _wb = getattr(self, "webhook", "")
            if _wb:
                if audio:
                    webhook_post(_wb, "audio_part", {
                        "creatorOid": self.oid, "file": name, "bytes": size,
                        "sha256": digest})
                else:
                    webhook_post(_wb, "part", {
                        "creatorOid": self.oid, "file": name,
                        "bytes": size, "segments": self.seg_part,
                        "sha256": digest, "part": attr("part_index") + 1})
            self.log("保存確定: %s (%.1fMB / sha256:%s…)" % (name,size/1048576,digest[:12]))
            return True
        except (OSError, ValueError) as e:
            if fh is not None:
                try: fh.close()
                except OSError: pass
            # v2.5.0(P2): quota系エラーを区別して記録(ENOSPC/EDQUOT)
            code = "MEDIA_COMMIT_FAILED"
            eno = getattr(e, "errno", None)
            if eno == errno.ENOSPC:
                code = "MEDIA_COMMIT_ENOSPC"
            elif eno == errno.EDQUOT:
                code = "MEDIA_COMMIT_QUOTA"
            self._save_error(track, name, code)
            _led = (getattr(self, "_ledger_by_name", None) or {}).get((track, name))
            if _led is not None:
                _led["status"] = "failed_" + code.lower()
                _led["failCode"] = code
                try:
                    _atomic_write_json(self.ledger_path, getattr(self, "ledger", {}))
                except Exception:
                    pass
            return False
        finally:
            setattr(self, pre+"fh", None)
            setattr(self, pre+"part_hasher", None)
            setattr(self, pre+"part_index", attr("part_index")+1)


    def push(self, u8):
        with self.wlock:
            if self.state == "IDLE" and not self.part_open:
                return
            self.ensure_part()
            if self.fh:
                tnow = time.time()
                if self._seg_iv_last:
                    self._seg_iv_sum += (tnow - self._seg_iv_last) * 1000.0
                    self._seg_iv_n += 1
                self._seg_iv_last = tnow
                try:
                    if self.fh.write(u8) != len(u8):
                        raise OSError("short write")
                except OSError as e:
                    self._failed_media.add("video")
                    eno = getattr(e, "errno", None)
                    self._save_error("video",self.part_name,
                                     "MEDIA_WRITE_ENOSPC" if eno == errno.ENOSPC else
                                     ("MEDIA_WRITE_QUOTA" if eno == errno.EDQUOT else "MEDIA_WRITE_FAILED"))
                    return
                if self.part_hasher:
                    self.part_hasher.update(u8)
                self.bytes_part += len(u8)
                self.bytes_total += len(u8)

    def close_part(self):
        with self.wlock:
            return self._close_media_part(audio=False)

    def maybe_split(self):
        if not self.part_open:
            return
        min_ok = self.split_min > 0 and (time.time() - self.file_started) >= self.split_min * 60
        if min_ok or self.bytes_part >= self.cap:
            evidence=getattr(self,"part_boundary_evidence",{});reason="size_limit" if self.bytes_part>=self.cap else "time_limit"
            evidence[reason]=evidence.get(reason,0)+1;self.part_boundary_evidence=evidence
            self.log("自動分割: %.1fMB を保存(%d本目)" % (self.bytes_part / 1048576, self.part_index + 1))
            self.close_part()

    def check_stall(self):
        if not self.queue and (time.time() - self.last_new) > END_STALL_S:
            self.pending_end = "新セグメント%d秒間停止" % END_STALL_S

    # ---- 追跡待機 ----
    def probe(self):
        # v1.7.0: 源候補を順に探査して生きた源を採用(新旧基盤の自動フォールバック)
        for cand in self.hls_candidates():
            st, body, _ra = self._m3u8_http(cand + ("&" if "?" in cand else "?") + "_rsp=" + str(now_ms()), 6)
            if st == 200 and body:
                t = body.decode("utf-8", "replace")
                if "#EXTM3U" not in t and "#EXTINF" not in t and "#EXT-X-STREAM-INF" not in t:
                    continue  # m3u8でない(JSON/HTML等)
                if cand != self.live_m3u8:
                    self.live_m3u8 = cand
                    kind = ("手動" if cand == self.m3u8_custom else
                            "abr(新基盤)" if (self.live_info or {}).get("bytePlusPlaybackUrl") == cand else
                            "ivs(新基盤)" if (self.live_info or {}).get("playUrl") == cand else "従来")
                    self.log("HLS源を確定: %s %s" % (kind, redact_url(cand)))  # v2.5.0(P2)
                if "#EXTINF" in t:
                    return "live"
                if "ENDLIST" in t:
                    return "offline"
                if "#EXT-X-STREAM-INF" in t:
                    # master playlist: variantまで見て live/offline を正確に判定
                    v = self.resolve_variant(t, cand)
                    if v:
                        st2, body2, _ra2 = self._m3u8_http(v + ("&" if "?" in v else "?") + "_rsp=" + str(now_ms()), 6)
                        if st2 == 200 and body2:
                            t2 = body2.decode("utf-8", "replace")
                            return "live" if "#EXTINF" in t2 else ("offline" if "ENDLIST" in t2 else "live")
                    return "offline"  # variantが取れない=配信はまだ無い
                return "live"
            if st in (401, 403):
                return "token"
        return "offline"

    def api_state(self):
        st, body, _ra = self.http(self.api + "/live/stream?creatorOid=" + self.oid, 6, headers=HDR_API)
        if st == 200 and body:
            try:
                return "live" if json.loads(body.decode("utf-8", "replace")).get("streamState") == "live" else "off"
            except Exception:
                return "unknown"
        return "unknown"

    def refresh_source(self, reason):
        """v1.7.0: 詮索やり直し+源再探査(基盤切替への追従)。60秒節流"""
        if self._src_at and now_ms() - self._src_at < 60000:
            return False
        self._src_at = now_ms()
        self.scent()
        cur = self.playlist_url()
        for cand in self.hls_candidates():
            if cand == cur:
                continue
            st, body, _ra = self.http(cand + "?_rsp=" + str(now_ms()), 6, headers=HDR_M3U8)
            if st == 200 and body:
                t = body.decode("utf-8", "replace")
                if "#EXTM3U" in t or "#EXTINF" in t or "#EXT-X-STREAM-INF" in t:
                    self.live_m3u8 = cand
                    self.src_switches += 1  # v1.10.0: 基盤切替の統計
                    self.log("HLS源を切替(%s): %s" % (reason, redact_url(cand)))  # v2.5.0(P2)
                    return True
        return False

    def standby_probe(self):
        self.last_standby = now_ms()
        if self.standby_limit and now_ms() - self.standby_since > self.standby_limit:
            self.stop("追跡待機の制限時間%d分に到達" % (self.standby_limit // 60000))
            return
        if self.flv_running:
            return  # FLV代替が受信中 — そちらを優先(二重取得を避ける)
        if self.refresh_source("待機中探査") and self.probe() == "live":
            self.resume("ts", "配信基盤の切替を検出")
            return
        if self.probe() == "live":
            self.resume("ts", "配信の復帰を検出")
            return
        if self.api_state() == "live":
            if self.refresh_source("API検出"):
                self.resume("ts", "API検出+配信基盤の切替に成功")
                return
            self.last_standby = 0  # 次ループで即再探索
            return
        # v1.8.0: 配信予約(--token+--wait-schedule時)。開始時刻を過ぎたら探索強化
        if self.wait_sched:
            item = self.schedule_info()
            if item:
                remain = item["scheduledAt"] - time.time()
                if remain > 0:
                    if remain <= 300 and self._sched_last != item["scheduledAt"]:
                        self._sched_last = item["scheduledAt"]
                        self.log("📡 予約「%s」%s開始予定 — 残り%d分" % (
                            item["title"] or "無題",
                            datetime.fromtimestamp(item["scheduledAt"]).strftime("%H:%M"),
                            int(remain // 60) + 1))
                else:
                    if self._sched_notify != item["scheduledAt"]:
                        self._sched_notify = item["scheduledAt"]
                        self.log("📡 予約「%s」の開始時刻を過ぎました — 探索を強化します" % (item["title"] or "無題"))
                    self.last_standby = 0  # 次ループで即再探索
                    return
        if self.flv_ok and not self.flv_running and now_ms() - self.flv_last_fail > FLV_COOLDOWN_S * 1000:
            self.try_flv()

    def try_flv(self):
        """FLV代替録画を別スレッドで開始(メインループを塞がない)。成功時は状態RUNへ"""
        if self.flv_running:
            return
        self.flv_running = True
        self.medium = "flv"
        self.log("HLS不通 → FLVストリームへ代替録画を試行…")
        threading.Thread(target=self._flv_loop, daemon=True).start()

    def _flv_loop(self):
        got = False
        try:
            req = urllib.request.Request(self.flv_url, headers={"User-Agent": self.ua})
            resp = urllib.request.urlopen(req, timeout=SEG_TIMEOUT_S)
            self.flv_resp = resp
            head = b""
            header_ok = False
            while self.state != "IDLE":
                chunk = resp.read(64 * 1024)
                if not chunk:
                    raise IOError("ストリーム終端")
                if not header_ok:
                    head += chunk
                    if len(head) < 9:
                        continue
                    if head[:3] != b"FLV":
                        raise IOError("FLVヘッダ不一致")
                    header_ok = True
                    self.push(head)
                else:
                    self.push(chunk)
                self.last_new = time.time()
                if not got:
                    got = True
                    self.state = "RUN"
                    self.log("FLV受信を確認 — FLV無劣化のまま録画を継続します")
        except Exception as e:
            self.flv_failed(e)
        finally:
            self.flv_running = False

    def flv_failed(self, e):
        had = self.bytes_part > 0
        if self.flv_resp:
            try:
                self.flv_resp.close()
            except Exception:
                pass
            self.flv_resp = None
        if had:
            self.close_part()
        self.medium = "ts"
        self.flv_last_fail = now_ms()
        if self.state == "RUN":
            self.state = "STANDBY"
            self.standby_since = now_ms()
            self.log("FLV切断(%s) → 追跡待機へ戻る" % (e or "切断"))

    def resume(self, medium, why):
        if self.state == "RUN":
            return
        # v2.5.0: 世代復旧 — 追跡再開は録画済みpath記録だけを引き継ぐ
        # (同じ配信の回復windowを重複録画しない。新配信は新pathで自然に記録される)
        _keep_uris = (getattr(self, "_hls_state", {}) or {}).get("uris")
        _keep_a_uris = (getattr(self, "_hls_a_state", {}) or {}).get("uris")
        self._hls_state = ({"uris": _keep_uris} if _keep_uris else {})
        self._hls_a_state = ({"uris": _keep_a_uris} if _keep_a_uris else {})
        self._hls_last_disc_key = None
        self.medium = medium
        self.state = "RUN"
        self.c404 = 0
        self.last_seq = -1
        self._skip_backlog = False  # 再開時は新配信を全て取得
        self.last_new = time.time()
        self.pending_end = None
        self._playlist_body = None
        self._playlist_uri = None
        self.resumes += 1
        self.log("%s → 録画を再開(%s / セッション%d)" % (why, medium.upper(), self.resumes + 1))
        if medium == "ts":
            self.poll_playlist()
            self.drain()

    def finish_run(self, reason):
        self.close_part()
        if self.follow:
            self.state = "STANDBY"
            self.standby_since = now_ms()
            self.medium = "ts"
            self.log("配信終了を検出(%s) → 追跡待機へ。次の配信を自動探索します(%d秒間隔)" %
                     (reason, STANDBY_MS // 1000))
        else:
            self.stop("配信終了(%s)" % reason)

    def stop(self, reason):
        self.state = "IDLE"  # 先に停止フラグ(FLVスレッドの新規書込を止める)
        if self.flv_resp:
            try:
                self.flv_resp.close()
            except Exception:
                pass
            self.flv_resp = None
        self.close_part()
        if self.audio_mode:
            self.close_audio_part()  # v1.11.0: 音声パートも確定保存
        self.log("録画終了(%s) — 計%s / %.1fMB / seg%d%s / 保存%d本%s%s%s" % (
            reason, fmt_dur(now_ms() - int(self.started * 1000)),
            self.bytes_total / 1048576, self.seg_total,
            (" / 画質%s%s" % (self.quality_txt, "(昇格%d回)" % self.quality_upgrades if self.quality_upgrades else "")) if self.quality_txt else "",
            self.saved_n(),
            (" / 音声%dseg" % self.a_seg_total) if self.a_seg_total else "",
            " / 追跡再開%d回" % self.resumes if self.resumes else "",
            " / 欠落疑い%d" % (self.seg_fails + self.gaps) if (self.seg_fails or self.gaps) else ""))
        # v2.5.0(P1): 実メディア品質監査(DECODED/CONTINUITY段階の証拠源)
        # 情報JSONの保存前に実施して監査結果を含める
        self.run_qaudit()
        # v2.7.0: リマックス前にメタデータ埋め込み文脈を確定。情報JSONは mux の後に
        # 保存する(品質監査結果とmetadataEvidenceの両方を含めるため)。
        meta_ctx = self._mp4_meta_ctx()
        # v2.10.0(AGGREGATE) + v2.15.0統合: 互換パートが複数ある場合は rplay_join.py で検証付き単一MP4化
        joined = False
        self.aggregate_evidence = {"status": "NOT_REQUESTED"}
        if self.mux != "no" and getattr(self, "join_parts_mode", "auto") != "no" and len(self.parts_log) > 1:
            try:
                has_sep_audio = bool(self.audio_mode and self.audio_parts_log)
                if has_sep_audio and not getattr(self, "mux_audio_parts", False):
                    raise ValueError("JOIN_SEPARATE_AUDIO_REQUIRES_MUX")
                import importlib.util
                helper_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "rplay_join.py")
                spec = importlib.util.spec_from_file_location("rsp_local_join", helper_path)
                helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
                job = {"parts": self.parts_log, "incomplete": bool(self.seg_fails + self.gaps or self.save_errors)}
                if has_sep_audio:
                    job["audioRendition"] = {"parts": self.audio_parts_log}
                self.aggregate_evidence = helper.join_parts(
                    job, self.out_dir,
                    metadata=dict(x.split("=", 1) for x in mp4_metadata_args(meta_ctx)[1::2]),
                    mux_audio=has_sep_audio)
                joined = True
                self._note_metadata(os.path.join(self.out_dir, self.aggregate_evidence["file"]), meta_ctx)
                self.log("まとめ保存: %d本 → %s（原本保持・全編デコード検証済み）" % (
                    len(self.parts_log), self.aggregate_evidence["file"]))
            except Exception as exc:
                code = str(exc)
                if not re.fullmatch(r"JOIN_[A-Z_]+", code):
                    code = "JOIN_FAILED"
                self.aggregate_evidence = {"status": "FAILED", "code": code, "originalsRetained": True}
                self.log("まとめ保存を見送り: " + code + " — 原本を保持します")
        # v1.10.0: TS→MP4リマックス(ffmpegストリームコピー・無劣化)
        if self.mux != "no":
            import shutil
            for p in ([] if joined else list(self.parts_log)):
                if p.get("ext") != "ts" or not p.get("file"):
                    continue
                ts_path = os.path.join(self.out_dir, p["file"])
                if not os.path.exists(ts_path):
                    continue
                if self.mux == "mp4" and not shutil.which("ffmpeg"):
                    self.log("--mux mp4 が指定されていますがffmpegが見つかりません — TSのまま保存します")
                    break
                out_mp4 = ts_path[:-3] + ".mp4"
                if remux_mp4(ts_path, self.log, meta_ctx):
                    self._note_metadata(out_mp4, meta_ctx)  # v2.7.0(A-05)
                    webhook_post(getattr(self, "webhook", ""), "merge_completed", {  # v2.7.0(A-04)
                        "creatorOid": self.oid, "file": os.path.basename(out_mp4),
                        "bytes": (os.path.getsize(out_mp4) if os.path.exists(out_mp4) else 0),
                        "kind": "remux", "tags": mp4_metadata_tags(meta_ctx)}, level="info")
            # v1.11.0: 2トラックmux(映像TS+音声TSが同数ある場合・無劣化)
            if self.audio_mode and self.audio_parts_log:
                import shutil
                vps = [p for p in self.parts_log if p.get("ext") == "ts" and p.get("kind") != "audio"]
                aps = self.audio_parts_log
                if vps and len(vps) == len(aps):
                    if not shutil.which("ffmpeg"):
                        self.log("ffmpegが見つからず2トラックmuxをスキップ(TSのまま保存)")
                    else:
                        for vp, ap in zip(vps, aps):
                            v_path = os.path.join(self.out_dir, vp["file"])
                            a_path = os.path.join(self.out_dir, ap["file"])
                            if os.path.exists(v_path) and os.path.exists(a_path):
                                out_mp4 = v_path[:-3] + "_2track.mp4"
                                if mux_two_track(v_path, a_path, out_mp4, self.log, meta_ctx):
                                    self._note_metadata(out_mp4, meta_ctx)  # v2.7.0(A-05)
                                    webhook_post(getattr(self, "webhook", ""), "merge_completed", {  # v2.7.0(A-04)
                                        "creatorOid": self.oid, "file": os.path.basename(out_mp4),
                                        "bytes": (os.path.getsize(out_mp4) if os.path.exists(out_mp4) else 0),
                                        "kind": "two_track", "tags": mp4_metadata_tags(meta_ctx)}, level="info")
                elif vps and aps:
                    self.log("映像/音声のパート数が不一致(%d/%d)のため2トラックmuxをスキップ" % (len(vps), len(aps)))
        # v2.11.0(W-06): 複数パート自動結合(--concat-parts auto|mp4|ts|no)
        c_mode = getattr(self, "concat_parts", "no") or "no"
        if c_mode != "no":
            v_ts = [os.path.join(self.out_dir, p["file"]) for p in self.parts_log
                    if p.get("ext") == "ts" and p.get("kind") != "audio" and p.get("file")]
            v_ts = [p for p in v_ts if os.path.exists(p) and os.path.getsize(p) > 0]
            if len(v_ts) >= 2:
                import shutil
                use_mp4 = (c_mode == "mp4") or (c_mode == "auto" and bool(shutil.which("ffmpeg")))
                ext_out = "mp4" if use_mp4 else "ts"
                merged_name = "RPLAY_%s_%s_merged.%s" % (safe_name(self.oid), stamp(), ext_out)
                merged_path = os.path.join(self.out_dir, merged_name)
                if concat_media_parts(v_ts, merged_path, self.log, ctx=meta_ctx, mode=("ts" if ext_out == "ts" else "auto")):
                    self._parts_concatenated = len(v_ts)
                    self._concat_output = merged_name
                    if ext_out == "mp4":
                        self._note_metadata(merged_path, meta_ctx)
                    webhook_post(getattr(self, "webhook", ""), "merge_completed", {
                        "creatorOid": self.oid, "file": merged_name,
                        "bytes": (os.path.getsize(merged_path) if os.path.exists(merged_path) else 0),
                        "kind": "concat_parts", "partsCount": len(v_ts)}, level="info")
        if self.info_json:
            self.save_info()
        # v2.5.0: 終了時の運用状態 — stop-file除去/最終heartbeat/segindex確定/台帳確定/end通知
        self._final_ops(reason)

    def _mp4_meta_ctx(self):
        """v2.7.0(A-05): MP4メタデータの埋め込み文脈。分かる値だけを返す
        (未知の値は空のまま — 埋め込み側の契約で省かれる)。"""
        li = self.live_info or {}
        return {"creatorOid": (self.oid or ""),
                "streamOid": (li.get("streamOid") or ""),
                "streamStartedAt": (li.get("startedAt") or li.get("streamStartTime") or ""),
                "recordingStartedAt": (iso(getattr(self, "started", 0) or time.time())),
                "title": (li.get("title") or ""),
                "artist": (li.get("nickname") or li.get("creatorNickname") or "")}

    def _note_metadata(self, out_path, ctx):
        """v2.7.0(A-05): メタデータ埋め込みの記録(metadataEvidenceの証拠源)。"""
        if not hasattr(self, "_meta_events"):
            self._meta_events = []
        self._meta_events.append({"file": os.path.basename(out_path),
                                  "tags": mp4_metadata_tags(ctx)})

    def _final_ops(self, reason):
        """終了時の運用後処理(stop()とrun()末尾の両方から呼ぶ。二重実行しない)。"""
        if getattr(self, "_final_done", False):
            return
        self._final_done = True
        try:
            if os.path.exists(getattr(self, "stop_file", "")):
                os.unlink(self.stop_file)
        except OSError:
            pass
        try:
            self.hb_write()
        except Exception:
            pass
        if getattr(self, "segindex_on", False):
            self._si_saved_at = 0.0
            self.segindex_flush()
        if getattr(self, "ledger_path", None):
            try:
                _atomic_write_json(self.ledger_path, getattr(self, "ledger", {}))
            except Exception:
                pass
        webhook_post(getattr(self, "webhook", ""), "end", {
            "creatorOid": self.oid, "reason": reason,
            "bytes": self.bytes_total, "segments": self.seg_total,
            "files": self.saved_n(), "audioSeg": self.a_seg_total,
            "missingSuspect": self.seg_fails + self.gaps,
            "fifoViolations": getattr(self, "_fifo_violations", 0) + getattr(self, "_fifo_a_violations", 0)}, wait=True)

    def save_info(self):
        if not self.parts_log and not self.audio_parts_log and not self.save_errors:
            return  # v1.11.0: --audio-onlyでは音声パートのみでも情報JSONを出す
        _tot = self.seg_total + self.seg_fails + self.gaps + self.byterange_skipped  # v1.12.0
        info = {
            "tool": "RPLAY Live Downloader (rplay_dl.py) v2.50.0",
            "recoveredOrphans": (self.recovered_orphans if self.recovered_orphans else None),
            "creatorOid": self.oid,
            "playlist": redact_url(self.playlist_url()),  # v2.5.0(P2): 署名/key2クエリを出力しない
            "accessMode": ("member" if self.member_playlist else "public"),
            "sourceKind": ("member" if self.member_playlist else
                           "custom" if (self.live_m3u8 == self.m3u8_custom and self.m3u8_custom) else
                           "abr" if (self.live_info or {}).get("bytePlusPlaybackUrl") == self.live_m3u8 else
                           "ivs" if (self.live_info or {}).get("playUrl") == self.live_m3u8 else "legacy"),
            "schedule": ({"title": self._sched_item["title"],
                          "scheduledAt": iso(self._sched_item["scheduledAt"])}
                         if self._sched_item else None),
            "startedAt": iso(self.started),
            "endedAt": iso(time.time()),
            "durationSec": round(time.time() - self.started),
            "totalBytes": self.bytes_total,
            "segments": self.seg_total,
            "missingSuspect": self.seg_fails + self.gaps,
            "byterangeSkipped": self.byterange_skipped,  # v1.12.0
            "trackingResumes": self.resumes,
            "nameTemplate": self.name_tpl or None,
            "extinfMode": getattr(self, "extinf_mode", "legacy"),  # v2.5.0(P1)
            "generationRecovery": {  # v2.5.0(P1): プレイリスト世代復旧の数値証拠
                "video": (getattr(self, "_hls_state", {}) or {}).get("recovery"),
                "audio": (getattr(self, "_hls_a_state", {}) or {}).get("recovery"),
                "provenance": "manifest_sequence_and_uri_classification",
                "note": "stale=再配信の旧playlist(重複排除), reset=正当な世代逆行, "
                        "rotation=同一番号の新path(エンコーダー再起動), context=源切替",
            },
            "fmp4Evidence": {  # v2.6.0(P1): EXT-X-MAP宣言の数値証拠
                "video": (getattr(self, "_hls_state", {}) or {}).get("fmp4"),
                "audio": (getattr(self, "_hls_a_state", {}) or {}).get("fmp4"),
                "provenance": "manifest_map_declarations",
                "note": "MAP切替はパート境界分割で初期化セグメント混在を防止。"
                        "DISCONTINUITY無し切替は品質リスク指標として計数(拒否しない)",
            },
            "llhlsEvidence": {  # v2.6.0(P2): LL-HLS系タグの安全側方針と計数証拠
                "videoIndicators": (getattr(self, "_hls_state", {}) or {}).get("llhlsIndicators", 0),
                "audioIndicators": (getattr(self, "_hls_a_state", {}) or {}).get("llhlsIndicators", 0),
                "policy": "EXT-X-SKIP(差分playlist)はHLS_LLHLS_SKIPで拒否。"
                          "PRELOAD-HINT/SERVER-CONTROL等は取得せず計数のみ",
                "provenance": "manifest_tag_counts",
            },
            "authEvidence": (self.auth.evidence()  # v2.7.0(A-02): 認証方式と401分類の証拠
                             if getattr(self, "auth", None) is not None else None),
            "canaryEvidence": (canary_evidence(self._canary)  # v2.7.0(A-03): 応答形状のcanary
                               if getattr(self, "_canary", None) else None),
            "sessionTrackingEvidence": (session_tracking_evidence(self._session_tracker)  # v2.8.0(W-02): streamStartTime 10分閾値追跡
                                        if getattr(self, "_session_tracker", None) is not None else None),
            "errorTaxonomyEvidence": (error_taxonomy_evidence(self._err_taxonomy)  # v2.8.0(W-03): 4層ErrorKind分類
                                      if getattr(self, "_err_taxonomy", None) is not None else None),
            "notificationEvidence": (notification_stats()  # v2.7.0(A-04): webhook配送計数
                                     if getattr(self, "webhook", "") else None),
            "metadataEvidence": (metadata_evidence(self._meta_events)  # v2.7.0(A-05): MP4タグ埋め込み
                                 if getattr(self, "_meta_events", None) else None),
            "subtitleEvidence": subtitle_evidence_block(self.master_txt, getattr(self, "variants", None) or []),  # v2.9.0(A-09): 字幕レンディション観測(取得しない)
            "partContinuityEvidence": part_continuity_evidence({  # v2.11.0(W-05/W-06): TS細切れ防止・単一ファイル継続の証拠
                "splitMinutes": getattr(self, "split_min", 0),
                "maxSizeMb": round(getattr(self, "cap", 600 * 1048576) / 1048576),
                "splitOnDiscontinuity": getattr(self, "split_on_discontinuity", False),
                "discontinuityMergedCount": getattr(self, "_disc_merged", 0),
                "discontinuitySplitCount": getattr(self, "_disc_split", 0),
                "sameSessionStandbyContinuations": getattr(self, "_same_session_continuations", 0),
                "partsConcatenated": getattr(self, "_parts_concatenated", 0),
                "concatOutput": getattr(self, "_concat_output", None),
            }),
            "externalDownloaderEvidence": external_downloader_evidence(
                build_m3u8dl_export(
                    getattr(self, "live_m3u8", "") or getattr(self, "custom_m3u8", "") or "",
                    "RPLAY_%s" % safe_name(self.oid),
                    {"Referer": "https://rplay.live/", "User-Agent": self.ua},
                    live_real_time_merge=True,
                ),
                {
                    "tsDisguiseStrippedCount": getattr(self, "_ts_disguise_stripped", 0),
                    "tsDisguiseBytesTotal": getattr(self, "_ts_disguise_bytes", 0),
                    "queryInheritedCount": getattr(self, "_hls_query_inherited", 0),
                },
            ),
            "decryptionEvidence": self._dec_evidence_block(),  # v2.37.0(N-02): AES-128復号証拠(ゼロシークレット)
            "continuityCounterEvidence": hls_cc_evidence(getattr(self, "_cc_audit", None)),  # v2.37.0(N-03)
            "queueOrder": {  # v2.5.0(P2): FIFO不変のshadow証拠(ordは1開始の連番)
                "videoEnqueued": getattr(self, "_ord", 0),
                "videoDrained": max(0, getattr(self, "_ord_max", 0)),
                "videoFifoViolations": getattr(self, "_fifo_violations", 0),
                "audioEnqueued": getattr(self, "_ord_a", 0),
                "audioDrained": max(0, getattr(self, "_ord_a_max", 0)),
                "audioFifoViolations": getattr(self, "_fifo_a_violations", 0),
            },
            "saveLedger": {  # v2.5.0(P1): 保存確定イベント契約の参照
                "file": (os.path.basename(self.ledger_path) if getattr(self, "ledger_path", None) else None),
                "contract": "REQUESTED->FILE_WRITTEN->BROWSER_DONE->HASHED->DECODED/CONTINUITY",
                "browserStageApplicable": False,
            },
            "robust": {  # v2.5.0: 運用ガードの設定と最終測定値
                "guardSemantics": "conservative_none_nan_nonnumeric_danger_double_confirm",
                "minFreeMb": getattr(self, "min_free_mb", 0),
                "lastFreeMb": (round(self._last_free_mb, 1) if getattr(self, "_last_free_mb", None) is not None else None),
                "minFreeInodes": getattr(self, "min_free_inodes", 0),
                "lastFreeInodes": (getattr(self, "_last_free_inodes", None) if getattr(self, "_last_free_inodes", None) is not None else None),
                "heartbeatPath": "heartbeat.json",
                "stopFile": ".rplay_stop",
                "segindex": bool(getattr(self, "segindex_on", False)),
                "webhookConfigured": bool(getattr(self, "webhook", "")),
                "qaudit": getattr(self, "qaudit", "auto"),
            },
            "stats": {  # v1.10.0: 統計レポート
                "missingRate": (round((self.seg_fails + self.gaps) / _tot, 3) if _tot else 0),
                "missingSuspect": self.seg_fails + self.gaps,
                "byterangeSkipped": self.byterange_skipped,  # v1.12.0
                "reconnects": self.resumes,
                "sourceSwitches": self.src_switches,
                "qualityUpgrades": self.quality_upgrades,
                "qualityFallbacks": self.quality_fallbacks,
                "avgSegIntervalMs": (round(self._seg_iv_sum / self._seg_iv_n) if self._seg_iv_n else 0),
                "pollCount": self.poll_count,
            },
            "quality": ({
                "selected": self.quality_txt,
                "url": redact_url((self.sel_variant or {}).get("url")),  # v2.5.0(P2)
                "width": (self.sel_variant or {}).get("width"),
                "height": (self.sel_variant or {}).get("height"),
                "fps": (self.sel_variant or {}).get("fps"),
                "bandwidth": (self.sel_variant or {}).get("bwEff"),
                "upgrades": self.quality_upgrades,
                "available": [{"label": quality_label(x), "bandwidth": x["bwEff"], "url": redact_url(x["url"])}
                              for x in self.variants]
            } if self.sel_variant else None),
            "audioRendition": ({  # v1.11.0: 音声レンディション録画の記録
                "group": self.a_group, "uri": redact_url(self.a_uri),  # v2.5.0(P2)
                "bandwidth": self.a_bw, "label": self.audio_label, "running": self.a_running,
                "stopped": self.a_stop_reason or None,
                "segTotal": self.a_seg_total, "segFails": self.a_seg_fails,
                "bytes": self.a_bytes_total, "files": len(self.audio_parts_log),
                "parts": self.audio_parts_log,
            } if self.audio_mode and (self.a_running or self.a_seg_total or self.a_stop_reason) else None),
            "saveErrors": self.save_errors,
            "protocolErrors":getattr(self,"protocol_errors",[]),
            "partialCandidates": self.recovered_orphans,
            "qualityAudit": (lambda _parts: {  # v2.5.0(P1)/v2.6.0(P1): パート単位の実メディア監査結果
                "provenance": "decoded",
                "note": "ffprobe PTS/DTS単調性・timebase・全編デコードの実測。"
                        "マニフェスト宣言値(PDT/EXTINF)との一致だけでは品質合格扱いにしない",
                "avCorrelation": getattr(self, "av_correlation", None),  # v2.6.0(P1): 分離音声との実時間相関
                "parts": [e.get("qualityAudit") for e in _parts if e.get("qualityAudit")],
                "verdicts": {e.get("file"): e.get("auditVerdict") for e in _parts},
            } if any(e.get("qualityAudit") for e in _parts) else {
                "provenance": "decoded", "ran": False,
                "reason": ("disabled" if getattr(self, "qaudit", "auto") == "no" else "ffprobe_unavailable"),
            })(list(getattr(self, "ledger", {}).get("parts", []))),
            "playlistParseGraceEvidence": {
                "videoTransientErrors": getattr(self, "_bad_playlist_total", 0),
                "videoRecovered": getattr(self, "_bad_playlist_recovered", 0),
                "audioTransientErrors": getattr(self, "_a_bad_playlist_total", 0),
                "audioRecovered": getattr(self, "_a_bad_playlist_recovered", 0),
            },
            "segmentTransferRetryEvidence": {
                "videoRetries": getattr(self, "_transient_transfer_retries", 0),
                "videoRecovered": getattr(self, "_transient_transfer_recovered", 0),
                "audioRetries": getattr(self, "_a_transient_transfer_retries", 0),
                "audioRecovered": getattr(self, "_a_transient_transfer_recovered", 0),
            },
            "adFilterEvidence": {
                "adKeywordConfigured": bool(getattr(self, "ad_keyword", "")),
                "videoScte35Indicators": (getattr(self, "_hls_state", {}) or {}).get("scte35Indicators", 0),
                "audioScte35Indicators": (getattr(self, "_hls_a_state", {}) or {}).get("scte35Indicators", 0),
                "videoFilteredSegments": (getattr(self, "_hls_state", {}) or {}).get("adFilteredSegments", 0),
                "audioFilteredSegments": (getattr(self, "_hls_a_state", {}) or {}).get("adFilteredSegments", 0),
            },
            "aggregationEvidence": getattr(self, "aggregate_evidence", {"status": "NOT_REQUESTED"}),
            "partBoundaryEvidence": getattr(self, "part_boundary_evidence", {}),
            "parts": self.parts_log,
        }
        # v2.7.0(A-02/A-03): 台帳ルートにも認証・canary証拠を反映(保存時点のスナップショット)
        try:
            if getattr(self, "ledger", None) is not None:
                self.ledger["authEvidence"] = (self.auth.evidence()
                                               if getattr(self, "auth", None) is not None else None)
                self.ledger["canaryEvidence"] = (canary_evidence(self._canary)
                                                 if getattr(self, "_canary", None) else None)
                self.ledger["sessionTrackingEvidence"] = (session_tracking_evidence(self._session_tracker)
                                                          if getattr(self, "_session_tracker", None) is not None else None)
                self.ledger["errorTaxonomyEvidence"] = (error_taxonomy_evidence(self._err_taxonomy)
                                                        if getattr(self, "_err_taxonomy", None) is not None else None)
                self.ledger["partContinuityEvidence"] = info.get("partContinuityEvidence")
        except Exception:
            pass
        name = os.path.join(self.out_dir, "RPLAY_%s_%s_%s_info.json" % (safe_name(self.oid), stamp(), uuid.uuid4().hex))
        with open(name, "x", encoding="utf-8") as f:
            json.dump(info, f, ensure_ascii=False, indent=2)
        self.log("録画情報JSONを保存: %s (パート%d本)" % (os.path.basename(name), len(info["parts"])))

    # ---- メインループ ----
    def run(self):
        # 開始ログ
        self.recover_orphan_parts()
        # v2.5.0: 旧stop-fileを除去 — 新規実行を開始(外部停止要求は録画中のみ有効)
        if os.path.exists(self.stop_file):
            try:
                os.unlink(self.stop_file)
            except OSError:
                pass
            self.log("旧stop-file(.rplay_stop)を除去 — 新規実行を開始します")
        # v2.5.0: 起動時ゲート — 保守判定+二重確認(低/不明が残れば開始しない)
        if self.min_free_mb > 0:
            free = free_mb(self.out_dir)
            if guard_low(free, self.min_free_mb):
                free = free_mb(self.out_dir)
            if guard_low(free, self.min_free_mb):
                self.log("エラー: ディスク空き容量不足(%s < %.0fMB) — 録画を開始できません" % (
                    "不明" if free is None else "%.0fMB" % free, self.min_free_mb))
                return 2
        if self.min_free_inodes > 0 and self._ino_supported:
            n = free_inodes(self.out_dir)
            if guard_low(n, self.min_free_inodes):
                n = free_inodes(self.out_dir)
            if guard_low(n, self.min_free_inodes):
                self.log("エラー: 空きinode不足(%s <= %.0f) — 録画を開始できません" % (
                    "不明" if n is None else "%.0f" % n, self.min_free_inodes))
                return 2
        print("RPLAY Live Downloader v2.50.0 CANDIDATE — ID: %s%s%s [認証:%s]" % (
            self.oid,
            " [音声%s]" % ("only" if self.audio_only else "both") if self.audio_mode else "",
            " [EXTINF:%s]" % self.extinf_mode,
            (getattr(self, "auth", None) and self.auth.mode) or "none"))
        print("保存先: %s" % os.path.abspath(self.out_dir))
        # v1.7.0: 詮索(live/play) — 現行の配信基盤URLを取得
        self.scent()
        info = self.live_info or {}
        print("詮索(live/play): state=%s / 基盤=%s / accessible=%s / allowAnonymous=%s" % (
            info.get("streamState", "不明"),
            "RPLAY自社" if info.get("useRplayStreamServer") else ("BytePlus+IVS併用" if info.get("bytePlusPlaybackUrl") and info.get("playUrl") else ("BytePlus" if info.get("bytePlusPlaybackUrl") else ("IVS" if info.get("playUrl") else "不明"))),
            info.get("accessible"), info.get("allowAnonymous")))
        cls = self.probe()
        print("配信状態: %s" % {"live": "LIVE(録画可能)", "offline": "オフライン(追跡待機で待ちます)",
                                "token": "アクセス制限(403/401) — 会員限定等の可能性"}.get(cls, "サーバー応答異常"))
        if cls == "token":
            # v1.8.0: 自分のトークンで視聴権限のある限定配信なら解決して録画へ
            if self.token and self.resolve_member("起動時"):
                print("限定配信を解決 — 自分のログイン会話で視聴権限のあるplaylistで録画します")
            else:
                print("この配信は認証が必要です。視聴権限がある場合は --token <自分のJWT> を指定してください")
                print("(JWTはブラウザでRPLAYにログイン後、F12→localStorageの _AUTHORIZATION_ で確認できます)")
                return 2
        if cls == "offline" and self.wait_sched:
            item = self.schedule_info()
            if item:
                print("📡 配信予約: 「%s」 %s開始予定 — 開始を待って自動録画します" % (
                    item["title"] or "無題",
                    datetime.fromtimestamp(item["scheduledAt"]).strftime("%H:%M")))
            else:
                print("📡 配信予約: なし(または取得できず) — 通常の追跡待機で開始を待ちます")
        self.state = "RUN"
        self._skip_backlog = not self.backlog
        self.last_new = time.time()
        # v2.5.0: segindex読込(前回書込済み鍵の再取得防止)とstart通知
        if self.segindex_on:
            seen_l, aseen_l = segindex_load(self.segindex_path)
            for u in seen_l:
                self._si_written[u] = True
            for u in aseen_l:
                self._si_awritten[u] = True
            # 世代復旧のURI不変フィルタへ既知鍵を播種(初回pollから重複排除が効く)
            st = getattr(self, "_hls_state", None) or {}
            st.setdefault("uris", {})
            for u in seen_l:
                st["uris"][u] = True
            self._hls_state = st
            ast = getattr(self, "_hls_a_state", None) or {}
            ast.setdefault("uris", {})
            for u in aseen_l:
                ast["uris"][u] = True
            self._hls_a_state = ast
            if seen_l or aseen_l:
                self.log("segindex読込: 映像%d/音声%d件の既知鍵を再取得対象から除外しました" % (
                    len(seen_l), len(aseen_l)))
        webhook_post(self.webhook, "start", {
            "creatorOid": self.oid, "outDir": os.path.abspath(self.out_dir),
            "pid": os.getpid(), "extinfMode": self.extinf_mode})
        self.hb_write()  # 起動直後に生存通知(15秒待たずに監視へ可視化)
        try:
            while True:
                # v2.5.0: 外部停止要求(stop-file) — Docker/nohup等シグナルを送れない環境から
                if os.path.exists(self.stop_file):
                    self.stop("stop-file(.rplay_stop)検出 — 外部からの停止要求")
                    break
                # v2.5.0: 定期heartbeat(壁時計15秒)・segindex・ディスクガード
                now_t = time.time()
                if now_t - self._hb_at >= HB_INTERVAL_S:
                    self._hb_at = now_t
                    self.hb_write()
                    self.segindex_flush()
                if now_t - self._disk_at >= DISK_CHECK_S:
                    self._disk_at = now_t
                    if self.min_free_mb > 0 and not self.disk_guard():
                        break
                    if self.min_free_inodes > 0 and not self.inode_guard():
                        break
                if self.max_hours and (time.time() - self.started) >= self.max_hours * 3600:
                    self.stop("最大録画時間%d時間に到達" % self.max_hours)
                    break
                if self.state == "RUN" and self.medium == "ts":
                    if not self.pending_end and now_ms() - self.last_poll >= self.cur_poll_ms:
                        self.poll_playlist()
                    self.drain()
                    self.audio_tick()  # v1.11.0: 音声の独立ループ(内部で例外吸収・0.3〜0.5秒オフセット)
                    if self.pending_end and not self.queue and (not self.a_running or not self.a_queue):
                        r = self.pending_end
                        self.pending_end = None
                        self.finish_run(r)
                    elif self.state == "RUN":
                        self.check_stall()
                        self.maybe_split()
                        self.maybe_quality_upgrade()  # v1.9.0: 画質昇格の定期再走査
                elif self.state == "RUN" and self.medium == "flv":
                    self.maybe_split()  # FLV受信はtry_flv/pump_flv内
                    time.sleep(0.2)
                elif self.state == "STANDBY":
                    if now_ms() - self.last_standby >= STANDBY_MS * (1 - JITTER + random.random() * JITTER * 2):
                        self.standby_probe()
                if self.state == "IDLE":
                    break
                self.status()
                time.sleep(0.3)
        except KeyboardInterrupt:
            self.status_clear()
            self.stop("Ctrl+C(ユーザー停止)")
            return 2 if self.save_errors or getattr(self,"protocol_errors",[]) else 0
        # stop()を経らずにIDLEになった場合(保存失敗)も終了処理を保証 —
        # 残った健康側パートを確定し、監査/情報JSON/終了通知/heartbeatまで実施する
        self.close_part()
        if self.audio_mode: self.close_audio_part()
        if not self._final_done:
            self.run_qaudit()
            if self.info_json and (self.save_errors or self.parts_log or self.audio_parts_log):
                self.save_info()
            self._final_ops("保存失敗 — 残パートを確定して停止")
        return 2 if self.save_errors or getattr(self,"protocol_errors",[]) else 0


def fmt_dur(ms):
    s = max(0, int(ms) // 1000)
    return "%02d:%02d:%02d" % (s // 3600, (s % 3600) // 60, s % 60)


# ---- v1.12.0: ライブ探索(--discover) — 「配信者を固定せず自分で探す」----
# 公式フロントと同一の公開APIのみ(認証回避なし):
#   ①GET /content/curation?componentOids[]=<公式creatorList>&liveDataRequest=true
#     (公式TOPの「VTubers」「Voice Actors」等クリエイター一覧コンポーネント → 候補集合)
#   ②GET /live/play?creatorOid=(公式が匿名視聴用に使う無認証API)で状態/タイトル/名前
#   ③LIVEのみGET /live/stream?creatorOid= で視聴者数
#   ④--token指定時は GET /live/streams(自分の会話)を併用(401は静かに無視)
# 防封禁設計: 全体ペーサー(要求開始間隔120ms)/同時8/403=60秒退避/429=指数バックオフ+RA優先
DISC_SOURCES_DEFAULT = "650beb0e0c98c9e3782b2b87,6478bcd82f73959e73f35ce1"
DISC_OID_RE = re.compile(r"^[0-9a-f]{24}$", re.I)
DISC_CONC = 8
DISC_GAP_S = 0.12


class DiscPacer(object):
    """全体ペーサー: 全スレッドの要求開始間隔を下限で直列化(録画のREQ_MIN_GAPと同一思想)"""

    def __init__(self, gap):
        self.gap = gap
        self.lock = threading.Lock()
        self.next_at = 0.0

    def wait(self):
        with self.lock:
            now = time.time()
            d = self.next_at - now
            self.next_at = max(now, self.next_at) + self.gap
        if d > 0:
            time.sleep(d)


class DiscState(object):
    def __init__(self):
        self.cooldown_until = 0.0
        self.c429 = 0
        self.last_err = ""


def disc_fetch_json(url, ua, timeout=9.0, token=None, pacer=None, state=None,
                    cooldown403=True):
    """公開GET → (status, obj|None, retry_after_ms)。
    429は常にstate退避(Retry-After優先)。403はcooldown403=Trueの呼び only
    (curation=インフラ層)で退避、個別creatorのprobeでは呼び側でスキップ学習"""
    headers = {"User-Agent": ua, "Origin": "https://rplay.live", "Referer": "https://rplay.live/",
               "Accept": "application/json"}
    if token:
        headers["Authorization"] = token
    headers["Accept-Encoding"] = "gzip"
    if pacer:
        pacer.wait()
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            if raw[:2] == b"\x1f\x8b":  # サーバーは要求なしでもgzipを返すことがある
                raw = gzip.decompress(raw)
            try:
                return r.status, json.loads(raw.decode("utf-8", "replace")), 0
            except ValueError:
                return r.status, None, 0
    except urllib.error.HTTPError as e:
        ra = retry_after_ms(e.headers.get("Retry-After")) if e.headers else 0
        e.close()
        if state is not None:
            if e.code == 429:
                state.c429 += 1
                ms = ra or min(CD429_BASE * (2 ** (state.c429 - 1)), CD429_MAX) * 1000
                state.cooldown_until = time.time() + ms / 1000.0
                state.last_err = "429(レート制限)"
            elif e.code == 403 and cooldown403:
                state.cooldown_until = time.time() + CD403
                state.last_err = "403(アクセス制限)"
        return e.code, None, ra
    except Exception:
        return 0, None, 0


def disc_sources(csv_arg):
    csv = (csv_arg or "").strip()
    if csv:
        arr = [x.strip() for x in csv.split(",") if DISC_OID_RE.match(x.strip())]
        if arr:
            return arr
    return DISC_SOURCES_DEFAULT.split(",")


def disc_pool(api, ua, sources, pacer, state):
    """creatorListコンポーネント(公開)から候補creatorOidを収集"""
    pool, seen = [], set()
    for cid in sources:
        if time.time() < state.cooldown_until:
            break
        st, j, _ = disc_fetch_json(
            api + "/content/curation?componentOids[]=" + cid +
            "&liveDataRequest=true&forceFetch=false&lang=jp&platformType=rplay",
            ua, pacer=pacer, state=state)
        if st != 200 or not isinstance(j, (list, dict)):
            continue
        items = j if isinstance(j, list) else (j.get("curationData") or [])
        for c in items:
            if not isinstance(c, dict) or c.get("curationType") != "creatorList":
                continue  # livestreamList(セッションOID)はcreator逆引き不能のため対象外
            comp = c.get("componentData") or {}
            for oid in (comp.get("list") or []):
                if isinstance(oid, str) and DISC_OID_RE.match(oid) and oid not in seen:
                    seen.add(oid)
                    pool.append(oid)
    return pool


def disc_parse_authed(j):
    """/live/streams(自分の会話)の未知形状を防御的に解釈"""
    if isinstance(j, list):
        arr = j
    elif isinstance(j, dict):
        arr = None
        for k in ("items", "streams", "list", "data", "lives"):
            v = j.get(k)
            if isinstance(v, list):
                arr = v
                break
    else:
        arr = None
    if not isinstance(arr, list):
        return None
    out = []
    for it in arr:
        if not isinstance(it, dict):
            continue
        cr = it.get("creator") if isinstance(it.get("creator"), dict) else {}
        oid = it.get("creatorOid") or cr.get("oid") or cr.get("_id") or it.get("oid") or it.get("_id")
        if not (isinstance(oid, str) and DISC_OID_RE.match(oid)):
            continue
        cm = it.get("creatorMetadata") if isinstance(it.get("creatorMetadata"), dict) else cr
        vc = it.get("viewerCount")
        out.append({"oid": oid, "nick": cm.get("nickname") or it.get("nickname") or "",
                    "title": it.get("title") or it.get("liveTitle") or "",
                    "adult": bool(it.get("isAdultContent")),
                    "viewers": vc if isinstance(vc, int) else None, "src": "authed"})
    return out


DISC_403_CONSEC = 30  # 連続403この回数でインフラ制限とみなし全体退避


def disc_probe(api, ua, oid, pacer, state):
    """creatorOid 1件を公開APIで確認(live/play → live/stream)。
    戻り値: {"kind": "live"/"offline"/"skip403", ...}
    個別creatorの403はskip403(学習スキップ) — 退避判定は呼び側で連続性を見る"""
    st, j, _ = disc_fetch_json(api + "/live/play?creatorOid=" + oid +
                               "&key=&platformType=rplay&lang=jp", ua, pacer=pacer,
                               state=state, cooldown403=False)
    if st == 403:
        return {"kind": "skip403", "oid": oid}
    if st == 200 and isinstance(j, dict) and j.get("streamState") == "live":
        cm = j.get("creatorMetadata") or {}
        item = {"oid": oid, "nick": cm.get("nickname") or "", "title": j.get("title") or "",
                "adult": bool(j.get("isAdultContent")), "viewers": None, "src": "public"}
        st2, j2, _ = disc_fetch_json(api + "/live/stream?creatorOid=" + oid,
                                     ua, pacer=pacer, state=state)
        if st2 == 200 and isinstance(j2, dict) and isinstance(j2.get("viewerCount"), int):
            item["viewers"] = j2["viewerCount"]
        item["kind"] = "live"
        return item
    return {"kind": "offline", "oid": oid}


def discover_once(api, ua, token, sources, state, skip403=None):
    """1回の走査。戻り値: {lives:[], pool:N, authed:bool} / 退避中はNone"""
    if time.time() < state.cooldown_until:
        return None
    skip403 = skip403 if skip403 is not None else set()
    pacer = DiscPacer(DISC_GAP_S)
    authed = None
    if token:
        st, j, _ = disc_fetch_json(api + "/live/streams", ua, token=token, pacer=pacer, state=state)
        if st == 200 and j is not None:
            authed = disc_parse_authed(j)  # 401は静かに無視(自分の会話のみ・認証回避なし)
    pool = disc_pool(api, ua, sources, pacer, state)
    # v1.12.0: curationが429/403で退避に入った場合 — 短いRetry-After(<=5秒)なら
    # 待って再試行(1ショット実行で「0件」と誤表示しない)。長い退避はNoneを返す
    for _ in range(2):
        if pool or time.time() >= state.cooldown_until:
            break
        time.sleep(min(5.0, max(0.2, state.cooldown_until - time.time())))
        pool = disc_pool(api, ua, sources, pacer, state)
    if not pool and state.cooldown_until > time.time():
        return None
    lives = {}
    for it in (authed or []):
        lives[it["oid"]] = it
    stop = threading.Event()
    idx = [0]
    consec403 = [0]  # 連続403(200で復位)。12連続でインフラ制限とみなし退避

    def worker():
        while not stop.is_set():
            i = idx[0]
            idx[0] += 1
            if i >= len(pool):
                break
            if time.time() < state.cooldown_until:
                stop.set()
                break
            if pool[i] in skip403:
                continue  # 学習済み403(配信単位の制限)は静かにスキップ
            it = disc_probe(api, ua, pool[i], pacer, state)
            if not it:
                consec403[0] = 0
                continue
            if it.get("kind") == "skip403":
                skip403.add(it["oid"])  # 学習(以後の走査でもスキップ)
                consec403[0] += 1
                if consec403[0] >= DISC_403_CONSEC:
                    state.cooldown_until = time.time() + CD403
                    state.last_err = "403(アクセス制限・%d連続)" % consec403[0]
                    stop.set()
                    break
            else:
                consec403[0] = 0
                if it.get("kind") == "live":
                    lives[it["oid"]] = it

    ths = [threading.Thread(target=worker, daemon=True) for _ in range(min(DISC_CONC, max(1, len(pool))))]
    for t in ths:
        t.start()
    for t in ths:
        t.join(120)
    out = sorted(lives.values(), key=lambda x: (-(x["viewers"] or 0), x["oid"]))
    return {"lives": out, "pool": len(pool), "authed": bool(authed),
            "cooldown": max(0, int(state.cooldown_until - time.time())), "err": state.last_err}


def cmd_discover(a):
    api = (a.api or "https://api.rplay.live").rstrip("/")
    ua = a.ua
    state = DiscState()
    sources = disc_sources(a.disc_src)
    seen_oids = set()
    round_no = 0
    if not a.json:
        # JSONモードはstdoutを純粋JSONに保つため、バナーは人間向け表示のみ
        print("RPLAY Live Downloader v1.12.0 — ライブ探索(公式フロントと同一の公開APIのみ)")
    try:
        while True:
            round_no += 1
            r = discover_once(api, ua, a.token, sources, state)
            if r is None:
                wait_s = max(0, int(state.cooldown_until - time.time()))
                if a.json:
                    print(json.dumps({"round": round_no, "cooling": True, "cooldownSec": wait_s,
                                      "err": state.last_err, "lives": []}, ensure_ascii=False))
                else:
                    print("— 退避中(%s)… %d秒後に再試行します" % (state.last_err, wait_s))
            else:
                lives = r["lives"]
                if a.json:
                    print(json.dumps({"round": round_no, "pool": r["pool"], "count": len(lives),
                                      "authed": r["authed"], "lives": lives,
                                      "err": r.get("err", "")}, ensure_ascii=False))
                else:
                    print("— ライブ探索 round%d: %d件ライブ / 候補%d人%s —" % (
                        round_no, len(lives), r["pool"],
                        " / 自分の会話一覧を併用" if r.get("authed") else ""))
                    for it in lives:
                        mark = "*" if it["oid"] not in seen_oids else " "
                        v = str(it["viewers"]) if it["viewers"] is not None else "-"
                        print(" %s %s  %-16s  👀%-6s %s%s" % (
                            mark, it["oid"], (it["nick"] or "?")[:16], v,
                            "[AD] " if it["adult"] else "", (it["title"] or "(無題)")[:56]))
                    if not lives:
                        print("  (ライブ中の配信がありません — 時間を置いて再走査してください)")
                    print("  録画するには: python rplay_dl.py <URLまたはクリエイターID> [オプション]")
                for it in lives:
                    seen_oids.add(it["oid"])
            if not a.watch:
                return 0
            time.sleep(max(60, a.watch))
    except KeyboardInterrupt:
        print("中断 — 退避状態を保持せず終了します")
        return 0



def cmd_audit_files(a):
    """v2.48.0(Priority #4): Explicit post-save media audit CLI mode (--audit-files).
    Runs real ffprobe/ffmpeg packet PTS/DTS monotonicity & full-decode audit (qaudit_part)
    plus two-track A/V decoded-duration correlation (qaudit_av_correlation) on saved local
    files without requiring a live stream or creator OID."""
    files = list(getattr(a, "audit_files", None) or [])
    entries = []
    ledger_like = []
    all_passed = True
    for raw_path in files:
        p = Path(raw_path)
        if p.is_symlink() or not p.is_file():
            entry = {
                "file": os.path.basename(raw_path),
                "bytes": 0,
                "sha256": None,
                "track": "video",
                "verdict": "missing_or_symlink",
                "qualityAudit": {"file": os.path.basename(raw_path), "verdict": "missing_or_symlink", "provenance": "decoded"},
            }
            entries.append(entry)
            all_passed = False
            continue
        sha = hashlib.sha256()
        cc_acc = None
        is_ts_ext = p.suffix.lower() in (".ts", ".m2ts")
        read_sz = 188 * 4096 if is_ts_ext else 1048576
        with open(p, "rb") as fh:
            for blk in iter(lambda: fh.read(read_sz), b""):
                sha.update(blk)
                if is_ts_ext:
                    cc_acc = hls_merge_cc(cc_acc, hls_audit_cc(blk))
        qa = qaudit_part(str(p))
        streams = qa.get("streams") or []
        has_v = any(s.get("codecType") == "video" for s in streams)
        has_a = any(s.get("codecType") == "audio" for s in streams)
        track = "audio" if ("_audio-p" in p.name or (has_a and not has_v)) else "video"
        verdict = qa.get("verdict") or "probe_failed"
        if verdict != "pass":
            all_passed = False
        entry = {
            "file": p.name,
            "bytes": p.stat().st_size,
            "sha256": sha.hexdigest(),
            "track": track,
            "verdict": verdict,
            "decodedDurationSec": qa.get("decodedDurationSec"),
            "qualityAudit": qa,
        }
        if cc_acc is not None:
            entry["continuityCounterAudit"] = hls_cc_evidence(cc_acc)
        entries.append(entry)
        ledger_like.append({"file": p.name, "track": track, "qualityAudit": qa, "auditVerdict": verdict})
    av_corr = qaudit_av_correlation(ledger_like)
    if av_corr.get("verdict") not in ("pass", "insufficient"):
        all_passed = False
    report = {
        "tool": "RPLAY Live Downloader (rplay_dl.py) v2.50.0",
        "mode": "explicit_post_save_audit",
        "provenance": "decoded",
        "allPassed": all_passed,
        "avCorrelation": av_corr,
        "files": entries,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if all_passed else 2


def cmd_merge_vtt(a):
    """v2.48.0: Standalone WebVTT subtitle segment merger (--merge-vtt / --vtt-out)."""
    files = list(getattr(a, "merge_vtt", None) or [])
    out_path = getattr(a, "vtt_out", None) or ""
    if not files:
        sys.stderr.write("エラー: --merge-vtt に1つ以上のWebVTTセグメントファイルを指定してください\n")
        return 2
    texts = []
    input_names = []
    for raw_p in files:
        fp = os.path.abspath(str(raw_p or ""))
        input_names.append(os.path.basename(fp))
        if not os.path.exists(fp) or os.path.islink(fp) or not os.path.isfile(fp):
            out = {"schema": "rplay-vtt-merge/v1", "version": "2.50.0", "ok": False, "reason": "WEBVTT_INPUT_INVALID", "file": os.path.basename(fp)}
            print(json.dumps(out, ensure_ascii=False, indent=2))
            return 2
        if os.path.getsize(fp) > 2 * 1024 * 1024:
            out = {"schema": "rplay-vtt-merge/v1", "version": "2.50.0", "ok": False, "reason": "WEBVTT_INPUT_TOO_LARGE", "file": os.path.basename(fp)}
            print(json.dumps(out, ensure_ascii=False, indent=2))
            return 2
        with open(fp, "r", encoding="utf-8", errors="replace") as f:
            texts.append(f.read())
    try:
        res = hls_merge_webvtt_segments(texts)
    except ValueError as e:
        out = {
            "schema": "rplay-vtt-merge/v1",
            "version": "2.50.0",
            "ok": False,
            "reason": str(e) or "WEBVTT_INVALID",
            "inputs": input_names,
        }
        print(json.dumps(out, ensure_ascii=False, indent=2))
        return 2
    merged_text = res.get("text") or ""
    written_file = None
    if out_path:
        ofp = os.path.abspath(str(out_path))
        if os.path.exists(ofp) or os.path.islink(ofp):
            out = {"schema": "rplay-vtt-merge/v1", "version": "2.50.0", "ok": False, "reason": "WEBVTT_OUTPUT_EXISTS", "outputFile": os.path.basename(ofp)}
            print(json.dumps(out, ensure_ascii=False, indent=2))
            return 2
        with open(ofp, "w", encoding="utf-8") as f:
            f.write(merged_text)
        written_file = os.path.basename(ofp)
    out = {
        "schema": "rplay-vtt-merge/v1",
        "version": "2.50.0",
        "ok": True,
        "segmentsMerged": res.get("segmentsProcessed", 0),
        "cuesMerged": res.get("cuesMerged", 0),
        "duplicatesDropped": res.get("duplicatesRemoved", 0),
        "timestampMap": res.get("timestampMap"),
        "sha256": hashlib.sha256(merged_text.encode("utf-8")).hexdigest(),
        "outputFile": written_file,
        "inputs": input_names,
    }
    if not out_path:
        out["text"] = merged_text
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0


def cmd_join_files(a):
    """v2.48.0: Standalone multi-part lossless join + optional separate audio & WebVTT subtitle mux (--join-files)."""
    v_files = list(getattr(a, "join_files", None) or [])
    a_files = list(getattr(a, "join_audio_files", None) or [])
    sub_file = getattr(a, "join_subtitle", None) or None
    sub_lang = getattr(a, "join_subtitle_lang", None) or "jpn"
    out_file = getattr(a, "join_out", None) or None
    if not v_files:
        print(json.dumps({"status": "FAILED", "code": "JOIN_BAD_PARTS", "originalsRetained": True}))
        return 2
    join_script = Path(__file__).resolve().parent / "rplay_join.py"
    if not join_script.is_file():
        join_script = Path(__file__).resolve().parent.parent / "rplay_join.py"
    try:
        v_paths = [Path(f).absolute() for f in v_files]
        if any(p.is_symlink() or not p.is_file() for p in v_paths):
            print(json.dumps({"status": "FAILED", "code": "JOIN_MISSING_OR_UNSUPPORTED_PART", "originalsRetained": True}))
            return 2
        directory = v_paths[0].parent.resolve()
        if any(p.parent.resolve() != directory for p in v_paths):
            print(json.dumps({"status": "FAILED", "code": "JOIN_DIFFERENT_DIRECTORIES", "originalsRetained": True}))
            return 2
        job = {"parts": [{"file": p.name, "bytes": p.stat().st_size} for p in v_paths]}
        if a_files:
            a_paths = [Path(f).absolute() for f in a_files]
            if any(p.is_symlink() or not p.is_file() for p in a_paths):
                print(json.dumps({"status": "FAILED", "code": "JOIN_MISSING_OR_UNSUPPORTED_PART", "originalsRetained": True}))
                return 2
            if any(p.parent.resolve() != directory for p in a_paths):
                print(json.dumps({"status": "FAILED", "code": "JOIN_DIFFERENT_DIRECTORIES", "originalsRetained": True}))
                return 2
            job["audioRendition"] = {"parts": [{"file": p.name, "bytes": p.stat().st_size, "kind": "audio"} for p in a_paths]}
        with tempfile.NamedTemporaryFile("w", suffix=".json", dir=str(directory), delete=False, encoding="utf-8") as tf:
            json.dump(job, tf)
            tmp_job_path = tf.name
        try:
            cmd = [sys.executable, str(join_script), tmp_job_path, "--directory", str(directory)]
            if a_files:
                cmd.append("--mux-audio")
            if sub_file:
                cmd += ["--subtitle", str(Path(sub_file).absolute()), "--subtitle-lang", str(sub_lang)]
            if out_file:
                cmd += ["--output", str(Path(out_file).absolute())]
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=600, check=False)
            out_txt = (proc.stdout or "").strip()
            if out_txt:
                print(out_txt)
            else:
                print(json.dumps({"status": "FAILED", "code": "JOIN_FAILED", "originalsRetained": True}))
            return proc.returncode if proc.returncode in (0, 2) else 2
        finally:
            try:
                os.unlink(tmp_job_path)
            except OSError:
                pass
    except Exception:
        print(json.dumps({"status": "FAILED", "code": "JOIN_FAILED", "originalsRetained": True}))
        return 2


def main():
    if sys.version_info < (3, 11):
        raise SystemExit("Python 3.11以降が必要です")
    ap = argparse.ArgumentParser(
        description="RPLAY Live Downloader — ログイン不要・無劣化録画(ログイン不要の公開エンドポイントを使用)")
    ap.add_argument("target", nargs="?", default="",
                    help="配信URL(https://rplay.live/live/<ID>)またはクリエイターID(--discoverでは不要)")
    ap.add_argument("--discover", action="store_true",
                    help="ライブ探索 — 配信者を固定せず、公式と同一の公開APIだけでライブ中の配信を一覧表示")
    ap.add_argument("--watch", type=int, default=0, metavar="SEC",
                    help="--discoverと併用: SEC秒間隔(最小60)で再走査し新規ライブを*で通知")
    ap.add_argument("--json", action="store_true", help="--discover出力をJSONにする(機械可読)")
    ap.add_argument("--disc-src", dest="disc_src", default="",
                    help="探索ソースのcuration componentOid(カンマ区切り)。空=公式VTubers/Voice Actors一覧")
    ap.add_argument("--out", default="")
    ap.add_argument("--once", action="store_true", help="状態確認のみで終了")
    ap.add_argument("--no-backlog", action="store_true")
    ap.add_argument("--split-min", type=int, default=0,
                    help="指定分数ごとにファイル分割(v2.11.0既定: 0=時間分割なし・容量上限まで単一ファイル継続)")
    ap.add_argument("--split-on-discontinuity", dest="split_on_discontinuity", action="store_true",
                    help="MPEG-TSでもEXT-X-DISCONTINUITYごとに別パートへ分割する(既定OFF=単一TSへ連続追記)")
    ap.add_argument("--concat-parts", dest="concat_parts", choices=["auto", "mp4", "ts", "no"], default="no",
                    help="複数パート発生時に停止後単一ファイルへ無劣化結合(auto=ffmpegがあればMP4無ければTS / mp4 / ts / no)")
    ap.add_argument("--join-parts", dest="join_parts", choices=["auto", "no"], default="auto",
                    help="互換性のある複数録画パートを終了後にrplay_join.pyで1本のMP4へ結合(原本保持・--mux no時は無効)")
    ap.add_argument("--inherit-query", dest="inherit_query", action="store_true",
                    help="cat-catch方式: M3U8のクエリパラメータ(token/key2等)を同一オリジンの相対セグメント/MAP URLへ自動継承")
    ap.add_argument("--print-m3u8dl", dest="print_m3u8dl", action="store_true",
                    help="cat-catch互換の m3u8dl:// プロトコルURIおよび N_m3u8DL-RE 実行コマンドをJSON出力して終了")
    ap.add_argument("--dec-key", dest="dec_key", default="", metavar="HEX|auto",
                    help="v2.37.0: AES-128暗号化HLSの復号(32桁hex)またはauto(鍵URIから自動取得・公式プレイヤー相当ヘッダ・鍵値は記録しない)")
    ap.add_argument("--dec-key-file", dest="dec_key_file", default="", metavar="PATH",
                    help="v2.37.0: AES-128復号鍵ファイル(32桁hexテキストまたは16バイト生データ)")
    ap.add_argument("--dec-key-env", dest="dec_key_env", default="", metavar="NAME",
                    help="v2.37.0: AES-128復号鍵を格納した環境変数名(32桁hex)")
    ap.add_argument("--dec-backend", dest="dec_backend", choices=["auto", "openssl", "python"], default="auto",
                    help="v2.37.0: 復号バックエンド(auto=openssl優先・無人fallback / openssl / python)")
    ap.add_argument("--max-size-mb", type=int, default=600)
    ap.add_argument("--no-follow", action="store_true")
    ap.add_argument("--standby-min", type=int, default=0)
    ap.add_argument("--no-flv", action="store_true")
    ap.add_argument("--max-hours", type=int, default=0)
    ap.add_argument("--info-json", action="store_true")
    ap.add_argument("--ua", default=UA_DEFAULT)
    ap.add_argument("--m3u8", default="")
    ap.add_argument("--flv", default="")
    ap.add_argument("--api", default="")
    ap.add_argument("--token", default="",
                    help="自分のRPLAY JWT(ブラウザでログイン後、F12→localStorageの _AUTHORIZATION_)。"
                         "視聴権限のある会員限定配信・配信予約の取得に使用(認証の回避ではありません)。"
                         "--refresh-token併用時は一次資格となり、401時だけ自動切替する")
    ap.add_argument("--refresh-token", dest="refresh_token", default="",
                    help="自分のRefresh-Token(v2.7.0)。値直接 / env:<環境変数名> / file:<パス> の三種で供給。"
                         "api.rplay.liveのrefresh-token APIで短命JWTを自動更新(leeway 300秒前・失敗3回再試行)。"
                         "単独指定では起動時に短命JWTを取得(--token指定時は401時の自動切替先)")
    ap.add_argument("--user-oid", dest="user_oid", default="",
                    help="自分のユーザーOID(24桁hex・v2.7.0)。APIクエリのrequestorOid補完に使用。"
                         "未指定時はJWTのpayload主張から補完する")
    ap.add_argument("--wait-schedule", action="store_true",
                    help="配信予約(live/schedules)を監視し、開始時刻に自動録画(--tokenが必要)")
    ap.add_argument("--first-variant", action="store_true",
                    help="最高画質でなくmasterの先頭バリアントを使用(既定: 最高画質を自動選択)")
    ap.add_argument("--config", default="",
                    help="設定ファイル(JSON)。キーはロングオプション名(--なし)。コマンドライン引数が優先")
    ap.add_argument("--mux", choices=["auto", "mp4", "no"], default="auto",
                    help="録画後のTS→MP4変換(ffmpeg -c copy の無劣化ストリームコピー)。"
                         "auto=ffmpegがあれば実行 / mp4=必須(無ければ警告) / no=無効(既定: auto)")
    ap.add_argument("--name-tpl", dest="name_tpl", default="",
                    help="保存ファイル名テンプレート({date}{time}{creator}{title}{quality}{part}{ext})。空=従来命名")
    ap.add_argument("--audio-only", dest="audio_only", action="store_true",
                    help="音声レンディション(URI付きEXT-X-MEDIA)のみを録画(音声TS)")
    ap.add_argument("--audio-both", dest="audio_both", action="store_true",
                    help="映像+音声の両TSを並行録画(音声はaudio-*.ts・停止時に2トラックmux)")
    # v2.5.0: 運用堅牢化(別系統v2.4.0バンドルから移植) + P1/P2新機能
    ap.add_argument("--min-free-mb", dest="min_free_mb", type=float, default=512,
                    help="ディスク空き容量の下限(MB)。下回ると安全停止(既定512、0で無効)。"
                         "測定不能も危険扱い(二重確認のうえ停止)")
    ap.add_argument("--min-free-inodes", dest="min_free_inodes", type=float, default=0,
                    help="空きinode数の下限(POSIXのみ)。下回ると安全停止(既定0=無効)。"
                         "小ファイル連投によるinode枯渇の保守。偽値を報告するFSでは0を推奨")
    ap.add_argument("--segindex", action="store_true",
                    help="取得済みURI鍵(path+range・署名なし)を永続化"
                         "(<out>/RPLAY_<ID>_segindex.json)。再起動時に既知セグメントを再取得しない")
    ap.add_argument("--webhook", default="",
                    help="イベント通知先URL(start/part/audio_part/endをJSON POST・非同期送信)")
    ap.add_argument("--healthcheck", default=None, metavar="DIR",
                    help="録画せずDIRのheartbeat.jsonの鮮度を判定して終了"
                         "(新鮮=exit 0/古い・無し=exit 1 — Docker HEALTHCHECK等)")
    ap.add_argument("--extinf-mode", dest="extinf_mode", choices=["legacy", "rfc"], default="legacy",
                    help="EXTINF検証モード(v2.5.0/P1)。legacy=EXTINF未宣言セグメントを"
                         "診断計数(missingExtinf)して継続(既定・旧入力互換)。"
                         "rfc=RFC 8216厳格モード(未宣言を拒否)")
    ap.add_argument("--qaudit", choices=["auto", "no"], default="auto",
                    help="停止時の実メディア品質監査(ffprobe PTS/DTS単調性・timebase・"
                         "全編デコード、v2.6.0: 分離音声との実時間相関avCorrelation)。"
                         "auto=ffprobeがあれば実施(既定)/no=無効。"
                         "マニフェスト宣言値(PDT)だけでは品質合格扱いにしない")
    ap.add_argument("--audit-files", dest="audit_files", nargs="+", metavar="FILE",
                    help="v2.48.0: 保存済みローカルファイル(TS/MP4)に対して実メディア品質監査(ffprobe PTS/DTS単調性・全編デコード・AV相関)を単体実行しJSON出力して終了")
    ap.add_argument("--ad-keyword", dest="ad_keyword", default="", metavar="REGEX",
                    help="v2.48.0: N_m3u8DL-RE/Streamlink方式 — セグメントURIパスが正規表現に一致する広告/フィラーセグメントを除外して計数")
    ap.add_argument("--mux-audio-parts", dest="mux_audio_parts", action="store_true",
                    help="v2.48.0: 分離音声パートがある複数パート録画でも終了時にrplay_join.py --mux-audioで単一MP4へ結合")
    ap.add_argument("--merge-vtt", dest="merge_vtt", nargs="+", metavar="VTT_FILE",
                    help="v2.48.0: 複数のWebVTT字幕セグメントファイル(.vtt)を検証・重複除去して1つのWebVTTへ結合")
    ap.add_argument("--vtt-out", dest="vtt_out", default=None, metavar="OUT_VTT",
                    help="v2.48.0: --merge-vtt の結合結果出力先ファイルパス(既存ファイル上書き拒否)")
    ap.add_argument("--join-files", dest="join_files", nargs="+", metavar="PART_FILE",
                    help="v2.48.0: 保存済みの複数TS/MP4パートを無劣化結合して単一MP4を生成(全編デコード検証・原本保持)")
    ap.add_argument("--join-audio-files", dest="join_audio_files", nargs="+", metavar="AUDIO_PART",
                    help="v2.48.0: --join-files 併用時に分離音声パート(audio-*.ts)を2トラックMP4へ無劣化mux")
    ap.add_argument("--join-subtitle", dest="join_subtitle", default=None, metavar="VTT_FILE",
                    help="v2.48.0: --join-files 併用時にWebVTT(.vtt)字幕をmov_text字幕トラックとしてMP4へmux")
    ap.add_argument("--join-subtitle-lang", dest="join_subtitle_lang", default="jpn", metavar="LANG",
                    help="v2.48.0: --join-subtitle の言語コード(既定: jpn)")
    ap.add_argument("--join-out", dest="join_out", default=None, metavar="OUT_MP4",
                    help="v2.48.0: --join-files の出力先MP4パス(既存ファイル上書き拒否)")
    a = ap.parse_args()
    # v1.10.0: 設定ファイル(JSON) — ロングオプション名のキーを既定値として適用
    if a.config:
        try:
            with open(a.config, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            if not isinstance(cfg, dict):
                raise ValueError("JSONオブジェクトではありません")
            dests = {act.dest for act in ap._actions if act.dest != "help"}
            applied = 0
            for k, v in cfg.items():
                dest = k.replace("-", "_").lstrip("-")
                if dest in dests and dest not in ("config",):
                    setattr(a, dest, v)
                    applied += 1
            print("設定ファイル: %s (%d項目を適用 — コマンドライン引数が優先)" % (a.config, applied))
        except Exception as e:
            print("警告: 設定ファイルを読めません(%s) — コマンドライン引数のみ使用" % e)

    # v2.5.0: ヘルスチェック単体モード(heartbeat.jsonの鮮度判定 — 監視用)
    if a.healthcheck is not None:
        d = a.healthcheck or "."
        hb = os.path.join(d, "heartbeat.json")
        ok, ts = heartbeat_fresh(hb)
        if ok:
            try:
                with open(hb, "r", encoding="utf-8") as f:
                    meta = json.load(f)
            except Exception:
                meta = {}
            print("healthy — heartbeat %.0f秒前 state=%s seg=%s parts=%s saveErrors=%s" % (
                time.time() - ts, meta.get("state"), meta.get("seg"), meta.get("parts"),
                meta.get("saveErrors")))
            return 0
        print("unhealthy — heartbeat.jsonが無いか古いです(%s)" % hb)
        return 1
    # v2.5.0: 標準入力から対象を読込(echo URL | rplay_dl.py -)
    if a.target == "-":
        line = sys.stdin.readline().strip()
        if not line:
            print("エラー: 標準入力が空です(対象のURLまたはIDをパイプしてください)", file=sys.stderr)
            return 1
        a.target = line
        print("標準入力から対象を読込みました: %s" % line)
    # v2.48.0: 保存済みファイル単体品質監査モード / WebVTT字幕セグメント結合モード(target不要)
    if getattr(a, "audit_files", None):
        return cmd_audit_files(a)
    if getattr(a, "merge_vtt", None):
        return cmd_merge_vtt(a)
    if getattr(a, "join_files", None):
        return cmd_join_files(a)
    # v1.12.0: ライブ探索モード(target不要 — 公開APIだけで配信者を探す)
    if a.discover:
        return cmd_discover(a)
    m = OID_RE.search(a.target or "")
    if not m:
        print("エラー: 配信URLまたはクリエイターID(16〜40桁の16進)を指定してください(--discoverなら対象不要)", file=sys.stderr)
        return 1
    a.oid = m.group(1)
    if not a.out:
        a.out = os.path.join("rplay_dl", a.oid)

    d = Dl(a)
    if getattr(a, "print_m3u8dl", False):
        cands = d.hls_candidates()
        target_u = a.m3u8 or (cands[0] if cands else "")
        hdrs = {"Referer": "https://rplay.live/", "User-Agent": d.ua}
        jwt_now = d.auth.ensure_jwt()
        if jwt_now:
            hdrs["Authorization"] = jwt_now
        exp = build_m3u8dl_export(target_u, "RPLAY_%s_%s" % (safe_name(a.oid), stamp()), hdrs, True)
        print(json.dumps(exp, ensure_ascii=False, indent=2))
        return 0
    if a.once:
        info = d.scent() or {}
        cls = d.probe()
        api = d.api_state()
        print("ID: %s" % a.oid)
        print("詮索(live/play): state=%s / accessible=%s / allowAnonymous=%s" % (
            info.get("streamState", "不明"), info.get("accessible"), info.get("allowAnonymous")))
        print("HLS源候補:")
        for c in d.hls_candidates():
            print("  - " + c)
        print("プレイリスト: %s" % cls)
        print("API: %s" % api)
        return 0
    return d.run()


if __name__ == "__main__":
    sys.exit(main())
