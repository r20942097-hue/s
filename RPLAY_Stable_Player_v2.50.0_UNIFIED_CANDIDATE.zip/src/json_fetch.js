  /* ---- v2.37.0: 共通JSON取得(ページ/BG同一実装) ----
     前版までページ側(player.user.js)のみだったstream読込契約をoffscreen_pre.js
     側にも共通適用する。旧offscreen実装(応答をjson()で一括読込・サイズ上限なし・
     ヘッダ受信でtimeout解除)は廃止し、BG経路のJSONも同じ上限契約へ揃える。
     - 2 MiB上限: 宣言Content-Lengthと実受信byte数の両方を検査し、超過は
       JSON_TOO_LARGEとして即失敗(再試行しない)。上限ちょうどは成功。
     - 本文はgetReaderでchunk読込し、fatal UTF-8 TextDecoderで連結する。
       stream非対応はJSON_STREAM_UNAVAILABLEとして即失敗(json()へfallbackしない)。
     - timeoutは本文受信完了まで有効(旧offscreenの「ヘッダで解除」を廃止)。
     - finallyでctl.abortとreader.cancel/releaseLockを必ず実施(部分受信の解放)。
     - 再試行は通信失敗(status 0)と5xxのみ最大1回・800ms間隔。429はretry-afterを
       返して再試行しない。JSON_TOO_LARGE/JSON_STREAM_UNAVAILABLEはterminal。
     - logFnは未使用引数(呼び互換のため保持)。signalは外部停止要求の即時反映。 */
  async function fetchJsonWithRetry(url, headers, timeoutMs, logFn, signal) {
    const cancelled=()=>signal&&signal.aborted;
    const pause=()=>new Promise(resolve=>{let timer;const finish=()=>{clearTimeout(timer);if(signal)signal.removeEventListener('abort',finish);resolve();};timer=setTimeout(finish,800);if(signal){signal.addEventListener('abort',finish,{once:true});if(signal.aborted)finish();}});
    for(let a=0;a<2;a++){
      if(cancelled())return {ok:false,status:0,aborted:true};
      const ctl=new AbortController(),abort=()=>ctl.abort();
      if(signal)signal.addEventListener('abort',abort,{once:true});
      const timer=setTimeout(abort,timeoutMs||8000);
      let result,reader;
      try{
        if(cancelled())ctl.abort();
        const res=await fetch(url,{cache:'no-store',headers:headers||{},signal:ctl.signal});
        if(res.status===200){
          const limit=2*1048576,fail=code=>{const e=Error(code);e.code=code;throw e;};
          if(Number(res.headers.get('content-length'))>limit)fail('JSON_TOO_LARGE');
          if(!res.body||!res.body.getReader)fail('JSON_STREAM_UNAVAILABLE');
          reader=res.body.getReader();let size=0,text='';const decoder=new TextDecoder('utf-8',{fatal:true});
          while(true){const part=await reader.read();if(part.done)break;size+=part.value.byteLength;if(size>limit)fail('JSON_TOO_LARGE');text+=decoder.decode(part.value,{stream:true});}
          text+=decoder.decode();result={ok:true,status:200,json:JSON.parse(text)};
        }
        else result={ok:false,status:res.status,...(res.status===429?{retryAfter:res.headers.get('retry-after')}:{})};
      }catch(e){result={ok:false,status:0,...(e.code?{error:e.code}:{})};}
      finally{ctl.abort();clearTimeout(timer);if(signal)signal.removeEventListener('abort',abort);if(reader){try{const p=reader.cancel();if(p&&p.catch)p.catch(()=>{});}catch(e){}reader.releaseLock();}}

      if(cancelled())return {ok:false,status:0,aborted:true};
      if(result.error||result.ok||result.status>0&&result.status<500||a===1)return result;
      await pause();
    }
  }
  if(typeof module!=='undefined')module.exports={fetchJsonWithRetry};
