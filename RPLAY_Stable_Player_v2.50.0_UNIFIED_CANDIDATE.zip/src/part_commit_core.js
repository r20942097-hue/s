  // v2.42.4 per-part audit correlation. Only numerical evidence and local part hashes.
  // Accepted HLS bytes are not proof that a completed media file will decode.
  const rspPartCommit=(function(){'use strict';
    const counters=['queued','accepted','terminal','acceptedMediaBytes','acceptedInitBytes',
      'suspectedManifestMissing','declaredGaps','backlogSkipped',
      'sequenceDiscontinuities','suspectedAcceptedSequenceGaps'];
    function snapshot(owner,transport){
      if(!transport||typeof transport.writeEvidence!=='function')return null;
      const report=transport.writeEvidence(owner),point={schema:1};
      for(const k of counters){const v=report[k];point[k]=Number.isSafeInteger(v)&&v>=0?v:0;}
      return Object.freeze(point);
    }
    function interval(before,after){
      if(!before||!after)return {schema:1,provenance:'no_hls_counter_snapshot',scope:'part_interval',countersAvailable:false,fileCommitted:false,avDecoded:false};
      const delta={};let reset=false;
      for(const k of counters){const a=before[k],b=after[k];
        if(!Number.isSafeInteger(a)||!Number.isSafeInteger(b)||a<0||b<0||b<a){reset=true;break;}
        delta[k]=b-a;
      }
      return reset?{schema:1,provenance:'counter_reset_or_unavailable',scope:'part_interval',countersAvailable:false,fileCommitted:false,avDecoded:false}:
        {schema:1,provenance:'writer_acceptance_counter_interval',scope:'part_interval',countersAvailable:true,
          attribution:'approximate_boundary_snapshot; queued segments can predate part open; acceptance can race part close',
          ...delta,fileCommitted:false,avDecoded:false};
    }
    function normPartSeq(ps){
      if(!ps||typeof ps!=='object')return undefined;
      const nat=v=>Number.isSafeInteger(v)&&v>=0?v:0;
      const optInt=v=>Number.isSafeInteger(v)&&v>=0?v:null;
      return {
        attribution:'exact_pushData_part_binding',
        segments:nat(ps.segments),
        mediaBytes:nat(ps.mediaBytes),
        initBytes:nat(ps.initBytes),
        firstSequence:optInt(ps.firstSequence),
        lastSequence:optInt(ps.lastSequence),
        firstEpoch:optInt(ps.firstEpoch),
        lastEpoch:optInt(ps.lastEpoch),
        firstDiscontinuity:optInt(ps.firstDiscontinuity),
        lastDiscontinuity:optInt(ps.lastDiscontinuity),
        sequenceGaps:nat(ps.sequenceGaps),
        discontinuities:nat(ps.discontinuities)
      };
    }
    function correlate(entry,from,to,result,track,partSeq){
      const counters=interval(from,to),confirmed=!!(result&&result.confirmed),stage=result&&result.stage||'unknown';
      const sha=typeof(result&&result.hashHex)==='string'&&/^[a-f0-9]{64}$/.test(result.hashHex)?result.hashHex:null;
      const fileClosed=confirmed&&stage==='FILE_CLOSED';
      const sinkReceipt=confirmed?(fileClosed?'file_closed_and_readback':'browser_reported_complete'):
        stage==='ERROR'?'write_failed':'not_confirmed';
      const ck=result&&result.checkpoint;
      const check=ck&&fileClosed&&ck.status==='complete'&&Number.isSafeInteger(ck.chunks)&&ck.chunks>=0&&
        Number.isSafeInteger(ck.committedBytes)&&ck.committedBytes>=0&&ck.committedBytes===entry.bytes?
        {chunks:ck.chunks,committedBytes:ck.committedBytes,status:'complete',source:'chunk_hash_verified_at_checkpoint'}:undefined;
      const seqRange=normPartSeq(partSeq);
      const proof={schema:1,track:track==='audio'?'audio':'video',
        provenance:'recording_part_writer_receipt_and_counter_interval',
        acceptedHls:counters,sinkReceipt,fileCommitted:fileClosed,
        browserReportedComplete:confirmed&&!fileClosed,sha256:sha,
        sha256Provenance:sha?(fileClosed?'saved_file_readback':'pre_download_blob'):null,
        ...(check?{checkpoint:check}:{}),...(seqRange?{partSequenceRange:seqRange}:{}),avDecoded:false};
      if(entry&&typeof entry==='object')entry.partIntegrity=proof;
      return proof;
    }
    return Object.freeze({snapshot,interval,correlate});
  })();
