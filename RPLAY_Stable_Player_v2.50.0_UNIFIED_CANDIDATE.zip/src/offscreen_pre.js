/* =====================================================================
   RPLAY Stable Player — offscreen recording host (v2.0 Step2)
   =====================================================================
   このファイルは scripts/build.py が生成します(手で編集しない)。
     offscreen.js = src/offscreen_pre.js
                  + user.js の「RSP RECORDING CORE」領域(そのまま同期)
                  + src/offscreen_post.js
   役割: 拡張機能のoffscreen document内で録画コアを実行する。
   - Service Workerは30秒程度で停止するが、offscreen documentは
     生成後は生存し続ける(長時間処理の受け皿として公式に想定された機能)。
   - コアはuser.jsと同一文字列(RSP_RECENV_HOOKでRECENVだけ差し替え)。
   - chrome.runtime が無い環境(通常ページ)で読み込まれた場合は
     試験ブリッジ(window.__RSP_OFFSCREEN_TEST__)を公開する(E2E用)。
   ===================================================================== */
(function () {
  'use strict';

  const HAS_EXT = typeof chrome !== 'undefined' && !!(chrome.runtime && chrome.runtime.id && chrome.runtime.sendMessage);

  const CONTROL_GATE = RspSessionGate.create(() => crypto.randomUUID(), () => {
    const raw=localStorage.getItem('rsp_control_epoch_v1');
    const old=raw===null?0:Number(raw);
    if(!Number.isSafeInteger(old)||old<0||old>=Number.MAX_SAFE_INTEGER)throw Error('CONTROL_EPOCH_INVALID');
    const next=old+1;localStorage.setItem('rsp_control_epoch_v1',String(next));return next;
  });
  /* ---- メッセージアダプタ(offscreen→SW/テストブリッジ) ----
     拡張: chrome.runtime.sendMessage(片方向・応答不要のイベント)
     ページ: window.postMessage(rspOffscreenEvt) を試験側が受け取る */
  const EVT_LOG = [];
  const MSG = {
    send: function (obj) {
      const binding=CONTROL_GATE.binding();
      if(binding && !obj.sessionId && ['rec.event','rec.stopped','perm.request'].includes(obj.type)) obj={...obj,sessionId:binding.sessionId,epoch:binding.epoch,oid:binding.oid};
      EVT_LOG.push(obj);
      if (EVT_LOG.length > 400) EVT_LOG.shift();
      /* v2.1.0 Step3: Firefox Event Pageでは同一背景ウィンドウ内の__RSP_SW_SINK__へ直接配送 */
      if (typeof window !== 'undefined' && typeof window.__RSP_SW_SINK__ === 'function') {
        try { window.__RSP_SW_SINK__(obj); return; } catch (e) {}
      }
      if (HAS_EXT) {
        try { const p = chrome.runtime.sendMessage(obj); if (p && p.catch) p.catch(function () {}); } catch (e) {}
      } else {
        try { window.postMessage({ rspOffscreenEvt: true, msg: obj }, '*'); } catch (e) {}
      }
    }
  };

  /* ---- 実行状態 ---- */
  const STATE = {
    recorder: null,      // Recorder コアインスタンス(同時に1件 — 二重録画の構造的排除)
    pageUrl: '',         // UIタブのURL(相対m3u8解決の基準)
    creatorName: '',
    customM3u8: '',
    customFlv: '',
    urlMode: false,      // v2.40.0: 任意HLS URL録画セッション(dashboard経由)
    urlSource: '',       // v2.40.0: 録画中URLの表示用ラベル(origin+path・クエリなし)
    handleOk: false,
    handleName: '',
    recoveredParts: []   // v2.1.0(設計書§4.3): OPFS退避から引き継いだ未フラッシュ復旧記録
  };
  const SET = {
    inheritQuery: false, follow: true, flv: true, backlog: true, infoJson: false, notify: true,
    bestQ: true, recAudio: false, nameTpl: '', csv: false, remind: 'both', splitMin: 0,
    opfsBackup: true,    // v2.1.0(設計書§4.3): パートクローズごとのOPFS複製退避(最新2パート・既定ON)
    mp4AutoHandoff: false, // v2.48.0(統合): BG停止後に残ったTSパートのMP4自動変換・引渡し(既定OFF・現行動作維持)
    segmentAcquire: false // v2.50.0(Stage 3): 汎用disk-backed取得の明示起動(既定OFF・dashboard明示操作のみ)
  };
  const TITLEC = { base: '', cur: '' };
  const LOGTAIL = [];

  function applySettings(s) {
    if (!s) return;
    if (typeof s.inheritQuery === 'boolean') SET.inheritQuery = s.inheritQuery;
    if (typeof s.follow === 'boolean') SET.follow = s.follow;
    if (typeof s.flv === 'boolean') SET.flv = s.flv;
    if (typeof s.backlog === 'boolean') SET.backlog = s.backlog;
    if (typeof s.infoJson === 'boolean') SET.infoJson = s.infoJson;
    if (typeof s.notify === 'boolean') SET.notify = s.notify;
    if (typeof s.bestQ === 'boolean') SET.bestQ = s.bestQ;
    if (typeof s.recAudio === 'boolean') SET.recAudio = s.recAudio;
    if (typeof s.nameTpl === 'string') SET.nameTpl = s.nameTpl;
    if (typeof s.csv === 'boolean') SET.csv = s.csv;
    if (typeof s.remind === 'string') SET.remind = s.remind;
    if (typeof s.splitMin === 'number' && s.splitMin >= 0) SET.splitMin = s.splitMin;
    if (typeof s.opfsBackup === 'boolean') SET.opfsBackup = s.opfsBackup;
    if (typeof s.mp4AutoHandoff === 'boolean') SET.mp4AutoHandoff = s.mp4AutoHandoff; /* v2.48.0(統合) */
    if (typeof s.segmentAcquire === 'boolean') SET.segmentAcquire = s.segmentAcquire; /* v2.50.0(Stage 3) */
  }

  /* ---- OPFS保存+サルベージ要求(メモリモード保存のoffscreen実装) ----
     パート/情報JSON/CSVのBlobを一度OPFSへ確定書き込みしてからSWへ
     'salvage'を送る。SWは同一originのOPFSから読みchrome.downloadsで
     ユーザーのダウンロードへ書き出す。offscreenがサルベージ前に
     異常終了してもOPFSのファイルは残る(次回SW起動時のsweepで回収)。 */
  function osSafeName(n) {
    return String(n || 'part.bin').replace(/[\\/:*?"<>|]/g, '_').slice(0, 180) || 'part.bin';
  }
  function sendExport(msg) {
    if (typeof window !== 'undefined' && typeof window.__RSP_SW_SINK__ === 'function') {
      return new Promise(resolve => window.__RSP_SW_SINK__(msg, resolve));
    }
    if (HAS_EXT) return chrome.runtime.sendMessage(msg);
    return Promise.resolve({ok:false,error:'NO_EXPORT_ROUTER'});
  }
  const EXPORT_HOST = RspExportHost.create({navigator, URL, crypto, send:sendExport});
  function opfsSaveAndSalvage(blob, name) { const p = EXPORT_HOST.save(blob, name); p.catch(() => {}); return p; }

  /* ---- v2.1.0(設計書§4.3): クラッシュ時のOPFS最新2パート複製退避と復旧記録 ---- */
  const BACKUP_META_KEY = 'rsp_backup_meta_v21';
  const BACKUP_DIRTY_KEY = 'rsp_backup_dirty_v21';
  function readBackupMeta() {
    try {
      const raw = localStorage.getItem(BACKUP_META_KEY);
      const arr = raw ? JSON.parse(raw) : [];
      return Array.isArray(arr) ? arr : [];
    } catch (e) { return []; }
  }
  function writeBackupMeta(arr) {
    try {
      if (!arr || !arr.length) localStorage.removeItem(BACKUP_META_KEY);
      else localStorage.setItem(BACKUP_META_KEY, JSON.stringify(arr.slice(-2)));
    } catch (e) {}
  }
  let backupChain = Promise.resolve();
  function opfsBackupPart(blob,name,meta) {
    const task=backupChain.then(()=>writeBackupPart(blob,name,meta));backupChain=task.catch(()=>{});return task;
  }
  async function writeBackupPart(blob, name, meta) {
    if (!SET.opfsBackup || !blob) return;
    const safe = osSafeName(name);
    const entry = Object.assign({ file: safe, backedUpAt: new Date().toISOString() }, meta || {});
    const list = readBackupMeta();
    list.push(entry);
    const keep = list.slice(-2);
    const keepNames = new Set(keep.map(function (x) { return osSafeName(x.file); }));

    try {
      const root = await navigator.storage.getDirectory();
      const dir = await root.getDirectoryHandle('rsp_backup', { create: true });
      const fh = await dir.getFileHandle(safe, { create: true });
      const w = await fh.createWritable();
      await w.write(blob);
      await w.close();
      writeBackupMeta(keep);
      /* 容量制限のため最新2パートのみ保持し、古い退避ファイルを削除 */
      for await (const [fname, h] of dir.entries()) {
        if (h.kind === 'file' && !keepNames.has(fname)) {
          try { await dir.removeEntry(fname); } catch (e2) {}
        }
      }
    } catch (e) {}
  }
  function markBackupClean() {
    try { localStorage.removeItem(BACKUP_DIRTY_KEY); } catch (e) {}
  }
  function checkBackupRecovery() {
    try {
      const dirty = localStorage.getItem(BACKUP_DIRTY_KEY) === '1';
      const leftover = readBackupMeta();
      if (dirty && leftover.length > 0) {
        STATE.recoveredParts = leftover.map(function (x) {
          return Object.assign({}, x, { recoveredAt: new Date().toISOString() });
        });
      } else {
        STATE.recoveredParts = [];
      }
      localStorage.setItem(BACKUP_DIRTY_KEY, '1');
    } catch (e) { STATE.recoveredParts = []; }
  }

  /* ---- RECENV差し替え実装(v2.0 Step2の核心) ----
     コアがページ環境に依存していた全機能をoffscreen向けに置換する。
     - storage: offscreen文書のlocalStorage(生成し直しても残る拡張origin分)
     - download: OPFS確定書き込み→SWへsalvage(フォルダ直書きはコアが
       dirHandle経由で行うため、ここはメモリ保存モードの退避路のみ)
     - notify: SWがchrome.notificationsでOS通知(ページ権限不要)
     - title: タイトル表示はUIタブへイベント中継(●REC表示)
     - onUnload: offscreenはブラウザのアンロード対象外のため無効化 */
  const RSP_RECENV_HOOK = {
    pageUrl: function () { return STATE.pageUrl || 'https://rplay.live/'; },
    storageGet: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    storageSet: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} },
    storageDel: function (k) { try { localStorage.removeItem(k); } catch (e) {} },
    download: function (blob, name) { return opfsSaveAndSalvage(blob, name); },
    partByteLimit: 512 * 1048576,
    notify: function (title, body) { MSG.send({ type: 'rec.notify', title: title, body: body }); },
    getTitle: function () { return TITLEC.base; },
    setTitle: function (t) { TITLEC.cur = t; MSG.send({ type: 'rec.event', kind: 'title', title: t }); },
    onUnload: function () {},
    offUnload: function () {},
    perfHeap: function () {
      try { if (performance.memory && performance.memory.usedJSHeapSize) return performance.memory.usedJSHeapSize; } catch (e) {}
      return null;
    },
    testHooks: function () { try { return window.__RSP_TEST || {}; } catch (e) { return {}; } },
    backupPart: function (blob, name, meta) { return opfsBackupPart(blob, name, meta); },
    recoveredParts: function () { return STATE.recoveredParts ? STATE.recoveredParts.slice() : []; },
    /* v2.7.0(A-02/A-03): 認証・canary証拠の供給(offscreenホスト版)。
       ページ側のRspAuthはここから直接参照できないため、content側から
       STATE.authStatsへ中継された計数を使う(未中継ならundefined — 証拠ブロック
       を出さない。虚偽のゼロを捏造しない契約)。canaryはoffscreenが独自に
       live/playを呼ばないため常に未供給(ページ側の録画情報JSONに残る)。 */
    authStats: function () { return buildHostAuthStats(); },
    canaryEvidence: function () { return STATE.canaryEvidence || undefined; },
    butterToken: function () { try { return butterToken(); } catch (e) { return Promise.resolve(''); } },
    /* Worker生成: MV3拡張ページのCSPはBlob URL Workerをブロックするため、
       実ファイル(rec_worker.js)のWorkerを使う(プロトコルはコアと同一)。
       失敗時はnull → コアがsetInterval/同期検証へフォールバック。 */
    makeWorker: function (src) {
      if (HAS_EXT) {
        try { return new Worker(chrome.runtime.getURL('rec_worker.js')); } catch (e) { return null; }
      }
      try { return new Worker(URL.createObjectURL(new Blob([src], { type: 'application/javascript' }))); }
      catch (e) { return null; }
    },
    /* v2.39.0: 自動開始の共通policy(offscreen版 — 追跡再開/FLV代替のgate)。
       この文書は拡張ページのためchrome.storage.localを直接読める(3秒有界・
       BGのdashboardDefaultsと同じ検証)。拒否=autoStartAllowed:false、
       読めない/不正=不明(fail-closed: 再開しない)。手動開始は参照しない。 */
    autoPolicy: function () {
      return new Promise(function (resolve) {
        let done = false;
        const finish = function (v) { if (!done) { done = true; resolve(v); } };
        try {
          if (!HAS_EXT || !chrome.storage || !chrome.storage.local || typeof chrome.storage.local.get !== 'function')
            return finish({ verdict: 'allowed' });
          const bound = (function () { try { const v = Number((typeof window !== 'undefined' && window.__RSP_TEST && window.__RSP_TEST.settingsReadMs)); return Number.isFinite(v) && v > 0 ? v : 3000; } catch (e) { return 3000; } })();
          let timer = 0;
          if (typeof setTimeout === 'function') { try { timer = setTimeout(function () { finish({ verdict: 'unavailable' }); }, bound); } catch (e) { timer = 0; } }
          chrome.storage.local.get('rsp_dashboard_defaults', function (v) {
            if (timer) { try { clearTimeout(timer); } catch (e) {} }
            if (chrome.runtime.lastError || !v || typeof v !== 'object') return finish({ verdict: 'unavailable' });
            const d = v.rsp_dashboard_defaults;
            if (d !== undefined && (!d || typeof d !== 'object' || Array.isArray(d) ||
              ['autoStartAllowed', 'enabled', 'follow', 'recAudio', 'inheritQuery', 'mp4Handover', 'mp4AutoHandoff', 'segmentAcquire'].some(function (k) { return d[k] !== undefined && typeof d[k] !== 'boolean'; }) || /* v2.48.0(統合): mp4AutoHandoff 追加 */
              (d.splitMin !== undefined && (typeof d.splitMin !== 'number' || !Number.isFinite(d.splitMin) || d.splitMin < 0 || d.splitMin > 1440))))
              return finish({ verdict: 'unavailable' });
            finish({ verdict: (d && d.autoStartAllowed === false) ? 'denied' : 'allowed' });
          });
        } catch (e) { finish({ verdict: 'unavailable' }); }
      });
    },
    /* v2.39.0: セッション終了フック — BG停止後のMP4引渡し台帳(rsp_last_session)を
       chrome.storage.localへ書く。秘密なし(名前/容量/トラック/結合job)。
       64KiB上限・書込失敗は静かに諦める(派生データ・失敗許容)。 */
    sessionEnded: function (rec) {
      if (!HAS_EXT || !chrome.storage || !chrome.storage.local || typeof chrome.storage.local.set !== 'function') return Promise.resolve(false);
      return new Promise(function (resolve) {
        try {
          const m = rspSessionManifest(rec);
          if (!m) return resolve(false);
          chrome.storage.local.set({ rsp_last_session: m }, function () { resolve(!chrome.runtime.lastError); });
        } catch (e) { resolve(false); }
      });
    }
  };

  /* ---- v2.39.0: セッション終了台帳の構築(MP4引渡し用・秘密なし) ----
     停止した録画セッションのパート一覧(名前/容量/トラック)と結合job(順序契約)を
     保存する。変換画面はこれを使って「どのファイルを選べばよいか」を案内する
     (ブラウザーのセキュリティモデル上、ファイル本体はユーザーが選ぶ)。 */
  function rspSessionManifest(rec) {
    try {
      if (!rec || typeof rec !== 'object') return null;
      const parts = [];
      const collect = function (r, track) {
        if (!r) return;
        const log = Array.isArray(r.partsLog) ? r.partsLog : [];
        for (const p of log) parts.push({ name: String(p && p.file || '').slice(0, 180), bytes: Number(p && p.bytes) || 0, track: track });
        if (r.partOpen) parts.push({ name: String(r.partName || '').slice(0, 180), bytes: Number(r.bytes) || 0, track: track });
      };
      collect(rec, 'video'); collect(rec.audio, 'audio');
      let job = null;
      try { job = recJoinJob(rec); } catch (e) { job = null; } /* 0パート等はnull */
      const m = { version: 1, at: Date.now(), oid: String(rec.id || '').toLowerCase(), creatorName: String(STATE.creatorName || '').slice(0, 200), title: String(TITLEC.base || '').slice(0, 200), urlSession: STATE.urlMode === true, sourceUrl: STATE.urlMode === true ? String(STATE.urlSource || '').slice(0, 500) : undefined, parts: parts.slice(0, 512), truncated: parts.length > 512, job: job };
      if (JSON.stringify(m).length > 65536) { m.parts = m.parts.slice(0, 256); m.truncated = true; m.job = null; }
      if (JSON.stringify(m).length > 65536) { m.parts = m.parts.slice(0, 64); m.job = null; }
      return m;
    } catch (e) { return null; }
  }

  /* =====================================================================
     以下、コアが参照するambient依存(ページ実装のoffscreen版)。
     user.jsではページ側にある API_BASE/CDN_BASE/RspAuth/authedJson/
     resolveMemberLive/resolveScheduleInfo/fetchSchedulesFor/memberFailHint/
     liveBaseLabel/_memberResolveCache をここで再定義する。
     ===================================================================== */
  /* API_BASE は録画コア領域内で定義される(__RSP_API_BASE 試験フック付き)。
     CDN_BASE はコアの外(ambient)のためここで定義する。 */
  const CDN_BASE = 'https://livestream.rplay.live/live/';

  /* 認証ホルダ: UIタブが rec.start / token.update で渡した自分のトークンを保持。
     offscreenではページのlocalStorageを読めないため、401時は token.stale イベントで
     UIタブへ再取得を促す(認証回避ではなく自分の会話の受け渡しのみ)。 */
  const BUTTER_KEY = 'S%M@#H#B(!@()a2@';
  const BUTTER_SALT = 'QWI@(!WAS)Dj1AA(!@*DJ#@$@~1)P';
  let _butterCache = { hex: '', at: 0 };
  function hexU8(u8) {
    let s = '';
    for (let i = 0; i < u8.length; i++) s += ('0' + u8[i].toString(16)).slice(-2);
    return s;
  }
  async function butterToken() {
    const now = Date.now();
    if (_butterCache.hex && now - _butterCache.at < 6 * 60 * 1000) return _butterCache.hex;
    try {
      const enc = new TextEncoder();
      const ts = String(Math.floor(now / 1000 / 360));
      const iv = enc.encode(ts.padStart(16, '0'));
      const clear = new Uint8Array(BUTTER_SALT.length + 17 + ts.length);
      let o = 0;
      clear.set(enc.encode(BUTTER_SALT), o); o += BUTTER_SALT.length;
      clear.set(enc.encode('https://rplay.live'), o); o += 17;
      clear.set(enc.encode(ts), o);
      const key = await crypto.subtle.importKey('raw', enc.encode(BUTTER_KEY), { name: 'AES-CBC' }, false, ['encrypt']);
      const cipher = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-CBC', iv: iv }, key, clear));
      _butterCache = { hex: hexU8(cipher), at: now };
      AUTH._butterSends = (AUTH._butterSends || 0) + 1;
      return _butterCache.hex;
    } catch (e) { return ''; }
  }
  function rspCanaryCheck(info) {
    const expected = ['bytePlusPlaybackUrl', 'playUrl', 'streamState',
      'accessible', 'tierHashes', 'useRplayStreamServer', 'allowAnonymous', 'title'];
    if (!info || typeof info !== 'object' || Array.isArray(info) || !Object.keys(info).length)
      return { result: 'unreachable', observedKeys: [], knownKeys: [] };
    const observed = Object.keys(info).map(String);
    const known = observed.filter(function (k) { return expected.indexOf(k) !== -1; });
    return { result: known.length ? 'ok' : 'shape_change',
             observedKeys: observed.slice().sort().slice(0, 24),
             knownKeys: known.slice().sort() };
  }
  function rspCanaryEvidence(res) {
    return { result: res.result, observedKeys: res.observedKeys, knownKeys: res.knownKeys,
             checkedAt: new Date().toISOString(), action: 'warn_only',
             provenance: 'live_play_response_shape' };
  }
  const AUTH = { jwt: '', refreshToken: '', userOid: '', nick: '', exp: 0,
    _401Classes: {}, _key2Resolutions: 0, _butterSends: 0, relayedStats: null };
  function jwtExp(jwt) {
    try {
      const p = JSON.parse(atob(jwt.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
      return (p && p.exp) || 0;
    } catch (e) { return 0; }
  }
  function sanitizeAuthStats(s) {
    if (!s || typeof s !== 'object') return null;
    const cls = {};
    if (s.classifications401 && typeof s.classifications401 === 'object') {
      for (const k of Object.keys(s.classifications401)) {
        const v = Number(s.classifications401[k]);
        if (Number.isFinite(v) && v >= 0) cls[String(k).slice(0, 32)] = v;
      }
    }
    return {
      mode: typeof s.mode === 'string' ? s.mode.slice(0, 40) : 'localStorage-interceptor',
      tokenSource: s.tokenSource === 'localStorage' || s.tokenSource === 'cli' ? s.tokenSource : null,
      refreshSource: s.refreshSource === 'localStorage-scan' || s.refreshSource === 'env' || s.refreshSource === 'file' || s.refreshSource === 'value' ? s.refreshSource : null,
      userOidSupplied: !!s.userOidSupplied,
      switchedToRefresh: !!s.switchedToRefresh,
      refreshAttempts: Number(s.refreshAttempts) || 0,
      refreshSuccesses: Number(s.refreshSuccesses) || 0,
      refreshFailures: Number(s.refreshFailures) || 0,
      responseKey: typeof s.responseKey === 'string' ? s.responseKey.slice(0, 32) : null,
      classifications401: cls,
      key2Resolutions: Number(s.key2Resolutions) || 0,
      butterSent: !!s.butterSent,
      provenance: 'rspauth_counters'
    };
  }
  function buildHostAuthStats() {
    const rel = AUTH.relayedStats;
    const hasLocal = !!(AUTH.jwt || AUTH.userOid || AUTH._key2Resolutions || AUTH._butterSends || Object.keys(AUTH._401Classes || {}).length);
    if (!rel && !hasLocal) return STATE.authStats || undefined;
    const merged401 = Object.assign({}, (rel && rel.classifications401) || {});
    for (const k of Object.keys(AUTH._401Classes || {})) {
      merged401[k] = (merged401[k] || 0) + (AUTH._401Classes[k] || 0);
    }
    return {
      mode: (rel && rel.mode) || 'localStorage-interceptor',
      tokenSource: (rel && rel.tokenSource) || (AUTH.jwt ? 'localStorage' : null),
      refreshSource: (rel && rel.refreshSource) || (AUTH.refreshToken ? 'localStorage-scan' : null),
      userOidSupplied: !!((rel && rel.userOidSupplied) || AUTH.userOid),
      switchedToRefresh: !!(rel && rel.switchedToRefresh),
      refreshAttempts: (rel && rel.refreshAttempts) || 0,
      refreshSuccesses: (rel && rel.refreshSuccesses) || 0,
      refreshFailures: (rel && rel.refreshFailures) || 0,
      responseKey: (rel && rel.responseKey) || null,
      classifications401: merged401,
      key2Resolutions: ((rel && rel.key2Resolutions) || 0) + (AUTH._key2Resolutions || 0),
      butterSent: !!((rel && rel.butterSent) || (AUTH._butterSends || 0) > 0),
      provenance: 'rspauth_counters',
      note: '秘密(トークン値)は含まない。公式interceptorと同一戦略(逐次読・Refresh-Tokenヘッダ送出のみ・本ツールは更新APIを呼ばない)'
    };
  }
  function applyAuth(p) {
    p = p || {};
    AUTH.jwt = p.jwt || '';
    AUTH.refreshToken = p.refreshToken || '';
    AUTH.userOid = p.userOid || '';
    AUTH.nick = p.nick || '';
    AUTH.exp = AUTH.jwt ? jwtExp(AUTH.jwt) : 0;
    if (p.authStats) AUTH.relayedStats = sanitizeAuthStats(p.authStats);
    if (p.canaryEvidence && typeof p.canaryEvidence === 'object') {
      STATE.canaryEvidence = {
        result: String(p.canaryEvidence.result || 'unreachable'),
        observedKeys: Array.isArray(p.canaryEvidence.observedKeys) ? p.canaryEvidence.observedKeys.slice(0, 24) : [],
        knownKeys: Array.isArray(p.canaryEvidence.knownKeys) ? p.canaryEvidence.knownKeys.slice(0, 24) : [],
        checkedAt: String(p.canaryEvidence.checkedAt || new Date().toISOString()),
        action: 'warn_only',
        provenance: 'live_play_response_shape'
      };
    }
  }
  const RspAuth = {
    get jwt() { return AUTH.jwt; },
    probe() { return this; }, /* offscreenでは再読込不可(expはjwtから常時算出) */
    requestorQuery() { return AUTH.userOid ? { requestorOid: AUTH.userOid, loginType: 'rplay' } : {}; },
    jwtHeaders(extra) {
      const h = { 'Platform-Type': 'rplay', Authorization: AUTH.jwt || 'null' };
      if (AUTH.refreshToken) h['Refresh-Token'] = AUTH.refreshToken;
      if (extra) for (const k in extra) h[k] = extra[k];
      return h;
    }
  };
  let _tokenStaleAt = 0;
  function emitTokenStale() {
    const now = Date.now();
    if (now - _tokenStaleAt < 60000) return;
    _tokenStaleAt = now;
    MSG.send({ type: 'rec.event', kind: 'token', msg: 'トークンが期限切れの可能性 — ライブページを開くと最新トークンへ自動更新します' });
  }

  /* RSP_JSON_FETCH_MODULE */
  /* offscreen版 authedJson: 401時の再読込はできないため token.stale を通知。
     トークンが token.update で更新されていれば、コア側の再試行ループが
     次回試行で新しいトークンを使用する(連打はコアの節流が担保)。 */
  async function authedJson(url, opts) {
    const o = opts || {};
    const r = await fetchJsonWithRetry(url, RspAuth.jwtHeaders(o.extraHeaders), o.timeoutMs || 8000, o.log, o.signal);
    if (r.status === 401) {
      AUTH._401Classes['auth-expired'] = (AUTH._401Classes['auth-expired'] || 0) + 1;
      emitTokenStale();
    }
    return r;
  }
  async function probeM3u8Ok(base) {
    if (!base) return false;
    try {
      const ctl = new AbortController();
      const to = setTimeout(() => ctl.abort(), 6000);
      const res = await fetch(base,
        { cache: 'no-store', signal: ctl.signal });
      clearTimeout(to);
      if (res.status !== 200) return false;
      const txt = await res.text();
      return txt.indexOf('#EXTM3U') >= 0 || txt.indexOf('#EXTINF') >= 0 || txt.indexOf('#EXT-X-STREAM-INF') >= 0;
    } catch (e) { return false; }
  }

  /* ---- 詮索/限定解決/予約(ページ実装と同一ロジック・キャッシュ付き) ---- */
  const _liveInfoCache = { oid: null, at: 0, info: null };
  async function resolveLiveInfo(creatorOid) {
    const now = Date.now();
    if (_liveInfoCache.oid === creatorOid && now - _liveInfoCache.at < 30000 && _liveInfoCache.info) {
      return _liveInfoCache.info;
    }
    const q = new URLSearchParams({ creatorOid: creatorOid });
    for (const k in RspAuth.requestorQuery()) q.set(k, RspAuth.requestorQuery()[k]);
    const r = await authedJson(API_BASE + '/live/play?' + q.toString(), { timeoutMs: 8000 });
    const info = (r && r.ok && r.json) ? r.json : null;
    STATE.canaryEvidence = rspCanaryEvidence(rspCanaryCheck(info));
    if (STATE.recorder && STATE.recorder.noteStreamStart && info) STATE.recorder.noteStreamStart(info);
    _liveInfoCache.oid = creatorOid;
    _liveInfoCache.at = now;
    _liveInfoCache.info = info;
    return info;
  }
  function liveBaseLabel(info) {
    if (!info) return '不明';
    if (info.streamState === 'youtube') return 'YouTube(外部)';
    if (info.useRplayStreamServer) return 'RPLAY自社';
    if (info.bytePlusPlaybackUrl && info.playUrl) return 'BytePlus+IVS併用';
    if (info.bytePlusPlaybackUrl) return 'BytePlus';
    if (info.playUrl) return 'IVS';
    return '不明';
  }
  const _memberResolveCache = { oid: null, at: 0, result: null }; /* コアが参照(キャッシュ無効化) */
  async function resolveMemberLive(creatorOid, logFn) {
    const logger = logFn || function () {};
    const now = Date.now();
    if (_memberResolveCache.oid === creatorOid && now - _memberResolveCache.at < 60000 && _memberResolveCache.result) {
      return _memberResolveCache.result;
    }
    const info = (await resolveLiveInfo(creatorOid)) || {};
    if (info == null || (!info.streamState && !info.oid && !info.creatorOid)) {
      logger('live/play 応答なし — 一時障害の可能性');
      return { ok: false, reason: 'api', status: 0 };
    }
    const st = info.streamState;
    if (st && st !== 'live') {
      if (st === 'youtube') return { ok: false, reason: 'youtube', redirect: info.liveStreamId };
      if (st === 'twitch') return { ok: false, reason: 'twitch', redirect: info.twitchLogin };
      return { ok: false, reason: st };
    }
    if (!info.accessible) {
      const freeTier = info.tierHashes && info.tierHashes.free;
      return { ok: false, reason: 'no-access', freeTier: !!freeTier };
    }
    if (!info.allowAnonymous && !RspAuth.jwt) return { ok: false, reason: 'login-required' };
    let key2 = '';
    if (RspAuth.jwt) {
      const q2 = new URLSearchParams({ creatorOid: creatorOid });
      for (const k in RspAuth.requestorQuery()) q2.set(k, RspAuth.requestorQuery()[k]);
      const r2 = await authedJson(API_BASE + '/live/key2?' + q2.toString(), { timeoutMs: 8000, log: logger });
      if (r2.ok && r2.json) { key2 = r2.json.authKey || ''; if (key2) AUTH._key2Resolutions = (AUTH._key2Resolutions || 0) + 1; }
      else if (r2.status === 401) {
        logger('live/key2 401 — トークンが無効です(UIタブを開くと自動更新します)');
        return { ok: false, reason: 'auth-expired', status: 401 };
      } else if (r2.status === 403) {
        logger('live/key2 403 — この配信への視聴権限がありません');
        return { ok: false, reason: 'no-access', status: 403 };
      } else logger('live/key2 ' + (r2.status || 'error') + ' — 鍵なしで継続を試みます');
    }
    const playlist = API_BASE + '/live/stream/playlist.m3u8?creatorOid=' + encodeURIComponent(creatorOid) +
      (key2 ? '&key2=' + encodeURIComponent(key2) : '');
    if (!(await probeM3u8Ok(playlist))) {
      logger('限定プレイリスト(' + playlist.split('?')[0] + ')が取得不能 — この源は採用しません');
      return { ok: false, reason: 'playlist' };
    }
    const result = { ok: true, playlist: playlist, key2: key2, title: info.title || '',
      allowAnonymous: !!info.allowAnonymous, base: liveBaseLabel(info) };
    _memberResolveCache.oid = creatorOid;
    _memberResolveCache.at = now;
    _memberResolveCache.result = result;
    return result;
  }
  function memberFailHint(r) {
    if (!r) return '限定配信の解決に失敗しました(一時障害の可能性 — 自動で再試行します)';
    switch (r.reason) {
      case 'no-access':
        return r.freeTier
          ? 'この配信は無料プラン加入限定です。プランに加入すると再生/録画できます'
          : 'この配信への視聴権限がありません(プラン加入/鍵/チケットのいずれかが必要)';
      case 'login-required':
        return '会員限定配信です。RPLAYにログインすると視聴権限があれば再生/録画できる可能性があります';
      case 'auth-expired':
        return 'ログイントークンが期限切れです — ライブページを開くと最新トークンへ自動更新します';
      case 'api':
        return 'RPLAY APIが一時的に応答していません — 自動で再試行します';
      case 'playlist':
        return '限定プレイリストを取得できません(配信の準備中/終了直後の可能性) — 自動で再試行します';
      case 'youtube':
      case 'twitch':
        return '外部配信(' + r.reason + ')のためこのプレイヤーでは扱いません';
      case 'offline':
        return '配信はオフラインです(開始を待機します)';
      default:
        return '限定配信を解決できませんでした(' + (r.reason || '不明') + ') — 自動で再試行します';
    }
  }
  const _schedCache = { oid: null, at: 0, item: null };
  function _pickScheduleItem(j) {
    let arr = null;
    if (Array.isArray(j)) arr = j;
    else if (j && typeof j === 'object') {
      for (const k of ['schedules', 'items', 'list', 'data', 'results']) {
        if (Array.isArray(j[k])) { arr = j[k]; break; }
      }
      if (!arr && (j.scheduledAt || j.startsAt || j.startAt)) arr = [j];
    }
    if (!arr) return null;
    const nowMs = Date.now();
    let best = null, bestT = Infinity;
    for (const it of arr) {
      if (!it || typeof it !== 'object') continue;
      const raw = it.scheduledAt || it.startsAt || it.startAt ||
        (it.live && (it.live.scheduledAt || it.live.startsAt));
      let t = 0;
      if (typeof raw === 'number') t = raw < 1e12 ? raw * 1000 : raw;
      else if (typeof raw === 'string') { const d = Date.parse(raw); if (!isNaN(d)) t = d; }
      if (!t) continue;
      if (t > nowMs - 30 * 60 * 1000 && t < bestT) { bestT = t; best = { title: it.title || it.name || '', scheduledAt: t }; }
    }
    return best;
  }
  async function resolveScheduleInfo(creatorOid) {
    const now = Date.now();
    const ttl = _schedCache.item ? 60000 : 20000;
    if (_schedCache.oid === creatorOid && now - _schedCache.at < ttl) return _schedCache.item;
    _schedCache.oid = creatorOid;
    _schedCache.at = now;
    if (!RspAuth.jwt) return null;
    try {
      const q = new URLSearchParams({ creatorOid: creatorOid });
      for (const k in RspAuth.requestorQuery()) q.set(k, RspAuth.requestorQuery()[k]);
      const r = await authedJson(API_BASE + '/live/schedules?' + q.toString(), { timeoutMs: 8000, signal });
      if (signal && signal.aborted) return { err: 'aborted' };
      if (!r.ok) return null;
      const item = _pickScheduleItem(r.json);
      _schedCache.item = item;
      return item;
    } catch (e) { return null; }
  }
  async function fetchSchedulesFor(creatorOid, signal) {
    if (!RspAuth.jwt) return { err: 'nologin' };
    try {
      const q = new URLSearchParams({ creatorOid: creatorOid });
      for (const k in RspAuth.requestorQuery()) q.set(k, RspAuth.requestorQuery()[k]);
      const r = await authedJson(API_BASE + '/live/schedules?' + q.toString(), { timeoutMs: 8000, signal });
      if (signal && signal.aborted) return { err: 'aborted' };
      if (!r.ok) return { err: String(r.status || 'error') };
      const arr = Array.isArray(r.json) ? r.json :
        ((r.json && (r.json.schedules || r.json.items || r.json.list || r.json.data || r.json.results)) || []);
      const nowMs = Date.now();
      const out = [];
      for (const it of arr) {
        if (!it || typeof it !== 'object') continue;
        const raw = it.scheduledAt || it.startsAt || it.startAt ||
          (it.live && (it.live.scheduledAt || it.live.startsAt));
        let t = 0;
        if (typeof raw === 'number') t = raw < 1e12 ? raw * 1000 : raw;
        else if (typeof raw === 'string') { const d = Date.parse(raw); if (!isNaN(d)) t = d; }
        if (!t) continue;
        if (t > nowMs - 30 * 60 * 1000) out.push({ title: it.title || it.name || '', scheduledAt: t });
      }
      return { items: out };
    } catch (e) { return { err: 'exception' }; }
  }

  /* ---- FSAハンドル共有(IndexedDB rsp_handles — 設計書§4.3) ----
     picker.html(拡張origin)が保存した FileSystemDirectoryHandle を復元し、
     コアの dirHandle へ渡す(パートのフォルダ直書きに使用)。 */
  function handlesDb() {
    return new Promise(function (res, rej) {
      const rq = indexedDB.open('rsp_handles', 1);
      rq.onupgradeneeded = function () { try { rq.result.createObjectStore('handles'); } catch (e) {} };
      rq.onsuccess = function () { res(rq.result); };
      rq.onerror = function () { rej(rq.error); };
    });
  }
  async function idbGetHandle() {
    try {
      const db = await handlesDb();
      return await new Promise(function (res, rej) {
        const tx = db.transaction('handles', 'readonly');
        const rq = tx.objectStore('handles').get('recDir');
        rq.onsuccess = function () { res(rq.result || null); };
        rq.onerror = function () { rej(rq.error); };
      });
    } catch (e) { return null; }
  }
  async function restoreHandle() {
    try {
      const dh = await idbGetHandle();
      if (!dh) { STATE.handleOk = false; STATE.handleName = ''; return; }
      let perm = 'granted';
      try { perm = await dh.queryPermission({ mode: 'readwrite' }); } catch (e) {}
      if (perm === 'granted') {
        STATE.handleOk = true;
        STATE.handleName = dh.name || 'folder';
        if (STATE.recorder) {
          STATE.recorder.dirHandle = dh;
          STATE.recorder.dirLabel = STATE.handleName;
        }
      } else {
        STATE.handleOk = false;
        STATE.handleName = dh.name || 'folder';
        MSG.send({ type: 'perm.request', name: STATE.handleName });
      }
    } catch (e) { STATE.handleOk = false; }
  }


  /* ===== ここからuser.jsと同期された録画コア(diff 0検証対象) ===== */
