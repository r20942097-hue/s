import {redactMediaURL} from './url-policy.mjs';
import {detectMediaType} from './diagnostics.mjs';
/** Bounded memory registry for the sidebar's observed media candidates. No localStorage. */
export class MediaCandidateRegistry {
  #items=new Map();#max;
  constructor({maxCandidates=250}={}){
    if(!Number.isInteger(maxCandidates)||maxCandidates<1||maxCandidates>10000)throw Error('invalid maxCandidates');
    this.#max=maxCandidates;
  }
  observe({id,url,tabId=null,source='webRequest',contentType='',observedAt=Date.now(),session='unknown'}){
    if(typeof id!=='string'||id.length<1||id.length>256)throw Error('invalid id');
    const target=new URL(url);if(!['http:','https:'].includes(target.protocol))throw Error('unsupported media URL');
    const type=detectMediaType({url,contentType});
    const previous=this.#items.get(id);
    const record={id,url,tabId,source,type,session,observedAt,updates:(previous?.updates??0)+1,state:'observed'};
    this.#items.delete(id);this.#items.set(id,record);
    while(this.#items.size>this.#max)this.#items.delete(this.#items.keys().next().value);
    return {id,type,updated:Boolean(previous)};
  }
  markFailure(id,status){
    const item=this.#items.get(id);if(!item)return false;
    item.state=status===401||status===403?'auth-required':status===404||status===410?'possibly-expired':'http-error';
    return true;
  }
  /** UI receives only masked candidate entries. */
  list(){return [...this.#items.values()].map(({id,url,tabId,source,type,session,observedAt,updates,state})=>
    ({id,displayUrl:redactMediaURL(url),tabId,source,type,session,observedAt,updates,state}));}
  /** Privileged playback path, NEVER UI/logs. */
  getForPlayback(id){const item=this.#items.get(id);return item?{...item}:null;}
  clear(){this.#items.clear();}
}
