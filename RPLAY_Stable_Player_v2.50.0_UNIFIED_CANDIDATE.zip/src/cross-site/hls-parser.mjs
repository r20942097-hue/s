import {resolveMediaURI, redactMediaURL} from './url-policy.mjs';

/** Parse HLS attribute lists preserving quoted commas; no eval or HTML processing. */
export function parseAttributes(text='') {
  const result = {};
  let i=0;
  while (i < text.length) {
    while (text[i] === ',' || text[i] === ' ') i++;
    const start=i;
    while (i < text.length && text[i] !== '=' && text[i] !== ',') i++;
    if (text[i] !== '=') { if(i<text.length)i++; continue; }
    const key=text.slice(start,i).trim().toUpperCase();i++;
    let val='';
    if(text[i] === '"') {i++;while(i<text.length){if(text[i]==='"'){i++;break;}val+=text[i++];}}
    else {const at=i;while(i<text.length && text[i]!==',')i++;val=text.slice(at,i).trim();}
    if(key)result[key]=val;
    if(text[i]===',')i++;
  }
  return result;
}
const tagValue=line=>line.includes(':')?line.slice(line.indexOf(':')+1):'';
const safeInteger = (s,defaultValue=0) => /^\d+$/.test(String(s))?Number(s):defaultValue;
function parseRange(text,lastEnd=0){
  if(!text) return null;
  const match = /^(\d+)(?:@(\d+))?$/.exec(text);
  if(!match) throw new Error('Invalid HLS byte range');
  const length=Number(match[1]); const offset=match[2]===undefined?lastEnd:Number(match[2]);
  if(!Number.isSafeInteger(length) || !Number.isSafeInteger(offset)) throw new Error('Byte range overflow');
  return {length,offset,end:offset+length};
}
/** Pure parser, no network requests. For authorized, non-DRM media only. */
export function parseHLS(text, playlistURL, options={}) {
  if(typeof text!=='string' || text.length>10_000_000) throw new Error('HLS text too large/invalid');
  const lines=text.replace(/^\uFEFF/,'').split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
  if(lines[0]!=='#EXTM3U') throw new Error('Missing #EXTM3U');
  const result={kind:'media',playlistUrl:playlistURL,variants:[],renditions:[],segments:[],parts:[],
    errors:[],warnings:[],targetDuration:null,mediaSequence:0,discontinuitySequence:0,endList:false,
    serverControl:null,initMap:null,encrypted:false,drm:false};
  let seq=0,discont=0,nextDisc=false,nextGap=false,pendingInf=null,pendingVariant=null,pendingRange=null,
      activeMap=null,key=null,pdt=null,previousRangeEnd=0,previousRangeURI=null;
  const resolve=uri=>resolveMediaURI(playlistURL,uri,options);
  for(const line of lines.slice(1)) {
    if(line.startsWith('#EXT-X-STREAM-INF:')) {result.kind='master';pendingVariant=parseAttributes(tagValue(line));continue;}
    if(line.startsWith('#EXT-X-MEDIA:')) {result.kind='master';const a=parseAttributes(tagValue(line));result.renditions.push({...a,uri:a.URI?resolve(a.URI):null});continue;}
    if(line.startsWith('#EXT-X-MEDIA-SEQUENCE:')) {seq=safeInteger(tagValue(line));result.mediaSequence=seq;continue;}
    if(line.startsWith('#EXT-X-DISCONTINUITY-SEQUENCE:')) {discont=safeInteger(tagValue(line));result.discontinuitySequence=discont;continue;}
    if(line.startsWith('#EXT-X-TARGETDURATION:')) {result.targetDuration=Number(tagValue(line));continue;}
    if(line.startsWith('#EXT-X-SERVER-CONTROL:')) {result.serverControl=parseAttributes(tagValue(line));continue;}
    if(line.startsWith('#EXTINF:')) {pendingInf=Number(tagValue(line).split(',')[0]);continue;}
    if(line.startsWith('#EXT-X-PROGRAM-DATE-TIME:')) {pdt=tagValue(line);continue;}
    if(line.startsWith('#EXT-X-BYTERANGE:')) {pendingRange=tagValue(line);continue;}
    if(line.startsWith('#EXT-X-MAP:')) {const a=parseAttributes(tagValue(line)); if(a.URI)activeMap={url:resolve(a.URI),range:a.BYTERANGE||null};result.initMap=activeMap;continue;}
    if(line.startsWith('#EXT-X-KEY:')) {const a=parseAttributes(tagValue(line));key={method:a.METHOD||'UNKNOWN',keyformat:a.KEYFORMAT||'identity'};
      if(key.method!=='NONE')result.encrypted=true;
      if(key.keyformat!=='identity'||/SAMPLE-AES/i.test(key.method))result.drm=true;
      continue;}
    if(line==='#EXT-X-DISCONTINUITY') {nextDisc=true;discont++;continue;}
    if(line==='#EXT-X-GAP') {nextGap=true;continue;}
    if(line==='#EXT-X-ENDLIST') {result.endList=true;continue;}
    if(line.startsWith('#EXT-X-PART:')) {const a=parseAttributes(tagValue(line)); if(a.URI)result.parts.push({url:resolve(a.URI),duration:Number(a.DURATION)||0,independent:a.INDEPENDENT==='YES'});continue;}
    if(line.startsWith('#')) continue;
    const url=resolve(line);
    if(pendingVariant){result.variants.push({...pendingVariant,url});pendingVariant=null;continue;}
    const range=parseRange(pendingRange, previousRangeURI===url?previousRangeEnd:0);
    if(pendingRange && !pendingRange.includes('@') && previousRangeURI!==url) result.errors.push('Implicit BYTERANGE without same prior resource');
    const seg={url,sequence:seq++,discontinuitySequence:discont,discontinuity:nextDisc,gap:nextGap,
      duration:Number.isFinite(pendingInf)?pendingInf:null,programDateTime:pdt,map:activeMap,
      range,encrypted:Boolean(key && key.method!=='NONE'),keyformat:key?.keyformat||null};
    result.segments.push(seg);
    if(range){previousRangeURI=url;previousRangeEnd=range.end;}else{previousRangeURI=null;previousRangeEnd=0;}
    pendingInf=null;pendingRange=null;nextDisc=false;nextGap=false;pdt=null;
  }
  if(result.kind==='master' && !result.variants.length && !result.renditions.length) result.warnings.push('Master without playable variants');
  if(result.drm) result.warnings.push('Protected/sample-encrypted stream: diagnostics only');
  if(!result.endList && result.kind==='media' && !(result.targetDuration>0)) result.warnings.push('Missing target duration');
  return result;
}
export function publicHLSReport(result) {
  return {kind:result.kind,playlist:redactMediaURL(result.playlistUrl),variants:result.variants.length,
    segments:result.segments.length,parts:result.parts.length,live:!result.endList,
    encrypted:result.encrypted,drm:result.drm,errors:result.errors,warnings:result.warnings};
}
