import {redactMediaURL} from './url-policy.mjs';
/** Classifies page address only; does not claim to have a downloadable media URL. */
export function classifySite(input) {
  const u=new URL(input);const h=u.hostname.toLowerCase();const p=u.pathname;
  let site='generic',mode='unknown';
  if(h==='www.nicovideo.jp'||h==='nicovideo.jp'||h==='sp.nicovideo.jp'||h==='nico.ms'){
    site='niconico-video';mode=/^\/watch\//.test(p)?'vod-page':'page';
  } else if(h==='live.nicovideo.jp'||/^live\d+\.nicovideo\.jp$/.test(h)){
    site='niconico-live';mode=/^\/watch\//.test(p)?'live-page':'page';
  } else if(h==='www.youtube.com'||h==='youtube.com'||h==='m.youtube.com'||h==='youtu.be'){
    site='youtube';mode='page';
  } else if(h==='www.twitch.tv'||h==='twitch.tv'||h==='player.twitch.tv'){
    site='twitch';mode='page';
  }
  const type=detectMediaType({url:input});
  if(type!=='unknown')mode=type;
  return {site,mode,needsObservedMediaRequest:!['hls','dash','mp4'].includes(mode),url:redactMediaURL(input)};
}
export function detectMediaType({url='',contentType=''}) {
  const ct=contentType.toLowerCase().split(';')[0].trim();
  if(['application/vnd.apple.mpegurl','application/x-mpegurl','audio/mpegurl'].includes(ct))return 'hls';
  if(ct==='application/dash+xml')return 'dash';
  if(['video/mp4','audio/mp4'].includes(ct))return 'mp4';
  const path=new URL(url).pathname.toLowerCase();
  if(path.endsWith('.m3u8'))return 'hls';
  if(path.endsWith('.mpd'))return 'dash';
  if(path.endsWith('.mp4')||path.endsWith('.m4a'))return 'mp4';
  return 'unknown';
}
/** Diagnostics don't trigger retries automatically for auth failures. */
export function diagnoseResponse({status, contentType='', mediaType='', redirects=0, url=''}) {
  const notes=[];let state='ok';let retry=false;
  if(status===401||status===403){state='authorization-required';notes.push('Check own playback permissions/session/cookies without exporting secrets');}
  else if(status===404||status===410){state='missing-or-expired';notes.push('Observed URL may have expired; reacquire through permitted site playback');}
  else if(status===429){state='rate-limited';notes.push('Respect Retry-After, stop aggressive polling');}
  else if(status>=500&&status<600){state='temporary-server-error';retry=true;}
  else if(status<200||status>=300){state='http-error';}
  else if(redirects>8){state='redirect-loop';}
  const detected=url?detectMediaType({url,contentType}):'unknown';
  if(state==='ok'&&mediaType&&detected!==mediaType&&detected!=='unknown') notes.push('Unexpected media content type');
  return {state,retry,notes};
}
/** No origin-wide permission is silently granted by this function. */
export function siteRequirements(siteProfile) {
  if(siteProfile.site==='niconico-live')return {session:'site-playback-dependent',connection:'may-require-websocket-heartbeat',capture:'observed-authorized-HLS-only'};
  if(siteProfile.site==='niconico-video')return {session:'site-playback-dependent',connection:'vod',capture:'observed-authorized-media-only'};
  return {session:'vary-by-site',connection:'observed',capture:'observed-authorized-media-only'};
}
