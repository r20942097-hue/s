/** Build a diagnostic snapshot of actual observed request metadata, without cookies or secrets. */
const HEADERS=new Set(['referer','origin','user-agent']);
export function captureRequestMetadata(webRequestDetails) {
  const result={requestId:String(webRequestDetails.requestId??''),tabId:webRequestDetails.tabId??null,
    url:webRequestDetails.url,documentUrl:webRequestDetails.documentUrl??null,originUrl:webRequestDetails.originUrl??null,
    cookieStoreId:webRequestDetails.cookieStoreId??null,headers:{},authObserved:false};
  for(const h of(webRequestDetails.requestHeaders||[])){
    const name=String(h.name||'').toLowerCase();
    if(HEADERS.has(name)&&typeof h.value==='string')result.headers[name]=h.value;
    if(name==='cookie'||name==='authorization')result.authObserved=true;
  }
  return result;
}
export function makeFetchOptions(capture,{useBrowserCredentials=false}={}){
  // Browser decides Origin/User-Agent; do not try to forge forbidden headers.
  // Referer may be controlled through referrer/referrerPolicy when permitted.
  const options={method:'GET',credentials:useBrowserCredentials?'include':'omit'};
  if(capture?.headers?.referer){
    try{const u=new URL(capture.headers.referer);
      if(u.protocol==='https:'||u.protocol==='http:')options.referrer=u.href;
    }catch{/* invalid observed referer */}
  }
  return options;
}
/** Plain diagnostic report never exposes URLs, cookies, full referrers or User-Agent. */
export function publicCaptureReport(capture){return {
  sourceObserved:Boolean(capture?.url),refererObserved:Boolean(capture?.headers?.referer),
  originObserved:Boolean(capture?.headers?.origin),userAgentObserved:Boolean(capture?.headers?.['user-agent']),
  authObserved:Boolean(capture?.authObserved),containerObserved:Boolean(capture?.cookieStoreId)
};}
