/**
 * Normalized observer for NicoLive's documented-in-upstream stream/keepalive
 * events. Pure passive telemetry. Does not initiate socket, login or fetch.
 * Site protocol can change. Must use observed authorized browser session.
 */
import {redactMediaURL} from './url-policy.mjs';
export class NicoLiveSessionObserver {
  #state='idle';#streamUrl=null;#streamChanges=0;#lastHeartbeat=null;#disconnectedReason=null;
  accept(value,receivedAt=Date.now()){
    let msg;
    try{msg=typeof value==='string'?JSON.parse(value):value;}catch{return {event:'invalid-json'};}
    if(!msg||typeof msg!=='object'||typeof msg.type!=='string')return {event:'invalid-message'};
    if(msg.type==='stream'){
      const data=msg.data||{};
      if(data.protocol!=='hls'||typeof data.uri!=='string')return {event:'unsupported-stream'};
      let url;
      try{url=new URL(data.uri);if(!['https:','http:'].includes(url.protocol))return {event:'unsupported-stream'};}
      catch{return {event:'invalid-stream-url'};}
      if(this.#streamUrl!==data.uri)this.#streamChanges++;
      this.#streamUrl=data.uri;this.#state='stream-observed';this.#disconnectedReason=null;
      return {event:'stream-observed',url:redactMediaURL(data.uri),changed:this.#streamChanges>1};
    }
    if(msg.type==='ping'){this.#lastHeartbeat=receivedAt;return {event:'heartbeat-observed'};}
    if(msg.type==='disconnect'){this.#state='disconnected';this.#disconnectedReason=String(msg.data?.reason??'unknown').slice(0,128);return {event:'disconnected'};}
    return {event:'unrecognized-message'};
  }
  getStreamForAuthorizedPlayback(){return this.#state==='stream-observed'?this.#streamUrl:null;}
  diagnostics(){return {state:this.#state,streamObserved:Boolean(this.#streamUrl),streamChanges:this.#streamChanges,
    lastHeartbeat:this.#lastHeartbeat,disconnected:Boolean(this.#disconnectedReason)};}
}
