const SIGNED_NAMES = /^(?:token|sig|signature|expires?|expiry|exp|policy|key-pair-id|x-amz-(?:signature|credential|security-token|date|expires|algorithm|signedheaders)|x-goog-(?:signature|credential|date|expires|algorithm|signedheaders)|hdnts|hdnea|auth|jwt|session(?:_?id)?|access[_-]?key|access[_-]?token|e|hmac)$/i;
export function isSigned(urlString) {
  const u = new URL(urlString);
  return [...u.searchParams.keys()].some(k => SIGNED_NAMES.test(k));
}
function pairsWithRawEncoding(search) {
  return search.replace(/^\?/, '').split('&').filter(Boolean).map(part=>({part,key:decodeURIComponent(part.split('=')[0].replace(/\+/g, ' '))}));
}
/** Resolve a playlist child while preserving explicit child query bytes and their order.
 * Parent query inheritance is opt-in and appends only keys absent on the child.
 * Never rewrite URLs containing child signatures (including absolute URLs).
 */
export function resolveMediaURI(parentUrl, childRef, {inheritParentQuery=false} = {}) {
  const parent = new URL(parentUrl);
  const value = String(childRef).trim();
  const child = new URL(value, parent);
  if (!['https:', 'http:'].includes(child.protocol)) throw new TypeError('Unsupported media scheme');
  // Even with inheritance enabled, never forward a parent's credentials to a new origin.
  // Preserve absolute signed URLs as authored, including query ordering and escapes.
  if (/^https?:\/\//i.test(value) && isSigned(child.href)) return value;
  if (child.origin !== parent.origin || !inheritParentQuery || !parent.search || isSigned(child.href)) return child.href;
  const existing = new Set([...child.searchParams.keys()]);
  const raw = child.search.replace(/^\?/, '');
  const append = pairsWithRawEncoding(parent.search).filter(x => !existing.has(x.key)).map(x=>x.part);
  if (append.length) {
    child.search = [raw, ...append].filter(Boolean).join('&');
  }
  return child.href;
}
/** No auth URL or secret-bearing path is rendered in UI/logs. */
export function redactMediaURL(urlString) {
  try {
    const u = new URL(urlString);
    return `${u.origin}/…${u.search ? '?[query redacted]' : ''}`;
  } catch { return '[invalid URL]'; }
}
export function originOf(urlString) { return new URL(urlString).origin; }
