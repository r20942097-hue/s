/** Live segment dedup/gap accounting across rolling playlists. Does not download media. */
export class LiveSegmentLedger {
  #seen = new Set(); #entries=[]; #max; #last=null;
  constructor({maxEntries=30000}={}) {if(!Number.isSafeInteger(maxEntries)||maxEntries<2)throw Error('invalid maxEntries');this.#max=maxEntries;}
  update(playlist){
    if(playlist.kind!=='media')throw new TypeError('media playlist required');
    const fresh=[],gaps=[],duplicates=[];let discontinuities=0;
    for(const s of playlist.segments){
      const key=`${s.discontinuitySequence}:${s.sequence}`;
      if(this.#seen.has(key)){duplicates.push(key);continue;}
      this.#seen.add(key);this.#entries.push(key);
      if(s.gap){gaps.push({reason:'EXT-X-GAP',sequence:s.sequence});continue;}
      if(this.#last && this.#last.discontinuitySequence===s.discontinuitySequence && s.sequence>this.#last.sequence+1)
        gaps.push({reason:'missing-sequence',from:this.#last.sequence+1,to:s.sequence-1});
      if(s.discontinuity)discontinuities++;
      fresh.push(s);
      if(!this.#last || s.discontinuitySequence>this.#last.discontinuitySequence ||
          (s.discontinuitySequence===this.#last.discontinuitySequence && s.sequence>this.#last.sequence))
        this.#last={sequence:s.sequence,discontinuitySequence:s.discontinuitySequence};
    }
    while(this.#entries.length>this.#max){this.#seen.delete(this.#entries.shift());}
    return {fresh,gaps,duplicates:duplicates.length,discontinuities,endList:playlist.endList};
  }
}
/** RFC 8216 6.3.4: playlist reload after >= targetduration/2 when changed; >= targetduration when unchanged. */
export function suggestedReloadMs({targetDuration,endList}, changed) {
  if(endList)return null;
  if(!Number.isFinite(targetDuration)||targetDuration<=0)return null;
  return Math.ceil((changed?targetDuration/2:targetDuration)*1000);
}
