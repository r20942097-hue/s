# RPLAY v2.17.0 開発継続資料

## 原本と統合

基準は添付v2.16.0 UNIFIED。引継ぎZIP内の候補ZIPと添付UNIFIED ZIPは全エントリのバイトが一致しました。AUDIO_TIMELINE側のMP4時刻処理、PSI検査、先行検査、重複ハンドル検査、関連回帰試験を移植し、統合側のGOP/PESストリーミング・ヘッダ除去・AES/CLI/録画機能を維持しました。コード全体をAUDIO_TIMELINEで上書きしていません。

入力の正確なファイル名・バイト数・SHA-256は INPUTS_v2.17.0.json。ソースはsrc/、生成はscripts/build.py、検証はscripts/validate.py、再現可能な配布はscripts/package_release.py。

## 現行の構成

- src/mp4_convert_core.js: 共通ローリングPSI/CC検査器、GOP/PES chunker、全入力の先行検査と入力hash照合、共通のMP4時刻補正。
- src/mp4_convert.js/html: 表示順、保存API、検査中キャンセル、容量制限の表示。
- tests/test_mp4_convert.cjs: AUDIO_TIMELINE由来の7追加回帰を含む。
- tests/test_v2170_stream.cjs: 15件。実メディア一致、65MiBスライス、時刻折返し、上限拒否、異常系。
- tests/test_v2170_ui.cjs: 5件。DOM/APIモック。実ブラウザ試験ではない。
- CHANGES_v2.17.0.patch: 入力UNIFIED版からのsrc/scripts/tests/manifest差分。

## 次に進める工程

1. 利用者が実機確認を行う時点で、Windows・実OSピッカー・Chrome/Firefox拡張導入・録画から変換までの受入を実施。実機待ちだけを理由にローカル開発全体を停止しない。
2. 長時間/高ビットレート/2GiB付近のメディア、時刻リセット、音声サンプルレート差、特殊なPSI pointerとPMT改訂、破損PES/NAL/AAC等で反証を追加する。
3. 部分PES/アクセスユニットの厳密監査とWorker移譲を検討。任意の入力に対する無欠落を断言しない。
4. 録画中MP4直接出力や別音声合成は別工程。既存保存/復旧の契約を維持し、既存安定版と今回の候補版を混同しない。

実RPLAY・Windows・長時間運用・実ブラウザ操作は未検証につきCANDIDATE_NO_GOを維持します。今回の環境にはローカルChromium実行体がないため、旧版のChromium成功記録を今回の検証として転用していません。
