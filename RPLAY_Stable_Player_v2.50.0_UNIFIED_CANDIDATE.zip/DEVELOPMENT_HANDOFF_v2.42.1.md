# RPLAY v2.42.1 Hand-off

Baseline: v2.42.0 supplied user ZIP; new candidate extends **only** browser extensions. `src/cross_site_core.js` added; `src/media_catalog.js`, `src/background.js`, `src/dashboard.js`, `src/media_inspect.*`, `scripts/build.py`, `scripts/validate.py` updated. Both manifests 2.42.1; CLI and userscript remain 2.42.0. The previous v0.1.0 standalone kit is still separate and not automatically used as a networking engine.

NEXT: add real permission-scoped Firefox/Floorp extension installation testing, readonly site fixture traffic observation, session-aware stream identity, authorization-specific E2E tests, DASH MPD inspector, non-DRM authorized media download with disk-backed resumable queue and committed-segment receipts, mux/decode QA. Respect 429 rate limiting and DRM/access controls. Keep RPLAY recorder baseline unchanged until all streaming QA passed.
