# RPLAY開発統合台帳（2026-10-25 / v2.6.0）

## コンポーネント・責務の境界

| 系統 | 作業基準 | 所有責務 | 統合許可範囲 | 状態 |
|---|---|---|---|---|
| Stable Player | 2.6.0 CANDIDATE(統合) | 手動プレイヤー、手動ブラウザー録画、単体Python CLI | HLS状態契約、診断仕様 | NO_GO |
| Public Profile Auto Recorder | 1.22.0 CANDIDATE | 公開プロフィール監視・ブラウザ自動録画、最大12（既定2） | 通信予算・保存監査の独立契約 | NO_GO(今回変更なし・境界を文書化) |
| Universal Live Watcher | GitHub `r20942097-hue/faaff` | FFmpeg長時間録画、起動監視、SQLiteと復旧 | API/JSONイベント（コード合体しない） | 変更なし・HEAD未固定 |
| Media Download Tools | 系統独立 | 権限がある終了済みVOD、メディアQA | 検証メタデータとffprobe結果 | 変更なし |

## v2.6.0で実施した実装（開発計画v2.5.0の残課題を消化）

- **P1 fMP4複数MAP監査** — 完了: EXT-X-MAP宣言数・切替回数・
  DISCONTINUITY無し切替・poll間切替を数値証拠(fmp4Evidence)として記録。
  MAP切替のパート境界分割は従来からの挙動(初期化セグメント混在防止)を
  実測証拠化。両HLSコア鏡像・相互言語比較試験。
- **P1 分離音声PTS相関のqaudit統合** — 完了: qaudit_partがパート毎の
  実デコード時間(decodedDurationSec=durationTs×timebase)を測定し、
  映像/音声トラック集計のドリフト(avCorrelation)をledger/情報JSONへ記録。
  原点同期はmux後再生で最終確認(量の整合のみ主張)。
- **P2 LL-HLS検討(安全側仕様)** — 完了: EXT-X-SKIP(差分playlist)は
  専用コードHLS_LLHLS_SKIPで拒否。PRELOAD-HINT/SERVER-CONTROL等は
  取得せず計数証拠(llhlsEvidence)のみ。仕様をHLS_TRANSPORT_DESIGN.mdへ固定。
- **P2 Auto Recorderとの通信予算境界設計** — 完了(文書化):
  COMMUNICATION_BUDGET_BOUNDARY.md — 独立契約のまま境界・共有可不可・
  将来統合の合意ゲートを明文化。全体4通信枠の共通化は行わない。
- **P0 実受入準備** — 完了: ACCEPTANCE.md — 実Chrome/Firefox/Windows受入の
  手順(A1〜A10)・観察記録テンプレート(T1〜T7)・判定プロトコル。
  モック試験のPASSを受入に含めない。
- 230自動試験PASS(154 Node + 76 Python)・再ビルド5コア一致。
- userscript @versionの版ずれ(2.4.0のまま)を2.6.0へ修正。

## 次に着手する実装順（順序を固定）

| 優先 | 作業 | Done基準 | 注意点 |
|---|---|---|---|
| P0 | 実機受入の実施 | ACCEPTANCE.md A1〜A10を完走・観察記録T1〜T7を埋める | 外部環境を勝手にGOにしない |
| P1 | LL-HLS全件形式の実配信評価 | 実LL-HLS源で指標タグ計数と録画継続を観察 | SKIPが来ない前提の検証で満足しない |
| P2 | avCorrelationの実RPLAY較正 | 実配信の実測drift分布で許容値(2%/0.5s)を再評価 | 合成メディアだけの較正で固定しない |
| P2 | Auto Recorder側の証拠ブロック対応 | 独立契約のままfmp4Evidence等のスキーマ適合 | 予算カウンタの共有をしない |
| P3 | 長時間耐久・Windows・実RPLAY受入 | ACCEPTANCE.mdのA6〜A9 | GO判定は別承認 |

## 再開プロトコル

1. 進行中のWorkまたはLibraryに新しい成果物がある場合、まず読み取り専用で原本一覧・SHAを比較する。
2. 変更競合があればbranch/candidateを分ける。Stable版や現行配布物を上書きしない。
3. 保存処理・録画制御・HLSコアの生成元を編集し、生成物を手編集しない。
4. JS/Python/FFmpeg回帰、生成ファイル一致、ZIP内のハッシュ、クリーン展開再試験を終えて候補版を作る。
5. GitHub/Store配布や公開判定GOは別承認。実機未検証のまま完了扱いにしない。
