# HLS transport：v2.6.0実装仕様

独自実装の根拠は[RFC8216 §4.3.2.2 BYTERANGE](https://www.rfc-editor.org/rfc/rfc8216.html#section-4.3.2.2)、[§4.3.2.5 MAP](https://www.rfc-editor.org/rfc/rfc8216.html#section-4.3.2.5)、[RFC9110 Range/Content-Range](https://www.rfc-editor.org/rfc/rfc9110.html#name-range-requests)。仕様全体への適合を保証するものではありません。第三者実装のコードを新たに転記していません。

## v2.6.0: fMP4複数MAPの宣言証拠

`EXT-X-MAP`の宣言数・切替回数を数値証拠(`fmp4`)として記録する:

| 計数 | 意味 |
|---|---|
| mapDeclarations | playlist内のEXT-X-MAP宣言数(再宣言を含む) |
| mapSwitches | URIまたはrangeが変わった宣言切替(同一再宣言は0) |
| mapSwitchesWithoutDiscontinuity | セグメントを挟まずDISCONTINUITY無しで切替った回数(品質リスク指標) |
| crossPollMapSwitches | poll間で初期化セグメントが変わった回数(同一世代の継続中のみ) |
| crossPollMapSwitchesWithoutDiscontinuity | poll間切替のうちDISCONTINUITY境界を伴わない回数 |

- 切替の検出はplaylist内(宣言列)とpoll間(先頭segmentのMAP vs 前poll末尾のMAP)の
  両方で行う。両者は排他ではなく、切替が1回のpoll内で見えるか複数pollにまたがるかの差。
- **切替時の動作は従来どおりパート境界分割**(MAP・discontinuity・世代・形式の境界で
  close→新パートに初期化データを付与)。本証拠は「既に守っている保証」の実測化であり、
  動作変更ではない。DISCONTINUITY無し切替を**拒否しない** — 仕様上合法だが
  破損疑いの指標として計数する。
- 情報JSONでは`fmp4Evidence`(video/audio別)に出力。ブラウザー/CLI同一形式。

## v2.6.0: LL-HLS安全側仕様

LL-HLS系タグへの方針を固定する:

| タグ | 方針 |
|---|---|
| `EXT-X-SKIP` | **拒否(専用コードHLS_LLHLS_SKIP)**。差分playlistは鍵計算が成り立たない |
| `EXT-X-SKIP`以外のLL-HLS指標タグ(SERVER-CONTROL / PRELOAD-HINT / RENDITION-REPORT / PART / PART-INF) | 取得も再生もしない。計数証拠(llhls.indicatorTags)のみ |

- `PRELOAD-HINT`は最適化ヒントであり、正式な`EXTINF`付きsegment URIの到着を
  待つ(先走り取得しない — 二重取得と冪等性リスクを避ける)。
- ブロッキングリロード(`_HLS_msn`等)は送らない。通常poll間隔のまま待つ。
- LL-HLS配信でも差分playlistが無い(全件リスト形式)なら現行実装で録画継続する。
  その場合も指標タグ計数が記録され、事後分析でLL-HLS源と判別できる。
- v2.5.0の`HLS_EXPECT_FULL_MEDIA`(STREAM-INF)・`HLS_DELTA_UNSUPPORTED`(SKIP)
  を分離し、SKIPは`HLS_LLHLS_SKIP`に統一(両言語同一コード)。

## v2.9.0: 字幕レンディションの観測契約(取得しない)

master playlistの `#EXT-X-MEDIA:TYPE=SUBTITLES` は**観測と計数のみ**を行い、
字幕playlist・セグメントは一切取得しない(録画経路・通信量に影響しない安全側契約)。

- 解析対象: TYPE=SUBTITLES のみ(AUDIO/CLOSED-CAPTIONS等は対象外)。
  GROUP-IDは必須(EXT-X-MEDIA仕様・音声解析と同一契約)。TYPE比較は大文字化。
- 記録鍵(固定・未知属性は埋め込まない): groupId / name / language /
  assocLanguage / default / autoselect / forced / hasUri。
- **URI値は保持しない**(署名クエリ混入防止・URL秘匿契約)。取得可否のみhasUri。
- `#EXT-X-STREAM-INF` の `SUBTITLES="gid"` はvariant辞書のsubsGroupとして記録し、
  subtitleEvidence.variantsLinkedで結合数を計数する。
- subtitleEvidence はmaster playlist取得済み(非空)のときのみ出力する。
  未取得では証拠ブロックを出さない(虚偽のゼロを捏造しない)。
- policy=`observed_not_fetched` / provenance=`master_playlist_ext_x_media`。
- 字幕の取得・保存・muxは第二段階(A-09後続)で設計する。本契約は実機観察
  (ACCEPTANCE A15)で実在と言語の実測を可能にするためのもの。

## v2.6.0: 分離音声との実デコード時間相関(qaudit)

`--qaudit`(既定auto)停止時、映像トラックと音声レンディションの両方に実測証拠が
あるとき、パート毎の`decodedDurationSec`(durationTs×timebase)を集計して
`avCorrelation`を記録する:

- verdict: `pass`(|drift| ≤ max(映像時間×2%, 0.5s)) / `av_drift_suspect` /
  `insufficient`(両トラックの証拠が揃わない — 相関を主張しない)。
- PTS原点はトラック毎に独立しているため、**原点差ではなく「量」の整合**で判定する。
  同期の最終確認は2トラックmux後の再生で行う(ここでは量の整合のみ主張する)。
- 情報JSON `qualityAudit.avCorrelation` と ledger.json ルート `avCorrelation` に出力。
  宣言値(EXTINF/PDT)は入力に使わない(provenance=decoded)。

## v2.5.0: EXTINF検証モード

`parse(text, base, mode)` は第3引数で検証モードを受け取る。既定 `legacy` は
EXTINF未宣言セグメントを診断計数(missingExtinf)して受け入れる(v2.4.0互換)。
`rfc` はRFC 8216 4.3.2.3とおり未宣言を拒否する(HLS_EXTINF_REQUIRED)。
CLIは `--extinf-mode`、ブラウザーは「RFC 8216厳格」チェックボックス。

## v2.5.0: プレイリスト世代復旧

毎pollを分類してからキューを変更する。分類は数値証拠として
`generationRecovery` に記録される:

| 分類 | 条件 | 動作 |
|---|---|---|
| initial | そのcontextの初回 | 全件取得 |
| progress | 通常進行/変化なし | 新規のみ取得 |
| stale | sequence巻き戻し+全path既知 | 再取得しない・エポック不変 |
| reset | 巻き戻し+未知path | エポック進行・既知pathは重複排除 |
| rotation | 同一番号+全path未知 | エポック進行(黙殺しない) |
| context | playlist origin/path変更 | エポック進行・キャッシュリセット |

- URI鍵は「署名クエリを除いたURL+range」。署名更新で同一メディアを
  重複取得しない。segindex永続鍵も同規則(ディスクに秘密を残さない)。
- 不変pathフィルタは同一セッション内で恒常適用(progress含む)。
  キャッシュ上限4096件(超過分は判別不能として新規扱い)。
- stale時のfirst基準線は高水準を維持し、繰り返しstaleを検出し続ける。
- 推測で旧セグメントを削除しない。skipは「この不変データは録画済み」
  という実測に基づく重複排除のみ。
- ブラウザーのreset(owner, keepUris)は追跡再開(resume)のみ録画済みpath
  記録を保持し、明示的な新規開始(start)は解除する。

独自実装の根拠は[RFC8216 §4.3.2.2 BYTERANGE](https://www.rfc-editor.org/rfc/rfc8216.html#section-4.3.2.2)、[§4.3.2.5 MAP](https://www.rfc-editor.org/rfc/rfc8216.html#section-4.3.2.5)、[RFC9110 Range/Content-Range](https://www.rfc-editor.org/rfc/rfc9110.html#name-range-requests)。仕様全体への適合を保証するものではありません。第三者実装のコードを新たに転記していません。

## 記述子と処理順

playlistを丸ごと構文解析し、URI・byte range・MAP・sequence・discontinuity・GAPを持つ記述子へ変換します。暗号化・不正範囲・delta・危険なURLを検出したplaylistはキューへ一部だけ追加しません。URLはHTTP(S)、資格情報埋込みなし。相対URIはplaylist URLを基準に解決します。

同じリソースへの直前の範囲指定segmentがある場合だけ、media rangeの暗黙offsetを継承します。MAPの暗黙offsetは未対応として拒否します。MAPのIDは完全URI＋範囲です。MAPの署名だけが変わっても新しい初期化境界になります。

配信contextはplaylistのorigin＋pathname。先頭sequenceの後退またはcontext変更で世代を進めます。明示的な録画開始・復帰でも通信scopeをリセットします。segment重複排除は世代・discontinuity・sequence・範囲を使用し、署名クエリーの変更による同じsequenceの二重追加を防ぎます。既にキューへ入った失効署名URLの差替えは未実装です。

キュー追加前に4096件上限を検証。上限超過では未取得をseen扱いにしません。FIFOで1件ずつ取得し、失敗の再試行を先頭へ戻します。GAPを取得せず、見落としたウィンドウと合わせて欠落へ計上します。seenは30000を超えた際に12000へ縮小します。

## HTTPと検査

| 対象 | 本文上限 | 検証 |
|---|---:|---|
| 録画playlist | 2MiB | ストリーム読取り上限＋構文解析 |
| MAP | 8MiB | ftyp/moov、トップレベルbox境界 |
| segment | 32MiB | TS全パケット同期・188バイト整列、またはmoof/mdatとbox境界 |
| range | 32MiB以下 | 206、開始/終了offset、総サイズとの整合、本文長 |

範囲指定を200で無視する応答を全文から切り出して救済しません。指定のない206、圧縮された範囲応答も拒否。通常のブラウザー応答は解凍後本文に上限を適用し、圧縮Content-Lengthと比較しません。フレーム/サンプル内部や音声映像同期はこの構造検査の範囲外です。

ブラウザーではAbortControllerに加え、本文読取りを含むdeadline Promiseで処理を終了します。停止は通信scopeを閉鎖し、世代番号を変更。fetch完了時と非同期パートclose後に照合し、古い要求が新規パートを作れないようにします。停止後に閉鎖scopeを自動で再開しません。

Pythonはurllibのsocket timeoutと本文ループのmonotonic期限を使用。`read1`がブロックしている間はsocket timeoutまで待つため、厳密な1回分のwall-clock期限保証ではありません。Ctrl+CはHTTP contextを閉じます。トラックの書込み直前に状態を確認します。

上限は取得本文とキューの上限です。最終結合コピー、保存中Blob/OPFS、再生ライブラリを含むプロセス全体のメモリー上限ではありません。開始前の接続探査・既存VODダウンロード・全API通信をこのJS transportへ統合してはいません。

## パート境界と保存

MAP変更・discontinuity・配信世代・形式の境界で前パートcloseを待ち、新パートへ進みます。fMP4初期化データは各新規パートへ再度付与します。時間/サイズ自動分割後も同様です。音声も同じ経路です。fMP4は`.mp4`、TSは`.ts`、FLV代替は従来の`.flv`。

MAPはトラックあたり1件だけRAMキャッシュ。新しいMAPが成功したときに置換します。不正MAPやsegmentをappendへ渡しません。セグメントが大きい場合は通常のパート上限を1件分超過できます。CLIの自動muxはTS中心で、v2.5.0のPTS監査(--qaudit)がfMP4パートのデコード証拠を提供します。

## v2.5.0: 保存確定イベント契約

パート確定は多段階の実測として記録される(CLI: `<out>/RPLAY_<ID>_ledger.json`、
ブラウザー: partsLogのstages)。REQUESTED→FILE_WRITTEN→BROWSER_DONE→
HASHED→DECODED/CONTINUITYの順で、発生した段階のみ追記する。段階を
飛ばしてSUCCESS扱いにしない。ハッシュ計算不能環境ではHASHEDを付けない。
DECODED段階はCLI --qauditのffprobe実測のみ(ブラウザーは構造検査を
structureValidatedとして分離記録)。

保存完了・ダウンロード完了・失敗保持の契約は前版から継承します。`CONTROL_AND_HLS_DESIGN.md`は継承したv2.2操作権設計です。

## v2.4.0 fail-closed playlist grammar

Media playlistに`TARGETDURATION`がないと取得を開始しない。`I-FRAMES-ONLY`は録画全体の映像を提供しないため、通常プレイリストとして扱わない。`ENDLIST`以降のURIや2つ目の`ENDLIST`は不正な入力として拒否する。JS/Pythonの同一ポリシーを回帰試験で確認する。

## v2.4.0時刻診断と文法整合性

- `EXTINF`（宣言されるセグメント長）と `PROGRAM-DATE-TIME`（宣言される先頭サンプルの壁時計時刻）をブラウザー/Pythonで同じ数値記述子に格納。
- 2つの明示的なPDTアンカーの差を、その間にある`EXTINF`の和と比較する。差分が±500msを超えたらギャップ/重複の**疑い**を増やす。DISCONTINUITYを越えた直接比較は禁止。
- 未宣言EXTINFが途中にあれば `unmeasuredIntervals` に移し、未観測を正常扱いしない。RFC必須のEXTINFが未宣言でも既存互換モードでは拒否せず診断上で計数する。今後は標準準拠/レガシーモードを別設定に分離する。
- 診断値は数値と固定キーのみ、URL/トークン/秘密情報は保存しない。現時点で録画セグメントの取得・復旧・書き込み順序・音声mux・ファイル品質判定へは介入しない。
- `TARGETDURATION`がある場合、`EXTINF`を整数丸めしてTARGETDURATIONを超える記述子は拒否（RFC8216 §4.3.3.1）。重複global tagや不正日時/URI余白は入力不正として拒否。実際のデコーダPTS精査は別途FFprobe/FFmpeg検証が必要。

## v2.10.0: MPEG-TS連続追記とパート境界契約の精緻化

- **fMP4 (`EXT-X-MAP` あり)**: 初期化セグメント(`ftyp`+`moov`)の整合性を保つため、`epoch`・`discontinuity`・`map` のいずれかが変化した時点でパートを分割する。
- **MPEG-TS (`EXT-X-MAP` なし)**: 188バイトパケット単位でPAT/PMT/PCRを内包する自己同期ストリームであるため、既定(`splitOnDiscontinuity=false`)では `discontinuity` 変化でパートを分割せず、単一 `.ts` パートへシームレスに連続追記する(`discontinuityMergedCount` を計上)。一方、プレイリスト世代変化(`epoch` 増加: `reset`/`rotation`/`context`)では旧世代と新世代の混在を防ぐためパート境界分割を維持する。
