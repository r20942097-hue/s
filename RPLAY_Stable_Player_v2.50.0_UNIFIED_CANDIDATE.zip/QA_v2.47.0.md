# QA & Verification Report — RPLAY Stable Player v2.47.0 (`CANDIDATE_NO_GO`)

## 1. Test & Validation Summary
- **Version**: `2.47.0` (`CANDIDATE_NO_GO`)
- **Shared Core SHA-256**: `53ea2ddebf59b82a6aad5773710265e15e2506b9c5f475a3f33eda4739b7592a` (5 identical copies verified)
- **Node.js Tests**: `811 / 811 PASS` (including `tests/test_v2460_addon_synthesis.cjs`)
- **Python Tests**: `177 / 177 PASS` (including `tests/test_v2460_cli_addon_parity.py`)
- **Total Automated Tests**: `988 / 988 PASS`
- **Standalone E2E Scripts**:
  - `tests/check_request_context_http.py`: `PASS` (`exact_query_and_order: PASS`)
  - `tests/check_cdn404_decode.py`: `PASS` (`byte_identity: PASS`, `full_decode: PASS`, `audio_and_video: PASS`)
  - `tests/check_recording_during_scan.cjs`: `2 / 2 PASS` (Chrome + Firefox hosts)

## 2. Newly Synthesized Capabilities from Open-Source Addons & Downloaders (`v2.47.0`)
1. **Multi-Tool Command Generator (`N_m3u8DL-RE`, `yt-dlp`, `streamlink`) (`src/media_inspect_core.js`, `src/media_inspect.js`)**:
   - Extended `RspMediaInspect.commands(...)` to output literal shell-quoted `nm3u8dlRe` (`--live-real-time-merge --live-pipe-mux`), `ytdlp` (`--no-overwrites --hls-use-mpegts`), and `streamlink` commands alongside `ffmpeg` and `curl` for both PowerShell and POSIX `sh`, with zero auto-execution and strict command-injection resistance.
2. **Master Playlist Codec / FPS / HDR / Subtitle Metadata Enrichment (`src/media_catalog.js`)**:
   - Enriched `RspMediaCatalog.manifest()` rows with `frameRate`, `codecs`, `videoRange`, `subtitlesGroup`, `channels`, `language`, `defaultTrack`, `autoselect`, and `TYPE=SUBTITLES` rendition entries while preserving signed query inheritance.
3. **SCTE-35 / Ad-Insertion Marker Detection & `--ad-keyword` Filtering (`src/media_inspect_core.js`, `src/hls_transport.js`, `src/hls_transport.py`, `src/cli.py`)**:
   - Added `#EXT-X-CUE-OUT`, `#EXT-X-CUE-IN`, `#EXT-X-SCTE35`, `#EXT-OATCLS-SCTE35`, and `#EXT-X-DATERANGE:` marker counting (`scte35.indicatorTags` in JS/Python `hls_parse` and `adMarkers` in `inspectHls`).
   - Added `--ad-keyword <REGEX>` CLI segment filter and `adFilterEvidence` block in `_info.json`.
4. **Dashboard Candidate -> One-Click URL Recording Bridge (`src/dashboard.js`, `src/background.js`)**:
   - Added a `URL録画へセット` action button on HLS candidates in `dashboard.html` that securely resolves `media.candidate.get` within trusted extension pages (`dashboard.html` and `media_inspect.html`) while continuing to reject external web origins.
5. **Recovery UI TS Sync-Byte Verification Toggle (`src/recovery.html`, `src/recovery.js`)**:
   - Exposed `#verifyTs` checkbox in `recovery.html` and wired `{ verifyTs }` into `RspRecovery.recover(...)` to validate 188-byte packet alignment and `0x47` sync bytes during checkpoint recovery.
6. **Automatic Two-Track Lossless Join in `rplay_dl.py` (`--mux-audio-parts`) & `acceptance_report.py` Evidence Block Parity (`src/cli.py`, `scripts/acceptance_report.py`)**:
   - Added `--mux-audio-parts` to `rplay_dl.py` so multi-part recordings with separate audio renditions can invoke `rplay_join.py` with `mux_audio=True` on stop.
   - Updated `scripts/acceptance_report.py` `EVIDENCE_BLOCKS` to summarize `decryptionEvidence`, `continuityCounterEvidence`, `playlistParseGraceEvidence`, `segmentTransferRetryEvidence`, and `adFilterEvidence`.
