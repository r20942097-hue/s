# v2.50.0 状況 — 2026-10-27 JST

CANDIDATE_NO_GO / remote_published=false
完了:
- **segment_store Stage 3（明示取得の本番結線）**: `src/acquire_host.js`（新規）が Stage 2 エンジン `RspSegmentAcquire` を実環境へ束縛
  - 実 OPFS segment store（`rsp_seg/acquire` 名前空間・sha256 digest 検証 fail-closed・予算LRU）へ接続
  - 境界つき fetch アダプタ（プレイリスト2MiB/セグメント16MiB上限・credentials無し・タイムアウト・中断連動）
  - hls_transport の legacy パーサをエンジン契約へ適合させるアダプタ（sequence/gap/discontinuity/endList をZero変換漏れなく映射）
  - offscreen ホストに `acquire.start/continue/cancel/status/list/residue/discard/bootRestore` の8ケースを追加 — dashboard フラグ `segmentAcquire`（既定OFF）が OFF なら全て `ACQUIRE_DISABLED` で fail-closed
  - BG ルータは dashboard 送信者のみ受付。入口は `mediaCatalog` の観測候補のみ（HLS型ガード・失効は `CANDIDATE_EXPIRED`）で、URL はオフスクリーンへの引渡し一度きり（応答・台帳・証拠に残らない）
  - 再起動台帳は `rsp_seg/acquire_ledger/state.json`（segment sweep の対象外の別名前空間）— `bootRestore` → 候補再選択 → `continueFrom` で未取得分のみ続行
  - dashboard にトグル（既定OFF）・候補行の「候補を取得（明示）」ボタン・取得ジョブパネル（状態/取消/再開/残存確認/状態破棄・最大8件表示）を追加
  - 変換・エクスポートは本版でも未配線（既存録画系経路へ接続するまで保存は行わない）
- v2.49.0 の全機能（addon-max統合・`--join-files`・`hls_inspect_master`・広告除外キーワード・Stage 2 エンジン・policy表示拡張）を完全維持
- 自動テスト合計 **1101 / 1101 PASS**（Node.js 922件 + Python 179件）

維持: v2.49のaddon-max統合とStage 2エンジン、v2.48の録画エラー・MP4自動引渡し・preview診断、v2.47のクラッシュ復帰・CrossSite統合・fMP4正規化。
未完: 汎用ブラウザ内動画DLの変換・保存経路（Stage 3の取得までは完了・組立は既存変換経路への接続が次）、全サービスの認証再現。
未受入: 実ブラウザCookie条件/実RPLAY/実Nico/Windows/2GiB/長時間/native preview進行/mp4AutoHandoff ON時の実変換/segment_acquire の実ネットワーク取得（A-12）。

CANDIDATE_NO_GO 維持: 実サービス・実ブラウザの受入観察がUnit suiteの代用にならないため（紀律: fixtureとモックで契約を固定するに留める）。
