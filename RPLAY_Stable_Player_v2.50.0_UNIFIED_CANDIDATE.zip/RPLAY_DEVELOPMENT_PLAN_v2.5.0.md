# RPLAY開発統合台帳（2026-10-25 / v2.5.0）

## コンポーネント・責務の境界

| 系統 | 作業基準 | 所有責務 | 統合許可範囲 | 状態 |
|---|---|---|---|---|
| Stable Player | 2.5.0 CANDIDATE(統合) | 手動プレイヤー、手動ブラウザー録画、単体Python CLI | HLS状態契約、診断仕様 | NO_GO |
| Public Profile Auto Recorder | 1.22.0 CANDIDATE | 公開プロフィール監視・ブラウザ自動録画、最大12（既定2） | 通信予算・保存監査の独立契約 | NO_GO(今回変更なし) |
| Universal Live Watcher | GitHub `r20942097-hue/faaff` | FFmpeg長時間録画、起動監視、SQLiteと復旧 | API/JSONイベント（コード合体しない） | 変更なし・HEAD未固定 |
| Media Download Tools | 系統独立 | 権限がある終了済みVOD、メディアQA | 検証メタデータとffprobe結果 | 変更なし |

## v2.5.0で実施した統合と実装

- **2系統の統合**: TIMELINE v2.4.0(基盤・HLS時刻検証/ビルドシステム/183試験)
  に運用系統v2.4.0(stop-file/heartbeat/guards/segindex/webhook/標準入力
  /deploy/games)を移植。生成経路(src/)を編集し、生成物はbuild.pyで再生成。
- **P1 EXTINFモード分離** — 完了: legacy(診断計数)/rfc(拒否)の別試験。
  両言語+ブラウザーUI。旧入力互換は維持。
- **P1 プレイリスト世代復旧** — 完了: stale/reset/rotation/contextを
  数値証拠で判別。staleは重複排除(v2.4.0の二重録画潜在危険を修正)、
  rotationは黙殺修正。推測削除なし。E2E+相互言語比較。
- **P1 音声/映像品質検証** — 完了: --qaudit。ffprobeのPTS/DTS・
  タイムベース・サンプル単位・全編デコード。PDT上の一致だけでは
  合格にしない(証拠はprovenance:decoded)。
- **P1 保存確定イベント契約** — 完了: REQUESTED→FILE_WRITTEN→
  BROWSER_DONE→HASHED→DECODED/CONTINUITYをledger.jsonに実測時刻付き。
  段階を飛ばしてSUCCESS扱いにしない。ブラウザーコアも同一契約。
- **P2 取得キュー・通信枠** — 完了(CLI側): FIFO shadow実測
  (queueOrder)。URL秘密は非出力(情報JSON/ログ/webhook/segindex)。
  手動録画とAuto Recorderの全体枠は共通化していない(別契約のまま)。
- **P2 再起動・破損復旧** — 完了: segindex(署名なし鍵)の再起動
  重複防止。孤立partはsha256台帳で報告のみ。ENOSPC/EDQUOT区別。
  不明/不一致の原本を削除しない。
- 212自動試験PASS・再ビルド5コア一致・クリーン展開115ハッシュ一致。

## 次に着手する実装順（順序を固定）

| 優先 | 作業 | Done基準 | 注意点 |
|---|---|---|---|
| P0 | 実受入準備 | 実Chrome/Firefoxへの拡張ロード手順・観察記録の整備 | モック試験のPASSを受入に含めない |
| P1 | fMP4複数MAP/映像音声PTS相関の監査拡張 | 分離音声とのPTS相関をqauditへ統合 | PDT宣言とデコード実測を混同しない |
| P2 | LL-HLS検討 | EXT-X-SKIP/PRELOADの安全側仕様 | 現状は拒否のまま |
| P2 | Auto Recorderとの通信予算設計 | 独立契約のまま境界を文書化 | 全体4通信枠を勝手に共通化しない |
| P3 | 実Chrome/Firefox/Windows受入 | 拡張インストール、OPFS、DL、タブ消滅、長時間、実RPLAY | 外部環境を勝手にGOにしない |

## 再開プロトコル

1. 進行中のWorkまたはLibraryに新しい成果物がある場合、まず読み取り専用で原本一覧・SHAを比較する。
2. 変更競合があればbranch/candidateを分ける。Stable版や現行配布物を上書きしない。
3. 保存処理・録画制御・HLSコアの生成元を編集し、生成物を手編集しない。
4. JS/Python/FFmpeg回帰、生成ファイル一致、ZIP内のハッシュ、クリーン展開再試験を終えて候補版を作る。
5. GitHub/Store配布や公開判定GOは別承認。実機未検証のまま完了扱いにしない。
