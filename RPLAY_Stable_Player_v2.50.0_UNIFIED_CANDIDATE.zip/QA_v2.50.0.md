# QA v2.50.0 — segment_store Stage 3（明示取得の結線）

## 1. 検証サマリ
- 自動テスト: **1101 / 1101 PASS**（Node.js 922件 + Python 179件）
- 共有録画コア: `9f91f07dfa3d86e9a1c7240a9c14eca3bae71a82f9918959c4a6de712e2b1e60`（5コピー一致）
- rebuild byte identity: PASS（build.py 再実行で生成物バイト不変）
- パッケージ: 2132ファイル・4.44MB・CRC PASS・`SOURCE_MANIFEST.json` ハッシュ再生成
- ステータス: `CANDIDATE_NO_GO` / `remote_published=false`（実機受入 A-10/A-11/A-12/A-13 が未実施のため・紀律維持）

## 2. 新規試験 `tests/test_v2500_acquire_wiring.cjs`（24件全 PASS）
### 機能試験（実 RspSegmentStore + 実 HLS パーサ + モック fetch/OPFS）
1. 既定OFFで全8操作が `ACQUIRE_DISABLED`（fail-closed・start/continue/cancel/status/list/residue/discard/bootRestore）
2. 明示取得 happy path: 3セグメント取得 → `complete`・`.bin`+`.json` ペア3組が disk へ・status 照合
3. ゼロシークレット: status / residue に URL も secret キーワードも含まない（`token=SECRET` 付きURLでの取得後も）
4. プレイリスト 403/404 → `HTTP_403` / `HTTP_404` で失敗可視化
5. プレイリスト2MiB超・セグメント16MiB超 → fail-closed
6. セグメント500 → `HTTP_500`・**取得済み1件は disk に残る**（非破壊）
7. 取消（2本目の取得中にゲート制御）→ `cancelled`・残存1件以上・`listResidue` 列挙・`discard` はRAM状態のみ
8. 再起動復元: 同一OPFSで新ホスト → `bootRestore` が台帳から復元 → store メタからセグメントマップ再構築
9. 台帳なしの `bootRestore` → `NO_LEDGER`
10. 入力検証: 不正ID・http URL・junk URL・129文字ID → `INVALID_ID` / `INVALID_PLAYLIST_URL`
11. パーサアダプタ: MEDIA-SEQUENCE 5 起点・`#EXT-X-DISCONTINUITY` で boolean 遷移 + `discontinuitySequence` 1・`#EXT-X-GAP`・ENDLIST・相対URI解決
12. digest 改竄検知: 同一サイズで .bin を改竄 → 実 store の get が `SEGMENT_DIGEST_MISMATCH`（fail-closed）

### 結線契約（ソース表明）
13. offscreen_pre: `SET.segmentAcquire=false` 既定・applySettings 反映・dashboard 設定検証配列に追加
14. offscreen_post: 8ケース + `acquireHost()` 遅延束縛（フラグ再判定）+ `ACQUIRE_DISABLED` ガード + `RspSha256.Sha256` 束縛
15. background: `fromDashboard` ガード・フラグOFF拒否・`CANDIDATE_EXPIRED`・`mediaType!=='hls'` 拒否・`mediaCatalog.get` 入口・明示 `rsp-host` 中継・設定検証配列・policy `external.segmentAcquire`
16. dashboard_settings: flags 配列・normalize 既定 false・boolean 検証
17. dashboard: keys 配列・`acquire.start {candidateId}`・`acquire.list`・`acquire.bootRestore`・html トグル/パネル
18. preload 順序: Chrome offscreen.html / Firefox manifest とも `sha256.js → segment_store.js → segment_acquire.js → acquire_host.js → offscreen.js`・build/validate の派生コピー網羅

### BG ルータ vm 試験
19. フラグOFF → `ACQUIRE_DISABLED`（オフスクリーン中継なし）
20. 非 dashboard 送信者 → ルータ無視
21. 失効候補 → `CANDIDATE_EXPIRED`（中継なし）
22. 非 HLS 候補（mp4）→ `ACQUIRE_UNSUPPORTED_TYPE`（中継なし）
23. HLS 候補 → `acquire.start` を1回だけ中継（payload.id / playlistUrl / target='rsp-host'）
24. cancel の id 形状検証（`../x` 拒否）+ 正常中継 + list 中継

## 3. 回帰確認
- 既存 1077 テストは全て維持（版ピン更新分を含む）。`test_v2380_start_policy` の policy 期待値は `segmentAcquire:null` 追加のみ（構造不変）。
- 共有録画コアは版ピン文字列のみ変化（録画挙動への変更なし）。
- `rplay_dl.py` / `rplay_join.py` / 変換・復旧経路は v2.49.0 から無変更（派生コピーのバイト一致を validate が保証）。

## 4. 未検証（実機受入が必要）
- 実ブラウザでの候補観測 → 明示取得 → OPFS 書き込み → 再起動復元の一連（A-13）
- `mp4AutoHandoff` ON の実変換（A-11）
- 取得セグメントの組立・変換・保存（本版未配線 — 次版の実装範囲）
