/* Cross-site HLS diagnostics, URL signature policy, segment ledger, capture context, and passive session observer.
   No DRM bypass, no credential scraping, no secret logging. */
(function(root,factory){
 'use strict';
 const api=factory();
 if(typeof module!=='undefined'&&module.exports)module.exports=api;
 root.RspCrossSite=Object.assign({},root.RspCrossSite||{},api);
})(typeof globalThis==='undefined'?this:globalThis,function(){
 'use strict';
 const SIGNED_NAMES=/^(?:token|sig|signature|expires?|expiry|exp|policy|key-pair-id|x-amz-(?:signature|credential|security-token|date|expires|algorithm|signedheaders)|x-goog-(?:signature|credential|date|expires|algorithm|signedheaders)|hdnts|hdnea|auth|jwt|session(?:_?id)?|access[_-]?key|access[_-]?token|e|hmac|key2)$/i;
 function safeHttpUrl(urlString){
  if(typeof urlString!=='string'||!urlString||urlString.length>16384||/[\x00-\x20\x7f]/.test(urlString))throw new TypeError('Invalid or unsafe media URL');
  const u=new URL(urlString);
  if(!['https:','http:'].includes(u.protocol)||u.username||u.password)throw new TypeError('Unsupported media scheme');
  return u;
 }
 function isSigned(urlString){
  const u=safeHttpUrl(urlString);
  return [...u.searchParams.keys()].some(k=>SIGNED_NAMES.test(k));
 }
 function decodeKeySafe(rawKey){
  const plusReplaced=rawKey.replace(/\+/g,' ');
  try{return decodeURIComponent(plusReplaced);}catch{return plusReplaced;}
 }
 function pairsWithRawEncoding(search){
  return search.replace(/^\?/,'').split('&').filter(Boolean).map(part=>({part,key:decodeKeySafe(part.split('=')[0])}));
 }
 function resolveMediaURI(parentUrl,childRef,{inheritParentQuery=false}={}){
  const parent=safeHttpUrl(parentUrl);
  const value=String(childRef??'').trim();
  if(!value||/[\x00-\x20\x7f]/.test(value))throw new TypeError('Invalid child media reference');
  const child=new URL(value,parent);
  if(!['https:','http:'].includes(child.protocol)||child.username||child.password)throw new TypeError('Unsupported media scheme');
  if(/^https?:\/\//i.test(value)&&isSigned(child.href))return value;
  if(child.origin!==parent.origin||!inheritParentQuery||!parent.search||isSigned(child.href))return child.href;
  const existing=new Set([...child.searchParams.keys()]);
  const raw=child.search.replace(/^\?/,'');
  const append=pairsWithRawEncoding(parent.search).filter(x=>!existing.has(x.key)).map(x=>x.part);
  if(append.length)child.search=[raw,...append].filter(Boolean).join('&');
  return child.href;
 }
 function redactMediaURL(urlString){
  try{
   const u=safeHttpUrl(urlString);
   return `${u.origin}/…${u.search?'?[query redacted]':''}`;
  }catch{return '[invalid URL]';}
 }
 function originOf(urlString){return safeHttpUrl(urlString).origin;}

 function parseAttributes(text=''){
  const result={};
  let i=0;
  while(i<text.length){
   while(text[i]===','||text[i]===' ')i++;
   const start=i;
   while(i<text.length&&text[i]!=='='&&text[i]!==',')i++;
   if(text[i]!=='='){if(i<text.length)i++;continue;}
   const key=text.slice(start,i).trim().toUpperCase();i++;
   let val='';
   if(text[i]==='"'){i++;while(i<text.length){if(text[i]==='"'){i++;break;}val+=text[i++];}}
   else{const at=i;while(i<text.length&&text[i]!==',')i++;val=text.slice(at,i).trim();}
   if(key)result[key]=val;
   if(text[i]===',')i++;
  }
  return result;
 }
 const tagValue=line=>line.includes(':')?line.slice(line.indexOf(':')+1):'';
 const safeInteger=(s,defaultValue=0)=>/^\d+$/.test(String(s))?Number(s):defaultValue;
 function parseRange(text,lastEnd=0){
  if(!text)return null;
  const match=/^(\d+)(?:@(\d+))?$/.exec(text);
  if(!match)throw new Error('Invalid HLS byte range');
  const length=Number(match[1]);const offset=match[2]===undefined?lastEnd:Number(match[2]);
  if(!Number.isSafeInteger(length)||!Number.isSafeInteger(offset))throw new Error('Byte range overflow');
  return {length,offset,end:offset+length};
 }
 function parseHLS(text,playlistURL,options={}){
  if(typeof text!=='string'||text.length>10000000)throw new Error('HLS text too large/invalid');
  const lines=text.replace(/^\uFEFF/,'').split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
  if(lines[0]!=='#EXTM3U')throw new Error('Missing #EXTM3U');
  const result={kind:'media',playlistUrl:playlistURL,variants:[],renditions:[],segments:[],parts:[],
   errors:[],warnings:[],targetDuration:null,mediaSequence:0,discontinuitySequence:0,endList:false,
   serverControl:null,initMap:null,encrypted:false,drm:false};
  let seq=0,discont=0,nextDisc=false,nextGap=false,pendingInf=null,pendingVariant=null,pendingRange=null,
      activeMap=null,key=null,pdt=null,previousRangeEnd=0,previousRangeURI=null;
  const resolve=uri=>resolveMediaURI(playlistURL,uri,options);
  for(const line of lines.slice(1)){
   if(line.startsWith('#EXT-X-STREAM-INF:')){result.kind='master';pendingVariant=parseAttributes(tagValue(line));continue;}
   if(line.startsWith('#EXT-X-MEDIA:')){result.kind='master';const a=parseAttributes(tagValue(line));result.renditions.push({...a,uri:a.URI?resolve(a.URI):null});continue;}
   if(line.startsWith('#EXT-X-MEDIA-SEQUENCE:')){seq=safeInteger(tagValue(line));result.mediaSequence=seq;continue;}
   if(line.startsWith('#EXT-X-DISCONTINUITY-SEQUENCE:')){discont=safeInteger(tagValue(line));result.discontinuitySequence=discont;continue;}
   if(line.startsWith('#EXT-X-TARGETDURATION:')){result.targetDuration=Number(tagValue(line));continue;}
   if(line.startsWith('#EXT-X-SERVER-CONTROL:')){result.serverControl=parseAttributes(tagValue(line));continue;}
   if(line.startsWith('#EXTINF:')){pendingInf=Number(tagValue(line).split(',')[0]);continue;}
   if(line.startsWith('#EXT-X-PROGRAM-DATE-TIME:')){pdt=tagValue(line);continue;}
   if(line.startsWith('#EXT-X-BYTERANGE:')){pendingRange=tagValue(line);continue;}
   if(line.startsWith('#EXT-X-MAP:')){const a=parseAttributes(tagValue(line));if(a.URI)activeMap={url:resolve(a.URI),range:a.BYTERANGE||null};result.initMap=activeMap;continue;}
   if(line.startsWith('#EXT-X-KEY:')){const a=parseAttributes(tagValue(line));key={method:a.METHOD||'UNKNOWN',keyformat:a.KEYFORMAT||'identity'};
    if(key.method!=='NONE')result.encrypted=true;
    if(key.keyformat!=='identity'||/SAMPLE-AES/i.test(key.method))result.drm=true;
    continue;}
   if(line==='#EXT-X-DISCONTINUITY'){nextDisc=true;discont++;continue;}
   if(line==='#EXT-X-GAP'){nextGap=true;continue;}
   if(line==='#EXT-X-ENDLIST'){result.endList=true;continue;}
   if(line.startsWith('#EXT-X-PART:')){const a=parseAttributes(tagValue(line));if(a.URI)result.parts.push({url:resolve(a.URI),duration:Number(a.DURATION)||0,independent:a.INDEPENDENT==='YES'});continue;}
   if(line.startsWith('#'))continue;
   const url=resolve(line);
   if(pendingVariant){result.variants.push({...pendingVariant,url});pendingVariant=null;continue;}
   const range=parseRange(pendingRange,previousRangeURI===url?previousRangeEnd:0);
   if(pendingRange&&!pendingRange.includes('@')&&previousRangeURI!==url)result.errors.push('Implicit BYTERANGE without same prior resource');
   const seg={url,sequence:seq++,discontinuitySequence:discont,discontinuity:nextDisc,gap:nextGap,
    duration:Number.isFinite(pendingInf)?pendingInf:null,programDateTime:pdt,map:activeMap,
    range,encrypted:Boolean(key&&key.method!=='NONE'),keyformat:key?.keyformat||null};
   result.segments.push(seg);
   if(range){previousRangeURI=url;previousRangeEnd=range.end;}else{previousRangeURI=null;previousRangeEnd=0;}
   pendingInf=null;pendingRange=null;nextDisc=false;nextGap=false;pdt=null;
  }
  if(result.kind==='master'&&!result.variants.length&&!result.renditions.length)result.warnings.push('Master without playable variants');
  if(result.drm)result.warnings.push('Protected/sample-encrypted stream: diagnostics only');
  if(!result.endList&&result.kind==='media'&&!(result.targetDuration>0))result.warnings.push('Missing target duration');
  return result;
 }
 function publicHLSReport(result){
  return {kind:result.kind,playlist:redactMediaURL(result.playlistUrl),variants:result.variants.length,
   segments:result.segments.length,parts:result.parts.length,live:!result.endList,
   encrypted:result.encrypted,drm:result.drm,errors:result.errors,warnings:result.warnings};
 }

 function detectMediaType({url='',contentType=''}={}){
  const ct=String(contentType||'').toLowerCase().split(';')[0].trim();
  if(['application/vnd.apple.mpegurl','application/x-mpegurl','audio/mpegurl','audio/x-mpegurl'].includes(ct))return 'hls';
  if(ct==='application/dash+xml')return 'dash';
  if(['video/mp4','audio/mp4'].includes(ct))return 'mp4';
  if(ct==='video/mp2t')return 'ts';
  if(!url)return 'unknown';
  const path=safeHttpUrl(url).pathname.toLowerCase();
  if(path.endsWith('.m3u8'))return 'hls';
  if(path.endsWith('.mpd'))return 'dash';
  if(path.endsWith('.mp4')||path.endsWith('.m4a'))return 'mp4';
  if(path.endsWith('.ts')||path.endsWith('.m2ts'))return 'ts';
  return 'unknown';
 }
 function classifySite(input){
  const u=safeHttpUrl(input);const h=u.hostname.toLowerCase();const p=u.pathname;
  let site='generic',mode='unknown';
  if(h==='www.nicovideo.jp'||h==='nicovideo.jp'||h==='sp.nicovideo.jp'||h==='nico.ms'){
   site='niconico-video';mode=/^\/watch\//.test(p)?'vod-page':'page';
  }else if(h==='live.nicovideo.jp'||/^live\d+\.nicovideo\.jp$/.test(h)){
   site='niconico-live';mode=/^\/watch\//.test(p)?'live-page':'page';
  }else if(h==='www.youtube.com'||h==='youtube.com'||h==='m.youtube.com'||h==='youtu.be'){
   site='youtube';mode='page';
  }else if(h==='www.twitch.tv'||h==='twitch.tv'||h==='player.twitch.tv'){
   site='twitch';mode='page';
  }else if(h==='rplay.live'||h==='www.rplay.live'){
   site='rplay';mode=/^\/live(?:\/|$)/.test(p)||u.searchParams.has('creatorOid')?'live-page':(/^\/play\//.test(p)?'vod-page':'page');
  }
  const type=detectMediaType({url:input});
  if(type!=='unknown')mode=type;
  return {site,mode,needsObservedMediaRequest:!['hls','dash','mp4','ts'].includes(mode),url:redactMediaURL(input)};
 }
 function diagnoseResponse({status,contentType='',mediaType='',redirects=0,url=''}={}){
  const notes=[];let state='ok';let retry=false;
  if(status===401||status===403){state='authorization-required';notes.push('Check own playback permissions/session/cookies without exporting secrets');}
  else if(status===404||status===410){state='missing-or-expired';notes.push('Observed URL may have expired; reacquire through permitted site playback');}
  else if(status===429){state='rate-limited';notes.push('Respect Retry-After, stop aggressive polling');}
  else if(status>=500&&status<600){state='temporary-server-error';retry=true;}
  else if(status<200||status>=300){state='http-error';}
  else if(redirects>8){state='redirect-loop';}
  const detected=url?detectMediaType({url,contentType}):'unknown';
  if(state==='ok'&&mediaType&&detected!==mediaType&&detected!=='unknown')notes.push('Unexpected media content type');
  return {state,retry,notes};
 }
 function siteRequirements(siteProfile){
  if(siteProfile&&siteProfile.site==='niconico-live')return {session:'site-playback-dependent',connection:'may-require-websocket-heartbeat',capture:'observed-authorized-HLS-only'};
  if(siteProfile&&siteProfile.site==='niconico-video')return {session:'site-playback-dependent',connection:'vod',capture:'observed-authorized-media-only'};
  if(siteProfile&&siteProfile.site==='rplay')return {session:'site-playback-dependent',connection:siteProfile.mode==='live-page'?'live-hls':'vod-hls',capture:'observed-authorized-HLS-only'};
  return {session:'vary-by-site',connection:'observed',capture:'observed-authorized-media-only'};
 }

 class LiveSegmentLedger{
  #seen=new Set();#entries=[];#max;#last=null;
  constructor({maxEntries=30000}={}){if(!Number.isSafeInteger(maxEntries)||maxEntries<2)throw Error('invalid maxEntries');this.#max=maxEntries;}
  update(playlist){
   if(!playlist||playlist.kind!=='media')throw new TypeError('media playlist required');
   const fresh=[],gaps=[],duplicates=[];let discontinuities=0;
   for(const s of playlist.segments){
    const key=`${s.discontinuitySequence}:${s.sequence}`;
    if(this.#seen.has(key)){duplicates.push(key);continue;}
    this.#seen.add(key);this.#entries.push(key);
    if(s.gap){gaps.push({reason:'EXT-X-GAP',sequence:s.sequence});continue;}
    if(this.#last&&this.#last.discontinuitySequence===s.discontinuitySequence&&s.sequence>this.#last.sequence+1)
     gaps.push({reason:'missing-sequence',from:this.#last.sequence+1,to:s.sequence-1});
    if(s.discontinuity)discontinuities++;
    fresh.push(s);
    if(!this.#last||s.discontinuitySequence>this.#last.discontinuitySequence||
       (s.discontinuitySequence===this.#last.discontinuitySequence&&s.sequence>this.#last.sequence))
     this.#last={sequence:s.sequence,discontinuitySequence:s.discontinuitySequence};
   }
   while(this.#entries.length>this.#max){this.#seen.delete(this.#entries.shift());}
   return {fresh,gaps,duplicates:duplicates.length,discontinuities,endList:playlist.endList};
  }
 }
 function suggestedReloadMs({targetDuration,endList}={},changed=false){
  if(endList)return null;
  if(!Number.isFinite(targetDuration)||targetDuration<=0)return null;
  return Math.ceil((changed?targetDuration/2:targetDuration)*1000);
 }

 const HEADERS=new Set(['referer','origin','user-agent']);
 function captureRequestMetadata(webRequestDetails={}){
  const result={requestId:String(webRequestDetails.requestId??''),tabId:webRequestDetails.tabId??null,
   url:webRequestDetails.url,documentUrl:webRequestDetails.documentUrl??null,originUrl:webRequestDetails.originUrl??null,
   cookieStoreId:webRequestDetails.cookieStoreId??null,headers:{},authObserved:false};
  for(const h of (webRequestDetails.requestHeaders||[])){
   const name=String(h.name||'').toLowerCase();
   if(name==='cookie'||name==='authorization')result.authObserved=true;
   if(HEADERS.has(name)&&typeof h.value==='string'&&h.value.length<=16384&&!/[\x00-\x1f\x7f]/.test(h.value)){
    if(name==='referer'){try{safeHttpUrl(h.value);result.headers[name]=h.value;}catch{}}
    else if(name==='origin'){try{result.headers[name]=safeHttpUrl(h.value).origin;}catch{}}
    else if(h.value.length<=1024){result.headers[name]=h.value;}
   }
  }
  return result;
 }
 function makeFetchOptions(capture,{useBrowserCredentials=false}={}){
  const options={method:'GET',credentials:useBrowserCredentials?'include':'omit'};
  if(capture?.headers?.referer){
   try{const u=safeHttpUrl(capture.headers.referer);options.referrer=u.href;}catch{}
  }
  return options;
 }
 function publicCaptureReport(capture){
  return {
   sourceObserved:Boolean(capture?.url),refererObserved:Boolean(capture?.headers?.referer),
   originObserved:Boolean(capture?.headers?.origin),userAgentObserved:Boolean(capture?.headers?.['user-agent']),
   authObserved:Boolean(capture?.authObserved),containerObserved:Boolean(capture?.cookieStoreId)
  };
 }

 class NicoLiveSessionObserver{
  #state='idle';#streamUrl=null;#streamChanges=0;#lastHeartbeat=null;#disconnectedReason=null;
  accept(value,receivedAt=Date.now()){
   let msg;
   try{msg=typeof value==='string'?JSON.parse(value):value;}catch{return {event:'invalid-json'};}
   if(!msg||typeof msg!=='object'||typeof msg.type!=='string')return {event:'invalid-message'};
   if(msg.type==='stream'){
    const data=msg.data||{};
    if(data.protocol!=='hls'||typeof data.uri!=='string')return {event:'unsupported-stream'};
    try{safeHttpUrl(data.uri);}catch{return {event:'unsupported-stream'};}
    if(this.#streamUrl!==data.uri)this.#streamChanges++;
    this.#streamUrl=data.uri;this.#state='stream-observed';this.#disconnectedReason=null;
    return {event:'stream-observed',url:redactMediaURL(data.uri),changed:this.#streamChanges>1};
   }
   if(msg.type==='ping'){this.#lastHeartbeat=receivedAt;return {event:'heartbeat-observed'};}
   if(msg.type==='disconnect'){this.#state='disconnected';this.#disconnectedReason=String(msg.data?.reason??'unknown').slice(0,128);return {event:'disconnected'};}
   return {event:'unrecognized-message'};
  }
  getStreamForAuthorizedPlayback(){return this.#state==='stream-observed'?this.#streamUrl:null;}
  diagnostics(){return {state:this.#state,streamObserved:Boolean(this.#streamUrl),streamChanges:this.#streamChanges,
   lastHeartbeat:this.#lastHeartbeat,disconnected:Boolean(this.#disconnectedReason)};}
 }

 class MediaCandidateRegistry{
  #items=new Map();#max;
  constructor({maxCandidates=250}={}){
   if(!Number.isInteger(maxCandidates)||maxCandidates<1||maxCandidates>10000)throw Error('invalid maxCandidates');
   this.#max=maxCandidates;
  }
  observe({id,url,tabId=null,source='webRequest',contentType='',observedAt=Date.now(),session='unknown'}={}){
   if(typeof id!=='string'||id.length<1||id.length>256)throw Error('invalid id');
   safeHttpUrl(url);
   const type=detectMediaType({url,contentType});
   const previous=this.#items.get(id);
   const record={id,url,tabId,source,type,session,observedAt,updates:(previous?.updates??0)+1,state:'observed'};
   this.#items.delete(id);this.#items.set(id,record);
   while(this.#items.size>this.#max)this.#items.delete(this.#items.keys().next().value);
   return {id,type,updated:Boolean(previous)};
  }
  markFailure(id,status){
   const item=this.#items.get(id);if(!item)return false;
   item.state=status===401||status===403?'auth-required':status===404||status===410?'possibly-expired':'http-error';
   return true;
  }
  list(){return [...this.#items.values()].map(({id,url,tabId,source,type,session,observedAt,updates,state})=>
   ({id,displayUrl:redactMediaURL(url),tabId,source,type,session,observedAt,updates,state}));}
  getForPlayback(id){const item=this.#items.get(id);return item?{...item}:null;}
  clear(){this.#items.clear();}
 }

 return {
  isSigned,resolveMediaURI,redactMediaURL,originOf,
  parseAttributes,parseHLS,publicHLSReport,
  classifySite,detectMediaType,diagnoseResponse,siteRequirements,
  LiveSegmentLedger,suggestedReloadMs,
  captureRequestMetadata,makeFetchOptions,publicCaptureReport,
  NicoLiveSessionObserver,MediaCandidateRegistry
 };
});
