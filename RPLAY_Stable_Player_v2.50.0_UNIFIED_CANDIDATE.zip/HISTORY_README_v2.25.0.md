# RPLAY Stable Player v2.25.0 CANDIDATE

既存v2.24.0に、ページ/BG/音声のHLSクエリ継承設定接続と連続保存ボタンを追加。

1. Firefoxは rplay-stable-player-extension-firefox/manifest.json を一時拡張として読み込みます。
2. 録画設定の「連続保存（時間分割なし）」で時間分割を0へ設定します。既存録画中のBG設定には遡及せず、次回BG開始時に反映します。
3. 長時間保存は保存先/OPFSの利用を推奨。メモリ方式の容量上限・配信形式/初期化情報変更等の分割は維持します。全状況で1ファイルの保証ではありません。
4. 取得できない相対セグメントがplaylistのクエリを必要とする場合のみ「クエリ継承」をON（既定OFF）。同一originのみ継承、子URLの既存値を優先します。
5. 保存した連続TS/複数TSは「TSをMP4へ変換」で選択し、検査/変換後にMP4をダウンロードします。FirefoxのWorker/OPFS経路に対応。録画中のTSを直接MP4出力する追加機能ではありません。

詳細: INTEGRATION_v2.25.0.md / QA_v2.25.0.md。旧版資料/evidenceは履歴です。実RPLAY・Windows・2GiB/長時間・preview時刻進行は未合格、CANDIDATE_NO_GOを維持。
