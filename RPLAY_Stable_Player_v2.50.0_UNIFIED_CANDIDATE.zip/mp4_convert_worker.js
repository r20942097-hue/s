'use strict';
importScripts('libs/mux.min.js','sha256.js','mp4_codec_core.js','mp4_convert_core.js','mp4_browser_io.js');
let active=null;
self.onmessage=async({data:m})=>{
 if(!m||typeof m.id!=='string')return;
 const emit=(type,extra={})=>self.postMessage({id:m.id,type,...extra});
 if(m.type==='cancel'){if(active&&active.id===m.id)active.controller.abort();return;}
 if(active){emit('error',{error:'WORKER_BUSY'});return;}
 const task={id:m.id,controller:new AbortController()};active=task;
 let stage=null,finalized=false,lastProgressAt=0,lastPhase='';
 const progress=p=>{const now=Date.now();if(p.phase!==lastPhase||now-lastProgressAt>120){emit('progress',{progress:p});lastPhase=p.phase;lastProgressAt=now;}};
 try{
  if(m.type==='list'){emit('listed',await RspMp4BrowserIO.listStages(navigator.storage));return;}
  if(m.type==='recover'){const result=await RspMp4BrowserIO.recoverStage(navigator.storage,m.jobId,RspSha256,progress);emit('ready',result);return;}
  if(m.type==='discard'){await RspMp4BrowserIO.discardStage(navigator.storage,m.jobId);emit('discarded');return;}
  if(m.type!=='convert')throw Error('WORKER_COMMAND');
  if(!Array.isArray(m.inputs)||m.inputs.length<1||m.inputs.length>4096)throw Error('INPUT_COUNT');
  const inputs=m.fileInputs?RspMp4BrowserIO.fileInputs(m.inputs):m.inputs;
  let inputBytes=0;for(const input of inputs){const file=await input.getFile();inputBytes+=file.size;if(!Number.isSafeInteger(inputBytes))throw Error('TS_FILE_LIMIT');}
  let destination=m.destination;
  if(!destination){stage=await RspMp4BrowserIO.createStage({id:crypto.randomUUID().replace(/-/g,''),inputBytes,forceMemory:!!m.forceMemory});destination=stage.destination;}
  const result=await RspMp4Convert.convertStreamed({inputs,destination,muxjs,hashing:RspSha256,signal:task.controller.signal,onProgress:progress});
  if(stage){const r=await stage.finalize(result);finalized=true;emit('ready',{receipt:r,file:await destination.getFile(),result});}
  else emit('complete',{result});
 }catch(e){if(stage&&!finalized)try{await stage.destroy();}catch(ignore){}emit('error',{error:e&&e.name==='QuotaExceededError'?'STORAGE_QUOTA_EXCEEDED':e&&e.name==='SecurityError'?'STORAGE_ACCESS_DENIED':String(e&&e.message||'CONVERSION_FAILED').slice(0,180),stageRetained:finalized});}
 finally{if(active===task)active=null;}
};
