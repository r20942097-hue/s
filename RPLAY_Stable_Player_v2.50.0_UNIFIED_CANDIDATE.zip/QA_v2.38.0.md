# v2.38.0 QA

追加Node28件(test_v2380_meta.cjs 12件 / test_v2380_sched_bg.cjs 16件)。

名前metadata(test_v2380_meta.cjs): metaEntryの名前優先順位(name/nickname/userName)と正規URL構築(customUrl優先・不正なら入力slug)、多byte slugによるURL長上限(340)拒否、hostile形状のnull返却。resolveListのonMetaは名前URL解決分だけ収集(直接IDは対象外・batch失敗時は不発火・重複slugは解決IDへ集約)。sanitizeMetaは不正key/entryの読み飛ばし(派生データのためID一覧保存を妨げない)、URLはhttps://rplay.live/c/正規形のみ許容(それ以外はURL失効し名前だけ存続)、101key超過は全体拒否、未来時刻atは0へ正規化。commitは1回のstorage.setで両keyを書き込み、metaUpdateにDate.now刻印、保存済みmetaとの併合、未登録IDの刈り取り、baseline競合時は書き込み前拒否(0書き込み)。

BG予約巡回(test_v2380_sched_bg.cjs): offscreenハンドラ切り出しで実コード検証 — 未ログインはnologinで巡回0件、ID検証(不正形濾過・100件上限)、ガード順序(nologinはレート制限を刻印しないためjwt復活後の再試行は即成功)、60秒レート制限(force時10秒)とretryInMs報告、並走はbusy、例外後もbusy解除、行の時刻ソートとerror集計、2件巡回で400ms待機は1回だけ(最終件の後は待たない)。BG router: dashboard発schedules.scanは登録一覧を読み小文字正規化してhostへtarget:'rsp-host'で中継、空一覧はno-idsでhost不達、content page(page内予約確認は別実装)からは中継なし。registry.list応答はids+サニタイズ済meta(一覧内IDだけ)。配線ガード: offscreen dispatchのcase、dashboardのsendMessage/renderMeta、dashboard.htmlのschedScan/schedResult/schedRows/metaList要素、Firefox manifestがbackground.jsの前にcreator_registry.jsを読むこと。ページ側予約一覧はregistry.list応答のmetaから名前表示(meta欠損・不正形式・名前なしentryはID前置きへフォールバック)。

既存試験の版ピンは現行版へ回転: test_v2150/v2160_core.cjsとtest_v2150/v291_features.pyの完全一致ピン、test_v270_features.pyの範囲ピン(36|37|38)、v291の列挙ピンへ38.0追加、test_v291_core.cjsのlast-2+current表明(36|37|38)。 acceptance_report.py/part_io.js/player.user.jsのtool表記とmanifest/build/validate/package_releaseの版スタンプを更新。

2026-10-27: 全回帰708件PASS(Node543/Python165)。Nodeは+28件(旧515)。Pythonは165件で変動なし。validate.py --output-dir evidence/v238-current合格(5実行物同一コアsha256・再構築byte同一・派生copy一致・package hash 400件一致)。

本環境の限定: 実ブラウザー受入(Firefox/Floorpのtemporary install、実RPLAYでのgetuser応答に含まれる名前の実key検証、BG録画中の外部予約閲覧の実機確認、native Web Locks)は未実施です。名前の取得元key(name/nickname/userName)は公式配信者確認APIの実応答形状に依存するため、実RPLAYでの受入時に応答keyを確認してください(いずれも無ければ名前なしでURLだけ記録され、失敗にはなりません)。実RPLAY/Windows/2GiB/長時間も未確認です。

試験対象のruntime・test本体・buildを最終成果物とbyte比較済み。ZIP CRC・全ファイルhash台帳を確認。
