(function(root,factory){const api=factory(typeof module==='object'&&module.exports?require('./mp4_codec_core.js'):root.RspMp4Codecs);if(typeof module==='object'&&module.exports)module.exports=api;else root.RspMp4Convert=api;})(globalThis,function(codecs){
 'use strict';
 const MAX_INPUT=64*1048576;
 const MAX_STREAM_INPUT=2048*1048576;
 const MAX_CHUNK_BYTES=32*1048576;
 function fail(s){throw Error(s);}
 // PSI sections may span packets. A section is trusted only after its MPEG-2 CRC has passed.
 function psiCrc(data){
  let crc=0xffffffff;
  for(const byte of data){crc^=byte<<24;for(let i=0;i<8;i++)crc=((crc&0x80000000)?((crc<<1)^0x04c11db7):(crc<<1))>>>0;}
  return crc>>>0;
 }
 // Bounded PES header/length and ADTS framing audit. This is not an H.264 decoder.
 // Annex-B framing and NAL header sanity only; slice/RBSP syntax is not decoded.
 function createNalAuditor(){
  let zeros=0,needHeader=false,seen=false,payload=0,lastType=0,nalUnits=0,capture=null;const parameterSets={sps:null,pps:null};
  function endNal(){if(seen&&payload-zeros<1&&lastType!==10&&lastType!==11)fail('TS_H264_NAL_EMPTY');if(capture){const data=capture.slice(0,capture.length-zeros);if(data.length>4096)fail('TS_AVC_PARAMETER_SET_LIMIT');const value=data.map(b=>b.toString(16).padStart(2,'0')).join(''),key=lastType===7?'sps':'pps';if(parameterSets[key]&&parameterSets[key]!==value)fail('TS_AVC_PARAMETER_SET_CHANGE');parameterSets[key]=value;}}
  function push(data){
   for(const byte of data){
    if(needHeader){
     const type=byte&31;if((byte&0x80)||!type||type>23)fail('TS_H264_NAL_HEADER');
     needHeader=false;seen=true;lastType=type;payload=0;zeros=0;capture=type===7||type===8?[byte]:null;nalUnits++;continue;
    }
    if(byte===1&&zeros>=2){endNal();needHeader=true;zeros=0;continue;}
    if(!seen&&byte!==0)fail('TS_H264_ANNEXB_REQUIRED');
    if(seen)payload++;if(capture){if(capture.length>=4100)fail('TS_AVC_PARAMETER_SET_LIMIT');capture.push(byte);}zeros=byte===0?zeros+1:0;
   }
  }
  function finish(){if(needHeader)fail('TS_H264_HEADER_TRUNCATED');if(!seen)fail('TS_H264_ANNEXB_REQUIRED');endNal();return nalUnits;}
  return {push,finish,get parameterSets(){return {...parameterSets};}};
 }
 function createPesAuditor(hashing){
  const sampleHash=hashing?new hashing.Sha256():null;
  const streams=new Map();let config=null;
  const evidence={videoPes:0,audioPes:0,aacFrames:0,aacPayloadBytes:0,policy:'strict_pes_adts',h264Decoded:false};
  function configure(entries){if(!streams.size)for(const [type,pid] of entries)streams.set(pid,{type,current:null,nal:type===0x1b?createNalAuditor():null});}
  function finishPes(state,final=false){
   const p=state.current;if(!p)return;
   if(p.headerSize===null||p.header.length<p.headerSize)fail('TS_PES_HEADER_TRUNCATED');
   if(p.declared!==null&&p.total!==p.declared)fail('TS_PES_TRUNCATED');
   if(state.type===15&&(p.aacHeader.length||p.aacRemaining))fail(final?'TS_AAC_TRUNCATED':'TS_AAC_PES_BOUNDARY_UNSUPPORTED');
   if(!p.payloadBytes)fail('TS_PES_EMPTY');
  }
  function adts(p,data){
   let at=0;
   while(at<data.length){
    if(p.aacRemaining){const n=Math.min(p.aacRemaining,data.length-at),skip=Math.min(p.aacCrcRemaining,n);p.aacCrcRemaining-=skip;if(sampleHash&&n>skip)sampleHash.update(data.subarray(at+skip,at+n));p.aacRemaining-=n;at+=n;evidence.aacPayloadBytes+=n;if(!p.aacRemaining)evidence.aacFrames++;continue;}
    while(p.aacHeader.length<7&&at<data.length)p.aacHeader.push(data[at++]);
    if(p.aacHeader.length<7)break;
    const h=p.aacHeader;
    if(h[0]!==255||(h[1]&0xf6)!==0xf0)fail('TS_AAC_SYNC');
    const sample=(h[2]>>2)&15,channels=((h[2]&1)<<2)|(h[3]>>6),profile=(h[2]>>6)&3;
    if(sample>12||!channels)fail('TS_AAC_CONFIG_UNSUPPORTED');
    if(h[6]&3)fail('TS_AAC_MULTIBLOCK_UNSUPPORTED');
    const next=[profile,sample,channels].join(':');if(config&&next!==config)fail('TS_AAC_CONFIG_CHANGE');config=next;
    const size=((h[3]&3)<<11)|(h[4]<<3)|(h[5]>>5),headerSize=(h[1]&1)?7:9;
    if(size<=headerSize)fail('TS_AAC_FRAME_LENGTH');
    // CRC bytes are counted as part of the frame; CRC contents are not verified.
    p.aacRemaining=size-7;p.aacCrcRemaining=headerSize-7;
    if(sampleHash){const prefix=new Uint8Array(4);new DataView(prefix.buffer).setUint32(0,size-headerSize);sampleHash.update(prefix);}
    evidence.aacPayloadBytes+=7;p.aacHeader=[];
   }
  }
  function parseHeader(p,type){
   const h=p.header;
   if(h.length===6){
    if(h[0]||h[1]||h[2]!==1||(type===15?(h[3]<0xc0||h[3]>0xdf):(h[3]<0xe0||h[3]>0xef)))fail('TS_PES_PREFIX');
    const length=(h[4]<<8)|h[5];p.declared=length?length+6:null;
    if(type===15&&!length)fail('TS_AUDIO_PES_LENGTH');
   }
   if(h.length===9){
    if((h[6]&0xc0)!==0x80||(h[6]&0x30))fail('TS_PES_FLAGS');
    const flags=(h[7]>>6)&3;if(flags===1)fail('TS_PES_TIMESTAMP');
    const min=flags===3?10:flags===2?5:0;
    if(h[8]<min)fail('TS_PES_HEADER_LENGTH');
    p.headerSize=9+h[8];if(p.declared!==null&&p.headerSize>=p.declared)fail('TS_PES_HEADER_LENGTH');
   }
   if(p.headerSize!==null&&h.length===p.headerSize){
    const flags=(h[7]>>6)&3;
    for(const [at,prefix] of flags===3?[[9,3],[14,1]]:flags===2?[[9,2]]:[]){
     if((h[at]>>4)!==prefix||!(h[at]&1)||!(h[at+2]&1)||!(h[at+4]&1))fail('TS_PES_TIMESTAMP');
    }
   }
  }
  function push(pid,pusi,data){
   const state=streams.get(pid);if(!state)return;
   if(pusi){
    finishPes(state);state.current={header:[],headerSize:null,declared:null,total:0,payloadBytes:0,aacHeader:[],aacRemaining:0,aacCrcRemaining:0};
    if(state.type===15)evidence.audioPes++;else evidence.videoPes++;
   }
   const p=state.current;if(!p)fail('TS_PES_START_REQUIRED');
   let at=0;
   while(at<data.length&&(p.headerSize===null||p.header.length<p.headerSize)){p.header.push(data[at++]);p.total++;parseHeader(p,state.type);}
   if(at<data.length){
    const payload=data.subarray(at);p.total+=payload.length;p.payloadBytes+=payload.length;
    if(p.declared!==null&&p.total>p.declared)fail('TS_PES_LENGTH_OVERFLOW');
    if(state.type===15)adts(p,payload);else state.nal.push(payload);
   }
  }
  function finish(){
   let nalUnits=0;for(const state of streams.values()){finishPes(state,true);if(state.nal)nalUnits+=state.nal.finish();}
   if(!evidence.videoPes)fail('TS_VIDEO_PES_REQUIRED');
   if([...streams.values()].some(s=>s.type===15)&&(!evidence.audioPes||!evidence.aacFrames))fail('TS_AUDIO_PES_REQUIRED');
   return {...evidence,aacConfig:config,nalUnits,aacSampleSha256:sampleHash?sampleHash.digest():null,avcParameterSets:[...streams.values()].find(s=>s.nal).nal.parameterSets};
  }
  return {configure,push,finish};
 }
 function createTsValidator({media=false,hashing=null,allowDiscontinuity=false}={}){
  const pes=media?createPesAuditor(hashing):null;
  let pmt=null,plan=null,program=null;const cc=new Map(),pending=new Map(),psiPackets=new Map();
  function processSection(pid,section){
   if(psiCrc(section)!==0)fail('TS_PSI_CRC');
   const length=section.length,table=section[0];
   if((section[1]&0xf0)!==0xb0||(section[5]&1)===0||section[6]!==0||section[7]!==0)fail('TS_PSI_HEADER');
   if(pid===0){
    if(table!==0||length<12)fail('TS_PAT');
    if((length-12)%4!==0)fail('TS_PAT');
    const programs=[];
    for(let p=8;p<length-4;p+=4){const number=(section[p]<<8)|section[p+1];if(number)programs.push({number,pid:((section[p+2]&31)<<8)|section[p+3]});}
    if(programs.length!==1||programs[0].pid===0||programs[0].pid===8191)fail('TS_MULTI_PROGRAM');
    if(pmt!==null&&(pmt!==programs[0].pid||program!==programs[0].number))fail('TS_PROGRAM_CHANGE');
    pmt=programs[0].pid;program=programs[0].number;
   }else{
    if(table!==2||length<16||program!==((section[3]<<8)|section[4]))fail('TS_PMT');
    const streams=[],end=length-4,descriptors=((section[10]&15)<<8)|section[11];let p=12+descriptors;
    if(p>end)fail('TS_PMT');
    while(p<end){
     if(p+5>end)fail('TS_PMT');
     const type=section[p],id=((section[p+1]&31)<<8)|section[p+2],sz=((section[p+3]&15)<<8)|section[p+4];
     if(type!==0x1b&&type!==0x0f&&type!==0x15)fail('TS_CODEC_UNSUPPORTED');
     if(type!==0x15)streams.push([type,id]);p+=5+sz;if(p>end)fail('TS_PMT');
    }
    if(streams.filter(s=>s[0]===0x1b).length!==1||streams.filter(s=>s[0]===0x0f).length>1)fail('TS_TRACKS_UNSUPPORTED');
    if(new Set(streams.map(s=>s[1])).size!==streams.length)fail('TS_TRACKS_UNSUPPORTED');
    if(streams.some(s=>s[1]===0||s[1]===pmt||s[1]===8191))fail('TS_TRACKS_UNSUPPORTED');
    if(pes&&!plan&&streams.some(s=>cc.has(s[1])))fail('TS_MEDIA_BEFORE_PMT');
    if(pes)pes.configure(streams);
    const next=JSON.stringify(streams.sort((a,b)=>a[0]-b[0]));
    if(plan&&next!==plan.signature)fail('TS_TRACK_CHANGE');plan={signature:next,audio:streams.some(s=>s[0]===0x0f),pmtPid:pmt,psiPackets:[...(psiPackets.get(0)||[]),...(psiPackets.get(pmt)||[])]};
   }
  }
  function addSectionBytes(pid,bytes){
   let buf=pending.get(pid)||new Uint8Array(0),pos=0;
   while(pos<bytes.length){
    if(!buf.length&&bytes[pos]===0xff){for(let i=pos;i<bytes.length;i++)if(bytes[i]!==0xff)fail('TS_PSI_STUFFING');break;}
    if(buf.length<3){const n=Math.min(3-buf.length,bytes.length-pos);const next=new Uint8Array(buf.length+n);next.set(buf);next.set(bytes.subarray(pos,pos+n),buf.length);buf=next;pos+=n;if(buf.length<3)break;}
    const sectionLength=((buf[1]&15)<<8)|buf[2],total=3+sectionLength;
    if(sectionLength>1021||total<12)fail('TS_PSI_LENGTH');
    const n=Math.min(total-buf.length,bytes.length-pos);
    if(n){const next=new Uint8Array(buf.length+n);next.set(buf);next.set(bytes.subarray(pos,pos+n),buf.length);buf=next;pos+=n;}
    if(buf.length===total){processSection(pid,buf);buf=new Uint8Array(0);}
   }
   pending.set(pid,buf);
  }
  function push(data){
  if(!data.length||data.length%188)fail('TS_ALIGNMENT');
  for(let at=0;at<data.length;at+=188){
   if(data[at]!==0x47||(data[at+1]&0x80)||(data[at+3]&0xc0))fail('TS_INVALID_OR_SCRAMBLED');
   const pid=((data[at+1]&31)<<8)|data[at+2],control=(data[at+3]>>4)&3;
   if(!control)fail('TS_ADAPTATION');let payload=at+4;
   let disc=false;
   if(control&2){const len=data[payload];if(payload+1+len>at+188)fail('TS_ADAPTATION');if(len&&(data[payload+1]&0x80)){if(!allowDiscontinuity)fail('TS_DISCONTINUITY');disc=true;}payload+=1+len;}
   if(!(control&1)||pid===8191)continue;
   const counter=data[at+3]&15;if(!disc&&cc.has(pid)&&counter!==((cc.get(pid)+1)&15))fail('TS_PACKET_GAP');cc.set(pid,counter);
   if(pes&&plan){if(payload>=at+188)fail('TS_PES_EMPTY_PACKET');pes.push(pid,!!(data[at+1]&0x40),data.subarray(payload,at+188));}
   if(pid!==0&&pid!==pmt)continue;
   if(payload>=at+188)fail('TS_PSI');
   if(data[at+1]&0x40)psiPackets.set(pid,[]);
   const packets=psiPackets.get(pid);
   if(packets){if(packets.length>=8)fail('TS_PSI_LENGTH');packets.push(new Uint8Array(data.subarray(at,at+188)));}
   const fragment=data.subarray(payload,at+188);
   if(data[at+1]&0x40){
    const pointer=fragment[0];if(1+pointer>fragment.length)fail('TS_PSI_POINTER');
    const prefix=fragment.subarray(1,1+pointer),buf=pending.get(pid);
    if(buf&&buf.length){if(!prefix.length)fail('TS_PSI_INCOMPLETE');addSectionBytes(pid,prefix);if(pending.get(pid).length)fail('TS_PSI_INCOMPLETE');}
    else if(prefix.length&&prefix.some(x=>x!==0xff))fail('TS_PSI_POINTER');
    addSectionBytes(pid,fragment.subarray(1+pointer));
   }else if((pending.get(pid)||[]).length)addSectionBytes(pid,fragment);
  }
  }
  function finish(){
   if(!plan)fail('TS_PMT_REQUIRED');
   for(const [pid,buf] of pending)if(buf.length)fail('TS_PSI_INCOMPLETE');
   if(pes)plan.mediaIntegrityEvidence=pes.finish();
   return plan;
  }
  return {push,finish,get plan(){return plan;}};
 }
 function tsPlan(data,options){const v=createTsValidator(options);v.push(data);return v.finish();}
 function stripDisguisedTs(bytes){
  if(!bytes||!bytes.length)return {bytes,strippedBytes:0,magic:null};
  let magic=null;
  if(bytes.length>=8&&bytes[0]===0x89&&bytes[1]===0x50&&bytes[2]===0x4E&&bytes[3]===0x47)magic='png';
  else if(bytes.length>=6&&bytes[0]===0x47&&bytes[1]===0x49&&bytes[2]===0x46&&bytes[3]===0x38&&(bytes[4]===0x37||bytes[4]===0x39)&&bytes[5]===0x61)magic='gif';
  else if(bytes.length>=2&&bytes[0]===0x42&&bytes[1]===0x4D)magic='bmp';
  else if(bytes.length>=3&&bytes[0]===0xFF&&bytes[1]===0xD8&&bytes[2]===0xFF)magic='jpeg';
  else if(bytes.length>=12&&bytes[0]===0x52&&bytes[1]===0x49&&bytes[2]===0x46&&bytes[3]===0x46&&bytes[8]===0x57&&bytes[9]===0x45&&bytes[10]===0x42&&bytes[11]===0x50)magic='webp';
  else if(bytes.length>=3&&bytes[0]===0x49&&bytes[1]===0x44&&bytes[2]===0x33)magic='id3';
  if(!magic)return {bytes,strippedBytes:0,magic:null};
  const maxScan=Math.min(bytes.length-188,4096);
  for(let off=1;off<=maxScan;off++){
   if(bytes[off]===0x47){
    const checks=Math.min(5,Math.floor((bytes.length-off)/188));
    if(checks>=1){
     let ok=true;
     for(let k=1;k<checks;k++)if(bytes[off+k*188]!==0x47){ok=false;break;}
     if(ok)return {bytes:bytes.subarray(off),strippedBytes:off,magic};
    }
   }
  }
  return {bytes,strippedBytes:0,magic};
 }

 function boxes(b,start=0,end=b.length){
  const result=[];for(let p=start;p<end;){if(p+8>end)fail('MP4_BOX');const v=new DataView(b.buffer,b.byteOffset+p,8),size=v.getUint32(0);if(size<8||p+size>end)fail('MP4_BOX');result.push({type:String.fromCharCode(...b.subarray(p+4,p+8)),start:p+8,end:p+size});p+=size;}return result;
 }
 function tracks(init){
  const moov=boxes(init).find(b=>b.type==='moov');if(!moov)fail('MP4_INIT');let video=0,audio=0;
  const scales=new Map(),kinds=new Map();const view=new DataView(init.buffer,init.byteOffset,init.byteLength);
  for(const trak of boxes(init,moov.start,moov.end).filter(b=>b.type==='trak')){
   const parts=boxes(init,trak.start,trak.end),tkhd=parts.find(b=>b.type==='tkhd'),mdia=parts.find(b=>b.type==='mdia');
   if(!tkhd||!mdia)fail('MP4_INIT');
   const idOffset=init[tkhd.start]===0?12:init[tkhd.start]===1?20:-1;
   if(idOffset<0||tkhd.start+idOffset+4>tkhd.end)fail('MP4_INIT');
   const id=view.getUint32(tkhd.start+idOffset),mdiaParts=boxes(init,mdia.start,mdia.end);
   const hdlr=mdiaParts.find(b=>b.type==='hdlr'),mdhd=mdiaParts.find(b=>b.type==='mdhd');
   if(!hdlr||!mdhd||hdlr.start+12>hdlr.end)fail('MP4_INIT');
   const scaleOffset=init[mdhd.start]===0?12:init[mdhd.start]===1?20:-1;
   if(scaleOffset<0||mdhd.start+scaleOffset+4>mdhd.end)fail('MP4_INIT');
   const scale=view.getUint32(mdhd.start+scaleOffset);
   if(!scale||!id||scales.has(id))fail('MP4_INIT');scales.set(id,scale);
   const type=String.fromCharCode(...init.subarray(hdlr.start+8,hdlr.start+12));
   if(type==='vide')video++;else if(type==='soun')audio++;else fail('MP4_TRACK_UNSUPPORTED');kinds.set(id,type);
  }return {video,audio,scales,kinds};
 }
 function normalizeInitHeaderDurations(init){
  const view=new DataView(init.buffer,init.byteOffset,init.byteLength);
  const moov=boxes(init).find(b=>b.type==='moov');if(!moov)return init;
  for(const b of boxes(init,moov.start,moov.end)){
   if(b.type==='mvhd'){
    const v=init[b.start],off=v===1?28:16;
    if(v===0&&b.start+off+4<=b.end&&view.getUint32(b.start+off)===0xffffffff)view.setUint32(b.start+off,0);
   }else if(b.type==='trak'){
    for(const tb of boxes(init,b.start,b.end)){
     if(tb.type==='tkhd'){
      const v=init[tb.start],off=v===1?28:20;
      if(v===0&&tb.start+off+4<=tb.end&&view.getUint32(tb.start+off)===0xffffffff)view.setUint32(tb.start+off,0);
     }else if(tb.type==='mdia'){
      for(const mb of boxes(init,tb.start,tb.end)){
       if(mb.type==='mdhd'){
        const v=init[mb.start],off=v===1?28:16;
        if(v===0&&mb.start+off+4<=mb.end&&view.getUint32(mb.start+off)===0xffffffff)view.setUint32(mb.start+off,0);
       }
      }
     }
    }
   }
  }
  return init;
 }
 // mux.js 6.3.0 can drop the leading AAC frame when it normalizes timestamps.
 // Retain the original frames, then shift *all* tfdt values by one common media
 // origin, expressed rationally in each track timescale. Never rewrite payload.
 function fragmentTimes(data,scales){
  const view=new DataView(data.buffer,data.byteOffset,data.byteLength),records=[];
  const moofs=boxes(data).filter(b=>b.type==='moof');
  if(!moofs.length||!boxes(data).some(b=>b.type==='mdat'))fail('MP4_FRAGMENT');
  for(const moof of moofs){
   const trafs=boxes(data,moof.start,moof.end).filter(b=>b.type==='traf');
   if(!trafs.length)fail('MP4_TIMING');
   for(const traf of trafs){
    const kids=boxes(data,traf.start,traf.end),h=kids.find(b=>b.type==='tfhd'),t=kids.find(b=>b.type==='tfdt');
    if(!h||!t||h.start+8>h.end||t.start+8>t.end)fail('MP4_TIMING');
    const id=view.getUint32(h.start+4),scale=scales.get(id),version=data[t.start];
    if(!scale||(version!==0&&version!==1)||t.start+(version===1?12:8)>t.end)fail('MP4_TIMING');
    const time=version===1?view.getBigUint64(t.start+4,false):BigInt(view.getUint32(t.start+4,false));
    records.push({id,scale,time,version,at:t.start+4});
   }
  }return records;
 }
 function rebaseTimes(data,scales,origin,last,opts={}){
  const stitch=!!opts.stitchTimeline,offsets=opts.stitchOffsets||null;
  let stitches=0;
  const items=fragmentTimes(data,scales),view=new DataView(data.buffer,data.byteOffset,data.byteLength);
  for(const item of items){
   const shift=origin.time*BigInt(item.scale)/BigInt(origin.scale);
   const extra=(stitch&&offsets&&offsets.has(item.id))?offsets.get(item.id):0n;
   let time=item.time-shift+extra;
   const trackState=opts.outputAudit&&opts.outputAudit.tracks?opts.outputAudit.tracks.get(item.id):null;
   const minNext=trackState?trackState.end:(last.has(item.id)?last.get(item.id)+1n:0n);
   if(time<0n||(last.has(item.id)&&time<=last.get(item.id))||(stitch&&trackState&&time<minNext)){
    if(!stitch)fail('MP4_TIMESTAMP_RESET');
    const step=item.scale===90000?3600n:1024n;
    const stitched=trackState?trackState.end:(last.has(item.id)?last.get(item.id)+step:0n);
    if(offsets)offsets.set(item.id,extra+(stitched-time));
    time=stitched;
    stitches++;
   }
   if(time>BigInt(Number.MAX_SAFE_INTEGER))fail('MP4_TIMESTAMP_RESET');
   if(!item.version&&time>0xffffffffn)fail('MP4_TIMESTAMP_RANGE');
   if(item.version===1)view.setBigUint64(item.at,time,false);else view.setUint32(item.at,Number(time),false);
   last.set(item.id,time);
  }
  return stitches;
 }
 function checkTrackClocks(init,plan){
  const rates=[96000,88200,64000,48000,44100,32000,24000,22050,16000,12000,11025,8000,7350];
  const cfg=plan.mediaIntegrityEvidence.aacConfig,expectedAudio=cfg?rates[Number(cfg.split(':')[1])]:null;
  for(const [id,kind] of init.kinds)if(init.scales.get(id)!==(kind==='vide'?90000:expectedAudio))fail('MP4_TRACK_CLOCK_MISMATCH');
 }
 function firstOrigin(queue,scales,needAudio){
  const all=queue.flatMap(s=>fragmentTimes(s.data,scales));
  const ids=new Set(all.map(x=>x.id));
  if(ids.size<scales.size||(needAudio&&scales.size!==2))fail('MP4_FIRST_FRAGMENT_TRACKS');
  return all.reduce((min,x)=>!min||x.time*BigInt(min.scale)<min.time*BigInt(x.scale)?x:min,null);
 }
 function mediaEvidence(plans){
  const totals={sourceCount:plans.length,videoPes:0,audioPes:0,aacFrames:0,aacPayloadBytes:0,nalUnits:0,policy:'strict_pes_adts',adtsFrameAlignedPerPes:true,h264Decoded:false,aacCrcVerified:false};
  for(const plan of plans)for(const key of ['videoPes','audioPes','aacFrames','aacPayloadBytes','nalUnits'])totals[key]+=plan.mediaIntegrityEvidence[key];
  totals.aacConfigurations=[...new Set(plans.map(p=>p.mediaIntegrityEvidence.aacConfig).filter(Boolean))];return totals;
 }
 // Contract for the unmodified, bundled mux.js 6.3.0 generator, not an arbitrary MP4 parser.
 function createOutputAudit(){return {tracks:new Map(),fragments:0,audioSamples:0,videoSamples:0,mdatBytes:0,audioBytes:0,avcNalUnits:0,audioClockAdjustments:0,maxAudioClockAdjustmentTicks:0,totalAudioClockAdjustmentTicks:0};}
 function auditFragment(data,init,state,audioHash){
  const view=new DataView(data.buffer,data.byteOffset,data.byteLength),top=boxes(data);let audioSamples=0;
  const one=(items,type)=>{const found=items.filter(b=>b.type===type);if(found.length!==1)fail('MP4_BOX_CARDINALITY');return found[0];};
  if(!top.length||top.length%2)fail('MP4_FRAGMENT_LAYOUT');
  for(let i=0;i<top.length;i+=2){
   const moof=top[i],mdat=top[i+1];if(moof.type!=='moof'||mdat.type!=='mdat'||mdat.start===mdat.end)fail('MP4_FRAGMENT_LAYOUT');
   const moofKids=boxes(data,moof.start,moof.end),mfhd=one(moofKids,'mfhd'),traf=one(moofKids,'traf');
   if(moofKids.length!==2||mfhd.end-mfhd.start!==8||view.getUint32(mfhd.start)!==0)fail('MP4_FRAGMENT_HEADER');
   const sequence=view.getUint32(mfhd.start+4),kids=boxes(data,traf.start,traf.end),tfhd=one(kids,'tfhd'),tfdt=one(kids,'tfdt'),trun=one(kids,'trun');
   if(tfhd.end-tfhd.start!==24||view.getUint32(tfhd.start)!==0x3a||view.getUint32(tfhd.start+8)!==1)fail('MP4_TFHD_UNSUPPORTED');
   const id=view.getUint32(tfhd.start+4),kind=init.kinds.get(id);if(!kind)fail('MP4_TRACK_UNKNOWN');
   const allowed=kind==='vide'?['tfhd','tfdt','trun','sdtp']:['tfhd','tfdt','trun'];
   if(kids.some(b=>!allowed.includes(b.type)))fail('MP4_TRAF_UNSUPPORTED');
   const sdtps=kids.filter(b=>b.type==='sdtp');if(sdtps.length>1)fail('MP4_BOX_CARDINALITY');
   if(trun.end-trun.start<12)fail('MP4_SAMPLE_TABLE');
   const full=view.getUint32(trun.start),version=full>>>24,flags=full&0xffffff,count=view.getUint32(trun.start+4);
   if(version>1||flags!==(kind==='soun'?0x301:0xf01))fail('MP4_TRUN_UNSUPPORTED');
   const stride=kind==='soun'?8:16;
   if(!count||trun.end-trun.start!==12+count*stride)fail('MP4_SAMPLE_TABLE');
   if(sdtps.length&&(sdtps[0].end-sdtps[0].start!==4+count||view.getUint32(sdtps[0].start)!==0))fail('MP4_SAMPLE_DEPENDENCY_TABLE');
   const offset=view.getInt32(trun.start+8),begin=moof.start-8+offset;
   if(begin!==mdat.start)fail('MP4_SAMPLE_DATA_OFFSET');
   const tv=data[tfdt.start];if((tv!==0&&tv!==1)||tfdt.end-tfdt.start!==(tv===1?12:8)||data[tfdt.start+1]||data[tfdt.start+2]||data[tfdt.start+3])fail('MP4_TIMING');
   let time=tv===1?view.getBigUint64(tfdt.start+4):BigInt(view.getUint32(tfdt.start+4));
   const previous=state.tracks.get(id);
   if(previous){
    if(time<previous.end){
     const correction=previous.end-time;
     // 90kHz PES timestamps converted to the AAC clock can floor one tick early.
     // Repair only that bounded quantum; larger overlaps and all video overlaps fail closed.
     if(kind!=='soun'||correction>1n)fail('MP4_DECODE_OVERLAP');
     time=previous.end;if(tv===1)view.setBigUint64(tfdt.start+4,time);else {if(time>0xffffffffn)fail('MP4_TIMESTAMP_RANGE');view.setUint32(tfdt.start+4,Number(time));}
     state.audioClockAdjustments++;state.maxAudioClockAdjustmentTicks=Math.max(state.maxAudioClockAdjustmentTicks,Number(correction));state.totalAudioClockAdjustmentTicks+=Number(correction);
    }
    const advance=(sequence-previous.sequence)>>>0;if(!advance||advance>=0x80000000)fail('MP4_SEQUENCE_RESET');}
   let cursor=begin,duration=0n;
   for(let n=0;n<count;n++){
    const at=trun.start+12+n*stride,ticks=view.getUint32(at),size=view.getUint32(at+4);
    if(!ticks||!size)fail('MP4_SAMPLE_EMPTY');
    if(cursor+size>mdat.end)fail('MP4_SAMPLE_DATA_RANGE');
    duration+=BigInt(ticks);
    if(kind==='soun'){
     if(ticks!==1024)fail('MP4_AAC_SAMPLE_DURATION');
     const prefix=new Uint8Array(4);new DataView(prefix.buffer).setUint32(0,size);audioHash.update(prefix);audioHash.update(data.subarray(cursor,cursor+size));
     audioSamples++;state.audioSamples++;state.audioBytes+=size;
    }else{
     if(view.getUint32(at+8)&0xf0000000)fail('MP4_SAMPLE_FLAGS');
     let nal=cursor,vcl=false;
     while(nal<cursor+size){
      if(nal+4>cursor+size)fail('MP4_AVC_SAMPLE_LAYOUT');const length=view.getUint32(nal);nal+=4;
      if(!length||nal+length>cursor+size)fail('MP4_AVC_SAMPLE_LAYOUT');
      const header=data[nal],type=header&31;if((header&0x80)||!type||type>23)fail('MP4_AVC_NAL_HEADER');
      if(type===1||type===5)vcl=true;state.avcNalUnits++;nal+=length;
     }
     if(!vcl)fail('MP4_AVC_VCL_REQUIRED');state.videoSamples++;
    }
    cursor+=size;
   }
   if(cursor!==mdat.end)fail('MP4_MDAT_UNREFERENCED');
   state.tracks.set(id,{end:time+duration,sequence});state.fragments++;state.mdatBytes+=mdat.end-mdat.start;
  }
  return audioSamples;
 }
 function outputEvidence(state){return {policy:'bundled_mux_6_3_fragment_contract',fragmentsAudited:state.fragments,audioSamples:state.audioSamples,videoSamples:state.videoSamples,mdatBytesVerified:state.mdatBytes,audioBytes:state.audioBytes,avcNalUnits:state.avcNalUnits,audioClockAdjustments:state.audioClockAdjustments,maxAudioClockAdjustmentTicks:state.maxAudioClockAdjustmentTicks,totalAudioClockAdjustmentTicks:state.totalAudioClockAdjustmentTicks,audioClockAdjustmentLimitTicks:1,sampleTablesAndRangesVerified:true,decodeOverlapChecked:true,trackClocksMatched:true,codecMetadata:state.codecMetadata,fullDecode:false};}
 function conserveAudio(plans,outputSamples){
  const evidence=mediaEvidence(plans);
  if(outputSamples!==evidence.aacFrames)fail('MP4_AAC_FRAME_COUNT_MISMATCH');
  return {...evidence,outputAacSamples:outputSamples,aacFrameCountConserved:true,aacPayloadHashVerified:true,aacPayloadHashAlgorithm:'SHA-256 of big-endian sample-length prefixes and raw AAC payloads'};
 }
 function same(a,b){return a.length===b.length&&a.every((n,i)=>n===b[i]);}
 async function convert({inputs,destination,muxjs,hashing,stitchTimeline=false,signal,onProgress=()=>{}}){
  const alive=()=>{if(signal&&signal.aborted)fail('CONVERSION_CANCELLED');};alive();
  if(!inputs||!inputs.length||inputs.length>4096)fail('INPUT_COUNT');const files=[];
  for(const handle of inputs){
   if(typeof destination.isSameEntry!=='function')fail('IDENTITY_CHECK_UNAVAILABLE');
   if(await destination.isSameEntry(handle))fail('SOURCE_OVERWRITE_REFUSED');
   for(const previous of files){if(previous.handle===handle||(typeof previous.handle.isSameEntry==='function'&&await previous.handle.isSameEntry(handle)))fail('DUPLICATE_INPUT');}
   const file=await handle.getFile();if(!file.size||file.size>MAX_INPUT)fail('TS_FILE_LIMIT_64_MIB');files.push({handle,file});
  }
  // Preflight all files before a writable is opened. Re-check while converting in case inputs mutate.
  let expected=null;
  for(let i=0;i<files.length;i++){
   alive();onProgress({phase:'preflight',index:i,total:files.length});
   const f=files[i].file,data=new Uint8Array(await f.arrayBuffer());if(data.length!==f.size)fail('TS_SIZE_CHANGED');
   const next=tsPlan(data,{media:true,hashing,allowDiscontinuity:stitchTimeline});if(expected&&expected!==next.signature)fail('TS_TRACK_CHANGE');expected=next.signature;files[i].plan=next;files[i].sha256=new hashing.Sha256().update(data).digest();
  }
  alive();
  const mux=new muxjs.mp4.Transmuxer({remux:true,keepOriginalTimestamps:true}),hash=new hashing.Sha256(),last=new Map(),stitchOffsets=new Map(),outputAudit=createOutputAudit();
  let queue=[],queued=0,init=null,initTracks=null,origin=null,plan=null,writer=null,bytes=0,fragments=0,timelineStitches=0,outputAudioSamples=0,error=null;
  mux.on('error',e=>{error=Error('TRANSMUX_ERROR');});
  mux.on('data',s=>{queued+=s.initSegment.byteLength+s.data.byteLength;if(queued>128*1048576){error=Error('MP4_BUFFER_LIMIT');return;}queue.push({init:new Uint8Array(s.initSegment),data:new Uint8Array(s.data)});});
  try{
   writer=await destination.createWritable();
   for(let i=0;i<files.length;i++){
    alive();onProgress({phase:'convert',index:i,total:files.length,bytes});const file=files[i].file,data=new Uint8Array(await file.arrayBuffer());if(data.length!==file.size)fail('TS_SIZE_CHANGED');
    const next=tsPlan(data,{media:true,hashing,allowDiscontinuity:stitchTimeline});if(plan&&plan.signature!==next.signature)fail('TS_TRACK_CHANGE');plan=next;
    if(new hashing.Sha256().update(data).digest()!==files[i].sha256)fail('TS_INPUT_CHANGED');
    const outputSampleHash=new hashing.Sha256();
    mux.push(data);mux.flush();if(error)throw error;alive();
    if(!queue.length)fail('NO_MP4_FRAGMENT');
    if(!init){
     initTracks=tracks(queue[0].init);
     if(initTracks.video!==1||initTracks.audio!==(plan.audio?1:0))fail('MP4_TRACK_LOSS');
     checkTrackClocks(initTracks,plan);outputAudit.codecMetadata=codecs.auditInit(queue[0].init,plan.mediaIntegrityEvidence);origin=firstOrigin(queue,initTracks.scales,plan.audio);
    }
    for(const out of queue){
     if(!init){init=normalizeInitHeaderDurations(new Uint8Array(out.init));await writer.write(init);hash.update(init);bytes+=init.length;}
     else if(!same(init,normalizeInitHeaderDurations(new Uint8Array(out.init))))fail('MP4_INIT_CHANGE');
     timelineStitches+=rebaseTimes(out.data,initTracks.scales,origin,last,{stitchTimeline,stitchOffsets,outputAudit});outputAudioSamples+=auditFragment(out.data,initTracks,outputAudit,outputSampleHash);alive();await writer.write(out.data);hash.update(out.data);bytes+=out.data.length;fragments++;
    }queue=[];queued=0;
    if(outputSampleHash.digest()!==files[i].plan.mediaIntegrityEvidence.aacSampleSha256)fail('MP4_AAC_PAYLOAD_HASH_MISMATCH');
   }
   const conserved=conserveAudio(files.map(f=>f.plan),outputAudioSamples);
   alive();onProgress({phase:'close',bytes});alive();await writer.close();writer=null;
   const output=await destination.getFile();if(output.size!==bytes)fail('MP4_SIZE_MISMATCH');onProgress({phase:'verify',bytes});
   const sha256=await hashing.hashBlob(output);if(sha256!==hash.digest())fail('MP4_HASH_MISMATCH');
   return {confirmed:true,bytes,sha256,fragments,timelineStitches,format:'fragmented_mp4',decoded:false,audio:plan.audio,inputHashVerified:true,mediaIntegrityEvidence:conserved,mp4IntegrityEvidence:outputEvidence(outputAudit)};
  }catch(e){if(writer)try{await writer.abort();}catch(ignore){}throw e;}
  finally{mux.dispose();}
 }
 // Keep incomplete audio PES in the next GOP chunk. Input is already PSI/CC validated.
 function createGopChunker(plan,target){
  const streams=JSON.parse(plan.signature),video=streams.find(s=>s[0]===0x1b)[1],ae=streams.find(s=>s[0]===0x0f),audio=ae?ae[1]:-1;
  let v=[],a=[],pending=[],bytes=0,seen=false;
  function pack(){
   const count=plan.psiPackets.length+v.length+a.length;
   const result=new Uint8Array(count*188);let at=0;
   for(const list of [plan.psiPackets,v,a])for(const pkt of list){result.set(pkt,at);at+=188;}
   return result;
  }
  function push(pkt){
   const pid=((pkt[1]&31)<<8)|pkt[2],pusi=!!(pkt[1]&0x40),ctrl=(pkt[3]>>4)&3;
   if(!(ctrl&1))return null;
   const rai=!!((ctrl&2)&&pkt[4]&&(pkt[5]&0x40));let out=null;
   if(pid===video){
    if(pusi&&rai&&seen&&bytes>=target){out=pack();v=[];a=pending;pending=[];bytes=a.length*188;}
    if(pusi&&rai)seen=true;
    v.push(new Uint8Array(pkt));bytes+=188;
   }else if(pid===audio){
    if(pusi){a=a.concat(pending);pending=[];}pending.push(new Uint8Array(pkt));bytes+=188;
   }
   if(bytes>MAX_CHUNK_BYTES)fail('TS_GOP_BUFFER_LIMIT');
   return out;
  }
  function finish(){a=a.concat(pending);pending=[];return v.length||a.length?pack():null;}
  return {push,finish};
 }
 function splitTsGopAligned(data,targetChunkBytes=16*1048576){
  if(!Number.isSafeInteger(targetChunkBytes)||targetChunkBytes<188||targetChunkBytes>MAX_CHUNK_BYTES)fail('CONVERSION_OPTIONS');
  const plan=tsPlan(data),chunker=createGopChunker(plan,targetChunkBytes),result=[];
  for(let at=0;at<data.length;at+=188){const chunk=chunker.push(data.subarray(at,at+188));if(chunk)result.push(chunk);}
  const tail=chunker.finish();if(tail)result.push(tail);return result;
 }
 async function convertStreamed({inputs,destination,muxjs,hashing,maxInputBytes=MAX_STREAM_INPUT,sliceBytes=8*1048576,chunkTargetBytes=16*1048576,stripDisguise=true,stitchTimeline=false,signal,onProgress=()=>{}}){
  const alive=()=>{if(signal&&signal.aborted)fail('CONVERSION_CANCELLED');};alive();
  if(!Number.isSafeInteger(sliceBytes)||sliceBytes<8192||sliceBytes>64*1048576||
   !Number.isSafeInteger(chunkTargetBytes)||chunkTargetBytes<188||chunkTargetBytes>MAX_CHUNK_BYTES||
   !Number.isSafeInteger(maxInputBytes)||maxInputBytes<1||maxInputBytes>MAX_STREAM_INPUT)fail('CONVERSION_OPTIONS');
  if(!inputs||!inputs.length||inputs.length>4096)fail('INPUT_COUNT');
  const step=Math.floor(sliceBytes/188)*188,files=[];let expected=null;
  for(const handle of inputs){
   alive();
   if(typeof destination.isSameEntry!=='function')fail('IDENTITY_CHECK_UNAVAILABLE');
   if(await destination.isSameEntry(handle))fail('SOURCE_OVERWRITE_REFUSED');
   for(const previous of files)if(previous.handle===handle||(typeof previous.handle.isSameEntry==='function'&&await previous.handle.isSameEntry(handle)))fail('DUPLICATE_INPUT');
   const file=await handle.getFile();if(!Number.isSafeInteger(file.size)||file.size<1||file.size>maxInputBytes)fail('TS_FILE_LIMIT');
   files.push({handle,file});
  }
  async function read(file,start,end){alive();const data=new Uint8Array(await file.slice(start,end).arrayBuffer());alive();if(data.length!==end-start)fail('TS_SIZE_CHANGED');return data;}
  // Validate every source, with a bounded rolling parser, before opening the output.
  for(let i=0;i<files.length;i++){
   const entry=files[i],file=entry.file,validator=createTsValidator({media:true,hashing,allowDiscontinuity:stitchTimeline}),digest=new hashing.Sha256();
   alive();onProgress({phase:'preflight',index:i,total:files.length,readBytes:0});alive();
   const probe=await read(file,0,Math.min(file.size,8192));
   const stripped=stripDisguise?stripDisguisedTs(probe):{strippedBytes:0};entry.offset=stripped.strippedBytes;
   if(file.size<=entry.offset||(file.size-entry.offset)%188)fail('TS_ALIGNMENT');
   for(let pos=entry.offset;pos<file.size;pos+=step){
    const data=await read(file,pos,Math.min(file.size,pos+step));validator.push(data);digest.update(data);
    onProgress({phase:'preflight',index:i,total:files.length,readBytes:Math.min(file.size,pos+step)});alive();
   }
   entry.plan=validator.finish();entry.sha256=digest.digest();
   if(expected&&expected!==entry.plan.signature)fail('TS_TRACK_CHANGE');expected=entry.plan.signature;
  }
  alive();
  const mux=new muxjs.mp4.Transmuxer({remux:true,keepOriginalTimestamps:true}),hash=new hashing.Sha256(),last=new Map(),stitchOffsets=new Map(),outputAudit=createOutputAudit();
  let activeAudioHash=null;
  let queue=[],queued=0,init=null,initTracks=null,origin=null,writer=null,bytes=0,fragments=0,chunksProcessed=0,timelineStitches=0,outputAudioSamples=0,error=null;
  mux.on('error',()=>{error=Error('TRANSMUX_ERROR');});
  mux.on('data',s=>{queued+=s.initSegment.byteLength+s.data.byteLength;if(queued>128*1048576){error=Error('MP4_BUFFER_LIMIT');return;}queue.push({init:new Uint8Array(s.initSegment),data:new Uint8Array(s.data)});});
  async function flush(chunk,plan){
   alive();mux.push(chunk);mux.flush();if(error)throw error;alive();if(!queue.length)fail('NO_MP4_FRAGMENT');
   if(!init){initTracks=tracks(queue[0].init);if(initTracks.video!==1||initTracks.audio!==(plan.audio?1:0))fail('MP4_TRACK_LOSS');checkTrackClocks(initTracks,plan);outputAudit.codecMetadata=codecs.auditInit(queue[0].init,plan.mediaIntegrityEvidence);origin=firstOrigin(queue,initTracks.scales,plan.audio);}
   for(const out of queue){
    if(!init){init=normalizeInitHeaderDurations(new Uint8Array(out.init));await writer.write(init);hash.update(init);bytes+=init.length;}else if(!same(init,normalizeInitHeaderDurations(new Uint8Array(out.init))))fail('MP4_INIT_CHANGE');
    timelineStitches+=rebaseTimes(out.data,initTracks.scales,origin,last,{stitchTimeline,stitchOffsets,outputAudit});outputAudioSamples+=auditFragment(out.data,initTracks,outputAudit,activeAudioHash);alive();await writer.write(out.data);hash.update(out.data);bytes+=out.data.length;fragments++;
   }
   queue=[];queued=0;chunksProcessed++;
  }
  try{
   writer=await destination.createWritable();
   for(let i=0;i<files.length;i++){
    const entry=files[i],file=entry.file,chunker=createGopChunker(entry.plan,chunkTargetBytes),digest=new hashing.Sha256(),validator=createTsValidator({media:true,hashing,allowDiscontinuity:stitchTimeline});
    activeAudioHash=new hashing.Sha256();
    alive();onProgress({phase:'convert',index:i,total:files.length,bytes});alive();
    for(let pos=entry.offset;pos<file.size;pos+=step){
     const data=await read(file,pos,Math.min(file.size,pos+step));validator.push(data);digest.update(data);
     for(let at=0;at<data.length;at+=188){const chunk=chunker.push(data.subarray(at,at+188));if(chunk)await flush(chunk,entry.plan);}
     onProgress({phase:'convert',index:i,total:files.length,bytes,readBytes:Math.min(file.size,pos+step)});alive();
    }
    validator.finish();if(digest.digest()!==entry.sha256)fail('TS_INPUT_CHANGED');
    const tail=chunker.finish();if(tail)await flush(tail,entry.plan);
    if(activeAudioHash.digest()!==entry.plan.mediaIntegrityEvidence.aacSampleSha256)fail('MP4_AAC_PAYLOAD_HASH_MISMATCH');
   }
   const conserved=conserveAudio(files.map(f=>f.plan),outputAudioSamples);
   alive();onProgress({phase:'close',bytes});alive();await writer.close();writer=null;
   const output=await destination.getFile();if(output.size!==bytes)fail('MP4_SIZE_MISMATCH');onProgress({phase:'verify',bytes});
   const sha256=await hashing.hashBlob(output);if(sha256!==hash.digest())fail('MP4_HASH_MISMATCH');
   return {confirmed:true,bytes,sha256,fragments,chunksProcessed,disguiseStrippedBytes:files.reduce((n,f)=>n+f.offset,0),timelineStitches,format:'fragmented_mp4',decoded:false,audio:files[0].plan.audio,timelineRebased:true,inputHashVerified:true,mediaIntegrityEvidence:conserved,mp4IntegrityEvidence:outputEvidence(outputAudit)};
  }catch(e){if(writer)try{await writer.abort();}catch(ignore){}throw e;}
  finally{mux.dispose();}
 }
 return {convert,convertStreamed,splitTsGopAligned,stripDisguisedTs,psiCrc,tsPlan,MAX_INPUT,MAX_STREAM_INPUT,MAX_CHUNK_BYTES};
});
