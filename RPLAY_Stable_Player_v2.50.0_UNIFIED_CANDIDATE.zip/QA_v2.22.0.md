# v2.22.0 検証結果

2026-10-26 JST / CANDIDATE_NO_GO

## 自動回帰試験

Node 411 + Python 165 = **576 PASS / 0 FAIL**。
新規17件: BrowserIO14件（読み取り専用File、fresh OPFS、async/sync writer、短いwrite/0-write、容量失敗、receipt、改変/サイズ検知、メモリ上限、列挙上限、Web Locksの排他）とローカルHTTPサーバー3件。
従来のUI5件はWorker経路で同等の順序・中止・未対応・選択キャンセル・書込失敗を試験する形へ更新。Firefoxを非対応と決め打ちする旧UI試験は現在の要件に合わせています。
従来の録画・CLI・MP4 codec/media/大容量素材等も全件実行。実行ログは evidence/v222-current に保存。

## 実Firefox

MozillaのFirefox **158.0.1** とgeckodriver **0.37.1**、Linux/headless、使い捨てプロファイルへ実際に一時拡張を読み込みました。
**22項目中21 PASS / 1 BLOCKED**。ブラウザ試験はモックではありません。結果は evidence/firefox-v222/FIREFOX_ACCEPTANCE.json と acceptance.log。

確認済み:
- ネイティブpickerがないFirefoxでFile選択・Worker・OPFSを使用。
- 44.1kHz mono/48kHz stereo/映像のみの実TSを変換。
- 実downloads APIの完了/サイズ一致、さらに試験側でPC上の出力SHA-256を独立照合。
- 保存MP4をffprobeで確認し、FFmpeg -xerrorで全デコード。
- decoded video frame MD5が元TSと一致。連続TSを自然順に並べた複数パート結合でも一致。
- 出力AACフレーム数とpayload hash照合、設定変更入力の拒否。
- 再読み込み後のOPFS復元と全体hash再照合、同サイズ改変の拒否、古い出力を誤って保存させないUI。
- 実Workerの中止、別画面のWeb Lock中の削除拒否、Worker強制終了後の未完了ジョブ一覧と明示削除。
- 600pxウィンドウで横方向のはみ出しなし。
- 77,520,108 bytes（約73.9MiB）の実TSをWorkerで変換し、75,504,063 bytesのMP4を保存・独立hash照合・全デコード。変換中にUIタイマーが進むことも確認。ピークRAM測定や2GiB実証ではありません。
- 元TSのhashが処理後も不変。

未合格1件:
ブラウザ内プレビューは320×180の映像メタデータを読み取れましたが、再生時刻が進む確認はできませんでした。FFmpegで別途作った通常のflat MP4の対照試験でも同様です。よって実ブラウザ再生・音声同期の合格は付けていません。保存MP4のFFmpeg全デコードと混同しません。

このコンテナでは通常のプロセスsandbox起動に制約があり、試験専用フラグ --relax-content-sandbox で使い捨てプロファイルのcontent/RDD/utility sandbox levelを調整しました。製品コードはその設定を変更しません。ユーザー環境でsandboxを無効化する手順は案内しません。

## 再現

python scripts/test_firefox_mp4.py --firefox /path/to/firefox --geckodriver /path/to/geckodriver --output-dir /outside/project/evidence --large

Firefox/driver/FFmpegが必要。外部binaryの自動ダウンロードはしません。制約のあるCI専用に --relax-content-sandbox を選択可能。
入力・ダウンロードの大容量試験ファイルは一時作業領域に作り、検証後に削除。報告JSONとログを出力します。
Mozilla取得物SHA-256: dce45470139242cf294eb6ada3d192a9bb334696842b02b71ade448a139eb41a（firefox-158.0.1.tar.xz、公式SHA256SUMSと照合）。

## 残る受入範囲

Windows・実RPLAY・2GiB境界・時間単位の長時間・GPU/オーディオデバイス差・通常プロファイルでの実再生同期は未検証。
今回の成果はTS/MP4変換経路のFirefox対応とその実拡張試験です。Chromeの新しい直接Worker保存経路はモック回帰試験で、実Chromeの受入は未実施です。
