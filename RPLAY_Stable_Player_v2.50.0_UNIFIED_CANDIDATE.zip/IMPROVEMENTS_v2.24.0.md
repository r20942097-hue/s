# 改善整理 v2.24.0

2026-10-26 JST。主ベースはv2.23.0。添付4点の原本・採否は INPUT_RECONCILIATION_v2.23.0.json / INTEGRATION_REVIEW_v2.23.0.md。今回、別系統コードの追加移植はしていない。

|優先|対象|確認と対応|残る検証|
|---|---|---|---|
|対応済|BG録画の配信判定|HTML・空・ヘッダーのみをoffline、ENDLISTをセグメントより優先。masterはchildの状態まで判定|実配信終了→追跡再開|
|対応済|認証付きHLS再試行|Butter再試行も既存transferを使い、2MiB・本文読取中timeout・stop abort・世代ガードを適用|実サービスの認証更新|
|P1|BG録画一覧|再起動時の永続台帳とファイル実体の照合・移行設計が必要。今回の変更は判定処理まで|ブラウザ再起動・クラッシュ復帰|
|P1|配信一覧|v2.21認証/identity、v2.23 query/SPA修正を保持|実RPLAYのAPI/DOM fixture、空一覧/会員配信/新旧配信源|
|P1|TS/MP4|Worker/OPFS/署名保持を保持。Firefoxで回帰|Windows保存・2GiB・時間単位の処理・native preview進行|
|P2|残る通信経路|member probe、source probe、VOD、API JSON等には全量text/json読取が残る|各経路のサイズ上限・中断所有者の統一|
|P2|UI|600px回帰を継続。大規模再配置は今回なし|実一覧件数・キーボード・スクリーンリーダー|
|P2|別音声/字幕|別音声mux・異なるWebVTT timestamp mapの統合は未採用|時刻差fixtureと音声同期|

## 調査した一次資料

- MDN Using the Fetch API: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch — fetchの応答後も本文読取は別段階。AbortControllerは本文も中断する。
- MDN Background scripts: https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/Background_scripts — background寿命と永続保存は別。storage.localで再起動をまたぐ台帳を設計する方針。
- Apple Creating a Multivariant Playlist: https://developer.apple.com/documentation/http-live-streaming/creating-a-multivariant-playlist — EXTM3U開始、各variantのENDLIST終了判定。

上記資料からの設計判断: 認証再試行も通常の有界transferへ合流させ、録画継続の判定には有効なmediaを要求する。診断結果はHLS完全構文検証・実再生合格を意味しない。
