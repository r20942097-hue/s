# RPLAY開発統合台帳（2026-10-26 / v2.9.0）

## コンポーネント・責務の境界

| 系統 | 作業基準 | 所有責務 | 統合許可範囲 | 状態 |
|---|---|---|---|---|
| Stable Player | 2.9.0 CANDIDATE(統合) | 手動プレイヤー、手動ブラウザー録画、単体Python CLI | HLS状態契約、診断仕様 | NO_GO |
| Public Profile Auto Recorder | 1.22.0 CANDIDATE | 公開プロフィール監視・ブラウザ自動録画、最大12（既定2） | 通信予算・保存監査の独立契約 | NO_GO(今回変更なし) |
| Universal Live Watcher | GitHub `r20942097-hue/faaff` | FFmpeg長時間録画、起動監視、SQLiteと復旧 | API/JSONイベント（コード合体しない） | 変更なし |
| Media Download Tools | 系統独立 | 権限がある終了済みVOD、メディアQA | 検証メタデータとffprobe結果 | 変更なし |

## v2.8.0からの引継ぎ（実施状況の書き換え）

| v2.8.0計画の残課題 | v2.9.0での扱い |
|---|---|
| P0 実機受入の実施(ACCEPTANCE.md A1〜A14) | **未実施のままP0維持**。本環境では実Chrome/Firefox/Windows/実RPLAYに接続できないため、v2.9.0でも実施できず観察手順のみ拡充(A15字幕観察点を追加)。ユーザー実施待ち |
| P2 refresh-token応答鍵の実測確定(responseKey) | 未実施(実RPLAYが必要)。形状証拠のまま。実測後にauthEvidence記録鍵を固定 |
| P1 LL-HLS全件形式の実配信評価 | 未実施(実配信が必要)。P1のまま次版へ |
| P2 avCorrelationの実RPLAY較正 | 未実施(実配信が必要)。許容値(2%/0.5s)は合成較正のまま |
| P2 Auto Recorder側の証拠ブロック対応 | 未実施(独立契約のため相手系統のコードは編集しない)。境界文書のまま |
| QA_REPORT.mdのv2.8.0セクション未作成 | **本版で補完**(文書ギャップ解消)。v2.8.0の変更範囲・実測検証・技術判断を追記 |

## v2.9.0の実施記録（2026-10-26確定）

- 全自動試験: Node171 + Python113 = 284 PASS・再ビルド5コア一致
  (shared_core_sha256 f214e5e0…から更新)・クリーン展開再検証PASS。
- 試験資産: tests/test_v290_core.cjs(6試験) / tests/test_v290_features.py(6試験)。
- 指示プロンプト集v2.0のP-13〜P-18フローに沿って実施(テストファースト:
  新規12試験の失敗確認→実装→全試験成功の順序を記録)。

## v2.9.0の目標（一文）

**v2.7.0完成報告で次版候補とされたA-09字幕対応の第一段階「観測と証拠」を、実配信に影響を与えない安全側契約（取得しない・URI秘匿・虚偽零なし）で両コアに鏡像実装し、実機受入時に字幕レンディションの実在判断を数値証拠で下せるようにする。**

## v2.9.0で実施する要件（A-09 字幕対応 第一段階：観測と証拠）

- **A-09-1 字幕レンディション解析（P1・両コア鏡像）** — 実装:
  master playlistの `#EXT-X-MEDIA:TYPE=SUBTITLES` を解析する
  `parse_subtitle_renditions`(Python) / `parseSubtitleRenditions`(JS) を追加。
  レンディション毎に groupId・name・language・assocLanguage・default・
  autoselect・forced・hasUri を記録。**字幕playlistのURI値は出力しない**
  (署名クエリ混入リスク・URL秘匿契約。取得可否のみhasUriで記録)。
- **A-09-2 variant結合属性の記録（P1）** — 実装:
  `#EXT-X-STREAM-INF` の `SUBTITLES="gid"` 属性をvariant辞書に追加
  (`subsGroup`)。音声グループ(AUDIO属性)と同形式の鏡像。
- **A-09-3 subtitleEvidence証拠ブロック（P1・情報JSON）** — 実装:
  `subtitleEvidence` をCLI情報JSONとブラウザー情報JSONに出力。
  renditions(配列)・renditionCount・variantsLinked・
  policy(`observed_not_fetched`)・provenance(`master_playlist_ext_x_media`)。
  **master playlist取得済み(非空)のときのみ出力**し、未取得なら証拠ブロックを
  出さない(虚偽のゼロを捏造しない・A-08契約の継承)。
- **A-09-4 安全側契約（取得しない）** — 実装:
  字幕レンディションは観測と計数のみ。字幕playlist・セグメントの取得は
  行わない(録画経路・通信量に影響を与えない。LL-HLSのPRELOAD-HINT
  先走り取得不実施と同じ安全側思想)。
- **A-09-5 版ピン2.9.0統一（P1）** — 実装:
  @version・Chrome/Firefox manifest(version/version_name)・CLI表示・tool文字列・
  情報JSON toolを2.9.0へ統一。旧版ピン試験(v270/v280)は範囲拡張で維持、
  新規版ピン試験(v290)で2.9.0を恒久固定。validate.pyの期待値も更新。
- **A-09-6 テストファースト（P1・手順契約）** — 実装:
  test_v290_core.cjs(6試験)・test_v290_features.py(6試験)を先行作成し、
  **失敗を確認してから**実装する。相互言語鏡像試験(node実行のJS解析結果と
  Python解析結果の同一性)を含む。
