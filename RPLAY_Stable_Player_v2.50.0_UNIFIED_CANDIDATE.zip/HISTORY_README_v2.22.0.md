# RPLAY Stable Player v2.22.0 CANDIDATE

TS→MP4変換をFirefox対応し、Worker・一時保存・ダウンロード確認・復元を追加した候補版です。

## 使用方法

Firefox: rplay-stable-player-extension-firefox/manifest.json を一時的なアドオンとして読み込み、RPLAYパネルの「TSをMP4へ変換」を開きます。
Chrome: rplay-stable-player-extension を読み込み、同じ変換画面を開きます。直接保存APIがある環境は従来の保存先選択を使用します。

拡張を使わないWindowsでは open_mp4_converter.cmd を起動します。Python 3が必要です。
その他の環境: python3 scripts/serve_mp4.py
表示された127.0.0.1のURLをFirefoxで開き、TSを選択してください。HTMLのfile://直開きはWorker制限で動作しない場合があります。

Firefoxの標準手順: TS選択 → 表示順確認 → MP4へ変換 → 一時MP4のハッシュ照合 → MP4をダウンロード。
拡張画面ではダウンロード完了とサイズを確認します。通常のローカルHTTP画面ではブラウザの保存結果を確認してください。
一時MP4は再読み込み後にも一覧へ表示し、再度ハッシュ照合して保存できます。不要な一時MP4・中断残骸は手動で削除できます。

## 対応と制限

H.264映像＋同じTSのAAC音声、または映像のみ。再エンコードしない断片化MP4です。元TSは保持します。
1入力2GiB・4096本まで（実Firefox試験は約77MBまで）。内部TS保持32MiBはプロセス全体RAMの上限ではありません。
一時保存APIがない場合は入力合計64MiB・出力128MiBのメモリ方式です。画面を閉じるとメモリ出力は失われます。
OPFS容量不足、ブラウザのデータ削除で一時MP4が失われる可能性があります。保管用の保存先ではありません。
コーデック変更、複数SPS/PPS、PESをまたぐAAC等の安全側制限は継続。別TSの音声合成や他コーデックへの再エンコードは未対応です。

## 検証

QA_v2.22.0.md と MP4_GUIDE_v2.22.0.md に手順・合格範囲を記載。Firefox実拡張試験の結果は evidence/firefox-v222/FIREFOX_ACCEPTANCE.json を参照。
Windows・実RPLAY・2GiB境界・長時間は未検証のため、CANDIDATE_NO_GOを維持します。
従来の録画/UI機能は HISTORY_README_v2.21.0.md を参照してください。
