(function(root){'use strict';
function parse(value){const raw=String(value||'').trim();if(/^[a-f0-9]{24}$/i.test(raw))return raw.toLowerCase();let u;try{u=new URL(raw);}catch(e){throw Error('URLまたは24桁の配信者IDを入力してください');}if(u.protocol!=='https:'||!['rplay.live','www.rplay.live'].includes(u.hostname)||u.port||u.username||u.password)throw Error('https://rplay.live/ のURLだけ登録できます');const m=/^\/(?:profile|channel|creator|live)\/([a-f0-9]{24})\/?$/i.exec(u.pathname),q=u.searchParams.getAll('creatorOid');if(q.length>1||q.length&&!/^[a-f0-9]{24}$/i.test(q[0]))throw Error('配信者IDが不正または重複しています');if(m&&q.length&&m[1].toLowerCase()!==q[0].toLowerCase())throw Error('URL内の配信者IDが一致しません');if(m)return m[1].toLowerCase();if(/^\/(?:profile|channel|creator|live)\/?$/i.test(u.pathname)&&q.length)return q[0].toLowerCase();throw Error('配信者IDを特定できません。動画URLや名前だけのURLではなく、配信者IDを含むURLを使ってください');}
function list(value){const tokens=String(value||'').split(/[\s,]+/).filter(Boolean);if(tokens.length>100)throw Error('一度に100件まで登録できます');return [...new Set(tokens.map(parse))];}
function target(value){try{return {id:parse(value)};}catch(original){let u;try{u=new URL(String(value).trim());}catch(e){throw original;}if(u.protocol!=='https:'||!['rplay.live','www.rplay.live'].includes(u.hostname)||u.port||u.username||u.password)throw original;const m=/^\/c\/([^/]+)(?:\/live)?\/?$/.exec(u.pathname);if(!m||u.searchParams.has('creatorOid'))throw original;let slug;try{slug=decodeURIComponent(m[1]);}catch(e){throw original;}if(!slug||slug.length>100||/[\s/\\\x00-\x1f\x7f]/.test(slug))throw original;return {slug};}}
async function resolveList(value,lookup,options={}){const signal=options.signal,check=()=>{if(signal&&signal.aborted)throw Error('登録を中止しました');};check();const tokens=String(value||'').split(/[\s,]+/).filter(Boolean);if(tokens.length>100)throw Error('一度に100件まで登録できます');const entries=tokens.map(target),aliases=new Set(entries.filter(x=>x.slug).map(x=>x.slug));if(aliases.size>20)throw Error('名前URLの解決は一度に20人までです');const cache=new Map(),ids=[],meta={};let completed=0;for(const entry of entries){check();let id=entry.id;if(!id){if(!cache.has(entry.slug)){const result=await lookup(entry.slug,signal);check();if(!result||typeof result._id!=='string'||!/^([a-f0-9]{24})$/i.test(result._id))throw Error('名前URLを配信者IDへ解決できませんでした。一覧は変更していません');const resolvedId=result._id.toLowerCase();cache.set(entry.slug,resolvedId);const entryMeta=metaEntry(entry.slug,result);if(entryMeta)meta[resolvedId]=entryMeta;}id=cache.get(entry.slug);}if(!ids.includes(id))ids.push(id);completed++;if(options.onProgress)options.onProgress({completed,total:entries.length,resolved:ids.length});}check();if(typeof options.onMeta==='function')options.onMeta(meta);return ids;}
async function lookupCustom(slug,fetchImpl=fetch,signal){
 if(signal&&signal.aborted)throw Error('登録を中止しました');
 const ctl=new AbortController(),abort=()=>ctl.abort();if(signal)signal.addEventListener('abort',abort,{once:true});const timer=setTimeout(()=>ctl.abort(),8000);let reader;
 try{if(signal&&signal.aborted)ctl.abort();const res=await fetchImpl('https://api.rplay.live/account/getuser?customUrl='+encodeURIComponent(slug),{cache:'no-store',credentials:'omit',redirect:'error',signal:ctl.signal});if(res.status!==200)throw Error('配信者確認API HTTP '+res.status);if(Number(res.headers.get('content-length'))>2*1048576)throw Error('配信者確認応答が大きすぎます');if(!res.body||!res.body.getReader)throw Error('応答streamを取得できません');reader=res.body.getReader();let size=0,text='';const decoder=new TextDecoder('utf-8',{fatal:true});while(true){const part=await reader.read();if(part.done)break;size+=part.value.byteLength;if(size>2*1048576)throw Error('配信者確認応答が大きすぎます');text+=decoder.decode(part.value,{stream:true});}text+=decoder.decode();return JSON.parse(text);}finally{ctl.abort();clearTimeout(timer);if(signal)signal.removeEventListener('abort',abort);if(reader){try{const p=reader.cancel();if(p&&p.catch)p.catch(()=>{});}catch(e){}reader.releaseLock();}}
}
function snapshot(value){if(value===undefined)return '[]';if(!Array.isArray(value)||value.length>100||value.some(x=>typeof x!=='string'||!/^[a-f0-9]{24}$/i.test(x)))throw Error('保存済み一覧の形式が不正です。上書きせず確認してください');return JSON.stringify([...new Set(value.map(x=>x.toLowerCase()))]);}
/* ---- v2.42.0: 名前metadata(rsp_creator_meta) ----
   rsp_registered_creators はID配列のまま(契約不变)。名前URL解決時に
   取得した名前/正規URLだけを別keyへ保存する(派生データ・失信許容)。
   直接ID/プロフィールURL登録はAPIへ問い合わせないため meta を作らない。 */
function slugOk(s){return typeof s==='string'&&s.length>0&&s.length<=100&&!/[\s/\\\x00-\x1f\x7f]/.test(s);}
function metaEntry(slug,result){
 if(!slugOk(slug)||!result||typeof result!=='object'||Array.isArray(result))return null;
 let name='';for(const k of ['name','nickname','userName']){const v=result[k];if(typeof v==='string'&&v.trim()){name=v.trim().replace(/\s+/g,' ').slice(0,100);break;}}
 const custom=slugOk(result.customUrl)?result.customUrl:slug;
 const url='https://rplay.live/c/'+encodeURIComponent(custom);
 if(url.length>340)return null;
 return {name:name,url:url};
}
function sanitizeMeta(value){
 const out={};
 if(!value||typeof value!=='object'||Array.isArray(value))return out;
 const keys=Object.keys(value);
 if(!keys.length||keys.length>100)return out;
 for(const k of keys){
  if(!/^[a-f0-9]{24}$/.test(k))continue;
  const e=value[k];
  if(!e||typeof e!=='object'||Array.isArray(e))continue;
  const name=typeof e.name==='string'?e.name.replace(/\s+/g,' ').trim().slice(0,100):'';
  const url=typeof e.url==='string'&&e.url.length<=340&&/^https:\/\/rplay\.live\/c\/[A-Za-z0-9\-_.!~*'()]+$/.test(e.url)?e.url:'';
  const at=Number.isSafeInteger(e.at)&&e.at>0&&e.at<=Date.now()+946684800000?e.at:0;
  if(!name&&!url)continue;
  out[k]={name:name,url:url,at:at};
 }
 return out;
}
async function commit(ids,expected,storage,locks,metaUpdate){const next=JSON.parse(snapshot(ids));if(typeof expected!=='string')throw Error('保存済み一覧を読み込んでから登録してください');if(!locks||typeof locks.request!=='function')throw Error('この環境は排他保存に非対応です。対応ブラウザで再確認してください');const patch=sanitizeMeta(metaUpdate);return locks.request('rsp-creator-registry-save-v1',async()=>{const current=await storage.get(['rsp_registered_creators','rsp_creator_meta']);if(snapshot(current.rsp_registered_creators)!==expected)throw Error('別の画面で登録一覧が更新されました。保存済みに戻してから編集し直してください');const merged=sanitizeMeta(current.rsp_creator_meta);const now=Date.now();for(const k of Object.keys(patch))if(next.includes(k))merged[k]={name:patch[k].name,url:patch[k].url,at:now};for(const k of Object.keys(merged))if(!next.includes(k))delete merged[k];await storage.set({rsp_registered_creators:next,rsp_creator_meta:merged});return snapshot(next);});}
const api={parse,list,target,resolveList,lookupCustom,snapshot,commit,metaEntry,sanitizeMeta};if(typeof module!=='undefined')module.exports=api;root.RspCreatorRegistry=api;
})(globalThis);
