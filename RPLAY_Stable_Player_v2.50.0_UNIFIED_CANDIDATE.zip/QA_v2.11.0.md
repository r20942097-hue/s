# v2.11.0 開発検証記録

## 範囲

今回添付のUNIFIED v2.10.0から独立した新しい開発版。旧AGGREGATE v2.10.0への上書きではない。
入力ZIPのSHA-256はINPUTS_v2.11.0.json、変更ソースの差分はCHANGES_v2.11.0.patchを参照。

## 実施内容

生成済みユーザースクリプトとChrome/Firefoxのcontent/offscreenの5つの録画コアが同一であること、再ビルドでバイトが変わらないこと、マニフェストとJavaScript構文、Node/Python全体の回帰試験を確認。
新規6試験はtest_parts.cjs。既存の版番号試験はv2.11.0を対象に更新した。挙動の検査を削除していない。

入力から継承したtest_v250_features.pyは、偽のTSパケットでEXTINFのlegacy許容を調べる試験である。FFmpegがAUDIT_decode_errorsを返す環境で期待値が不足して失敗したため、すでに許容していたAUDIT_probe_failedと同様にデコード監査エラーも期待するように修正した。デコード失敗を成功へ読み替えていない。生成された有効TS/fMP4を使う他の試験は継承。

## 解釈の限界

容量による分割抑制の試験では仮想的な3GiBのバイト数を使用し、実際に3GiBを書き込んでいない。遅い書き込み・ディスク障害・保存先失敗はAPIモックによる。実Chrome/Firefoxへの導入、実RPLAY、Windows、長時間録画、空き容量枯渇、停止前クラッシュの耐性、実映像での継ぎ目・音声同期は未確認。

cat-catchについては公開資料・変更履歴の知見を設計へ反映した。上流全ソースの解析完了や性能比較を主張しない。

## 公開判定

CANDIDATE / NO_GO。今回追加したブラウザ内MP4変換はない。既存CLIのFFmpeg機能は継承。
最新の件数・結果はevidence/v211-current/VALIDATION.jsonを参照。既存evidence内のv2.10.0等の資料は入力から継承した過去の記録。
