# RPLAY v2.42.4: 既存メディア取得ツールの調査とパート単位の保存証拠連携

日付: 2026-10-27 JST  /  状態: CANDIDATE / NO_GO  /  ベース: v2.42.3 ZIP

## 調査対象と評価（2026-10-27の公開情報）

| 参考実装・製品 | 評価したアイデア | v2.42.4での扱い |
|---|---|---|
| Video DownloadHelper（Firefox/Chrome） | 幅広いサイトのHLS/DASH検出、形式・トラック別の処理 | 既存の候補識別／診断機能を継続。サイト固有の非公開フローの模倣は未実施 |
| cat-catch | タブごとの発見資源一覧、HLS取得済みデータの再利用、再試行一覧 | 既存v2.42.3の候補一覧と部分監査を確認。GPL-3.0元ソースは今回コピーしていない |
| Streamlink | ストリームのプラグイン分離、セグメント試行数／並列数／live-edge調整 | 今後の取得スケジューラ設計候補、未統合 |
| yt-dlp | 再試行分類、フラグメント再開、非上書き、部分出力 | 既存パート保存との差分を検討。現行版の保存レシートへ監査証拠を紐づけ |
| N_m3u8DL-RE | HLS/DASHライブ録画、音声と映像のmux、診断 | CLI/MP4統合の中長期候補。今回はDASH録画を実装していない |

出典: https://addons.mozilla.org/en-US/firefox/addon/video-downloadhelper/ ; https://github.com/xifangczy/cat-catch/releases ; https://github.com/xifangczy/cat-catch/blob/master/LICENSE ; https://streamlink.github.io/cli.html ; https://github.com/yt-dlp/yt-dlp/blob/master/README.md ; https://github.com/nilaoda/N_m3u8DL-RE/blob/main/README.en.md

### ライセンス上の重要事項
2026-10-27時点で公開されている cat-catch リポジトリの `LICENSE` は GPL-3.0。RPLAY同梱の旧 `THIRD_PARTY_NOTICES.md` にある「cat-catch (MIT License)」の記載はリポジトリ全体への現在のライセンス説明としては整合しない。**既存v2.16.0実装の由来とライセンス適合性は再配布前に個別監査が必要**。本変更では cat-catch / Streamlink / yt-dlp / Video DownloadHelper / N_m3u8DL-RE の外部ソースコードを取り込んでいない。参考にしたのは公開されている動作設計のみ。

## 今回の実装

新規 `src/part_commit_core.js` を `src/part_io.js` ビルド時に統合し、以下の証拠を `parts[].partIntegrity`（別音声は `audioRendition.parts[].partIntegrity`）へ記録する。

- `acceptedHls`: パート開始・終了時の HLS 監査カウンタ差分。境界付近のキュー投入と受理は別タイミングなので *approximate_boundary_snapshot* と明示し、厳密なセグメント対ファイル対応とは主張しない。
- `sinkReceipt`: `file_closed_and_readback`（File System Accessの書き込み完了と実ファイルサイズ確認）、`browser_reported_complete`、`not_confirmed`、`write_failed` の別。
- `fileCommitted`: **FILE_CLOSED かつ confirmed の場合に限り true**。永続ディスクへの fsync を保証するものではない。
- `sha256`: 保存済みファイルを読み直した値か、ダウンロード前 Blob から計算した値かを `sha256Provenance` に明記。未取得・不正形式は null。
- `checkpoint`: ディスク復旧用チェックポイントの complete レシートがあり、元ファイルと確定バイト数が整合したときのみ、チャンク数とバイト数を参照。
- `avDecoded:false`: 全編デコード・AV同期・再生可能性はこの監査だけでは判定できない。

署名URL・Cookie・Authorization・通信ヘッダー・セグメントの実データは新規証拠へ記録しない。既存のHTTP再取得・鍵処理・別サイトアクセス権限は変更しない。

## QAと範囲

- Node.js 全件回帰 657/657 PASS。新規パート証拠の10件を含む。
- Python全件試験は今回の実行環境上限で中断（未完走）。Python CLI・HLS Python実装・join tool のソースがv2.42.3と**バイト一致**することを確認。HLSタイミングPython6件はPASS。
- Firefox/Chromium拡張の本番インストール、ニコニコ・Twitch・YouTube・RPLAY実配信、24時間録画、Windows実機、映像音声の全編デコードは本版では未検証。
- DASH MPDは引き続き診断のみ。DRM/暗号保護の回避機能はない。

## 次の優先実装

1. 署名URL・認証値を含まない「セグメントID→書き込みパート」の厳密対応を、取得→append→close処理で一貫して保持する。
2. 既存 `rsp-recovery` のチャンクSHA256レシートと `parts[]` を停止前にも耐障害保存し、クラッシュ復旧後に検証可能な範囲を分ける。
3. 許可された実配信のHLS/LL-HLS負荷テスト、429/403/410と世代切替、Firefox/Floorp MV2とChromium MV3の実挙動検証。
4. FFprobe/FFmpeg等でA/Vタイムスタンプと全編デコードの検査を、保存後の明示操作として追加。
