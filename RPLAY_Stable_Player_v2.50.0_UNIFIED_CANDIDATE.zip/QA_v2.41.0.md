# QA v2.41.0 — 2026-10-27 JST

全回帰746件PASS（Node581/Python165）。構文・manifest参照・core5コピー一致・派生コピー・build再生成byte一致を確認。配布時にZIP CRCと全ファイルhashも照合。

追加14件: RAM候補の重複/TTL/件数/クリア/安全一覧、URL/MIME分類、masterの画質/音声属性・相対URL・非継承署名、危険URL/過大目録/候補過多拒否、目録fetchの資格情報非添付/上限/取消、FFmpeg別音声mapping/quoting、production background observerとinspector fragmentの認可、実inspectorスクリプトの目録取得→映像/音声選択→2入力生成、video/audioの404 FIFO再試行と同一part、404/410の試行上限、記録後quality upgrade抑制。

最初の回帰では既存importScripts配線試験の期待文字列が旧2moduleのままのため1件失敗。新catalogを含む3module配線の期待値に更新し、全回帰を再実行して合格。機能検査の判定は弱めていない。

独立E2E: python3 tests/check_cdn404_decode.py 合格。FFmpeg合成4秒・4segment・映像＋AACをローカルHTTP提供、先頭segmentを初回のみ404。取得順はseg0→seg0再試行→seg1→seg2→seg3、1part、元segment順序付き連結とbyte同一、AV存在、FFmpeg全decode PASS。evidence/v241-current/CDN404_DECODE.json。これは実サービス・長時間の代替ではない。

独立確認: node --test tests/check_recording_during_scan.cjs 2件PASS。模擬Chrome/Firefox hostで予約HTTP待ち中の録画停止が妨げられないことを継承確認。

新webRequest observerと画面はVM/mockによる検証。実ブラウザ（現行Chrome/Firefox/Floorp）でのpermission・観察・保存は未確認。実RPLAY・Windows・2GiB・長時間・native preview進行も未合格。CANDIDATE_NO_GOを維持。

runtimeは全回帰後に変更していない。最終更新は資料と証拠のみ。VDH内部ソースを解析/コピーした版ではなく、公開仕様・RFCから独立実装した候補版。
