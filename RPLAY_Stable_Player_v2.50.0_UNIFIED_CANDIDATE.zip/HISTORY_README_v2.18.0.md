# RPLAY Stable Player v2.18.0 UNIFIED CANDIDATE

TSパケットの構造検査では見逃していたPES切断やAACフレーム境界の異常を、保存前に検出します。さらに、入力AACフレーム数と出力MP4音声サンプル数を照合し、不一致のまま保存を確定しないようにしました。既存の録画、復旧、AES-128、CLI、MP4時刻補正は維持しています。

状態: **CANDIDATE / NO_GO**。実RPLAY・Windows・実拡張導入・実OSファイル選択/保存・長時間運用は未検証です。

## 検証結果

- **476件PASS / 0 FAIL**（Node.js 314 + Python 162）。ソース検証・再ビルドのバイト一致・派生コピー一致を確認。
- 前版の問題を再現: 4秒素材の末尾音声TSパケットを1つ削ると、v2.17.0は189→178 AACフレームの出力を完了扱いにしました。v2.18.0は同じ入力をTS_PES_TRUNCATEDとして、保存先を開く前に拒否します。欠損した音声の修復ではありません。
- 120秒の44.1kHzステレオ/48kHzモノラル、50秒・12Mbps・77,606,776バイトの符号化TSを実ディスク経由で試験。ADTSバイト一致・映像framemd5一致・FFmpegデコード成功・音声映像の開始差保持を確認しました。合成メディアの結果です。

## 使い方

1. ZIPを新しいフォルダーへ展開し、旧版は保持してください。
2. Chrome系の拡張はrplay-stable-player-extension、Firefox系はrplay-stable-player-extension-firefox。未署名の開発候補です。
3. 録画済みTSの変換は、File System Access API対応ブラウザでmp4_convert.htmlを開きます。入力を選び、表示順を確認し、別のMP4へ保存します。
4. 1入力2GiBまで、最大4096本。H.264映像と同じTS内のAACが対象です。全入力の検査後に変換を開始します。実2GiBや数時間の試験は未実施です。
5. 完了画面にSHA-256と音声フレーム照合を表示します。実際の再生・シークも確認してください。元TSは削除しません。

CLIはpython rplay_dl.py --help、結合はrplay_join.pyを継承しています。録画中MP4直接出力・別音声同期合成・任意の破損修復・DRMには対応しません。

API非対応ブラウザでは変換できません。Firefox拡張の収録は、このMP4保存APIのFirefox対応を保証するものではありません。

詳細: [MP4操作と制限](MP4_GUIDE_v2.18.0.md)、[検証報告](QA_v2.18.0.md)、[開発継続資料](DEVELOPMENT_HANDOFF_v2.18.0.md)。旧版説明はHISTORY_README_v2.17.0.md、旧QA/evidenceは各記載版の履歴です。

## 検証の再実行

Node.js 24+、Python 3.11+、FFmpeg/ffprobe（libx264）を用意し、展開先で実行します。

```sh
python scripts/validate.py
```

生成メディア、ローカルHTTP、API/DOMモックによる検証です。RPLAYへのアクセスは行いません。75MB程度の一時メディアと出力を使い、数分かかる場合があります。
