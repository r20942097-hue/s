# v2.33.0

creator_registry.js: target/resolveList/lookupCustom。既存/c/custom/live mountが使うgetuser?customUrl契約を外部画面に独立実装。URLを任意fetchせずAPI固定。resolveListはlookup注入で単体試験。dashboard登録中disabled、失敗時既存storage保持。
次: 実サービス応答fixtureと解決結果の利用者確認、外部登録のwindow間競合/取消、名前cache、予約表示の外部化。
