# v2.39.0 引継ぎ

添付v2.38を基盤に本チャットv2.37のext_glue自動開始制御とbackground設定拒否を再統合。共通JSON・metadata・外部予約は維持。
background.dashboardDefaults: settled guard + 5秒timer、成功/失敗時clear、late callback無視。エラー応答START_SETTINGS_UNAVAILABLE。
offscreen.handleBgSchedScan: 小文字化Set重複除外、日時finite/Date範囲制約、走査全体で近い順500件を保持。配信者間400ms/60秒rate制約は維持。
追加試験: 復元8件、timeout4件、予約集約1件。ID上限試験は重複150→異なるID150の入力へ修正し100件上限を検証。

次: 予約巡回の取消/進捗とpagehide終了、認証供給の独立設計、実応答fixture、全録画経路policyの統一、BG停止後MP4連携。
