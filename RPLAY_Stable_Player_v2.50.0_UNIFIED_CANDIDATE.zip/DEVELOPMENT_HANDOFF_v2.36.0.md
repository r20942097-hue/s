# v2.36.0 開発引継ぎ

dashboard_settings.js: normalize/snapshot/commit。設定保存用lock rsp-dashboard-settings-save-v1。既存undefinedは従来のfollow=true/autoStartAllowed=trueを保持。部分保存objectは従来の各boolean解釈を継承。未知キー・不正type・範囲外splitMinは拒否。保存前に現在storageのsnapshot照合。読込失敗ならbaseline=nullで保存不可。再読込は明示操作で入力破棄。

player.user.js fetchJsonWithRetry: 200応答をgetReader/fatal UTF8 TextDecoderで2 MiBまで読込。宣言長と実byte数を検査。上限/stream非対応はterminal error。通信失敗/不正JSON等の既存再試行は最大2回。finallyでctl.abort、reader.cancel/releaseLock。予約cancelと本文受信timeoutを保持。offscreen_preの独自JSON関数は未変更。

今後: 本物のRPLAY fixture/受入、BG側JSON取得の共通化、登録配信者の名前metadataと外部予約閲覧、native preview環境要因の切分け、Windows/2 GiB/長時間。VDH星は位置と実際のtooltipが確認できるまで意味を断定しない。
