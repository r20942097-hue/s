/* RPLAY 汎用取得ホスト v1 (v2.50.0 — 汎用取得 段階設計 Stage 3 結線).
   Stage 2 エンジン (segment_acquire.js / RspSegmentAcquire) を実環境へ束縛する
   薄い結線層。紀律は Stage 0..2 と完全不変:
     - 既定OFF: settings().segmentAcquire が true のときだけ動作(呼び出し側も二重ガード)
     - 明示候補のみ: dashboard の「取得」ボタン → BG が mediaCatalog の観測候補を解決
     - RAM 1セグメント上限: セグメント受信→即 store へ確定書き込み→参照解放
     - ゼロシークレット: fetch は credentials:'omit'(観測資格情報の送信もしない)。
       URL/トークン/Cookie は一切保持しない(台帳は候補ID・通し番号・バイト数・時刻のみ)
     - fail-closed: 2MiB(プレイリスト)/16MiB(セグメント)上限・HTTPエラーは HTTP_xxx で可視化
     - 非破壊: cancel後もdisk上セグメントは残る(listResidue で列挙)。discard はRAM状態のみ
   変換・連結・エクスポートは本モジュールでは行わない(Stage 3範囲は取得・再開・列挙まで)。 */
(function(root){
'use strict';
function create(deps){
 deps=deps||{};
 const settings=typeof deps.settings==='function'?deps.settings:function(){return {segmentAcquire:false};};
 const storage=deps.storage&&typeof deps.storage.getDirectory==='function'?deps.storage:null;
 const HLS=deps.HLS&&typeof deps.HLS.parse==='function'?deps.HLS:null;
 const fetchImpl=typeof deps.fetchImpl==='function'?deps.fetchImpl:null;
 const sha256=typeof deps.sha256==='function'?deps.sha256:null;
 const now=typeof deps.now==='function'?deps.now:Date.now;
 const acquireTimeoutMs=Number.isSafeInteger(deps.acquireTimeoutMs)&&deps.acquireTimeoutMs>0?deps.acquireTimeoutMs:20000;
 const segmentTimeoutMs=Number.isSafeInteger(deps.segmentTimeoutMs)&&deps.segmentTimeoutMs>0?deps.segmentTimeoutMs:30000;
 const PLAYLIST_CAP=2*1048576, SEGMENT_CAP=16*1048576;
 if(!storage)throw Error('STORAGE_UNAVAILABLE');
 if(!HLS)throw Error('HLS_PARSER_REQUIRED');
 if(!fetchImpl)throw Error('FETCH_REQUIRED');

 /* --- engine store adapter: 実 RspSegmentStore を RspSegmentAcquire 契約へ --- */
 const realStore=root.RspSegmentStore&&root.RspSegmentStore.create?root.RspSegmentStore.create({
  storage:storage,digest:sha256||undefined,now:now,namespace:'acquire'
 }):null;
 if(!realStore)throw Error('STORE_REQUIRED');
 const engineStore={
  async put(o){
   const r=await realStore.put(o.id,o.bytes,{pin:o.pinned===true});
   return {id:r.id,bytes:r.bytes};
  },
  async get(id){const r=await realStore.get(id);return {id:id,bytes:r.bytes,digest:(r.meta&&r.meta.sha256)||null};},
  async meta(id){
   try{const r=await realStore.get(id);return {id:id,bytes:r.meta.bytes,at:r.meta.at,pinned:r.meta.pinned===true};}
   catch(e){return null;}
  },
  list:function(){return realStore.list();},
  sweep:function(){return realStore.sweep();},
  digest:sha256||null
 };

 /* --- OPFS 台帳 (別名前空間: segment sweep の孤児清掃対象外) --- */
 let ledgerCache=null;
 const ledger={
  async read(){
   if(ledgerCache)return ledgerCache;
   try{
    const d=await storage.getDirectory();
    const area=await d.getDirectoryHandle('rsp_seg',{create:true});
    const ns=await area.getDirectoryHandle('acquire_ledger',{create:true});
    const fh=await ns.getFileHandle('state.json');
    const f=await fh.getFile();
    if(f.size>65536)throw Error('LEDGER_TOO_LARGE');
    ledgerCache=JSON.parse(await f.text());
   }catch(e){ledgerCache=null;}
   return ledgerCache;
  },
  write(state){
   ledgerCache=state||null;
   return (async()=>{
    const d=await storage.getDirectory();
    const area=await d.getDirectoryHandle('rsp_seg',{create:true});
    const ns=await area.getDirectoryHandle('acquire_ledger',{create:true});
    const fh=await ns.getFileHandle('state.json',{create:true});
    const w=await fh.createWritable();
    await w.write(new TextEncoder().encode(JSON.stringify(state)));
    await w.close();
   })().catch(function(){ /* 台帳永続化はbest-effort・取得は中断しない */ });
  },
  clear(){
   ledgerCache=null;
   return (async()=>{
    const d=await storage.getDirectory();
    const area=await d.getDirectoryHandle('rsp_seg',{create:true});
    const ns=await area.getDirectoryHandle('acquire_ledger',{create:true});
    try{await ns.getFileHandle('state.json');await ns.removeEntry('state.json');}catch(e){}
   })().catch(function(){});
  }
 };

 /* --- fetch adapters: bounded・no-credentials・fail-closed --- */
 async function fetchTextBounded(url,opts,timeoutMs,log,signal){
  const cap=PLAYLIST_CAP;
  const ac=new AbortController();
  const timer=setTimeout(function(){try{ac.abort();}catch(e){}},timeoutMs||acquireTimeoutMs);
  const onAbort=function(){try{ac.abort();}catch(e){}};
  if(signal){if(signal.aborted)onAbort();else if(signal.addEventListener)signal.addEventListener('abort',onAbort,{once:true});}
  try{
   const res=await fetchImpl(url,{credentials:'omit',redirect:'follow',cache:'no-store',signal:ac.signal});
   if(res.status!==200)return {ok:false,status:res.status};
   const buf=await res.arrayBuffer();
   if(buf.byteLength>cap)return {ok:false,status:0,error:'PLAYLIST_TOO_LARGE'};
   return {ok:true,status:200,json:new TextDecoder().decode(buf)};
  }catch(e){
   if(signal&&signal.aborted)return {ok:false,status:0,aborted:true};
   return {ok:false,status:0,error:String((e&&e.name)||e||'fetch-failed')};
  }finally{
   clearTimeout(timer);
   if(signal&&signal.removeEventListener)signal.removeEventListener('abort',onAbort);
  }
 }
 async function fetchBytesBounded(url,opts){
  const cap=SEGMENT_CAP;
  const timeoutMs=(opts&&opts.timeoutMs)||segmentTimeoutMs;
  const signal=opts&&opts.signal;
  const ac=new AbortController();
  const timer=setTimeout(function(){try{ac.abort();}catch(e){}},timeoutMs);
  const onAbort=function(){try{ac.abort();}catch(e){}};
  if(signal){if(signal.aborted)onAbort();else if(signal.addEventListener)signal.addEventListener('abort',onAbort,{once:true});}
  try{
   const res=await fetchImpl(url,{credentials:'omit',redirect:'follow',cache:'no-store',signal:ac.signal});
   if(res.status!==200)return {ok:false,status:res.status};
   const buf=await res.arrayBuffer();
   if(buf.byteLength>cap)return {ok:false,status:0,error:'SEGMENT_TOO_LARGE'};
   return {ok:true,status:200,bytes:new Uint8Array(buf)};
  }catch(e){
   if(signal&&signal.aborted)return {ok:false,status:0,aborted:true};
   return {ok:false,status:0,error:String((e&&e.name)||e||'fetch-failed')};
  }finally{
   clearTimeout(timer);
   if(signal&&signal.removeEventListener)signal.removeEventListener('abort',onAbort);
  }
 }
 /* hls_transport の parse(クロージャ内関数)をエンジン契約へ包む。
   URL は保持せず解決のみ。legacy モード(録画系と同一の受容範囲)。 */
 function playlistParser(text,baseUrl){
  const p=HLS.parse(text,baseUrl);
  let prevDisc=null;
  const segments=p.segments.map(function(s){
   const discBool=prevDisc!==null&&s.discontinuity!==prevDisc;
   prevDisc=s.discontinuity;
   return {sequence:s.sequence,uri:s.uri,gap:!!s.gap,
    discontinuity:discBool,discontinuitySequence:s.discontinuity};
  });
  return {kind:'media',endList:!!p.endList,segments:segments};
 }

 let engine=null;
 function acquireEnabled(){return settings().segmentAcquire===true;}
 function getEngine(){
  if(!acquireEnabled())return null;
  if(engine)return engine;
  engine=root.RspSegmentAcquire.create({store:engineStore,fetcher:fetchTextBounded,
   fetchSegment:fetchBytesBounded,playlistParser:playlistParser,now:now,ledger:ledger,
   acquireTimeoutMs:acquireTimeoutMs,segmentTimeoutMs:segmentTimeoutMs});
  return engine;
 }
 function disabledResult(){return {ok:false,error:'ACQUIRE_DISABLED'};}
 function validId(id){return typeof id==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(id);}

 async function bootRestore(){
  /* 起動時復帰: 台帳があれば paused 状態で engine へ復元する(未取得分は continueFrom)。
     URL は台帳に無いため再開には候補の再選択が必要(ゼロシークレット契約)。 */
  if(!acquireEnabled())return {ok:false,error:'ACQUIRE_DISABLED'};
  const eng=getEngine();
  const st=await ledger.read();
  if(!st||!st.id||!validId(st.id))return {ok:false,error:'NO_LEDGER'};
  try{
   const known=await realStore.list();
   await eng.restore({id:st.id,candidate:(st.candidate&&typeof st.candidate==='object')?st.candidate:{id:String(st.candidate||'unknown')},
    ledgerState:st,knownSegmentIds:known.map(function(e){return e.id;})});
   return {ok:true,restored:st.id};
  }catch(e){
   return {ok:false,error:String((e&&e.message)||e||'restore-failed')};
  }
 }

 return {
  start:async function(payload){
   if(!acquireEnabled())return disabledResult();
   const p=payload||{};
   if(!validId(p.id))return {ok:false,error:'INVALID_ID'};
   if(typeof p.playlistUrl!=='string'||!/^https:\/\//i.test(p.playlistUrl)||p.playlistUrl.length>4096)
    return {ok:false,error:'INVALID_PLAYLIST_URL'};
   const eng=getEngine();
   const st=await eng.start({id:p.id,
    candidate:{id:String(p.id),type:'hls',source:'dashboard-explicit'},
    initialPlaylistUrl:p.playlistUrl,signal:p.signal||null});
   return {ok:true,status:st};
  },
  continueFrom:async function(payload){
   if(!acquireEnabled())return disabledResult();
   const p=payload||{};
   if(!validId(p.id))return {ok:false,error:'INVALID_ID'};
   if(typeof p.playlistUrl!=='string'||!/^https:\/\//i.test(p.playlistUrl)||p.playlistUrl.length>4096)
    return {ok:false,error:'INVALID_PLAYLIST_URL'};
   const eng=getEngine();
   const st=await eng.continueFrom({id:p.id,playlistUrl:p.playlistUrl,signal:p.signal||null});
   return {ok:true,status:st};
  },
  cancel:function(payload){
   if(!acquireEnabled())return disabledResult();
   const p=payload||{};
   if(!validId(p.id))return {ok:false,error:'INVALID_ID'};
   return {ok:true,cancelled:getEngine().cancel(p.id)};
  },
  status:function(payload){
   if(!acquireEnabled())return disabledResult();
   const p=payload||{};
   if(!validId(p.id))return {ok:false,error:'INVALID_ID'};
   return {ok:true,status:getEngine().status(p.id)};
  },
  list:function(){
   if(!acquireEnabled())return disabledResult();
   return {ok:true,items:getEngine().list()};
  },
  residue:async function(payload){
   if(!acquireEnabled())return disabledResult();
   const p=payload||{};
   if(!validId(p.id))return {ok:false,error:'INVALID_ID'};
   const r=await getEngine().listResidue(p.id);
   return {ok:r!==null,residue:r};
  },
  discard:function(payload){
   if(!acquireEnabled())return disabledResult();
   const p=payload||{};
   if(!validId(p.id))return {ok:false,error:'INVALID_ID'};
   return {ok:true,discarded:getEngine().discard(p.id)};
  },
  stats:function(){
   if(!acquireEnabled())return disabledResult();
   return {ok:true,engineStatus:getEngine().list(),storeStats:null};
  },
  bootRestore:bootRestore,
  acquireEnabled:acquireEnabled,
  _internal:{engineStore:engineStore,ledger:ledger,fetchTextBounded:fetchTextBounded,
   fetchBytesBounded:fetchBytesBounded,playlistParser:playlistParser,getEngine:getEngine}
 };
}
const value={create};
if(typeof module==='object'&&module.exports)module.exports=value;
if(typeof root!=='undefined')root.RspAcquireHost=value;
})(typeof globalThis!=='undefined'?globalThis:this);
