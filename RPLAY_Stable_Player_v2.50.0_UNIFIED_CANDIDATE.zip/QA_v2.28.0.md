# v2.28.0 QA

現在版: evidence/v228-current（Node460/Python165を予定）、evidence/firefox-v228（実Firefox）。最終実測はJSON。
VOD試験7件はHTTP/タイマーのモックと実Response。追加は429中止・401即失敗・待機完了のtimer解放。実サービス受入ではない。
FirefoxはLinux/headless/使い捨てprofile。試験のみsandbox level調整、製品変更なし。ルート検査は実DOM+APIスタブ。preview進行未合格。

最終ZIPはCRC・全SHA台帳を検査し、包装後に追加した証拠/資料以外の全ファイルを試験済み展開ツリーとバイト照合。独立再包装も同一SHAを確認。dashboard.jsの既定表示の最終修正はFirefoxで再試験し、その他のコードは全件試験対象とバイト照合。
