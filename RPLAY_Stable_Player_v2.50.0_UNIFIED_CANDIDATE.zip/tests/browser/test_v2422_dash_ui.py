"""Headless Chromium DOM-only smoke. Does not load the WebExtension or contact media sites."""
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[2]
MPD='''<?xml version="1.0"?><MPD type="dynamic" minimumUpdatePeriod="PT4S"><BaseURL>https://cdn.invalid/HIDDEN?TOKEN=NEVER_VISIBLE</BaseURL><Period><AdaptationSet mimeType="video/mp4"><SegmentTemplate media="seg-$Number$.m4s"/><Representation id="720"/><Representation id="1080"/></AdaptationSet></Period></MPD>'''
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    page=browser.new_page()
    # Running the unmodified HTML and scripts on an isolated document; scripts loaded from local sources.
    html=(ROOT/'src/media_inspect.html').read_text()
    import re
    html=re.sub(r'<script src="[^"]+"></script>','',html)
    page.set_content(html)
    for f in ['hls_transport.js','media_catalog.js','media_inspect_core.js','cross_site_core.js','media_inspect.js']:
        page.add_script_tag(content=(ROOT/'src'/f).read_text())
    page.locator('#url').fill('https://cdn.invalid/master.mpd?session=SECRET_URL')
    page.locator('#body').fill(MPD)
    page.locator('#crossSiteInspect').click()
    detail=page.locator('#crossSiteReport').inner_text()
    assert '"kind": "dash"' in detail and '"representations": 2' in detail
    assert 'HIDDEN' not in detail and 'SECRET_URL' not in detail
    print('PASS DASH cross-site report counts and redaction')
    page.locator('#inspect').click()
    report=page.locator('#result').inner_text()
    assert '"stage": "DASH_LIVE_DIAGNOSTICS"' in report
    assert 'HIDDEN' not in report and 'SECRET_URL' not in report
    print('PASS main inspector DASH path and redaction')
    # No network; explicitly stub the transport, exercise candidate mode and checkbox.
    page.evaluate('''() => { window.__loads=[]; RspMediaCatalog.loadDASH=async (url,opts)=>{window.__loads.push({url,cookies:opts.useCookies});return {body:'<MPD><Period/></MPD>',rows:[]};}; }''')
    page.locator('#useCookies').check()
    page.locator('#loadManifest').click()
    page.wait_for_function("document.getElementById('manifestStatus').textContent.includes('DASH MPD')")
    loads=page.evaluate('window.__loads')
    assert len(loads)==1 and loads[0]['cookies'] is True
    assert loads[0]['url']=='https://cdn.invalid/master.mpd?session=SECRET_URL'
    assert 'DASH_VOD_DIAGNOSTICS' in page.locator('#result').inner_text()
    print('PASS user-triggered DASH path, original signed URL and Cookie opt-in')
    browser.close()
