const {test}=require('node:test'),assert=require('node:assert/strict');
const Gate=require('../rplay-stable-player-extension/session_gate.js');
const oid='a'.repeat(24),otherOid='b'.repeat(24),owner={tabId:1,documentId:'doc1',clientId:'1'.repeat(32)},other={tabId:2,documentId:'doc2',clientId:'2'.repeat(32)};
function setup(){let epoch=0,id=0;const gate=Gate.create(()=>String(++id),()=>++epoch);const begin=gate.begin(owner,oid);gate.activate(begin.binding);return {gate,binding:begin.binding,ref:gate.status(owner,oid).control};}
test('owner with exact session/epoch/creator may control',()=>{const {gate,ref}=setup();assert(gate.authorize(owner,ref));});
test('same creator on another tab cannot stop or update auth',()=>{const {gate,ref}=setup();assert(!gate.authorize(other,ref));});
test('new document in the same tab has no implicit authority',()=>{const {gate,ref}=setup();assert(!gate.authorize({...owner,documentId:'newdoc'},ref));});
test('same tab fallback nonce distinguishes Firefox reload',()=>{const {gate,ref}=setup();assert(!gate.authorize({...owner,clientId:'f'.repeat(32)},ref));});
test('wrong creator rejected even for owner',()=>{const {gate,ref}=setup();assert(!gate.authorize(owner,{...ref,oid:otherOid}));});
test('missing control token rejected',()=>{const {gate}=setup();assert(!gate.authorize(owner,{}));});
test('explicit claim rotates epoch and revokes previous owner',()=>{const {gate,ref}=setup();const r=gate.claim(other,ref);assert(r.ok);assert(r.control.epoch>ref.epoch);assert(gate.authorize(other,r.control));assert(!gate.authorize(owner,ref));});
test('stale claim compare-and-swap rejected',()=>{const {gate,ref}=setup();gate.claim(other,ref);assert(!gate.claim(owner,ref).ok);});
test('draining blocks claim, stop, and new starts',()=>{const {gate,binding,ref}=setup();gate.draining(binding);assert(!gate.claim(other,ref).ok);assert(!gate.authorize(owner,ref));assert.equal(gate.begin(other,otherOid).error,'draining');});
test('new session never accepts a previous session identifier',()=>{const {gate,binding,ref}=setup();gate.end(binding);const n=gate.begin(owner,oid);gate.activate(n.binding);assert(!gate.authorize(owner,ref));assert.notEqual(gate.status(owner,oid).control.sessionId,ref.sessionId);});
test('closing an old binding cannot close a newer session',()=>{const {gate,binding}=setup();gate.end(binding);const n=gate.begin(other,oid);gate.activate(n.binding);gate.end(binding);assert(gate.status(other,oid).canControl);});
test('starting reserves the recorder before async work',()=>{let e=0;const gate=Gate.create(()=> 'random',()=>++e);assert(gate.begin(owner,oid).ok);assert.equal(gate.begin(other,otherOid).error,'busy');});
test('epoch persistence failure never grants permission',()=>{const gate=Gate.create(()=> 'id',()=>{throw Error('storage failed')});assert.throws(()=>gate.begin(owner,oid));assert.equal(gate.binding(),null);});
test('public status exposes no control for non-owner or other creator',()=>{const {gate}=setup();assert.equal(gate.status(other,oid).control,null);assert.equal(gate.status(owner,otherOid).claim,null);});
test('malformed identity and creator are rejected before allocation',()=>{const gate=Gate.create(()=> 'id',()=>1);assert(!gate.begin({...owner,clientId:''},oid).ok);assert(!gate.begin(owner,'bad').ok);assert.equal(gate.binding(),null);});
