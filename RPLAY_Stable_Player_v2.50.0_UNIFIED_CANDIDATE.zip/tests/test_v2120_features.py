"""v2.12.0 feature acceptance (4-branch unification + cat-catch learnings):
1. cat-catch TS disguise header stripping (PNG/GIF/BMP/JPEG/WEBP disguise prefix before 0x47 sync bytes) in hls_strip_disguised_ts & hls_validate.
2. cat-catch M3U8 query-parameter inheritance (--inherit-query) in hls_parse / hls_url.
3. cat-catch m3u8dl:// protocol URI & N_m3u8DL-RE command builder (build_m3u8dl_export) and zero-secret externalDownloaderEvidence.
4. E2E CLI recording of disguised TS segments (PNG header prepended to each TS segment) + query-inherited relative segment URLs into a single clean TS file.
5. Unified coexistence of v2.9.1 acceptance_report.py (with v2.12.0 evidence blocks), v2.10.0 AGGREGATE rplay_join.py, and v2.10.0 UNIFIED concat_media_parts.
Local HTTP only — VM-safe."""
import http.server,threading,tempfile,pathlib,subprocess,sys,json,unittest,base64
import importlib.util

R=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('v2120feat',R/'rplay_dl.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


class UnitV2120Features(unittest.TestCase):
    def test_ts_disguise_stripping_and_validation(self):
        valid_ts=(b'\x47'+b'\x00'*187)*3
        png_hdr=b'\x89PNG\r\n\x1a\n'+b'\x11'*24
        disguised=png_hdr+valid_ts
        clean,stripped,magic=m.hls_strip_disguised_ts(disguised)
        self.assertEqual(stripped,32)
        self.assertEqual(magic,'png')
        self.assertEqual(clean,valid_ts)
        # hls_validate('ts') returns the stripped valid TS bytes
        validated=m.hls_validate(disguised,'ts')
        self.assertEqual(validated,valid_ts)
        # Non-magic random prefix before TS must still raise HLS_BAD_TS
        with self.assertRaisesRegex(ValueError,'HLS_BAD_TS'):
            m.hls_validate(b'\x00\x01\x02\x03'+valid_ts,'ts')

    def test_m3u8_query_inheritance(self):
        m3u8=('#EXTM3U\n#EXT-X-TARGETDURATION:2\n'
              '#EXT-X-MAP:URI="init.mp4"\n'
              '#EXTINF:1,\nseg0.ts\n'
              '#EXTINF:1,\nseg1.ts?custom=1&sig=SEG_SIG\n')
        base='https://cdn.example/live/master.m3u8?sig=PLAYLIST_SIG&key2=KEY2_VAL'
        p_def=m.hls_parse(m3u8,base,'legacy',inherit_query=False)
        self.assertEqual(p_def['segments'][0]['uri'],'https://cdn.example/live/seg0.ts')
        self.assertEqual(p_def['segments'][0]['map']['uri'],'https://cdn.example/live/init.mp4')

        p_inh=m.hls_parse(m3u8,base,'legacy',inherit_query=True)
        self.assertEqual(p_inh['segments'][0]['uri'],'https://cdn.example/live/seg0.ts?sig=PLAYLIST_SIG&key2=KEY2_VAL')
        self.assertEqual(p_inh['segments'][0]['map']['uri'],'https://cdn.example/live/init.mp4?sig=PLAYLIST_SIG&key2=KEY2_VAL')
        self.assertEqual(p_inh['segments'][1]['uri'],'https://cdn.example/live/seg1.ts?custom=1&sig=SEG_SIG&key2=KEY2_VAL')

    def test_m3u8dl_protocol_and_zero_secret_evidence(self):
        exp=m.build_m3u8dl_export(
            'https://cdn.example/live/stream.m3u8?sig=TOPSECRET&key2=K2',
            'RPLAY_creator_20261026',
            {'Referer':'https://rplay.live/','User-Agent':'TestUA','Authorization':'JWT_SECRET'},
            live_real_time_merge=True
        )
        self.assertTrue(exp['protocolUri'].startswith('m3u8dl://'))
        raw=base64.b64decode(exp['protocolUri'][len('m3u8dl://'):]).decode('utf-8')
        self.assertIn('https://cdn.example/live/stream.m3u8?sig=TOPSECRET&key2=K2',raw)
        self.assertIn('--save-name "RPLAY_creator_20261026"',raw)
        self.assertIn('--live-real-time-merge',raw)
        ev=m.external_downloader_evidence(exp,{'tsDisguiseStrippedCount':3,'tsDisguiseBytesTotal':96,'queryInheritedCount':4})
        self.assertEqual(ev['targetUrl'],'https://cdn.example/live/stream.m3u8')
        dump=json.dumps(ev)
        self.assertNotIn('TOPSECRET',dump)
        self.assertNotIn('JWT_SECRET',dump)
        self.assertEqual(ev['headerKeys'],['Authorization','Referer','User-Agent'])
        self.assertEqual(ev['tsDisguiseStrippedCount'],3)

    def test_acceptance_report_supports_v2120_evidence_blocks(self):
        aspec=importlib.util.spec_from_file_location('acc2120',R/'scripts'/'acceptance_report.py')
        acc=importlib.util.module_from_spec(aspec);aspec.loader.exec_module(acc)
        self.assertIn('partContinuityEvidence',acc.EVIDENCE_BLOCKS)
        self.assertIn('partBoundaryEvidence',acc.EVIDENCE_BLOCKS)
        self.assertIn('aggregationEvidence',acc.EVIDENCE_BLOCKS)
        self.assertIn('externalDownloaderEvidence',acc.EVIDENCE_BLOCKS)


class E2EV2120Features(unittest.TestCase):
    def test_cli_disguised_ts_and_inherited_query_records_clean_ts_and_emits_evidence(self):
        """cat-catch知見E2E:
        1) 相対セグメントURLにM3U8のクエリパラメータ(?token=REQ_TOKEN)がなければ403を返すサーバーに対し、
           --inherit-query でクエリを自動継承して取得成功する。
        2) セグメント先頭にPNG偽装ヘッダ(24バイト)が付与されていても、自動除去して純粋な188バイト境界TSとして保存し、
           externalDownloaderEvidence に tsDisguiseStrippedCount / queryInheritedCount を記録する(秘密は非出力)。"""
        playlist=('#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:0\n'
                  '#EXTINF:1,\nseg0.ts\n#EXTINF:1,\nseg1.ts\n#EXT-X-ENDLIST\n')
        pure_seg=(b'\x47'+b'\x22'*187)*5
        png_disguised_seg=b'\x89PNG\r\n\x1a\n'+b'\x00'*16+pure_seg
        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self,*a):pass
            def _send(s,code,body=b''):
                s.send_response(code);s.send_header('Content-Length',str(len(body)));s.end_headers();s.wfile.write(body)
            def do_GET(s):
                path,_,q=s.path.partition('?')
                if path=='/api/live/play':
                    s._send(200,json.dumps({'streamState':'live','accessible':True,'allowAnonymous':True,'title':'CatCatchTest'}).encode());return
                if path=='/live.m3u8':
                    s._send(200,playlist.encode());return
                if path in ('/seg0.ts','/seg1.ts'):
                    # Require inherited token=REQ_SECRET from /live.m3u8?token=REQ_SECRET
                    if 'token=REQ_SECRET' not in q:
                        s._send(403,b'Missing inherited token');return
                    s._send(200,png_disguised_seg);return
                s._send(404)
        srv=http.server.ThreadingHTTPServer(('127.0.0.1',0),H)
        threading.Thread(target=srv.serve_forever,daemon=True).start()
        url='http://127.0.0.1:%d'%srv.server_port
        try:
            with tempfile.TemporaryDirectory() as d:
                dp=pathlib.Path(d)
                cmd=[sys.executable,str(R/'rplay_dl.py'),'a'*24,'--api',url+'/api',
                     '--m3u8',url+'/live.m3u8?token=REQ_SECRET','--inherit-query',
                     '--no-follow','--no-flv','--mux','no','--out',d,'--info-json']
                p=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                info=json.loads(next(dp.glob('*_info.json')).read_text())
                self.assertEqual(len(info['parts']),1)
                # Saved TS file must have the 24-byte PNG disguise stripped from both segments!
                ts_file=dp/info['parts'][0]['file']
                self.assertEqual(ts_file.read_bytes(),pure_seg*2)
                ext_ev=info.get('externalDownloaderEvidence')
                self.assertIsInstance(ext_ev,dict)
                self.assertEqual(ext_ev['tsDisguiseStrippedCount'],2)
                self.assertEqual(ext_ev['tsDisguiseBytesTotal'],48)
                self.assertGreaterEqual(ext_ev['queryInheritedCount'],2)
                self.assertNotIn('REQ_SECRET',json.dumps(info))
        finally:
            srv.shutdown();srv.server_close()

    def test_cli_print_m3u8dl_outputs_protocol_and_command(self):
        with tempfile.TemporaryDirectory() as d:
            cmd=[sys.executable,str(R/'rplay_dl.py'),'a'*24,
                 '--m3u8','https://cdn.example/live/stream.m3u8?sig=MY_SIG',
                 '--print-m3u8dl','--out',d]
            p=subprocess.run(cmd,capture_output=True,text=True,timeout=30)
            self.assertEqual(p.returncode,0,p.stdout+p.stderr)
            out=json.loads(p.stdout)
            self.assertTrue(out['protocolUri'].startswith('m3u8dl://'))
            self.assertIn('N_m3u8DL-RE',out['command'])


if __name__=='__main__':unittest.main()
