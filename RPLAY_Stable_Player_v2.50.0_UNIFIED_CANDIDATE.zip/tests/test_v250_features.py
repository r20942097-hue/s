"""v2.5.0 feature acceptance: EXTINF modes, generation recovery, URL redaction,
save ledger contract, ffprobe quality audit, segindex restart dedup, heartbeat/
healthcheck, stop-file, webhook, FIFO shadow evidence, orphan ledger, guards."""
import http.server,threading,tempfile,pathlib,subprocess,sys,json,re,hashlib,time,os,errno,unittest
import importlib.util
from unittest.mock import patch
R=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('v250',R/'rplay_dl.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
BASE='https://fixtures.invalid/live.m3u8'
def playlist(x):return '#EXTM3U\n#EXT-X-TARGETDURATION:1\n'+x

def ts_payload(n,sync=True):
    b=bytearray([0x47]+[n%251]*187)
    if not sync:b[0]=0x00
    return bytes(b)*5

class Receiver:
    def __init__(self):
        self.events=[]
        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self,*a):pass
            def do_POST(s):
                n=int(s.headers.get('Content-Length') or 0);body=s.rfile.read(n)
                s.send_response(200);s.send_header('Content-Length','2');s.end_headers();s.wfile.write(b'ok')
                self.events.append(json.loads(body.decode('utf-8','replace')))
        self.server=http.server.ThreadingHTTPServer(('127.0.0.1',0),H)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
    @property
    def url(self):return 'http://127.0.0.1:%d/hook'%self.server.server_port
    def close(self):self.server.shutdown();self.server.server_close();self.thread.join(2)

class SeqServer:
    """Serves an api, a fixed m3u8 list per request (round-robin), and /segN.ts."""
    def __init__(self,playlists,payloads=None):
        self.playlists=playlists;self.payloads=payloads or {};self.n=0;self.requests=[]
        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self,*a):pass
            def do_GET(s):
                path=s.path.split('?')[0];self.requests.append(path)
                if path=='/api/live/play' or path.startswith('/api/'):
                    body=json.dumps({'streamState':'live','accessible':True,'allowAnonymous':True}).encode()
                elif path=='/live.m3u8':
                    i=min(self.n,len(self.playlists)-1);self.n+=1
                    body=self.playlists[i].encode()
                else:
                    body=self.payloads.get(path.lstrip('/')) or ts_payload(abs(hash(path))%251)
                s.send_response(200);s.send_header('Content-Length',str(len(body)));s.end_headers();s.wfile.write(body)
        self.server=http.server.ThreadingHTTPServer(('127.0.0.1',0),H)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
    @property
    def url(self):return 'http://127.0.0.1:%d'%self.server.server_port
    def close(self):self.server.shutdown();self.server.server_close();self.thread.join(2)

def run_cli(url,out,*extra,timeout=40):
    cmd=[sys.executable,str(R/'rplay_dl.py'),'a'*24,'--api',url+'/api','--m3u8',url+'/live.m3u8','--no-follow','--no-flv','--mux','no','--out',str(out)]+list(extra)
    return subprocess.run(cmd,capture_output=True,text=True,timeout=timeout)

class UnitV250(unittest.TestCase):
    def test_guard_low_semantics(self):
        self.assertTrue(m.guard_low(None,10));self.assertTrue(m.guard_low(float('nan'),10))
        self.assertTrue(m.guard_low('x',10));self.assertTrue(m.guard_low(5,10));self.assertFalse(m.guard_low(50,10))
        self.assertTrue(m.guard_low(10,10))
    def test_redact_url_strips_query_and_fragment(self):
        self.assertEqual(m.redact_url('https://cdx.example/path/seg.ts?X-Amz-Signature=SECRET&key2=K#f'),'https://cdx.example/path/seg.ts')
        self.assertEqual(m.redact_url('https://cdx.example/path/seg.ts'),'https://cdx.example/path/seg.ts')
        self.assertEqual(m.redact_url(''),'')
        self.assertEqual(m.redact_url(None),None)
    def test_extinf_mode_rfc_rejects_missing_extinf(self):
        with self.assertRaisesRegex(ValueError,'HLS_EXTINF_REQUIRED'):m.hls_parse(playlist('a.ts'),BASE,'rfc')
        self.assertEqual(len(m.hls_parse(playlist('a.ts'),BASE,'legacy')['segments']),1)
        self.assertEqual(len(m.hls_parse(playlist('#EXTINF:1,\na.ts'),BASE,'rfc')['segments']),1)
    def test_seg_key_is_path_and_range_only(self):
        self.assertEqual(m.seg_key({'hls':{'uri':'https://x/p/s1.ts?sig=A','range':None}}),'https://x/p/s1.ts')
        self.assertEqual(m.seg_key({'hls':{'uri':'https://x/p/s1.ts?sig=A','range':{'offset':0,'length':188}}}),'https://x/p/s1.ts|{"length": 188, "offset": 0}')
        self.assertEqual(m.seg_key({'base':'','name':'rel.ts'}),'rel.ts')
    def test_heartbeat_fresh(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'heartbeat.json';self.assertFalse(m.heartbeat_fresh(str(p))[0])
            p.write_text(json.dumps({'ts':time.time()}));self.assertTrue(m.heartbeat_fresh(str(p))[0])
            p.write_text(json.dumps({'ts':time.time()-9999}));self.assertFalse(m.heartbeat_fresh(str(p))[0])
    def test_qaudit_part_verdict_pass_on_valid_media(self):
        if not m.ffprobe_tool():self.skipTest('ffprobe required')
        with tempfile.TemporaryDirectory() as d:
            ts=pathlib.Path(d)/'v.ts'
            subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-f','lavfi','-i','testsrc2=size=128x72:rate=12','-t','1','-an','-c:v','libx264','-preset','ultrafast','-f','mpegts',str(ts)],check=True,capture_output=True,timeout=20)
            r=m.qaudit_part(str(ts))
            self.assertEqual(r['verdict'],'pass',json.dumps(r)[:400])
            self.assertEqual(r['provenance'],'decoded');self.assertTrue(r['streams']);self.assertFalse(r['decodeErrors'])
            v=[s for s in r['streams'] if s['codecType']=='video'][0]
            self.assertEqual(v['codec'],'h264');self.assertTrue(v['timeBase'])
    def test_qaudit_part_flags_corrupt_media(self):
        if not m.ffprobe_tool():self.skipTest('ffprobe required')
        with tempfile.TemporaryDirectory() as d:
            bad=pathlib.Path(d)/'bad.ts';bad.write_bytes(b'\x47'+os.urandom(187*40))
            r=m.qaudit_part(str(bad))
            self.assertIn(r['verdict'],('decode_errors','pts_regression','probe_failed'))
    def test_generation_recovery_cross_language_parity(self):
        cases=[('#EXT-X-MEDIA-SEQUENCE:4\na.ts?sig=old','#EXT-X-MEDIA-SEQUENCE:4\na.ts?sig=new','#EXT-X-MEDIA-SEQUENCE:1\na.ts','#EXT-X-MEDIA-SEQUENCE:0\nnew1.ts\nnew2.ts'),
               ('#EXT-X-MEDIA-SEQUENCE:5\nseg5.ts','#EXT-X-MEDIA-SEQUENCE:5\nother5.ts','#EXT-X-MEDIA-SEQUENCE:9\nzz9.ts')]
        js="const H=require('./src/hls_transport.js');let v='';process.stdin.on('data',x=>v+=x);process.stdin.on('end',()=>process.stdout.write(JSON.stringify(JSON.parse(v).map(pls=>{const o={seen:new Set(),queue:[]};for(const p of pls){H.enqueue(o,H.parse(p[0],p[1]),p[1]);}return o._hlsRecovery;}))));"
        r=subprocess.run(['node','-e',js],cwd=R,text=True,input=json.dumps([[ [playlist(p),BASE] for p in case] for case in cases]),capture_output=True,check=True)
        js_results=json.loads(r.stdout)
        for case,expected in zip(cases,js_results):
            class O:pass
            o=O();o.seen=set();o.queue=[]
            for p in case:m.hls_enqueue(o,m.hls_parse(playlist(p),BASE),BASE)
            self.assertEqual(o._hls_state['recovery'],expected)

class E2EV250(unittest.TestCase):
    def test_ledger_contract_and_qaudit_and_redaction(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);out=root/'out';media=root/'media';media.mkdir();out.mkdir()
            subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-f','lavfi','-i','testsrc2=size=128x72:rate=12','-t','2','-an','-c:v','libx264','-preset','ultrafast','-g','12','-sc_threshold','0','-f','hls','-hls_time','1','-hls_segment_filename',str(media/'seg%d.ts'),str(media/'live.m3u8')],check=True,capture_output=True,timeout=20)
            text=(media/'live.m3u8').read_text()
            class H(http.server.BaseHTTPRequestHandler):
                def log_message(self,*a):pass
                def do_GET(s):
                    path=s.path.split('?')[0]
                    if path.startswith('/api/'):body=json.dumps({'streamState':'live','accessible':True,'allowAnonymous':True}).encode()
                    elif path=='/live.m3u8':body=text.encode()
                    else:body=(media/path.lstrip('/')).read_bytes()
                    s.send_response(200);s.send_header('Content-Length',str(len(body)));s.end_headers();s.wfile.write(body)
            server=http.server.ThreadingHTTPServer(('127.0.0.1',0),H);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            try:
                url='http://127.0.0.1:'+str(server.server_port)
                p=run_cli(url,out,'--info-json')
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                led=json.loads((out/('RPLAY_'+'a'*24+'_ledger.json')).read_text())
                self.assertEqual(led['browserStageApplicable'],False)
                self.assertEqual(len(led['parts']),1)
                stages=[s['stage'] for s in led['parts'][0]['stages']]
                self.assertEqual(stages,['REQUESTED','FILE_WRITTEN','HASHED','DECODED/CONTINUITY'],json.dumps(led)[:500])
                if m.ffprobe_tool():
                    self.assertEqual(led['parts'][0]['auditVerdict'],'pass')
                    self.assertEqual(led['parts'][0]['status'],'SUCCESS_DECODED_CONTINUOUS')
                info=json.loads(next(out.glob('*_info.json')).read_text())
                self.assertEqual(info['saveLedger']['contract'],'REQUESTED->FILE_WRITTEN->BROWSER_DONE->HASHED->DECODED/CONTINUITY')
                if m.ffprobe_tool():
                    self.assertEqual(info['qualityAudit']['verdicts'][led['parts'][0]['file']],'pass')
                    self.assertEqual(info['qualityAudit']['provenance'],'decoded')
                self.assertEqual(info['queueOrder']['videoFifoViolations'],0)
                self.assertEqual(info['queueOrder']['videoEnqueued'],info['queueOrder']['videoDrained'])
                self.assertIn('generationRecovery',info)
                self.assertEqual((out/'heartbeat.json').exists(),True)
                self.assertFalse(list(out.glob('*.part')))
            finally:server.shutdown();server.server_close();thread.join(2)
    def test_healthcheck_mode(self):
        with tempfile.TemporaryDirectory() as d:
            fresh=pathlib.Path(d);(fresh/'heartbeat.json').write_text(json.dumps({'ts':time.time(),'state':'RUN','seg':3,'parts':1,'saveErrors':0}))
            p=subprocess.run([sys.executable,str(R/'rplay_dl.py'),'--healthcheck',str(fresh)],capture_output=True,text=True,timeout=10)
            self.assertEqual(p.returncode,0);self.assertIn('healthy',p.stdout)
            stale=pathlib.Path(d)/'stale';stale.mkdir();(stale/'heartbeat.json').write_text(json.dumps({'ts':time.time()-9999}))
            p=subprocess.run([sys.executable,str(R/'rplay_dl.py'),'--healthcheck',str(stale)],capture_output=True,text=True,timeout=10)
            self.assertEqual(p.returncode,1)
            p=subprocess.run([sys.executable,str(R/'rplay_dl.py'),'--healthcheck',str(pathlib.Path(d)/'missing')],capture_output=True,text=True,timeout=10)
            self.assertEqual(p.returncode,1)
    def test_stop_file_graceful_stop(self):
        pls=[('#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:%d\n'%seq)+''.join('#EXTINF:2,\nseg%d.ts\n'%i for i in range(seq,seq+2)) for seq in (0,2,4,6,8,10)]
        srv=SeqServer(pls)
        try:
            with tempfile.TemporaryDirectory() as d:
                out=pathlib.Path(d)
                th=threading.Timer(1.2,lambda:(out/'.rplay_stop').write_text(''))
                th.start()
                p=run_cli(srv.url,out,timeout=30)
                th.join()
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                self.assertIn('stop-file',p.stdout)
                self.assertFalse((out/'.rplay_stop').exists())
                hb=json.loads((out/'heartbeat.json').read_text());self.assertEqual(hb['state'],'IDLE')
        finally:srv.close()
    def test_webhook_events_and_info_redaction(self):
        pls=['#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:1,\nseg0.ts?X-Amz-Signature=TOPSECRET\n#EXT-X-ENDLIST\n']
        srv=SeqServer(pls)
        rec=Receiver()
        try:
            with tempfile.TemporaryDirectory() as d:
                out=pathlib.Path(d)
                p=run_cli(srv.url,out,'--info-json','--webhook',rec.url,timeout=30)
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                names=[e['event'] for e in rec.events]
                self.assertIn('start',names);self.assertIn('part',names);self.assertIn('end',names)
                part=[e for e in rec.events if e['event']=='part'][0]
                self.assertIn('sha256',part)
                info=json.loads(next(out.glob('*_info.json')).read_text())
                raw=json.dumps(info)
                self.assertNotIn('TOPSECRET',raw)
                self.assertNotIn('X-Amz-Signature',raw)
                self.assertNotIn('?',info['playlist'])
        finally:srv.close();rec.close()
    def test_extinf_rfc_mode_rejects_and_legacy_accepts(self):
        no_extinf='#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:0\nseg0.ts\n#EXT-X-ENDLIST\n'
        srv=SeqServer([no_extinf])
        try:
            with tempfile.TemporaryDirectory() as d:
                out=pathlib.Path(d)
                p=run_cli(srv.url,out,'--info-json','--extinf-mode','rfc',timeout=20)
                self.assertEqual(p.returncode,2,p.stdout+p.stderr)
                self.assertIn('HLS_EXTINF_REQUIRED',p.stdout)
        finally:srv.close()
        srv=SeqServer([no_extinf])
        try:
            with tempfile.TemporaryDirectory() as d:
                out=pathlib.Path(d)
                p=run_cli(srv.url,out,'--info-json','--extinf-mode','legacy',timeout=20)
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                info=json.loads(next(out.glob('*_info.json')).read_text())
                self.assertEqual(info['extinfMode'],'legacy')
                led=json.loads((out/('RPLAY_'+'a'*24+'_ledger.json')).read_text())
                # 実メディアでない合成TSはffprobe監査で失敗が記録される(偽の合格にしない)
                self.assertIn(led['parts'][0]['status'],('CONFIRMED_HASHED','AUDIT_probe_failed','AUDIT_decode_errors'))
                self.assertIn('HASHED',[x['stage'] for x in led['parts'][0]['stages']])
        finally:srv.close()
    def test_stale_playlist_not_rerecorded_with_evidence(self):
        # 起動時のprobe()が先頭のプレイリストを1件消費するため、Aを重ねて並べる:
        # probe(A) → poll1(A=initial) → poll2(B=progress) → poll3(A=stale)
        # → poll4(B=既知のみ) → poll5(END)
        A='#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:1,\nseg0.ts\n#EXTINF:1,\nseg1.ts\n'
        B='#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:2\n#EXTINF:1,\nseg2.ts\n#EXTINF:1,\nseg3.ts\n'
        END='#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:4\n#EXTINF:1,\nseg4.ts\n#EXT-X-ENDLIST\n'
        srv=SeqServer([A,A,B,A,B,END],payloads={('seg%d.ts'%i):ts_payload(i) for i in range(5)})
        try:
            with tempfile.TemporaryDirectory() as d:
                out=pathlib.Path(d)
                p=run_cli(srv.url,out,'--info-json',timeout=40)
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                info=json.loads(next(out.glob('*_info.json')).read_text())
                rec=info['generationRecovery']['video']
                self.assertGreaterEqual(rec['staleResponses'],1,rec)
                self.assertEqual(rec['lastKind'],'progress',rec)
                # only 5 unique segments recorded — no duplicated bytes
                files=list(out.glob('*.ts'));self.assertEqual(len(files),1)
                expected=b''.join(ts_payload(i) for i in range(5))
                self.assertEqual(files[0].read_bytes(),expected)
                self.assertEqual(info['queueOrder']['videoFifoViolations'],0)
        finally:srv.close()
    def test_uri_rotation_detected_and_recorded(self):
        # probe(A) → poll1(A=initial) → poll2(B=同一番号・新path→rotation)
        # → poll3(END=fin2)
        A='#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:1,\nold0.ts\n#EXTINF:1,\nold1.ts\n'
        B='#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:1,\nnew0.ts\n#EXTINF:1,\nnew1.ts\n'
        END='#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:2\n#EXTINF:1,\nfin2.ts\n#EXT-X-ENDLIST\n'
        srv=SeqServer([A,A,B,END])
        try:
            with tempfile.TemporaryDirectory() as d:
                out=pathlib.Path(d)
                p=run_cli(srv.url,out,'--info-json',timeout=40)
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                info=json.loads(next(out.glob('*_info.json')).read_text())
                rec=info['generationRecovery']['video']
                self.assertGreaterEqual(rec['uriRotations'],1,rec)
                # old + new + fin all recorded (rotation must not drop new media).
                # 世代境界でパート分割されるため2本になる(仕様どおり — 古い世代と
                # 新しい世代を別パートに分けて混在させない)
                files=list(out.glob('*.ts'));self.assertEqual(len(files),2)
                self.assertEqual(sum(pp['segments'] for pp in info['parts']),5)
        finally:srv.close()
    def test_segindex_restart_dedup(self):
        pls=['#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:1,\nseg0.ts\n#EXTINF:1,\nseg1.ts\n#EXT-X-ENDLIST\n']
        srv=SeqServer(pls)
        try:
            with tempfile.TemporaryDirectory() as d:
                out=pathlib.Path(d)
                p1=run_cli(srv.url,out,'--info-json','--segindex',timeout=30)
                self.assertEqual(p1.returncode,0,p1.stdout+p1.stderr)
                seg=pathlib.Path(out)/('RPLAY_'+'a'*24+'_segindex.json')
                self.assertTrue(seg.exists())
                raw=seg.read_text();self.assertNotIn('sig=',raw)  # no signed URLs at rest
                first=json.loads(next(out.glob('*_info.json')).read_text())
                self.assertEqual(first['segments'],2)
                srv.n=0
                p2=run_cli(srv.url,out,'--info-json','--segindex',timeout=30)
                self.assertEqual(p2.returncode,0,p2.stdout+p2.stderr)
                self.assertIn('segindex読込',p2.stdout)
                # 2回目は既知鍵で全セグメントが重複排除される → 0件・情報JSON無し
                self.assertIn('/ seg0 /',p2.stdout)
                self.assertEqual(len(list(out.glob('*_info.json'))),1)
                self.assertEqual(len(list(out.glob('*.ts'))),1)
        finally:srv.close()
    def test_orphan_ledger_report_only(self):
        with tempfile.TemporaryDirectory() as d:
            out=pathlib.Path(d);(out/'RPLAY_x.part').write_bytes(b'orphan-data-123')
            class O:pass
            o=O();o.out_dir=str(out);o.log=lambda *a:None
            m.Dl.recover_orphan_parts(o)
            self.assertEqual(len(o.recovered_orphans),1)
            self.assertEqual(o.recovered_orphans[0]['sha256'],hashlib.sha256(b'orphan-data-123').hexdigest())
            led=json.loads((out/'orphan_ledger.json').read_text())
            self.assertEqual(led['policy'],'report_only_no_promotion')
            self.assertTrue((out/'RPLAY_x.part').exists())  # never promoted/deleted
    def test_stdin_target(self):
        p=subprocess.run([sys.executable,str(R/'rplay_dl.py'),'-','--once','--api','http://127.0.0.1:1'],input='https://rplay.live/live/'+'b'*24+'\n',capture_output=True,text=True,timeout=15)
        self.assertIn('b'*24,p.stdout)
        self.assertIn('標準入力から対象を読込みました',p.stdout)
        empty=subprocess.run([sys.executable,str(R/'rplay_dl.py'),'-','--once','--api','http://127.0.0.1:1'],input='\n',capture_output=True,text=True,timeout=15)
        self.assertEqual(empty.returncode,1)
    def test_enospc_write_failure_classified(self):
        import io
        r=m.Dl.__new__(m.Dl)
        r.out_dir='/tmp';r.wlock=threading.Lock();r.log=lambda *a:None;r.save_errors=[];r._failed_media=set();r.state='RUN';r.parts_log=[];r.audio_parts_log=[];r.seg_part=0
        r.part_open=True;r.part_name='x.ts';r.part_tmp_path='/tmp/x.part';r.bytes_part=0;r.part_hasher=hashlib.sha256();r.file_started=time.time();r.part_index=0;r.part_ext='ts';r._seg_iv_last=0;r._seg_iv_sum=0.0;r._seg_iv_n=0;r.speed_win=[]
        class Boom(io.BytesIO):
            def write(self,b):raise OSError(errno.ENOSPC,'No space left on device')
        r.fh=Boom()
        u8=b'12345'
        with patch.object(r,'ensure_part'):
            with patch.object(r,'_save_error') as se:
                m.Dl.push(r,u8)
                se.assert_called_once_with('video','x.ts','MEDIA_WRITE_ENOSPC')

if __name__=='__main__':unittest.main()
