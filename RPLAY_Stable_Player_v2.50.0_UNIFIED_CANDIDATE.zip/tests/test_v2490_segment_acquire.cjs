"use strict";
/* v2.49.0: 汎用 disk-backed 取得エンジン Stage 2 の単体検証(API/OPFS/fetch モック)。
   紀律: 明示候補のみ・RAM 1セグメント上限・fail-closed・ゼロシークレット・既定OFF。 */
const {test}=require('node:test'),a=require('node:assert/strict');
const path=require('path');
const vm=require('vm');

const ROOT=path.resolve(__dirname,'..');

function loadModule(){
 const src=require('fs').readFileSync(ROOT+'/src/segment_acquire.js','utf8');
 const sandbox={module:{exports:{}},require,globalThis:{},console};
 sandbox.globalThis=sandbox;
 vm.runInContext('(function(module,require,globalThis,console){'+src+'\n})(module,require,globalThis,console);',
  vm.createContext(sandbox));
 return sandbox.module.exports;
}

function makeMockStore(opts){
 opts=opts||{};
 const stored=new Map();
 const fails=opts.fails||{};
 const maxSegmentBytes=opts.maxSegmentBytes||16*1048576;
 return {
  stored,
  digest:opts.digest||(async(b)=>{let h=0;const u=b instanceof Uint8Array?b:new Uint8Array(b);for(let i=0;i<u.length;i++)h=((h*31)+u[i])>>>0;return ('00000000'+h.toString(16)).slice(-8);}),
  async put({id,bytes,digest,pinned}){
   if(fails.put){const e=Error('STORE_PUT_FAILED');e.code='STORE_PUT_FAILED';throw e;}
   if(!(id&&/^[a-f0-9]{8,64}$/.test(id)))throw Error('SEGMENT_BAD_ID');
   const u=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes);
   if(u.byteLength>maxSegmentBytes)throw Error('SEGMENT_TOO_LARGE');
   stored.set(id,{id,bytes:u,digest:digest||null,at:Date.now(),pinned:Boolean(pinned),bytes:u.byteLength});
   return {id,bytes:u.byteLength};
  },
  async get(id){if(fails.get)throw Error('STORE_GET_FAILED');if(!stored.has(id))return null;const e=stored.get(id);return {id,bytes:e.bytes,digest:e.digest};},
  async meta(id){return stored.has(id)?stored.get(id):null;},
  async list(){return [...stored.values()].map(e=>({id:e.id,bytes:e.bytes,at:e.at,pinned:e.pinned}));},
  async sweep(){let n=0;for(const k of stored.keys()){stored.delete(k);n++;}return n;},
  async remove(id){return stored.delete(id);}
 };
}

function makeMockFetcher(opts){
 opts=opts||{};
 const calls={playlist:[],segment:[]};
 const defaultPl=opts.playlist||{kind:'media',segments:[
   {sequence:1,discontinuitySequence:0,discontinuity:false,uri:'seg1.ts'},
   {sequence:2,discontinuitySequence:0,discontinuity:false,uri:'seg2.ts'},
   {sequence:3,discontinuitySequence:0,discontinuity:false,uri:'seg3.ts'}
  ],endList:true};
 return {
  calls,
  playlistFetcher:(url,headers,tmo,log,signal)=>{
   calls.playlist.push({url});
   if(opts.playlistFail)return Promise.resolve({ok:false,status:0,error:opts.playlistFail});
   if(opts.playlist404)return Promise.resolve({ok:false,status:404});
   if(opts.playlist500)return Promise.resolve({ok:false,status:500});
   if(opts.playlistAbort)return Promise.resolve({ok:false,status:0,aborted:true});
   const pl=opts.playlistFn?opts.playlistFn(url):defaultPl;
   return Promise.resolve({ok:true,status:200,json:pl});
  },
  segmentFetcher:(url,{timeoutMs,signal}={})=>{
   calls.segment.push({url});
   if(opts.segmentFail)return Promise.resolve({ok:false,status:0,error:opts.segmentFail});
   if(opts.segment404)return Promise.resolve({ok:false,status:404});
   if(opts.segmentAbort)return Promise.resolve({ok:false,status:0,aborted:true});
   const bytes=opts.segmentFn?opts.segmentFn(url):new Uint8Array([0x47,0x40,0x00,0x10]);
   return Promise.resolve({ok:true,status:200,bytes});
  }
 };
}

function makeParser(opts){
 opts=opts||{};
 return (json,url)=>{
  if(opts.parseFail)throw Error('PARSE_FAIL');
  if(!json||json.kind!=='media'||!Array.isArray(json.segments))throw Error('PLAYLIST_NOT_MEDIA');
  return json;
 };
}

function stdCandidate(){return {id:'cand-001',type:'hls',source:'webRequest'};}
function stdPlaylist(segs){
 return {
  kind:'media',
  segments:segs||[
   {sequence:1,discontinuitySequence:0,discontinuity:false,uri:'seg1.ts'},
   {sequence:2,discontinuitySequence:0,discontinuity:false,uri:'seg2.ts'},
   {sequence:3,discontinuitySequence:0,discontinuity:false,uri:'seg3.ts'}
  ],
  endList:true
 };
}

test('v2.49.0 acquire happy path: explicit candidate yields 3 segments acquired',async()=>{
 const mod=loadModule();
 const store=makeMockStore();
 const f=makeMockFetcher();
 const eng=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser()});
 const status=await eng.start({id:'acq-1',candidate:stdCandidate(),initialPlaylistUrl:'https://example.test/playlist.m3u8'});
 a.strictEqual(status.status,'complete');
 a.strictEqual(status.segmentsAcquired,3);
 a.strictEqual(status.segmentsSkipped,0);
 a.strictEqual(status.endListReached,true);
 a.strictEqual(status.bytesAcquired,12);
 a.strictEqual(store.stored.size,3);
 a.strictEqual(status.id,'acq-1');
 a.strictEqual(status.candidate.id,'cand-001');
});

test('v2.49.0 default OFF: start() requires explicit candidate',async()=>{
 const mod=loadModule();
 const store=makeMockStore();
 const f=makeMockFetcher();
 const eng=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser()});
 await a.rejects(()=>eng.start({id:'acq-x'}),/INVALID_CANDIDATE/);
 a.strictEqual(eng.list().length,0);
});

test('v2.49.0 RAM 1-segment cap: each segment put before next fetch (interleaved)',async()=>{
 const mod=loadModule();
 const store=makeMockStore();
 const fetchOrder=[];
 const f=makeMockFetcher({segmentFn:(url)=>{fetchOrder.push(url);return new Uint8Array(fetchOrder.length*4);}});
 const realPut=store.put.bind(store);
 const putOrder=[];
 store.put=async(args)=>{putOrder.push(args.id);return realPut(args);};
 const eng=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser()});
 const status=await eng.start({id:'acq-ram',candidate:stdCandidate(),initialPlaylistUrl:'https://example.test/p.m3u8'});
 a.strictEqual(status.segmentsAcquired,3);
 a.strictEqual(putOrder.length,3);
 a.strictEqual(fetchOrder.length,3);
});

test('v2.49.0 cancel mid-acquisition: residue remains on disk (non-destructive)',async()=>{
 const mod=loadModule();
 const store=makeMockStore();
 const pl={kind:'media',endList:false,segments:Array.from({length:5},(_,i)=>({sequence:i+1,discontinuitySequence:0,uri:'s'+(i+1)+'.ts'}))};
 let nFetch=0;
 const f=makeMockFetcher({playlist:pl,segmentFn:()=>{nFetch++;if(nFetch>=2){eng.cancel('acq-cancel');}return new Uint8Array(4);}});
 const eng=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser()});
 const status=await eng.start({id:'acq-cancel',candidate:stdCandidate(),initialPlaylistUrl:'https://example.test/p.m3u8'});
 a.ok(['cancelled','failed','complete'].includes(status.status),'status: '+status.status);
 const residue=await eng.listResidue('acq-cancel');
 a.ok(residue);
 a.ok(residue.segments.length>=1,'at least 1 segment on disk after cancel');
});

test('v2.49.0 restart continuation: skipped already-acquired segments',async()=>{
 const mod=loadModule();
 const store=makeMockStore();
 // Use a non-endList playlist so the initial start() leaves status 'paused' (resumable).
 const pl={kind:'media',endList:false,segments:[
   {sequence:1,discontinuitySequence:0,uri:'seg1.ts'},
   {sequence:2,discontinuitySequence:0,uri:'seg2.ts'},
   {sequence:3,discontinuitySequence:0,uri:'seg3.ts'}
 ]};
 const f1=makeMockFetcher({playlist:pl});
 const eng=mod.create({store,fetcher:f1.playlistFetcher,fetchSegment:f1.segmentFetcher,playlistParser:makeParser()});
 const s1=await eng.start({id:'acq-resume',candidate:stdCandidate(),initialPlaylistUrl:'https://example.test/p.m3u8'});
 a.strictEqual(s1.segmentsAcquired,3);
 a.strictEqual(s1.status,'paused','non-endList start pauses for continuation');
 const f2=makeMockFetcher({playlist:pl});
 eng._fetcher=f2.playlistFetcher;eng._fetchSegment=f2.segmentFetcher;
 const s2=await eng.continueFrom({id:'acq-resume',playlistUrl:'https://example.test/p.m3u8'});
 a.strictEqual(s2.segmentsAcquired,3);
 a.ok(s2.segmentsSkipped>=3);
 a.strictEqual(store.stored.size,3,'no duplicates');
});

test('v2.49.0 zero-secret scan: status output never leaks URL/secret',async()=>{
 const mod=loadModule();
 const store=makeMockStore();
 const f=makeMockFetcher();
 const eng=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser()});
 // Note: ID must not contain regex-keyword false-positives like 'secret'/'token'.
 await eng.start({id:'acq-zsscan',candidate:stdCandidate(),initialPlaylistUrl:'https://x.example/playlist?key=TOKEN'});
 const scan=eng.zeroSecretScan('acq-zsscan');
 a.ok(scan);
 a.strictEqual(scan.clean,true,'no secret leaks: '+JSON.stringify(scan.suspect));
});

test('v2.49.0 fail-closed on segment fetch failure',async()=>{
 const mod=loadModule();
 const store=makeMockStore();
 const f=makeMockFetcher({segmentFail:'SEGMENT_FETCH_FAILED'});
 const eng=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser()});
 const status=await eng.start({id:'acq-fail',candidate:stdCandidate(),initialPlaylistUrl:'https://example.test/p.m3u8'});
 a.strictEqual(status.status,'failed');
 a.match(status.error,/SEGMENT_FETCH_FAILED/);
});

test('v2.49.0 fail-closed on playlist 404',async()=>{
 const mod=loadModule();
 const store=makeMockStore();
 const f=makeMockFetcher({playlist404:true});
 const eng=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser()});
 const status=await eng.start({id:'acq-404',candidate:stdCandidate(),initialPlaylistUrl:'https://example.test/p.m3u8'});
 a.strictEqual(status.status,'failed');
 a.match(status.error,/HTTP_404/);
});

test('v2.49.0 segment too large → fail-closed SEGMENT_TOO_LARGE',async()=>{
 const mod=loadModule();
 const store=makeMockStore({maxSegmentBytes:8});
 const f=makeMockFetcher({segmentFn:()=>new Uint8Array(16)});
 const eng=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser()});
 const status=await eng.start({id:'acq-too-large',candidate:stdCandidate(),initialPlaylistUrl:'https://example.test/p.m3u8'});
 a.strictEqual(status.status,'failed');
 a.match(status.error,/SEGMENT_TOO_LARGE/);
});

test('v2.49.0 segment limit reached — bounded acquisition',async()=>{
 const mod=loadModule();
 const store=makeMockStore();
 const bigPl={kind:'media',endList:false,segments:Array.from({length:5000},(_,i)=>({sequence:i+1,discontinuitySequence:0,uri:'s'+i+'.ts'}))};
 const f=makeMockFetcher({playlist:bigPl,segmentFn:()=>new Uint8Array(2)});
 const eng=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser()});
 const status=await eng.start({id:'acq-limit',candidate:stdCandidate(),initialPlaylistUrl:'https://example.test/p.m3u8'});
 a.strictEqual(status.status,'failed');
 a.match(status.error,/SEGMENT_LIMIT_REACHED/);
});

test('v2.49.0 GAP segment skipped non-destructively',async()=>{
 const mod=loadModule();
 const store=makeMockStore();
 const pl={kind:'media',endList:true,segments:[
   {sequence:1,discontinuitySequence:0,uri:'s1.ts'},
   {sequence:2,discontinuitySequence:0,gap:true},
   {sequence:3,discontinuitySequence:0,uri:'s3.ts'}
 ]};
 const f=makeMockFetcher({playlist:pl});
 const eng=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser()});
 const status=await eng.start({id:'acq-gap',candidate:stdCandidate(),initialPlaylistUrl:'https://example.test/p.m3u8'});
 a.strictEqual(status.segmentsAcquired,2);
 a.ok(status.segmentsSkipped>=1);
 a.strictEqual(store.stored.size,2);
});

test('v2.49.0 restore() rehydrates from ledger + known segment ids',async()=>{
 const mod=loadModule();
 const store=makeMockStore();
 const pl=stdPlaylist();
 const f=makeMockFetcher({playlist:pl});
 const eng=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser()});
 const s1=await eng.start({id:'acq-restore',candidate:stdCandidate(),initialPlaylistUrl:'https://example.test/p.m3u8'});
 a.strictEqual(s1.segmentsAcquired,3);
 const residue=await eng.listResidue('acq-restore');
 const knownIds=residue.segments.map(s=>s.id);
 eng.discard('acq-restore');
 const eng2=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser()});
 const restored=await eng2.restore({id:'acq-restore',candidate:stdCandidate(),
  ledgerState:{status:'paused',segmentsAcquired:3,bytesAcquired:12,lastSequence:3,lastDiscontinuitySequence:0},
  knownSegmentIds:knownIds});
 a.strictEqual(restored.status,'paused');
 const r2=await eng2.listResidue('acq-restore');
 a.strictEqual(r2.segments.length,3);
});

test('v2.49.0 discard() is non-destructive — segments remain on disk',async()=>{
 const mod=loadModule();
 const store=makeMockStore();
 const f=makeMockFetcher();
 const eng=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser()});
 await eng.start({id:'acq-discard',candidate:stdCandidate(),initialPlaylistUrl:'https://example.test/p.m3u8'});
 a.strictEqual(store.stored.size,3);
 eng.discard('acq-discard');
 a.strictEqual(eng.list().length,0);
 a.strictEqual(store.stored.size,3,'non-destructive: disk segments preserved');
});

test('v2.49.0 TOO_MANY_ACQUIRES bound enforced',async()=>{
 const mod=loadModule();
 const store=makeMockStore();
 const f=makeMockFetcher();
 const eng=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser()});
 for(let i=0;i<eng.MAX_ACQUIRES;i++){
  await eng.start({id:'acq-bounded-'+i,candidate:stdCandidate(),initialPlaylistUrl:'https://example.test/p.m3u8'});
 }
 await a.rejects(()=>eng.start({id:'acq-overflow',candidate:stdCandidate(),initialPlaylistUrl:'https://example.test/p.m3u8'}),/TOO_MANY_ACQUIRES/);
});

test('v2.49.0 ID_EXISTS guard',async()=>{
 const mod=loadModule();
 const store=makeMockStore();
 const f=makeMockFetcher();
 const eng=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser()});
 await eng.start({id:'acq-dup',candidate:stdCandidate(),initialPlaylistUrl:'https://example.test/p.m3u8'});
 await a.rejects(()=>eng.start({id:'acq-dup',candidate:stdCandidate(),initialPlaylistUrl:'https://example.test/p.m3u8'}),/ID_EXISTS/);
});

test('v2.49.0 SEGMENT_NO_SEQUENCE → fail-closed',async()=>{
 const mod=loadModule();
 const store=makeMockStore();
 const pl={kind:'media',endList:true,segments:[{discontinuitySequence:0,uri:'s1.ts'}]};
 const f=makeMockFetcher({playlist:pl});
 const eng=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser()});
 const status=await eng.start({id:'acq-noseq',candidate:stdCandidate(),initialPlaylistUrl:'https://example.test/p.m3u8'});
 a.strictEqual(status.status,'failed');
 a.match(status.error,/SEGMENT_NO_SEQUENCE/);
});

test('v2.49.0 PLAYLIST_NOT_MEDIA → fail-closed',async()=>{
 const mod=loadModule();
 const store=makeMockStore();
 const f=makeMockFetcher({playlist:{kind:'master',variants:[]}});
 const eng=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser()});
 const status=await eng.start({id:'acq-notmedia',candidate:stdCandidate(),initialPlaylistUrl:'https://example.test/p.m3u8'});
 a.strictEqual(status.status,'failed');
 a.match(status.error,/PLAYLIST_NOT_MEDIA/);
});

test('v2.49.0 status() / list() with no acquires → empty results',()=>{
 const mod=loadModule();
 const store=makeMockStore();
 const f=makeMockFetcher();
 const eng=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser()});
 a.strictEqual(eng.status('nonexistent'),null);
 a.ok(Array.isArray(eng.list()));
 a.strictEqual(eng.list().length,0);
});

test('v2.49.0 listResidue for nonexistent acquire → null',async()=>{
 const mod=loadModule();
 const store=makeMockStore();
 const f=makeMockFetcher();
 const eng=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser()});
 a.strictEqual(await eng.listResidue('nonexistent'),null);
});

test('v2.49.0 pause without endList → status paused',async()=>{
 const mod=loadModule();
 const store=makeMockStore();
 const pl={kind:'media',endList:false,segments:[{sequence:1,discontinuitySequence:0,uri:'s1.ts'}]};
 const f=makeMockFetcher({playlist:pl});
 const eng=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser()});
 const status=await eng.start({id:'acq-pause',candidate:stdCandidate(),initialPlaylistUrl:'https://example.test/p.m3u8'});
 a.strictEqual(status.status,'paused');
 a.strictEqual(status.endListReached,false);
});

test('v2.49.0 ledger persistence: state recoverable from best-effort write',async()=>{
 const mod=loadModule();
 const store=makeMockStore();
 const f=makeMockFetcher();
 let saved=null;
 const ledger={read:()=>saved,write:(s)=>{saved=s;},clear:()=>{saved=null;}};
 const eng=mod.create({store,fetcher:f.playlistFetcher,fetchSegment:f.segmentFetcher,playlistParser:makeParser(),ledger});
 await eng.start({id:'acq-ledger',candidate:stdCandidate(),initialPlaylistUrl:'https://example.test/p.m3u8'});
 a.ok(saved,'ledger state written');
 a.strictEqual(saved.id,'acq-ledger');
 a.strictEqual(saved.status,'complete');
 a.strictEqual(saved.segmentsAcquired,3);
 // Verify no URL/secret in persisted state
 const flat=JSON.stringify(saved);
 a.ok(!/https?:\/\//i.test(flat),'no URLs in ledger');
 a.ok(!/bearer|authorization|cookie|secret/i.test(flat),'no secrets in ledger');
});

test('v2.49.0 dependencies required — missing store/fetcher/parser throws',()=>{
 a.throws(()=>loadModule().create({}),/STORE_REQUIRED/);
 a.throws(()=>loadModule().create({store:makeMockStore()}),/FETCHER_REQUIRED/);
 a.throws(()=>loadModule().create({store:makeMockStore(),fetcher:()=>{}}),/SEGMENT_FETCHER_REQUIRED/);
 a.throws(()=>loadModule().create({store:makeMockStore(),fetcher:()=>{},fetchSegment:()=>{}}),/PLAYLIST_PARSER_REQUIRED/);
});
