'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),H=require('../src/hls_transport.js');
const b='https://fixtures.invalid/live.m3u8';
const p=s=>'#EXTM3U\n#EXT-X-TARGETDURATION:2\n'+s;
const dt=t=>`#EXT-X-PROGRAM-DATE-TIME:${t}\n`;
test('reject duplicate global tags and misplaced target',()=>{
 for(const input of [p('#EXT-X-VERSION:4\n#EXT-X-VERSION:5\n'),p('#EXT-X-MEDIA-SEQUENCE:1\n#EXT-X-MEDIA-SEQUENCE:2\na.ts'),p('#EXT-X-DISCONTINUITY-SEQUENCE:1\n#EXT-X-DISCONTINUITY-SEQUENCE:2\na.ts'),p('#EXT-X-TARGETDURATION:2\na.ts'),p('a.ts\n#EXT-X-TARGETDURATION:3')])assert.throws(()=>H.parse(input,b));
});
test('EXTINF syntax, duplicate and duration target bound fail atomically',()=>{
 for(const input of ['#EXTINF:zero,\na.ts','#EXTINF:0,\na.ts','#EXTINF:-2,\na.ts','#EXTINF:2.5,\na.ts','#EXTINF:1.0,\n#EXTINF:1.0,\na.ts','#EXTINF:1.0,'])assert.throws(()=>H.parse(p(input),b));
 assert.equal(H.parse(p('#EXTINF:1.49,\na.ts'),b).segments[0].duration,1.49);
});
test('strict segment URL whitespace and control rejected',()=>{
 for(const line of [' a.ts','a.ts ','\ta.ts','a.ts\t'])assert.throws(()=>H.parse(p(line),b),/HLS_BAD_URL/);
});
test('PROGRAM-DATE-TIME rejects invalid dates and dangling tag',()=>{
 for(const v of ['2025-02-29T00:00:00Z','2024-13-01T00:00:00Z','2024-02-29T24:00:00Z','2024-02-29T00:60:00Z','2024-02-29T00:00:60Z','0000-01-01T00:00:00Z','2024-01-01T00:00:00+24:00'])assert.throws(()=>H.parse(p(dt(v)+'#EXTINF:1,\na.ts'),b),/HLS_BAD_PROGRAM_DATE_TIME/);
 assert.throws(()=>H.parse(p(dt('2024-02-29T00:00:00Z')),b),/HLS_DANGLING_TAG/);
 assert.equal(H.parse(p(dt('2024-02-29T00:00:00+09:00')+'#EXTINF:1,\na.ts'),b).segments[0].programDateTimeMs,Date.parse('2024-02-28T15:00:00Z'));
});
test('manifest-only timing evidence detects positive gap and negative overlap',()=>{
 for(const [when,gap,overlap,maxDelta] of [['2026-01-01T00:00:01Z',0,0,0],['2026-01-01T00:00:04Z',1,0,3000],['2026-01-01T00:00:00Z',0,1,1000]]){
  const text=p(dt('2026-01-01T00:00:00Z')+'#EXTINF:1,\na.ts\n'+dt(when)+'#EXTINF:1,\nb.ts');
  const evidence=H.timingEvidence(H.parse(text,b));
  assert.equal(evidence.checkedIntervals,1);assert.equal(evidence.suspectedGapIntervals,gap);assert.equal(evidence.suspectedOverlapIntervals,overlap);assert.equal(evidence.maxAbsDeviationMs,maxDelta);assert.equal(evidence.provenance,'manifest_declared_only');
  assert.equal(JSON.stringify(evidence).includes('https://'),false);
 }
});
test('discontinuity boundaries stop unsupported cross-epoch clock comparison',()=>{
 const text=p(dt('2026-01-01T00:00:00Z')+'#EXTINF:1,\na.ts\n#EXT-X-DISCONTINUITY\n'+dt('2026-01-01T00:01:00Z')+'#EXTINF:1,\nb.ts');
 const x=H.timingEvidence(H.parse(text,b));assert.equal(x.discontinuityBoundaries,1);assert.equal(x.checkedIntervals,0);
});
test('missing duration is reported, never treated as exact PTS',()=>{
 const x=H.timingEvidence(H.parse(p(dt('2026-01-01T00:00:00Z')+'a.ts\n'+dt('2026-01-01T00:01:00Z')+'b.ts'),b));
 assert.equal(x.unmeasuredIntervals,1);assert.equal(x.missingExtinf,2);assert.equal(x.checkedIntervals,0);
});
test('enqueue attaches sanitized numeric clock diagnostics, no URLs',()=>{
 const o={seen:new Set(),queue:[]};H.enqueue(o,H.parse(p(dt('2026-01-01T00:00:00Z')+'#EXTINF:1,\na.ts'),b),b);
 assert.equal(o._hlsTiming.explicitAnchors,1);assert.equal(JSON.stringify(o._hlsTiming).includes('fixtures.invalid'),false);
});
