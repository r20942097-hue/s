"""v2.10.0 feature acceptance (TS anti-fragmentation & Video DownloadHelper / Stream Recorder / N_m3u8DL-RE / rplay_watcher v0.5.2 learnings):
1. MPEG-TS EXT-X-DISCONTINUITY seamless single-part append by default (--split-on-discontinuity opt-in for splitting).
2. Default --split-min changed to 0 (single continuous file by default unless size cap reached).
3. Multi-part auto-concatenation (--concat-parts auto|mp4|ts|no) using FFmpeg concat demuxer (-f concat -safe 0 -c copy)
   inspired by Video DownloadHelper CoApp (vdhcoapp) & N_m3u8DL-RE.
4. Segment HTTP 503 Retry-After backoff in both video and audio pipelines.
5. Master 200 / Media 404 paywall detection (paywall_blocked) from rplay_watcher v0.5.2.
6. partContinuityEvidence block in info JSON and ledger.json.
Local HTTP only — VM-safe."""
import http.server,threading,tempfile,pathlib,subprocess,sys,json,unittest
from unittest.mock import patch
import importlib.util
R=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('v2100feat',R/'rplay_dl.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


class UnitV2100Features(unittest.TestCase):
    def test_ts_discontinuity_merged_by_default_and_split_when_opted_in(self):
        # 1) Default (split_on_discontinuity=False): TS boundary ignores discontinuity & epoch
        d1={'epoch':1,'discontinuity':0,'map':None}
        d2={'epoch':1,'discontinuity':1,'map':None}
        b1=m.hls_part_boundary(d1,split_on_discontinuity=False)
        b2=m.hls_part_boundary(d2,split_on_discontinuity=False)
        self.assertEqual(b1,b2,'TS boundary must stay identical across discontinuity by default')
        # 2) Opt-in (split_on_discontinuity=True): TS boundary changes on discontinuity/epoch
        b1_s=m.hls_part_boundary(d1,split_on_discontinuity=True)
        b2_s=m.hls_part_boundary(d2,split_on_discontinuity=True)
        self.assertNotEqual(b1_s,b2_s)
        # 3) fMP4 (map present) ALWAYS includes epoch/discontinuity/map in boundary
        m1={'epoch':1,'discontinuity':0,'map':{'uri':'https://x/init1.mp4','range':None}}
        m2={'epoch':1,'discontinuity':1,'map':{'uri':'https://x/init1.mp4','range':None}}
        self.assertNotEqual(m.hls_part_boundary(m1,False),m.hls_part_boundary(m2,False))

    def test_segment_503_retry_after_sets_backoff(self):
        r=m.Dl.__new__(m.Dl)
        r.c429=0;r.a_c429=0;r.seg_backoff=0;r.a_backoff=0;r.seg_fails=0;r.a_seg_fails=0
        item={'tries':1}
        with patch.object(m,'now_ms',return_value=5000):
            res=r._hls_status(item,503,15000,False)
            self.assertEqual(res,(None,True))
            self.assertEqual(r.seg_backoff,20000)
            res_a=r._hls_status(item,503,25000,True)
            self.assertEqual(res_a,(None,True))
            self.assertEqual(r.a_backoff,30000)

    def test_paywall_blocked_detection_and_continuity_evidence(self):
        self.assertTrue(m.detect_paywall_blocked(200,404))
        self.assertTrue(m.detect_paywall_blocked(200,403))
        self.assertFalse(m.detect_paywall_blocked(200,200))
        self.assertFalse(m.detect_paywall_blocked(404,404))
        ev=m.part_continuity_evidence({
            'splitMinutes':0,'maxSizeMb':600,'splitOnDiscontinuity':False,
            'discontinuityMergedCount':5,'discontinuitySplitCount':0,
            'sameSessionStandbyContinuations':2,'partsConcatenated':3,
            'concatOutput':'RPLAY_merged.mp4'
        })
        self.assertEqual(ev['discontinuityMergedCount'],5)
        self.assertEqual(ev['sameSessionStandbyContinuations'],2)
        self.assertEqual(ev['partsConcatenated'],3)
        self.assertEqual(ev['provenance'],'vdh_coapp_and_streamlink_ts_continuity_v2100')

    def test_concat_parts_merges_multiple_ts_files_into_single_mp4_or_ts(self):
        with tempfile.TemporaryDirectory() as d:
            dp=pathlib.Path(d)
            # Generate 2 valid TS files using ffmpeg if available, else raw TS packets
            ff=m.ffmpeg_tool()
            p1,p2=dp/'part1.ts',dp/'part2.ts'
            if ff:
                for idx,p in enumerate((p1,p2)):
                    subprocess.run([ff,'-y','-loglevel','error','-f','lavfi','-i',
                                    f'testsrc=duration=1:size=160x120:rate=10',
                                    '-f','lavfi','-i','sine=frequency=440:duration=1',
                                    '-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac',
                                    '-f','mpegts',str(p)],check=True,timeout=30)
                out_mp4=dp/'merged_all.mp4'
                ok=m.concat_media_parts([str(p1),str(p2)],str(out_mp4),lambda s:None,ctx={'creatorOid':'a'*24,'title':'結合テスト'})
                self.assertTrue(ok)
                self.assertTrue(out_mp4.exists() and out_mp4.stat().st_size>0)
            # Also test binary TS concat mode (always works even without ffmpeg)
            out_ts=dp/'merged_all.ts'
            p1.write_bytes(b'\x47'+b'\x00'*187)
            p2.write_bytes(b'\x47'+b'\x01'*187)
            ok_ts=m.concat_media_parts([str(p1),str(p2)],str(out_ts),lambda s:None,mode='ts')
            self.assertTrue(ok_ts)
            self.assertEqual(out_ts.read_bytes(),(b'\x47'+b'\x00'*187)+(b'\x47'+b'\x01'*187))


class E2EV2100Features(unittest.TestCase):
    def test_cli_discontinuity_ts_records_into_single_file_with_continuity_evidence(self):
        """EXT-X-DISCONTINUITYを含むTS配信でも、v2.10.0既定では細切れに分割せず
        単一のTSパートへ連続追記し、partContinuityEvidence.discontinuityMergedCountを記録する。"""
        playlist=('#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:0\n'
                  '#EXTINF:1,\nseg0.ts\n#EXT-X-DISCONTINUITY\n'
                  '#EXTINF:1,\nseg1.ts\n#EXT-X-DISCONTINUITY\n'
                  '#EXTINF:1,\nseg2.ts\n#EXT-X-ENDLIST\n')
        seg=b'\x47'*(188*10)
        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self,*a):pass
            def _send(s,code,body=b''):
                s.send_response(code);s.send_header('Content-Length',str(len(body)));s.end_headers();s.wfile.write(body)
            def do_GET(s):
                path=s.path.split('?')[0]
                if path=='/api/live/play':
                    s._send(200,json.dumps({'streamState':'live','accessible':True,'allowAnonymous':True,
                                            'title':'連続TS配信','streamStartTime':'2026-10-26T12:00:00Z'}).encode());return
                if path=='/live.m3u8':
                    s._send(200,playlist.encode());return
                if path in ('/seg0.ts','/seg1.ts','/seg2.ts'):
                    s._send(200,seg);return
                s._send(404)
        srv=http.server.ThreadingHTTPServer(('127.0.0.1',0),H)
        threading.Thread(target=srv.serve_forever,daemon=True).start()
        url='http://127.0.0.1:%d'%srv.server_port
        try:
            with tempfile.TemporaryDirectory() as d:
                cmd=[sys.executable,str(R/'rplay_dl.py'),'a'*24,'--api',url+'/api',
                     '--m3u8',url+'/live.m3u8','--no-follow','--no-flv','--mux','no',
                     '--out',d,'--info-json']
                p=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                info=json.loads(next(pathlib.Path(d).glob('*_info.json')).read_text())
                # All 3 segments across 2 discontinuities must be in 1 single part!
                self.assertEqual(len(info['parts']),1,info['parts'])
                self.assertEqual(info['parts'][0]['segments'],3)
                self.assertEqual(info['parts'][0]['bytes'],len(seg)*3)
                ce=info.get('partContinuityEvidence')
                self.assertIsInstance(ce,dict)
                self.assertEqual(ce['discontinuityMergedCount'],2)
                self.assertEqual(ce['discontinuitySplitCount'],0)
                self.assertEqual(ce['splitMinutes'],0)
        finally:
            srv.shutdown();srv.server_close()

    def test_cli_master_200_media_404_detects_paywall_blocked(self):
        """Master playlistが200でバリアントm3u8が404を返す場合(rplay_watcher v0.5.2知見)、
        paywall_blocked を検出して errorTaxonomyEvidence に記録する。"""
        master='#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=2000000,RESOLUTION=1920x1080\nvariant_locked.m3u8\n'
        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self,*a):pass
            def _send(s,code,body=b''):
                s.send_response(code);s.send_header('Content-Length',str(len(body)));s.end_headers();s.wfile.write(body)
            def do_GET(s):
                path=s.path.split('?')[0]
                if path=='/api/live/play':
                    s._send(200,json.dumps({'streamState':'live','accessible':True,'allowAnonymous':True,'title':'Paywall'}).encode());return
                if path=='/live.m3u8':
                    s._send(200,master.encode());return
                if path=='/variant_locked.m3u8':
                    s._send(404,b'Not Found');return
                s._send(404)
        srv=http.server.ThreadingHTTPServer(('127.0.0.1',0),H)
        threading.Thread(target=srv.serve_forever,daemon=True).start()
        url='http://127.0.0.1:%d'%srv.server_port
        try:
            with tempfile.TemporaryDirectory() as d:
                cmd=[sys.executable,str(R/'rplay_dl.py'),'a'*24,'--api',url+'/api',
                     '--m3u8',url+'/live.m3u8','--no-follow','--no-flv','--mux','no',
                     '--out',d,'--info-json']
                p=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
                self.assertIn('paywall_blocked',p.stdout)
        finally:
            srv.shutdown();srv.server_close()


if __name__=='__main__':unittest.main()
