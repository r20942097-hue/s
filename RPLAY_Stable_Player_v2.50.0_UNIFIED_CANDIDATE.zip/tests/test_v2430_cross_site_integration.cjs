'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const CS=require('../src/cross_site_compat.js');
const C=require('../src/media_catalog.js');
const M=require('../src/media_inspect_core.js');
const H=require('../src/hls_transport.js');
const RspRecovery=require('../src/recovery_core.js');
const hashing=require('../src/sha256.js');

const {
 resolveMediaURI,isSigned,redactMediaURL,
 parseAttributes,parseHLS,publicHLSReport,
 classifySite,detectMediaType,diagnoseResponse,siteRequirements,
 LiveSegmentLedger,suggestedReloadMs,
 captureRequestMetadata,makeFetchOptions,publicCaptureReport,
 NicoLiveSessionObserver,MediaCandidateRegistry
}=CS;

const fixture=name=>fs.readFileSync(path.join(__dirname,'fixtures','cross-site',name),'utf8');
const base='https://cdn.example.test/media/master.m3u8?sig=abc%2B%2F&sig=two&Expires=1790000000';

/* ---- 1. Full 56-test suite from CrossSite Compatibility v0.1.0 ---- */
test('signature detection',()=>assert.equal(isSigned(base),true));
test('unsigned detection',()=>assert.equal(isSigned('https://cdn.example.test/x?a=1'),false));
test('absolute signed child kept unchanged',()=>{
 const c='https://other.example.test/v.m3u8?token=A%2Fb&token=B%2B&u=%2520';
 assert.equal(resolveMediaURI(base,c,{inheritParentQuery:true}),c);
});
test('relative signed child keeps exact query order/duplicates',()=>{
 assert.equal(resolveMediaURI(base,'s.ts?sig=1%2B&sig=2&x=%252F',{inheritParentQuery:true}),
 'https://cdn.example.test/media/s.ts?sig=1%2B&sig=2&x=%252F');
});
test('no inheritance default',()=>assert.equal(resolveMediaURI(base,'s.ts'),'https://cdn.example.test/media/s.ts'));
test('explicit inheritance preserves raw parent query',()=>{
 assert.equal(resolveMediaURI(base,'s.ts',{inheritParentQuery:true}),
 'https://cdn.example.test/media/s.ts?sig=abc%2B%2F&sig=two&Expires=1790000000');
});
test('existing unsigned child value not overwritten',()=>{
 assert.equal(resolveMediaURI('https://x.test/p.m3u8?a=1&b=two%2B&b=three','s.ts?a=own&k=ok',{inheritParentQuery:true}),
 'https://x.test/s.ts?a=own&k=ok&b=two%2B&b=three');
});
test('never forward signed query to cross-origin child',()=>{
 assert.equal(resolveMediaURI(base,'https://another-cdn.example/seg.ts',{inheritParentQuery:true}),
 'https://another-cdn.example/seg.ts');
});
test('absolute signed URL preserves literal escapes and ordering',()=>{
 const original='https://CDN.example.test/path/seg.ts?sig=%2f%2F&sig=2&X=%25';
 assert.equal(resolveMediaURI(base,original,{inheritParentQuery:true}),original);
});
test('unsafe protocol rejected',()=>assert.throws(()=>resolveMediaURI(base,'javascript:alert(1)'),/Unsupported/));
test('redacted URL does not leak query/path',()=>{
 const r=redactMediaURL(base);assert.ok(!r.includes('abc'));assert.ok(!r.includes('master'));assert.ok(r.includes('[query redacted]'));
});
test('bad url rendered safely',()=>assert.equal(redactMediaURL('BAD URL'),'[invalid URL]'));
test('HLS attr: comma in quotes',()=>{
 const a=parseAttributes('NAME="Japanese, stereo",CODECS="avc1.4d401f,mp4a.40.2",AUTOSELECT=YES');
 assert.equal(a.NAME,'Japanese, stereo');assert.equal(a.CODECS,'avc1.4d401f,mp4a.40.2');assert.equal(a.AUTOSELECT,'YES');
});

test('generic live segments and discontinuity',()=>{
 const p=parseHLS(fixture('generic-live.m3u8'),base);
 assert.equal(p.kind,'media');assert.equal(p.mediaSequence,91);assert.equal(p.discontinuitySequence,3);
 assert.equal(p.segments.length,4);assert.equal(p.segments[2].sequence,93);
 assert.equal(p.segments[2].discontinuitySequence,4);assert.equal(p.segments[2].discontinuity,true);
 assert.equal(p.segments[2].map.url,'https://cdn.example.test/media/init.mp4');
 assert.equal(p.segments[2].url,'https://cdn.example.test/media/93.m4s?sig=child%2Btoken&sig=dup');
});
test('nico video synthetic master with audio rendition',()=>{
 const p=parseHLS(fixture('niconico-video-synthetic-master.m3u8'),base,{inheritParentQuery:true});
 assert.equal(p.kind,'master');assert.equal(p.variants.length,2);assert.equal(p.renditions.length,1);
 assert.equal(p.renditions[0].NAME,'Japanese, stereo');
 assert.equal(p.variants[0].url,'https://cdn.example.test/media/720p.m3u8?token=own%3D1&token=two');
 assert.ok(p.variants[1].url.endsWith('?sig=abc%2B%2F&sig=two&Expires=1790000000'));
});
test('nico live synthetic playlist duration and sequence',()=>{
 const p=parseHLS(fixture('niconico-live-synthetic.m3u8'),'https://cdn.example.test/x/index.m3u8');
 assert.equal(p.segments.length,3);assert.equal(p.targetDuration,2);assert.equal(p.serverControl['CAN-BLOCK-RELOAD'],'YES');
 assert.equal(p.segments[2].programDateTime,'2026-10-27T10:00:00+09:00');
});
test('twitch synthetic LL-HLS contains parts',()=>{
 const p=parseHLS(fixture('twitch-llhls-synthetic.m3u8'),base);
 assert.equal(p.parts.length,2);assert.equal(p.parts[0].independent,true);assert.equal(p.segments.length,1);
});
test('BYTERANGE offsets and gap',()=>{
 const p=parseHLS(fixture('range-discontinuity.m3u8'),base);
 assert.deepEqual(p.segments[0].range,{length:100,offset:0,end:100});
 assert.deepEqual(p.segments[1].range,{length:200,offset:100,end:300});
 assert.equal(p.segments[2].gap,true);assert.equal(p.endList,true);
});
test('invalid implicit BYTERANGE error',()=>{
 const p=parseHLS('#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-BYTERANGE:10\n#EXTINF:2,\na.ts',base);
 assert.ok(p.errors.some(x=>x.includes('Implicit')));
});
test('encrypted stream gets metadata but never key url exposure',()=>{
 const p=parseHLS('#EXTM3U\n#EXT-X-TARGETDURATION:5\n#EXT-X-KEY:METHOD=SAMPLE-AES,KEYFORMAT="com.apple.streamingkeydelivery",URI="skd://secret"\n#EXTINF:5,\na.ts',base);
 assert.equal(p.drm,true);assert.equal(p.encrypted,true);
 assert.ok(!JSON.stringify(publicHLSReport(p)).includes('secret'));
});
test('AES-128 classified encrypted but not automatically DRM',()=>{
 const p=parseHLS('#EXTM3U\n#EXT-X-TARGETDURATION:5\n#EXT-X-KEY:METHOD=AES-128,URI="key"\n#EXTINF:5,\na.ts',base);
 assert.equal(p.drm,false);assert.equal(p.encrypted,true);
});
test('HLS parser fails without header',()=>assert.throws(()=>parseHLS('random',base),/Missing/));
test('HLS parser size limit',()=>assert.throws(()=>parseHLS('x'.repeat(10000001),base),/large/));
test('public HLS report redacts query',()=>{
 const p=parseHLS(fixture('generic-live.m3u8'),base);assert.equal(publicHLSReport(p).playlist,'https://cdn.example.test/…?[query redacted]');
});
for(const [url,site,mode] of [
 ['https://www.nicovideo.jp/watch/sm123','niconico-video','vod-page'],
 ['https://live.nicovideo.jp/watch/lv555','niconico-live','live-page'],
 ['https://live2.nicovideo.jp/watch/lv555','niconico-live','live-page'],
 ['https://www.youtube.com/watch?v=abc','youtube','page'],
 ['https://www.twitch.tv/channel','twitch','page'],
 ['https://random.example/video','generic','unknown'],
 ['https://cdn.example/a/master.m3u8','generic','hls'],
 ['https://cdn.example/a/file.mpd','generic','dash'],
 ['https://cdn.example/a/movie.mp4','generic','mp4']
])test(`classify ${site} ${mode}`,()=>{const p=classifySite(url);assert.equal(p.site,site);assert.equal(p.mode,mode);});
test('site requirements live has session note',()=>assert.match(siteRequirements(classifySite('https://live.nicovideo.jp/watch/lv1')).connection,/websocket/));
test('content type overrides extension',()=>assert.equal(detectMediaType({url:'https://a.test/v',contentType:'application/vnd.apple.mpegurl'}),'hls'));
for(const [status,state,retry] of [[200,'ok',false],[401,'authorization-required',false],[403,'authorization-required',false],[404,'missing-or-expired',false],[410,'missing-or-expired',false],[429,'rate-limited',false],[500,'temporary-server-error',true],[503,'temporary-server-error',true]]){
 test(`HTTP ${status}: ${state}`,()=>{const d=diagnoseResponse({status});assert.equal(d.state,state);assert.equal(d.retry,retry);});
}
test('ledger duplicate across reloads',()=>{
 const p=parseHLS(fixture('niconico-live-synthetic.m3u8'),base);const l=new LiveSegmentLedger();
 assert.equal(l.update(p).fresh.length,3);const again=l.update(p);assert.equal(again.fresh.length,0);assert.equal(again.duplicates,3);
});
test('ledger detects missing later sequence',()=>{
 const l=new LiveSegmentLedger();l.update(parseHLS('#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:10\n#EXTINF:2,\n10.ts',base));
 const d=l.update(parseHLS('#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:13\n#EXTINF:2,\n13.ts',base));
 assert.deepEqual(d.gaps[0],{reason:'missing-sequence',from:11,to:12});
});
test('ledger handles discontinuities',()=>{
 const l=new LiveSegmentLedger();const r=l.update(parseHLS(fixture('generic-live.m3u8'),base));assert.equal(r.discontinuities,1);
});
test('ledger endlist',()=>{const l=new LiveSegmentLedger();assert.equal(l.update(parseHLS(fixture('range-discontinuity.m3u8'),base)).endList,true);});
test('reload period respects changed/unchanged',()=>{
 assert.equal(suggestedReloadMs({targetDuration:4,endList:false},true),2000);
 assert.equal(suggestedReloadMs({targetDuration:4,endList:false},false),4000);
 assert.equal(suggestedReloadMs({targetDuration:4,endList:true},false),null);
});
test('capture request headers normalizes and redacts',()=>{
 const c=captureRequestMetadata({requestId:'a',tabId:2,url:base,requestHeaders:[
  {name:'User-Agent',value:'test UA'},{name:'Referer',value:'https://foo.test/watch?v=secret'},
  {name:'ORIGIN',value:'https://foo.test'},{name:'Cookie',value:'secret=123'}]});
 assert.equal(c.authObserved,true);assert.equal(c.headers.origin,'https://foo.test');
 assert.ok(!JSON.stringify(publicCaptureReport(c)).includes('secret'));
});
test('fetch browser credentials opt in',()=>{
 const c=captureRequestMetadata({requestHeaders:[{name:'Referer',value:'https://foo.test/watch'}]});
 assert.equal(makeFetchOptions(c).credentials,'omit');assert.equal(makeFetchOptions(c,{useBrowserCredentials:true}).credentials,'include');
 assert.equal(makeFetchOptions(c).referrer,'https://foo.test/watch');
});
test('nicolive passive observer detects stream and keeps auth URL private',()=>{
 const o=new NicoLiveSessionObserver();const signed='https://cdn.example.test/v/master.m3u8?token=abc%2F&token=def';
 const result=o.accept(JSON.stringify({type:'stream',data:{protocol:'hls',uri:signed,cookies:[{name:'secret',value:'private'}]}}));
 assert.equal(result.event,'stream-observed');assert.ok(!JSON.stringify(result).includes('abc'));
 assert.equal(o.getStreamForAuthorizedPlayback(),signed);
 assert.equal(o.diagnostics().streamObserved,true);
});
test('nicolive session reconnect/change observed',()=>{
 const o=new NicoLiveSessionObserver();
 o.accept({type:'stream',data:{protocol:'hls',uri:'https://a.test/a.m3u8?sig=old'}});
 o.accept({type:'ping'},1000);
 o.accept({type:'stream',data:{protocol:'hls',uri:'https://a.test/a.m3u8?sig=new'}});
 assert.equal(o.diagnostics().streamChanges,2);assert.equal(o.diagnostics().lastHeartbeat,1000);
 o.accept({type:'disconnect',data:{reason:'expired'}});
 assert.equal(o.getStreamForAuthorizedPlayback(),null);
});
test('nicolive invalid & non HLS rejects',()=>{
 const o=new NicoLiveSessionObserver();assert.equal(o.accept('BAD').event,'invalid-json');
 assert.equal(o.accept({type:'stream',data:{protocol:'dash',uri:'https://a.test/x'}}).event,'unsupported-stream');
 assert.equal(o.accept({type:'stream',data:{protocol:'hls',uri:'file:///a'}}).event,'unsupported-stream');
});
test('candidate registry masks secrets on list but keeps original for playback',()=>{
 const c=new MediaCandidateRegistry();c.observe({id:'nico:tab2',url:base,tabId:2,session:'browser'});
 assert.ok(!JSON.stringify(c.list()).includes('abc%2B'));
 assert.equal(c.getForPlayback('nico:tab2').url,base);
 assert.equal(c.list()[0].type,'hls');
});
test('candidate registry updates token without duplicate rows',()=>{
 const c=new MediaCandidateRegistry();
 c.observe({id:'nico',url:'https://a.test/master.m3u8?token=old'});
 c.observe({id:'nico',url:'https://a.test/master.m3u8?token=new'});
 assert.equal(c.list().length,1);assert.equal(c.list()[0].updates,2);
 assert.ok(c.getForPlayback('nico').url.endsWith('new'));
});
test('candidate registry evicts old items and classifies failure',()=>{
 const c=new MediaCandidateRegistry({maxCandidates:2});
 c.observe({id:'a',url:'https://a.test/1.m3u8'});
 c.observe({id:'b',url:'https://a.test/2.m3u8'});
 c.observe({id:'c',url:'https://a.test/3.m3u8'});
 assert.deepEqual(c.list().map(x=>x.id),['b','c']);assert.equal(c.markFailure('b',403),true);
 assert.equal(c.list()[0].state,'auth-required');c.clear();assert.equal(c.list().length,0);
});

/* ---- 2. New v2.43.0 Integration & Hardening Tests ---- */
test('v2.43.0 RspMediaCatalog manifest merges parent query into unsigned child with existing non-signature query',()=>{
 const parent='https://cdn.example.test/live/master.m3u8?sig=abc%2B%2F&Expires=1790000000&a=parent';
 const body='#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1000\n720p.m3u8?a=own&quality=high\n#EXT-X-STREAM-INF:BANDWIDTH=2000\n1080p.m3u8?token=CHILD_OWN\n';
 const rows=C.manifest(body,parent,H,true);
 assert.equal(rows[0].url,'https://cdn.example.test/live/720p.m3u8?a=own&quality=high&sig=abc%2B%2F&Expires=1790000000');
 assert.equal(rows[1].url,'https://cdn.example.test/live/1080p.m3u8?token=CHILD_OWN');
});
test('v2.43.0 RspMediaCatalog tracks update counts and failure states without leaking URLs',()=>{
 const cat=C.create();
 const ev={url:base,tabId:3,statusCode:200,responseHeaders:[]};
 cat.add(ev);cat.add(ev);
 const items=cat.list();
 assert.equal(items.length,1);
 assert.equal(items[0].updates,2);
 assert.equal(items[0].state,'observed');
 assert.equal(cat.markFailure(items[0].id,403),true);
 assert.equal(cat.list()[0].state,'auth-required');
 assert.equal(cat.markFailure(items[0].id,404),true);
 assert.equal(cat.list()[0].state,'possibly-expired');
 assert.equal(cat.markFailure('missing',500),false);
});
test('v2.43.0 RspMediaInspect classifies watch pages vs direct media streams and redacts secrets',()=>{
 const nicoWatch=M.safeReport({url:'https://live.nicovideo.jp/watch/lv123456?token=SECRET'});
 assert.equal(nicoWatch.siteProfile.site,'niconico-live');
 assert.equal(nicoWatch.siteProfile.mode,'live-page');
 assert.equal(nicoWatch.siteProfile.needsObservedMediaRequest,true);
 assert.equal(nicoWatch.workflow.stage,'CANDIDATE_ONLY');
 assert.match(nicoWatch.workflow.message,/視聴ページURL/);
 assert.equal(JSON.stringify(nicoWatch).includes('SECRET'),false);
 assert.equal(JSON.stringify(nicoWatch).includes('lv123456'),false);

 const rplayWatch=M.safeReport({url:'https://rplay.live/live?creatorOid='+'a'.repeat(24)+'&key2=SECRET'});
 assert.equal(rplayWatch.siteProfile.site,'rplay');
 assert.equal(rplayWatch.siteProfile.mode,'live-page');
 assert.equal(rplayWatch.siteProfile.needsObservedMediaRequest,true);
 assert.equal(JSON.stringify(rplayWatch).includes('SECRET'),false);
});
test('v2.43.0 RspRecovery.recover supports optional verifyTs packet alignment and sync byte verification',async()=>{
 const pkt=new Uint8Array(376);pkt[0]=0x47;pkt[188]=0x47;
 const sha=new hashing.Sha256().update(pkt).digest();
 const makeDir=(chunkBytes,chunkSha)=>{
  const jObj={schema:2,status:'active',ext:'ts',file:'rec.ts',committedBytes:chunkBytes.length,parts:[{file:'chunk-00000001.bin',bytes:chunkBytes.length,sha256:chunkSha}]};
  return {name:'rec.ts.checkpoint',getFileHandle:async n=>({getFile:async()=>new Blob([n==='journal.json'?JSON.stringify(jObj):chunkBytes])})};
 };
 const makeDst=()=>{let stored=new Blob(['old']),pending=[];const h={isSameEntry:async x=>x===h,getFile:async()=>stored,createWritable:async()=>({write:async b=>pending.push(new Uint8Array(b)),close:async()=>{stored=new Blob(pending);},abort:async()=>{pending=[];}})};return h;};
 const res=await RspRecovery.recover(makeDir(pkt,sha),makeDst(),null,()=>{},{verifyTs:true});
 assert.equal(res.confirmed,true);assert.equal(res.tsVerified,true);assert.equal(res.tsPackets,2);
 const badPkt=new Uint8Array(376);badPkt[0]=0x47;badPkt[188]=0x00;
 const badSha=new hashing.Sha256().update(badPkt).digest();
 await assert.rejects(()=>RspRecovery.recover(makeDir(badPkt,badSha),makeDst(),null,()=>{},{verifyTs:true}),/RECOVERY_BAD_TS/);
});
test('v2.43.0 RspHlsTransport validates WebVTT and deduplicates boundary cues across segments',()=>{
 const vtt1='WEBVTT\nX-TIMESTAMP-MAP=MPEGTS:90000,LOCAL:00:00:00.000\n\n00:00:00.000 --> 00:00:02.000\nLine 1\n\n00:00:02.000 --> 00:00:04.000\nShared\n';
 const vtt2='WEBVTT\n\n00:00:02.000 --> 00:00:04.000\nShared\n\n00:00:04.000 --> 00:00:06.000\nLine 3\n';
 const merged=H.mergeWebVttSegments([vtt1,vtt2]);
 assert.equal(merged.cuesMerged,3);
 assert.equal(merged.duplicatesRemoved,1);
 assert.equal(merged.timestampMap,'MPEGTS:90000,LOCAL:00:00:00.000');
 assert.throws(()=>H.validateWebVtt('NOT_WEBVTT\n00:00:00.000 --> 00:00:01.000\nBad'),/WEBVTT_HEADER/);
});
