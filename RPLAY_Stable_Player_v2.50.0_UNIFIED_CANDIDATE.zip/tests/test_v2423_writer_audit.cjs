'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const H=require('../src/hls_transport.js'),{recording}=require('./helpers_hls.cjs');
const playlist='https://cdn.test.invalid/live.m3u8?auth=SECRET_PRIVATE&auth=SECRET2';
const ts=Buffer.alloc(376);ts[0]=ts[188]=0x47;
function m3u(seq,n=2){return '#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:'+seq+'\n'+Array.from({length:n},(_,i)=>`#EXTINF:2,\ns${seq+i}.ts?sig=SECRET_${seq+i}\n`).join('')+'#EXT-X-ENDLIST\n';}
async function poll(w,which){const r=w[which];await(which==='video'?r.pollPlaylist():r.poll(Date.now()));return r;}
for(const which of ['video','audio'])test(which+' ledger counts queued vs write-accepted, never disk-complete',async()=>{
 const w=recording(playlist,async uri=>new Response(uri.includes('m3u8')?m3u(11,2):ts));
 const r=await poll(w,which);let ev=H.writeEvidence(r);assert.equal(ev.queued,2);assert.equal(ev.accepted,0);assert.equal(ev.unresolved,2);
 await r.drain();ev=H.writeEvidence(r);assert.equal(ev.queued,2);assert.equal(ev.accepted,2);
 assert.equal(ev.terminal,0);assert.equal(ev.unresolved,0);assert.equal(ev.acceptedMediaBytes,752);
 assert.equal(ev.fileCommitted,false);assert.equal(ev.avDecoded,false);
 assert.equal(ev.provenance,'writer_acceptance_not_file_commit');
 assert.equal(JSON.stringify(ev).includes('SECRET'),false);
 assert.deepEqual(ev.tail.map(x=>x.status),['queued','queued','accepted','accepted']);
});
test('failed append is not counted as accepted, pending remains explicit',async()=>{
 const r=await poll(recording(playlist,async uri=>new Response(uri.includes('m3u8')?m3u(1,1):ts)),'video');
 r.pushData=async()=>{throw Error('write unavailable')};
 await assert.rejects(r.drain(),/write unavailable/);const ev=H.writeEvidence(r);
 assert.equal(ev.queued,1);assert.equal(ev.accepted,0);assert.equal(ev.unresolved,1);
});
test('terminal 410 increments dropped count, never accepted',async()=>{
 const r=await poll(recording(playlist,async uri=>new Response(uri.includes('m3u8')?m3u(7,1):'',{status:uri.includes('m3u8')?200:410})),'video');
 await r.drain();const ev=H.writeEvidence(r);
 assert.equal(ev.queued,1);assert.equal(ev.terminal,1);assert.equal(ev.unresolved,0);assert.equal(ev.accepted,0);
});
test('404 recovery retries without double counting accepted or terminal',async()=>{
 let n=0;const r=await poll(recording(playlist,async uri=>{if(uri.includes('m3u8'))return new Response(m3u(7,1));return n++===0?new Response('',{status:404}):new Response(ts)}),'video');
 await r.drain();assert.equal(H.writeEvidence(r).unresolved,1);r.segBackoffUntil=0;
 await r.drain();let ev=H.writeEvidence(r);assert.equal(ev.accepted,1);assert.equal(ev.terminal,0);assert.equal(ev.unresolved,0);
});
test('manifest omissions and explicit EXT-X-GAP are separated from media-accepted holes',async()=>{
 const r=await poll(recording(playlist,async uri=>new Response(uri.includes('m3u8')?m3u(10,1):ts)),'video');await r.drain();
 H.enqueue(r,H.parse(m3u(15,2).replace('#EXTINF:2,\ns16.ts','\u0023EXT-X-GAP\n#EXTINF:2,\ns16.ts'),playlist),playlist);
 const ev=H.writeEvidence(r);assert.equal(ev.queued,2);assert.equal(ev.accepted,1);
 assert.equal(ev.suspectedManifestMissing,4);assert.equal(ev.declaredGaps,1);
});
test('different discontinuity epoch is not classified as an accepted-sequence hole',async()=>{
 const o={stopped:false,state:'RUN',queue:[],seen:new Set(),partOpen:false,pushData:async()=>{o.partOpen=true;},closePart:async()=>{o.partOpen=false;}};
 for(const d of [{epoch:1,discontinuity:0,sequence:1},{epoch:1,discontinuity:0,sequence:4},{epoch:1,discontinuity:1,sequence:50},{epoch:2,discontinuity:0,sequence:1}]){
  const item={hls:{...d,map:null}};
  assert.equal(await H.append(o,item,{data:ts,boundary:'ts'},0),true);
 }
 const ev=H.writeEvidence(o);assert.equal(ev.accepted,4);assert.equal(ev.suspectedAcceptedSequenceGaps,2);assert.equal(ev.sequenceDiscontinuities,2);
});
test('init bytes accounted without confusing them with media bytes',async()=>{
 const o={stopped:false,state:'RUN',queue:[],seen:new Set(),partOpen:false,pushData:async()=>{o.partOpen=true;},closePart:async()=>{o.partOpen=false;}};
 const item={hls:{epoch:1,discontinuity:0,sequence:0,map:{uri:'https://private.invalid/init.mp4?auth=SECRET'}}};
 await H.append(o,item,{data:new Uint8Array(16),init:new Uint8Array(8),boundary:'mp4'},0);
 const ev=H.writeEvidence(o);assert.equal(ev.acceptedInitBytes,8);assert.equal(ev.acceptedMediaBytes,16);assert.equal(JSON.stringify(ev).includes('SECRET'),false);
});
test('bounded event tail, reconnect reset preserves counters, explicit new session clears',()=>{
 const o={queue:[],seen:new Set()};
 H.enqueue(o,H.parse(m3u(100,150),playlist),playlist);
 let ev=H.writeEvidence(o);assert.equal(ev.queued,150);assert.equal(ev.tail.length,96);assert(ev.truncated>0);
 H.reset(o,true);assert.equal(H.writeEvidence(o).queued,150);
 H.reset(o);assert.equal(H.writeEvidence(o).queued,150);H.clearWriteEvidence(o);ev=H.writeEvidence(o);assert.equal(ev.queued,0);assert.equal(ev.accepted,0);
});
test('audit exposed to metadata JSON for both tracks, not CLI/DRM path',()=>{
 const fs=require('node:fs');const s=fs.readFileSync(require.resolve('../src/player.user.js'),'utf8');
 assert.match(s,/segmentWriteEvidence: \(\(typeof HLS\.writeEvidence/);
 assert.match(s,/HLS\.writeEvidence\(selfRef\.audio\)/);
 assert.match(s,/HLS\.noteTerminal\(owner,item\)/);
});
