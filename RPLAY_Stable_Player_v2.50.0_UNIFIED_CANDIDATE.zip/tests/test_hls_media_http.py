"""Real FFmpeg-generated HLS -> loopback HTTP -> recording -> full decode."""
import http.server,threading,tempfile,pathlib,subprocess,sys,json,re,hashlib,unittest
R=pathlib.Path(__file__).resolve().parents[1]
class MediaHTTP(unittest.TestCase):
 def record(self,kind,engine):
  with tempfile.TemporaryDirectory() as d:
   root=pathlib.Path(d);media=root/'media';out=root/'out';media.mkdir();out.mkdir()
   args=['ffmpeg','-hide_banner','-loglevel','error','-f','lavfi','-i','testsrc2=size=128x72:rate=12','-t','2','-an','-c:v','libx264','-preset','ultrafast','-g','12','-sc_threshold','0','-f','hls','-hls_time','1']
   if kind=='mp4':args+=['-hls_segment_type','fmp4','-hls_flags','single_file','-hls_segment_filename',str(media/'media.mp4')]
   else:args+=['-hls_segment_filename',str(media/'seg%d.ts')]
   subprocess.run(args+[str(media/'live.m3u8')],check=True,capture_output=True,timeout=15)
   text=(media/'live.m3u8').read_text();requests=[]
   class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_GET(self):
     path=self.path.split('?')[0];br=self.headers.get('Range');requests.append((path,br))
     if path.startswith('/api/'):
      data=json.dumps({'streamState':'live','accessible':True,'allowAnonymous':True}).encode()
     else:data=(media/path.lstrip('/')).read_bytes()
     if br:
      m=re.fullmatch(r'bytes=(\d+)-(\d+)',br);start,end=map(int,m.groups());total=len(data);data=data[start:end+1]
      self.send_response(206);self.send_header('Content-Range','bytes %d-%d/%d'%(start,end,total))
     else:self.send_response(200)
     self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
   server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
   try:
    url='http://127.0.0.1:'+str(server.server_port)
    if engine=='cli':
     cmd=[sys.executable,str(R/'rplay_dl.py'),'a'*24,'--api',url+'/api','--m3u8',url+'/live.m3u8','--no-follow','--no-flv','--mux','no','--info-json','--out',str(out)]
    else:cmd=['node',str(R/'tests/helpers_hls.cjs'),url+'/live.m3u8',str(out/('recording.'+kind))]
    p=subprocess.run(cmd,capture_output=True,text=True,timeout=15);self.assertEqual(p.returncode,0,p.stdout+p.stderr)
    files=list(out.glob('*.'+kind));self.assertEqual(len(files),1,p.stdout);recorded=files[0]
    if kind=='mp4':
     expected=(media/'media.mp4').read_bytes();self.assertEqual(recorded.read_bytes(),expected)
     self.assertEqual(len([br for path,br in requests if path=='/media.mp4']),3)
     self.assertTrue(all(br for path,br in requests if path=='/media.mp4'))
    else:
     expected=b''.join((media/line.strip()).read_bytes() for line in text.splitlines() if line and not line.startswith('#'))
     self.assertEqual(recorded.read_bytes(),expected)
    if engine=='cli':
     info=json.loads(next(out.glob('*_info.json')).read_text());self.assertEqual(info['parts'][0]['sha256'],hashlib.sha256(expected).hexdigest());self.assertEqual(info['parts'][0]['ext'],kind)
    probe=subprocess.run(['ffprobe','-v','error','-select_streams','v:0','-count_frames','-show_entries','stream=codec_name,nb_read_frames','-of','json',str(recorded)],capture_output=True,text=True,check=True,timeout=10)
    stream=json.loads(probe.stdout)['streams'][0];self.assertEqual(stream['codec_name'],'h264');self.assertEqual(int(stream['nb_read_frames']),24)
    decoded=subprocess.run(['ffmpeg','-hide_banner','-v','error','-xerror','-i',str(recorded),'-f','null','-'],capture_output=True,text=True,timeout=10);self.assertEqual(decoded.returncode,0,decoded.stderr)
   finally:server.shutdown();server.server_close();thread.join(2)
 def test_cli_fmp4_map_ranges_decode(self):self.record('mp4','cli')
 def test_browser_core_fmp4_map_ranges_decode(self):self.record('mp4','browser_vm')
 def test_cli_ts_decode(self):self.record('ts','cli')
 def test_browser_core_ts_decode(self):self.record('ts','browser_vm')
if __name__=='__main__':unittest.main()
