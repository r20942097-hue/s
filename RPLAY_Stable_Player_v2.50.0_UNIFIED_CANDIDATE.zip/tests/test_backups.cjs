const {test}=require('node:test'),assert=require('node:assert/strict'),vm=require('vm'),fs=require('fs'),path=require('path');
const source=fs.readFileSync(path.join(__dirname,'../src/offscreen_pre.js'),'utf8');
function setup(options={}){const storage=new Map(),files=new Map();let writes=0,release;
 const gate=options.delayed?new Promise(r=>release=r):Promise.resolve();
 const dir={getFileHandle:async n=>({createWritable:async()=>({write:async b=>{writes++;},close:async()=>{await gate;if(options.fail)throw Error('quota');files.set(n,1);}})}),removeEntry:async n=>files.delete(n),async *entries(){for(const n of [...files.keys()])yield[n,{kind:'file'}];}};
 const ctx=vm.createContext({Date,Set,Promise,SET:{opfsBackup:true},osSafeName:n=>n,localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},navigator:{storage:{getDirectory:async()=>({getDirectoryHandle:async()=>dir})}}});
 const start=source.indexOf('  const BACKUP_META_KEY'),end=source.indexOf('  function markBackupClean',start);
 vm.runInContext(source.slice(start,end)+';globalThis.api={opfsBackupPart,readBackupMeta};',ctx);return {api:ctx.api,files,release:()=>release(),writes:()=>writes};
}
test('null backup does not publish metadata-only protection',async()=>{const h=setup();await h.api.opfsBackupPart(null,'x.ts',{});assert.equal(h.api.readBackupMeta().length,0);assert.equal(h.writes(),0);});
test('failed backup close leaves no committed metadata',async()=>{const h=setup({fail:true});await h.api.opfsBackupPart({},'x.ts',{});assert.equal(h.api.readBackupMeta().length,0);});
test('backup metadata is committed only after close',async()=>{const h=setup({delayed:true});const p=h.api.opfsBackupPart({},'x.ts',{});await Promise.resolve();assert.equal(h.api.readBackupMeta().length,0);h.release();await p;assert.equal(h.api.readBackupMeta().length,1);});
test('concurrent backup requests serialize and retain newest two',async()=>{const h=setup();await Promise.all(['a.ts','b.ts','c.ts'].map(n=>h.api.opfsBackupPart({},n,{})));assert.deepEqual([...h.files.keys()],['b.ts','c.ts']);assert.deepEqual(Array.from(h.api.readBackupMeta(),x=>x.file),['b.ts','c.ts']);});
