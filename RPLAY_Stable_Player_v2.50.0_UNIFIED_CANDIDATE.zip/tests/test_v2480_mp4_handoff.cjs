'use strict';
/* v2.48.0: BG停止後MP4自動引渡し — 編規律の単体検証(API/OPFSモック)。
   非破壊(元TS不変)、既定OFF、単発実行、秘密ゼロを確認する。 */
const {test}=require('node:test'),a=require('node:assert/strict'),{webcrypto}=require('node:crypto');
const Handoff=require('../src/mp4_handoff.js');

function harness(over={}){
  over=over||{};
  const state={enabled:over.enabled!==false,recording:false};
  const files=new Map();           /* name -> {size,lastModified} */
  const calls={convert:0,handoff:0,createDestination:0,destroyed:0,handoffNames:[],convertOrder:[]};
  const events=[],notified=[];
  let convertErr=null,handoffErr=null;
  const deps={
    now:()=>Date.now(),
    crypto:webcrypto,
    bootAt:over.bootAt!==undefined?over.bootAt:1000,
    settings:()=>({enabled:state.enabled}),
    isRecording:()=>state.recording,
    listParts:over.listParts||(async()=>[...files.entries()].map(([name,f])=>({name,size:f.size,lastModified:f.lastModified||0}))),
    openInputs:over.openInputs||(async names=>{
      const inputs=[];let missing=0;const seen=new Set();
      for(const n of (Array.isArray(names)?names:[])){
        if(seen.has(n))continue;seen.add(n);
        const f=files.get(n);
        if(!f||f.size<1){missing++;continue;}
        calls.convertOrder.push(n);
        inputs.push({name:n,size:f.size,getFile:async()=>({size:f.size,name:n}),isSameEntry:async o=>o===n});
      }
      return {inputs,missing};
    }),
    createDestination:over.createDestination||(async()=>{
      calls.createDestination++;
      const receipt={confirmed:true,bytes:1234,sha256:'a'.repeat(64),audio:true,aacFrames:1000,id:'f'.repeat(32)};
      return {destination:{},finalize:async()=>receipt,file:async()=>({size:receipt.bytes}),destroy:async()=>{calls.destroyed++;}};
    }),
    convert:over.convert||(async p=>{calls.convert++;if(convertErr)throw convertErr;return {confirmed:true};}),
    handoff:over.handoff||(async(file,name)=>{calls.handoff++;calls.handoffNames.push(name);if(handoffErr)throw handoffErr;return {confirmed:true};}),
    notify:(t,b)=>notified.push([String(t),String(b||'')]),
    emit:e=>events.push(e),
    excludeNames:over.excludeNames||(()=>[])
  };
  const hoff=Handoff.create(deps);
  return {hoff,state,files,calls,events,notified,setConvertError:e=>{convertErr=e;},setHandoffError:e=>{handoffErr=e;}};
}

test('v2.48.0 handoff bg-stop happy path: converts queued parts and hands the MP4 off',async()=>{
  const h=harness();
  h.files.set('p01_RPLAY_a.ts',{size:10,lastModified:500});
  h.files.set('p02_RPLAY_b.ts',{size:20,lastModified:600});
  const r=h.hoff.enqueue({trigger:'bg-stop',parts:['p01_RPLAY_a.ts','p02_RPLAY_b.ts']});
  a.equal(r.ok,true);
  await h.hoff.settled();
  const st=h.hoff.status();
  a.equal(st.counters.completed,1);
  a.equal(st.counters.bytesIn,30);
  a.equal(st.counters.bytesOut,1234);
  a.equal(h.calls.handoff,1);
  a.match(h.calls.handoffNames[0],/^RPLAY_auto_\d{14}\.mp4$/);
  a.equal(st.last.status,'complete');
  a.equal(st.last.partsTotal,2);
  a.equal(st.last.inputBytes,30);
  a.equal(st.last.outputBytes,1234);
  a.equal(st.last.audio,true);
  a.equal(st.last.aacFrames,1000);
  const phases=h.events.map(e=>e.phase);
  a.ok(phases.includes('preflight')&&phases.includes('convert')&&phases.includes('export')&&phases.includes('complete'));
  a.ok(h.notified.some(n=>n[0].includes('完了')));
});

test('v2.48.0 handoff default is disabled and never converts (現行動作維持)',async()=>{
  const h=harness({enabled:false});
  h.files.set('p01_RPLAY_a.ts',{size:10,lastModified:500});
  const r=h.hoff.enqueue({trigger:'bg-stop',parts:['p01_RPLAY_a.ts']});
  a.equal(r.ok,true);
  await h.hoff.settled();
  const st=h.hoff.status();
  a.equal(st.enabled,false);
  a.equal(st.counters.skipped,1);
  a.equal(st.last.status,'skipped');
  a.equal(st.last.reason,'disabled');
  a.equal(h.calls.convert,0);
  a.equal(h.calls.handoff,0);
});

test('v2.48.0 handoff skips while recording and reports busy-recording',async()=>{
  const h=harness();
  h.state.recording=true;
  h.files.set('p01_RPLAY_a.ts',{size:10,lastModified:500});
  h.hoff.enqueue({trigger:'bg-stop',parts:['p01_RPLAY_a.ts']});
  await h.hoff.settled();
  a.equal(h.hoff.status().last.reason,'busy-recording');
  a.equal(h.calls.convert,0);
});

test('v2.48.0 handoff reports parts-missing when staged TS no longer exists',async()=>{
  const h=harness();
  h.hoff.enqueue({trigger:'bg-stop',parts:['p99_RPLAY_gone.ts']});
  await h.hoff.settled();
  const st=h.hoff.status();
  a.equal(st.last.status,'skipped');
  a.equal(st.last.reason,'parts-missing');
  a.equal(h.calls.handoff,0);
});

test('v2.48.0 handoff part-too-large is enforced with enabled setting',async()=>{
  const h=harness();
  h.files.set('p01_RPLAY_big.ts',{size:2*1024**3+1,lastModified:500});
  h.hoff.enqueue({trigger:'bg-stop',parts:['p01_RPLAY_big.ts']});
  await h.hoff.settled();
  const st=h.hoff.status();
  a.equal(st.last.status,'skipped');
  a.equal(st.last.reason,'part-too-large');
  a.equal(h.calls.convert,0);
});

test('v2.48.0 enqueue rejects unknown triggers, non-TS and traversal names',async()=>{
  const h=harness();
  a.deepEqual(h.hoff.enqueue({trigger:'elsewhere',parts:['a.ts']}),{ok:false,error:'bad-trigger'});
  a.deepEqual(h.hoff.enqueue({trigger:'bg-stop',parts:['a.mp4']}),{ok:false,error:'no-parts'});
  a.deepEqual(h.hoff.enqueue({trigger:'bg-stop',parts:['../etc/passwd.ts']}),{ok:false,error:'no-parts'});
  a.deepEqual(h.hoff.enqueue({trigger:'bg-stop',parts:['a\\b.ts']}),{ok:false,error:'no-parts'});
  a.deepEqual(h.hoff.enqueue({trigger:'bg-stop'}),{ok:false,error:'no-parts'});
});

test('v2.48.0 enqueue dedupes repeated part names',async()=>{
  const h=harness();
  h.files.set('p01_RPLAY_a.ts',{size:5,lastModified:500});
  const r=h.hoff.enqueue({trigger:'bg-stop',parts:['p01_RPLAY_a.ts','p01_RPLAY_a.ts']});
  a.equal(r.ok,true);
  await h.hoff.settled();
  a.equal(h.hoff.status().last.partsTotal,1);
});

test('v2.48.0 enqueue refuses jobs beyond MAX_PARTS',async()=>{
  const h=harness();
  const many=Array.from({length:Handoff.MAX_PARTS+1},(_,i)=>'p'+String(i).padStart(4,'0')+'_RPLAY_x.ts');
  a.deepEqual(h.hoff.enqueue({trigger:'bg-stop',parts:many}),{ok:false,error:'too-many-parts'});
});

test('v2.48.0 conversion failure destroys staging, keeps sources and reports the code',async()=>{
  const h=harness();
  h.files.set('p01_RPLAY_a.ts',{size:10,lastModified:500});
  h.setConvertError(Error('TS_TRACK_CHANGE'));
  h.hoff.enqueue({trigger:'bg-stop',parts:['p01_RPLAY_a.ts']});
  await h.hoff.settled();
  const st=h.hoff.status();
  a.equal(st.counters.failed,1);
  a.equal(st.last.status,'failed');
  a.equal(st.last.errorCode,'CONVERT_TS_TRACK_CHANGE');
  a.equal(h.calls.destroyed,1);
  a.equal(h.calls.handoff,0);
  a.equal(h.files.size,1,'元TSは削除されない');
  a.ok(h.notified.some(n=>n[0].includes('失敗')));
});

test('v2.48.0 export failure keeps the staged MP4 recoverable and reports EXPORT_ code',async()=>{
  const h=harness();
  h.files.set('p01_RPLAY_a.ts',{size:10,lastModified:500});
  h.setHandoffError(Error('EXPORT_OFFER_FAILED'));
  h.hoff.enqueue({trigger:'bg-stop',parts:['p01_RPLAY_a.ts']});
  await h.hoff.settled();
  const st=h.hoff.status();
  a.equal(st.counters.failed,1);
  a.equal(st.last.errorCode,'EXPORT_EXPORT_OFFER_FAILED');
  a.equal(h.calls.destroyed,0,'確定済み一時MP4は変換画面から復元可能なため保持');
  a.ok(h.notified.some(n=>n[0].includes('失敗')));
});

test('v2.48.0 orphan sweep converts only stale, non-empty, tracked-excluded TS parts',async()=>{
  const exclude=[];
  const h2=harness({excludeNames:()=>exclude});
  h2.files.set('p01_RPLAY_old.ts',{size:10,lastModified:500});
  h2.files.set('p02_RPLAY_fresh.ts',{size:10,lastModified:2000});
  h2.files.set('p03_RPLAY_inflight.ts',{size:10,lastModified:400});
  h2.files.set('p04_RPLAY_empty.ts',{size:0,lastModified:300});
  exclude.push('p03_RPLAY_inflight.ts');
  const r=await h2.hoff.sweep();
  a.equal(r.ok,true);
  a.equal(r.parts,1);
  await h2.hoff.settled();
  a.deepEqual(h2.calls.convertOrder,['p01_RPLAY_old.ts']);
  a.equal(h2.hoff.status().last.trigger,'orphan-sweep');
});

test('v2.48.0 orphan sweep guards: disabled, recording, and no-orphans',async()=>{
  const h=harness({enabled:false});
  a.deepEqual(await h.hoff.sweep(),{ok:false,error:'disabled'});
  const h3=harness();
  h3.state.recording=true;
  a.deepEqual(await h3.hoff.sweep(),{ok:false,error:'busy-recording'});
  const h4=harness();
  h4.files.set('p02_RPLAY_fresh.ts',{size:10,lastModified:2000});
  a.deepEqual(await h4.hoff.sweep(),{ok:true,skipped:'no-orphans'});
});

test('v2.48.0 status evidence never contains URLs or secret-like values',async()=>{
  const h=harness();
  h.files.set('p01_RPLAY_a.ts',{size:10,lastModified:500});
  h.hoff.enqueue({trigger:'bg-stop',parts:['p01_RPLAY_a.ts']});
  await h.hoff.settled();
  const text=JSON.stringify(h.hoff.status());
  a.ok(!text.includes('https://'));
  a.ok(!text.includes('blob:'));
  a.ok(!/token|jwt|cookie/i.test(text));
});

test('v2.48.0 multiple jobs run sequentially in FIFO order',async()=>{
  const h=harness();
  h.files.set('p01_RPLAY_a.ts',{size:1,lastModified:500});
  h.files.set('p02_RPLAY_b.ts',{size:1,lastModified:600});
  h.files.set('p03_RPLAY_c.ts',{size:1,lastModified:700});
  h.hoff.enqueue({trigger:'bg-stop',parts:['p01_RPLAY_a.ts']});
  h.hoff.enqueue({trigger:'bg-stop',parts:['p02_RPLAY_b.ts','p03_RPLAY_c.ts']});
  await h.hoff.settled();
  const st=h.hoff.status();
  a.equal(st.counters.completed,2);
  a.equal(st.counters.enqueued,2);
  a.deepEqual(h.calls.convertOrder,['p01_RPLAY_a.ts','p02_RPLAY_b.ts','p03_RPLAY_c.ts']);
  a.equal(st.queued,0);
  a.equal(st.busy,false);
});

test('v2.48.0 last evidence parts list is bounded at 50 while partsTotal is exact',async()=>{
  const h=harness();
  const names=[];
  for(let i=0;i<60;i++){const n='p'+String(i).padStart(4,'0')+'_RPLAY_x.ts';names.push(n);h.files.set(n,{size:1,lastModified:500});}
  h.hoff.enqueue({trigger:'bg-stop',parts:names});
  await h.hoff.settled();
  const st=h.hoff.status();
  a.equal(st.last.partsTotal,60);
  a.equal(st.last.parts.length,50);
  a.equal(st.counters.completed,1);
});
