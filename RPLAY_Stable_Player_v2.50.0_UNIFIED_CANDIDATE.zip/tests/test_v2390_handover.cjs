'use strict';
/* v2.39.0: BG停止後のMP4変換画面引渡し — セッション台帳(rspSessionManifest/sessionEnded) + BG自動オープン(maybeOpenConverter) + 変換画面照合(rspSessionCompare) */
const {test}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const base=path.join(__dirname,'..');
const pre=fs.readFileSync(path.join(base,'src/offscreen_pre.js'),'utf8');
const bg=fs.readFileSync(path.join(base,'src/background.js'),'utf8');
const user=fs.readFileSync(path.join(base,'src/player.user.js'),'utf8');
const conv=fs.readFileSync(path.join(base,'src/mp4_convert.js'),'utf8');
const partio=fs.readFileSync(path.join(base,'src/part_io.js'),'utf8');
const id='a'.repeat(24);

/* ---- rspSessionManifest(offscreen_pre) ---- */
function extractFn(src,startMarker){
 const i=src.indexOf(startMarker);
 a.ok(i>0,'extract marker '+startMarker);
 const b=src.indexOf('{',i);let d=0,j=b;
 for(;;j++){if(src[j]==='{')d++;else if(src[j]==='}'){d--;if(!d)break;}}
 return src.slice(i,j+1);
}
const RECJOIN_SRC=extractFn(partio,'  function recJoinJob(');
function manifestCtx(){
 const c=vm.createContext({Date:{now:()=>1700000000000},console,JSON,Number,String,Array,Object,
  STATE:{creatorName:'配信者太郎'},TITLEC:{base:'配信タイトル'},recJoinJob:null});
 vm.runInContext(RECJOIN_SRC+';globalThis.recJoinJob=recJoinJob;',c);
 const i=pre.indexOf('  function rspSessionManifest(rec) {');
 const j=pre.indexOf('\n  /* =====',i);
 a.ok(i>0&&j>i,'manifest markers');
 vm.runInContext(pre.slice(i,j)+';globalThis.build=rspSessionManifest;',c);
 return rec=>vm.runInContext('build('+JSON.stringify(JSON.parse(JSON.stringify(rec)))+')',c);
}
function fakeRec(parts,extra={}){
 return Object.assign({id:id,partsLog:parts,partOpen:false,partName:'',bytes:0,audio:null,segFails:0,gapCount:0,failedSaves:0,_joinTruncated:false,_joinParts:null},extra);
}
test('v2.39.0 session manifest: video and audio parts with join job and session identity',()=>{
 const h=manifestCtx();
 const m=h(fakeRec([{file:'part-001.ts',bytes:100,sha256:'aa'},{file:'part-002.ts',bytes:200,sha256:'bb'}],
  {audio:{partsLog:[{file:'audio-001.ts',bytes:50}],partOpen:false,partName:'',bytes:0}}));
 a.equal(m.version,1);a.equal(m.oid,id);a.equal(m.creatorName,'配信者太郎');a.equal(m.title,'配信タイトル');
 a.equal(m.parts.length,3);
 a.equal(m.parts[0].name,'part-001.ts');a.equal(m.parts[0].track,'video');a.equal(m.parts[0].bytes,100);
 a.equal(m.parts[2].name,'audio-001.ts');a.equal(m.parts[2].track,'audio');
 a.equal(m.job.schema,'rsp.join.v1');a.equal(m.job.parts.length,2);
 a.equal(m.truncated,false);
});
test('v2.39.0 session manifest: empty session yields parts:[] with null job (supersedes stale)',()=>{
 const m=manifestCtx()(fakeRec([]));
 a.deepEqual(JSON.parse(JSON.stringify(m.parts)),[]);a.equal(m.job,null);a.equal(m.version,1);
 a.equal(manifestCtx()(null),null,'null recorder yields null');
});
test('v2.39.0 session manifest: open part is included and >512 parts set truncated',()=>{
 const h=manifestCtx();
 const m=h(fakeRec([],[{partOpen:true,partName:'open.ts',bytes:42}][0]));
 a.equal(m.parts.length,1);a.equal(m.parts[0].name,'open.ts');
 const many=[];for(let i=0;i<600;i++)many.push({file:'p'+i+'.ts',bytes:1});
 const m2=h(fakeRec(many));
 a.equal(m2.parts.length,512);a.equal(m2.truncated,true);
 a.ok(JSON.stringify(m2).length<=65536,'64KiB guard');
});
test('v2.39.0 sessionEnded hook: RECENV contract and offscreen wiring (source guards)',()=>{
 a.ok(user.includes('if(typeof RECENV.sessionEnded===\'function\')'),'core stop() calls the hook');
 const i=pre.indexOf('    sessionEnded: function (rec) {');
 a.ok(i>0,'offscreen hook present');
 a.ok(pre.slice(i,pre.indexOf('\n  };',i)).includes('rsp_last_session'),'writes rsp_last_session');
});

/* ---- BG maybeOpenConverter(background.js) ---- */
function bgOpenHarness(initial,opts={}){
 const store=Object.assign({},initial);
 const session=Object.assign({},opts.sessionStore);
 const opened=[];
 const c=vm.createContext({
  chrome:{runtime:{id:'rsp',getURL:n=>'chrome-extension://rsp/'+n},
   storage:{local:{get:(k,cb)=>cb(structuredClone(store))},
    session:{get:(k,cb)=>cb(structuredClone(session)),set:(o,cb)=>{Object.assign(session,structuredClone(o));cb&&cb();}}},
   tabs:{create:o=>opened.push(o)}},
  setTimeout:fn=>{if(opts.lateManifest)opts.lateManifest(store);fn();return 1;},clearTimeout:()=>{},
  console,Promise,Number,Date,
  dashboardDefaults:async()=>({rsp_dashboard_defaults:store.rsp_dashboard_defaults})});
 const i=bg.indexOf('let _rspHandoverQueue = Promise.resolve();');
 const j=bg.indexOf('chrome.runtime.onMessage.addListener',i);
 a.ok(i>0&&j>i,'maybeOpenConverter markers');
 vm.runInContext(bg.slice(i,j)+';globalThis.maybe=maybeOpenConverter;globalThis.setStore=v=>{store.rsp_last_session=v};',c);
 return {run:()=>vm.runInContext('maybe()',c),opened,store,session};
}
const freshManifest={version:1,at:Date.now(),oid:id,creatorName:'x',title:'t',
 parts:[{name:'p1.ts',bytes:10,track:'video'},{name:'p2.ts',bytes:20,track:'video'}],job:null};
test('v2.39.0 handover: disabled setting never opens the converter',async()=>{
 const h=bgOpenHarness({rsp_dashboard_defaults:{mp4Handover:false},rsp_last_session:freshManifest});
 await h.run();
 a.equal(h.opened.length,0);
});
test('v2.39.0 handover: enabled setting opens converter once for a fresh manifest with parts',async()=>{
 const h=bgOpenHarness({rsp_dashboard_defaults:{mp4Handover:true},rsp_last_session:freshManifest});
 await h.run();
 a.equal(h.opened.length,1);
 a.equal(h.opened[0].url,'chrome-extension://rsp/mp4_convert.html');
 await h.run();
 a.equal(h.opened.length,1,'session-storage dedupe blocks a second open for the same manifest');
});
test('v2.39.0 handover: stale manifest or empty parts never open',async()=>{
 const stale=Object.assign({},freshManifest,{at:Date.now()-60000});
 let h=bgOpenHarness({rsp_dashboard_defaults:{mp4Handover:true},rsp_last_session:stale});
 await h.run();
 a.equal(h.opened.length,0,'stale manifest ignored');
 h=bgOpenHarness({rsp_dashboard_defaults:{mp4Handover:true},rsp_last_session:Object.assign({},freshManifest,{parts:[]})});
 await h.run();
 a.equal(h.opened.length,0,'empty parts ignored');
 h=bgOpenHarness({rsp_dashboard_defaults:{mp4Handover:true},rsp_last_session:Object.assign({},freshManifest,{version:2})});
 await h.run();
 a.equal(h.opened.length,0,'unknown schema ignored');
});
test('v2.39.0 handover: manifest arriving during polling is picked up (max 3s window)',async()=>{
 const h=bgOpenHarness({rsp_dashboard_defaults:{mp4Handover:true}},{lateManifest:store=>{
  if(!store.rsp_last_session)store.rsp_last_session=freshManifest; /* 遅れて書かれる(停止直後の非同期書込) */
 }});
 await h.run();
 a.equal(h.opened.length,1,'late manifest opens once it appears');
});
test('v2.39.0 handover: rec.stopped wiring calls maybeOpenConverter (source guard)',()=>{
 const i=bg.indexOf("case 'rec.stopped':");
 const seg=bg.slice(i,bg.indexOf('default:',i));
 a.ok(seg.includes('maybeOpenConverter();'),'rec.stopped path triggers handover check');
 a.ok(bg.includes('d.mp4Handover !== true'),'opt-in flag gate');
});

/* ---- 変換画面の照合(mp4_convert.js rspSessionCompare) ---- */
function compareFn(){
 const c=vm.createContext({console,Set,String,Array,Number});
 const i=conv.indexOf('function rspSessionCompare(manifest,pickedNames){');
 const j=conv.indexOf('function rspSessionRender(',i);
 a.ok(i>0&&j>i,'compare markers');
 vm.runInContext(conv.slice(i,j)+';globalThis.cmp=rspSessionCompare;',c);
 return (m,p)=>vm.runInContext('cmp('+JSON.stringify(m)+','+JSON.stringify(p)+')',c);
}
test('v2.39.0 converter compare: exact video-part match, audio excluded from expected',()=>{
 const cmp=compareFn();
 const m={parts:[{name:'v1.ts',track:'video'},{name:'v2.ts',track:'video'},{name:'a1.ts',track:'audio'}]};
 a.deepEqual(JSON.parse(JSON.stringify(cmp(m,['v1.ts','v2.ts']))),{expected:2,missing:[],extra:[],match:true});
 a.deepEqual(JSON.parse(JSON.stringify(cmp(m,['v1.ts']))),{expected:2,missing:['v2.ts'],extra:[],match:false});
 a.deepEqual(JSON.parse(JSON.stringify(cmp(m,['v1.ts','v2.ts','other.ts']))),{expected:2,missing:[],extra:['other.ts'],match:false});
});
test('v2.39.0 converter compare: malformed inputs degrade safely',()=>{
 const cmp=compareFn();
 a.equal(cmp(null,['x.ts']).match,false);
 a.equal(cmp({parts:'broken'},['x.ts']).expected,0);
 a.equal(cmp({parts:[{name:'v.ts',track:'video'}]},null).match,false);
});
test('v2.39.0 converter wiring: session panel and picked-file check (source guards)',()=>{
 const html=fs.readFileSync(path.join(base,'src/mp4_convert.html'),'utf8');
 a.ok(html.includes('id="session-parts"'),'session panel present');
 a.ok(html.includes('直近のBG録画セッション'),'panel heading');
 a.ok(conv.includes('rspSessionCheck(inputs);'),'selectEntries runs the comparison');
 const dash=fs.readFileSync(path.join(base,'src/dashboard.html'),'utf8');
 a.ok(dash.includes('id="mp4Handover"'),'dashboard toggle present');
});
