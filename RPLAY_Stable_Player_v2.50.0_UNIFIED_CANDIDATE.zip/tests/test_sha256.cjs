'use strict';
const {test}=require('node:test'),a=require('node:assert/strict'),crypto=require('node:crypto');
const {Sha256,hashBlob}=require('../src/sha256.js');
const expected=b=>crypto.createHash('sha256').update(b).digest('hex');
test('SHA256 standard empty, abc, multi-block and million-a known vectors',()=>{
 for(const [data,hex] of [['','e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'],['abc','ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'],['abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq','248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1'],['a'.repeat(1000000),'cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0']])a.equal(new Sha256().update(Buffer.from(data)).digest(),hex);
});
test('SHA256 padding and arbitrary incremental partitions match Node crypto',()=>{
 for(const len of [0,1,55,56,57,63,64,65,119,120,127,128,129,4097,65537]){
  const data=crypto.randomBytes(len);for(const step of [1,7,64,137,4096]){const h=new Sha256();for(let at=0;at<len;at+=step)h.update(data.subarray(at,at+step));a.equal(h.digest(),expected(data),len+'/'+step);}
 }
});
test('SHA256 offset views, finalization and invalid inputs',()=>{
 const b=new Uint8Array([0,97,98,99,255]),h=new Sha256().update(b.subarray(1,4));a.equal(h.digest(),expected(Buffer.from('abc')));a.equal(h.digest(),h.digest());a.throws(()=>h.update(b),/HASH_FINALIZED/);a.throws(()=>new Sha256().update('abc'),/HASH_INPUT/);
});
test('Blob hashing rejects short reads instead of certifying truncated content',async()=>{
 await a.rejects(()=>hashBlob({size:10,slice:()=>({arrayBuffer:async()=>new ArrayBuffer(9)})}),/HASH_SHORT_READ/);
});
test('SHA256 bit-length carry beyond 512MiB matches Node without large allocation',()=>{
 const block=Buffer.alloc(1048576,0x61),h=new Sha256(),ref=crypto.createHash('sha256');
 for(let i=0;i<513;i++){h.update(block);ref.update(block);}a.equal(h.digest(),ref.digest('hex'));
});
