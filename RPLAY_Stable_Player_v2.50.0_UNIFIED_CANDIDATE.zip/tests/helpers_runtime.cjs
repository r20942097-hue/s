'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),vm=require('vm'),fs=require('fs'),path=require('path'),{webcrypto}=require('node:crypto');
const base=path.join(__dirname,'../rplay-stable-player-extension');
function system(firefox=false,recorderDouble=false){
 const h={store:{},files:new Map(),downloads:[],bytes:[],errors:[],host:null,bg:null,created:0};
 const dispatch=(ctx,msg,sender)=>new Promise(resolve=>{let answered=false;const response=r=>{answered=true;resolve(r)};const live=ctx.listener(msg,sender,response);if(!live&&!answered)resolve(undefined);});
 const disk={getDirectoryHandle:async()=>disk,getFileHandle:async(n,opt)=>{if(!h.files.has(n)&&!opt?.create)throw new DOMException('missing','NotFoundError');if(!h.files.has(n))h.files.set(n,new Blob([]));return {getFile:async()=>h.files.get(n),createWritable:async()=>{let b;return {write:async v=>{b=v},close:async()=>h.files.set(n,b),abort:async()=>{}}}};},removeEntry:async n=>h.files.delete(n),async *entries(){for(const n of h.files.keys())yield[n,{kind:'file',getFile:async()=>h.files.get(n)}];}};
 function make(role){
  const local=new Map();const c={Blob,URL,TextEncoder,TextDecoder,crypto:webcrypto,Date,Set,Promise,AbortController,console,
   fetch:()=>{throw Error('RPLAY network forbidden in test')},navigator:{storage:{getDirectory:async()=>disk}},
   localStorage:{getItem:k=>local.get(k)||null,setItem:(k,v)=>local.set(k,v),removeItem:k=>local.delete(k)},
   location:{pathname:role==='host'?'/offscreen.html':'/_generated_background_page.html',href:'chrome-extension://rsp/offscreen.html'},
   setTimeout:()=>1,clearTimeout:()=>{},setInterval:()=>1,clearInterval:()=>{},addEventListener:()=>{},postMessage:()=>{}};
  c.window=c;
  const runtime={id:'rsp',lastError:null,getURL:n=>'chrome-extension://rsp/'+n,onMessage:{addListener:f=>c.listener=f},onStartup:{addListener:f=>c.startup=f},onInstalled:{addListener:()=>{}},getContexts:async()=>h.host?[{}]:[],sendMessage:msg=>{
   const recipient=msg.target==='rsp-host'?h.host:h.bg;
   const sender={id:'rsp',url:role==='host'?'chrome-extension://rsp/offscreen.html':'chrome-extension://rsp/background.js'};
   return dispatch(recipient,msg,sender);
  }};
  c.chrome={runtime,storage:{local:{get:(k,cb)=>cb(structuredClone(h.store)),set:(o,cb)=>{Object.assign(h.store,structuredClone(o));cb();}}},
   downloads:{onChanged:{addListener:f=>{h.change=f}},download:(o,cb)=>{(async()=>{const response=await fetch(o.url);h.bytes.push(Buffer.from(await response.arrayBuffer()));const id=h.downloads.length+1;h.downloads.push({id,state:'in_progress',filename:'/tmp/'+o.filename,startTime:new Date().toISOString()});cb(id);})().catch(e=>h.errors.push(e));},search:(q,cb)=>cb(structuredClone(q.id===undefined?h.downloads:h.downloads.filter(i=>i.id===q.id)))},
   tabs:{query:async()=>[],sendMessage:async()=>{}},action:{setBadgeText:()=>{}},notifications:{create:()=>{}},alarms:{create:()=>{},clear:()=>{},onAlarm:{addListener:()=>{}}}};
  if(!firefox)c.chrome.offscreen={createDocument:async()=>{h.created++;loadHost();},closeDocument:async()=>{}};
  return vm.createContext(c);
 }
 function instrument(source,c){
  if(!recorderDouble)return source;
  c.TestRecorder=class {
   constructor(id,ui){this.id=id;this.ui=ui;this.recording=false;this.state='IDLE';this.failedSaves=0;}
   start(){this.recording=true;this.state='RUN';this.ui.recState(true,'RUN','ts');}
   async stop(){this.recording=false;this.isDraining=true;this.ui.recState(false,'DRAINING','ts');if(h.stopGate)await h.stopGate;this.isDraining=false;this.ui.recState(false,'IDLE','ts');}
   stats(){return {files:0};}
  };
  return source.replace('new Recorder(oid, makeUiShim(binding), deps)','new TestRecorder(oid, makeUiShim(binding), deps)').replace('  /* ---- token.update:', '  globalThis.TEST_AUTH=AUTH;\n  /* ---- token.update:');
 }
 function loadHost(){const c=make('host');h.host=c;vm.runInContext(fs.readFileSync(base+'/export_host.js','utf8'),c);vm.runInContext(fs.readFileSync(base+'/session_gate.js','utf8'),c);
  // Test-only access injection; the packaged production source is not modified.
  let source=fs.readFileSync(base+'/offscreen.js','utf8').replace('  const RSP_RECENV_HOOK = {','  globalThis.TEST_EXPORT_HOST=EXPORT_HOST;\n  const RSP_RECENV_HOOK = {');source=instrument(source,c);vm.runInContext(source,c);}
 function loadBg(){const c=make('bg');h.bg=c;vm.runInContext(fs.readFileSync(base+'/export_manager.js','utf8'),c);vm.runInContext(fs.readFileSync(base+'/background.js','utf8'),c);}
 if(firefox){
  const c=make('bg');h.host=c;h.bg=c;
  vm.runInContext(fs.readFileSync(base+'/export_host.js','utf8'),c);vm.runInContext(fs.readFileSync(base+'/session_gate.js','utf8'),c);
  vm.runInContext(instrument(fs.readFileSync(base+'/offscreen.js','utf8').replace('  const RSP_RECENV_HOOK = {','  globalThis.TEST_EXPORT_HOST=EXPORT_HOST;\n  const RSP_RECENV_HOOK = {'),c),c);
  vm.runInContext(fs.readFileSync(base+'/export_manager.js','utf8'),c);vm.runInContext(fs.readFileSync(base+'/background.js','utf8'),c);
 }else loadBg();
 h.start=()=>vm.runInContext('recoverExports()',h.bg);
 h.save=()=>vm.runInContext("TEST_EXPORT_HOST.save(new Blob(['known-bytes']),'RPLAY_integration.ts')",h.host);
 h.complete=async()=>{h.downloads[0].state='complete';h.downloads[0].fileSize=11;h.change({id:1});return vm.runInContext('exportManager.status()',h.bg);};
 h.command=(type,payload={},who={})=>dispatch(h.bg,{type,payload,clientId:who.clientId||'1'.repeat(32),control:{tabId:999,documentId:'spoof',clientId:'f'.repeat(32)}},{id:'rsp',url:'https://rplay.live/live/'+('a'.repeat(24)),frameId:who.frameId||0,documentId:who.documentId===undefined?'doc1':who.documentId,tab:{id:who.tabId||1}});
 h.auth=()=>vm.runInContext('TEST_AUTH.jwt',h.host);
 h.restartBg=loadBg;return h;
}
module.exports={system};
