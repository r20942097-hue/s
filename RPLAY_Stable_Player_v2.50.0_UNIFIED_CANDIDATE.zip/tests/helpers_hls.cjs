'use strict';
const vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
function recording(url,fetchImpl=fetch,recenv={}){
 const s=fs.readFileSync(path.join(__dirname,'../rplay-stable-player-extension/content.js'),'utf8');
 const helper=s.slice(s.indexOf('  async function recFetchDescriptor'),s.indexOf('  class AudioRecorder'));
 const classes=s.slice(s.indexOf('  class AudioRecorder'),s.indexOf('  /* ==== RSP RECORDING CORE',s.indexOf('  class AudioRecorder')));
 const c=vm.createContext({RECENV:recenv,HLS:require('../src/hls_transport.js'),fetch:fetchImpl,TextDecoder,Date,Set,Promise,setTimeout,clearTimeout,console,
  recRetryAfterMs:s=>s?Number(s)*1000:0,recHlsReloadMs:()=>1000,REC_AUDIO_STALL_MS:90000,REC_API_TIMEOUT_MS:1000,REC_SEG_TIMEOUT_MS:1000,REC_REQ_MIN_GAP_MS:0,REC_QUEUE_WARN_MS:60000,REC_SEG_MAX_TRIES:5,REC_403_COOLDOWN_MS:60000,REC_429_BASE_MS:1000,REC_429_MAX_MS:60000});
 vm.runInContext(helper+classes+';globalThis.api={Recorder,AudioRecorder};',c);
 function sink(o){return Object.assign(o,{partOpen:false,writes:[],parts:[],bytes:0,segCount:0,segTotal:0,segFails:0,seen:new Set(),queue:[],_lastReqAt:0,
 pushData(b){this.partOpen=true;this.writes.push(Buffer.from(b));},async closePart(){if(this.partOpen)this.parts.push(Buffer.concat(this.writes));this.partOpen=false;this.writes=[];},log:()=>{}});}
 const r=sink(Object.create(c.api.Recorder.prototype));Object.assign(r,{stopped:false,state:'RUN',targetDur:0,lastPollAt:0,plBackoffUntil:0,pollCount:0,consecutive404:0,consecutive429:0,segBackoffUntil:0,_queueWarnAt:0,gapCount:0,_skipBacklog:false,_lastSegAddedAt:0,playlistUrl:()=>url,bestQ:()=>false,masterUrl:'',follow:()=>false});
 const audio=sink(Object.create(c.api.AudioRecorder.prototype));Object.assign(audio,{rec:r,running:true,uri:url,backoffUntil:0,c429:0,targetDur:0,lastSeq:-1});
 return {video:r,audio};
}
module.exports={recording};
if(require.main===module)(async()=>{const {video:r}=recording(process.argv[2]);await r.pollPlaylist();await r.drain();await r.closePart();if(r.segFails||r.queue.length||!r.parts.length)throw Error('recording failed');fs.writeFileSync(process.argv[3],Buffer.concat(r.parts));process.stdout.write(JSON.stringify({segments:r.segTotal,parts:r.parts.length,format:r.mediaFormat}));})().catch(e=>{console.error(e);process.exitCode=1;});
