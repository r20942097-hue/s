'use strict';
const {test}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const X=require('../src/cross_site_core.js'),C=require('../src/media_catalog.js'),M=require('../src/media_inspect_core.js'),H=require('../src/hls_transport.js');
const signed='https://cdn.example.invalid/watch/master.mpd?sig=Ab%2F1&sig=Z&state=TOKEN_PRIVATE';
const dynamic=`<?xml version="1.0" encoding="utf-8"?>
<MPD xmlns="urn:mpeg:dash:schema:mpd:2011" type="dynamic" minimumUpdatePeriod="PT4.5S" availabilityStartTime="2026-10-27T01:00:00Z" timeShiftBufferDepth="PT20S">
 <BaseURL>https://edge.invalid/SECRET_SEGMENT?token=VERY_SECRET</BaseURL>
 <Period id="p0"><AdaptationSet contentType="video" mimeType="video/mp4" id="v">
 <SegmentTemplate timescale="90000" media="v/$RepresentationID$/$Time$.m4s?sig=HIDDEN" initialization="v/init.mp4" startNumber="1">
  <SegmentTimeline><S t="0" d="180000" r="2"/><S d="180000" r="-1" /></SegmentTimeline></SegmentTemplate>
 <Representation id="720p" bandwidth="1200000" width="1280" height="720"/>
 <Representation id="1080p" bandwidth="2300000" width="1920" height="1080"/>
 </AdaptationSet><AdaptationSet contentType="audio"><Representation id="japanese" mimeType="audio/mp4" bandwidth="128000" /></AdaptationSet></Period>
</MPD>`;
const vod='<MPD type="static"><Period><AdaptationSet mimeType="video/mp4"><SegmentList><SegmentURL media="p1.m4s"/><SegmentURL media="p2.m4s"/></SegmentList><Representation id="1"/></AdaptationSet></Period></MPD>';
function fixture(inner){return '<MPD>'+inner+'</MPD>'}
test('dynamic MPEG-DASH MPD: counts periods, representations, audio, timeline',()=>{const p=X.parseDASH(dynamic);a.equal(p.kind,'dash');a.equal(p.manifestType,'dynamic');a.equal(p.periods,1);a.equal(p.representations,3);a.equal(p.audioAdaptations,1);a.equal(p.videoAdaptations,1);a.equal(p.segmentTemplates,1);a.equal(p.timelineEntries,2);a.equal(p.timelineExpanded,3);a.equal(p.indefiniteTimeline,true);a.equal(p.minimumUpdateSeconds,4.5);a.equal(p.externalReferencesFetched,false);a.equal(p.recordingComplete,false);});
test('signed URLs and private BaseURL text are absent in report',()=>{const r=M.safeReport({url:signed,mime:'application/dash+xml',body:dynamic});a.equal(r.hls,null);a.equal(r.workflow.stage,'DASH_LIVE_DIAGNOSTICS');a.equal(r.commandsIncluded,false);for(const secret of ['SECRET_SEGMENT','VERY_SECRET','TOKEN_PRIVATE','HIDDEN'])a.equal(JSON.stringify(r).includes(secret),false);});
test('static MPD with SegmentList and segment URL count',()=>{const x=X.parseDASH(vod);a.equal(x.segmentUrls,2);a.equal(x.segmentLists,1);a.equal(x.timelineEntries,0);a.equal(x.manifestType,'static');a.equal(M.safeReport({url:signed,body:vod}).workflow.stage,'DASH_VOD_DIAGNOSTICS');});
test('DASH XML attributes with quoted > characters are not token delimiters',()=>{const x=X.parseDASH(fixture('<Period id="a>b"><AdaptationSet mimeType="audio/mp4"><Representation id="a"/></AdaptationSet></Period>'));a.equal(x.audioAdaptations,1);});
test('namespace-prefixed MPD and nodes accepted',()=>{const x=X.parseDASH('<d:MPD xmlns:d="urn:mpeg:dash:schema:mpd:2011"><d:Period><d:AdaptationSet><d:Representation id="x"/></d:AdaptationSet></d:Period></d:MPD>');a.equal(x.periods,1);a.equal(x.representations,1);});
test('ContentProtection and external XLink are flagged without fetching',()=>{const x=X.parseDASH(fixture('<Period xlink:href="https://other.invalid/secret.xml?key=SECRET" xmlns:xlink="http://www.w3.org/1999/xlink"><AdaptationSet><ContentProtection schemeIdUri="urn:uuid:secret"/></AdaptationSet></Period>'));a.equal(x.contentProtection,1);a.equal(x.remoteXlinks,1);a.equal(x.externalReferencesFetched,false);a.equal(JSON.stringify(x).includes('SECRET'),false);});
test('XML external entities and DOCTYPE rejected',()=>{a.throws(()=>X.parseDASH('<!DOCTYPE MPD [ <!ENTITY x SYSTEM "file:///etc/passwd"> ]><MPD>&x;</MPD>'),/DASH_DTD_FORBIDDEN/);});
test('XML comments and processing instructions skipped',()=>{a.equal(X.parseDASH('<?xml version="1.0"?><MPD><!-- note --><Period /></MPD>').periods,1);});
test('invalid XML nesting rejected',()=>a.throws(()=>X.parseDASH('<MPD><Period></MPD></Period>'),/INVALID_DASH_XML/));
test('unclosed XML element rejected',()=>a.throws(()=>X.parseDASH('<MPD><Period/>'),/INVALID_DASH_XML/));
test('non-DASH root rejected',()=>a.throws(()=>X.parseDASH('<html><video/></html>'),/BODY_NOT_DASH/));
test('second root rejected',()=>a.throws(()=>X.parseDASH('<MPD/><MPD/>'),/INVALID_DASH_XML/));
test('malformed attributes and duplicate keys rejected',()=>{a.throws(()=>X.parseDASH('<MPD type=dynamic/>'),/INVALID_DASH_XML/);a.throws(()=>X.parseDASH('<MPD type="static" type="dynamic"/>'),/INVALID_DASH_XML/);});
test('refuses oversized manifest',()=>a.throws(()=>X.parseDASH('<MPD>'+(' '.repeat(2097152))+'</MPD>'),/DASH_LIMIT/));
test('max XML depth enforced',()=>a.throws(()=>X.parseDASH('<MPD>'+('<Period>'.repeat(40))+'</Period>'.repeat(40)+'</MPD>'),/DASH_DEPTH_LIMIT/));
test('timeline invalid repetition rejected',()=>a.throws(()=>X.parseDASH(fixture('<Period><SegmentTimeline><S d="4" r="-2" /></SegmentTimeline></Period>')),/DASH_TIMELINE_LIMIT/));
test('timeline very high repeat rejected',()=>a.throws(()=>X.parseDASH(fixture('<SegmentTimeline><S r="1000001"/></SegmentTimeline>')),/DASH_TIMELINE_LIMIT/));
test('dynamic MPD with no refresh hints only warns',()=>{const r=X.parseDASH(fixture('<Period/>').replace('<MPD>','<MPD type="dynamic">'));a.equal(r.minimumUpdateSeconds,null);a.ok(r.warnings.some(x=>x.includes('refresh')));});
test('HLS delta skip correct media sequence accounting',()=>{const p=X.parseHLS('#EXTM3U\n#EXT-X-TARGETDURATION:4\n#EXT-X-MEDIA-SEQUENCE:20\n#EXT-X-SKIP:SKIPPED-SEGMENTS=4\n#EXTINF:4,\nf24.ts\n#EXTINF:4,\nf25.ts\n',signed);a.deepEqual(p.segments.map(x=>x.sequence),[24,25]);a.equal(X.publicReport(p).skippedSegments,4);});
test('HLS skipped regions do not hide a genuine live-window gap',()=>{const m=X.createMonitor(),u='https://cdn.invalid/live.m3u8?session=1';const p=seq=>X.parseHLS(`#EXTM3U\n#EXT-X-TARGETDURATION:4\n#EXT-X-MEDIA-SEQUENCE:${seq}\n#EXTINF:4,\nf${seq}.ts\n`,u);m.observe(u,p(10));const result=m.observe(u,p(14));a.equal(result.possibleMissing,3);});
test('duplicate delta skip rejected without serializing private text',()=>a.throws(()=>X.parseHLS('#EXTM3U\n#EXT-X-SKIP:SKIPPED-SEGMENTS=1\n#EXT-X-SKIP:SKIPPED-SEGMENTS=2\n',signed),/DUPLICATE_HLS_SKIP/));
test('MPD loader only fetches manifest and respects explicit cookie switch',async()=>{const requests=[];const fetchImpl=async (url,opts)=>{requests.push({url,opts});return new Response(dynamic,{status:200,headers:{'Content-Type':'application/dash+xml'}});};let r=await C.loadDASH(signed,{HLS:H,DASH:X,fetchImpl});a.equal(r.report.representations,3);a.equal(requests[0].url,signed);a.equal(requests[0].opts.credentials,'omit');a.equal(requests[0].opts.redirect,'error');r=await C.loadDASH(signed,{HLS:H,DASH:X,fetchImpl,useCookies:true});a.equal(requests[1].opts.credentials,'include');a.equal(r.rows.length,0);});
test('MPD loader refuses non-DASH response body',async()=>{await a.rejects(C.loadDASH(signed,{HLS:H,DASH:X,fetchImpl:async()=>new Response('<html>no</html>')}),/BODY_NOT_DASH/);});
test('DASH partial HTTP 206 is not treated as a complete MPD',async()=>{await a.rejects(C.loadDASH(signed,{HLS:H,DASH:X,fetchImpl:async()=>new Response(vod,{status:206,headers:{'Content-Range':'bytes 0-9/100'}})}),/DASH_EXPECT_FULL_200|HLS_UNEXPECTED_RANGE/);});
test('MPD loader returns no file or segment bytes to caller',async()=>{const r=await C.loadDASH(signed,{HLS:H,DASH:X,fetchImpl:async()=>new Response(vod)});a.equal(r.report.downloaded,false);a.equal(r.report.externalReferencesFetched,false);a.deepEqual(r.rows,[]);});
test('both packed WebExtension variants contain MPD inspector with original permissions',()=>{for(const d of ['rplay-stable-player-extension','rplay-stable-player-extension-firefox']){const manifest=require('../'+d+'/manifest.json');a.equal(manifest.version,'2.50.0');a.ok(!manifest.permissions.includes('cookies'));a.match(fs.readFileSync(d+'/media_inspect.html','utf8'),/DASH/);a.match(fs.readFileSync(d+'/cross_site_core.js','utf8'),/parseDASH/);}});
