'use strict';
const {test}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),path=require('path'),vm=require('node:vm');
const D=require('../src/preview_diag.js');
const ROOT=path.join(__dirname,'..');

/* ---- codecSupport: canPlayTypeの trio 収集 ---- */
test('v2.48.0 codecSupport maps canPlayType results for video/audio/combined',()=>{
  a.deepEqual(D.codecSupport({canPlayType:t=>t.startsWith('audio')?'maybe':'probably'}),{video:'probably',audio:'maybe',combined:'probably'});
  a.equal(D.codecSupport({canPlayType:()=>'probably'}).combined,'probably');
});
test('v2.48.0 codecSupport tolerates missing or throwing canPlayType as empty',()=>{
  a.deepEqual(D.codecSupport({}),{video:'',audio:'',combined:''});
  a.deepEqual(D.codecSupport(null),{video:'',audio:'',combined:''});
  a.deepEqual(D.codecSupport({canPlayType(){throw Error('x');}}),{video:'',audio:'',combined:''});
});

/* ---- classifyPreview: 要因の切分け ---- */
test('v2.48.0 classifyPreview NO_DECODER from MEDIA_ERR_SRC_NOT_SUPPORTED or empty canPlayType',()=>{
  const c1=D.classifyPreview({errorCode:4,canPlay:'probably',timeAdvanced:false});
  a.equal(c1.factor,'environment');a.equal(c1.code,'NO_DECODER');a.match(c1.message,/環境要因/);a.match(c1.message,/H\.264/);
  const c2=D.classifyPreview({canPlay:''});
  a.equal(c2.factor,'environment');a.equal(c2.code,'NO_DECODER');
});
test('v2.48.0 classifyPreview AUTOPLAY_BLOCKED from NotAllowedError play rejection',()=>{
  const c=D.classifyPreview({canPlay:'probably',playRejection:'NotAllowedError'});
  a.equal(c.factor,'policy');a.equal(c.code,'AUTOPLAY_BLOCKED');a.match(c.message,/自動再生をブロック/);
});
test('v2.48.0 classifyPreview DECODE_ERROR from MEDIA_ERR_DECODE with decoder present',()=>{
  const c=D.classifyPreview({canPlay:'probably',errorCode:3});
  a.equal(c.factor,'content');a.equal(c.code,'DECODE_ERROR');a.match(c.message,/デコードエラー/);
});
test('v2.48.0 classifyPreview FROZEN_CLOCK classifies non-advancing playback as environment',()=>{
  const c=D.classifyPreview({canPlay:'probably',timeAdvanced:false,readyState:4,paused:false});
  a.equal(c.factor,'environment');a.equal(c.code,'FROZEN_CLOCK');a.match(c.message,/再生時刻が進んでいません/);a.match(c.message,/保存・構造照合には影響しません/);
});
test('v2.48.0 classifyPreview PLAYBACK_OK and UNKNOWN fallbacks',()=>{
  const ok=D.classifyPreview({canPlay:'probably',timeAdvanced:true});
  a.equal(ok.factor,'none');a.equal(ok.code,'PLAYBACK_OK');
  const un=D.classifyPreview({canPlay:'maybe'});
  a.equal(un.factor,'unknown');a.equal(un.code,'UNKNOWN');a.match(un.message,/対応プレイヤーで確認/);
  a.equal(D.classifyPreview(null).code,'UNKNOWN');
  a.equal(D.classifyPreview({errorCode:1,canPlay:'probably'}).code,'UNKNOWN');  /* ABORTEDは確定しない */
});
test('v2.48.0 classifyPreview precedence: NO_DECODER outranks autoplay rejection and frozen clock',()=>{
  a.equal(D.classifyPreview({errorCode:4,canPlay:'',playRejection:'NotAllowedError',timeAdvanced:false}).code,'NO_DECODER');
  a.equal(D.classifyPreview({canPlay:'probably',playRejection:'NotAllowedError',timeAdvanced:false}).code,'AUTOPLAY_BLOCKED');
  a.equal(D.classifyPreview({canPlay:'probably',errorCode:3,timeAdvanced:false}).code,'DECODE_ERROR');
});

/* ---- videoState: 状態収集 + extra併合 ---- */
test('v2.48.0 videoState collects element state and merges extra probes',()=>{
  const v={currentTime:1.5,paused:false,readyState:3,canPlayType:()=>'maybe',error:{code:0}};
  a.deepEqual(D.videoState(v),{canPlay:'maybe',errorCode:0,playRejection:null,timeAdvanced:null,readyState:3,paused:false});
  a.deepEqual(D.videoState(v,{timeAdvanced:true}),{canPlay:'maybe',errorCode:0,playRejection:null,timeAdvanced:true,readyState:3,paused:false});
  a.deepEqual(D.videoState(null),{canPlay:'',errorCode:null,playRejection:null,timeAdvanced:null,readyState:0,paused:true});
});

/* ---- watchClock: play後の時計監視 ---- */
test('v2.48.0 watchClock fires onFrozen with a non-advancing classification state',async()=>{
  let frozen=null;
  const v={currentTime:0,paused:false,readyState:4,canPlayType:()=>'probably',error:null};
  const w=D.watchClock(v,{interval:2,threshold:8,onFrozen:s=>{frozen=s;}});
  await new Promise(r=>setTimeout(r,50));
  a.ok(frozen,'onFrozen fired');
  a.equal(frozen.timeAdvanced,false);
  a.equal(D.classifyPreview(frozen).code,'FROZEN_CLOCK');
});
test('v2.48.0 watchClock fires onOk once the clock advances past the threshold',async()=>{
  let ok=false,frozen=null;
  const t0=Date.now();
  const v={get currentTime(){return (Date.now()-t0)/1000;},paused:false,readyState:4,canPlayType:()=>'probably',error:null};
  const w=D.watchClock(v,{interval:2,threshold:8,advance:0.01,onOk:()=>{ok=true;},onFrozen:s=>{frozen=s;}});
  await new Promise(r=>setTimeout(r,60));
  a.ok(ok,'onOk fired');a.equal(frozen,null);
});
test('v2.48.0 watchClock never classifies a paused element as frozen',async()=>{
  let frozen=null;
  const v={currentTime:0,paused:true,readyState:4,canPlayType:()=>'probably',error:null};
  const w=D.watchClock(v,{interval:2,threshold:8,onFrozen:s=>{frozen=s;}});
  await new Promise(r=>setTimeout(r,40));
  a.equal(frozen,null);w.stop();
});
test('v2.48.0 watchClock stop() prevents all later callbacks',async()=>{
  let frozen=null,ok=false;
  const v={currentTime:0,paused:false,readyState:4,canPlayType:()=>'probably',error:null};
  const w=D.watchClock(v,{interval:2,threshold:8,onFrozen:s=>{frozen=s;},onOk:()=>{ok=true;}});
  w.stop();
  await new Promise(r=>setTimeout(r,40));
  a.equal(frozen,null);a.equal(ok,false);
});

/* ---- ページ組み込み: mp4_convert.js + preview_diag.js (vm) ---- */
function setupPage({convert}={}){
  class Element{constructor(){this.disabled=false;this.hidden=false;this.textContent='';this.handlers={};this.children=[];this.files=[];this.value='';this.tag='';this.videoWidth=0;this.videoHeight=0;this.currentTime=0;this.duration=NaN;this.paused=true;this.readyState=0;this.error=null;this.currentSrc='';this.canPlayType=()=>'probably';}
   replaceChildren(){this.children=[];}append(...e){this.children.push(...e);}setAttribute(k,v){this[k]=v;}getAttribute(k){return this[k];}removeAttribute(k){delete this[k];}
   querySelectorAll(){return this.children.flatMap(e=>e instanceof Element?[e,...e.querySelectorAll()]:[]).filter(e=>e.tag==='button');}
   addEventListener(n,f){this.handlers[n]=f;}async click(){await new Promise(setImmediate);if(!this.disabled)return this.handlers.click?.({preventDefault(){}});}
   play(){this.paused=false;return Promise.resolve();}pause(){this.paused=true;}load(){}}
  const els=Object.fromEntries(['choose','start','cancel','items','status','file-chooser','download','discard','staged','mode','progress','report','preview','preview-status'].map(n=>[n,new Element()]));
  els.start.disabled=els.cancel.disabled=true;els.download.hidden=true;
  const handles=['part1.ts'].map(name=>({name,getFile:async()=>({name,size:1024})}));
  const win={showOpenFilePicker:async()=>handles,showSaveFilePicker:async()=>({}),addEventListener:()=>{}};
  let ctl;
  class FakeWorker{postMessage(m){if(m.type==='cancel'){ctl.abort();return;}if(m.type==='list'){queueMicrotask(()=>this.onmessage({data:{id:m.id,type:'listed',jobs:[]}}));return;}if(m.type==='convert'){ctl=new AbortController();Promise.resolve().then(()=>(convert||(async()=>({bytes:123,audio:true,sha256:'abc'})))({inputs:m.inputs,signal:ctl.signal,onProgress:p=>this.onmessage({data:{id:m.id,type:'progress',progress:p}})})).then(()=>this.onmessage({data:{id:m.id,type:'ready',receipt:{id:'job1',bytes:123,audio:true,sha256:'abc',createdAt:'20261027T000000Z'},file:{slice:()=>new Blob(['x']),size:123},result:{bytes:123,audio:true,sha256:'abc'}}}),e=>this.onmessage({data:{id:m.id,type:'error',error:e.message}}));}}terminate(){}}
  const sandbox={document:{getElementById:n=>els[n],createElement:tag=>{const e=new Element();e.tag=tag;return e;}},window:win,Worker:FakeWorker,Blob,URL,AbortController,Error,console,setTimeout,setInterval,clearInterval};
  const ctx=vm.createContext(sandbox);
  vm.runInContext(fs.readFileSync(path.join(ROOT,'src/preview_diag.js'),'utf8'),ctx);
  vm.runInContext(fs.readFileSync(path.join(ROOT,'src/mp4_convert.js'),'utf8'),ctx);
  return {els,sandbox,ctx};
}
async function completeConversion(page){
  await page.els.choose.click();
  await page.els.start.click();
  await new Promise(r=>setTimeout(r,30));
}

test('v2.48.0 mp4_convert.html loads preview_diag.js before the page script',()=>{
  const html=fs.readFileSync(path.join(ROOT,'src/mp4_convert.html'),'utf8');
  a.ok(html.includes('<script src="preview_diag.js"></script><script src="mp4_convert.js"></script>'),'script tag order');
});
test('v2.48.0 build/validate wiring lists preview_diag.js in every derived-copy loop',()=>{
  const build=fs.readFileSync(path.join(ROOT,'scripts/build.py'),'utf8');
  a.ok(build.split('preview_diag.js').length-1>=2,'build.py copies into extension and root loops');
  const val=fs.readFileSync(path.join(ROOT,'scripts/validate.py'),'utf8');
  a.ok(val.includes("'preview_diag.js'"),'validate.py derived-copy guard');
});
test('v2.48.0 page error event classifies NO_DECODER and shows the environment-factor guidance',async()=>{
  const page=setupPage();await completeConversion(page);
  page.els.preview.canPlayType=()=>'';
  page.els.preview.error={code:4};
  page.els.preview.handlers.error();
  a.match(page.els['preview-status'].textContent,/環境要因/);
  a.match(page.els['preview-status'].textContent,/H\.264\/AACの再生に対応していない/);
  a.doesNotMatch(page.els['preview-status'].textContent,/再生時刻が進んでいません/);
});
test('v2.48.0 page error event classifies DECODE_ERROR when the decoder exists',async()=>{
  const page=setupPage();await completeConversion(page);
  page.els.preview.error={code:3};
  page.els.preview.handlers.error();
  a.match(page.els['preview-status'].textContent,/デコードエラー/);
  a.doesNotMatch(page.els['preview-status'].textContent,/環境要因/);
});
test('v2.48.0 page play watchdog reports FROZEN_CLOCK when the clock never advances',async()=>{
  const page=setupPage();await completeConversion(page);
  const real=D.watchClock;
  page.sandbox.RspPreviewDiag.watchClock=(v,opts)=>real(v,{...opts,interval:2,threshold:8});
  page.els.preview.paused=false;page.els.preview.readyState=4;
  page.els.preview.handlers.play();
  await new Promise(r=>setTimeout(r,50));
  a.match(page.els['preview-status'].textContent,/再生時刻が進んでいません/);
  a.match(page.els['preview-status'].textContent,/保存・構造照合には影響しません/);
});
test('v2.48.0 page play watchdog confirms playback when the clock advances',async()=>{
  const page=setupPage();await completeConversion(page);
  const real=D.watchClock,t0=Date.now();
  page.sandbox.RspPreviewDiag.watchClock=(v,opts)=>real(v,{...opts,interval:2,threshold:200,advance:0.01});
  Object.defineProperty(page.els.preview,'currentTime',{get(){return (Date.now()-t0)/1000;},configurable:true});
  page.els.preview.paused=false;page.els.preview.readyState=4;
  page.els.preview.handlers.play();
  await new Promise(r=>setTimeout(r,60));
  a.match(page.els['preview-status'].textContent,/再生されています/);
  a.doesNotMatch(page.els['preview-status'].textContent,/再生時刻が進んでいません/);
});
test('v2.48.0 page pause event stops the running watchdog',async()=>{
  const page=setupPage();await completeConversion(page);
  let stopped=0;
  page.sandbox.RspPreviewDiag.watchClock=()=>({stop(){stopped++;}});
  page.els.preview.paused=false;
  page.els.preview.handlers.play();
  a.equal(stopped,0);
  page.els.preview.handlers.pause();
  a.equal(stopped,1);
});
test('v2.48.0 page falls back to the legacy fixed message when the module is missing',async()=>{
  const page=setupPage();await completeConversion(page);
  page.sandbox.RspPreviewDiag=undefined;
  page.els.preview.error={code:4};
  page.els.preview.handlers.error();
  a.equal(page.els['preview-status'].textContent,'この環境ではプレビューを再生できません。MP4の保存・構造照合とは別に、対応プレイヤーで確認してください。');
  page.els.preview.paused=false;
  page.els.preview.handlers.play();  /* モジュール不在でも例外にならない */
});
test('v2.48.0 conversion status and controls stay unaffected by the diagnostics wiring',async()=>{
  const page=setupPage();
  await completeConversion(page);
  a.match(page.els.status.textContent,/ハッシュ照合が完了/);
  a.equal(page.els.preview.hidden,false);
  a.equal(page.els['preview-status'].textContent,'');
});
