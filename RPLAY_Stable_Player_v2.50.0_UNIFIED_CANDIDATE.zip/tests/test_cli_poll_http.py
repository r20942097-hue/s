import http.server,threading,tempfile,pathlib,subprocess,sys,json,time,unittest
R=pathlib.Path(__file__).resolve().parents[1]
class PollHTTP(unittest.TestCase):
 def test_recording_reload_minima_on_local_http(self):
  reloads=[];packet=bytearray([0]*188);packet[0]=0x47;data=bytes(packet)*5
  class Handler(http.server.BaseHTTPRequestHandler):
   def log_message(self,*args):pass
   def do_GET(self):
    path=self.path.split('?')[0]
    if path=='/live.m3u8':
     reloads.append(time.monotonic());body=b'#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:1\n#EXTINF:1,\nseg.ts\n'
     if len(reloads)>=4:body+=b'#EXT-X-ENDLIST\n'
    elif path=='/seg.ts':body=data
    else:body=json.dumps({'streamState':'live','accessible':True,'allowAnonymous':True}).encode()
    self.send_response(200);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
  server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  try:
   with tempfile.TemporaryDirectory() as d:
    url='http://127.0.0.1:'+str(server.server_port)
    p=subprocess.run([sys.executable,str(R/'rplay_dl.py'),'a'*24,'--api',url+'/api','--m3u8',url+'/live.m3u8','--no-follow','--no-flv','--mux','no','--out',d],capture_output=True,text=True,timeout=12)
    self.assertEqual(p.returncode,0,p.stdout+p.stderr);self.assertEqual(len(reloads),4,p.stdout)
    # Request 1 is the pre-recording source probe, outside this recording-loop policy.
    self.assertGreaterEqual(reloads[2]-reloads[1],.99)
    self.assertGreaterEqual(reloads[3]-reloads[2],.49)
    self.assertEqual(next(pathlib.Path(d).glob('*.ts')).read_bytes(),data)
  finally:server.shutdown();server.server_close();thread.join(2)
if __name__=='__main__':unittest.main()
