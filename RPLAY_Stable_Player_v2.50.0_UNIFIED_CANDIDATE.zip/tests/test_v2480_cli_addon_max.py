#!/usr/bin/env python3
"""v2.48.0 tests: Multi-part joiner WebVTT subtitle muxing (mov_text) and rplay_dl.py --join-files CLI mode."""
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RPLAY_DL = ROOT / "rplay_dl.py"
RPLAY_JOIN = ROOT / "rplay_join.py"


def make_sample_ts(path: Path, start_sec: float = 0.0, duration_sec: float = 1.0):
    cmd = [
        "ffmpeg", "-v", "error", "-y",
        "-f", "lavfi", "-i", f"testsrc2=size=160x90:rate=10:duration={duration_sec}",
        "-f", "lavfi", "-i", f"sine=frequency=440:sample_rate=48000:duration={duration_sec}",
        "-output_ts_offset", str(start_sec),
        "-c:v", "libx264", "-preset", "ultrafast", "-g", "10",
        "-c:a", "aac", "-b:a", "64k",
        "-f", "mpegts", str(path),
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    assert proc.returncode == 0, proc.stderr


class TestV2480CliJoinAndSubtitleMux(unittest.TestCase):
    def test_rplay_join_subtitle_mux_and_fail_closed_validation(self):
        with tempfile.TemporaryDirectory() as td:
            td_path = Path(td)
            p1 = td_path / "part1.ts"
            p2 = td_path / "part2.ts"
            vtt = td_path / "subs.vtt"
            bad_vtt = td_path / "bad.vtt"
            out_mp4 = td_path / "joined_with_subs.mp4"

            make_sample_ts(p1, 0.0, 1.0)
            make_sample_ts(p2, 1.0, 1.0)
            vtt.write_text(
                "WEBVTT\n\n"
                "00:00:00.200 --> 00:00:01.500\n"
                "First subtitle line\n",
                encoding="utf-8",
            )
            bad_vtt.write_text("NOT_A_WEBVTT_FILE\n", encoding="utf-8")

            # 1. Fail-closed on invalid WebVTT header
            proc_bad = subprocess.run(
                [sys.executable, str(RPLAY_JOIN), "--files", p1.name, p2.name, "--directory", str(td_path), "--subtitle", str(bad_vtt), "--output", str(out_mp4)],
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(proc_bad.returncode, 2)
            bad_res = json.loads(proc_bad.stdout)
            self.assertEqual(bad_res["status"], "FAILED")
            self.assertEqual(bad_res["code"], "JOIN_BAD_SUBTITLE")
            self.assertFalse(out_mp4.exists())

            # 2. Valid WebVTT subtitle muxing into MP4 (mov_text)
            proc_ok = subprocess.run(
                [sys.executable, str(RPLAY_JOIN), "--files", p1.name, p2.name, "--directory", str(td_path), "--subtitle", str(vtt), "--subtitle-lang", "jpn", "--output", str(out_mp4)],
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(proc_ok.returncode, 0, msg=proc_ok.stderr + proc_ok.stdout)
            res = json.loads(proc_ok.stdout)
            self.assertEqual(res["status"], "JOINED_DECODE_VERIFIED")
            self.assertTrue(res["subtitleMuxed"])
            self.assertEqual(res["subtitleFile"], "subs.vtt")
            self.assertEqual(res["subtitleLang"], "jpn")
            self.assertTrue(out_mp4.is_file())

            # Verify via ffprobe that h264, aac, and mov_text streams are all present
            probe = subprocess.run(
                ["ffprobe", "-v", "error", "-show_streams", "-of", "json", str(out_mp4)],
                capture_output=True,
                text=True,
                check=True,
            )
            streams = json.loads(probe.stdout)["streams"]
            codecs = sorted(s.get("codec_name") for s in streams)
            self.assertEqual(codecs, ["aac", "h264", "mov_text"])

    def test_rplay_dl_join_files_cli_mode(self):
        with tempfile.TemporaryDirectory() as td:
            td_path = Path(td)
            p1 = td_path / "seg_a.ts"
            p2 = td_path / "seg_b.ts"
            vtt = td_path / "caption.vtt"
            out_mp4 = td_path / "cli_joined.mp4"

            make_sample_ts(p1, 0.0, 1.0)
            make_sample_ts(p2, 1.0, 1.0)
            vtt.write_text(
                "WEBVTT\n\n"
                "00:00:00.100 --> 00:00:01.800\n"
                "CLI joined caption\n",
                encoding="utf-8",
            )

            proc = subprocess.run(
                [
                    sys.executable, str(RPLAY_DL),
                    "--join-files", str(p1), str(p2),
                    "--join-subtitle", str(vtt),
                    "--join-subtitle-lang", "eng",
                    "--join-out", str(out_mp4),
                ],
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(proc.returncode, 0, msg=proc.stderr + proc.stdout)
            data = json.loads(proc.stdout)
            self.assertEqual(data["status"], "JOINED_DECODE_VERIFIED")
            self.assertEqual(data["parts"], 2)
            self.assertTrue(data["subtitleMuxed"])
            self.assertEqual(data["subtitleLang"], "eng")
            self.assertTrue(out_mp4.is_file())


if __name__ == "__main__":
    unittest.main()
