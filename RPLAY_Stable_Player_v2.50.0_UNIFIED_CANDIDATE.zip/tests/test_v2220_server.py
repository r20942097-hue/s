import importlib.util,unittest,threading,urllib.request,urllib.error
from pathlib import Path
spec=importlib.util.spec_from_file_location('serve_mp4',Path(__file__).resolve().parents[1]/'scripts/serve_mp4.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
class LocalServer(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.server=module.create_server();cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start();cls.base=f'http://127.0.0.1:{cls.server.server_port}'
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.thread.join(5)
 def test_only_loopback_and_conversion_assets(self):
  self.assertEqual(self.server.server_address[0],'127.0.0.1')
  for path in ['/','/mp4_convert_worker.js','/libs/mux.min.js','/media_inspect.html','/media_inspect_core.js','/hls_transport.js','/media_catalog.js','/cross_site_compat.js']:
   with urllib.request.urlopen(self.base+path) as r:self.assertEqual(r.status,200);self.assertEqual(r.headers['Cache-Control'],'no-store');self.assertGreater(len(r.read()),0)
 def test_no_project_source_or_path_traversal(self):
  for path in ['/src/cli.py','/README.md','/../README.md','/%2e%2e/README.md']:
   with self.assertRaises(urllib.error.HTTPError) as e:urllib.request.urlopen(self.base+path)
   self.assertEqual(e.exception.code,404)
 def test_foreign_host_and_upload_rejected(self):
  request=urllib.request.Request(self.base+'/mp4_convert.html',headers={'Host':'attacker.example'})
  with self.assertRaises(urllib.error.HTTPError) as e:urllib.request.urlopen(request)
  self.assertEqual(e.exception.code,404)
  request=urllib.request.Request(self.base+'/',data=b'file-data',method='POST')
  with self.assertRaises(urllib.error.HTTPError) as e:urllib.request.urlopen(request)
  self.assertEqual(e.exception.code,501)
if __name__=='__main__':unittest.main()
