"""Local HTTP fixture: exact query preservation + explicit credential policy.
The test injects a fixture Cookie to emulate a browser cookie jar; real browser
SameSite/partition/CORS behavior is deliberately not claimed by this test.
"""
from pathlib import Path
import http.server,subprocess,threading,json
R=Path(__file__).resolve().parents[1]
query='?sig=A%2fb+X&x=1&x=2';seen=[]
class Handler(http.server.BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_GET(self):
  seen.append({'path':self.path,'cookie_present':self.headers.get('Cookie')=='fixture=ok'})
  good=self.path in ['/master.m3u8'+query,'/child.m3u8'+query] and self.headers.get('Cookie')=='fixture=ok'
  body=(b'#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1\nchild.m3u8\n' if self.path.startswith('/master') else b'#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXTINF:2,\na.ts\n#EXT-X-ENDLIST\n') if good else b'not authorized'
  self.send_response(200 if good else 403);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
try:
 url=f'http://127.0.0.1:{server.server_port}/master.m3u8'+query
 runner="""const a=require('node:assert/strict'),C=require('./src/media_catalog.js'),H=require('./src/hls_transport.js');(async()=>{const u=process.argv[1],fetchImpl=(url,o)=>fetch(url,{...o,headers:{...o.headers,...(o.credentials==='include'?{Cookie:'fixture=ok'}:{})}});await a.rejects(C.load(u,{HLS:H,fetchImpl}),/HTTP_403/);const r=await C.load(u,{HLS:H,fetchImpl,useCookies:true,inheritQuery:true});a.equal(r.rows[0].url,new URL('child.m3u8',u).href+new URL(u).search);await C.load(r.rows[0].url,{HLS:H,fetchImpl,useCookies:true});console.log(JSON.stringify({anonymous_policy_request:'HTTP_403',explicit_cookie_policy:'PASS',raw_query_preserved:true,parent_query_inheritance:'PASS',browser_cookie_jar:'emulated_not_real_browser'}));})().catch(e=>{console.error(e);process.exitCode=1;});"""
 result=subprocess.run(['node','-e',runner,url],cwd=R,capture_output=True,text=True,check=True,timeout=30);summary=json.loads(result.stdout)
 assert [x['path'] for x in seen]==['/master.m3u8'+query,'/master.m3u8'+query,'/child.m3u8'+query]
 assert [x['cookie_present'] for x in seen]==[False,True,True]
 print(json.dumps({'checks':summary,'request_count':len(seen),'exact_query_and_order':'PASS','scope':'local HTTP; fixture Cookie injection, not live-service/browser acceptance'},indent=2))
finally:server.shutdown();server.server_close();thread.join()
