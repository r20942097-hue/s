"""Advisory manifest timing; this does not assert media PTS integrity."""
import importlib.util, pathlib, unittest, subprocess, json
R=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('hls_timing', R/'rplay_dl.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
BASE='https://fixtures.invalid/live.m3u8'
def playlist(x):return '#EXTM3U\n#EXT-X-TARGETDURATION:2\n'+x
def dt(x):return '#EXT-X-PROGRAM-DATE-TIME:'+x+'\n'
class ManifestTiming(unittest.TestCase):
 def test_duplicate_global_tags(self):
  for x in [playlist('#EXT-X-VERSION:4\n#EXT-X-VERSION:5\n'),playlist('#EXT-X-MEDIA-SEQUENCE:1\n#EXT-X-MEDIA-SEQUENCE:2\na.ts'),playlist('#EXT-X-TARGETDURATION:2\na.ts'),playlist('a.ts\n#EXT-X-TARGETDURATION:3')]:
   with self.subTest(x=x),self.assertRaises(ValueError):h.hls_parse(x,BASE)
 def test_extinf_bounds_and_dangling(self):
  for x in ['#EXTINF:zero,\na.ts','#EXTINF:0,\na.ts','#EXTINF:2.5,\na.ts','#EXTINF:1.0,\n#EXTINF:1.0,\na.ts','#EXTINF:1.0,']:
   with self.subTest(x=x),self.assertRaises(ValueError):h.hls_parse(playlist(x),BASE)
  self.assertEqual(h.hls_parse(playlist('#EXTINF:1.49,\na.ts'),BASE)['segments'][0]['duration'],1.49)
 def test_bad_clock_and_whitespace(self):
  for x in ['2025-02-29T00:00:00Z','2024-13-01T00:00:00Z','2024-02-29T24:00:00Z','2024-02-29T00:60:00Z','2024-02-29T00:00:60Z','0000-01-01T00:00:00Z','2024-01-01T00:00:00+24:00']:
   with self.subTest(x=x),self.assertRaises(ValueError):h.hls_parse(playlist(dt(x)+'#EXTINF:1,\na.ts'),BASE)
  for x in [' a.ts','a.ts ','\ta.ts']:
   with self.subTest(x=x),self.assertRaises(ValueError):h.hls_parse(playlist(x),BASE)
 def test_clock_gap_overlap_and_discontinuity(self):
  for when,gap,overlap in [('2026-01-01T00:00:01Z',0,0),('2026-01-01T00:00:04Z',1,0),('2026-01-01T00:00:00Z',0,1)]:
   text=playlist(dt('2026-01-01T00:00:00Z')+'#EXTINF:1,\na.ts\n'+dt(when)+'#EXTINF:1,\nb.ts')
   e=h.hls_timing_evidence(h.hls_parse(text,BASE));self.assertEqual(e['checkedIntervals'],1);self.assertEqual(e['suspectedGapIntervals'],gap);self.assertEqual(e['suspectedOverlapIntervals'],overlap)
  text=playlist(dt('2026-01-01T00:00:00Z')+'#EXTINF:1,\na.ts\n#EXT-X-DISCONTINUITY\n'+dt('2026-01-01T00:01:00Z')+'#EXTINF:1,\nb.ts')
  e=h.hls_timing_evidence(h.hls_parse(text,BASE));self.assertEqual(e['checkedIntervals'],0);self.assertEqual(e['discontinuityBoundaries'],1)
 def test_descriptor_and_timing_cross_language_parity(self):
  fixtures=[playlist(dt('2024-02-29T03:12:40.125+09:00')+'#EXTINF:1,\na.ts\n'+dt('2024-02-29T03:12:41.125+09:00')+'#EXTINF:1,\nb.ts'),playlist(dt('2026-01-01T00:00:00Z')+'a.ts\n'+dt('2026-01-01T00:00:02Z')+'b.ts')]
  js="const H=require('./src/hls_transport.js');let v='';process.stdin.on('data',x=>v+=x);process.stdin.on('end',()=>process.stdout.write(JSON.stringify(JSON.parse(v).map(x=>{let p=H.parse(x,'"+BASE+"');delete p.discontinuity;return [p,H.timingEvidence(p)];}))));"
  r=subprocess.run(['node','-e',js],cwd=R,text=True,input=json.dumps(fixtures),capture_output=True,check=True)
  for src,(data,expected) in zip(fixtures,json.loads(r.stdout)):
   parsed=h.hls_parse(src,BASE);self.assertEqual(parsed,data);self.assertEqual(h.hls_timing_evidence(parsed),expected)
 def test_timing_ledger_tracks_separate_audio_and_video(self):
  class O:pass
  o=O();o.seen=set();o.queue=[];o.a_seen=set();o.a_queue=[]
  parsed=h.hls_parse(playlist(dt('2026-01-01T00:00:00Z')+'#EXTINF:1,\na.ts'),BASE)
  h.hls_enqueue(o,parsed,BASE);h.hls_enqueue(o,parsed,BASE,audio=True)
  self.assertEqual(o._hls_state['last'],0);self.assertEqual(o._hls_a_state['last'],0)
  self.assertEqual(o._hls_timing['explicitAnchors'],1);self.assertEqual(o._hls_a_timing['explicitAnchors'],1)
