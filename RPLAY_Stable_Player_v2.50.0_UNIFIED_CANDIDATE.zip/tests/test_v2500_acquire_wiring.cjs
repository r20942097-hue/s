'use strict';
/* v2.50.0: 汎用取得 Stage 3 結線の検証 — RspAcquireHost(実 store/実 HLS パーサ/モック fetch)
   による機能試験と、offscreen/BG/dashboard の結線契約(ソース表明+BGルータvm)。
   紀律: 既定OFF・明示候補のみ・fail-closed・ゼロシークレット・非破壊。 */
const {test}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const ROOT=path.resolve(__dirname,'..');
const Host=require('../src/acquire_host.js');
const Store=require('../src/segment_store.js');
const HLS=require('../src/hls_transport.js');
const Engine=require('../src/segment_acquire.js');

/* ---- 共通ハーネス: OPFSモック + 実ストア + モックfetch ---- */
function mockStorage(){
  const areas=new Map();
  const dirFor=ns=>{
    if(!areas.has(ns))areas.set(ns,new Map());
    const files=areas.get(ns);
    return {
      getFileHandle:async(name,opt)=>{
        if(!files.has(name)&&!(opt&&opt.create))throw new DOMException('missing','NotFoundError');
        return {
          kind:'file',
          getFile:async()=>{
            if(!files.has(name))throw new DOMException('missing','NotFoundError');
            const bytes=files.get(name);
            return {size:bytes.length,arrayBuffer:async()=>bytes.slice().buffer,text:async()=>new TextDecoder().decode(bytes)};
          },
          createWritable:async()=>{
            let held=null;
            return {write:async b=>{held=Uint8Array.from(b instanceof Uint8Array?b:new Uint8Array(b));},close:async()=>files.set(name,held),abort:async()=>{}};
          }
        };
      },
      removeEntry:async name=>{if(!files.has(name))throw new DOMException('missing','NotFoundError');files.delete(name);},
      async *entries(){for(const [name,bytes] of [...files])yield [name,{kind:'file',getFile:async()=>({size:bytes.length})}];}
    };
  };
  return {storage:{getDirectory:async()=>({getDirectoryHandle:async(area,opt)=>({getDirectoryHandle:async(ns,opt2)=>dirFor(ns)})})},areas};
}
function digestFn(u8){const c=require('node:crypto');return c.createHash('sha256').update(u8).digest('hex');}
const TS_BYTE=Uint8Array.from([0x47,0x40,0x00,0x10,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1]); /* 20B 合成TS風 */
const M3U8_3=['#EXTM3U','#EXT-X-VERSION:3','#EXT-X-TARGETDURATION:2','#EXT-X-MEDIA-SEQUENCE:1',
 '#EXTINF:1.0,','seg1.ts','#EXTINF:1.0,','seg2.ts','#EXTINF:1.0,','seg3.ts','#EXT-X-ENDLIST'].join('\n');

function makeHost(over={}){
  over=over||{};
  const m=mockStorage();
  const fetchLog={playlist:[],segment:[]};
  const playlistBody=over.playlistBody!==undefined?over.playlistBody:M3U8_3;
  const host=Host.create({
    settings:()=>({segmentAcquire:over.enabled!==false}),
    storage:m.storage,
    HLS,
    fetchImpl:async(url,opts)=>{
      if(String(url).includes('.m3u8')){
        fetchLog.playlist.push(String(url));
        if(over.playlistStatus)return {status:over.playlistStatus};
        if(over.playlistBytes)return {status:200,arrayBuffer:async()=>new ArrayBuffer(over.playlistBytes)};
        const text=typeof playlistBody==='function'?playlistBody(String(url)):playlistBody;
        return {status:200,arrayBuffer:async()=>new TextEncoder().encode(text).buffer};
      }
      fetchLog.segment.push(String(url));
      if(over.gate&&fetchLog.segment.length===over.gateAt)await over.gate.promise;
      if(over.segmentStatus&&fetchLog.segment.length>over.segmentFailAfter)return {status:over.segmentStatus};
      if(over.segmentBytes)return {status:200,arrayBuffer:async()=>new ArrayBuffer(over.segmentBytes)};
      return {status:200,arrayBuffer:async()=>TS_BYTE.slice().buffer};
    },
    sha256:digestFn,
    now:over.now||Date.now,
    acquireTimeoutMs:over.acquireTimeoutMs,
    segmentTimeoutMs:over.segmentTimeoutMs
  });
  return {host,areas:m.areas,fetchLog};
}

/* ---- ① 機能試験(実ストア・実パーサ) ---- */
test('v2.50.0 acquire host: default OFF fails closed on every operation',async()=>{
  const {host}=makeHost({enabled:false});
  a.equal((await host.start({id:'abc',playlistUrl:'https://x/live.m3u8'})).error,'ACQUIRE_DISABLED');
  a.equal((await host.continueFrom({id:'abc',playlistUrl:'https://x/live.m3u8'})).error,'ACQUIRE_DISABLED');
  a.equal(host.cancel({id:'abc'}).error,'ACQUIRE_DISABLED');
  a.equal(host.status({id:'abc'}).error,'ACQUIRE_DISABLED');
  a.equal(host.list().error,'ACQUIRE_DISABLED');
  a.equal((await host.residue({id:'abc'})).error,'ACQUIRE_DISABLED');
  a.equal(host.discard({id:'abc'}).error,'ACQUIRE_DISABLED');
  a.equal((await host.bootRestore()).error,'ACQUIRE_DISABLED');
});
test('v2.50.0 acquire host: explicit start acquires all segments to disk and completes',async()=>{
  const {host,areas,fetchLog}=makeHost();
  const r=await host.start({id:'job-1',playlistUrl:'https://cdn.example/live/index.m3u8'});
  a.equal(r.ok,true);a.equal(r.status.status,'complete');
  a.equal(r.status.segmentsAcquired,3);a.equal(r.status.endListReached,true);
  a.equal(fetchLog.segment.length,3);
  const files=[...(areas.get('acquire')||new Map()).keys()];
  a.equal(files.filter(n=>n.endsWith('.bin')).length,3);
  a.equal(files.filter(n=>n.endsWith('.json')).length,3);
  const st=host.status({id:'job-1'});
  a.equal(st.ok,true);a.equal(st.status.status,'complete');
});
/* 最小 store(ゼロシークレット走査のための engine 再利用) */
function makeBareStore(){const stored=new Map();return {async put(o){stored.set(o.id,o.bytes);return {id:o.id,bytes:o.bytes.byteLength};},async get(id){return stored.has(id)?{id,bytes:stored.get(id)}:null;},async meta(id){return null;},async list(){return [];},async sweep(){return 0;},digest:null};}
test('v2.50.0 acquire host: status and residue never contain URLs or secret keywords',async()=>{
  const {host}=makeHost();
  await host.start({id:'scanjob',playlistUrl:'https://cdn.example/live/index.m3u8?token=SECRET'});
  const eng=host._internal.getEngine();
  const scan=eng.zeroSecretScan('scanjob');
  a.equal(scan.clean,true,String(scan.suspect));
  const st=JSON.stringify(host.status({id:'scanjob'}));
  a.ok(!/https?:\/\//i.test(st),'no URL in status');
  a.ok(!/token|secret|cookie|authorization/i.test(st),'no secret keyword in status');
  const res=await host.residue({id:'scanjob'});
  a.equal(res.ok,true);a.equal(res.residue.segments.length,3);
  a.ok(!/https?:\/\//i.test(JSON.stringify(res.residue)),'no URL in residue');
});
test('v2.50.0 acquire host: playlist HTTP errors surface as HTTP_xxx and keep residue',async()=>{
  const {host}=makeHost({playlistStatus:403});
  const r=await host.start({id:'job-403',playlistUrl:'https://cdn.example/live/index.m3u8'});
  a.equal(r.ok,true);a.equal(r.status.status,'failed');a.equal(r.status.error,'HTTP_403');
  const {host:h2}=makeHost({playlistStatus:404});
  const r2=await h2.start({id:'job-404',playlistUrl:'https://cdn.example/live/index.m3u8'});
  a.equal(r2.status.error,'HTTP_404');
});
test('v2.50.0 acquire host: bounded playlist (2MiB) and segment (16MiB) caps fail closed',async()=>{
  const {host}=makeHost({playlistBytes:2*1048576+1});
  let r=await host.start({id:'job-bigpl',playlistUrl:'https://cdn.example/live/index.m3u8'});
  a.equal(r.status.status,'failed');
  const {host:h2}=makeHost({segmentBytes:16*1048576+1});
  const r2=await h2.start({id:'job-bigseg',playlistUrl:'https://cdn.example/live/index.m3u8'});
  a.equal(r2.status.status,'failed');
});
test('v2.50.0 acquire host: segment HTTP errors surface and acquisition fails without destroying residue',async()=>{
  const {host}=makeHost({segmentStatus:500,segmentFailAfter:1});
  const r=await host.start({id:'job-500',playlistUrl:'https://cdn.example/live/index.m3u8'});
  a.equal(r.status.status,'failed');a.equal(r.status.error,'HTTP_500');
  const res=await host.residue({id:'job-500'});
  a.equal(res.residue.segmentsAcquired,1,'first segment stays on disk');
});
test('v2.50.0 acquire host: cancel mid-flight stops, keeps residue, listResidue enumerates',async()=>{
  let release;
  const gate={promise:new Promise(res=>{release=res;})};
  const {host}=makeHost({gate,gateAt:2}); /* 2本目の取得中に取消 */
  const p=host.start({id:'job-cancel',playlistUrl:'https://cdn.example/live/index.m3u8'});
  await new Promise(r=>setTimeout(r,20)); /* seg1 確定を待つ */
  a.equal(host.cancel({id:'job-cancel'}).cancelled,true);
  release();
  const r=await p;
  a.equal(r.status.status,'cancelled');
  a.equal(r.status.cancelRequested,true);
  const res=await host.residue({id:'job-cancel'});
  a.ok(res.residue.segmentsAcquired>=1,'at least one segment remains on disk');
  a.equal(host.discard({id:'job-cancel'}).discarded,true,'discard drops RAM state only');
});
test('v2.50.0 acquire host: restart continuation restores from ledger and skips acquired segments',async()=>{
  const first=makeHost();
  await first.host.start({id:'job-resume',playlistUrl:'https://cdn.example/live/index.m3u8'});
  /* 取消しで paused にする2セッション目: 同じOPFS・新しいホスト */
  const second=makeHost();
  /* ledger は first のものを使うため、ここでは first の OPFS を直接共有する形で再構成 */
  const shared=mockStorage();
  const mk=()=>Host.create({settings:()=>({segmentAcquire:true}),storage:shared.storage,HLS,fetchImpl:async(url)=>{
      if(String(url).includes('.m3u8'))return {status:200,arrayBuffer:async()=>new TextEncoder().encode(M3U8_3).buffer};
      return {status:200,arrayBuffer:async()=>TS_BYTE.slice().buffer};
    },sha256:digestFn});
  const A=mk();
  const started=await A.start({id:'job-rr',playlistUrl:'https://cdn.example/live/index.m3u8'});
  a.equal(started.status.status,'complete');
  /* ENDLIST済みのため完全取得 → 台帳は complete。再起動復元は paused/failed を対象とするため
     ここでは強制的に途中停止のジョブを作る */
  const B=mk();
  const bo=await B.bootRestore();
  a.equal(bo.ok,true,'bootRestore succeeds with a ledger present');
  a.equal(bo.restored,'job-rr');
  const st=B.status({id:'job-rr'});
  a.equal(st.ok,true);
  a.ok(st.status.segments>=3,'restored segment map rebuilt from store meta');
});
test('v2.50.0 acquire host: bootRestore without ledger reports NO_LEDGER',async()=>{
  const {host}=makeHost();
  const r=await host.bootRestore();
  a.equal(r.ok,false);a.equal(r.error,'NO_LEDGER');
});
test('v2.50.0 acquire host: input validation rejects bad ids, non-https and junk URLs',async()=>{
  const {host}=makeHost();
  a.equal((await host.start({id:'../etc',playlistUrl:'https://x/a.m3u8'})).error,'INVALID_ID');
  a.equal((await host.start({id:'ok',playlistUrl:'http://x/a.m3u8'})).error,'INVALID_PLAYLIST_URL');
  a.equal((await host.start({id:'ok',playlistUrl:'not-a-url'})).error,'INVALID_PLAYLIST_URL');
  a.equal((await host.start({id:'ok'})).error,'INVALID_PLAYLIST_URL');
  a.equal((await host.continueFrom({id:'x'.repeat(129),playlistUrl:'https://x/a.m3u8'})).error,'INVALID_ID');
});
test('v2.50.0 acquire host: playlist parser adapter maps sequence/gap/discontinuity/endList',async()=>{
  const {host}=makeHost();
  const pl=host._internal.playlistParser(
    ['#EXTM3U','#EXT-X-TARGETDURATION:2','#EXT-X-MEDIA-SEQUENCE:5','#EXTINF:1.0,','a.ts',
     '#EXT-X-DISCONTINUITY','#EXTINF:1.0,','#EXT-X-GAP','b.ts','#EXT-X-ENDLIST'].join('\n'),
    'https://cdn.example/live/index.m3u8');
  a.equal(pl.kind,'media');a.equal(pl.endList,true);
  a.equal(pl.segments[0].sequence,5);a.equal(pl.segments[0].discontinuity,false);
  a.equal(pl.segments[1].sequence,6);a.equal(pl.segments[1].discontinuity,true);
  a.equal(pl.segments[1].discontinuitySequence,1);
  a.equal(pl.segments[1].gap,true);
  a.ok(pl.segments[0].uri.startsWith('https://cdn.example/live/'),'relative URI resolved against playlist base');
});
test('v2.50.0 acquire host: digest integrity is verified on readback (fail-closed)',async()=>{
  const {host,areas}=makeHost();
  await host.start({id:'job-dig',playlistUrl:'https://cdn.example/live/index.m3u8'});
  const files=areas.get('acquire');
  const bin=[...files.keys()].find(n=>n.endsWith('.bin'));
  const meta=JSON.parse(new TextDecoder().decode(files.get(bin.slice(0,-4)+'.json')));
  a.ok(/^[a-f0-9]{64}$/.test(meta.sha256),'meta carries sha256');
  /* 改竄 → 実store の get は SEGMENT_DIGEST_MISMATCH */
  const firstBin=[...files.keys()].find(n=>n.endsWith('.bin'));
  const orig=files.get(firstBin);
  files.set(firstBin,Uint8Array.from(orig,(b,i)=>(i+1)%256)); /* 同一サイズ・異なる内容 */
  await a.rejects(()=>host._internal.engineStore.get(firstBin.slice(0,-4)),/SEGMENT_DIGEST_MISMATCH/);
});

/* ---- ② 結線契約(ソース表明) ---- */
const read=p=>fs.readFileSync(path.join(ROOT,p),'utf8');
test('v2.50.0 wiring: offscreen settings default OFF, applied and validated',()=>{
  const pre=read('src/offscreen_pre.js');
  a.match(pre,/segmentAcquire: false \/\/ v2\.50\.0\(Stage 3\)/);
  a.match(pre,/if \(typeof s\.segmentAcquire === 'boolean'\) SET\.segmentAcquire = s\.segmentAcquire;/);
  a.match(pre,/'mp4Handover', 'mp4AutoHandoff', 'segmentAcquire'\]\.some/);
});
test('v2.50.0 wiring: offscreen host lazy-binds RspAcquireHost and gates every acquire case',()=>{
  const post=read('src/offscreen_post.js');
  for(const c of ['acquire.start','acquire.continue','acquire.cancel','acquire.status','acquire.list','acquire.residue','acquire.discard','acquire.bootRestore'])
    a.ok(post.includes(`case '${c}':`),c);
  a.match(post,/function acquireHost\(\) \{\s*\n\s*if \(SET\.segmentAcquire !== true\) return null;/);
  a.match(post,/RspAcquireHost\.create\(/);
  a.match(post,/error: 'ACQUIRE_DISABLED' \}\); return; \}/,'fail-closed when flag off or module missing');
  a.match(post,/RspSha256\.Sha256/,'sha256 bound from the preloaded module');
});
test('v2.50.0 wiring: BG routes acquire.* for dashboard only, candidate-resolved and flag-gated',()=>{
  const bg=read('src/background.js');
  a.match(bg,/fromDashboard&&typeof msg\.type==='string'&&msg\.type\.indexOf\('acquire\.'\)===0/);
  a.match(bg,/d\.segmentAcquire!==true\)\{reply\(\{ok:false,error:'ACQUIRE_DISABLED'\}\)/);
  a.match(bg,/CANDIDATE_EXPIRED/);
  a.match(bg,/c\.mediaType!=='hls'\)\{reply\(\{ok:false,error:'ACQUIRE_UNSUPPORTED_TYPE'\}\)/);
  a.match(bg,/mediaCatalog\.get\(pl\.candidateId\)/);
  a.match(bg,/toOffscreen\(\{type:'acquire\.'\+\(op==='start'\?'start':'continue'\)/);
  a.match(bg,/\['autoStartAllowed','enabled','follow','recAudio','inheritQuery','mp4Handover','mp4AutoHandoff','segmentAcquire'\]/);
  a.match(bg,/segmentAcquire:\(d&&typeof d\.segmentAcquire==='boolean'\)\?d\.segmentAcquire:null/);
});
test('v2.50.0 wiring: dashboard settings module carries the new flag',()=>{
  const ds=require('../src/dashboard_settings.js');
  const n=ds.normalize(undefined);
  a.equal(n.segmentAcquire,false);
  a.equal(ds.normalize({segmentAcquire:true}).segmentAcquire,true);
  a.throws(()=>ds.normalize({segmentAcquire:'yes'}),/ON\/OFF/);
});
test('v2.50.0 wiring: dashboard UI exposes toggle, explicit acquire button and job panel',()=>{
  const js=read('src/dashboard.js');
  a.match(js,/keys=\['autoStartAllowed','enabled','follow','recAudio','inheritQuery','mp4Handover','mp4AutoHandoff','segmentAcquire'\]/);
  a.match(js,/type:'acquire\.start',payload:\{candidateId:item\.id\}/);
  a.match(js,/type:'acquire\.list'/);
  a.match(js,/type:'acquire\.bootRestore'/);
  const html=read('src/dashboard.html');
  a.match(html,/id="segmentAcquire" type="checkbox"/);
  a.match(html,/id="acquireSection" hidden/);
  a.match(html,/id="acquireRefresh"/);
  a.match(html,/id="acquireBootRestore"/);
});
test('v2.50.0 wiring: preload order puts store/engine/host before offscreen runtime',()=>{
  const html=read('rplay-stable-player-extension/offscreen.html');
  const order=['sha256.js','segment_store.js','segment_acquire.js','acquire_host.js','offscreen.js'].map(n=>html.indexOf(`src="${n}"`));
  order.forEach((x,i)=>a.ok(x>=0,'referenced: '+i));
  for(let i=1;i<order.length;i++)a.ok(order[i-1]<order[i],'order '+i);
  const ff=JSON.parse(read('rplay-stable-player-extension-firefox/manifest.json'));
  const sc=ff.background.scripts;
  for(const n of ['sha256.js','segment_store.js','segment_acquire.js','acquire_host.js','offscreen.js'])a.ok(sc.includes(n),n);
  a.ok(sc.indexOf('acquire_host.js')<sc.indexOf('offscreen.js'));
  const build=read('scripts/build.py');
  a.match(build,/'segment_acquire\.js','acquire_host\.js'\]/);
  const val=read('scripts/validate.py');
  a.match(val,/'segment_acquire\.js','acquire_host\.js'\]/);
});

/* ---- ③ BGルータ vm 試験 ---- */
function bgWorld(over={}){
  const h={hostMessages:[],catalog:new Map()};
  const api={storage:{local:{get:(k,cb)=>cb({rsp_dashboard_defaults:{segmentAcquire:over.flag!==false}})}},
   runtime:{id:'rsp',lastError:null,getURL:n=>'chrome-extension://rsp/'+n,
    onMessage:{addListener:f=>h.listener=f},onStartup:{addListener:f=>{}},onInstalled:{addListener:f=>{}},
    getContexts:async()=>[{}],sendMessage:async m=>{h.hostMessages.push(m);return {ok:true,status:{status:'paused'}};}},
   offscreen:{createDocument:async()=>{},closeDocument:async()=>{}},
   downloads:{onChanged:{addListener:f=>{}}},alarms:{create:()=>{},clear:()=>{},onAlarm:{addListener:()=>{}}},
   action:{setBadgeText:()=>{}},tabs:{query:async()=>[],sendMessage:async()=>{},create:async()=>{},onRemoved:{addListener:()=>{}},onUpdated:{addListener:()=>{}}},
   webRequest:{onBeforeSendHeaders:{addListener:()=>{}},onErrorOccurred:{addListener:()=>{}},onHeadersReceived:{addListener:()=>{}}}};
  const c=vm.createContext({chrome:api,console,Promise,Date,setTimeout:f=>1,clearTimeout:()=>{},
   RspExportManager:{create:()=>({pending:async()=>false,status:async()=>({verified:0}),offer:async()=>({ok:true}),changed:async()=>{},reconcile:async()=>{}})},
   RspMediaCatalog:{create:()=>({captureRequest:()=>{},forgetRequest:()=>{},add:()=>{},clear:()=>{},list:()=>[...h.catalog.values()],
    get:id=>h.catalog.get(id)||null})}});
  vm.runInContext(fs.readFileSync(path.join(ROOT,'rplay-stable-player-extension/background.js'),'utf8'),c);
  h.message=(msg,sender)=>new Promise(res=>{const keep=h.listener(msg,sender,res);if(keep!==true)res(null);});
  h.dash={id:'rsp',url:'chrome-extension://rsp/dashboard.html',frameId:0};
  h.catalog=h.catalog;
  return h;
}
test('v2.50.0 BG router: acquire.start requires the dashboard flag (fail closed)',async()=>{
  const h=bgWorld({flag:false});
  const r=await h.message({type:'acquire.start',payload:{candidateId:'c1'}},h.dash);
  a.equal(r.error,'ACQUIRE_DISABLED');
  a.equal(h.hostMessages.length,0,'nothing relayed to offscreen');
});
test('v2.50.0 BG router: non-dashboard senders cannot reach acquire.*',async()=>{
  const h=bgWorld();
  const r=await h.message({type:'acquire.start',payload:{candidateId:'c1'}},{id:'rsp',url:'https://rplay.live/live',tab:{id:1}});
  a.equal(r,null,'router ignores content senders');
});
test('v2.50.0 BG router: expired candidate is rejected before any relay',async()=>{
  const h=bgWorld();
  const r=await h.message({type:'acquire.start',payload:{candidateId:'ghost'}},h.dash);
  a.equal(r.error,'CANDIDATE_EXPIRED');
  a.equal(h.hostMessages.length,0);
});
test('v2.50.0 BG router: only HLS candidates are acquirable',async()=>{
  const h=bgWorld();
  h.catalog.set('m1',{id:'m1',url:'https://cdn.example/video.mp4?sig=SECRET',mediaType:'mp4'});
  const r=await h.message({type:'acquire.start',payload:{candidateId:'m1'}},h.dash);
  a.equal(r.error,'ACQUIRE_UNSUPPORTED_TYPE');
  a.equal(h.hostMessages.length,0);
});
test('v2.50.0 BG router: HLS candidate start relays the playlist URL to the host once',async()=>{
  const h=bgWorld();
  h.catalog.set('c1',{id:'c1',url:'https://cdn.example/live/index.m3u8?token=SECRET',mediaType:'hls'});
  const r=await h.message({type:'acquire.start',payload:{candidateId:'c1'}},h.dash);
  a.equal(r.ok,true);
  a.equal(h.hostMessages.length,1);
  a.equal(h.hostMessages[0].type,'acquire.start');
  a.equal(h.hostMessages[0].payload.id,'c1');
  a.equal(h.hostMessages[0].payload.playlistUrl,'https://cdn.example/live/index.m3u8?token=SECRET');
  a.equal(h.hostMessages[0].target,'rsp-host','explicit host target');
});
test('v2.50.0 BG router: cancel/status/residue/discard validate id shape before relay',async()=>{
  const h=bgWorld();
  const bad=await h.message({type:'acquire.cancel',payload:{id:'../x'}},h.dash);
  a.equal(bad.error,'INVALID_ID');
  a.equal(h.hostMessages.length,0);
  const okr=await h.message({type:'acquire.cancel',payload:{id:'c1'}},h.dash);
  a.equal(okr.ok,true);
  a.equal(h.hostMessages[0].type,'acquire.cancel');
  const lst=await h.message({type:'acquire.list'},h.dash);
  a.equal(lst.ok,true);
});
