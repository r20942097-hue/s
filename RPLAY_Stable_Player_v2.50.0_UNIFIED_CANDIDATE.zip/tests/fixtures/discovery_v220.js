  const DISC_SOURCES_DEFAULT = '650beb0e0c98c9e3782b2b87,6478bcd82f73959e73f35ce1';
  const DISC_CACHE_TTL_MS = 120000;
  const DISC_403_COOLDOWN_MS = 60000;
  const DISC_429_BASE_MS = 30000;
  const DISC_429_MAX_MS = 300000;
  const DISC_CONC = 6;
  const DISC_TIMEOUT_MS = 9000;
  const DISC_REQ_GAP_MS = 120;
  const DISC_403_CONSEC = 30; // 連続403この回数でインフラ制限とみなし全体退避(散発403は学習スキップ)
  const DISC_AUTO_MS_DEFAULT = 60000;
  const DISC_SLICE = 40;
  const DISC_OID_RE = /^[0-9a-f]{24}$/i;

  function discSourcesGet() {
    try {
      const v = localStorage.getItem('rsp_disc_sources');
      if (v && v.trim()) {
        const arr = v.split(',').map(function (x) { return x.trim(); }).filter(function (x) { return DISC_OID_RE.test(x); });
        if (arr.length) return arr;
      }
    } catch (e) {}
    return DISC_SOURCES_DEFAULT.split(',');
  }
  function discSourcesSet(csv) {
    try { localStorage.setItem('rsp_disc_sources', String(csv || '')); } catch (e) {}
  }
  /* 未知形状の /live/streams 応答を防御的に解釈(公式の応答形式に依存しない) */
  function discParseAuthedStreams(j) {
    const arr = Array.isArray(j) ? j : (j && typeof j === 'object')
      ? (j.items || j.streams || j.list || j.data || (Array.isArray(j.lives) ? j.lives : null)) : null;
    if (!Array.isArray(arr)) return null;
    const out = [];
    for (let i = 0; i < arr.length; i++) {
      const it = arr[i];
      if (!it || typeof it !== 'object') continue;
      const oid = it.creatorOid || (it.creator && (it.creator.oid || it.creator._id)) || it.oid || it._id;
      if (typeof oid !== 'string' || !DISC_OID_RE.test(oid)) continue;
      const cm = it.creatorMetadata || it.creator || {};
      out.push({
        oid: oid,
        nick: cm.nickname || it.nickname || '',
        title: it.title || it.liveTitle || '',
        adult: !!(it.isAdultContent),
        viewers: (typeof it.viewerCount === 'number') ? it.viewerCount : null,
        src: 'authed'
      });
    }
    return out;
  }

  function openDiscoveryPanel() {
    injectStyle();
    const old = document.getElementById('rsp-disc');
    if (old) { old.remove(); _discCleanup && _discCleanup(); }
    const D = {
      live: new Map(),        // oid -> {oid,nick,title,adult,viewers,src}
      pool: [],               // 候補creatorOid(重複排除)
      poolAt: 0,
      scanning: false,
      cooldownUntil: 0,
      c429: 0,
      nextAt: 0,              // 全体ペーシング用
      lastScanAt: 0,
      lastFullAt: 0,
      rotateIdx: 0,
      authedTriedAt: 0,
      authedUsed: false,
      consec403: 0,   // v1.12.0: 連続403カウンタ(200で復位・12連続で退避)
      skip403: new Set(), // v1.12.0: 403になったcreatorの学習リスト(以後スキップ)
      lastErr: '',
      timer: null
    };
    window.__RSP_DISC = D; // 試験フック(E2Eはこの状態を検査する)
    const T = RSP_I18N[rspLang()] || RSP_I18N.ja;
    const autoChk = el('input', { type: 'checkbox' });
    try { autoChk.checked = localStorage.getItem('rsp_disc_auto') !== '0'; } catch (e) { autoChk.checked = true; }
    autoChk.addEventListener('change', function () {
      try { localStorage.setItem('rsp_disc_auto', autoChk.checked ? '1' : '0'); } catch (e2) {}
    });
    const scanBtn = el('button', { class: 'rsp-btn', text: T.discScan, title: '公式クリエイター一覧(公開)からライブ中の配信を全走査します' });
    const refBtn = el('button', { class: 'rsp-btn', text: T.discRefresh, title: '既知のライブと候補の一部を再確認します(軽量)' });
    const autoLbl = el('label', { class: 'rsp-auto' }, autoChk, T.discAuto);
    const statLine = el('div', { class: 'rsp-dstat', text: T.discReady });
    const listEl = el('ul', { class: 'rsp-dlist' });
    const srcInput = el('input', { class: 'rsp-url', placeholder: T.discSrc, value: (function () {
      try { const v = localStorage.getItem('rsp_disc_sources'); return v != null ? v : DISC_SOURCES_DEFAULT; } catch (e) { return DISC_SOURCES_DEFAULT; }
    })() });
    const srcApply = el('button', { class: 'rsp-btn', text: T.apply });
    srcApply.addEventListener('click', function () {
      discSourcesSet(srcInput.value);
      D.pool = []; D.poolAt = 0; // ソース変更でpoolを無効化
      setStat(T.discReady);
    });
    const authBadge = el('span', { class: 'rsp-dauth', text: '' });
    const head = el('div', { class: 'rsp-dhead' },
      el('span', { text: '🔭 ライブ探索' }), authBadge,
      el('button', { class: 'rsp-minbtn', text: '✕', title: '閉じる' }));
    head.lastChild.addEventListener('click', function () { closeDisc(); });
    const srcDetails = el('details', { class: 'rsp-dfoot' },
      el('summary', { text: T.discFoot }),
      el('div', { class: 'rsp-dsrc' }, srcInput, srcApply));
    const box = el('div', { id: 'rsp-disc', class: 'rsp-disc' },
      head,
      el('div', { class: 'rsp-dbar' }, scanBtn, refBtn, autoLbl),
      statLine, listEl, srcDetails);
    document.body.appendChild(box);

    function setStat(m) { statLine.textContent = m; }
    function closeDisc() {
      if (D.timer) { clearInterval(D.timer); D.timer = null; }
      try { box.remove(); } catch (e) {}
      if (window.__RSP_DISC === D) window.__RSP_DISC = null;
      _discCleanup = null;
    }
    function openLive(oid) {
      try { window.open('/live?creatorOid=' + encodeURIComponent(oid), '_blank', 'noopener'); } catch (e) {}
    }
    function render() {
      listEl.textContent = '';
      const items = Array.from(D.live.values()).sort(function (a, b) {
        return (b.viewers || 0) - (a.viewers || 0) || a.oid.localeCompare(b.oid);
      });
      if (!items.length) {
        listEl.appendChild(el('li', { class: 'rsp-dempty', text: T.discEmpty }));
        return;
      }
      for (let i = 0; i < items.length; i++) {
        const it = items[i];
        const view = (it.viewers != null) ? ('👁 ' + it.viewers) : '👁 -';
        const row = el('li', { class: 'rsp-ditem', title: (it.nick || '') + ' — ' + (it.title || '') },
          it.adult ? el('span', { class: 'rsp-dad', text: 'AD' }) : null,
          el('span', { class: 'rsp-dnick', text: it.nick || it.oid.slice(0, 8) }),
          el('span', { class: 'rsp-dtitle', text: it.title || '(タイトルなし)' }),
          el('span', { class: 'rsp-dview', text: view }),
          el('span', { class: 'rsp-dtag', text: '▶' }));
        row.addEventListener('click', function () { openLive(it.oid); });
        listEl.appendChild(row);
      }
    }
    let _renderTimer = null;
    function renderSoon() { // 節流描画(800ms) — 走査中の高頻度結果更新を平滑化
      if (_renderTimer) return;
      _renderTimer = setTimeout(function () { _renderTimer = null; render(); }, 800);
    }
    function statText() {
      if (D.scanning) return T.discScanning;
      if (Date.now() < D.cooldownUntil) {
        return (T.discCooldown || 'cooling %Ss').replace('%S', Math.ceil((D.cooldownUntil - Date.now()) / 1000)) +
          (D.lastErr ? ' — ' + D.lastErr : '');
      }
      const base = D.live.size + '件ライブ / 候補' + D.pool.length + '人' +
        (D.lastScanAt ? ' / 最終' + new Date(D.lastScanAt).toTimeString().slice(0, 8) : '');
      return base;
    }
    function renderStat() { setStat(statText()); }

    /* 全体ペーシング+403/429退避つきの取得(Discovery内部の全fetchはここを通る)。
       scope='pool'(curation)の403はインフラ制限とみなし即全体退避。
       scope='probe'(個別creatorのlive/play)の403は配信単位の事情の可能性が
       高いため、DISC_403_TOL回/走査までは個人スキップで継続(実環境で
       一部creatorが403でも全体が死なない) */
    async function fetchDisc(url, authJwt, scope) {
      if (Date.now() < D.cooldownUntil) return { status: 0, held: true };
      /* スロット先確保: 応答が速いと到着時にnextAtが過去になり無ペース化するため、
         待機の有無にかかわらず必ずスロットを1つ予約してから送信する(全体で
         DISC_REQ_GAP_MS間隔を保証 — 防封禁設計の要) */
      const nowMs = Date.now();
      const wait = D.nextAt - nowMs;
      D.nextAt = Math.max(D.nextAt, nowMs) + DISC_REQ_GAP_MS;
      if (wait > 0) await new Promise(function (r) { setTimeout(r, wait); });
      try {
        const ctl = new AbortController();
        const to = setTimeout(function () { ctl.abort(); }, DISC_TIMEOUT_MS);
        const opt = { cache: 'no-store', signal: ctl.signal };
        if (authJwt) opt.headers = { Authorization: authJwt };
        const res = await fetch(url, opt);
        clearTimeout(to);
        if (res.status === 429) {
          const ra = recRetryAfterMs(res.headers.get('retry-after')); // v1.12.0: RA最優先
          const ms = ra || Math.min(DISC_429_BASE_MS * Math.pow(2, ++D.c429 - 1), DISC_429_MAX_MS);
          D.cooldownUntil = Date.now() + ms;
          D.lastErr = '429(レート制限)' + (ra ? '/RA' : '');
          return { status: 429, held: true };
        }
        if (res.status === 403) {
          if (scope !== 'probe') { // curation等インフラ層の403 → 全体退避
            D.cooldownUntil = Date.now() + DISC_403_COOLDOWN_MS;
            D.lastErr = '403(アクセス制限)';
            return { status: 403, held: true };
          }
          return { status: 403, held: false }; // 個別creator → 呼び側で学習/連続判定
        }
        if (res.status === 200) {
          D.c429 = 0;
          let json = null;
          try { json = await res.json(); } catch (e) { /* 非JSON */ }
          return { status: 200, json: json };
        }
        return { status: res.status };
      } catch (e) { return { status: 0 }; }
    }
    /* 候補pool: 公式creatorListコンポーネント(公開)から取得 */
    async function ensurePool() {
      if (D.pool.length && Date.now() - D.poolAt < DISC_CACHE_TTL_MS) return true;
      const srcs = discSourcesGet();
      const set = new Set();
      for (let i = 0; i < srcs.length; i++) {
        const r = await fetchDisc(API_BASE + '/content/curation?componentOids[]=' + srcs[i] +
          '&liveDataRequest=true&forceFetch=false&lang=jp&platformType=rplay');
        if (r.held) return false;
        if (r.status !== 200 || !r.json) continue;
        const items = Array.isArray(r.json) ? r.json : (r.json.curationData || []);
        for (let k = 0; k < items.length; k++) {
          const c = items[k];
          if (!c || c.curationType !== 'creatorList') continue; // livestreamList(セッションOID)は逆引き不能のため対象外
          const lst = ((c.componentData || {}).list) || [];
          for (let m = 0; m < lst.length; m++) {
            const oid = lst[m];
            if (typeof oid === 'string' && DISC_OID_RE.test(oid)) set.add(oid);
          }
        }
      }
      D.pool = Array.from(set);
      D.poolAt = Date.now();
      return D.pool.length > 0;
    }
    /* 自分の会話での一覧API(ログイン時のみ。401=静かに諦めて公開走査) */
    async function tryAuthedStreams() {
      if (D.authedTriedAt && Date.now() - D.authedTriedAt < 300000) return null;
      D.authedTriedAt = Date.now();
      try {
        const r = await authedJson(API_BASE + '/live/streams', { timeoutMs: DISC_TIMEOUT_MS });
        if (!r.ok || !r.json) return null; // 401含む(未ログインは公式と同様に見えないだけ)
        const items = discParseAuthedStreams(r.json);
        if (items && items.length) {
          D.authedUsed = true;
          authBadge.textContent = T.discAuthed;
          return items;
        }
      } catch (e) { /* 公開走査へ */ }
      return null;
    }
    /* creatorOid 1件の確認(公開・公式の匿名視聴用API) */
    async function probeCreator(oid) {
      if (D.skip403.has(oid)) { D.live.delete(oid); return { status: 403, held: false }; } // 学習済みスキップ
      const r = await fetchDisc(API_BASE + '/live/play?creatorOid=' + encodeURIComponent(oid) +
        '&key=&platformType=rplay&lang=jp', null, 'probe');
      if (r.held) return r;
      if (r.status === 403) {
        /* 実環境では一部creatorのlive/playが恒常403(約4%)。
           散発403はスキップ学習し、連続403(DISC_403_CONSEC回)のときだけ
           インフラ制限とみなして全体退避する(IPブロック等の早期検出) */
        D.skip403.add(oid);
        D.live.delete(oid);
        D.consec403++;
        if (D.consec403 >= DISC_403_CONSEC) {
          D.cooldownUntil = Date.now() + DISC_403_COOLDOWN_MS;
          D.lastErr = '403(アクセス制限・' + D.consec403 + '連続)';
          return { status: 403, held: true };
        }
        return r;
      }
      if (r.status === 200) D.consec403 = 0;
      renderSoon(); // v1.12.0: 走査中も結果を漸次表示(節流描画)
      if (r.status !== 200 || !r.json || r.json.streamState !== 'live') {
        D.live.delete(oid);
        return r;
      }
      const cm = r.json.creatorMetadata || {};
      const item = {
        oid: oid, nick: cm.nickname || '', title: r.json.title || '',
        adult: !!r.json.isAdultContent, viewers: null, src: 'public'
      };
      const r2 = await fetchDisc(API_BASE + '/live/stream?creatorOid=' + encodeURIComponent(oid),
        null, 'probe');
      renderSoon(); // v1.12.0: 視聴者数確認後も漸次表示
      if (!r2.held && r2.status === 200 && r2.json && typeof r2.json.viewerCount === 'number') {
        item.viewers = r2.json.viewerCount;
      }
      D.live.set(oid, item);
      return r;
    }
    /* 同時実行ランナー(403/429で全体中断) */
    async function runPool(list) {
      let idx = 0, aborted = false;
      const workers = [];
      for (let w = 0; w < DISC_CONC; w++) {
        workers.push((async function () {
          while (!aborted) {
            const i = idx++;
            if (i >= list.length) break;
            const r = await probeCreator(list[i]);
            if (r && r.held) { aborted = true; }
          }
        })());
      }
      await Promise.all(workers);
      return !aborted;
    }
    async function scan(full) {
      if (D.scanning) return;
      if (Date.now() < D.cooldownUntil) { renderStat(); return; }
      D.scanning = true;
      D.consec403 = 0; // v1.12.0: 連続403は走査単位で復位
      renderStat();
      render(); // 走査前の現状を表示維持
      try {
        if (full) {
          const ok = await ensurePool();
          if (!ok && Date.now() < D.cooldownUntil) { renderStat(); return; }
          const authed = await tryAuthedStreams(); // 自分の会話(401なら非表示・公開走査へ)
          if (authed) for (let i = 0; i < authed.length; i++) D.live.set(authed[i].oid, authed[i]);
          if (D.pool.length) await runPool(D.pool);
          D.lastFullAt = Date.now();
          D.rotateIdx = 0;
        } else {
          /* 軽量更新: 既知LIVEの再確認+候補の輪読スライス(恒常負荷を最小化) */
          const known = Array.from(D.live.keys());
          const slice = [];
          const n = Math.min(DISC_SLICE, D.pool.length);
          for (let i = 0; i < n; i++) slice.push(D.pool[(D.rotateIdx + i) % D.pool.length]);
          D.rotateIdx = D.pool.length ? ((D.rotateIdx + n) % D.pool.length) : 0;
          await runPool(known.concat(slice));
        }
        D.lastScanAt = Date.now();
        if (Date.now() >= D.cooldownUntil) D.lastErr = ''; // 退避中は理由を表示保持
      } finally {
        D.scanning = false;
        render();
        renderStat();
      }
    }
    scanBtn.addEventListener('click', function () { scan(true); });
    refBtn.addEventListener('click', function () { scan(false); });
    /* 自動更新(軽量のみ・タブ非表示時は停止・退避中は何もしない) */
    const autoMs = (window.__RSP_TEST && window.__RSP_TEST.discAutoMs) || DISC_AUTO_MS_DEFAULT;
    D.timer = setInterval(function () {
      if (document.hidden || D.scanning || !autoChk.checked) return;
      if (Date.now() < D.cooldownUntil) { renderStat(); return; }
      if (!D.pool.length && !D.live.size) return; // 未走査なら自動では始めない
      scan(false);
    }, autoMs);
    render();
    renderStat();
    scan(true); // パネルを開いたら最初に全走査
    _discCleanup = closeDisc;
    return D;
  }

  let _discCleanup = null;
  /* ライブ/動画ページ以外(TOP・一覧等)で提示する探索ボタン */
  function mountDiscoveryFab() {}
