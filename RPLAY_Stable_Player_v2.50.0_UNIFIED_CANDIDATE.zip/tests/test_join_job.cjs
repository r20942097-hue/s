'use strict';
const {test}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const source=fs.readFileSync(require('node:path').join(__dirname,'../src/part_io.js'),'utf8');
const code=source.slice(source.indexOf('  function recJoinJob(owner)'));
const context=vm.createContext({});vm.runInContext(code+';this.make=recJoinJob;',context);
test('browser join job preserves part order and hashes while excluding credentials and URLs',()=>{
 const owner={partsLog:[{file:'b.ts',bytes:2,sha256:'b'.repeat(64)},{file:'a.ts',bytes:1}],jwt:'SECRET',playlist:'https://host/?token=SECRET'};
 const job=JSON.parse(JSON.stringify(context.make(owner)));
 a.deepEqual(job.parts.map(p=>p.file),['b.ts','a.ts']);a.equal(job.parts[0].sha256,'b'.repeat(64));
 a(!JSON.stringify(job).includes('SECRET'));a(!JSON.stringify(job).includes('https:'));
});
test('browser loss and truncated history are explicitly marked',()=>{
 const job=context.make({partsLog:[{file:'a.ts',bytes:1}],gapCount:1,_joinTruncated:true});
 a.equal(job.incomplete,true);a.equal(job.truncated,true);
});
test('browser separate audio is retained in job so helper cannot silently omit it',()=>{
 const job=context.make({partsLog:[{file:'v.ts',bytes:1}],audio:{partsLog:[{file:'a.ts',bytes:2}]}});
 a.equal(job.audioRendition.parts[0].file,'a.ts');
});
test('join manifest retains earlier files beyond the 500-entry display history',()=>{
 const all=Array.from({length:600},(_,i)=>({file:'part'+i+'.ts',bytes:1}));
 const job=context.make({partsLog:all.slice(-500),_joinParts:all});
 a.equal(job.parts.length,600);a.equal(job.parts[0].file,'part0.ts');a.equal(job.truncated,false);
});
test('HLS boundary evidence remains numeric after a prior size split',async()=>{
 const H=require('../src/hls_transport.js');
 const owner={partOpen:true,_hlsBoundary:'old',_hlsPartBoundaries:{sizeLimit:1},
  async closePart(){this.partOpen=false;},pushData(){this.partOpen=true;}};
 await H.append(owner,{hls:{map:null}},{boundary:'new',data:new Uint8Array([1])});
 a.equal(owner._hlsPartBoundaries.hlsBoundary,1);a.equal(owner._hlsPartBoundaries.sizeLimit,1);
});
