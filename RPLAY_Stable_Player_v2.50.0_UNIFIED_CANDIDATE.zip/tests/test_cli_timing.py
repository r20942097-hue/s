import importlib.util,pathlib,unittest
from unittest.mock import patch
p=pathlib.Path(__file__).resolve().parents[1]/'rplay_dl.py';spec=importlib.util.spec_from_file_location('cli_timing',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
BODY='#EXTM3U\n#EXT-X-TARGETDURATION:12\n#EXT-X-MEDIA-SEQUENCE:1\n#EXTINF:12,\na.ts\n'
class Timing(unittest.TestCase):
 def test_minima(self):
  self.assertEqual(m.hls_reload_ms(12,True,0),12000);self.assertEqual(m.hls_reload_ms(12,False,0),6000);self.assertEqual(m.hls_reload_ms(30,True,0),30000)
 def test_invalid(self):
  self.assertEqual(m.hls_reload_ms(float('nan'),True,float('nan')),9000);self.assertEqual(m.hls_reload_ms(-3,False,0),4500)
 def test_jitter_never_shortens(self):
  self.assertGreaterEqual(m.hls_reload_ms(12,True,-1),12000);self.assertGreaterEqual(m.hls_reload_ms(12,False,.1),6000)
 def video(self):
  r=m.Dl.__new__(m.Dl);r.poll_count=0;r.pl_backoff=0;r.playlist_url=lambda:'https://fixture/a.m3u8';r.best_q=False;r.master_url='';r.c404=0;r.target_dur=0;r.last_seq=-1;r.last_dis=None;r.part_open=False;r.follow=False;r._skip_backlog=False;r.audio_only=False;r.seen=set();r.queue=[];r.gaps=0;r.byterange_skipped=0;r.backlog=True;r.log=lambda *a:None;r.last_poll=0
  r.http=lambda *a,**kw:(200,BODY.encode(),0)
  return r
 def test_actual_video_response_schedule(self):
  r=self.video()
  with patch.object(m.random,'random',return_value=0):
   r.poll_playlist();self.assertEqual(r.cur_poll_ms,12000);r.poll_playlist();self.assertEqual(r.cur_poll_ms,6000);r.http=lambda *a,**k:(200,BODY.replace('SEQUENCE:1','SEQUENCE:2').encode(),0);r.poll_playlist();self.assertEqual(r.cur_poll_ms,12000)
 def test_effective_request_start(self):
  r=self.video()
  with patch.object(m,'now_ms',side_effect=[100000,100000,100500,100500]),patch.object(m.random,'random',return_value=0):r.poll_playlist()
  self.assertEqual(r.last_poll,100500)
 def test_signed_query_is_preserved_when_adding_cache_bust(self):
  r=self.video();seen=[];r.http=lambda u,*a,**k:(seen.append(u) or (200,BODY.encode(),0));r._playlist_get('https://fixture/a.m3u8?signature=fixture');self.assertIn('?signature=fixture&_rsp=',seen[0]);self.assertEqual(seen[0].count('?'),1)
 def test_actual_audio_response_schedule(self):
  r=m.Dl.__new__(m.Dl);r.a_uri='https://fixture/audio.m3u8';r.state='RUN';r.a_target_dur=0;r.a_last_seq=-1;r.a_part_open=False;r.a_seen=set();r.a_queue=[];r.http=lambda *a,**k:(200,BODY.encode(),0);r.log=lambda *a:None
  with patch.object(m.random,'random',return_value=0):
   r.a_seg_fails=0;r.audio_poll(100000);self.assertEqual(r.a_cur_poll_ms,12000);r.audio_poll(112000);self.assertEqual(r.a_cur_poll_ms,6000)
if __name__=='__main__':unittest.main()
