import importlib.util,pathlib,unittest,subprocess,json
from unittest.mock import patch
R=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('hls_cli',R/'rplay_dl.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
BASE='https://fixture/live.m3u8'
def playlist(s):return '#EXTM3U\n#EXT-X-TARGETDURATION:1\n'+s
class HLS(unittest.TestCase):
 def test_parser_matches_browser_vectors(self):
  vectors=[playlist('#EXT-X-MEDIA-SEQUENCE:12\n#EXT-X-BYTERANGE:188@0\na.ts\n#EXT-X-BYTERANGE:188\na.ts'),playlist('#EXT-X-DISCONTINUITY-SEQUENCE:9\n#EXT-X-MAP:URI="init,a.mp4",BYTERANGE="16@0"\na.m4s\n#EXT-X-DISCONTINUITY\n#EXT-X-GAP\nb.m4s\n#EXT-X-ENDLIST')]
  js="const H=require('./src/hls_transport.js');let s='';process.stdin.on('data',x=>s+=x);process.stdin.on('end',()=>process.stdout.write(JSON.stringify(JSON.parse(s).map(t=>H.parse(t,'"+BASE+"')))));"
  p=subprocess.run(['node','-e',js],input=json.dumps(vectors),text=True,capture_output=True,cwd=R,check=True)
  expected=json.loads(p.stdout)
  for text,jsvalue in zip(vectors,expected):
   actual=m.hls_parse(text,BASE);jsvalue.pop('discontinuity');self.assertEqual(actual,jsvalue)
 def test_invalid_descriptors_fail_before_queue_mutation(self):
  for s in ['#EXT-X-BYTERANGE:188\na.ts','#EXT-X-BYTERANGE:0@0\na.ts','#EXT-X-BYTERANGE:33554433@0\na.ts','#EXT-X-BYTERANGE:1@9007199254740992\na.ts','#EXT-X-BYTERANGE:188@0','#EXT-X-KEY:METHOD=AES-128,URI="key"\na.ts','#EXT-X-MAP:URI="init",BYTERANGE="16"\na.m4s','file:///tmp/a']:
   with self.subTest(s=s),self.assertRaises(ValueError):m.hls_parse(playlist(s),BASE)
 def test_missing_target_is_rejected(self):
  with self.assertRaisesRegex(ValueError, 'HLS_BAD_TARGET'):m.hls_parse('#EXTM3U\na.ts',BASE)
 def test_iframes_only_is_not_normal_recording(self):
  with self.assertRaisesRegex(ValueError, 'HLS_IFRAMES_UNSUPPORTED'):m.hls_parse(playlist('#EXT-X-I-FRAMES-ONLY\na.ts'),BASE)
 def test_endlist_rejects_late_segments_and_duplicate_endtags(self):
  with self.assertRaisesRegex(ValueError, 'HLS_SEGMENT_AFTER_ENDLIST'):m.hls_parse(playlist('#EXT-X-ENDLIST\na.ts'),BASE)
  with self.assertRaisesRegex(ValueError, 'HLS_DUPLICATE_ENDLIST'):m.hls_parse(playlist('a.ts\n#EXT-X-ENDLIST\n#EXT-X-ENDLIST'),BASE)
 def test_sequence_identity_backpressure_and_rewind(self):
  r=m.Dl.__new__(m.Dl);r.seen=set();r.queue=[]
  for sig in ['old','new']:m.hls_enqueue(r,m.hls_parse(playlist('#EXT-X-MEDIA-SEQUENCE:4\na.ts?sig='+sig),BASE),BASE)
  self.assertEqual(len(r.queue),1)
  # v2.5.0 generation recovery: rewind to an already-recorded path is stale evidence
  # (no epoch bump, no duplicate enqueue) instead of a new generation.
  m.hls_enqueue(r,m.hls_parse(playlist('#EXT-X-MEDIA-SEQUENCE:1\na.ts'),BASE),BASE)
  self.assertEqual(len(r.queue),1)
  self.assertEqual(r._hls_state['recovery']['staleResponses'],1)
  self.assertEqual(r._hls_state['recovery']['lastKind'],'stale')
  # rewind to unknown paths is a legitimate reset: epoch advances and new data is queued
  m.hls_enqueue(r,m.hls_parse(playlist('#EXT-X-MEDIA-SEQUENCE:0\nnew1.ts\nnew2.ts'),BASE),BASE)
  self.assertEqual(len(r.queue),3);self.assertNotEqual(r.queue[0]['hls']['epoch'],r.queue[2]['hls']['epoch'])
  self.assertEqual(r._hls_state['recovery']['sequenceResets'],1)
  r.queue=[None]*4096;before=r.seen.copy()
  with self.assertRaisesRegex(ValueError,'QUEUE_LIMIT'):m.hls_enqueue(r,m.hls_parse(playlist('#EXT-X-MEDIA-SEQUENCE:2\nb.ts'),BASE),BASE)
  self.assertEqual(r.seen,before)
 def test_ts_validation_rejects_later_packet_corruption(self):
  data=(b'G'+bytes(187))*6;m.hls_validate(data,'ts')
  with self.assertRaisesRegex(ValueError,'BAD_TS'):m.hls_validate(data[:-188]+bytes(188),'ts')
  with self.assertRaisesRegex(ValueError,'BAD_TS'):m.hls_validate(data[:-1],'ts')
 def test_map_validation_checks_container_bounds(self):
  def box(t):return (8).to_bytes(4,'big')+t
  m.hls_validate(box(b'ftyp')+box(b'moov'),'init');m.hls_validate(box(b'moof')+box(b'mdat'),'fragment')
  for data in [b'html',box(b'ftyp'),(100).to_bytes(4,'big')+b'moov']:
   with self.assertRaises(ValueError):m.hls_validate(data,'init')
 def test_rate_limit_retains_fifo_attempt_and_server_wait(self):
  r=m.Dl.__new__(m.Dl);r.c429=0;item={'tries':1}
  with patch.object(m,'now_ms',return_value=1000):self.assertEqual(r._hls_status(item,429,120000,False),(None,True))
  self.assertEqual(item['tries'],0);self.assertEqual(r.seg_backoff,121000)
if __name__=='__main__':unittest.main()

class RangeHTTP(unittest.TestCase):
 def test_real_http_rejects_ignored_wrong_short_and_oversized_ranges(self):
  import http.server,threading
  class Handler(http.server.BaseHTTPRequestHandler):
   def log_message(self,*args):pass
   def do_GET(self):
    mode=self.path;self.send_response(200 if mode=='/ignored' else 206)
    self.send_header('Content-Range','bytes 0-187/1000' if mode=='/wrong' else 'bytes 188-375/1000')
    data=b'x' if mode=='/short' else bytes(188)
    self.send_header('Content-Length','99999999' if mode=='/huge' else str(len(data)))
    self.end_headers();self.wfile.write(data)
  server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  r=m.Dl.__new__(m.Dl);r.ua='offline-test'
  try:
   for mode in ['ignored','wrong','short','huge']:
    with self.subTest(mode=mode),self.assertRaises(ValueError):m.hls_request(r,{'uri':'http://127.0.0.1:%d/%s'%(server.server_port,mode),'range':{'offset':188,'length':188}})
  finally:server.shutdown();server.server_close();thread.join(2)
