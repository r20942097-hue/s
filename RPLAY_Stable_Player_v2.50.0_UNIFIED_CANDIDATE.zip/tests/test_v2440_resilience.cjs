const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const HLS = require(path.join(root, 'src/hls_transport.js'));
const PartCommit = vm.runInNewContext(fs.readFileSync(path.join(root, 'src/part_commit_core.js'), 'utf8') + '\nrspPartCommit;', {});

function validTsChunk(seq = 0, packets = 2) {
  const buf = new Uint8Array(188 * packets);
  for (let i = 0; i < packets; i++) {
    buf[i * 188] = 0x47;
    buf[i * 188 + 1] = 0x01;
    buf[i * 188 + 2] = 0x00;
    buf[i * 188 + 3] = 0x10 | ((seq + i) & 0x0f);
  }
  return buf;
}

function loadRecorderContext(fetchImpl) {
  const s = fs.readFileSync(path.join(root, 'rplay-stable-player.user.js'), 'utf8');
  const start = s.indexOf('async function recFetchDescriptor');
  const end = s.indexOf('/* ==== RSP RECORDING CORE', start);
  const code = s.slice(start, end);
  const savedJsons = [];
  const ctx = {
    HLS,
    rspPartCommit: PartCommit,
    fetch: fetchImpl,
    TextDecoder,
    TextEncoder,
    Uint8Array,
    URL,
    Set,
    Map,
    Math,
    Date,
    Promise,
    Error,
    Number,
    String,
    Object,
    Array,
    Blob: class { constructor(parts) { this.text = parts.join(''); } },
    JSON,
    console,
    setTimeout: (fn) => { fn(); return 1; },
    clearTimeout: () => {},
    setInterval: () => 1,
    clearInterval: () => {},
    CDN_BASE: 'https://cdn.example/',
    API_BASE: 'https://api.example',
    TITLEC: { base: 'StreamTitle' },
    REC_TICK_MS: 10,
    REC_POLL_JITTER_MS: 0,
    REC_STALL_GIVE_UP_MS: 60000,
    REC_STANDBY_FAST_MS: 10,
    REC_STANDBY_SLOW_MS: 10,
    REC_STANDBY_WARM_SEC: 60,
    REC_STANDBY_API_MS: 10,
    REC_STANDBY_SCHED_MS: 10,
    REC_SCHED_WARM_BEFORE_MS: 10,
    REC_SEG_MAX_TRIES: 3,
    REC_SEG_TIMEOUT_MS: 50,
    REC_API_TIMEOUT_MS: 50,
    REC_REQ_MIN_GAP_MS: 0,
    REC_404_STANDBY: 3,
    REC_404_GIVE_UP: 5,
    REC_403_COOLDOWN_MS: 10,
    REC_429_BASE_MS: 10,
    REC_429_MAX_MS: 20,
    REC_FILE_CAP_BYTES: 1048576,
    REC_SPLIT_MIN_DEFAULT: 0,
    REC_QUEUE_WARN_MS: 60000,
    REC_QUALITY_RESCAN_MS: 60000,
    REC_MASTER_FAILOVER_N: 2,
    REC_AUDIO_OFFSET_MIN_MS: 0,
    REC_AUDIO_OFFSET_SPAN_MS: 0,
    REC_AUDIO_STALL_MS: 60000,
    REC_SESSION_KEY: 'k',
    REC_SESSION_STALE_MS: 60000,
    RECENV: {
      download: (blob, name) => savedJsons.push({ name, obj: blob && blob.text ? JSON.parse(blob.text) : null }),
      storageGet: () => '',
      storageSet: () => {},
      storageDel: () => {},
      saveJson: (obj, name) => savedJsons.push({ name, obj: JSON.parse(obj) }),
      notify: () => {},
      sessionLoad: () => null,
      sessionSave: () => {},
      sessionClear: () => {},
      historyAdd: () => {},
      testHooks: () => ({}),
      autoPolicy: async () => ({ verdict: 'allowed' }),
      sessionEnded: () => {}
    },
    RecPartSink: class {
      constructor(name, dir, ext) {
        this.name = name;
        this.ext = ext;
        this.bytes = 0;
      }
      push(u8) { this.bytes += u8.byteLength; }
      async flush() {}
      continuousDisk() { return true; }
      async close() {
        return {
          confirmed: true,
          stage: 'FILE_CLOSED',
          bytes: this.bytes,
          hashHex: 'a'.repeat(64),
          checkpoint: { chunks: 1, committedBytes: this.bytes, status: 'complete' }
        };
      }
    },
    recFileName: (_tpl, _vars, def) => def,
    safeName: (x) => x,
    stampNow: () => 'now',
    pad2: (n) => String(n).padStart(2, '0'),
    recSaveBlob: (blob, _dir, name) => { savedJsons.push({ name, obj: blob && blob.text ? JSON.parse(blob.text) : null }); return Promise.resolve({ confirmed: true, stage: 'FILE_CLOSED' }); },
    idbAddSession: async () => {},
    recTrackSave: (_o, p) => p,
    recWaitSaves: async () => {},
    recLedgerStage: () => {},
    recLedgerStatus: () => 'verified_local',
    recHlsReloadMs: () => 10,
    recRetryAfterMs: () => 0,
    recRedactUrl: (u) => (u ? u.split('?')[0] : ''),
    recJoinJob: () => null,
    resolveMemberLive: async () => null,
    memberHintText: () => '',
    memberFailHint: () => '',
    refreshPlayCandidates: async () => [],
    liveStreamState: async () => ({}),
    liveBaseLabel: () => 'CDN',
    rspSourceCandidates: () => [],
    probeLiveApiState: async () => null,
    fetchUpcomingSchedule: async () => null,
    resolveScheduleInfo: async () => null,
    fetchSchedulesFor: async () => ({ items: [] }),
    pickBestVariant: (v) => v[0] || null,
    pickBestAudioRendition: () => null,
    parseM3u8Variants: () => [],
    parseM3u8AudioRenditions: () => [],
    recRecoveryEvidence: () => undefined,
    rspPartContinuityEvidence: () => undefined,
    createTsVerifier: () => ({ usingWorker: () => false, check: async () => ({ ok: true }) })
  };
  vm.runInNewContext(
    code + '\nthis.Recorder=Recorder;this.AudioRecorder=AudioRecorder;this.recFetchDescriptor=recFetchDescriptor;',
    ctx
  );
  ctx.savedJsons = savedJsons;
  return ctx;
}

function makeUi() {
  const logs = [];
  return {
    logs,
    log: (m) => logs.push(m),
    recState: () => {},
    recBytes: () => {},
    setQualityList: () => {},
    getSelectedQuality: () => 'best',
    isBestQuality: () => false,
    isFollow: () => false,
    getSplitMinutes: () => 0,
    isInfoJson: () => true,
    getFilenameTpl: () => '',
    isRecAudio: () => true,
    isInheritQuery: () => false,
    isSplitOnDiscontinuity: () => false
  };
}

test('v2.44.0 resilience: video pollPlaylist tolerates up to 2 transient corrupted playlists during active recording and recovers without stopping', async () => {
  let pollStep = 0;
  const ctx = loadRecorderContext(async (u) => {
    const url = String(u);
    if (url.endsWith('.m3u8')) {
      pollStep++;
      if (pollStep === 1) {
        return new Response('#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:10\n#EXTINF:2.0,\nseg10.ts\n', { status: 200 });
      }
      if (pollStep === 2) {
        // Transient truncated playlist (missing header / partial write)
        return new Response('CORRUPTED_PARTIAL_CDN_FLUSH', { status: 200 });
      }
      if (pollStep === 3) {
        // Transient dangling #EXTINF without segment URI
        return new Response('#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:11\n#EXTINF:2.0,\n', { status: 200 });
      }
      return new Response('#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:11\n#EXTINF:2.0,\nseg11.ts\n', { status: 200 });
    }
    return new Response(validTsChunk(pollStep), { status: 200 });
  });
  const ui = makeUi();
  const rec = new ctx.Recorder('a'.repeat(24), ui, {});
  rec.recording = true;
  rec.stopped = false;
  rec.state = 'RUN';

  // Poll 1: valid playlist + drain seg10.ts -> segTotal becomes 1
  await rec.pollPlaylist();
  await rec.drain();
  assert.equal(rec.segTotal, 1);
  assert.equal(rec.stopped, false);

  // Poll 2: corrupted playlist #1 (HLS_BAD_PLAYLIST) -> tolerated!
  await rec.pollPlaylist();
  assert.equal(rec.stopped, false);
  assert.equal(rec._badPlaylistConsec, 1);

  // Poll 3: corrupted playlist #2 (HLS_DANGLING_TAG) -> tolerated!
  await rec.pollPlaylist();
  assert.equal(rec.stopped, false);
  assert.equal(rec._badPlaylistConsec, 2);

  // Poll 4: valid playlist with seg11.ts -> recovers!
  await rec.pollPlaylist();
  await rec.drain();
  assert.equal(rec.stopped, false);
  assert.equal(rec._badPlaylistConsec, 0);
  assert.equal(rec._badPlaylistRecovered, 1);
  assert.equal(rec.segTotal, 2);

  await rec.closePart();
  rec.saveInfoJson();
  const info = ctx.savedJsons[ctx.savedJsons.length - 1].obj;
  assert.deepEqual(info.playlistParseGraceEvidence, {
    transientFailures: 2,
    recoveredPolls: 1
  });
});

test('v2.44.0 resilience: video pollPlaylist fails closed on initial bad playlist (segTotal===0) or unsupported encryption', async () => {
  const ctx1 = loadRecorderContext(async () => new Response('NOT_M3U8', { status: 200 }));
  const rec1 = new ctx1.Recorder('a'.repeat(24), makeUi(), {});
  rec1.recording = true;
  rec1.stopped = false;
  rec1.state = 'RUN';
  await rec1.pollPlaylist();
  assert.equal(rec1.stopped, true, 'must stop immediately when segTotal === 0');

  let step = 0;
  const ctx2 = loadRecorderContext(async (u) => {
    if (String(u).endsWith('.m3u8')) {
      step++;
      if (step === 1) return new Response('#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:1\n#EXTINF:2,\ns1.ts\n', { status: 200 });
      return new Response('#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-KEY:METHOD=AES-128,URI="https://cdn.example/k"\n#EXTINF:2,\ns2.ts\n', { status: 200 });
    }
    return new Response(validTsChunk(1), { status: 200 });
  });
  const rec2 = new ctx2.Recorder('a'.repeat(24), makeUi(), {});
  rec2.recording = true;
  rec2.stopped = false;
  rec2.state = 'RUN';
  await rec2.pollPlaylist();
  await rec2.drain();
  assert.equal(rec2.segTotal, 1);
  await rec2.pollPlaylist();
  assert.equal(rec2.stopped, true, 'must fail closed immediately on HLS_ENCRYPTED_UNSUPPORTED even when segTotal > 0');
});

test('v2.44.0 resilience: recFetchDescriptor retries transient segment truncation (HLS_BODY_LENGTH / HLS_EMPTY_BODY) in strict FIFO order without dropping', async () => {
  const attempts = {};
  const ctx = loadRecorderContext(async (u) => {
    const url = String(u);
    if (url.endsWith('.m3u8')) {
      return new Response('#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:100\n#EXTINF:2,\nseg100.ts\n#EXTINF:2,\nseg101.ts\n', { status: 200 });
    }
    attempts[url] = (attempts[url] || 0) + 1;
    if (url.endsWith('seg100.ts') && attempts[url] === 1) {
      // First attempt for seg100.ts: Content-Length mismatch (truncated read -> HLS_BODY_LENGTH)
      return new Response(new Uint8Array(100), { status: 200, headers: { 'content-length': '376' } });
    }
    if (url.endsWith('seg101.ts') && attempts[url] === 1) {
      // First attempt for seg101.ts: Empty body (0 bytes -> HLS_EMPTY_BODY)
      return new Response(new Uint8Array(0), { status: 200 });
    }
    return new Response(validTsChunk(url.endsWith('seg100.ts') ? 0 : 2), { status: 200 });
  });
  const ui = makeUi();
  const rec = new ctx.Recorder('a'.repeat(24), ui, {});
  rec.recording = true;
  rec.stopped = false;
  rec.state = 'RUN';

  await rec.pollPlaylist();
  // Drain step 1: seg100 fails with HLS_BODY_LENGTH -> sets segBackoffUntil and unshifts seg100 back to head
  await rec.drain();
  assert.equal(rec.segTotal, 0);
  assert.equal(rec.segFails, 0);
  assert.equal(rec.queue.length, 2);
  assert.ok(rec.queue[0].name.endsWith('seg100.ts'), 'seg100 must remain at head of queue');

  // Clear backoff and drain step 2: seg100 succeeds, seg101 fails with HLS_EMPTY_BODY -> unshifts seg101
  rec.segBackoffUntil = 0;
  await rec.drain();
  assert.equal(rec.segTotal, 1);
  assert.equal(rec.segFails, 0);
  assert.equal(rec.queue.length, 1);
  assert.ok(rec.queue[0].name.endsWith('seg101.ts'));

  // Clear backoff and drain step 3: seg101 succeeds
  rec.segBackoffUntil = 0;
  await rec.drain();
  assert.equal(rec.segTotal, 2);
  assert.equal(rec.segFails, 0);
  assert.equal(rec.queue.length, 0);

  const we = HLS.writeEvidence(rec);
  assert.equal(we.accepted, 2);
  assert.equal(we.terminal, 0);
  assert.equal(we.suspectedAcceptedSequenceGaps, 0);

  await rec.closePart();
  rec.saveInfoJson();
  const info = ctx.savedJsons[ctx.savedJsons.length - 1].obj;
  assert.deepEqual(info.segmentTransferRetryEvidence, {
    retries: 2,
    recoveredSegments: 2,
    failedSegments: 0
  });
});

test('v2.44.0 resilience: AudioRecorder tolerates single active-stream 404 and transient bad playlist without stopping audio track', async () => {
  let audioStep = 0;
  const ctx = loadRecorderContext(async (u) => {
    const url = String(u);
    if (url.endsWith('audio.m3u8')) {
      audioStep++;
      if (audioStep === 1) return new Response('#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:1\n#EXTINF:2,\na1.ts\n', { status: 200 });
      if (audioStep === 2) return new Response('', { status: 404 }); // single transient CDN 404 while active
      if (audioStep === 3) return new Response('TRUNCATED_AUDIO_M3U8', { status: 200 }); // single transient bad playlist
      return new Response('#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:2\n#EXTINF:2,\na2.ts\n', { status: 200 });
    }
    return new Response(validTsChunk(1), { status: 200 });
  });
  const ui = makeUi();
  const rec = new ctx.Recorder('a'.repeat(24), ui, {});
  rec.recording = true;
  rec.stopped = false;
  rec.state = 'RUN';
  const audio = rec.audio = new ctx.AudioRecorder(rec);
  audio.running = true;
  audio.uri = 'https://cdn.example/audio.m3u8';

  // Step 1: valid audio playlist + drain a1.ts
  await audio.poll(Date.now());
  await audio.drain();
  assert.equal(audio.segTotal, 1);
  assert.equal(audio.running, true);

  // Step 2: single 404 while segTotal > 0 -> tolerated!
  await audio.poll(Date.now());
  assert.equal(audio.running, true);
  assert.equal(audio._c404, 1);

  // Step 3: single corrupted playlist while segTotal > 0 -> tolerated!
  await audio.poll(Date.now());
  assert.equal(audio.running, true);
  assert.equal(audio._badPlaylistConsec, 1);

  // Step 4: valid playlist with a2.ts -> recovers!
  await audio.poll(Date.now());
  await audio.drain();
  assert.equal(audio.running, true);
  assert.equal(audio._c404, 0);
  assert.equal(audio._badPlaylistConsec, 0);
  assert.equal(audio.segTotal, 2);
});

test('v2.44.0 resilience: exact per-part segment sequence binding (partSequenceRange) across multi-part recording', async () => {
  let pollCount = 0;
  const ctx = loadRecorderContext(async (u) => {
    if (String(u).endsWith('.m3u8')) {
      pollCount++;
      if (pollCount === 1) {
        return new Response('#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:50\n#EXTINF:2,\ns50.ts\n#EXTINF:2,\ns51.ts\n', { status: 200 });
      }
      return new Response('#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:52\n#EXTINF:2,\ns52.ts\n#EXTINF:2,\ns53.ts\n#EXTINF:2,\ns54.ts\n', { status: 200 });
    }
    return new Response(validTsChunk(0), { status: 200 });
  });
  const ui = makeUi();
  const rec = new ctx.Recorder('a'.repeat(24), ui, {});
  rec.recording = true;
  rec.stopped = false;
  rec.state = 'RUN';

  // Part 1: segments 50..51
  await rec.pollPlaylist();
  await rec.drain();
  await rec.closePart();

  // Part 2: segments 52..54
  await rec.pollPlaylist();
  await rec.drain();
  await rec.closePart();

  assert.equal(rec.partsLog.length, 2);
  const p1 = rec.partsLog[0].partIntegrity;
  const p2 = rec.partsLog[1].partIntegrity;

  assert.ok(p1.partSequenceRange);
  assert.equal(p1.partSequenceRange.attribution, 'exact_pushData_part_binding');
  assert.equal(p1.partSequenceRange.segments, 2);
  assert.equal(p1.partSequenceRange.firstSequence, 50);
  assert.equal(p1.partSequenceRange.lastSequence, 51);
  assert.equal(p1.partSequenceRange.sequenceGaps, 0);

  assert.ok(p2.partSequenceRange);
  assert.equal(p2.partSequenceRange.attribution, 'exact_pushData_part_binding');
  assert.equal(p2.partSequenceRange.segments, 3);
  assert.equal(p2.partSequenceRange.firstSequence, 52);
  assert.equal(p2.partSequenceRange.lastSequence, 54);
  assert.equal(p2.partSequenceRange.sequenceGaps, 0);
});
