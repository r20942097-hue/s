'use strict';
const {test,before,after}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),vm=require('node:vm'),{spawnSync}=require('node:child_process');
const core=require('../src/mp4_convert_core.js'),hashing=require('../src/sha256.js');
const ctx=vm.createContext({console,Uint8Array,Uint32Array,DataView,ArrayBuffer});ctx.window=ctx;vm.runInContext(fs.readFileSync(path.join(__dirname,'../src/vendor/mux.min.js'),'utf8'),ctx);
let dir,raw,noAudio,audioPid;
function run(cmd,args){const r=spawnSync(cmd,args,{timeout:60000,maxBuffer:16*1048576});a.equal(r.status,0,r.stderr?.toString());return r.stdout;}
function pid(p){return ((p[1]&31)<<8)|p[2];}
function packets(data){return Array.from({length:data.length/188},(_,i)=>data.subarray(i*188,i*188+188));}
function adts(size=24){const b=Buffer.alloc(size,0x35);b.set([255,241,76,128|((size>>11)&3),(size>>3)&255,((size&7)<<5)|31,252]);return b;}
function pes(body,opts={}){const h=Buffer.from([0,0,1,0xc0,0,0,0x80,0x80,5,0x21,0,1,0,1]);h.writeUInt16BE(body.length+8,4);if(opts.mutate)opts.mutate(h);return Buffer.concat([h,body]);}
function packetize(data,pidValue=audioPid,{firstBytes=184,start=true}={}){
 const out=[];let pos=0,cc=0;
 while(pos<data.length){const n=Math.min(pos===0?firstBytes:184,data.length-pos),p=Buffer.alloc(188,0xff);p[0]=0x47;p[1]=((pidValue>>8)&31)|((pos===0&&start)?0x40:0);p[2]=pidValue&255;
  let at=4;if(n<184){p[3]=0x30|(cc++&15);p[4]=183-n;if(p[4])p[5]=0;at=188-n;}else p[3]=0x10|(cc++&15);
  data.copy(p,at,pos,pos+n);pos+=n;out.push(p);
 }return out;
}
function sample(body,opts={}){return Buffer.concat([noAudio,...packetize(pes(body,opts),audioPid,opts)]);}
function strict(data){return core.tsPlan(data,{media:true});}
function output(){let opens=0;return {handle:{isSameEntry:async()=>false,createWritable:async()=>{opens++;throw Error('MUST_NOT_OPEN');}},get opens(){return opens;}};}
before(()=>{dir=fs.mkdtempSync(path.join(os.tmpdir(),'rsp-v218-integrity-'));const file=path.join(dir,'source.ts');run('ffmpeg',['-v','error','-f','lavfi','-i','testsrc2=s=160x90:r=25:d=4','-f','lavfi','-i','sine=sample_rate=48000:duration=4','-c:v','libx264','-preset','ultrafast','-g','25','-c:a','aac','-f','mpegts',file]);raw=fs.readFileSync(file);audioPid=JSON.parse(core.tsPlan(raw).signature).find(x=>x[0]===15)[1];noAudio=Buffer.concat(packets(raw).filter(p=>pid(p)!==audioPid));});
after(()=>fs.rmSync(dir,{recursive:true,force:true}));
test('strict preflight counts real AAC frames and byte lengths independently of mux.js',()=>{const plan=strict(raw),audio=run('ffmpeg',['-v','error','-i',path.join(dir,'source.ts'),'-map','0:a:0','-c','copy','-f','adts','-']);let at=0,count=0;while(at<audio.length){at+=((audio[at+3]&3)<<11)|(audio[at+4]<<3)|(audio[at+5]>>5);count++;}a.equal(at,audio.length);a.equal(plan.mediaIntegrityEvidence.aacFrames,count);a.equal(plan.mediaIntegrityEvidence.aacPayloadBytes,audio.length);a.equal(plan.mediaIntegrityEvidence.h264Decoded,false);});
test('PES header and ADTS header can span arbitrary TS packet boundaries',()=>{const p=strict(sample(adts(500),{firstBytes:3}));a.equal(p.mediaIntegrityEvidence.aacFrames,1);a.equal(p.mediaIntegrityEvidence.aacPayloadBytes,500);});
test('CRC-bearing ADTS frames have a nine-byte header and bounded framing',()=>{const frame=adts(30);frame[1]&=~1;a.equal(strict(sample(frame)).mediaIntegrityEvidence.aacFrames,1);});
test('wrong PES prefix is rejected',()=>{a.throws(()=>strict(sample(adts(),{mutate:h=>h[2]=2})),/TS_PES_PREFIX/);});
test('audio PES with no declared packet length is rejected',()=>{a.throws(()=>strict(sample(adts(),{mutate:h=>{h[4]=0;h[5]=0;}})),/TS_AUDIO_PES_LENGTH/);});
test('truncated final PES is rejected although all TS packets are aligned',()=>{const ps=packets(raw),last=ps.findLastIndex(p=>pid(p)===audioPid),bad=Buffer.concat(ps.filter((_,i)=>i!==last));a.equal(bad.length%188,0);a.doesNotThrow(()=>core.tsPlan(bad));a.throws(()=>strict(bad),/TS_PES_TRUNCATED/);});
test('declared PES length shorter than payload is rejected',()=>{a.throws(()=>strict(sample(adts(),{mutate:h=>h.writeUInt16BE(10,4)})),/TS_PES_LENGTH_OVERFLOW/);});
test('truncated PES optional header is rejected at EOF',()=>{const h=pes(adts());const data=Buffer.concat([noAudio,...packetize(h.subarray(0,11))]);a.throws(()=>strict(data),/TS_PES_HEADER_TRUNCATED/);});
test('invalid PTS marker bits and timestamp flags are rejected',()=>{for(const mutate of [h=>h[9]&=~1,h=>h[7]=0x40,h=>h[8]=0])a.throws(()=>strict(sample(adts(),{mutate})),/TS_PES_TIMESTAMP|TS_PES_HEADER_LENGTH/);});
test('AAC sync loss does not trigger silent resynchronization',()=>{const b=adts();b[0]=0; a.throws(()=>strict(sample(b)),/TS_AAC_SYNC/);});
test('ADTS payload ending before its declared frame length is rejected',()=>{const b=adts(100).subarray(0,50);a.throws(()=>strict(sample(b)),/TS_AAC_TRUNCATED/);});
test('AAC sampling configuration changes are rejected',()=>{const x=adts(),y=adts();y[2]^=4;a.throws(()=>strict(sample(Buffer.concat([x,y]))),/TS_AAC_CONFIG_CHANGE/);});
test('AAC invalid sample rate, multiblock and short-frame declarations are rejected',()=>{for(const [mutate,error] of [[b=>b[2]=(b[2]&0xc3)|60,/TS_AAC_CONFIG_UNSUPPORTED/],[b=>b[6]|=1,/TS_AAC_MULTIBLOCK_UNSUPPORTED/],[b=>{b[3]&=0xfc;b[4]=0;b[5]=(b[5]&31)|0xe0;},/TS_AAC_FRAME_LENGTH/]]){const b=adts();mutate(b);a.throws(()=>strict(sample(b)),error);}});
test('continuation payload without a PES start is rejected',()=>{const data=Buffer.concat([noAudio,...packetize(pes(adts()),audioPid,{start:false})]);a.throws(()=>strict(data),/TS_PES_START_REQUIRED/);});
test('AAC split across PES is explicitly unsupported, even when both PES lengths are valid',()=>{const frame=adts(500),one=packetize(pes(frame.subarray(0,200))),two=packetize(pes(frame.subarray(200)));let cc=one.length&15;for(const p of two)p[3]=(p[3]&0xf0)|(cc++&15);a.throws(()=>strict(Buffer.concat([noAudio,...one,...two])),/TS_AAC_PES_BOUNDARY_UNSUPPORTED/);});
test('malformed PES fails both conversion APIs before opening the output',async()=>{const broken=sample(adts(),{mutate:h=>h[2]=0});for(const fn of [core.convert,core.convertStreamed]){const d=output();await a.rejects(()=>fn({inputs:[{getFile:async()=>new Blob([broken])}],destination:d.handle,muxjs:ctx.muxjs,hashing}),/TS_PES_PREFIX/);a.equal(d.opens,0);}});
function videoSample(body){const videoPid=JSON.parse(core.tsPlan(raw).signature).find(x=>x[0]===27)[1],filtered=Buffer.concat(packets(raw).filter(p=>pid(p)!==videoPid)),bytes=pes(body);bytes[3]=0xe0;return Buffer.concat([filtered,...packetize(bytes,videoPid)]);}
test('Annex-B NAL headers are inspected without claiming decoded H264',()=>{const p=strict(videoSample(Buffer.from([0,0,0,1,9,0xf0])));a.equal(p.mediaIntegrityEvidence.nalUnits,1);a.equal(p.mediaIntegrityEvidence.h264Decoded,false);});
test('forbidden NAL bit and reserved NAL type are rejected',()=>{for(const h of [0x89,0,31])a.throws(()=>strict(videoSample(Buffer.from([0,0,1,h,0xf0]))),/TS_H264_NAL_HEADER/);});
test('a start code with no NAL header is rejected at the end',()=>{a.throws(()=>strict(videoSample(Buffer.from([0,0,1]))),/TS_H264_HEADER_TRUNCATED/);});
test('empty NAL payload and missing Annex-B framing are rejected',()=>{a.throws(()=>strict(videoSample(Buffer.from([0,0,1,9]))),/TS_H264_NAL_EMPTY/);a.throws(()=>strict(videoSample(Buffer.from([0x10,0x20,0x30]))),/TS_H264_ANNEXB_REQUIRED/);});
function memorySink(){let stored=new Blob(['previous']),parts=[],aborts=0,closes=0;return {handle:{isSameEntry:async()=>false,getFile:async()=>stored,createWritable:async()=>({write:async b=>parts.push(new Uint8Array(b)),close:async()=>{closes++;stored=new Blob(parts);},abort:async()=>{aborts++;parts=[];}})},get aborts(){return aborts;},get closes(){return closes;},get stored(){return stored;}};}
function boxList(data,start=0,end=data.length){const out=[];for(let at=start;at<end;){const size=new DataView(data.buffer,data.byteOffset+at,4).getUint32(0);out.push({type:String.fromCharCode(...data.subarray(at+4,at+8)),start:at+8,end:at+size});at+=size;}return out;}
test('both APIs report exact input AAC versus emitted MP4 audio sample conservation',async()=>{for(const fn of [core.convert,core.convertStreamed]){const d=memorySink(),r=await fn({inputs:[{getFile:async()=>new Blob([raw])}],destination:d.handle,muxjs:ctx.muxjs,hashing});const e=r.mediaIntegrityEvidence;a.ok(e.aacFrames>0);a.equal(e.aacFrames,e.outputAacSamples);a.equal(e.aacFrameCountConserved,true);a.equal(e.h264Decoded,false);a.equal(e.aacCrcVerified,false);}});
test('missing MP4 audio sample is detected before commit in both APIs',async()=>{
 class DamagedMux {
  constructor(opts){this.inner=new ctx.muxjs.mp4.Transmuxer(opts);this.changed=false;}
  on(event,callback){this.inner.on(event,event==='data'?segment=>{const data=new Uint8Array(segment.data),view=new DataView(data.buffer);if(!this.changed)for(const moof of boxList(data).filter(b=>b.type==='moof'))for(const traf of boxList(data,moof.start,moof.end).filter(b=>b.type==='traf')){const kids=boxList(data,traf.start,traf.end),tfhd=kids.find(b=>b.type==='tfhd');if(view.getUint32(tfhd.start+4)!==audioPid)continue;const trun=kids.find(b=>b.type==='trun'),n=view.getUint32(trun.start+4);if(n){view.setUint32(trun.start+4,n-1);this.changed=true;}}callback({...segment,data});}:callback);}
  push(data){this.inner.push(data);}flush(){this.inner.flush();}dispose(){this.inner.dispose();}
 }
 for(const fn of [core.convert,core.convertStreamed]){const d=memorySink();await a.rejects(()=>fn({inputs:[{getFile:async()=>new Blob([raw])}],destination:d.handle,muxjs:{mp4:{Transmuxer:DamagedMux}},hashing}),/MP4_SAMPLE_TABLE|MP4_AAC_FRAME_COUNT_MISMATCH/);a.equal(d.aborts,1);a.equal(d.closes,0);a.equal(await d.stored.text(),'previous');}
});

test('CRC-bearing ADTS source digest skips both CRC bytes',()=>{const frame=adts(30);frame[1]&=~1;const prefix=Buffer.alloc(4);prefix.writeUInt32BE(21);const expected=require('node:crypto').createHash('sha256').update(prefix).update(frame.subarray(9)).digest('hex');a.equal(core.tsPlan(sample(frame),{media:true,hashing}).mediaIntegrityEvidence.aacSampleSha256,expected);});
