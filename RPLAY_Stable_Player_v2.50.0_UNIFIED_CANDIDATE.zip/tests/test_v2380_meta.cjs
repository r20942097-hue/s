const {test}=require('node:test'),a=require('node:assert/strict'),R=require('../src/creator_registry.js'),id='a'.repeat(24),other='b'.repeat(24);
const URL_OK='https://rplay.live/c/canonical';

/* ---- metaEntry: getuser応答からの名前/正規URL抽出 ---- */
test('v2.42.0 metaEntry picks name with priority and canonical customUrl',()=>{
  a.deepEqual(R.metaEntry('slug',{_id:id,name:'太郎'}),{name:'太郎',url:'https://rplay.live/c/slug'});
  a.deepEqual(R.metaEntry('slug',{_id:id,nickname:'花子',customUrl:'canonical'}),{name:'花子',url:URL_OK});
  a.deepEqual(R.metaEntry('slug',{_id:id,userName:'  Yuki   Tarou '}),{name:'Yuki Tarou',url:'https://rplay.live/c/slug'});
  a.deepEqual(R.metaEntry('slug',{_id:id,name:'x'.repeat(150)}).name.length,100);
});
test('v2.42.0 metaEntry rejects hostile shapes and bounds url length',()=>{
  a.equal(R.metaEntry('',{_id:id}),null);
  a.equal(R.metaEntry('a/b',{_id:id}),null);
  a.equal(R.metaEntry('ok','string'),null);
  a.equal(R.metaEntry('ok',null),null);
  a.equal(R.metaEntry('ok',[]),null);
  /* customUrlが不正な文字を含むときは入力slugへフォールバック(無効で終わりにはしない) */
  a.deepEqual(R.metaEntry('ok',{_id:id,customUrl:'x/y'}),{name:'',url:'https://rplay.live/c/ok'});
  a.equal(R.metaEntry('あ'.repeat(40),{_id:id,customUrl:'い'.repeat(40)}),null); /* 多byte slugでurl>340 */
});

/* ---- resolveList onMeta: 名前URL解決分だけ収集 ---- */
test('v2.42.0 resolveList onMeta collects only slug-resolved entries before returning',async()=>{
  let got=null;const calls=[];
  const ids=await R.resolveList(`https://rplay.live/c/one ${other}`,async slug=>{calls.push(slug);return {_id:id.toUpperCase(),name:'一号',customUrl:'one'};},{onMeta:m=>{got=m;}});
  a.deepEqual(ids,[id,other]);
  a.deepEqual(calls,['one']);
  a.deepEqual(got,{[id]:{name:'一号',url:'https://rplay.live/c/one'}});
});
test('v2.42.0 onMeta stays uncalled when the batch is rejected mid-way',async()=>{
  let called=false;
  await a.rejects(R.resolveList(`${other} https://rplay.live/c/missing`,async()=>({_id:'invalid'}),{onMeta:()=>{called=true;}}),/一覧は変更/);
  a.equal(called,false);
});
test('v2.42.0 duplicate slugs collapse to one meta entry keyed by resolved id',async()=>{
  let got=null;
  await R.resolveList('https://rplay.live/c/a https://rplay.live/c/a',async()=>({_id:id,name:'同一名'}),{onMeta:m=>{got=m;}});
  a.deepEqual(Object.keys(got),[id]);
});

/* ---- sanitizeMeta: 保存済み/入力の厳格検証(派生データ・スキップ許容) ---- */
test('v2.42.0 sanitizeMeta keeps valid entries and drops malformed ones without throwing',()=>{
  const at=Date.now();
  a.deepEqual(R.sanitizeMeta({[id]:{name:'x',url:URL_OK,at}}),{[id]:{name:'x',url:URL_OK,at}});
  a.deepEqual(R.sanitizeMeta({[id]:{name:'  x  y ',url:URL_OK}}),{[id]:{name:'x y',url:URL_OK,at:0}});
  a.deepEqual(R.sanitizeMeta({[id]:{name:'n'}}),{[id]:{name:'n',url:'',at:0}});       /* URL無しは名前だけ許容 */
  a.deepEqual(R.sanitizeMeta({[id]:{url:URL_OK}}),{[id]:{name:'',url:URL_OK,at:0}});  /* 名前無しはURLだけ許容 */
  a.deepEqual(R.sanitizeMeta({'NOTHEX!':{name:'x',url:URL_OK}}),{});                   /* 不正key */
  a.deepEqual(R.sanitizeMeta({[id]:null,[other]:'str'}),{});                           /* 不正entry */
  a.deepEqual(R.sanitizeMeta({[id]:{name:'x',url:'https://evil/c/a'}}),{[id]:{name:'x',url:'',at:0}});    /* 不正URLは除去・名前は存続 */
  a.deepEqual(R.sanitizeMeta({[id]:{name:'x',url:'https://rplay.live/profile/'+id}}),{[id]:{name:'x',url:'',at:0}}); /* /c/以外はURL失効 */
  a.deepEqual(R.sanitizeMeta(null),{});a.deepEqual(R.sanitizeMeta([1]),{});a.deepEqual(R.sanitizeMeta('x'),{});
});
test('v2.42.0 sanitizeMeta bounds stored volume and timestamp sanity',()=>{
  const big={};for(let i=0;i<101;i++)big['c'+String(i).padStart(23,'0')]={name:'x',url:URL_OK};
  a.deepEqual(R.sanitizeMeta(big),{});
  const future={};future[id]={name:'x',url:URL_OK,at:Date.now()+946684800001};
  a.equal(future[id].at&&R.sanitizeMeta(future)[id].at,0);
});

/* ---- commit: metaUpdate付きの原子保存(1回のsetで両key) ---- */
function store(ids=[],meta=undefined){let v={ids,meta,writes:[]};return{storage:{get:async k=>({rsp_registered_creators:v.ids,rsp_creator_meta:v.meta}),set:async x=>{v.writes.push(x);v.ids=x.rsp_registered_creators;v.meta=x.rsp_creator_meta;}},locks:{request:(name,fn)=>fn()},state:()=>v};}
test('v2.42.0 commit stores ids and meta in one set call with fresh timestamps',async()=>{
  const h=store();
  await R.commit([id],'[]',h.storage,h.locks,{[id]:{name:'太郎',url:URL_OK}});
  const v=h.state();
  a.equal(v.writes.length,1);
  a.deepEqual(v.writes[0].rsp_registered_creators,[id]);
  a.equal(v.writes[0].rsp_creator_meta[id].name,'太郎');
  a.equal(v.writes[0].rsp_creator_meta[id].url,URL_OK);
  a.ok(Number.isInteger(v.writes[0].rsp_creator_meta[id].at)&&v.writes[0].rsp_creator_meta[id].at>0);
});
test('v2.42.0 commit merges over stored meta and prunes removed creators',async()=>{
  const at0=1234567890123;
  const h=store([id,other],{[id]:{name:'旧名',url:URL_OK,at:at0},[other]:{name:'残る',url:'https://rplay.live/c/other',at:at0}});
  await R.commit([other],JSON.stringify([id,other]),h.storage,h.locks,{[id]:{name:'新名',url:URL_OK}});
  const meta=h.state().meta;
  a.deepEqual(Object.keys(meta).sort(),[other]); /* 削除されたidのmetaは刈り取り */
  a.equal(meta[other].at,at0);                   /* 残存entryのatは保存済み値を保持 */
});
test('v2.42.0 malformed stored meta never blocks the id-list save',async()=>{
  const h=store([id],'broken-metadata-object');
  const baseline=JSON.stringify([id]);
  await R.commit([id],baseline,h.storage,h.locks,{[id]:{name:'太郎',url:URL_OK}});
  a.deepEqual(h.state().ids,[id]);
  a.equal(h.state().meta[id].name,'太郎');
});
test('v2.42.0 commit without metaUpdate still prunes meta to the saved list',async()=>{
  const h=store([id],{[id]:{name:'太郎',url:URL_OK,at:1},[other]:{name:'他人',url:URL_OK,at:1}});
  await R.commit([id],JSON.stringify([id]),h.storage,h.locks);
  a.deepEqual(Object.keys(h.state().meta),[id]);
  a.equal(h.state().writes.length,1);
});
test('v2.42.0 conflicting baseline still refuses before any write (meta path unchanged)',async()=>{
  const h=store([id],{[id]:{name:'太郎',url:URL_OK,at:1}});
  await a.rejects(R.commit([other],'[]',h.storage,h.locks,{[other]:{name:'x',url:URL_OK}}),/別の画面/);
  a.equal(h.state().writes.length,0);
  a.deepEqual(h.state().ids,[id]);
});
