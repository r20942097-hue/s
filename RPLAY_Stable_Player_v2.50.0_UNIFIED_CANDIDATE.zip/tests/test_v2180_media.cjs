'use strict';
const {test,before,after}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),vm=require('node:vm'),{spawnSync}=require('node:child_process');
const core=require('../src/mp4_convert_core.js'),hashing=require('../src/sha256.js');
const c=vm.createContext({console,Uint8Array,Uint32Array,DataView,ArrayBuffer});c.window=c;vm.runInContext(fs.readFileSync(path.join(__dirname,'../src/vendor/mux.min.js'),'utf8'),c);
let dir;before(()=>dir=fs.mkdtempSync(path.join(os.tmpdir(),'rsp-v218-media-')));after(()=>fs.rmSync(dir,{recursive:true,force:true}));
function run(cmd,args){const p=spawnSync(cmd,args,{timeout:90000,maxBuffer:32*1048576});a.equal(p.status,0,p.stderr?.toString());return p.stdout;}
function fileView(name,stats){return {size:fs.statSync(name).size,slice(start,end){stats.reads++;stats.maxSlice=Math.max(stats.maxSlice,end-start);return {arrayBuffer:async()=>{const fd=fs.openSync(name,'r');try{const b=Buffer.alloc(end-start),n=fs.readSync(fd,b,0,b.length,start);return b.buffer.slice(b.byteOffset,b.byteOffset+n);}finally{fs.closeSync(fd);}}};},arrayBuffer(){throw Error('FULL_READ_FORBIDDEN');}};}
function sourceHandle(name,stats){return {name:path.basename(name),getFile:async()=>fileView(name,stats)};}
function target(name,stats){let fd=null;const tmp=name+'.pending',h={isSameEntry:async b=>h===b,getFile:async()=>fileView(name,stats),createWritable:async()=>{fd=fs.openSync(tmp,'w');return {write:async data=>{let offset=0;while(offset<data.length)offset+=fs.writeSync(fd,data,offset,data.length-offset);},close:async()=>{fs.closeSync(fd);fd=null;fs.renameSync(tmp,name);},abort:async()=>{if(fd!==null)fs.closeSync(fd);fd=null;fs.rmSync(tmp,{force:true});}};}};return h;}
function frames(name){return run('ffmpeg',['-v','error','-i',name,'-map','0:v:0','-vsync','0','-f','framemd5','-']).toString().split('\n').filter(x=>x&&!x.startsWith('#')).map(x=>x.split(',').at(-1).trim());}
function adts(name){return run('ffmpeg',['-v','error','-i',name,'-map','0:a:0','-c','copy','-f','adts','-']);}
async function scenario({name,duration,sampleRate,channels,cbr=false}){
 const src=path.join(dir,name+'.ts'),out=path.join(dir,name+'.mp4'),stats={reads:0,maxSlice:0};
 const args=['-v','error','-f','lavfi','-i',`testsrc2=s=320x180:r=25:d=${duration}`,'-f','lavfi','-i',`sine=sample_rate=${sampleRate}:duration=${duration}`,'-c:v','libx264','-preset',cbr?'ultrafast':'medium','-g','25','-c:a','aac','-ac',String(channels)];
 if(cbr)args.push('-b:v','12M','-minrate','12M','-maxrate','12M','-bufsize','24M','-x264-params','nal-hrd=cbr:force-cfr=1');
 run('ffmpeg',[...args,'-f','mpegts',src]);
 const result=await core.convertStreamed({inputs:[sourceHandle(src,stats)],destination:target(out,stats),muxjs:c.muxjs,hashing,sliceBytes:1048576,chunkTargetBytes:512*1024});
 a.equal(result.confirmed,true);a.equal(result.mediaIntegrityEvidence.aacPayloadHashVerified,true);a.equal(result.mp4IntegrityEvidence.sampleTablesAndRangesVerified,true);a.ok(result.mediaIntegrityEvidence.aacFrames>0);a.equal(result.mediaIntegrityEvidence.aacPayloadBytes,adts(src).length);a.deepEqual(adts(out),adts(src));a.deepEqual(frames(out),frames(src));a.ok(stats.maxSlice<=1048576);
 run('ffmpeg',['-v','error','-xerror','-i',out,'-f','null','-']);
 const meta=JSON.parse(run('ffprobe',['-v','error','-show_entries','format=duration,start_time:stream=codec_type,sample_rate,channels,start_time','-of','json',out]));a.ok(+meta.format.start_time>=-0.001&&+meta.format.start_time<0.15,JSON.stringify(meta.format));a.ok(Math.abs(+meta.format.duration-duration)<0.25);const audio=meta.streams.find(s=>s.sample_rate);a.equal(+audio.sample_rate,sampleRate);a.equal(audio.channels,channels);
 if(cbr){a.ok(fs.statSync(src).size>64*1048576,'must exercise a true encoded-media input beyond 64MiB');a.ok(result.chunksProcessed>=40);}
 const srcMeta=JSON.parse(run('ffprobe',['-v','error','-show_entries','stream=codec_type,start_time','-of','json',src]));
 const starts=m=>Object.fromEntries(m.streams.map(s=>[s.codec_type,+s.start_time]));
 const srcStarts=starts(srcMeta),outStarts=starts(meta),relativeStartDrift=(outStarts.audio-outStarts.video)-(srcStarts.audio-srcStarts.video);
 a.ok(Math.abs(relativeStartDrift)<2/sampleRate,'common origin must retain the input AV start relationship, including B-frame decode delay');
 return {sourceBytes:fs.statSync(src).size,outputBytes:result.bytes,chunks:result.chunksProcessed,aacFrames:result.mediaIntegrityEvidence.aacFrames,nalUnits:result.mediaIntegrityEvidence.nalUnits,sampleRate,channels,duration,startTime:+meta.format.start_time,relativeStartDrift,maxReadBytes:stats.maxSlice,aacPayloadHashVerified:result.mediaIntegrityEvidence.aacPayloadHashVerified,audioClockAdjustments:result.mp4IntegrityEvidence.audioClockAdjustments,maxAudioClockAdjustmentTicks:result.mp4IntegrityEvidence.maxAudioClockAdjustmentTicks};
}
test('120-second 44.1kHz stereo media retains all AAC frames and decoded video',async t=>{t.diagnostic(JSON.stringify(await scenario({name:'long44100',duration:120,sampleRate:44100,channels:2})));});
test('120-second 48kHz mono media retains all AAC frames and decoded video',async t=>{t.diagnostic(JSON.stringify(await scenario({name:'long48000',duration:120,sampleRate:48000,channels:1})));});
test('50-second 12Mbps encoded media exceeds 64MiB and streams through real disk files',async t=>{t.diagnostic(JSON.stringify(await scenario({name:'highbitrate',duration:50,sampleRate:48000,channels:2,cbr:true})));});
