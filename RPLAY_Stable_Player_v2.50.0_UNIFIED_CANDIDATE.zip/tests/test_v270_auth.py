"""v2.7.0 auth acceptance: AuthStore secret supply (value/env/file), refresh-token
loop (leeway pre-refresh, bounded retries, response-key shape evidence), 401
classification with --token priority and automatic fallback, authEvidence block
(no secret values ever), requestor params, and the synthetic refresh-token E2E
through the real CLI (local HTTP only — VM-safe, no real network)."""
import http.server,threading,tempfile,pathlib,subprocess,sys,json,os,unittest,time
import unittest.mock
import base64
import importlib.util
R=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('v270auth',R/'rplay_dl.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def make_jwt(oid=None,exp=None):
    def b64(d):
        return base64.urlsafe_b64encode(json.dumps(d).encode()).decode().rstrip('=')
    payload={}
    if oid is not None:payload['oid']=oid
    if exp is not None:payload['exp']=exp
    return b64({'alg':'none'})+'.'+b64(payload)+'.sig'
OID='b'*24


def fake_http(responses):
    """Injection http fn → (fn, calls). responses: list of (status, body_bytes)."""
    calls=[]
    def fn(url,timeout,headers,method='GET',data=None):
        calls.append({'url':url,'timeout':timeout,'headers':dict(headers or {}),
                      'method':method,'data':data})
        st,body=(responses.pop(0) if responses else (200,b'{}'))
        return st,body,0
    return fn,calls


def store(token='',refresh='',user_oid='',responses=None,sleep=None,api='https://api.invalid'):
    fn,calls=fake_http(responses or [])
    a=m.AuthStore(api,http_fn=fn,log_fn=lambda msg:None,token=token,
                  refresh_spec=refresh,user_oid=user_oid)
    if sleep is not None:a._sleep=sleep
    return a,calls


class UnitV270Auth(unittest.TestCase):
    def test_parse_secret_spec_supply_kinds(self):
        self.assertEqual(m.parse_secret_spec(''),('',''))
        self.assertEqual(m.parse_secret_spec('  '),('',''))
        self.assertEqual(m.parse_secret_spec('PLAINSECRET'),('PLAINSECRET','value'))
        with unittest.mock.patch.dict(os.environ,{'RSP_RT':'ENVSECRET'}):
            self.assertEqual(m.parse_secret_spec('env:RSP_RT'),('ENVSECRET','env'))
        self.assertEqual(m.parse_secret_spec('env:RSP_MISSING_X'),('','env'))
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'rt.txt';p.write_text('FILESECRET\n')
            self.assertEqual(m.parse_secret_spec('file:'+str(p)),('FILESECRET','file'))
            self.assertEqual(m.parse_secret_spec('file:'+str(pathlib.Path(d)/'none.txt')),('','file'))
    def test_auth_store_modes(self):
        self.assertEqual(store(token='t')[0].mode,'static-token')
        self.assertEqual(store(refresh='r')[0].mode,'refresh-token')
        self.assertEqual(store(token='t',refresh='r')[0].mode,'token+refresh')
        self.assertEqual(store()[0].mode,'none')
    def test_static_token_never_refreshes_without_fallback(self):
        a,calls=store(token=make_jwt(OID,exp=time.time()+3600))
        self.assertEqual(a.ensure_jwt().count('.'),2)
        self.assertEqual(a.ensure_jwt().count('.'),2)
        self.assertEqual(calls,[])  # no HTTP at all while the static JWT is fresh
        self.assertEqual(a.note_401('live/key2'),'invalid_or_expired')
        self.assertEqual(a.evidence()['classifications401'],{'invalid_or_expired':1})
        self.assertEqual(calls,[])  # classification alone must not hit the network
    def test_refresh_loop_leeway_pre_refresh(self):
        jwt_soon=make_jwt(OID,exp=time.time()+100)   # valid now, inside the 300s leeway
        jwt_fresh=make_jwt(OID,exp=time.time()+3600)
        a,calls=store(refresh='RT',responses=[(200,json.dumps({'jwt':jwt_soon}).encode()),
                                              (200,json.dumps({'jwt':jwt_fresh}).encode())])
        self.assertEqual(a.ensure_jwt(),jwt_soon)   # initial fetch
        self.assertGreater(a._jwt_exp,0)            # exp claim parsed for the leeway check
        self.assertEqual(a.ensure_jwt(),jwt_fresh)  # pre-refreshed BEFORE expiry (leeway)
        self.assertEqual(len(calls),2)
        self.assertEqual(a.ensure_jwt(),jwt_fresh)   # fresh now → no further calls
        self.assertEqual(len(calls),2)
        ev=a.evidence()
        self.assertEqual(ev['mode'],'refresh-token')
        self.assertEqual(ev['refreshSource'],'value')
        self.assertEqual(ev['refreshAttempts'],2)
        self.assertEqual(ev['refreshSuccesses'],2)
        self.assertEqual(ev['refreshFailures'],0)
        self.assertEqual(ev['responseKey'],'jwt')       # shape evidence, not the secret
    def test_refresh_response_key_candidates(self):
        for key in ('jwt','token','accessToken','authorization'):
            jwt=make_jwt(OID,exp=time.time()+3600)
            a,_=store(refresh='RT',responses=[(200,json.dumps({key:jwt}).encode())])
            self.assertEqual(a.ensure_jwt(),jwt,key)
            self.assertEqual(a.evidence()['responseKey'],key)
        # non-string/empty candidates are not accepted
        a,_=store(refresh='RT',responses=[(200,b'{"jwt":""}')])
        self.assertEqual(a.ensure_jwt(),'')
        self.assertEqual(a.evidence()['responseKey'],None)
    def test_refresh_retries_then_succeeds(self):
        jwt=make_jwt(OID,exp=time.time()+3600)
        a,calls=store(refresh='RT',responses=[(500,b'{}'),(500,b'{}'),
                                              (200,json.dumps({'jwt':jwt}).encode())],sleep=lambda s:None)
        self.assertEqual(a.refresh_now(),True)
        self.assertEqual(len(calls),3)
        ev=a.evidence()
        self.assertEqual(ev['refreshAttempts'],3)
        self.assertEqual(ev['refreshSuccesses'],1)
        self.assertEqual(ev['refreshFailures'],2)
    def test_refresh_gives_up_after_max_attempts(self):
        a,calls=store(refresh='RT',responses=[(401,b'{}')]*6,sleep=lambda s:None)
        self.assertEqual(a.refresh_now(),False)
        self.assertEqual(len(calls),a.MAX_ATTEMPTS)    # bounded — no infinite loop
        self.assertEqual(a.note_401('live/key2'),'refresh_failed')
        self.assertEqual(len(calls),a.MAX_ATTEMPTS)    # cooldown suppresses re-hammering
        ev=a.evidence()
        self.assertEqual(ev['refreshAttempts'],3)
        self.assertEqual(ev['refreshSuccesses'],0)
        self.assertEqual(ev['refreshFailures'],3)
    def test_401_classification_matrix(self):
        # no credentials at all
        a,_=store();self.assertEqual(a.note_401('api'),'no_credentials')
        # static only → terminal invalid_or_expired
        a,_=store(token='t');self.assertEqual(a.note_401('api'),'invalid_or_expired')
        # token+refresh: 401 switches primary and refreshes → 'refreshed'
        jwt=make_jwt(OID,exp=time.time()+3600)
        a,calls=store(token='STALE',refresh='RT',
                      responses=[(200,json.dumps({'jwt':jwt}).encode())])
        self.assertEqual(a.note_401('api'),'refreshed')
        self.assertEqual(a.evidence()['switchedToRefresh'],True)
        self.assertEqual(a.ensure_jwt(),jwt)            # Authorization is now the refreshed JWT
        self.assertEqual(len(calls),1)
        # token+refresh with failing refresh → 'refresh_failed'
        a,_=store(token='STALE',refresh='RT',responses=[(500,b'{}')]*3,sleep=lambda s:None)
        self.assertEqual(a.note_401('api'),'refresh_failed')
        # refresh-mode with valid jwt: 401 → re-refresh → 'refreshed'
        jwt2=make_jwt(OID,exp=time.time()+3600)
        a,_=store(refresh='RT',responses=[(200,json.dumps({'jwt':jwt2}).encode()),
                                           (200,json.dumps({'jwt':jwt2}).encode())])
        a.ensure_jwt()
        self.assertEqual(a.note_401('api'),'refreshed')
        self.assertEqual(a.evidence()['switchedToRefresh'],False)  # was never on static primary
    def test_evidence_contains_no_secrets(self):
        secret_token=make_jwt(OID,exp=time.time()+3600)
        secret_refresh='REFRESHSECRETVALUE'
        a,_=store(token=secret_token,refresh=secret_refresh,
                  responses=[(200,json.dumps({'token':secret_token}).encode())])
        a.note_401('api')
        dump=json.dumps(a.evidence())
        self.assertNotIn(secret_refresh,dump)
        self.assertNotIn(secret_token,dump)
        self.assertNotIn('REFRESHSECRETVALUE',dump)
        ev=a.evidence()
        self.assertIn('mode',ev);self.assertIn('refreshSource',ev)
        self.assertIn('userOidSupplied',ev);self.assertIn('switchedToRefresh',ev)
        self.assertIn('refreshAttempts',ev);self.assertIn('refreshSuccesses',ev)
        self.assertIn('refreshFailures',ev);self.assertIn('responseKey',ev)
        self.assertIn('classifications401',ev);self.assertIn('key2Resolutions',ev)
        self.assertIn('butterSent',ev);self.assertIn('provenance',ev)
    def test_requestor_params(self):
        a,_=store();self.assertEqual(a.requestor_params(),{})
        a,_=store(user_oid=OID)
        self.assertEqual(a.requestor_params(),{'requestorOid':OID,'loginType':'rplay'})
        a,_=store(token=make_jwt(OID,exp=time.time()+3600))
        self.assertEqual(a.requestor_params(),{'requestorOid':OID,'loginType':'rplay'})
        a,_=store(token=make_jwt('short',exp=time.time()+3600))
        self.assertEqual(a.requestor_params(),{})  # non-24hex oid is not asserted
    def test_key2_resolution_counted(self):
        a,_=store(token='t')
        self.assertEqual(a.evidence()['key2Resolutions'],0)
        a.note_key2();a.note_key2()
        self.assertEqual(a.evidence()['key2Resolutions'],2)


class SyntheticServer:
    """Local HTTP server emulating the auth-dependent API shape (A-07 synthetic
    regression): POST /rplay/account/refresh-token + GET live/play + playlist."""
    def __init__(self,refresh_jwt,require_jwt=None,play_body=None):
        self.refresh_jwt=refresh_jwt
        self.require_jwt=require_jwt  # Authorization value required for live/play
        self.play_body=play_body if play_body is not None else {
            'streamState':'live','accessible':True,'allowAnonymous':True,'title':'テスト配信'}
        self.refresh_hits=[];self.play_hits=[];self.hook_hits=[]
        playlist=('#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:0\n'
                  '#EXTINF:1,\na.ts\n#EXT-X-ENDLIST\n')
        files={'a.ts':b'\x47'*(188*20)}
        outer=self
        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self,*a):pass
            def _send(s,code,body=b'',headers=None):
                s.send_response(code)
                for k,v in (headers or {}).items():s.send_header(k,v)
                s.send_header('Content-Length',str(len(body)));s.end_headers();s.wfile.write(body)
            def do_POST(s):
                ln=int(s.headers.get('Content-Length') or 0)
                s.rfile.read(ln)
                if s.path.split('?')[0].endswith('/rplay/account/refresh-token'):
                    outer.refresh_hits.append({'refreshToken':s.headers.get('Refresh-Token'),
                                               'authorization':s.headers.get('Authorization'),
                                               'contentType':s.headers.get('Content-Type')})
                    s._send(200,json.dumps({'jwt':outer.refresh_jwt}).encode(),
                            {'Content-Type':'application/json'})
                else:s._send(404)
            def do_GET(s):
                path=s.path.split('?')[0];q=s.path.split('?')[1] if '?' in s.path else ''
                if path.endswith('/rplay/account/refresh-token'):
                    s._send(200,json.dumps({'jwt':outer.refresh_jwt}).encode());return
                if path=='/api/live/play':
                    auth=s.headers.get('Authorization')
                    outer.play_hits.append({'authorization':auth,'query':q})
                    if outer.require_jwt is not None and auth!=outer.require_jwt:
                        s._send(401,b'{"message":"expired"}');return
                    s._send(200,json.dumps(outer.play_body).encode());return
                if path=='/api/live/key2':
                    s._send(200,b'{"authKey":"k2"}');return
                if path=='/live.m3u8':s._send(200,playlist.encode());return
                body=files.get(path.lstrip('/'))
                if body is not None:s._send(200,body)
                else:s._send(404)
            do_PUT=do_POST
        self.srv=http.server.ThreadingHTTPServer(('127.0.0.1',0),H)
        threading.Thread(target=self.srv.serve_forever,daemon=True).start()
        self.url='http://127.0.0.1:%d'%self.srv.server_port
    def close(self):self.srv.shutdown();self.srv.server_close()


def run_cli(url,out,*extra,timeout=60,env=None):
    cmd=[sys.executable,str(R/'rplay_dl.py'),'a'*24,'--api',url+'/api','--m3u8',url+'/live.m3u8',
         '--no-follow','--no-flv','--mux','no','--out',str(out),'--info-json']+list(extra)
    return subprocess.run(cmd,capture_output=True,text=True,timeout=timeout,env=env)


class E2EV270Auth(unittest.TestCase):
    def test_cli_refresh_token_flow(self):
        """refresh-token単独: 初回ensure_jwtで短命JWTを取得し、live/playはそのJWTと
        requestorOid付きで呼ばれる。authEvidenceに供給源・応答鍵・成功回数。"""
        jwt=make_jwt(OID,exp=time.time()+3600)
        srv=SyntheticServer(jwt)
        try:
            with tempfile.TemporaryDirectory() as d:
                p=run_cli(srv.url,pathlib.Path(d),'--refresh-token','RTVALUE','--user-oid',OID)
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                self.assertEqual(len(srv.refresh_hits),1)
                self.assertEqual(srv.refresh_hits[0]['refreshToken'],'RTVALUE')
                self.assertGreater(len(srv.play_hits),0)
                self.assertEqual(srv.play_hits[0]['authorization'],jwt)
                self.assertIn('requestorOid='+OID,srv.play_hits[0]['query'])
                info=json.loads(next(pathlib.Path(d).glob('*_info.json')).read_text())
                ev=info['authEvidence']
                self.assertEqual(ev['mode'],'refresh-token')
                self.assertEqual(ev['refreshSource'],'value')
                self.assertEqual(ev['responseKey'],'jwt')
                self.assertGreaterEqual(ev['refreshSuccesses'],1)
                self.assertEqual(ev['userOidSupplied'],True)
                self.assertEqual(ev['butterSent'],False)
                dump=json.dumps(info)
                self.assertNotIn('RTVALUE',dump);self.assertNotIn(jwt,dump)
                led=pathlib.Path(d)/('RPLAY_'+'a'*24+'_ledger.json')
                if led.exists():
                    self.assertEqual(json.loads(led.read_text())['authEvidence']['mode'],'refresh-token')
        finally:srv.close()
    def test_cli_token_priority_with_401_fallback(self):
        """--token(明示)が一次。live/playが401を返した時だけrefresh-tokenへ自動切替し
        1回再試行する(公式interceptorと同一戦略)。"""
        jwt=make_jwt(OID,exp=time.time()+3600)
        srv=SyntheticServer(jwt,require_jwt=jwt)
        try:
            with tempfile.TemporaryDirectory() as d:
                p=run_cli(srv.url,pathlib.Path(d),'--token','STALETOKEN','--refresh-token','RTVALUE')
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                auths=[h['authorization'] for h in srv.play_hits]
                self.assertIn('STALETOKEN',auths)                       # primary tried first
                self.assertEqual(auths[-1],jwt)                         # fallback won
                self.assertGreaterEqual(auths.count('STALETOKEN'),1)
                self.assertLessEqual(auths.count('STALETOKEN'),2)       # retried once, not hammered
                self.assertEqual(len(srv.refresh_hits),1)
                info=json.loads(next(pathlib.Path(d).glob('*_info.json')).read_text())
                ev=info['authEvidence']
                self.assertEqual(ev['mode'],'token+refresh')
                self.assertEqual(ev['switchedToRefresh'],True)
                self.assertGreaterEqual(ev['classifications401'].get('refreshed',0),1)
                self.assertNotIn('STALETOKEN',json.dumps(info))
                self.assertNotIn('RTVALUE',json.dumps(info))
        finally:srv.close()
    def test_cli_env_and_file_supply(self):
        """env:VAR と file:PATH の供給種別がauthEvidenceへ記録される(値は出ない)。"""
        jwt=make_jwt(OID,exp=time.time()+3600)
        srv=SyntheticServer(jwt)
        try:
            with tempfile.TemporaryDirectory() as d:
                env={**os.environ,'RSP_TEST_RT':'ENVSECRETVALUE'}
                p=run_cli(srv.url,pathlib.Path(d),'--refresh-token','env:RSP_TEST_RT',env=env)
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                info=json.loads(next(pathlib.Path(d).glob('*_info.json')).read_text())
                self.assertEqual(info['authEvidence']['refreshSource'],'env')
                self.assertNotIn('ENVSECRETVALUE',json.dumps(info))
            with tempfile.TemporaryDirectory() as d:
                rt=pathlib.Path(d)/'secret.txt'  # supply file lives outside the out dir
                rt.write_text('FILESECRETVALUE')
                out=pathlib.Path(d)/'rec';out.mkdir()
                p=run_cli(srv.url,out,'--refresh-token','file:'+str(rt))
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                info=json.loads(next(out.glob('*_info.json')).read_text())
                self.assertEqual(info['authEvidence']['refreshSource'],'file')
                self.assertNotIn('FILESECRETVALUE',json.dumps(info))
        finally:srv.close()
    def test_cli_auth_failed_event_when_no_valid_credentials(self):
        """資格が全て無効な場合: auth_failed webhook(level=error)と401分類が記録され、
        録画自体は公開playlistで継続できる(安全側・停止しない)。"""
        jwt=make_jwt(OID,exp=time.time()+3600)
        srv=SyntheticServer(jwt,require_jwt=jwt)
        hook=[]
        class HookH(http.server.BaseHTTPRequestHandler):
            def log_message(self,*a):pass
            def do_POST(s):
                ln=int(s.headers.get('Content-Length') or 0)
                hook.append(json.loads(s.rfile.read(ln).decode()))
                s.send_response(200);s.send_header('Content-Length','0');s.end_headers()
        hsrv=http.server.ThreadingHTTPServer(('127.0.0.1',0),HookH)
        threading.Thread(target=hsrv.serve_forever,daemon=True).start()
        try:
            with tempfile.TemporaryDirectory() as d:
                p=run_cli(srv.url,pathlib.Path(d),'--token','STALETOKEN',
                          '--webhook','http://127.0.0.1:%d/hook'%hsrv.server_port)
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                time.sleep(1.2)  # end event is sent from a non-daemon thread just before exit
                events=[h['event'] for h in hook]
                self.assertIn('start',events);self.assertIn('end',events)
                failed=[h for h in hook if h['event']=='auth_failed']
                self.assertGreaterEqual(len(failed),1)
                self.assertEqual(failed[0]['level'],'error')
                self.assertIn('classification',failed[0])
                info=json.loads(next(pathlib.Path(d).glob('*_info.json')).read_text())
                ev=info['authEvidence']
                self.assertGreaterEqual(ev['classifications401'].get('invalid_or_expired',0),1)
        finally:hsrv.shutdown();hsrv.server_close();srv.close()


if __name__=='__main__':unittest.main()
