"""v2.9.0 feature acceptance (A-09 subtitle support, phase 1: observation & evidence):
1. parse_subtitle_renditions: parse #EXT-X-MEDIA:TYPE=SUBTITLES from master
   playlists. URIs are NEVER output (hasUri only) — URL redaction contract.
   Unknown attributes (CHARACTERISTICS etc.) are never embedded (fixed key set).
2. parse_variants captures the SUBTITLES group attribute (subsGroup).
3. subtitle_evidence / subtitle_evidence_block: zero-fabrication evidence block —
   emitted only when master playlist text is a non-empty string; policy
   observed_not_fetched; subtitle playlists/segments are never fetched.
4. Cross-language mirror with JS (rspSubtitleEvidenceBlock).
5. E2E through the real rplay_dl.py: master playlist carrying SUBTITLES renditions
   must record subtitleEvidence and leave the recording path unaffected.
Local HTTP only — VM-safe."""
import http.server,threading,tempfile,pathlib,subprocess,sys,json,unittest
import importlib.util
R=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('v290feat',R/'rplay_dl.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

MASTER='\n'.join([
  '#EXTM3U',
  '#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID="subs",NAME="Japanese",LANGUAGE="ja",DEFAULT=YES,AUTOSELECT=YES,FORCED=NO,URI="subs_ja.m3u8?sig=SECRET"',
  '#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID="subs",NAME="English",LANGUAGE="en",CHARACTERISTICS="public.accessibility.transcribes-spoken-dialog"',
  '#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="aud",NAME="Audio",CHANNELS="2"',
  '#EXT-X-STREAM-INF:BANDWIDTH=2000000,RESOLUTION=1920x1080,SUBTITLES="subs",AUDIO="aud"',
  'v.m3u8',
])

class UnitV290Features(unittest.TestCase):
    def test_parse_subtitle_renditions_basic(self):
        r=m.parse_subtitle_renditions(MASTER)
        self.assertEqual(len(r),2)
        self.assertEqual(r[0],{'groupId':'subs','name':'Japanese','language':'ja',
                               'assocLanguage':'','default':True,'autoselect':True,
                               'forced':False,'hasUri':True})
        self.assertEqual(r[1]['name'],'English')
        self.assertEqual(r[1]['hasUri'],False)
        # URL秘匿契約: URI値は一切出力しない(署名クエリ混入防止)
        self.assertNotIn('subs_ja.m3u8',json.dumps(r))
        self.assertNotIn('SECRET',json.dumps(r))

    def test_parse_subtitle_renditions_edges(self):
        self.assertEqual(m.parse_subtitle_renditions(''),[])
        self.assertEqual(m.parse_subtitle_renditions('#EXTM3U\n#EXTINF:1,\na.ts\n'),[])
        # TYPE=AUDIO/CLOSED-CAPTIONSは対象外・小文字typeは受理(大文字化比較)
        lo='\n'.join(['#EXTM3U',
                      '#EXT-X-MEDIA:TYPE=audio,GROUP-ID="aud",NAME="A"',
                      '#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID="s2",NAME="Sub2",DEFAULT=yes',
                      '#EXT-X-MEDIA:TYPE=CLOSED-CAPTIONS,GROUP-ID="cc",NAME="CC"'])
        r=m.parse_subtitle_renditions(lo)
        self.assertEqual(len(r),1)
        self.assertEqual(r[0]['groupId'],'s2')
        self.assertEqual(r[0]['default'],True)
        # GROUP-ID必須(EXT-X-MEDIA仕様・audio解析と同一契約): 無い行は無視
        nogid='\n'.join(['#EXTM3U','#EXT-X-MEDIA:TYPE=SUBTITLES,NAME="X"'])
        self.assertEqual(m.parse_subtitle_renditions(nogid),[])

    def test_variants_subs_group_and_evidence_linkage(self):
        base='https://rplay.example/master.m3u8'
        vs=m.parse_variants(MASTER,base)
        self.assertEqual(len(vs),1)
        self.assertEqual(vs[0]['subsGroup'],'subs')
        self.assertEqual(vs[0]['audioGroup'],'aud')
        evd=m.subtitle_evidence(m.parse_subtitle_renditions(MASTER),vs)
        self.assertEqual(evd['renditionCount'],2)
        self.assertEqual(evd['variantsLinked'],1)
        self.assertEqual(evd['policy'],'observed_not_fetched')
        self.assertEqual(evd['provenance'],'master_playlist_ext_x_media')

    def test_subtitle_evidence_block_contract_and_secret_free(self):
        # 虚偽零回避: master playlist未取得(None/'')では証拠ブロックを出さない
        self.assertIsNone(m.subtitle_evidence_block(None,[]))
        self.assertIsNone(m.subtitle_evidence_block('',[]))
        blk=m.subtitle_evidence_block(MASTER,[{'subsGroup':'subs'}])
        self.assertIsNotNone(blk)
        self.assertEqual(set(blk),{'renditions','renditionCount','variantsLinked',
                                   'policy','provenance','note'})
        # 未知属性は埋め込まない(固定鍵集合のみ)
        self.assertEqual(set(blk['renditions'][0]),
                         {'groupId','name','language','assocLanguage',
                          'default','autoselect','forced','hasUri'})
        s=json.dumps(blk)
        self.assertNotIn('subs_ja.m3u8',s)
        self.assertNotIn('SECRET',s)
        self.assertNotIn('CHARACTERISTICS',s)

    def test_browser_subtitle_block_mirrors_python(self):
        """相互言語比較: subtitle_evidence_block と rspSubtitleEvidenceBlock が同一結果。"""
        vectors=[MASTER,'#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1\nv.m3u8','',None]
        js=("const fs=require('fs');let src=fs.readFileSync('rplay-stable-player.user.js','utf8');"
            "const s1=src.slice(src.indexOf('function parseM3u8Attrs'),src.indexOf('function parseVariants'));"
            "const s2=src.slice(src.indexOf('function parseSubtitleRenditions'),src.indexOf('function audioLabelFor'));"
            "const s3=src.slice(src.indexOf('function rspSubtitleEvidence('),src.indexOf('async function fetchJsonWithRetry'));"
            "const vm=require('vm');"
            "const c=vm.createContext({JSON,console,RECENV:{pageUrl:()=>'https://rplay.live/live/x'}});"
            "vm.runInContext([s1,s2,s3].join('\\n')+';globalThis._fns={blk:rspSubtitleEvidenceBlock};',c);"
            "let s='';process.stdin.on('data',x=>s+=x);process.stdin.on('end',()=>{"
            "const v=JSON.parse(s);"
            "process.stdout.write(JSON.stringify(v.map(x=>c._fns.blk(x,[{subsGroup:'subs'}]))));});")
        p=subprocess.run(['node','-e',js],input=json.dumps(vectors),text=True,capture_output=True,cwd=R)
        self.assertEqual(p.returncode,0,p.stderr)
        got=json.loads(p.stdout)
        want=[m.subtitle_evidence_block(v,[{'subsGroup':'subs'}]) for v in vectors]
        self.assertEqual(json.loads(json.dumps(got)),json.loads(json.dumps(want)))


class E2EV290Features(unittest.TestCase):
    def test_cli_master_with_subtitles_records_evidence_and_unaffected(self):
        """master playlistがSUBTITLESレンディションを含むとき、CLIは
        subtitleEvidenceを記録し、録画経路(映像セグメント取得・情報JSON)は
        不影響で完走する。字幕playlistへの取得要求は発生しない。"""
        master='\n'.join([
            '#EXTM3U',
            '#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID="subs",NAME="Japanese",LANGUAGE="ja",DEFAULT=YES,URI="subs_ja.m3u8?sig=SECRET"',
            '#EXT-X-STREAM-INF:BANDWIDTH=2000000,RESOLUTION=1920x1080,SUBTITLES="subs"',
            'variant.m3u8',
        ])
        playlist=('#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:0\n'
                  '#EXTINF:1,\na.ts\n#EXT-X-ENDLIST\n')
        seg=b'\x47'*(188*20)
        subs_hits=[]
        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self,*a):pass
            def _send(s,code,body=b''):
                s.send_response(code)
                s.send_header('Content-Length',str(len(body)));s.end_headers();s.wfile.write(body)
            def do_GET(s):
                path=s.path.split('?')[0]
                if path=='/api/live/play':
                    s._send(200,json.dumps({'streamState':'live','accessible':True,
                        'allowAnonymous':True,'title':'字幕観測配信',
                        'streamStartTime':'2026-10-26T10:00:00Z'}).encode());return
                if path=='/live.m3u8':
                    s._send(200,master.encode());return
                if path=='/variant.m3u8':
                    s._send(200,playlist.encode());return
                if path=='/a.ts':
                    s._send(200,seg);return
                if path.startswith('/subs_ja.m3u8'):
                    subs_hits.append(path);s._send(404,b'not fetched');return
                s._send(404)
        srv=http.server.ThreadingHTTPServer(('127.0.0.1',0),H)
        threading.Thread(target=srv.serve_forever,daemon=True).start()
        url='http://127.0.0.1:%d'%srv.server_port
        try:
            with tempfile.TemporaryDirectory() as d:
                cmd=[sys.executable,str(R/'rplay_dl.py'),'a'*24,'--api',url+'/api',
                     '--m3u8',url+'/live.m3u8','--no-follow','--no-flv','--mux','no',
                     '--out',d,'--info-json']
                p=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                # 字幕playlistは取得されない(観測のみ契約)
                self.assertEqual(subs_hits,[],'subtitle playlist must never be fetched')
                info=json.loads(next(pathlib.Path(d).glob('*_info.json')).read_text())
                evd=info.get('subtitleEvidence')
                self.assertIsInstance(evd,dict)
                self.assertEqual(evd['renditionCount'],1)
                self.assertEqual(evd['variantsLinked'],1)
                self.assertEqual(evd['policy'],'observed_not_fetched')
                self.assertEqual(evd['renditions'][0]['hasUri'],True)
                self.assertNotIn('SECRET',json.dumps(evd))
                # 録画経路は影響を受けない(セグメント取得・ledger成立)
                self.assertEqual(info.get('segments',0)>=1,True,info.get('segments'))
        finally:
            srv.shutdown();srv.server_close()


if __name__=='__main__':unittest.main()
