'use strict';
const {test}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),{webcrypto}=require('node:crypto');
const recovery=require('../src/recovery_core.js');
function sink(root,options={}){const c=vm.createContext({Blob,Date,Map,Set,Promise,crypto:webcrypto,RECENV:{}});vm.runInContext(fs.readFileSync(require('path').join(__dirname,'../src/part_io.js'),'utf8').replace('  /* RSP_SHA256_MODULE */',fs.readFileSync(require('path').join(__dirname,'../src/sha256.js'),'utf8'))+';globalThis.Sink=RecPartSink',c);return new c.Sink('capture.ts',root,'ts',options);}
function disk(){
 const files=new Map(),dirs=new Set(['root']);const state={files,dirs,fault:null,maxWrite:0,aborts:0};
 function fail(p,op){if(state.fault&&state.fault(p,op))throw Error('INJECTED_DISK_FAILURE');}
 function file(p){return {kind:'file',name:p.split('/').pop(),isSameEntry:async h=>h.path===p,path:p,getFile:async()=>{fail(p,'read');return files.get(p);},createWritable:async()=>{fail(p,'open');let data=[],closed=false;return {write:async b=>{fail(p,'write');if(closed)throw Error('CLOSED');const blob=new Blob([b]);state.maxWrite=Math.max(state.maxWrite,blob.size);data.push(blob);},close:async()=>{fail(p,'close');files.set(p,new Blob(data));closed=true;},abort:async()=>{closed=true;state.aborts++;}};}};}
 function dir(p){return {kind:'directory',name:p.split('/').pop(),getDirectoryHandle:async(n,o={})=>{const path=p+'/'+n;if(!dirs.has(path)&&!o.create)throw new DOMException('missing','NotFoundError');dirs.add(path);return dir(path);},getFileHandle:async(n,o={})=>{const path=p+'/'+n;if(!files.has(path)&&!o.create)throw new DOMException('missing','NotFoundError');if(!files.has(path))files.set(path,new Blob([]));return file(path);}};}
 state.root=dir('root');state.recovery=s=>dir('root/rsp-recovery/'+s.name+'.checkpoint');return state;
}
const push=async(s,data)=>{s.push(new Uint8Array(data));await s.flush();};
test('checkpoint crash snapshot recovers only committed prefix and leaves source intact',async()=>{
 const d=disk(),s=sink(d.root,{checkpointBytes:4});await push(s,[1,2,3,4]);await push(s,[5,6]);
 const before=await recovery.inspect(d.recovery(s));a.equal(before.journal.committedBytes,4);a.equal((await s.handle.getFile()).size,0);
 const out=await d.root.getFileHandle('recovered.ts',{create:true});const result=await recovery.recover(d.recovery(s),out,s.handle);
 a.equal(result.decoded,false);a.deepEqual([...new Uint8Array(await (await out.getFile()).arrayBuffer())],[1,2,3,4]);a.equal(s.closed,false);a.equal((await s.handle.getFile()).size,0);
});
test('normal close keeps one final file and marks recovery complete',async()=>{
 const d=disk(),s=sink(d.root,{checkpointBytes:3});await push(s,[1,2,3]);await push(s,[4,5]);const r=await s.close();a.equal(r.confirmed,true);
 a.deepEqual([...new Uint8Array(await (await s.handle.getFile()).arrayBuffer())],[1,2,3,4,5]);
 const h=await d.recovery(s).getFileHandle('journal.json');const j=JSON.parse(await (await h.getFile()).text());a.equal(j.status,'complete');a.equal(j.committedBytes,5);
 await a.rejects(()=>recovery.inspect(d.recovery(s)),/INVALID_JOURNAL/);
});
test('journal write failure retains previous checkpoint and never confirms new data',async()=>{
 const d=disk(),s=sink(d.root,{checkpointBytes:2});await push(s,[1,2]);d.fault=(p,op)=>p.endsWith('journal.json')&&op==='write';
 await a.rejects(()=>push(s,[3,4]),/PART_WRITE_FAILED/);await a.rejects(()=>s.close());d.fault=null;
 const snap=await recovery.inspect(d.recovery(s));a.equal(snap.journal.committedBytes,2);a.equal(snap.chunks.length,1);
});
test('final media close failure leaves all checkpoint bytes recoverable',async()=>{
 const d=disk(),s=sink(d.root,{checkpointBytes:20});await push(s,[1,2,3]);d.fault=(p,op)=>p==='root/'+s.name&&op==='close';await a.rejects(()=>s.close(),/PART_CLOSE_FAILED/);
 a.equal((await recovery.inspect(d.recovery(s))).journal.committedBytes,3);
});
test('checkpoint chunk close failure cannot advance advertised bytes',async()=>{
 const d=disk(),s=sink(d.root,{checkpointBytes:2});await push(s,[1,2]);d.fault=(p,op)=>p.endsWith('00000002.bin')&&op==='close';
 await a.rejects(()=>push(s,[3,4]));await a.rejects(()=>s.close());d.fault=null;a.equal((await recovery.inspect(d.recovery(s))).journal.committedBytes,2);
});
test('recovery rejects traversal, wrong sums, duplicate chunk names, and complete records',()=>{
 const base={schema:1,file:'x.ts',ext:'ts',status:'active',committedBytes:2,parts:[{file:'chunk-00000001.bin',bytes:2}]};
 for(const j of [{...base,file:'../x.ts'},{...base,committedBytes:3},{...base,status:'complete'},{...base,parts:[base.parts[0],base.parts[0]],committedBytes:4}])a.throws(()=>recovery.validate(j,j.file+'.checkpoint'));
});
test('missing or truncated checkpoint chunks are rejected before destination mutation',async()=>{
 const d=disk(),s=sink(d.root,{checkpointBytes:2});await push(s,[1,2]);const key='root/rsp-recovery/'+s.name+'.checkpoint/chunk-00000001.bin';d.files.set(key,new Blob([new Uint8Array([1])]));
 const out=await d.root.getFileHandle('safe.ts',{create:true});d.files.set(out.path,new Blob(['keep']));await a.rejects(()=>recovery.recover(d.recovery(s),out,s.handle),/CHUNK_SIZE_MISMATCH/);a.equal(await (await out.getFile()).text(),'keep');
});
test('recovery refuses source, original media, and journal overwrite',async()=>{
 const d=disk(),s=sink(d.root,{checkpointBytes:2});await push(s,[1,2]);const snap=await recovery.inspect(d.recovery(s));
 for(const dest of [s.handle,snap.journalHandle,snap.chunks[0].handle])await a.rejects(()=>recovery.recover(d.recovery(s),dest,s.handle),/SOURCE_OVERWRITE_REFUSED/);
});
test('recovery streams in 1MiB blocks; destination failure preserves old file',async()=>{
 const d=disk(),s=sink(d.root,{checkpointBytes:2*1048576});const data=new Uint8Array(2*1048576+12).fill(7);await push(s,data);
 const out=await d.root.getFileHandle('out.ts',{create:true});d.maxWrite=0;await recovery.recover(d.recovery(s),out,s.handle);a(d.maxWrite<=1048576);a.equal((await out.getFile()).size,data.length);
 d.files.set(out.path,new Blob(['previous']));d.fault=(p,op)=>p===out.path&&op==='write';await a.rejects(()=>recovery.recover(d.recovery(s),out,s.handle));a.equal(await (await out.getFile()).text(),'previous');a(d.aborts>0);
});
test('time threshold checkpoints on the next write even below the byte limit',async()=>{
 const d=disk(),s=sink(d.root,{checkpointBytes:100});await push(s,[1]);s.checkpoints.last=Date.now()-31000;await push(s,[2]);a.equal((await recovery.inspect(d.recovery(s))).journal.committedBytes,2);
});
test('oversized journal is rejected without decoding its text',async()=>{
 let read=false;const dir={getFileHandle:async()=>({getFile:async()=>({size:3*1048576,text:()=>{read=true;}})})};await a.rejects(()=>recovery.inspect(dir),/JOURNAL_LIMIT/);a.equal(read,false);
});
test('recovered committed TS prefix matches real FFmpeg video and decodes',async()=>{
 const {spawnSync}=require('node:child_process'),os=require('node:os'),path=require('node:path');
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'rsp-checkpoint-'));
 try{
  const input=path.join(dir,'input.ts'),output=path.join(dir,'recovered.ts');
  const gen=spawnSync('ffmpeg',['-v','error','-f','lavfi','-i','color=c=blue:s=160x90:r=10:d=0.5','-c:v','mpeg2video','-f','mpegts',input],{timeout:15000});a.equal(gen.status,0,gen.stderr?.toString());
  const data=fs.readFileSync(input),d=disk(),s=sink(d.root,{checkpointBytes:1});await push(s,data);s.checkpoints.limit=100;await push(s,[99]);
  const dest=await d.root.getFileHandle('recovered.ts',{create:true});await recovery.recover(d.recovery(s),dest,s.handle);
  const bytes=Buffer.from(await (await dest.getFile()).arrayBuffer());a.deepEqual(bytes,data);fs.writeFileSync(output,bytes);
  const dec=spawnSync('ffmpeg',['-v','error','-xerror','-i',output,'-f','null','-'],{timeout:15000});a.equal(dec.status,0,dec.stderr?.toString());
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
test('schema2 detects same-size checkpoint corruption before destination is opened',async()=>{
 const d=disk(),s=sink(d.root,{checkpointBytes:2});await push(s,[1,2]);
 const path='root/rsp-recovery/'+s.name+'.checkpoint/chunk-00000001.bin';d.files.set(path,new Blob([new Uint8Array([1,99])]));
 const out=await d.root.getFileHandle('out.ts',{create:true});d.files.set(out.path,new Blob(['previous']));await a.rejects(()=>recovery.recover(d.recovery(s),out,s.handle),/CHUNK_HASH_MISMATCH/);a.equal(await (await out.getFile()).text(),'previous');
});
test('schema2 digest syntax is validated; schema1 remains explicitly size-only',async()=>{
 const d=disk(),s=sink(d.root,{checkpointBytes:2});await push(s,[1,2]);const dir=d.recovery(s),h=await dir.getFileHandle('journal.json');const j=JSON.parse(await (await h.getFile()).text());a.equal(j.schema,2);a.match(j.parts[0].sha256,/^[0-9a-f]{64}$/);
 a.throws(()=>recovery.validate({...j,parts:[{...j.parts[0],sha256:'bad'}]},dir.name),/INVALID_HASH/);
 j.schema=1;delete j.parts[0].sha256;d.files.set(h.path,new Blob([JSON.stringify(j)]));const out=await d.root.getFileHandle('legacy.ts',{create:true});a.equal((await recovery.recover(dir,out,s.handle)).sourceIntegrity,'size_only');
});
test('same-size output corruption after close is not confirmed as recovery success',async()=>{
 const d=disk(),s=sink(d.root,{checkpointBytes:2});await push(s,[1,2]);const out=await d.root.getFileHandle('bad.ts',{create:true}),open=out.createWritable;
 out.createWritable=async()=>{const w=await open(),close=w.close;w.close=async()=>{await close();d.files.set(out.path,new Blob([new Uint8Array([9,9])]));};return w;};
 await a.rejects(()=>recovery.recover(d.recovery(s),out,s.handle),/RECOVERY_HASH_MISMATCH/);
});
test('checkpoint read-back content mismatch cannot replace previous valid journal',async()=>{
 const d=disk(),s=sink(d.root,{checkpointBytes:2});await push(s,[1,2]);d.fault=(p,op)=>{if(p.endsWith('00000002.bin')&&op==='read')d.files.set(p,new Blob([new Uint8Array([9,9])]));return false;};
 await a.rejects(()=>push(s,[3,4]),/PART_WRITE_FAILED/);await a.rejects(()=>s.close());d.fault=null;
 a.equal((await recovery.inspect(d.recovery(s))).journal.committedBytes,2);
});
test('source changed between verification and copy aborts before committing destination',async()=>{
 const d=disk(),s=sink(d.root,{checkpointBytes:2});await push(s,[1,2]);const path='root/rsp-recovery/'+s.name+'.checkpoint/chunk-00000001.bin';let reads=0;
 d.files.set(path,{size:2,slice:()=>new Blob([new Uint8Array(++reads===1?[1,2]:[9,9])])});
 const out=await d.root.getFileHandle('out.ts',{create:true});d.files.set(out.path,new Blob(['previous']));await a.rejects(()=>recovery.recover(d.recovery(s),out,s.handle),/CHUNK_HASH_MISMATCH/);a.equal(await (await out.getFile()).text(),'previous');
});
