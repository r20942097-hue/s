'use strict';
const {test}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),vm=require('node:vm'),{spawnSync}=require('node:child_process');
const M=require('../src/media_inspect_core.js');
const C=require('../src/media_catalog.js');
const H=require('../src/hls_transport.js');

test('v2.47.0: RspMediaInspect.commands generates literal-quoted N_m3u8DL-RE, yt-dlp, and streamlink commands alongside ffmpeg and curl',()=>{
 const url="https://cdn.example/live/master.m3u8?token=abc'def&sig=$(touch%20PWN)";
 const referer="https://rplay.live/live?id=1";
 const userAgent="Mozilla/5.0 'quote' $(cmd)";
 const shCmds=M.commands({url,referer,userAgent,output:"stream'name.mp4",shell:'sh'});
 a.equal(shCmds.executed,false);
 a.equal(shCmds.overwrite,false);
 a.match(shCmds.nm3u8dlRe,/^N_m3u8DL-RE /);
 a.ok(shCmds.nm3u8dlRe.includes('--live-real-time-merge --live-pipe-mux'));
 a.ok(shCmds.nm3u8dlRe.includes("--save-name 'stream'\"'\"'name'"));
 a.match(shCmds.ytdlp,/^yt-dlp --no-overwrites --hls-use-mpegts /);
 a.ok(shCmds.ytdlp.includes("--referer 'https://rplay.live/live?id=1'"));
 a.match(shCmds.streamlink,/^streamlink /);
 a.ok(shCmds.streamlink.includes("'best'"));

 // Verify POSIX shell literal safety for N_m3u8DL-RE and yt-dlp via fake argv dumper
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'rsp-v246-argv-'));
 try{
  for(const bin of ['N_m3u8DL-RE','yt-dlp','streamlink']){
   const p=path.join(dir,bin);
   fs.writeFileSync(p,'#!/usr/bin/env python3\nimport sys,json\nprint(json.dumps(sys.argv[1:]))\n',{mode:0o755});
  }
  for(const key of ['nm3u8dlRe','ytdlp','streamlink']){
   const run=spawnSync('/bin/sh',['-c',shCmds[key]],{cwd:dir,env:{...process.env,PATH:dir+path.delimiter+process.env.PATH},encoding:'utf8'});
   a.equal(run.status,0,run.stderr);
   const argv=JSON.parse(run.stdout);
   a.ok(argv.includes(url),`exact url preserved in ${key}`);
   a.equal(fs.existsSync(path.join(dir,'PWN')),false);
  }
 }finally{
  fs.rmSync(dir,{recursive:true,force:true});
 }

 const psCmds=M.commands({url:"https://cdn.example/live.m3u8?q='test",referer,userAgent:"UA'1",output:'out.mp4',shell:'powershell'});
 a.ok(psCmds.nm3u8dlRe.includes("'https://cdn.example/live.m3u8?q=''test'"));
 a.ok(psCmds.ytdlp.includes("'UA''1'"));
 a.ok(psCmds.streamlink.includes("'.\\out.mp4'"));
});

test('v2.47.0: RspMediaInspect.inspectHls counts SCTE-35/CUE ad markers and program-date-time tags and surfaces ad-boundary guidance in downloadPlan',()=>{
 const m3u8=[
  '#EXTM3U',
  '#EXT-X-TARGETDURATION:4',
  '#EXT-X-PROGRAM-DATE-TIME:2026-10-27T00:00:00.000Z',
  '#EXT-X-DATERANGE:ID="ad1",START-DATE="2026-10-27T00:00:00Z",SCTE35-OUT=0xFC3011',
  '#EXT-X-CUE-OUT:30.0',
  '#EXT-X-SCTE35:CUE="/DAvAAAAAAAAAP/wFAUAAAABf+/+A25m4A=="',
  '#EXTINF:4.0,',
  'seg1.ts?sig=SECRET1',
  '#EXT-X-CUE-IN',
  '#EXT-X-PROGRAM-DATE-TIME:2026-10-27T00:00:04.000Z',
  '#EXTINF:4.0,',
  'seg2.ts?sig=SECRET2',
  '#EXT-X-ENDLIST'
 ].join('\n');
 const d=M.inspectHls(m3u8);
 a.equal(d.programDateTimes,2);
 a.deepEqual(d.adMarkers,{cueOut:1,cueIn:1,scte35:1,dateRanges:1});
 a.equal(JSON.stringify(d).includes('SECRET'),false);
 const rep=M.safeReport({url:'https://cdn.example/live.m3u8?sig=SECRET',body:m3u8});
 a.ok(rep.workflow.requirements.some(r=>r.includes('SCTE-35/CUE')));
 a.equal(JSON.stringify(rep).includes('SECRET'),false);
});

test('v2.47.0: RspMediaCatalog.manifest extracts frameRate, codecs, videoRange, subtitlesGroup, channels, language, and SUBTITLES tracks',()=>{
 const master=[
  '#EXTM3U',
  '#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="aud-hi",NAME="Japanese",LANGUAGE="ja",CHANNELS="2",DEFAULT=YES,AUTOSELECT=YES,URI="audio/ja.m3u8"',
  '#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID="subs",NAME="Japanese CC",LANGUAGE="ja",DEFAULT=YES,AUTOSELECT=YES,URI="subs/ja.m3u8"',
  '#EXT-X-STREAM-INF:BANDWIDTH=6500000,AVERAGE-BANDWIDTH=6000000,RESOLUTION=1920x1080,FRAME-RATE=59.94,CODECS="avc1.64002a,mp4a.40.2",VIDEO-RANGE=PQ,AUDIO="aud-hi",SUBTITLES="subs"',
  'video/1080p.m3u8'
 ].join('\n');
 const rows=C.manifest(master,'https://cdn.example/live/master.m3u8?token=ROOT_SIG',H,true);
 a.equal(rows.length,3);
 const aud=rows.find(r=>r.kind==='audio');
 const sub=rows.find(r=>r.kind==='subtitles');
 const vid=rows.find(r=>r.kind==='variant');
 a.equal(aud.channels,'2');
 a.equal(aud.language,'ja');
 a.equal(aud.defaultTrack,true);
 a.ok(aud.label.includes('(2ch)'));
 a.ok(aud.url.includes('token=ROOT_SIG'));
 a.equal(sub.language,'ja');
 a.equal(sub.groupId,'subs');
 a.ok(sub.url.includes('token=ROOT_SIG'));
 a.equal(vid.frameRate,59.94);
 a.equal(vid.codecs,'avc1.64002a,mp4a.40.2');
 a.equal(vid.videoRange,'PQ');
 a.equal(vid.subtitlesGroup,'subs');
 a.ok(vid.label.includes('60fps'));
 a.ok(vid.label.includes('PQ'));
 a.ok(vid.label.includes('avc1.64002a,mp4a.40.2'));
});

test('v2.47.0: background.js allows dashboard.html and media_inspect.html to resolve media.candidate.get while rejecting web origins',async()=>{
 let listener,observed;
 const chrome={
  runtime:{id:'x',getURL:n=>'chrome-extension://x/'+n,onMessage:{addListener:f=>listener=f},onStartup:{addListener:()=>{}},onInstalled:{addListener:()=>{}}},
  webRequest:{onHeadersReceived:{addListener:f=>observed=f}},
  tabs:{onRemoved:{addListener:()=>{}},onUpdated:{addListener:()=>{}},create:async()=>({})},
  downloads:{onChanged:{addListener:()=>{}}},
  alarms:{onAlarm:{addListener:()=>{}}}
 };
 const ctx=vm.createContext({chrome,RspMediaCatalog:C,crypto:require('node:crypto').webcrypto,setTimeout,clearTimeout,RspExportManager:{create:()=>({})}});
 vm.runInContext(fs.readFileSync(require.resolve('../src/background.js'),'utf8'),ctx);
 const signed='https://cdn.example/live/index.m3u8?token=SECRET_TOKEN';
 observed({tabId:3,statusCode:200,url:signed,responseHeaders:[{name:'content-type',value:'application/vnd.apple.mpegurl'}]});
 const send=(msg,url)=>new Promise(resolve=>{const keep=listener(msg,{id:'x',url},resolve);if(!keep)resolve(undefined);});
 const dash='chrome-extension://x/dashboard.html';
 const list=await send({type:'media.candidates.list'},dash);
 a.equal(list.items.length,1);
 a.equal(JSON.stringify(list).includes('SECRET_TOKEN'),false);
 const fromDash=await send({type:'media.candidate.get',id:list.items[0].id},dash);
 a.equal(fromDash.ok,true);
 a.equal(fromDash.url,signed);
 const fromWeb=await send({type:'media.candidate.get',id:list.items[0].id},'https://rplay.live/live');
 a.equal(fromWeb,undefined);
});

test('v2.47.0: recovery.html and recovery.js wire #verifyTs checkbox into RspRecovery.recover options',()=>{
 const html=fs.readFileSync(require.resolve('../src/recovery.html'),'utf8');
 const js=fs.readFileSync(require.resolve('../src/recovery.js'),'utf8');
 a.ok(html.includes('id="verifyTs"'),'recovery.html has #verifyTs checkbox');
 a.ok(js.includes("getElementById('verifyTs')")&&js.includes('{verifyTs:wantVerifyTs}'),'recovery.js passes verifyTs to RspRecovery.recover');
});
