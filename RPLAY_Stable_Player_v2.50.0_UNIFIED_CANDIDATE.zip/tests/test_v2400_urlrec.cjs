'use strict';
/* v2.40.0: 任意HLS URL録画(P4) — 共有コアのurlMode契約(Butter不送・API不探査・FLV不用) +
   セッション台帳のurlSession/sourceUrl + dashboard経由のurl.start/url.stop(BG固定owner・SW再起動claim) */
const {test}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const base=path.join(__dirname,'..');
const built=fs.readFileSync(path.join(base,'rplay-stable-player-extension/content.js'),'utf8');
const pre=fs.readFileSync(path.join(base,'src/offscreen_pre.js'),'utf8');
const post=fs.readFileSync(path.join(base,'src/offscreen_post.js'),'utf8');
const bg=fs.readFileSync(path.join(base,'src/background.js'),'utf8');
const user=fs.readFileSync(path.join(base,'src/player.user.js'),'utf8');
const partio=fs.readFileSync(path.join(base,'src/part_io.js'),'utf8');
const {system}=require('./helpers_runtime.cjs');

/* ---- 共通: test_v2390_policy流のRecorder実装スライス(build済みcontent.jsから) ---- */
function world(recenv){
 let now=100000,alloc=0;const active=new Set();
 class Clock extends Date {static now(){return now;}}
 const math=Object.create(Math);math.random=()=>0;
 const c=vm.createContext({Blob,URL,TextEncoder,TextDecoder,Date:Clock,Math:math,Set,Promise,console,AbortController,
  setTimeout:()=>{const n=++alloc;active.add(n);return n;},clearTimeout:n=>active.delete(n),
  fetch:async()=>{throw Error('offline')},recRetryAfterMs:x=>Number(x)||0,
  HLS:require(path.join(base,'src/hls_transport.js')),REC_API_TIMEOUT_MS:1000,REC_SESSION_WRITE_EVERY:9999,
  RECENV:recenv||{}});
 const helper=built.slice(built.indexOf('  // Ordinary HLS only'),built.indexOf('  /* Shared per-part writer:'));
 const classes=built.slice(built.indexOf('  class AudioRecorder'),built.indexOf('  /* ==== RSP RECORDING CORE',built.indexOf('  class AudioRecorder')));
 vm.runInContext(helper+classes+';globalThis.Recorder=Recorder;',c);
 return {Recorder:c.Recorder,c,setNow:n=>{now=n;},active};
}
function standbyRecorder(w,logs){
 const r=Object.create(w.Recorder.prototype);
 Object.assign(r,{recording:true,stopped:false,state:'STANDBY',id:'a'.repeat(24),deadVariants:new Set(),bytes:0,filesSaved:0,
  _autoDenyKey:'',ui:{recState:()=>{}},log:m=>logs.push(String(m)),notify:(t)=>{logs.push('notify:'+t);},updateTitle:()=>{},persistSession:()=>{},
  _fResolveMember:async()=>({ok:true,playlist:'https://new/authorized.m3u8'}),pollPlaylist:async()=>{r.polled=true;},drain:async()=>{},
  stop:async()=>{r.stopped=true;r.recording=false;},creatorName:()=>'fixture',flvUrl:()=>'https://fixture/live.flv',pushData:async()=>{}});
 return r;
}

/* ---- ①共有コアのurlMode契約 ---- */
test('v2.40.0 urlMode(): default false, hook-driven true',()=>{
 const w=world();
 const r=Object.create(w.Recorder.prototype);
 a.equal(r.urlMode(),false,'no hook means RPLAY recording (default)');
 r.getUrlMode=()=>true;
 a.equal(r.urlMode(),true);
 r.getUrlMode=()=>{throw Error('boom');};
 a.equal(r.urlMode(),false,'broken hook degrades to RPLAY mode');
});
test('v2.40.0 fetchPlaylistOnce(): urlMode never retries 403 with a Butter token (no credentials to foreign hosts)',async()=>{
 let butter=0;const calls=[];
 const w=world({butterToken:async()=>{butter++;return 'SECRET-TOKEN';}});
 w.c.fetch=async(u,o)=>{calls.push({u:String(u),headers:(o&&o.headers)||{}});return {status:403,headers:{get:()=>null},body:{cancel:async()=>{}}};};
 const r=Object.create(w.Recorder.prototype);
 Object.assign(r,{getUrlMode:()=>true,_hlsGeneration:0,stopped:false});
 const res=await r.fetchPlaylistOnce('https://foreign.example/live/pl.m3u8');
 a.equal(res.status,403);
 a.equal(calls.length,1,'single request only');
 a.equal(butter,0,'Butter token never requested');
 a.ok(!calls[0].headers.Butter,'no Butter header sent to the foreign host');
});
test('v2.40.0 fetchPlaylistOnce(): non-urlMode keeps the Butter retry (v2.8.0 contract unchanged)',async()=>{
 let butter=0;const calls=[];
 const w=world({butterToken:async()=>{butter++;return 'SECRET-TOKEN';}});
 w.c.fetch=async(u,o)=>{calls.push({u:String(u),headers:(o&&o.headers)||{}});return {status:403,headers:{get:()=>null},body:{cancel:async()=>{}}};};
 const r=Object.create(w.Recorder.prototype);
 Object.assign(r,{getUrlMode:()=>null,_hlsGeneration:0,stopped:false});
 const res=await r.fetchPlaylistOnce('https://livestream.rplay.live/live/x.m3u8');
 a.equal(res.status,403);
 a.equal(butter,1,'Butter token fetched once for RPLAY source');
 a.equal(calls.length,2,'retry issued');
 a.equal(calls[1].headers.Butter,'SECRET-TOKEN','retry carries the Butter header');
});
test('v2.40.0 refreshLiveSource(): urlMode returns false without any request',async()=>{
 const w=world();const fetches=[];
 w.c.fetch=async u=>{fetches.push(String(u));throw Error('net');};
 const r=Object.create(w.Recorder.prototype);
 Object.assign(r,{getUrlMode:()=>true,_srcRefrAt:0,id:'a'.repeat(24)});
 a.equal(await r.refreshLiveSource('404確認'),false);
 a.equal(fetches.length,0,'RPLAY API never probed with a synthetic oid');
});
test('v2.40.0 tryFlv(): urlMode never starts the RPLAY CDN FLV fallback',async()=>{
 const logs=[],fetches=[];
 const w=world({autoPolicy:async()=>({verdict:'allowed'})});
 w.c.fetch=async u=>{fetches.push(String(u));throw Error('net');};
 const r=standbyRecorder(w,logs);r.getUrlMode=()=>true;r.flvRunning=false;
 a.equal(await r.tryFlv(),false);
 a.equal(fetches.length,0);
});
test('v2.40.0 standbyProbe(): urlMode probes only the same URL (no member/API/schedule/FLV)',async()=>{
 const logs=[],w=world({autoPolicy:async()=>({verdict:'allowed'})});
 const r=standbyRecorder(w,logs);r.getUrlMode=()=>true;
 let probed=0,member=0,api=0,sched=0;const fetches=[];
 r.probePlaylist=async()=>{probed++;return 'offline';};
 r._fResolveMember=async()=>{member++;return {ok:false};};
 r.apiStreamState=async()=>{api++;return 'off';};
 r._fResolveSched=async()=>{sched++;return null;};
 w.c.fetch=async u=>{fetches.push(String(u));throw Error('net');};
 r.flvFallback=()=>true;r.flvRunning=false;r.flvLastFail=0;
 await r.standbyProbe();
 a.equal(probed,1,'same-URL revival check runs');
 a.equal(member,0,'member resolution skipped');
 a.equal(api,0,'RPLAY stream-state API skipped');
 a.equal(sched,0,'schedule polling skipped');
 a.equal(fetches.length,0,'no FLV fallback fetch');
});
test('v2.40.0 standbyProbe(): urlMode still resumes when the same URL comes back live',async()=>{
 const logs=[],w=world({autoPolicy:async()=>({verdict:'allowed'})});
 const r=standbyRecorder(w,logs);r.getUrlMode=()=>true;
 r.probePlaylist=async()=>'live';
 const resumed=[];
 r.resume=async(m,why)=>{resumed.push(why);};
 await r.standbyProbe();
 a.equal(resumed.length,1);
 a.ok(resumed[0].includes('配信の復帰'));
});

/* ---- ②セッション台帳のurlSession/sourceUrl(offscreen_pre) ---- */
function extractFn(src,startMarker){
 const i=src.indexOf(startMarker);
 a.ok(i>0,'extract marker '+startMarker);
 const b=src.indexOf('{',i);let d=0,j=b;
 for(;;j++){if(src[j]==='{')d++;else if(src[j]==='}'){d--;if(!d)break;}}
 return src.slice(i,j+1);
}
const RECJOIN_SRC=extractFn(partio,'  function recJoinJob(');
function manifestCtx(state){
 const c=vm.createContext({Date:{now:()=>1700000000000},console,JSON,Number,String,Array,Object,
  STATE:state,TITLEC:{base:'t'},recJoinJob:null});
 vm.runInContext(RECJOIN_SRC+';globalThis.recJoinJob=recJoinJob;',c);
 const i=pre.indexOf('  function rspSessionManifest(rec) {');
 const j=pre.indexOf('\n  /* =====',i);
 a.ok(i>0&&j>i,'manifest markers');
 vm.runInContext(pre.slice(i,j)+';globalThis.build=rspSessionManifest;',c);
 return rec=>vm.runInContext('build('+JSON.stringify(JSON.parse(JSON.stringify(rec)))+')',c);
}
const fakeUrlRec=()=>({id:'a'.repeat(24),partsLog:[{file:'p1.ts',bytes:10}],partOpen:false,partName:'',bytes:0,audio:null,segFails:0,gapCount:0,failedSaves:0,_joinTruncated:false,_joinParts:null});
test('v2.40.0 session manifest: urlSession carries the query-free source label',()=>{
 const m=manifestCtx({creatorName:'配信者',urlMode:true,urlSource:'https://cdn.example.com/live/pl.m3u8'})(fakeUrlRec());
 a.equal(m.urlSession,true);
 a.equal(m.sourceUrl,'https://cdn.example.com/live/pl.m3u8');
 a.equal(m.parts.length,1);
});
test('v2.40.0 session manifest: RPLAY sessions omit the URL fields',()=>{
 const m=manifestCtx({creatorName:'配信者',urlMode:false,urlSource:''})(fakeUrlRec());
 a.equal(m.urlSession,false);
 a.equal(m.sourceUrl,undefined);
});

/* ---- ③BG urlOwner: 固定制御権identity(生成・記憶・復元・代替乱数) ---- */
function ownerHarness(storage){
 const c=vm.createContext({chrome:{storage:{session:storage}},Math,Number,String,console,Promise,Uint8Array,
  setTimeout:()=>1,clearTimeout:()=>{}});
 const i=bg.indexOf('let _urlOwner = null;');
 const j=bg.indexOf('chrome.runtime.onMessage.addListener',i);
 a.ok(i>0&&j>i,'urlOwner markers');
 vm.runInContext(bg.slice(i,j)+';globalThis.getOwner=urlOwner;globalThis.isValid=rspUrlOwnerValid;globalThis.hex32=rspRandomHex32;',c);
 return c;
}
test('v2.40.0 urlOwner(): valid identity, cached per SW instance, persisted to session storage',async()=>{
 const store={};
 const storage={get:(k,cb)=>cb(structuredClone(store)),set:(o,cb)=>{Object.assign(store,structuredClone(o));cb&&cb();}};
 const c=ownerHarness(storage);
 const o1=await vm.runInContext('getOwner()',c);
 a.ok(vm.runInContext('isValid(globalThis.__o1)',Object.assign(c,{__o1:o1})));
 a.ok(Number.isInteger(o1.tabId)&&o1.tabId>0);
 a.match(o1.clientId,/^[a-f0-9]{32}$/);
 a.equal(o1.documentId,'rsp-url-session-v1');
 const o2=await vm.runInContext('getOwner()',c);
 a.equal(o2,o1,'same SW instance reuses the identity');
 a.ok(store.rsp_url_owner&&store.rsp_url_owner.clientId===o1.clientId,'persisted for SW restarts');
});
test('v2.40.0 urlOwner(): a fresh SW instance restores the persisted identity',async()=>{
 const persisted={rsp_url_owner:{tabId:42,clientId:'f'.repeat(32),documentId:'rsp-url-session-v1'}};
 const storage={get:(k,cb)=>cb(structuredClone(persisted)),set:(o,cb)=>{Object.assign(persisted,structuredClone(o));cb&&cb();}};
 const c=ownerHarness(storage);
 const o=await vm.runInContext('getOwner()',c);
 a.equal(o.clientId,'f'.repeat(32),'restored from chrome.storage.session');
});
test('v2.40.0 rspRandomHex32(): works without crypto (test/legacy contexts)',()=>{
 const c=vm.createContext({Math,Number,String,console,Uint8Array});
 const i=bg.indexOf('function rspRandomHex32(){');
 const j=bg.indexOf('\n}',i)+2;
 vm.runInContext(bg.slice(i,j)+';globalThis.h=rspRandomHex32;',c);
 const h=vm.runInContext('h()',c);
 a.match(h,/^[a-f0-9]{32}$/);
});

/* ---- ④実ルータE2E: dashboard発url.start/url.stop(helpers_runtime・TestRecorder) ---- */
function dashSend(h,type,payload={}){
 return new Promise(res=>{
  const live=h.bg.listener({type,payload},{id:'rsp',url:'chrome-extension://rsp/dashboard.html',frameId:0,documentId:'docdash',tab:{id:77}},res);
  if(!live)res(undefined);
 });
}
test('v2.40.0 E2E: dashboard url.start → monitor.status(urlSession/urlSource) → url.stop',async()=>{
 const h=system(false,true);await h.start();
 const r=await dashSend(h,'url.start',{url:'https://cdn.example.com/live/abc/playlist.m3u8?token=secretquery',label:'テスト配信'});
 a.ok(r&&r.ok,JSON.stringify(r));
 a.match(r.oid,/^[a-f0-9]{24}$/,'synthetic oid is gate-shaped');
 a.equal(r.urlSession,true);
 const st=await dashSend(h,'monitor.status');
 a.ok(st&&st.ok);
 a.equal(st.recording,true);
 a.equal(st.urlSession,true);
 a.equal(st.urlSource,'https://cdn.example.com/live/abc/playlist.m3u8','query strings never leave the host');
 a.equal(st.oid,r.oid);
 const sp=await dashSend(h,'url.stop');
 a.ok(sp&&sp.ok,JSON.stringify(sp));
 const st2=await dashSend(h,'monitor.status');
 a.equal(st2.recording,false);
});
test('v2.40.0 E2E: same URL derives the same synthetic oid; different URL differs',async()=>{
 const h=system(false,true);await h.start();
 const r1=await dashSend(h,'url.start',{url:'https://x.example/a.m3u8'});
 a.ok(r1.ok);
 a.ok((await dashSend(h,'url.stop')).ok);
 const r2=await dashSend(h,'url.start',{url:'https://x.example/a.m3u8'});
 a.ok(r2.ok);
 a.equal(r2.oid,r1.oid,'deterministic identity per URL');
 a.ok((await dashSend(h,'url.stop')).ok);
 const r3=await dashSend(h,'url.start',{url:'https://x.example/b.m3u8'});
 a.ok(r3.ok);
 a.notEqual(r3.oid,r1.oid);
 a.ok((await dashSend(h,'url.stop')).ok);
});
test('v2.40.0 E2E: URL validation — malformed and http:// are rejected before the host',async()=>{
 const h=system(false,true);await h.start();
 a.equal((await dashSend(h,'url.start',{url:'not a url'})).error,'bad-url');
 a.equal((await dashSend(h,'url.start',{url:''})).error,'bad-url');
 a.equal((await dashSend(h,'url.start',{url:'http://x.example/a.m3u8'})).error,'https-only');
 a.equal((await dashSend(h,'url.start',{url:'file:///etc/passwd'})).error,'https-only','non-http schemes are rejected');
 a.equal((await dashSend(h,'url.start',{url:'https://'+('a'.repeat(2100))+'.example/x.m3u8'})).error,'bad-url');
 const st=await dashSend(h,'monitor.status');
 a.equal(st.recording,false,'nothing started by rejected requests');
});
test('v2.40.0 E2E: URL session and RPLAY session are mutually exclusive; url.stop refuses RPLAY sessions',async()=>{
 const h=system(false,true);await h.start();
 const started=await h.command('rec.start',{oid:'a'.repeat(24)});
 a.ok(started.ok);
 const r=await dashSend(h,'url.start',{url:'https://x.example/a.m3u8'});
 a.equal(r.ok,false);a.equal(r.error,'busy');
 const sp=await dashSend(h,'url.stop');
 a.equal(sp.ok,false);a.equal(sp.error,'not-url-session','RPLAY sessions stay owned by their page');
 a.ok((await h.command('rec.stop',started.control)).ok);
});
test('v2.40.0 E2E: URL session active blocks RPLAY rec.start with busy',async()=>{
 const h=system(false,true);await h.start();
 const r=await dashSend(h,'url.start',{url:'https://x.example/a.m3u8'});
 a.ok(r.ok);
 const s=await h.command('rec.start',{oid:'a'.repeat(24)});
 a.equal(s.ok,false);a.equal(s.error,'busy');
 a.ok((await dashSend(h,'url.stop')).ok);
});
test('v2.40.0 E2E: SW restart re-claims the URL session ownership and stops it',async()=>{
 const h=system(false,true);await h.start();
 const r=await dashSend(h,'url.start',{url:'https://x.example/a.m3u8'});
 a.ok(r.ok);
 h.restartBg();await h.start(); /* _urlOwner lost (no session storage in harness) — claim path must recover */
 const sp=await dashSend(h,'url.stop');
 a.ok(sp&&sp.ok,JSON.stringify(sp));
 const st=await dashSend(h,'monitor.status');
 a.equal(st.recording,false);
});
test('v2.40.0 E2E: Firefox in-process host serves the same url.start/stop contract',async()=>{
 const h=system(true,true);await h.start();
 const r=await dashSend(h,'url.start',{url:'https://x.example/a.m3u8',label:'firefox'});
 a.ok(r&&r.ok,JSON.stringify(r));
 const st=await dashSend(h,'monitor.status');
 a.equal(st.urlSession,true);
 a.ok((await dashSend(h,'url.stop')).ok);
});

/* ---- ⑤配線のソースガード(offscreen・BG・dashboard) ---- */
test('v2.40.0 wiring: offscreen handleUrlStart/handleStart/handleStatus source guards',()=>{
 a.ok(post.includes('async function handleUrlStart(p, owner)'),'url.start handler present');
 a.ok(post.includes("case 'url.start':"),'dispatch case present');
 a.ok(post.includes('settings: Object.assign({}, p.settings || {}, { follow: false, flv: false })'),'follow/FLV forced off for URL sessions');
 a.ok(post.includes('STATE.urlMode = p.urlMode === true;'),'handleStart resets STATE.urlMode (rec.start clears it)');
 a.ok(post.includes('STATE.recorder.getUrlMode = function () { return STATE.urlMode === true; }'),'recorder hook wired');
 a.ok(post.includes('out.urlSession = STATE.urlMode === true;')&&post.includes('out.urlSource = STATE.urlSource || \'\';'),'handleStatus exposes URL session fields');
 a.ok(post.includes('rspUrlSourceLabel'),'query-free label helper present');
 a.ok(pre.includes('urlSession: STATE.urlMode === true'),'session manifest carries urlSession');
});
test('v2.40.0 wiring: BG router and dashboard UI source guards',()=>{
 a.ok(bg.includes("msg.type === 'url.start'")&&bg.includes("msg.type === 'url.stop'"),'BG dashboard handlers present');
 a.ok(bg.includes("'https-only'"),'BG rejects http before the host');
 a.ok(bg.includes("st.urlSession !== true"),"url.stop refuses non-URL sessions");
 a.ok(bg.includes('rsp_url_owner'),'fixed owner persisted');
 a.ok(bg.includes('urlSession:st.urlSession===true')&&bg.includes('urlSource:st.urlSource||\'\''),'monitor.status relays URL session fields');
 const dash=fs.readFileSync(path.join(base,'src/dashboard.html'),'utf8');
 a.ok(dash.includes('id="urlRecInput"')&&dash.includes('id="urlRecStart"')&&dash.includes('id="urlRecStop"'),'dashboard section elements');
 a.ok(dash.includes('任意のHLS URLを録画'),'section heading');
 const djs=fs.readFileSync(path.join(base,'src/dashboard.js'),'utf8');
 a.ok(djs.includes("{type:'url.start'")&&djs.includes("{type:'url.stop'}"),'dashboard sends the new message types');
 a.ok(djs.includes('/^https:\\/\\//i.test(raw)'),'client-side https validation');
 a.ok(djs.includes('s.urlSession===true?(s.urlSource||\'URL録画\')'),'target line shows the source instead of the synthetic oid');
});
test('v2.40.0 wiring: shared-core gates present in all five core copies',()=>{
 const extChrome=fs.readFileSync(path.join(base,'rplay-stable-player-extension/content.js'),'utf8');
 const extFx=fs.readFileSync(path.join(base,'rplay-stable-player-extension-firefox/content.js'),'utf8');
 const off=fs.readFileSync(path.join(base,'rplay-stable-player-extension/offscreen.js'),'utf8');
 for(const [name,src] of [['built',built],['chrome-content',extChrome],['firefox-content',extFx],['offscreen',off]]){
  a.ok(src.includes('!this.urlMode() && typeof RECENV.butterToken'),name+': butter gate');
  a.ok(src.includes('if (this.urlMode()) return false; /* v2.40.0'),name+': source re-probe gate');
  a.ok(src.includes('if (this.urlMode()) return;'),name+': standby gate');
  a.ok(src.includes('if (self.urlMode()) return done(false);'),name+': FLV gate');
 }
 a.ok(user.includes('this.getUrlMode = null;'),'hook slot declared');
});
