'use strict';
const {test,before,after}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),vm=require('node:vm'),{spawnSync}=require('node:child_process'),crypto=require('node:crypto');
const core=require('../src/mp4_convert_core.js'),hashing=require('../src/sha256.js');
const c=vm.createContext({console,Uint8Array,Uint32Array,DataView,ArrayBuffer});c.window=c;vm.runInContext(fs.readFileSync(path.join(__dirname,'../src/vendor/mux.min.js'),'utf8'),c);
let dir,whole,parts,video,other;
function run(cmd,args){const r=spawnSync(cmd,args,{timeout:20000,maxBuffer:4*1048576});a.equal(r.status,0,r.stderr?.toString());return r.stdout;}
function input(data,name='in.ts'){const blob=new Blob([data]);return {name,getFile:async()=>blob};}
function output(options={}){let stored=new Blob(['previous']),pending=[],opened=0,aborted=0;const handle={isSameEntry:async h=>h===handle,getFile:async()=>stored,createWritable:async()=>{opened++;return {write:async b=>{if(options.writeFail)throw Error('DISK');pending.push(new Uint8Array(b));},close:async()=>{stored=new Blob(pending);if(options.corrupt)stored=new Blob([new Uint8Array(stored.size)]);},abort:async()=>{aborted++;pending=[];}};}};return {handle,get opened(){return opened;},get aborted(){return aborted;},get blob(){return stored;}};}

function mpegCrc(data){let crc=0xffffffff;for(const byte of data){crc^=byte<<24;for(let i=0;i<8;i++)crc=((crc&0x80000000)?(crc<<1)^0x04c11db7:crc<<1)>>>0;}return crc>>>0;}
function fixPsiCrc(data,at){const end=at+3+(((data[at+1]&15)<<8)|data[at+2]);const c=mpegCrc(data.subarray(at,end-4));data.writeUInt32BE(c,end-4);}
function packetWithSection(pid,section,counter=0,start=true){const p=Buffer.alloc(188,0xff);p[0]=0x47;p[1]=((pid>>8)&31)|(start?0x40:0);p[2]=pid&255;p[3]=0x10|(counter&15);if(start)p[4]=0;section.copy(p,start?5:4);return p;}
async function convert(inputs,out=output(),extra={}){const result=await core.convert({inputs,destination:out.handle,muxjs:c.muxjs,hashing,...extra});return {result,out};}
function frames(file){return run('ffmpeg',['-v','error','-i',file,'-map','0:v:0','-vsync','0','-f','framemd5','-']).toString().split('\n').filter(l=>l&&!l.startsWith('#')).map(l=>l.split(',').at(-1).trim());}
function adts(file){return run('ffmpeg',['-v','error','-i',file,'-map','0:a:0','-c','copy','-f','adts','-']);}
before(()=>{
 dir=fs.mkdtempSync(path.join(os.tmpdir(),'rsp-mp4-'));whole=path.join(dir,'whole.ts');video=path.join(dir,'video.ts');other=path.join(dir,'other.ts');
 const base=['-v','error','-f','lavfi','-i','testsrc2=s=160x90:r=25:d=8','-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=8','-c:v','libx264','-preset','medium','-g','50','-c:a','aac'];
 run('ffmpeg',[...base,'-f','hls','-hls_time','2','-hls_list_size','0','-hls_segment_filename',path.join(dir,'seg%d.ts'),path.join(dir,'index.m3u8')]);
 parts=fs.readdirSync(dir).filter(n=>/^seg\d+\.ts$/.test(n)).sort().map(n=>path.join(dir,n));fs.writeFileSync(whole,Buffer.concat(parts.map(p=>fs.readFileSync(p))));
 run('ffmpeg',['-v','error','-f','lavfi','-i','testsrc2=s=160x90:r=25:d=2','-c:v','libx264','-f','mpegts',video]);
 run('ffmpeg',['-v','error','-f','lavfi','-i','testsrc2=s=320x180:r=25:d=2','-c:v','libx264','-f','mpegts',other]);
});
after(()=>fs.rmSync(dir,{recursive:true,force:true}));
test('single TS to fMP4 preserves video frames and AAC packets and verifies output hash',async()=>{
 const {out,result}=await convert([input(fs.readFileSync(whole))]);const file=path.join(dir,'single.mp4');fs.writeFileSync(file,Buffer.from(await out.blob.arrayBuffer()));
 a.equal(result.audio,true);a.equal(result.decoded,false);a.equal(result.sha256,crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'));
 run('ffmpeg',['-v','error','-xerror','-i',file,'-f','null','-']);a.deepEqual(frames(file),frames(whole));a.deepEqual(adts(file),adts(whole));
});
test('ordered HLS TS files become one MP4 with matching frames and audio',async()=>{
 const {out,result}=await convert(parts.map(p=>input(fs.readFileSync(p),path.basename(p))));a.equal(result.fragments,parts.length);const file=path.join(dir,'parts.mp4');fs.writeFileSync(file,Buffer.from(await out.blob.arrayBuffer()));
 run('ffmpeg',['-v','error','-xerror','-i',file,'-f','null','-']);a.deepEqual(frames(file),frames(whole));a.deepEqual(adts(file),adts(whole));
});
test('v2.16 preserves the first AAC frame and normalizes MP4 duration across mismatched track starts',async()=>{
 const short=path.join(dir,'start-offset.ts'),mp4=path.join(dir,'start-offset.mp4');
 run('ffmpeg',['-v','error','-f','lavfi','-i','testsrc2=s=160x90:r=25:d=4',
  '-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=4',
  '-c:v','libx264','-preset','ultrafast','-c:a','aac','-f','mpegts',short]);
 const {out,result}=await convert([input(fs.readFileSync(short))]);fs.writeFileSync(mp4,Buffer.from(await out.blob.arrayBuffer()));
 const sourceAudio=adts(short),outAudio=adts(mp4);
 a.deepEqual(outAudio,sourceAudio,'must preserve first AAC access unit and all following AAC bytes');
 a.deepEqual(frames(mp4),frames(short));
 const srcMeta=JSON.parse(run('ffprobe',['-v','error','-show_entries','format=duration','-of','json',short]));
 const outMeta=JSON.parse(run('ffprobe',['-v','error','-show_entries','format=duration,start_time','-of','json',mp4]));
 a.ok(Math.abs(Number(outMeta.format.duration)-Number(srcMeta.format.duration))<0.1,
  `normalized MP4 duration ${outMeta.format.duration} vs TS ${srcMeta.format.duration}`);
 a.ok(Number(outMeta.format.start_time)<0.05,'media timeline should start near zero');
 a.equal(result.confirmed,true);
});
test('v2.16 multiple short HLS TS segments retain full AAC data with normalized duration',async()=>{
 const playlist=path.join(dir,'edge-index.m3u8'),combined=path.join(dir,'edge-combined.ts'),mp4=path.join(dir,'edge-short.mp4');
 run('ffmpeg',['-v','error','-f','lavfi','-i','testsrc2=s=160x90:r=25:d=4',
  '-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=4','-c:v','libx264',
  '-preset','ultrafast','-g','50','-c:a','aac','-f','hls','-hls_time','2',
  '-hls_list_size','0','-hls_segment_filename',path.join(dir,'edge-%d.ts'),playlist]);
 const edge=fs.readdirSync(dir).filter(n=>/^edge-\d+\.ts$/.test(n)).sort().map(n=>path.join(dir,n));
 a.ok(edge.length>=2,'should exercise multiple independent TS inputs');
 fs.writeFileSync(combined,Buffer.concat(edge.map(p=>fs.readFileSync(p))));
 const {out}=await convert(edge.map(p=>input(fs.readFileSync(p),path.basename(p))));
 fs.writeFileSync(mp4,Buffer.from(await out.blob.arrayBuffer()));
 a.deepEqual(adts(mp4),adts(combined));a.deepEqual(frames(mp4),frames(combined));
 const meta=JSON.parse(run('ffprobe',['-v','error','-show_entries','format=start_time,duration','-of','json',mp4]));
 a.ok(Number(meta.format.start_time)<0.05);
 a.ok(Number(meta.format.duration)<4.2,'avoid keeping the MPEG-TS 1.4-second timeline offset');
});
test('video-only TS stays explicitly video-only',async()=>{const {result}=await convert([input(fs.readFileSync(video))]);a.equal(result.audio,false);});
test('oversized TS is refused before output writer opens',async()=>{const o=output();await a.rejects(()=>convert([{getFile:async()=>({size:65*1048576})}],o),/TS_FILE_LIMIT/);a.equal(o.opened,0);});
test('source overwrite and duplicate handles are refused before output opens',async()=>{const o=output(),i=input(fs.readFileSync(video));await a.rejects(()=>convert([o.handle],o),/SOURCE_OVERWRITE/);await a.rejects(()=>convert([i,i],o),/DUPLICATE_INPUT/);a.equal(o.opened,0);});
test('invalid TS and scrambled packets abort and retain prior destination',async()=>{
 for(const data of [Buffer.from('not ts'),Buffer.from(fs.readFileSync(video))]){if(data.length>188)data[3]|=0x80;const o=output();await a.rejects(()=>convert([input(data)],o),/TS_ALIGNMENT|TS_INVALID_OR_SCRAMBLED/);a.equal(o.opened,0);a.equal(await o.blob.text(),'previous');}
});
test('PMT unsupported codec and continuity gaps are rejected',()=>{
 const original=fs.readFileSync(video),plan=core.tsPlan(new Uint8Array(original));a.equal(plan.audio,false);
 const gap=Buffer.from(original);for(let at=188;at<gap.length;at+=188)if((gap[at+3]&0x10)&&(((gap[at+1]&31)<<8)|gap[at+2])===0){gap[at+3]=(gap[at+3]&0xf0)|((gap[at+3]+5)&15);break;}a.throws(()=>core.tsPlan(gap),/TS_PACKET_GAP/);
 const bad=Buffer.from(original);for(let at=0;at<bad.length;at+=188){const pid=((bad[at+1]&31)<<8)|bad[at+2];if(pid!==4096||!(bad[at+1]&0x40))continue;let p=at+4;if(bad[at+3]&0x20)p+=1+bad[p];const section=p+1+bad[p];bad[section+12]=0x24;fixPsiCrc(bad,section);}
 a.throws(()=>core.tsPlan(bad),/TS_CODEC_UNSUPPORTED/);
});
test('reverse segment timing is rejected without publishing output',async()=>{const o=output();await a.rejects(()=>convert(parts.slice().reverse().map(p=>input(fs.readFileSync(p))),o),/MP4_TIMESTAMP_RESET/);a.equal(o.aborted,1);a.equal(await o.blob.text(),'previous');});
test('configuration change cannot reuse initial MP4 header',async()=>{const o=output();await a.rejects(()=>convert([input(fs.readFileSync(video)),input(fs.readFileSync(other))],o),/MP4_INIT_CHANGE/);a.equal(o.aborted,1);});
test('write error and cancellation abort output; originals remain',async()=>{
 const data=fs.readFileSync(video),i=input(data),o=output({writeFail:true});await a.rejects(()=>convert([i],o),/DISK/);a.equal(o.aborted,1);a.deepEqual(Buffer.from(await (await i.getFile()).arrayBuffer()),data);
 const cancel=new AbortController(),target=output();await a.rejects(()=>convert([i],target,{signal:cancel.signal,onProgress:p=>{if(p.phase==='convert')cancel.abort();}}),/CONVERSION_CANCELLED/);a.equal(target.aborted,1);a.equal(await target.blob.text(),'previous');
});
test('same-size output corruption is refused after read-back hash',async()=>{await a.rejects(()=>convert([input(fs.readFileSync(video))],output({corrupt:true})),/MP4_HASH_MISMATCH/);});
test('declared AAC with missing audio data cannot silently produce video-only MP4',async()=>{
 const data=fs.readFileSync(whole),plan=core.tsPlan(data),pid=JSON.parse(plan.signature).find(s=>s[0]===15)[1],packets=[];
 for(let at=0;at<data.length;at+=188)if((((data[at+1]&31)<<8)|data[at+2])!==pid)packets.push(data.subarray(at,at+188));
 const o=output();await a.rejects(()=>convert([input(Buffer.concat(packets))],o),/TS_AUDIO_PES_REQUIRED/);a.equal(o.opened,0);a.equal(await o.blob.text(),'previous');
});
test('pre-cancelled conversion never opens output',async()=>{const o=output(),ctl=new AbortController();ctl.abort();await a.rejects(()=>convert([input(fs.readFileSync(video))],o,{signal:ctl.signal}),/CONVERSION_CANCELLED/);a.equal(o.opened,0);});
test('bundled mux.js copies match pinned source and Apache license is included',()=>{
 const r=path.join(__dirname,'..'),deps=JSON.parse(fs.readFileSync(path.join(r,'DEPENDENCIES.json'))),entry=deps.assets.find(x=>x.file==='mux.min.js');a.equal(entry.internal_version,'6.3.0');a.equal(entry.license,'Apache-2.0');
 for(const n of ['src/vendor/mux.min.js','libs/mux.min.js','rplay-stable-player-extension/libs/mux.min.js','rplay-stable-player-extension-firefox/libs/mux.min.js'])a.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(r,n))).digest('hex'),entry.sha256);
 a.match(fs.readFileSync(path.join(r,'licenses/mux.js-LICENSE.txt'),'utf8'),/Apache License/);
});

test('PSI CRC tampering is detected before destination can be opened',async()=>{
 const corrupted=Buffer.from(fs.readFileSync(video));let changed=false;
 for(let at=0;at<corrupted.length;at+=188){const pid=((corrupted[at+1]&31)<<8)|corrupted[at+2];if(pid!==4096||!(corrupted[at+1]&0x40))continue;
  let p=at+4;if(corrupted[at+3]&0x20)p+=1+corrupted[p];const sec=p+1+corrupted[p];corrupted[sec+5]^=0x02;changed=true;break;
 }
 a.equal(changed,true);const o=output();await a.rejects(()=>convert([input(corrupted)],o),/TS_PSI_CRC/);a.equal(o.opened,0);
});
test('large multi-packet PMT is parsed with CRC and continuity enforcement',()=>{
 const src=fs.readFileSync(video);let pat,section,pid;
 for(let at=0;at<src.length;at+=188){const id=((src[at+1]&31)<<8)|src[at+2];if(id===0&&!pat)pat=Buffer.from(src.subarray(at,at+188));
  if(id!==4096||section)continue;pid=id;let p=at+4;if(src[at+3]&0x20)p+=1+src[p];const start=p+1+src[p],end=start+3+(((src[start+1]&15)<<8)|src[start+2]);section=Buffer.from(src.subarray(start,end));}
 a.ok(pat&&section);const info=Buffer.concat([Buffer.from([0x80,170]),Buffer.alloc(170)]),newSection=Buffer.concat([section.subarray(0,12),info,section.subarray(12,section.length-4),Buffer.alloc(4)]);
 const len=newSection.length-3;newSection[1]=(newSection[1]&0xf0)|((len>>8)&15);newSection[2]=len&255;newSection[10]=0xf0|((info.length>>8)&15);newSection[11]=info.length&255;fixPsiCrc(newSection,0);
 const first=packetWithSection(pid,newSection.subarray(0,183),0,true),rest=packetWithSection(pid,newSection.subarray(183),1,false);
 const t=core.tsPlan(Buffer.concat([pat,first,rest]));a.equal(t.audio,false);
 const broken=Buffer.from(rest);broken[3]=(broken[3]&0xf0)|3;a.throws(()=>core.tsPlan(Buffer.concat([pat,first,broken])),/TS_PACKET_GAP/);
 const missing=Buffer.from(rest);missing[4]^=0x20;a.throws(()=>core.tsPlan(Buffer.concat([pat,first,missing])),/TS_PSI_CRC/);
 a.throws(()=>core.tsPlan(Buffer.concat([pat,first])),/TS_PMT_REQUIRED|TS_PSI_INCOMPLETE/);
});
test('late-invalid inputs fail preflight without altering the existing output',async()=>{
 const o=output(),good=input(fs.readFileSync(video)),bad=input(Buffer.from('bad ts'));
 await a.rejects(()=>convert([good,bad],o),/TS_ALIGNMENT/);a.equal(o.opened,0);a.equal(await o.blob.text(),'previous');
});
test('distinct handles for the same underlying file are refused',async()=>{
 const data=fs.readFileSync(video),a1=input(data),a2=input(data);a1.isSameEntry=async b=>b===a2;
 const o=output();await a.rejects(()=>convert([a1,a2],o),/DUPLICATE_INPUT/);a.equal(o.opened,0);
});
test('preflight emits cancellable progress before opening a destination',async()=>{
 const ctl=new AbortController(),o=output(),events=[];
 await a.rejects(()=>convert([input(fs.readFileSync(video))],o,{signal:ctl.signal,onProgress:p=>{events.push(p.phase);if(p.phase==='preflight')ctl.abort();}}),/CONVERSION_CANCELLED/);
 a.deepEqual(events,['preflight']);a.equal(o.opened,0);
});
