"""v2.6.0 feature acceptance: fMP4 MAP declaration evidence (within-playlist and
cross-poll), LL-HLS safe-side policy (dedicated SKIP rejection, counted indicator
tags), decoded-duration measurement, and audio/video correlation in the quality
audit (real FFmpeg-generated media)."""
import http.server,threading,tempfile,pathlib,subprocess,sys,json,os,unittest
import importlib.util
R=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('v260',R/'rplay_dl.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
BASE='https://fixtures.invalid/live.m3u8'
def playlist(x):return '#EXTM3U\n#EXT-X-TARGETDURATION:1\n'+x


class UnitV260(unittest.TestCase):
    def test_fmp4_map_evidence_counts_switches_and_discontinuity(self):
        with_disc=playlist('#EXT-X-MAP:URI="init1.mp4"\na.m4s\n#EXT-X-DISCONTINUITY\n#EXT-X-MAP:URI="init2.mp4"\nb.m4s')
        self.assertEqual(m.hls_parse(with_disc,BASE)['fmp4'],{'mapDeclarations':2,'mapSwitches':1,'mapSwitchesWithoutDiscontinuity':0})
        without=playlist('#EXT-X-MAP:URI="init1.mp4"\na.m4s\n#EXT-X-MAP:URI="init2.mp4"\nb.m4s')
        self.assertEqual(m.hls_parse(without,BASE)['fmp4'],{'mapDeclarations':2,'mapSwitches':1,'mapSwitchesWithoutDiscontinuity':1})
        same=playlist('#EXT-X-MAP:URI="init1.mp4"\na.m4s\n#EXT-X-MAP:URI="init1.mp4"\nb.m4s')
        self.assertEqual(m.hls_parse(same,BASE)['fmp4'],{'mapDeclarations':2,'mapSwitches':0,'mapSwitchesWithoutDiscontinuity':0})
        one=m.hls_parse(playlist('#EXT-X-MAP:URI="init1.mp4"\na.m4s'),BASE)
        self.assertEqual(one['fmp4'],{'mapDeclarations':1,'mapSwitches':0,'mapSwitchesWithoutDiscontinuity':0})
        self.assertEqual(one['segments'][0]['map']['uri'],BASE.rsplit('/',1)[0]+'/init1.mp4')
    def test_llhls_skip_dedicated_rejection_and_indicators_counted(self):
        with self.assertRaisesRegex(ValueError,'HLS_LLHLS_SKIP'):
            m.hls_parse(playlist('#EXT-X-SKIP:SKIPPED-SEGMENTS=2\na.ts'),BASE)
        with self.assertRaisesRegex(ValueError,'HLS_LLHLS_SKIP'):
            m.hls_parse(playlist('#EXT-X-SKIP:SKIPPED-SEGMENTS=2'),BASE)
        p=m.hls_parse(playlist('#EXT-X-SERVER-CONTROL:CAN-BLOCK-RELOAD=YES,PART-HOLD-BACK=1.5\n'
                               '#EXT-X-PRELOAD-HINT:URI="seg1.ts",TYPE=PART\n'
                               '#EXT-X-RENDITION-REPORT:URI="../lo/manifest.m3u8"\n'
                               '#EXT-X-PART-INF:PART-TARGET=0.5\n'
                               '#EXTINF:1,\nseg1.ts'),BASE)
        self.assertEqual(p['llhls'],{'indicatorTags':4})
        self.assertEqual(len(p['segments']),1)  # the real segment is still recorded
        self.assertEqual(m.hls_parse(playlist('#EXTINF:1,\na.ts'),BASE)['llhls'],{'indicatorTags':0})
    def test_enqueue_accumulates_fmp4_and_llhls_evidence(self):
        class O:pass
        o=O();o.seen=set();o.queue=[]
        m.hls_enqueue(o,m.hls_parse(playlist('#EXT-X-MAP:URI="init1.mp4"\na.m4s'),BASE),BASE)
        m.hls_enqueue(o,m.hls_parse(playlist('#EXT-X-SERVER-CONTROL:CAN-BLOCK-RELOAD=YES\n#EXT-X-MEDIA-SEQUENCE:1\n#EXT-X-MAP:URI="init1.mp4"\nb.m4s'),BASE),BASE)
        self.assertEqual(o._hls_state['fmp4'],{'mapDeclarations':2,'mapSwitches':0,'mapSwitchesWithoutDiscontinuity':0,'crossPollMapSwitches':0,'crossPollMapSwitchesWithoutDiscontinuity':0})
        self.assertEqual(o._hls_state['llhlsIndicators'],1)
        # switch visible only across polls (same generation, changed init segment)
        m.hls_enqueue(o,m.hls_parse(playlist('#EXT-X-MEDIA-SEQUENCE:2\n#EXT-X-MAP:URI="init2.mp4"\nc.m4s'),BASE),BASE)
        self.assertEqual(o._hls_state['fmp4'],{'mapDeclarations':3,'mapSwitches':0,'mapSwitchesWithoutDiscontinuity':0,'crossPollMapSwitches':1,'crossPollMapSwitchesWithoutDiscontinuity':1})
        self.assertEqual(o._hls_state['recovery']['lastKind'],'progress')
    def test_fmp4_llhls_parse_fields_match_browser_core(self):
        vectors=[playlist('#EXT-X-MAP:URI="init1.mp4"\na.m4s\n#EXT-X-DISCONTINUITY\n#EXT-X-MAP:URI="init2.mp4"\nb.m4s'),
                 playlist('#EXT-X-MAP:URI="init1.mp4"\na.m4s\n#EXT-X-MAP:URI="init2.mp4"\nb.m4s'),
                 playlist('#EXT-X-SERVER-CONTROL:CAN-BLOCK-RELOAD=YES\n#EXT-X-PRELOAD-HINT:URI="s.ts",TYPE=PART\n#EXTINF:1,\ns.ts'),
                 playlist('#EXT-X-MEDIA-SEQUENCE:4\n#EXT-X-MAP:URI="i.mp4"\na.m4s')]
        js=("const H=require('./src/hls_transport.js');let s='';process.stdin.on('data',x=>s+=x);"
            "process.stdin.on('end',()=>process.stdout.write(JSON.stringify(JSON.parse(s).map(t=>{"
            "const p=H.parse(t,'"+BASE+"');return {fmp4:p.fmp4,llhls:p.llhls};}))));")
        p=subprocess.run(['node','-e',js],input=json.dumps(vectors),text=True,capture_output=True,cwd=R,check=True)
        expected=json.loads(p.stdout)
        for text,jsvalue in zip(vectors,expected):
            actual=m.hls_parse(text,BASE)
            self.assertEqual({'fmp4':actual['fmp4'],'llhls':actual['llhls']},jsvalue,text[:80])
    def test_fmp4_accumulator_matches_browser_core(self):
        cases=[[playlist('#EXT-X-MAP:URI="init1.mp4"\na.m4s'),
                playlist('#EXT-X-MEDIA-SEQUENCE:1\n#EXT-X-MAP:URI="init1.mp4"\nb.m4s'),
                playlist('#EXT-X-MEDIA-SEQUENCE:2\n#EXT-X-MAP:URI="init2.mp4"\nc.m4s')],
               [playlist('#EXT-X-MAP:URI="i1.mp4"\na.m4s\n#EXT-X-DISCONTINUITY\n#EXT-X-MAP:URI="i2.mp4"\nb.m4s')]]
        js=("const H=require('./src/hls_transport.js');let s='';process.stdin.on('data',x=>s+=x);"
            "process.stdin.on('end',()=>process.stdout.write(JSON.stringify(JSON.parse(s).map(cs=>{"
            "const o={seen:new Set(),queue:[]};for(const p of cs)H.enqueue(o,H.parse(p,'"+BASE+"'),'"+BASE+"');"
            "return o._hlsFmp4;}))));")
        p=subprocess.run(['node','-e',js],input=json.dumps(cases),text=True,capture_output=True,cwd=R,check=True)
        expected=json.loads(p.stdout)
        for case,want in zip(cases,expected):
            class O:pass
            o=O();o.seen=set();o.queue=[]
            for text in case:m.hls_enqueue(o,m.hls_parse(text,BASE),BASE)
            self.assertEqual(o._hls_state['fmp4'],want)
    def test_qaudit_av_correlation_verdicts(self):
        def part(track,dur,prov='decoded'):
            return {'track':track,'qualityAudit':{'provenance':prov,'decodedDurationSec':dur}}
        # aligned tracks pass
        r=m.qaudit_av_correlation([part('video',10.0),part('audio',10.2)])
        self.assertEqual(r['verdict'],'pass');self.assertEqual(r['driftSec'],0.2)
        self.assertEqual(r['provenance'],'decoded')
        # drift beyond max(2%, 0.5s) is suspect — never silently pass
        r=m.qaudit_av_correlation([part('video',10.0),part('audio',8.0)])
        self.assertEqual(r['verdict'],'av_drift_suspect');self.assertEqual(r['driftRatio'],-0.2)
        # one-sided evidence refuses to judge
        r=m.qaudit_av_correlation([part('video',10.0)])
        self.assertEqual(r['verdict'],'insufficient')
        r=m.qaudit_av_correlation([part('video',10.0,prov='manifest')])
        self.assertEqual(r['verdict'],'insufficient')
        # multiple parts aggregate per track
        r=m.qaudit_av_correlation([part('video',10.0),part('video',5.0),part('audio',15.4)])
        self.assertEqual(r['verdict'],'pass');self.assertEqual(r['videoDurationSec'],15.0)
        self.assertEqual(r['videoParts'],2);self.assertEqual(r['audioParts'],1)
    def test_qaudit_part_measures_decoded_duration(self):
        if not m.ffprobe_tool():self.skipTest('ffprobe required')
        with tempfile.TemporaryDirectory() as d:
            ts=pathlib.Path(d)/'v.ts'
            subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-f','lavfi','-i','testsrc2=size=128x72:rate=12','-t','2','-an','-c:v','libx264','-preset','ultrafast','-f','mpegts',str(ts)],check=True,capture_output=True,timeout=20)
            r=m.qaudit_part(str(ts))
            self.assertEqual(r['verdict'],'pass',json.dumps(r)[:300])
            self.assertIsNotNone(r.get('decodedDurationSec'))
            self.assertGreater(r['decodedDurationSec'],1.5)
            self.assertLess(r['decodedDurationSec'],2.5)
            v=[s for s in r['streams'] if s['codecType']=='video'][0]
            self.assertIsNotNone(v.get('durationSec'))


class E2EV260(unittest.TestCase):
    """Real-media E2E: two FFmpeg-produced fMP4 generations joined by a MAP switch,
    plus the audio/video decoded-duration correlation on real TS tracks."""
    @classmethod
    def setUpClass(cls):
        cls.ok=True
        if not m.ffprobe_tool():cls.ok=False;return
        cls.tmp=tempfile.TemporaryDirectory();root=pathlib.Path(cls.tmp.name)
        for i in (1,2):
            d=root/('g%d'%i);d.mkdir()
            subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-f','lavfi',
                            '-i','testsrc2=size=128x72:rate=12','-t','1','-an',
                            '-c:v','libx264','-preset','ultrafast','-f','hls',
                            '-hls_time','1','-hls_segment_type','fmp4',
                            '-hls_fmp4_init_filename','init%d.mp4'%i,
                            '-hls_segment_filename',str(d/'seg%d.m4s'),
                            str(d/'live.m3u8')],check=True,capture_output=True,timeout=30)
        cls.root=root
        cls.init1=(root/'g1'/'init1.mp4').read_bytes()
        cls.init2=(root/'g2'/'init2.mp4').read_bytes()
        cls.seg1=next((root/'g1').glob('seg*.m4s')).read_bytes()
        cls.seg2=next((root/'g2').glob('seg*.m4s')).read_bytes()
        # real audio track for the correlation test (sine, 3.0s vs 2.2s)
        subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-f','lavfi','-i','sine=frequency=440:sample_rate=48000','-t','3.0','-c:a','aac','-f','mpegts',str(root/'a3.ts')],check=True,capture_output=True,timeout=30)
        subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-f','lavfi','-i','sine=frequency=440:sample_rate=48000','-t','2.2','-c:a','aac','-f','mpegts',str(root/'a22.ts')],check=True,capture_output=True,timeout=30)
        subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-f','lavfi','-i','testsrc2=size=128x72:rate=12','-t','3.0','-an','-c:v','libx264','-preset','ultrafast','-f','mpegts',str(root/'v3.ts')],check=True,capture_output=True,timeout=30)
    @classmethod
    def tearDownClass(cls):
        if cls.ok:cls.tmp.cleanup()
    def _server(self,playlist_text):
        files={'init1.mp4':self.init1,'init2.mp4':self.init2,'a.m4s':self.seg1,'b.m4s':self.seg2}
        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self,*a):pass
            def do_GET(s):
                path=s.path.split('?')[0]
                if path.startswith('/api/'):body=json.dumps({'streamState':'live','accessible':True,'allowAnonymous':True}).encode()
                elif path=='/live.m3u8':body=playlist_text.encode()
                else:body=files.get(path.lstrip('/'),b'')
                s.send_response(200);s.send_header('Content-Length',str(len(body)));s.end_headers();s.wfile.write(body)
        srv=http.server.ThreadingHTTPServer(('127.0.0.1',0),H)
        t=threading.Thread(target=srv.serve_forever,daemon=True);t.start()
        return srv,'http://127.0.0.1:%d'%srv.server_port
    def _run(self,url,out,*extra,timeout=60):
        cmd=[sys.executable,str(R/'rplay_dl.py'),'a'*24,'--api',url+'/api','--m3u8',url+'/live.m3u8','--no-follow','--no-flv','--mux','no','--out',str(out),'--info-json']+list(extra)
        return subprocess.run(cmd,capture_output=True,text=True,timeout=timeout)
    def test_fmp4_map_switch_records_two_parts_with_evidence(self):
        if not self.ok:self.skipTest('ffprobe required')
        pls=('#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:0\n'
             '#EXT-X-MAP:URI="init1.mp4"\n#EXTINF:1,\na.m4s\n'
             '#EXT-X-DISCONTINUITY\n#EXT-X-MAP:URI="init2.mp4"\n#EXTINF:1,\nb.m4s\n#EXT-X-ENDLIST\n')
        srv,url=self._server(pls)
        try:
            with tempfile.TemporaryDirectory() as d:
                p=self._run(url,pathlib.Path(d))
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                out=pathlib.Path(d)
                parts=sorted(out.glob('*.mp4'))
                self.assertEqual(len(parts),2,'MAP切替はパート分割で初期化セグメント混在を防止')
                self.assertTrue(parts[0].read_bytes().startswith(self.init1))
                self.assertTrue(parts[1].read_bytes().startswith(self.init2))
                info=json.loads(next(out.glob('*_info.json')).read_text())
                ev=info['fmp4Evidence']['video']
                self.assertEqual(ev['mapDeclarations'],2)
                self.assertEqual(ev['mapSwitches'],1)
                self.assertEqual(ev['mapSwitchesWithoutDiscontinuity'],0)
                self.assertEqual(ev['crossPollMapSwitches'],0)
                self.assertEqual(info['fmp4Evidence']['provenance'],'manifest_map_declarations')
                if m.ffprobe_tool():
                    led=json.loads((out/('RPLAY_'+'a'*24+'_ledger.json')).read_text())
                    for e in led['parts']:
                        self.assertEqual(e['auditVerdict'],'pass',e.get('file'))
        finally:srv.shutdown();srv.server_close()
    def test_fmp4_map_switch_without_discontinuity_counted_not_rejected(self):
        if not self.ok:self.skipTest('ffprobe required')
        pls=('#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:0\n'
             '#EXT-X-MAP:URI="init1.mp4"\n#EXTINF:1,\na.m4s\n'
             '#EXT-X-MAP:URI="init2.mp4"\n#EXTINF:1,\nb.m4s\n#EXT-X-ENDLIST\n')
        srv,url=self._server(pls)
        try:
            with tempfile.TemporaryDirectory() as d:
                p=self._run(url,pathlib.Path(d))
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                out=pathlib.Path(d)
                self.assertEqual(len(list(out.glob('*.mp4'))),2)  # part split still protects integrity
                info=json.loads(next(out.glob('*_info.json')).read_text())
                ev=info['fmp4Evidence']['video']
                self.assertEqual(ev['mapSwitches'],1)
                self.assertEqual(ev['mapSwitchesWithoutDiscontinuity'],1)  # risk counted, not rejected
        finally:srv.shutdown();srv.server_close()
    def test_llhls_indicator_tags_counted_while_recording_continues(self):
        if not self.ok:self.skipTest('ffprobe required')
        pls=('#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:0\n'
             '#EXT-X-SERVER-CONTROL:CAN-BLOCK-RELOAD=YES,PART-HOLD-BACK=1.0\n'
             '#EXT-X-PRELOAD-HINT:URI="b.m4s",TYPE=PART\n'
             '#EXT-X-MAP:URI="init1.mp4"\n#EXTINF:1,\na.m4s\n#EXT-X-ENDLIST\n')
        srv,url=self._server(pls)
        try:
            with tempfile.TemporaryDirectory() as d:
                p=self._run(url,pathlib.Path(d))
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                out=pathlib.Path(d)
                self.assertEqual(len(list(out.glob('*.mp4'))),1)  # PRELOAD-HINT is not fetched; real segment recorded
                info=json.loads(next(out.glob('*_info.json')).read_text())
                self.assertEqual(info['llhlsEvidence']['videoIndicators'],2)
                self.assertIn('HLS_LLHLS_SKIP',info['llhlsEvidence']['policy'])
                self.assertEqual(info['llhlsEvidence']['provenance'],'manifest_tag_counts')
        finally:srv.shutdown();srv.server_close()
    def test_llhls_skip_playlist_rejected_with_dedicated_code(self):
        if not self.ok:self.skipTest('ffprobe required')
        pls=('#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:0\n'
             '#EXT-X-SKIP:SKIPPED-SEGMENTS=2\n#EXTINF:1,\na.m4s\n#EXT-X-ENDLIST\n')
        srv,url=self._server(pls)
        try:
            with tempfile.TemporaryDirectory() as d:
                p=self._run(url,pathlib.Path(d),timeout=30)
                self.assertEqual(p.returncode,2,p.stdout+p.stderr)
                self.assertIn('HLS_LLHLS_SKIP',p.stdout)
                self.assertEqual(len(list(pathlib.Path(d).glob('*.mp4'))),0)
        finally:srv.shutdown();srv.server_close()
    def test_av_correlation_real_media_pass_and_drift(self):
        if not self.ok:self.skipTest('ffprobe required')
        vq=m.qaudit_part(str(self.root/'v3.ts'))
        a3=m.qaudit_part(str(self.root/'a3.ts'))
        a22=m.qaudit_part(str(self.root/'a22.ts'))
        self.assertEqual(vq['verdict'],'pass');self.assertEqual(a3['verdict'],'pass')
        parts=[{'track':'video','qualityAudit':vq},{'track':'audio','qualityAudit':a3}]
        r=m.qaudit_av_correlation(parts)
        self.assertEqual(r['verdict'],'pass',json.dumps(r))
        self.assertAlmostEqual(r['videoDurationSec'],3.0,delta=0.25)
        self.assertAlmostEqual(r['audioDurationSec'],3.0,delta=0.25)
        self.assertLessEqual(abs(r['driftSec']),r['toleranceSec'])
        parts=[{'track':'video','qualityAudit':vq},{'track':'audio','qualityAudit':a22}]
        r=m.qaudit_av_correlation(parts)
        self.assertEqual(r['verdict'],'av_drift_suspect',json.dumps(r))
        self.assertLess(r['audioDurationSec'],r['videoDurationSec']-0.5)


if __name__=='__main__':unittest.main()
