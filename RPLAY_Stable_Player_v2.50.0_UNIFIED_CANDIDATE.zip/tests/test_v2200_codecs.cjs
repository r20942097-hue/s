'use strict';
const {test,before,after}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),vm=require('node:vm'),{spawnSync}=require('node:child_process');
const core=require('../src/mp4_convert_core.js'),codecs=require('../src/mp4_codec_core.js'),hashing=require('../src/sha256.js');
const c=vm.createContext({console,Uint8Array,Uint32Array,DataView,ArrayBuffer});c.window=c;vm.runInContext(fs.readFileSync(path.join(__dirname,'../src/vendor/mux.min.js'),'utf8'),c);
let dir,raw;
function run(cmd,args){const p=spawnSync(cmd,args,{timeout:30000,maxBuffer:4*1048576});a.equal(p.status,0,p.stderr?.toString());return p.stdout;}
function boxes(d,start=0,end=d.length){const v=new DataView(d.buffer,d.byteOffset,d.byteLength),out=[];for(let at=start;at<end;){const n=v.getUint32(at);a.ok(n>=8);out.push({type:String.fromCharCode(...d.subarray(at+4,at+8)),header:at,start:at+8,end:at+n});at+=n;}return out;}
function desc(d,at){const tag=d[at++];let n=0;for(let i=0;i<4;i++){const b=d[at++];n=n*128+(b&127);if(!(b&128))break;}return {tag,start:at,end:at+n};}
function locations(d){const v=new DataView(d.buffer,d.byteOffset,d.byteLength),moov=boxes(d).find(b=>b.type==='moov'),result={};for(const t of boxes(d,moov.start,moov.end).filter(b=>b.type==='trak')){const tk=boxes(d,t.start,t.end),tkhd=tk.find(b=>b.type==='tkhd'),mdia=tk.find(b=>b.type==='mdia'),md=boxes(d,mdia.start,mdia.end),h=md.find(b=>b.type==='hdlr'),kind=String.fromCharCode(...d.subarray(h.start+8,h.start+12)),minf=md.find(b=>b.type==='minf'),stbl=boxes(d,minf.start,minf.end).find(b=>b.type==='stbl'),stsd=boxes(d,stbl.start,stbl.end).find(b=>b.type==='stsd'),entry=boxes(d,stsd.start+8,stsd.end)[0];if(kind==='soun'){const esds=boxes(d,entry.start+28,entry.end).find(b=>b.type==='esds'),es=desc(d,esds.start+4),decoder=desc(d,es.start+3),asc=desc(d,decoder.start+13),sl=desc(d,decoder.end);result.audio={tkhd,stsd,entry,esds,es,decoder,asc,sl};}else{const avcc=boxes(d,entry.start+78,entry.end).find(b=>b.type==='avcC'),sps=avcc.start+8,spsEnd=sps+v.getUint16(avcc.start+6),pps=spsEnd+3;result.video={tkhd,stsd,entry,avcc,sps,spsEnd,pps};}}return result;}
function sink(){let old=new Blob(['previous']),parts=[],aborts=0,closes=0;return {handle:{isSameEntry:async()=>false,getFile:async()=>old,createWritable:async()=>({write:async b=>parts.push(new Uint8Array(b)),close:async()=>{closes++;old=new Blob(parts);},abort:async()=>{aborts++;parts=[];}})},get aborts(){return aborts;},get closes(){return closes;},get stored(){return old;}};}
function mutated(mutate){return {mp4:{Transmuxer:class{constructor(o){this.base=new c.muxjs.mp4.Transmuxer(o);}on(e,cb){this.base.on(e,e==='data'?s=>{const init=new Uint8Array(s.initSegment);mutate(init,new DataView(init.buffer),locations(init));cb({...s,initSegment:init});}:cb);}push(d){this.base.push(d);}flush(){this.base.flush();}dispose(){this.base.dispose();}}}};}
function generate(name,profile='baseline'){const file=path.join(dir,name+'.ts');run('ffmpeg',['-v','error','-f','lavfi','-i','testsrc2=s=160x90:r=25:d=4','-f','lavfi','-i','sine=sample_rate=48000:duration=4','-c:v','libx264','-profile:v',profile,'-preset',profile==='baseline'?'ultrafast':'medium','-g','25','-c:a','aac','-f','mpegts',file]);return file;}
before(()=>{dir=fs.mkdtempSync(path.join(os.tmpdir(),'rsp-v220-'));raw=fs.readFileSync(generate('baseline'));});after(()=>fs.rmSync(dir,{recursive:true,force:true}));
const cases=[
 ['mp4a channels',{error:/MP4_AAC_CONFIG_MISMATCH/,f:(d,v,x)=>v.setUint16(x.audio.entry.start+16,2)}],
 ['mp4a sample rate',{error:/MP4_AAC_CONFIG_MISMATCH/,f:(d,v,x)=>v.setUint32(x.audio.entry.start+24,44100*65536)}],
 ['mp4a sample size',{error:/MP4_AUDIO_ENTRY/,f:(d,v,x)=>v.setUint16(x.audio.entry.start+18,8)}],
 ['mp4a data reference',{error:/MP4_AUDIO_ENTRY/,f:(d,v,x)=>v.setUint16(x.audio.entry.start+6,2)}],
 ['unsupported audio entry version',{error:/MP4_AUDIO_ENTRY/,f:(d,v,x)=>v.setUint32(x.audio.entry.start+8,1)}],
 ['multiple stsd entries declaration',{error:/MP4_STSD_UNSUPPORTED/,f:(d,v,x)=>v.setUint32(x.audio.stsd.start+4,2)}],
 ['wrong audio sample entry type',{error:/MP4_AUDIO_ENTRY/,f:(d,v,x)=>d.set(Buffer.from('enca'),x.audio.entry.header+4)}],
 ['esds fullbox flags',{error:/MP4_ESDS_DESCRIPTOR/,f:(d,v,x)=>d[x.audio.esds.start+3]=1}],
 ['truncated descriptor declaration',{error:/MP4_ESDS_DESCRIPTOR/,f:(d,v,x)=>d[x.audio.esds.start+5]=127}],
 ['unsupported ES flags',{error:/MP4_ESDS_DESCRIPTOR/,f:(d,v,x)=>d[x.audio.es.start+2]=128}],
 ['wrong decoder object type',{error:/MP4_ESDS_DECODER/,f:(d,v,x)=>d[x.audio.decoder.start]=0x41}],
 ['wrong decoder stream type',{error:/MP4_ESDS_DECODER/,f:(d,v,x)=>d[x.audio.decoder.start+1]=0x11}],
 ['ASC AAC object type',{error:/MP4_AAC_CONFIG_MISMATCH/,f:(d,v,x)=>d[x.audio.asc.start]^=8}],
 ['ASC sample frequency index',{error:/MP4_AAC_CONFIG_MISMATCH/,f:(d,v,x)=>d[x.audio.asc.start]^=1}],
 ['ASC channel configuration',{error:/MP4_AAC_CONFIG_MISMATCH/,f:(d,v,x)=>d[x.audio.asc.start+1]^=16}],
 ['ASC GASpecific flags',{error:/MP4_AAC_CONFIG_MISMATCH/,f:(d,v,x)=>d[x.audio.asc.start+1]|=1}],
 ['SL descriptor',{error:/MP4_ESDS_DESCRIPTOR/,f:(d,v,x)=>d[x.audio.sl.start]=1}],
 ['avcC declared profile',{error:/MP4_AVCC_PROFILE_MISMATCH/,f:(d,v,x)=>d[x.video.avcc.start+1]^=1}],
 ['avcC NAL length size',{error:/MP4_AVCC_UNSUPPORTED/,f:(d,v,x)=>d[x.video.avcc.start+4]=0xfe}],
 ['avcC SPS bytes differ from source',{error:/MP4_AVC_PARAMETER_SET_MISMATCH/,f:(d,v,x)=>d[x.video.sps+3]^=1}],
 ['avcC PPS bytes differ from source',{error:/MP4_AVC_PARAMETER_SET_MISMATCH/,f:(d,v,x)=>d[x.video.pps+1]^=1}],
 ['avcC SPS length overruns box',{error:/MP4_AVCC_LENGTH/,f:(d,v,x)=>v.setUint16(x.video.avcc.start+6,65535)}],
 ['multiple SPS declaration',{error:/MP4_AVCC_UNSUPPORTED/,f:(d,v,x)=>d[x.video.avcc.start+5]=2}],
 ['multiple PPS declaration',{error:/MP4_AVCC_UNSUPPORTED/,f:(d,v,x)=>d[x.video.spsEnd]=2}],
 ['avc1 width differs from SPS',{error:/MP4_AVC_DIMENSIONS_MISMATCH/,f:(d,v,x)=>v.setUint16(x.video.entry.start+24,161)}],
 ['tkhd height differs from SPS',{error:/MP4_AVC_DIMENSIONS_MISMATCH/,f:(d,v,x)=>v.setUint32(x.video.tkhd.end-4,91*65536)}],
 ['wrong video entry type',{error:/MP4_VIDEO_ENTRY/,f:(d,v,x)=>d.set(Buffer.from('hev1'),x.video.entry.header+4)}]
];
for(const [name,m] of cases)test(name+' is refused before commit in both APIs',async()=>{for(const fn of [core.convert,core.convertStreamed]){const out=sink();await a.rejects(()=>fn({inputs:[{getFile:async()=>new Blob([raw])}],destination:out.handle,muxjs:mutated(m.f),hashing}),m.error);a.equal(out.aborts,1);a.equal(out.closes,0);a.equal(await out.stored.text(),'previous');}});
for(const profile of ['baseline','main','high'])test(profile+' SPS dimensions match independent ffprobe and input parameter sets',async()=>{const file=profile==='baseline'?path.join(dir,'baseline.ts'):generate(profile,profile),data=fs.readFileSync(file),out=sink(),r=await core.convertStreamed({inputs:[{getFile:async()=>new Blob([data])}],destination:out.handle,muxjs:c.muxjs,hashing});const meta=JSON.parse(run('ffprobe',['-v','error','-show_entries','stream=codec_type,width,height,sample_rate,channels','-of','json',file])),video=meta.streams.find(s=>s.codec_type==='video'),audio=meta.streams.find(s=>s.codec_type==='audio'),codec=r.mp4IntegrityEvidence.codecMetadata;a.equal(codec.inputSettingsMatched,true);const vc=codec.tracks.find(s=>s.kind==='vide'),ac=codec.tracks.find(s=>s.kind==='soun');a.equal(vc.width,video.width);a.equal(vc.height,video.height);a.equal(ac.sampleRate,+audio.sample_rate);a.equal(ac.channels,audio.channels);a.equal(vc.parameterSetsMatched,true);});
test('SPS parameter-set change within an input is rejected before opening output',async()=>{const bytes=Buffer.from(raw),pattern=Buffer.from([0,0,0,1,0x67]),first=bytes.indexOf(pattern),second=bytes.indexOf(pattern,first+5);a.ok(second>=0);bytes[second+7]^=1;let opens=0;const dest={isSameEntry:async()=>false,createWritable:async()=>{opens++;throw Error('MUST_NOT_OPEN');}};await a.rejects(()=>core.convertStreamed({inputs:[{getFile:async()=>new Blob([bytes])}],destination:dest,muxjs:c.muxjs,hashing}),/TS_AVC_PARAMETER_SET_CHANGE/);a.equal(opens,0);});
test('SPS parser rejects truncation, unsupported profile and bounded large input',()=>{const sps=Buffer.from(core.tsPlan(raw,{media:true}).mediaIntegrityEvidence.avcParameterSets.sps,'hex');a.throws(()=>codecs.spsGeometry(sps.subarray(0,5)),/AVC_SPS_TRUNCATED/);const unsupported=Buffer.from(sps);unsupported[1]=110;a.throws(()=>codecs.spsGeometry(unsupported),/AVC_SPS_PROFILE_UNSUPPORTED/);a.throws(()=>codecs.spsGeometry(Buffer.alloc(4097)),/AVC_SPS_INVALID/);});
