'use strict';
const {test,before,after}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),vm=require('node:vm'),{spawnSync}=require('node:child_process');
const core=require('../src/mp4_convert_core.js'),hashing=require('../src/sha256.js');
const ctx=vm.createContext({console,Uint8Array,Uint32Array,DataView,ArrayBuffer});ctx.window=ctx;
vm.runInContext(fs.readFileSync(path.join(__dirname,'../src/vendor/mux.min.js'),'utf8'),ctx);
let dir,raw,source;
function run(cmd,args){const r=spawnSync(cmd,args,{timeout:30000,maxBuffer:8*1048576});a.equal(r.status,0,r.stderr?.toString());return r.stdout;}
function dest(opts={}){let stored=new Blob(['previous']),pending=[],opens=0,aborts=0;const handle={isSameEntry:async h=>h===handle,getFile:async()=>stored,createWritable:async()=>{opens++;return {write:async d=>{if(opts.writeFail)throw Error('DISK');pending.push(new Uint8Array(d));},close:async()=>{stored=opts.corrupt?new Blob([new Uint8Array(pending.reduce((n,b)=>n+b.length,0))]):new Blob(pending);},abort:async()=>{aborts++;pending=[];}};}};return {handle,get opens(){return opens;},get aborts(){return aborts;},get stored(){return stored;}};}
function input(bytes){const blob=new Blob([bytes]);return {name:'source.ts',getFile:async()=>blob};}
async function convert(inputs,d=dest(),opts={}){return core.convertStreamed({inputs,destination:d.handle,muxjs:ctx.muxjs,hashing,sliceBytes:8192,chunkTargetBytes:15000,...opts});}
function audio(p){return run('ffmpeg',['-v','error','-i',p,'-map','0:a:0','-c','copy','-f','adts','-']);}
function video(p){return run('ffmpeg',['-v','error','-i',p,'-map','0:v:0','-vsync','0','-f','framemd5','-']).toString().split('\n').filter(x=>x&&!x.startsWith('#')).map(x=>x.split(',').at(-1).trim());}
before(()=>{dir=fs.mkdtempSync(path.join(os.tmpdir(),'rsp-v217-'));source=path.join(dir,'source.ts');run('ffmpeg',['-v','error','-f','lavfi','-i','testsrc2=s=160x90:r=25:d=8','-f','lavfi','-i','sine=sample_rate=48000:duration=8','-c:v','libx264','-preset','ultrafast','-g','25','-c:a','aac','-f','mpegts',source]);raw=fs.readFileSync(source);});
after(()=>fs.rmSync(dir,{recursive:true,force:true}));
test('streamed ultrafast GOP boundaries preserve every AAC byte and video frame with common zero origin',async()=>{
 const d=dest(),result=await convert([input(raw)],d);a.ok(result.chunksProcessed>=7);a.equal(result.timelineRebased,true);a.equal(result.inputHashVerified,true);
 const out=path.join(dir,'out.mp4');fs.writeFileSync(out,Buffer.from(await d.stored.arrayBuffer()));a.deepEqual(audio(out),audio(source));a.deepEqual(video(out),video(source));
 run('ffmpeg',['-v','error','-xerror','-i',out,'-f','null','-']);const meta=JSON.parse(run('ffprobe',['-v','error','-show_entries','format=start_time,duration','-of','json',out]));a.ok(+meta.format.start_time<0.05);a.ok(Math.abs(+meta.format.duration-8)<0.2);
});
test('a real 65MiB input with TS null padding uses bounded slices and preserves media',async()=>{
 const total=Math.ceil(65*1048576/188)*188,padded=Buffer.alloc(total,0xff);raw.copy(padded);
 for(let at=raw.length;at<total;at+=188){padded[at]=0x47;padded[at+1]=0x1f;padded[at+2]=0xff;padded[at+3]=0x10;}
 const blob=new Blob([padded]);let max=0,reads=0;
 const h={getFile:async()=>({size:blob.size,slice:(s,e)=>{max=Math.max(max,e-s);reads++;return blob.slice(s,e);},arrayBuffer(){throw Error('FULL_READ_FORBIDDEN');}})};
 const d=dest(),res=await convert([h],d,{sliceBytes:1048576});a.ok(max<=1048576);a.ok(reads>130);a.equal(res.confirmed,true);
 const out=path.join(dir,'large.mp4');fs.writeFileSync(out,Buffer.from(await d.stored.arrayBuffer()));a.deepEqual(audio(out),audio(source));a.deepEqual(video(out),video(source));
});
test('streaming rejects invalid option values before opening destination',async()=>{
 for(const options of [{sliceBytes:NaN},{sliceBytes:0},{sliceBytes:Infinity},{chunkTargetBytes:0},{chunkTargetBytes:Infinity},{maxInputBytes:3*1024**3}]){const d=dest();await a.rejects(()=>convert([input(raw)],d,options),/CONVERSION_OPTIONS/);a.equal(d.opens,0);}
});
test('streaming preflight rejects late invalid input without opening destination',async()=>{const d=dest();await a.rejects(()=>convert([input(raw),input(Buffer.from('bad'))],d),/TS_ALIGNMENT/);a.equal(d.opens,0);a.equal(await d.stored.text(),'previous');});
test('streaming detects aliases of the same file before output opens',async()=>{const x=input(raw),y=input(raw);x.isSameEntry=async h=>h===y;const d=dest();await a.rejects(()=>convert([x,y],d),/DUPLICATE_INPUT/);a.equal(d.opens,0);});
test('streaming source overwrite is rejected',async()=>{const d=dest();await a.rejects(()=>convert([d.handle],d),/SOURCE_OVERWRITE/);a.equal(d.opens,0);});
test('preflight cancellation stops without opening destination',async()=>{const d=dest(),ctl=new AbortController();await a.rejects(()=>convert([input(raw)],d,{signal:ctl.signal,onProgress:p=>{if(p.phase==='preflight')ctl.abort();}}),/CONVERSION_CANCELLED/);a.equal(d.opens,0);});
test('conversion cancellation aborts and retains previous destination',async()=>{const d=dest(),ctl=new AbortController();await a.rejects(()=>convert([input(raw)],d,{signal:ctl.signal,onProgress:p=>{if(p.phase==='convert')ctl.abort();}}),/CONVERSION_CANCELLED/);a.equal(d.aborts,1);a.equal(await d.stored.text(),'previous');});
test('write failure aborts streamed destination',async()=>{const d=dest({writeFail:true});await a.rejects(()=>convert([input(raw)],d),/DISK/);a.equal(d.aborts,1);a.equal(await d.stored.text(),'previous');});
test('same-size readback corruption is never reported as confirmed',async()=>{await a.rejects(()=>convert([input(raw)],dest({corrupt:true})),/MP4_HASH_MISMATCH/);});
test('same-size source mutation after preflight is rejected before close',async()=>{
 let changed=false;const edited=Buffer.from(raw);
 // Change a PES payload byte while keeping packet headers and PSI valid.
 for(let at=0;at<edited.length;at+=188){if((((edited[at+1]&31)<<8)|edited[at+2])===256){edited[at+180]^=1;break;}}
 const h={getFile:async()=>({size:raw.length,slice:(s,e)=>new Blob([(changed?edited:raw).subarray(s,e)])})},d=dest();
 await a.rejects(()=>convert([h],d,{chunkTargetBytes:core.MAX_CHUNK_BYTES,onProgress:p=>{if(p.phase==='convert')changed=true;}}),/TS_INPUT_CHANGED/);a.equal(d.aborts,1);a.equal(await d.stored.text(),'previous');
});
test('streaming rejects packet gaps during preflight',async()=>{const data=Buffer.from(raw);for(let at=188;at<data.length;at+=188)if((((data[at+1]&31)<<8)|data[at+2])===256){data[at+3]^=2;break;}const d=dest();await a.rejects(()=>convert([input(data)],d),/TS_PACKET_GAP/);a.equal(d.opens,0);});
test('slice truncation is rejected in preflight',async()=>{const d=dest(),h={getFile:async()=>({size:raw.length,slice:(s,e)=>new Blob([raw.subarray(s,e-1)])})};await a.rejects(()=>convert([h],d),/TS_SIZE_CHANGED/);a.equal(d.opens,0);});
test('timestamp wrap across 33-bit MPEG-TS boundary preserves audio, video and duration',async()=>{
 const wrap=path.join(dir,'wrap.ts'),mp4=path.join(dir,'wrap.mp4');
 run('ffmpeg',['-v','error','-f','lavfi','-i','testsrc2=s=160x90:r=25:d=8','-f','lavfi','-i','sine=sample_rate=48000:duration=8','-c:v','libx264','-preset','ultrafast','-g','25','-c:a','aac','-output_ts_offset','95440','-f','mpegts',wrap]);
 const d=dest();await convert([input(fs.readFileSync(wrap))],d);fs.writeFileSync(mp4,Buffer.from(await d.stored.arrayBuffer()));
 a.deepEqual(audio(mp4),audio(wrap));a.deepEqual(video(mp4),video(wrap));
 const meta=JSON.parse(run('ffprobe',['-v','error','-show_entries','format=duration,start_time','-of','json',mp4]));a.ok(+meta.format.start_time<0.05);a.ok(Math.abs(+meta.format.duration-8)<0.2);run('ffmpeg',['-v','error','-xerror','-i',mp4,'-f','null','-']);
});
test('pathological GOP without another keyframe stops at the explicit memory cap',async()=>{
 const onlyVideo=path.join(dir,'cap-video-only.ts');
 run('ffmpeg',['-v','error','-f','lavfi','-i','testsrc2=s=160x90:r=25:d=2','-c:v','libx264','-preset','ultrafast','-f','mpegts',onlyVideo]);
 const raw=fs.readFileSync(onlyVideo);
 const prefix=[];let vp;
 for(let at=0;at<raw.length;at+=188){const p=raw.subarray(at,at+188);prefix.push(p);if((((p[1]&31)<<8)|p[2])===256){vp=Buffer.from(p);break;}}
 a.ok(vp);const extra=Math.ceil((core.MAX_CHUNK_BYTES+188)/188),buf=Buffer.alloc((prefix.length+extra)*188);Buffer.concat(prefix).copy(buf);
 let cc=vp[3]&15;
 for(let i=0;i<extra;i++){const at=(prefix.length+i)*188;buf.fill(0x55,at,at+188);buf[at]=0x47;buf[at+1]=1;buf[at+2]=0;cc=(cc+1)&15;buf[at+3]=0x10|cc;}
 const d=dest();await a.rejects(()=>convert([input(buf)],d,{sliceBytes:1048576,chunkTargetBytes:core.MAX_CHUNK_BYTES}),/TS_GOP_BUFFER_LIMIT/);a.equal(d.aborts,1);a.equal(await d.stored.text(),'previous');
});
