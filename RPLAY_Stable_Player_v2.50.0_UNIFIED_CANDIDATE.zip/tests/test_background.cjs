'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),vm=require('vm'),fs=require('fs'),path=require('path');
const base=path.join(__dirname,'../rplay-stable-player-extension');
function context(){
 const h={listener:null,created:0,closed:0,hostMessages:[],callbacks:[],alarms:[],offers:0};let creatingResolve;
 const api={storage:{local:{get:(k,cb)=>cb({})}},runtime:{id:'rsp',lastError:null,getURL:n=>'chrome-extension://rsp/'+n,
  onMessage:{addListener:f=>h.listener=f},onStartup:{addListener:f=>h.start=f},onInstalled:{addListener:f=>h.install=f},
  getContexts:async()=>h.created?[{}]:[],sendMessage:async m=>{h.hostMessages.push(m);if(m.type==='rec.status')return {recording:false,exportHost:{busy:0,retained:h.retained||0}};return {ok:true};}},
  offscreen:{createDocument:async()=>{h.created++;if(h.delayCreate)await new Promise(r=>creatingResolve=r);},closeDocument:async()=>h.closed++},
  downloads:{onChanged:{addListener:f=>h.changed=f}},alarms:{create:(...a)=>h.alarms.push(a),clear:()=>{},onAlarm:{addListener:()=>{}}},action:{setBadgeText:()=>{}},tabs:{query:async()=>[],sendMessage:async()=>{}}};
 const c=vm.createContext({chrome:api,console,Promise,Date,setTimeout:f=>(h.callbacks.push(f),h.callbacks.length),clearTimeout:()=>{},RspExportManager:{create:()=>({pending:async()=>false,status:async()=>({verified:2}),offer:async()=>{h.offers++;return{ok:true}},changed:async()=>{},reconcile:async()=>{}})}});
 vm.runInContext(fs.readFileSync(base+'/background.js','utf8'),c);h.run=x=>vm.runInContext(x,c);h.release=()=>creatingResolve();h.api=api;
 h.message=(msg,sender)=>new Promise(res=>{const keep=h.listener(msg,sender,res);if(keep!==true)res(null);});return h;
}
const own={id:'rsp',url:'https://rplay.live/live/test',tab:{id:1}};
test('router never calls SW Blob/OPFS APIs during host export',async()=>{const h=context();const r=await h.message({type:'export.offer'}, {id:'rsp',url:'chrome-extension://rsp/offscreen.html'});assert(r.ok);assert.equal(h.offers,1);});
test('offscreen URL substring spoof is rejected',async()=>{const h=context();const r=await h.message({type:'export.offer'}, {id:'rsp',url:'https://attacker/offscreen.html'});assert.equal(r,null);assert.equal(h.offers,0);});
test('untrusted content origin cannot request recording',async()=>{const h=context();await h.message({type:'rec.start'},{id:'rsp',url:'https://attacker/',tab:{id:1}});assert.equal(h.hostMessages.length,0);});
test('host-target messages are ignored by router',async()=>{const h=context();await h.message({type:'rec.start',target:'rsp-host'},own);assert.equal(h.hostMessages.length,0);});
test('recording request is relayed with explicit host target',async()=>{const h=context();const r=await h.message({type:'rec.start'},own);assert(r.ok);assert.equal(h.hostMessages[0].target,'rsp-host');});
test('status includes persistent export aggregates',async()=>{const h=context();const r=await h.message({type:'rec.status'},own);assert.equal(r.exports.verified,2);});
test('offscreen concurrent creation has a single promise',async()=>{const h=context();h.delayCreate=true;const a=h.run('ensureOffscreen()'),b=h.run('ensureOffscreen()');await new Promise(setImmediate);assert.equal(h.created,1);h.release();assert(await a);assert(await b);});
test('retained OPFS data blocks timed close',async()=>{const h=context();h.created=1;h.retained=1;h.run('scheduleOffscreenClose()');await h.callbacks.at(-1)();assert.equal(h.closed,0);});
test('idle host with no pending data may close',async()=>{const h=context();h.created=1;h.run('scheduleOffscreenClose()');await h.callbacks.at(-1)();assert.equal(h.closed,1);});
test('recovery opens only the packaged page from trusted top-level RPLAY content',async()=>{
 const h=context(),urls=[];h.api.tabs.create=async o=>urls.push(o.url);
 const result=await h.message({type:'recovery.open',url:'https://attacker/'},own);assert(result.ok);assert.deepEqual(urls,['chrome-extension://rsp/recovery.html']);
});
test('untrusted origin and child frame cannot open recovery page',async()=>{
 const h=context();let opened=0;h.api.tabs.create=async()=>opened++;
 await h.message({type:'recovery.open'},{id:'rsp',url:'https://attacker/',tab:{id:1}});
 const r=await h.message({type:'recovery.open'},{...own,frameId:3});assert.equal(r.error,'top-frame-required');assert.equal(opened,0);
});
test('MP4 converter opens only packaged URL for trusted content',async()=>{const h=context(),urls=[];h.api.tabs.create=async x=>urls.push(x.url);const r=await h.message({type:'mp4.open',url:'https://attacker/'},own);assert(r.ok);assert.deepEqual(urls,['chrome-extension://rsp/mp4_convert.html']);});
test('untrusted page cannot open converter',async()=>{const h=context();let count=0;h.api.tabs.create=async()=>count++;await h.message({type:'mp4.open'},{id:'rsp',url:'https://attacker/',tab:{id:1}});assert.equal(count,0);});
