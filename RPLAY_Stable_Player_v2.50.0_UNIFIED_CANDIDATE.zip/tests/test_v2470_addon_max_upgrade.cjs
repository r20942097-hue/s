"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const ROOT = path.resolve(__dirname, "..");

function loadScript(relPath, sandbox) {
  const code = fs.readFileSync(path.join(ROOT, relPath), "utf8");
  vm.runInNewContext(code, sandbox, { filename: relPath });
}

// 1. Test JS HLS.enqueue ad-keyword filtering & Recorder.setAdKeyword / saveInfoJson parity
{
  const sb = { console, Math, Date, URL, RegExp, Set, Map, Uint8Array, ArrayBuffer, DataView };
  sb.window = sb;
  sb.globalThis = sb;
  loadScript("src/hls_transport.js", sb);
  const HLS = sb.RspHlsTransport;
  assert(HLS && typeof HLS.enqueue === "function", "RspHlsTransport.enqueue must exist");

  const base = "https://cdn.example.com/live/index.m3u8";
  const m3u8 = [
    "#EXTM3U",
    "#EXT-X-VERSION:3",
    "#EXT-X-TARGETDURATION:2",
    "#EXT-X-MEDIA-SEQUENCE:100",
    "#EXTINF:2.0,",
    "seg100.ts",
    "#EXT-X-DISCONTINUITY",
    "#EXT-X-CUE-OUT:DURATION=4.0",
    "#EXTINF:2.0,",
    "preroll_01.ts",
    "#EXTINF:2.0,",
    "ad-break-2.ts",
    "#EXT-X-CUE-IN",
    "#EXT-X-DISCONTINUITY",
    "#EXTINF:2.0,",
    "seg103.ts",
  ].join("\n");
  const parsed = HLS.parse(m3u8, base);
  assert.strictEqual(parsed.scte35.indicatorTags, 2);
  const owner = {
    _adKeywordRe: /(?:^|\/)(?:ad|preroll|midroll)[_/-]/i,
    seen: new Set(),
    queue: [],
    _hlsAdFilteredSegments: 0,
  };
  const res = HLS.enqueue(owner, parsed, base);
  assert.strictEqual(res.added, 2, "Only 2 non-ad segments should be enqueued");
  assert.strictEqual(owner._hlsAdFilteredSegments, 2, "2 ad segments should be counted in _hlsAdFilteredSegments");
  assert.strictEqual(owner.queue.length, 2);
  assert.strictEqual(owner.queue[0].hls.sequence, 100);
  assert.strictEqual(owner.queue[1].hls.sequence, 103);

  // Verify player.user.js contains setAdKeyword and adFilterEvidence
  const playerSrc = fs.readFileSync(path.join(ROOT, "src/player.user.js"), "utf8");
  assert(playerSrc.includes("setAdKeyword("), "Recorder.prototype.setAdKeyword must exist in player.user.js");
  assert(playerSrc.includes("adFilterEvidence:"), "saveInfoJson must include adFilterEvidence");
}

// 2. Test DASH MPD representationsList extraction and zero-secret attribute sanitization
{
  const sb = { console, Math, Date, URL, RegExp, Set, Map, TextEncoder, TextDecoder };
  sb.window = sb;
  sb.globalThis = sb;
  loadScript("src/cross_site_core.js", sb);
  const CS = sb.RspCrossSite;
  assert(CS && typeof CS.parseDASH === "function", "RspCrossSite.parseDASH must exist");

  const mpd = `<?xml version="1.0" encoding="UTF-8"?>
<MPD xmlns="urn:mpeg:dash:schema:mpd:2011" type="dynamic" mediaPresentationDuration="PT1H30M0S">
  <Period id="p0">
    <AdaptationSet contentType="video" mimeType="video/mp4" frameRate="60/1">
      <SegmentTemplate media="v_$Number$.m4s?token=SECRET_JWT_ABC" initialization="v_init.mp4"/>
      <Representation id="v1080p" codecs="avc1.64002a" width="1920" height="1080" bandwidth="6500000"/>
      <Representation id="v720p" codecs="avc1.4d401f" width="1280" height="720" bandwidth="3200000" frameRate="30"/>
    </AdaptationSet>
    <AdaptationSet contentType="audio" mimeType="audio/mp4" lang="ja">
      <Representation id="a128k" codecs="mp4a.40.2" bandwidth="128000" audioSamplingRate="48000"/>
    </AdaptationSet>
  </Period>
</MPD>`;

  const r = CS.parseDASH(mpd);
  assert.strictEqual(r.kind, "dash");
  assert.strictEqual(r.manifestType, "dynamic");
  assert.strictEqual(r.representations, 3);
  assert(Array.isArray(r.representationsList), "representationsList must be an array");
  assert.strictEqual(r.representationsList.length, 3);

  const v1080 = r.representationsList[0];
  assert.strictEqual(v1080.id, "v1080p");
  assert.strictEqual(v1080.contentType, "video");
  assert.strictEqual(v1080.mimeType, "video/mp4");
  assert.strictEqual(v1080.codecs, "avc1.64002a");
  assert.strictEqual(v1080.width, 1920);
  assert.strictEqual(v1080.height, 1080);
  assert.strictEqual(v1080.frameRate, "60/1");
  assert.strictEqual(v1080.bandwidth, 6500000);

  const a128 = r.representationsList[2];
  assert.strictEqual(a128.id, "a128k");
  assert.strictEqual(a128.contentType, "audio");
  assert.strictEqual(a128.lang, "ja");
  assert.strictEqual(a128.audioSamplingRate, 48000);

  const dumped = JSON.stringify(r);
  assert(!dumped.includes("SECRET_JWT_ABC"), "Zero-secret policy: no token or URL may leak into DASH report");
}

// 3. Test m3u8dl:// custom protocol URI generator in RspMediaInspect.commands
{
  const sb = {
    console, Math, Date, URL, RegExp, Set, Map,
    btoa: (str) => Buffer.from(str, "binary").toString("base64"),
    encodeURIComponent, decodeURIComponent, unescape,
  };
  sb.window = sb;
  sb.globalThis = sb;
  loadScript("src/media_inspect_core.js", sb);
  const MI = sb.RspMediaInspect;
  assert(MI && typeof MI.commands === "function", "RspMediaInspect.commands must exist");

  const cmds = MI.commands({
    url: "https://cdn.example.com/hls/master.m3u8",
    output: "Live_Stream_1.mp4",
    referer: "https://rplay.live/",
    userAgent: "Mozilla/5.0 TestAgent",
  });
  assert(typeof cmds.m3u8dlProtocol === "string" && cmds.m3u8dlProtocol.startsWith("m3u8dl://"), "m3u8dlProtocol must start with m3u8dl://");
  const b64 = cmds.m3u8dlProtocol.slice("m3u8dl://".length);
  const decoded = Buffer.from(b64, "base64").toString("utf8");
  assert(decoded.startsWith('"https://cdn.example.com/hls/master.m3u8"'), "Decoded m3u8dl payload must start with quoted URL");
  assert(decoded.includes('--save-name "Live_Stream_1"'), "Decoded m3u8dl payload must include sanitized --save-name");
  assert(decoded.includes("Referer: https://rplay.live/"), "Decoded m3u8dl payload must include origin Referer");
  assert(decoded.includes("User-Agent: Mozilla/5.0 TestAgent"), "Decoded m3u8dl payload must include User-Agent");
}

console.log("PASS: test_v2470_addon_max_upgrade.cjs");
