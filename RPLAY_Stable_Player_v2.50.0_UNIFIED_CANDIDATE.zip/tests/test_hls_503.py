import importlib.util
import pathlib
import unittest
from unittest.mock import patch

ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('retry503_cli', ROOT / 'rplay_dl.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class ServiceUnavailable(unittest.TestCase):
    def check_track(self, audio):
        r = m.Dl.__new__(m.Dl)
        r.last_req = 0
        r.seg_fails = r.a_seg_fails = 0
        r.seg_backoff = r.a_backoff = 0
        item = {'tries': 0, 'hls': {'uri': 'https://fixture/s.ts', 'map': None}}
        # Exercise the real descriptor-fetch path, including attempt accounting.
        with patch.object(m, 'hls_request', return_value=(503, None, 120000)), \
                patch.object(m, 'now_ms', return_value=1000):
            self.assertEqual(r._fetch_hls(item, audio), (None, True))
        self.assertEqual(item['tries'], 1)
        self.assertEqual(r.a_backoff if audio else r.seg_backoff, 121000)
        self.assertEqual(r.seg_backoff if audio else r.a_backoff, 0)
        self.assertEqual(r.seg_fails + r.a_seg_fails, 0)

    def test_video_503_delay(self):
        self.check_track(False)

    def test_audio_503_delay(self):
        self.check_track(True)

    def test_503_without_retry_after_remains_retryable(self):
        r = m.Dl.__new__(m.Dl)
        r.seg_backoff = 0
        self.assertEqual(r._hls_status({'tries': 1}, 503, 0, False), (None, True))
        self.assertEqual(r.seg_backoff, 0)


if __name__ == '__main__':
    unittest.main()
