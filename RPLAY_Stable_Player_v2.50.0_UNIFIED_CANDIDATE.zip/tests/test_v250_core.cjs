'use strict';
/* v2.5.0 browser-core features: EXTINF modes, save-ledger event contract with
   real hashing, URL redaction, FIFO queue order shadow, resume uri cache. */
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),vm=require('vm'),{webcrypto}=require('node:crypto');
const source=fs.readFileSync(path.join(__dirname,'../rplay-stable-player-extension/content.js'),'utf8');
const H=require('../src/hls_transport.js');
const rspPartCommit=vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../src/part_commit_core.js'),'utf8')+'\nrspPartCommit',{});
function world(env={}){
 const code=source.slice(source.indexOf('  function recTrackSave'),source.indexOf('  /* ================= v1.11.0: AudioRecorder'));
 const classes=source.slice(source.indexOf('  class AudioRecorder'),source.indexOf('  /* ==== RSP RECORDING CORE',source.indexOf('  class AudioRecorder')));
 const c=vm.createContext({Blob,crypto:webcrypto,Date,Set,Map,Promise,console,HLS:H,RspSha256:require('../src/sha256.js'),rspPartCommit,RECENV:{download:async()=>undefined,backupPart:async()=>{},...env},REC_REQ_MIN_GAP_MS:0,REC_QUEUE_WARN_MS:60000});
 vm.runInContext(code+classes+';globalThis.api={RecPartSink,Recorder,AudioRecorder,recTrackSave,recWaitSaves,recRedactUrl,recLedgerStage,recLedgerStatus,recSha256Hex};',c);return c.api;
}
const base='https://fixture/live.m3u8',playlist=s=>'#EXTM3U\n#EXT-X-TARGETDURATION:1\n'+s;
test('v2.5.0 rfc EXTINF mode rejects missing EXTINF, legacy counts it',()=>{
 assert.throws(()=>H.parse(playlist('a.ts'),base,'rfc'),/HLS_EXTINF_REQUIRED/);
 assert.equal(H.parse(playlist('a.ts'),base,'legacy').segments.length,1);
 assert.equal(H.parse(playlist('#EXTINF:1,\na.ts'),base,'rfc').segments.length,1);
});
test('v2.5.0 redactUrl strips signature queries and fragments only for output',()=>{
 const a=world();
 assert.equal(a.recRedactUrl('https://cdx/seg.ts?X-Amz-Signature=SECRET&key2=K#f'),'https://cdx/seg.ts');
 assert.equal(a.recRedactUrl('https://cdx/seg.ts'),'https://cdx/seg.ts');
 assert.equal(a.recRedactUrl(''),'');
});
test('v2.5.0 RecPartSink close hashes bytes and reports FILE_CLOSED with hashHex',async()=>{
 const a=world(),dir=directory();
 const p=new a.RecPartSink('x.ts',dir,'ts');p.push(new Uint8Array([1,2,3,4,5]));
 const r=await p.close();
 assert(r.confirmed);assert.equal(r.stage,'FILE_CLOSED');
 const {createHash}=require('node:crypto');
 assert.equal(r.hashHex,createHash('sha256').update(Buffer.from([1,2,3,4,5])).digest('hex'));
});
test('v2.5.0 memory-mode part hash is computed even without folder handle',async()=>{
 const a=world({download:async b=>({confirmed:true,stage:'OPFS_STAGED'})});
 const p=new a.RecPartSink('x.ts',null,'ts');p.push(new Uint8Array([9,9,9]));
 const r=await p.close();
 assert(r.confirmed);assert.equal(r.stage,'OPFS_STAGED');
 const {createHash}=require('node:crypto');
 assert.equal(r.hashHex,createHash('sha256').update(Buffer.from([9,9,9])).digest('hex'));
});
test('v2.5.0 save ledger contract records stages in order without skipping',async()=>{
 const a=world();
 const r=Object.create(a.Recorder.prototype);
 Object.assign(r,{partOpen:true,bytes:3,segCount:1,partExt:'ts',partName:'x.ts',fileStartedAt:Date.now(),partsLog:[],filesSaved:0,filesByExt:{},partIndex:0,log:()=>{},
  partIO:{close:async()=>({confirmed:true,stage:'FILE_CLOSED',hashHex:'deadbeef'.repeat(8)})}});
 await r.closePart();
 const e=r.partsLog[0];
 assert.equal(e.saveState,'FILE_CLOSED');
 assert.deepEqual(Array.from(e.stages.map(s=>s.stage)),['REQUESTED','FILE_WRITTEN','HASHED']);
 assert.equal(e.sha256,'deadbeef'.repeat(8));
 assert.equal(e.structureValidated,true);
 assert.equal(e.ledgerStatus,'CONFIRMED_HASHED_STRUCTURE');
});
test('v2.5.0 browser ledger separates OPFS_STAGED as FILE_WRITTEN+BROWSER_DONE',async()=>{
 const a=world();
 const r=Object.create(a.Recorder.prototype);
 Object.assign(r,{partOpen:true,bytes:2,segCount:1,partExt:'ts',partName:'y.ts',fileStartedAt:Date.now(),partsLog:[],filesSaved:0,filesByExt:{},partIndex:0,log:()=>{},
  partIO:{close:async()=>({confirmed:true,stage:'OPFS_STAGED'})}});
 await r.closePart();
 const e=r.partsLog[0];
 assert.deepEqual(Array.from(e.stages.map(s=>s.stage)),['REQUESTED','FILE_WRITTEN','BROWSER_DONE']);
 assert.equal(e.ledgerStatus,'CONFIRMED_UNHASHED'); // HASHED absent — never faked
});
test('v2.5.0 failed part close is recorded as failed, not SUCCESS',async()=>{
 const a=world();
 const r=Object.create(a.Recorder.prototype);
 Object.assign(r,{partOpen:true,bytes:2,segCount:1,partExt:'ts',partName:'z.ts',fileStartedAt:Date.now(),partsLog:[],filesSaved:0,partIndex:0,log:()=>{},
  partIO:{close:async()=>{throw Error('quota')}}});
 await r.closePart();
 const e=r.partsLog[0];
 assert.equal(e.saveState,'failed');assert.equal(e.ledgerStatus,'failed');
 assert.deepEqual(Array.from(e.stages.map(s=>s.stage)),['REQUESTED']);
});
test('v2.5.0 recorder drain preserves FIFO order (shadow proof)',async()=>{
 const {recording}=require('./helpers_hls.cjs');
 const ts=Buffer.alloc(376);ts[0]=ts[188]=0x47;
 const segs=[];
 for(let i=0;i<6;i++)segs.push('#EXT-X-MEDIA-SEQUENCE:'+(10+i)+'\n#EXTINF:1,\nq'+i+'.ts\n');
 const list=i=>'#EXTM3U\n#EXT-X-TARGETDURATION:1\n'+segs[Math.min(i,segs.length-1)];
 let n=0;const order=[];
 const w=recording(base,async u=>{
  if(u.includes('m3u8')){const i=Math.min(n,5);n++;return new Response(list(i));}
  order.push(u.split('/').pop().split('?')[0]);
  return new Response(ts,{status:200});
 });
 const r=w.video;
 for(let i=0;i<6;i++){await r.pollPlaylist();await r.drain();}
 // every fetch happened in playlist declaration order (q0..q5, no reordering)
 assert.deepEqual(order,['q0.ts','q1.ts','q2.ts','q3.ts','q4.ts','q5.ts']);
 assert.equal(r.segTotal,6);
});
test('v2.5.0 reset keeps uri cache only when asked (resume semantics)',()=>{
 const o={seen:new Set(),queue:[]};
 H.enqueue(o,H.parse(playlist('a.ts'),base),base);
 assert.ok(o._hlsUris&&o._hlsUris.size===1);
 H.reset(o,true); // resume: keep recorded-path cache
 assert.ok(o._hlsUris&&o._hlsUris.size===1);
 H.reset(o);      // fresh start: clear
 assert.equal(o._hlsUris,null);
});
function directory(){let data=[];const state={size:0,closed:false};
 const writer={write:async b=>data.push(new Uint8Array(b)),close:async()=>{state.closed=true;state.size=data.reduce((n,b)=>n+b.length,0);},abort:async()=>{}};
 return {state,getFileHandle:async()=>({createWritable:async()=>writer,getFile:async()=>new Blob([Buffer.concat(data.map(Buffer.from))])})};
}
