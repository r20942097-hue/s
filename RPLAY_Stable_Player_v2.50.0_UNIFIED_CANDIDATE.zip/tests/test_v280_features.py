"""v2.8.0 feature acceptance:
1. Butter token generation (AES-128-CBC, exact byte parity with WebCrypto) and
   M3U8 403 automatic Butter header retry with authEvidence.butterSent=True.
2. Session streamStartTime 10-minute (600s) threshold tracking (learned from
   rplay_watcher v0.5.0 SessionManager: <=600s -> same_session_resumed,
   >600s -> new_session_split) recorded in sessionTrackingEvidence.
3. 4-layer ErrorKind taxonomy classification (SOURCE, NETWORK, AUTH, PLATFORM,
   COMPATIBILITY, INTERNAL) recorded in errorTaxonomyEvidence.
Local HTTP only — VM-safe."""
import http.server,threading,tempfile,pathlib,subprocess,sys,json,unittest,time
import importlib.util
R=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('v280feat',R/'rplay_dl.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


class UnitV280Features(unittest.TestCase):
    def test_butter_token_deterministic_and_cached(self):
        t1=m.generate_butter_token(now_s=1792946308)
        t2=m.generate_butter_token(now_s=1792946310)  # same 360s bucket (4980406)
        t3=m.generate_butter_token(now_s=1792946308+360)  # next 360s bucket
        self.assertEqual(len(t1),128)
        self.assertEqual(t1,t2)
        self.assertNotEqual(t1,t3)

    def test_parse_stream_start_sec_formats(self):
        self.assertEqual(m.parse_stream_start_sec('2026-10-25T10:00:00Z'),1792922400.0)
        self.assertEqual(m.parse_stream_start_sec(1792922400),1792922400.0)
        self.assertEqual(m.parse_stream_start_sec(1792922400000),1792922400.0)
        self.assertIsNone(m.parse_stream_start_sec(None))
        self.assertIsNone(m.parse_stream_start_sec(''))

    def test_session_change_10min_threshold(self):
        # <= 600s -> same_session_resumed (TEST-X-002 equivalent)
        r1=m.classify_session_change('2026-10-25T10:00:00Z','2026-10-25T10:05:00Z',600)
        self.assertEqual(r1['changed'],True)
        self.assertEqual(r1['gapSec'],300)
        self.assertEqual(r1['classification'],'same_session_resumed')
        # > 600s -> new_session_split (TEST-X-003 equivalent)
        r2=m.classify_session_change('2026-10-25T10:00:00Z','2026-10-25T10:15:00Z',600)
        self.assertEqual(r2['changed'],True)
        self.assertEqual(r2['gapSec'],900)
        self.assertEqual(r2['classification'],'new_session_split')
        # identical -> unchanged
        r3=m.classify_session_change('2026-10-25T10:00:00Z','2026-10-25T10:00:00Z',600)
        self.assertEqual(r3['changed'],False)
        self.assertEqual(r3['classification'],'unchanged')

    def test_error_taxonomy_evidence_structure(self):
        tax=m.error_taxonomy_evidence({'SOURCE':2,'NETWORK':1,'AUTH':0})
        self.assertEqual(tax['counts']['SOURCE'],2)
        self.assertEqual(tax['counts']['NETWORK'],1)
        self.assertEqual(tax['recoverableCount'],3)
        self.assertEqual(tax['provenance'],'rplay_watcher_error_kind_v050')


class E2EV280Features(unittest.TestCase):
    def test_cli_m3u8_403_butter_retry_succeeds_and_records_evidence(self):
        """M3U8が初回403を返した際、Butterトークン付きで自動再試行して成功し、
        authEvidence.butterSent=True と errorTaxonomyEvidence が記録される。"""
        playlist=('#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:0\n'
                  '#EXTINF:1,\na.ts\n#EXT-X-ENDLIST\n')
        seg=b'\x47'*(188*20)
        m3u8_hits=[]
        play_body={'streamState':'live','accessible':True,'allowAnonymous':True,
                   'title':'Butter配信','streamStartTime':'2026-10-25T10:00:00Z'}
        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self,*a):pass
            def _send(s,code,body=b'',headers=None):
                s.send_response(code)
                for k,v in (headers or {}).items():s.send_header(k,v)
                s.send_header('Content-Length',str(len(body)));s.end_headers();s.wfile.write(body)
            def do_GET(s):
                path=s.path.split('?')[0]
                if path=='/api/live/play':
                    s._send(200,json.dumps(play_body).encode());return
                if path=='/live.m3u8':
                    butter=s.headers.get('Butter') or ''
                    m3u8_hits.append(butter)
                    if not butter:
                        s._send(403,b'Forbidden without Butter');return
                    s._send(200,playlist.encode());return
                if path=='/a.ts':
                    s._send(200,seg);return
                s._send(404)
        srv=http.server.ThreadingHTTPServer(('127.0.0.1',0),H)
        threading.Thread(target=srv.serve_forever,daemon=True).start()
        url='http://127.0.0.1:%d'%srv.server_port
        try:
            with tempfile.TemporaryDirectory() as d:
                cmd=[sys.executable,str(R/'rplay_dl.py'),'a'*24,'--api',url+'/api',
                     '--m3u8',url+'/live.m3u8','--no-follow','--no-flv','--mux','no',
                     '--out',d,'--info-json']
                p=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                self.assertTrue(any(len(b)==128 for b in m3u8_hits),m3u8_hits)
                info=json.loads(next(pathlib.Path(d).glob('*_info.json')).read_text())
                self.assertEqual(info['authEvidence']['butterSent'],True)
                self.assertIn('sessionTrackingEvidence',info)
                self.assertEqual(info['sessionTrackingEvidence']['initialStreamStartSec'],1792922400.0)
                self.assertEqual(info['sessionTrackingEvidence']['thresholdSec'],600)
                self.assertIn('errorTaxonomyEvidence',info)
        finally:
            srv.shutdown();srv.server_close()


if __name__=='__main__':unittest.main()
