import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class TestV2460CliAddonParity(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rplay_dl = _load_module("rplay_dl_v2460", ROOT / "rplay_dl.py")
        cls.acc = _load_module("acc_v2460", ROOT / "scripts" / "acceptance_report.py")

    def test_hls_parse_counts_scte35_and_cue_markers_and_ad_keyword_filters_segments(self):
        dl_mod = self.rplay_dl
        m3u8 = (
            "#EXTM3U\n"
            "#EXT-X-VERSION:3\n"
            "#EXT-X-TARGETDURATION:4\n"
            "#EXT-X-MEDIA-SEQUENCE:100\n"
            "#EXTINF:2.0,\n"
            "seg_100.ts\n"
            "#EXT-X-DATERANGE:ID=\"ad-1\",START-DATE=\"2026-10-27T00:00:00Z\",SCTE35-OUT=0xFC30\n"
            "#EXT-X-CUE-OUT:15.0\n"
            "#EXTINF:2.0,\n"
            "ad_bumper_101.ts?token=SECRET\n"
            "#EXT-X-CUE-IN\n"
            "#EXTINF:2.0,\n"
            "seg_102.ts\n"
        )
        parsed = dl_mod.hls_parse(m3u8, "https://cdn.example/live/index.m3u8")
        self.assertEqual(parsed["scte35"]["indicatorTags"], 3)
        self.assertEqual(len(parsed["segments"]), 3)

        class DummyOwner:
            def __init__(self, pattern):
                import re
                self.seen = set()
                self.queue = []
                self._hls_state = {}
                self._ad_keyword_re = re.compile(pattern) if pattern else None

        owner = DummyOwner(r"ad_bumper")
        added, missing = dl_mod.hls_enqueue(owner, parsed, "https://cdn.example/live/index.m3u8")
        self.assertEqual(added, 2)
        self.assertEqual(missing, 0)
        self.assertEqual(len(owner.queue), 2)
        self.assertEqual([item["name"] for item in owner.queue], [
            "https://cdn.example/live/seg_100.ts",
            "https://cdn.example/live/seg_102.ts",
        ])
        self.assertEqual(owner._hls_state["scte35Indicators"], 3)
        self.assertEqual(owner._hls_state["adFilteredSegments"], 1)

    def test_dl_stop_mux_audio_parts_and_default_fallback(self):
        dl_mod = self.rplay_dl
        with tempfile.TemporaryDirectory() as tmp:
            v1, v2, a1, a2 = [os.path.join(tmp, n) for n in ("v1.ts", "v2.ts", "a1.ts", "a2.ts")]
            for vp in (v1, v2):
                subprocess.run([
                    "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                    "-f", "lavfi", "-i", "testsrc=size=160x120:rate=10:duration=1.0",
                    "-c:v", "libx264", "-bf", "0", "-pix_fmt", "yuv420p", "-g", "10",
                    "-f", "mpegts", vp,
                ], check=True)
            for ap in (a1, a2):
                subprocess.run([
                    "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                    "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000:duration=1.0",
                    "-c:a", "aac", "-b:a", "64k",
                    "-f", "mpegts", ap,
                ], check=True)

            import hashlib
            def _part_entry(path, kind=None):
                b = Path(path).read_bytes()
                e = {
                    "file": os.path.basename(path),
                    "ext": "ts",
                    "bytes": len(b),
                    "sha256": hashlib.sha256(b).hexdigest(),
                    "status": "committed",
                    "segments": 1,
                }
                if kind:
                    e["kind"] = kind
                return e

            class Args:
                oid = "a" * 24
                out = tmp
                ua = dl_mod.UA_DEFAULT
                m3u8 = ""
                flv = ""
                api = "https://api.rplay.live"
                token = ""
                refresh_token = ""
                user_oid = ""
                wait_schedule = False
                first_variant = False
                mux = "auto"
                join_parts = "auto"
                mux_audio_parts = True
                concat_parts = "no"
                name_tpl = ""
                audio_only = False
                audio_both = True
                min_free_mb = 0
                min_free_inodes = 0
                segindex = False
                webhook = ""
                extinf_mode = "legacy"
                qaudit = "no"
                max_size_mb = 600
                no_follow = True
                standby_min = 0
                no_flv = True
                max_hours = 0
                info_json = True
                no_backlog = True
                split_min = 0
                split_on_discontinuity = False
                inherit_query = False
                dec_key = ""
                dec_key_file = ""
                dec_key_env = ""
                dec_backend = "auto"
                ad_keyword = "ad_filler"

            d = dl_mod.Dl(Args())
            d.parts_log = [_part_entry(v1), _part_entry(v2)]
            d.audio_parts_log = [_part_entry(a1, "audio"), _part_entry(a2, "audio")]
            d.seg_total = 2
            d.a_seg_total = 2
            d.bytes_total = sum(p["bytes"] for p in d.parts_log)
            d.a_bytes_total = sum(p["bytes"] for p in d.audio_parts_log)
            d.stop("test_mux_audio_parts")
            self.assertEqual(d.aggregate_evidence.get("status"), "JOINED_DECODE_VERIFIED")
            self.assertTrue(d.aggregate_evidence.get("audioMuxed"))
            self.assertEqual(d.aggregate_evidence.get("audioParts"), 2)
            joined_file = os.path.join(tmp, d.aggregate_evidence["file"])
            self.assertTrue(os.path.isfile(joined_file))

            info_files = list(Path(tmp).glob("*_info.json"))
            self.assertEqual(len(info_files), 1)
            info_data = json.loads(info_files[0].read_text(encoding="utf-8"))
            self.assertIn("adFilterEvidence", info_data)
            self.assertTrue(info_data["adFilterEvidence"]["adKeywordConfigured"])

            # Verify acceptance_report.py summarizes the new evidence blocks without triggering secret tripwire
            rep_md = self.acc.build_report(tmp)
            for blk in (
                "playlistParseGraceEvidence",
                "segmentTransferRetryEvidence",
                "adFilterEvidence",
                "aggregationEvidence",
            ):
                self.assertIn(f"| {blk} | 在 |", rep_md)
            self.assertEqual(self.acc.secret_tripwire(rep_md), [])


if __name__ == "__main__":
    unittest.main()
