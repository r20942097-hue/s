"""v2.37.0 feature acceptance (cat-catch 3rd wave — N-01..N-04):
1. N-01/N-02: pure-Python AES-128-CBC decryptor — NIST SP 800-38A CBC-AES128 known answers,
   strict PKCS7 fail-closed validation, openssl fast-path backend, and byte-identity of the
   openssl/python/JS backends on identical ciphertext.
2. N-02: CLI AES-128 acquisition E2E over local HTTP — an encrypted media playlist with an
   #EXT-X-KEY endpoint is downloaded and decrypted to byte-identical TS with
   decryptionEvidence/continuityCounterEvidence emitted and ZERO key material anywhere in
   the output directory (zero-secret scan). --dec-key auto fetches keys with the
   official-player-equivalent headers; 403 classifies as HLS_DEC_KEY_DENIED.
3. N-03: continuityCounterEvidence cross-language mirror (already covered in core) plus the
   CLI-side accumulation contract (audit-only, never destructive).
4. Packaging regression: rplay_join.py at tree root equals src/join_parts.py.
"""
import importlib.util, pathlib, unittest, subprocess, sys, json, hashlib, tempfile, os, re
import http.server, threading
from unittest import mock
R = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('cli', R / 'rplay_dl.py'); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

NIST_KEY = bytes.fromhex('2b7e151628aed2a6abf7158809cf4f3c')
NIST_IV = bytes.fromhex('000102030405060708090a0b0c0d0e0f')
NIST_CT = bytes.fromhex('7649abac8119b246cee98e9b12e9197d5086cb9b507219ee95db113a917678b273bed6b8e3c1743b7116e69e222295163ff1caa1681fac09120eca307586e1a7')
NIST_PT = bytes.fromhex('6bc1bee22e409f96e93d7e117393172aae2d8a571e03ac9c9eb76fac45af8e5130c81c46a35ce411e5fbc1191a0a52eff69f2445df4f9b17ad2b417be66c3710')
# NIST SP 800-38A F.1.1 CBC-AES128.Encrypt (same key, same IV)
NIST_ENC_PT = NIST_PT
NIST_ENC_CT = NIST_CT


def ts_packet(cc, pid, afc=1, tei=False):
    b = bytearray(188)
    b[0] = 0x47
    b[1] = (0x80 if tei else 0x00) | 0x40 | ((pid >> 8) & 0x1f)
    b[2] = pid & 0xff
    b[3] = (afc << 4) | (cc & 0xf)
    return bytes(b)


def nist_encrypt_reference(key, iv, plaintext):
    """Reference AES-128-CBC encryptor via Node WebCrypto (single source of truth for
    fixtures; no Python crypto dependency needed)."""
    js = ("const c=require('node:crypto').webcrypto;" +
          "const k=Buffer.from(process.argv[1],'hex'),iv=Buffer.from(process.argv[2],'hex');"+
          "const pt=Buffer.from(process.argv[3],'hex');"+
          "c.subtle.importKey('raw',k,{name:'AES-CBC'},false,['encrypt'])"+
          ".then(x=>c.subtle.encrypt({name:'AES-CBC',iv},x,pt))"+
          ".then(b=>process.stdout.write(Buffer.from(b).toString('hex')));")
    r = subprocess.run(['node', '-e', js, key.hex(), iv.hex(), plaintext.hex()], capture_output=True, text=True, cwd=R, timeout=20)
    assert r.returncode == 0, r.stderr
    return bytes.fromhex(r.stdout.strip())


class Aes128Decrypt(unittest.TestCase):
    def test_nist_kat_raw_and_strict_padding(self):
        raw = m.hls_aes128_cbc_decrypt_py(NIST_KEY, NIST_IV, NIST_CT)
        self.assertEqual(raw, NIST_PT)
        # Unpadded NIST vector must fail strict PKCS7 through the auto pipeline
        with self.assertRaisesRegex(ValueError, 'HLS_DECRYPT_PADDING'):
            m.hls_aes128_cbc_decrypt(NIST_KEY, NIST_IV, NIST_CT)
        # PKCS7 removal contract
        for n in (1, 7, 16):
            buf = bytearray(b'A' * 32)
            for i in range(32 - n, 32):
                buf[i] = n
            self.assertEqual(len(m.hls_remove_pkcs7(bytes(buf))), 32 - n)
        for bad in (b'\x00' * 32, b'A' * 31 + b'\x11', b'A' * 30 + b'\x02\x03'):
            with self.assertRaisesRegex(ValueError, 'HLS_DECRYPT_PADDING'):
                m.hls_remove_pkcs7(bad)

    def test_argument_validation_fail_closed(self):
        for args in [(b'short', NIST_IV, NIST_CT), (NIST_KEY, b'short', NIST_CT),
                     (NIST_KEY, NIST_IV, b'x' * 31), (NIST_KEY, NIST_IV, b'')]:
            with self.subTest(args=args), self.assertRaisesRegex(ValueError, 'HLS_DECRYPT_(KEY|IV|BLOCK_SIZE)'):
                m.hls_aes128_cbc_decrypt(*args)

    def test_backends_agree_on_real_pkcs7_ciphertext(self):
        plain = bytes((i * 7 + 11) & 0xff for i in range(2000))
        ct = nist_encrypt_reference(NIST_KEY, NIST_IV, plain)
        via_openssl = m.hls_aes128_cbc_decrypt(NIST_KEY, NIST_IV, ct, backend='openssl')
        via_python = m.hls_aes128_cbc_decrypt(NIST_KEY, NIST_IV, ct, backend='python')
        js = ("const H=require('./src/hls_transport.js');"+
              "const k=Buffer.from(process.argv[1],'hex'),iv=Buffer.from(process.argv[2],'hex');"+
              "const ct=Buffer.from(process.argv[3],'hex');"+
              "process.stdout.write(Buffer.from(H.decryptCbc(new Uint8Array(k),new Uint8Array(iv),new Uint8Array(ct))).toString('hex'));")
        r = subprocess.run(['node', '-e', js, NIST_KEY.hex(), NIST_IV.hex(), ct.hex()], capture_output=True, text=True, cwd=R, timeout=20)
        self.assertEqual(r.returncode, 0, r.stderr)
        via_js = bytes.fromhex(r.stdout.strip())
        self.assertEqual(via_openssl, plain)
        self.assertEqual(via_python, plain)
        self.assertEqual(via_js, plain, 'JS software decryptor must agree byte-for-byte')

    def test_openssl_missing_tool_falls_back_to_python(self):
        plain = b'\x47' + b'\x00' * 300
        ct = nist_encrypt_reference(NIST_KEY, NIST_IV, plain)
        with mock.patch.object(m, '_OPENSSL_BIN', None), \
             mock.patch.object(m, '_OPENSSL_CHECKED', True):
            self.assertEqual(m.hls_aes128_cbc_decrypt(NIST_KEY, NIST_IV, ct, backend='auto'), plain)

    def test_truncated_segment_fails_closed(self):
        ct = nist_encrypt_reference(NIST_KEY, NIST_IV, b'\x47' + b'\x00' * 300)
        with self.assertRaisesRegex(ValueError, 'HLS_DECRYPT_BLOCK_SIZE'):
            m.hls_aes128_cbc_decrypt(NIST_KEY, NIST_IV, ct[:-8])


class ParseAes128(unittest.TestCase):
    PL = ('#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:4\n'
          '#EXT-X-KEY:METHOD=AES-128,URI="https://cdn/key?token=t",IV=0x000102030405060708090a0b0c0d0e0f\n'
          'seg0.ts\nseg1.ts\n#EXT-X-KEY:METHOD=NONE\nseg2.ts\n#EXT-X-ENDLIST\n')

    def test_key_fields_per_segment(self):
        p = m.hls_parse(self.PL, 'https://cdn/live.m3u8', allow_aes128=True)
        self.assertEqual(p['segments'][0]['keyUri'], 'https://cdn/key?token=t')
        self.assertEqual(p['segments'][0]['keyIvHex'], '0x000102030405060708090a0b0c0d0e0f')
        self.assertEqual(p['segments'][1]['keyUri'], 'https://cdn/key?token=t')
        self.assertNotIn('keyUri', p['segments'][2])
        # default stays fail-closed
        with self.assertRaisesRegex(ValueError, 'HLS_ENCRYPTED_UNSUPPORTED'):
            m.hls_parse(self.PL, 'https://cdn/live.m3u8')

    def test_explicit_unsupported_classifications(self):
        with self.assertRaisesRegex(ValueError, 'HLS_SAMPLE_AES_UNSUPPORTED'):
            m.hls_parse('#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-KEY:METHOD=SAMPLE-AES,URI="k"\ns.ts\n', 'https://c/l', allow_aes128=True)
        with self.assertRaisesRegex(ValueError, 'HLS_ENCRYPTED_MAP_UNSUPPORTED'):
            m.hls_parse('#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-KEY:METHOD=AES-128,URI="k"\n#EXT-X-MAP:URI="i.mp4"\ns.m4s\n', 'https://c/l', allow_aes128=True)
        with self.assertRaisesRegex(ValueError, 'HLS_BAD_KEY'):
            m.hls_parse('#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-KEY:METHOD=AES-128\ns.ts\n', 'https://c/l', allow_aes128=True)
        with self.assertRaisesRegex(ValueError, 'HLS_BAD_KEY_IV'):
            m.hls_parse('#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-KEY:METHOD=AES-128,URI="k",IV=0x01\ns.ts\n', 'https://c/l', allow_aes128=True)


class CliAes128E2E(unittest.TestCase):
    """Full CLI E2E: encrypted playlist + key endpoint over local HTTP, byte-identical
    output, evidence blocks, and a zero-secret scan over every produced file."""

    def _server(self, segments_plain, key, key_status=200, key_bytes=None):
        state = {'key_headers': None, 'key_requests': 0}
        enc = {i: nist_encrypt_reference(key, i.to_bytes(16, 'big'), seg)
               for i, seg in enumerate(segments_plain)}
        body_pl = b'#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:0\n' + \
                  b'#EXT-X-KEY:METHOD=AES-128,URI="http://127.0.0.1:%d/key"\n'  # port patched below
        holder = {}

        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_GET(s):
                path = s.path.split('?')[0]
                if path == '/live.m3u8':
                    body = (b'#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:0\n'
                            + ('#EXT-X-KEY:METHOD=AES-128,URI="http://127.0.0.1:%d/key"\n' % holder['port']).encode()
                            + b''.join(b'#EXTINF:1,\nseg%d.ts\n' % i for i in range(len(segments_plain)))
                            + b'#EXT-X-ENDLIST\n')
                elif path == '/key':
                    state['key_headers'] = {k.lower(): v for k, v in s.headers.items()}
                    state['key_requests'] += 1
                    s.send_response(key_status)
                    kb = key_bytes if key_bytes is not None else key
                    body = kb if key_status == 200 else b''
                    if key_status == 200:
                        body = kb if key_bytes is not None else key
                    else:
                        body = b''
                    s.send_header('Content-Length', str(len(body)))
                    s.end_headers()
                    s.wfile.write(body)
                    return
                elif path.startswith('/seg'):
                    body = enc[int(path[4])]
                else:
                    body = json.dumps({'streamState': 'live', 'accessible': True, 'allowAnonymous': True,
                                       'title': 'offline-fixture'}).encode()
                s.send_response(200)
                s.send_header('Content-Length', str(len(body)))
                s.end_headers()
                s.wfile.write(body)

        srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        holder['port'] = srv.server_port
        t = threading.Thread(target=srv.serve_forever, daemon=True)
        t.start()
        return srv, state, enc

    def test_dec_key_hex_produces_identical_ts_with_evidence_and_zero_secret(self):
        segs = [ts_packet(0, 0x100) + ts_packet(1, 0x100),
                ts_packet(2, 0x100) + ts_packet(3, 0x100)]
        key = bytes(range(16))
        srv, state, enc = self._server(segs, key)
        try:
            with tempfile.TemporaryDirectory() as d:
                url = 'http://127.0.0.1:%d' % srv.server_port
                r = subprocess.run([sys.executable, str(R / 'rplay_dl.py'), 'a' * 24,
                                    '--api', url + '/api', '--m3u8', url + '/live.m3u8',
                                    '--no-follow', '--no-flv', '--mux', 'no', '--info-json',
                                    '--dec-key', key.hex(), '--out', d],
                                   capture_output=True, text=True, timeout=60)
                self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
                ts = sorted(pathlib.Path(d).glob('*.ts'))
                self.assertEqual(len(ts), 1, r.stdout)
                self.assertEqual(ts[0].read_bytes(), b''.join(segs), 'decrypted output must be byte-identical')
                info = json.loads(next(pathlib.Path(d).glob('*_info.json')).read_text())
                ev = info['decryptionEvidence']
                self.assertEqual(ev['enabled'], True)
                self.assertEqual(ev['method'], 'AES-128')
                self.assertEqual(ev['keySource'], 'arg')
                self.assertEqual(ev['keyCount'], 1)
                self.assertEqual(ev['segmentsDecrypted'], 2)
                self.assertEqual(ev['segmentsFailed'], 0)
                self.assertEqual(ev['bytesDecrypted'], sum(len(e) for e in enc.values()))
                self.assertIn(ev['zeroSecret'], 'decryption-key-never-recorded')
                self.assertTrue(ev['segmentsByBackend'].get('openssl', 0) + ev['segmentsByBackend'].get('python', 0) >= 2)
                cce = info['continuityCounterEvidence']
                self.assertEqual(cce['segmentsAudited'], 2)
                self.assertEqual(cce['continuityOk'], 2)
                self.assertEqual(cce['lostPacketEstimate'], 0)
                # zero-secret scan: the key hex must appear in NO produced file
                blob = b''.join(p.read_bytes() for p in pathlib.Path(d).iterdir() if p.is_file())
                self.assertNotIn(key.hex().encode(), blob)
                self.assertNotIn(key.hex().encode().upper(), blob)
                self.assertNotIn(key, blob.split(b'--dec-key')[0])  # raw key bytes never stored
                self.assertNotIn(key, blob)
        finally:
            srv.shutdown(); srv.server_close()

    def test_dec_key_env_and_forced_python_backend(self):
        segs = [ts_packet(5, 0x200) + ts_packet(6, 0x200)]
        key = bytes.fromhex('00112233445566778899aabbccddeeff')
        srv, state, enc = self._server(segs, key)
        try:
            with tempfile.TemporaryDirectory() as d:
                env = dict(os.environ, RSP_TEST_DEC_KEY=key.hex())
                url = 'http://127.0.0.1:%d' % srv.server_port
                r = subprocess.run([sys.executable, str(R / 'rplay_dl.py'), 'a' * 24,
                                    '--api', url + '/api', '--m3u8', url + '/live.m3u8',
                                    '--no-follow', '--no-flv', '--mux', 'no', '--info-json',
                                    '--dec-key-env', 'RSP_TEST_DEC_KEY', '--dec-backend', 'python',
                                    '--out', d], capture_output=True, text=True, timeout=120, env=env)
                self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
                ts = sorted(pathlib.Path(d).glob('*.ts'))
                self.assertEqual(len(ts), 1)
                self.assertEqual(ts[0].read_bytes(), b''.join(segs))
                info = json.loads(next(pathlib.Path(d).glob('*_info.json')).read_text())
                ev = info['decryptionEvidence']
                self.assertEqual(ev['keySource'], 'env')
                self.assertEqual(ev['segmentsByBackend'].get('python', 0), 1)
        finally:
            srv.shutdown(); srv.server_close()

    def test_dec_key_auto_fetches_with_official_headers(self):
        segs = [ts_packet(0, 0x100)]
        key = bytes.fromhex('feed00112233445566778899aabbccdd')
        srv, state, enc = self._server(segs, key)
        try:
            with tempfile.TemporaryDirectory() as d:
                url = 'http://127.0.0.1:%d' % srv.server_port
                r = subprocess.run([sys.executable, str(R / 'rplay_dl.py'), 'a' * 24,
                                    '--api', url + '/api', '--m3u8', url + '/live.m3u8',
                                    '--no-follow', '--no-flv', '--mux', 'no', '--info-json',
                                    '--dec-key', 'auto', '--user-oid', 'tester-oid', '--out', d],
                                   capture_output=True, text=True, timeout=60)
                self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
                ts = sorted(pathlib.Path(d).glob('*.ts'))
                self.assertEqual(len(ts), 1)
                self.assertEqual(ts[0].read_bytes(), b''.join(segs))
                self.assertEqual(state['key_requests'], 1)
                self.assertEqual(state['key_headers'].get('rplay-private-content-requestor'), 'tester-oid')
                self.assertIn('age', state['key_headers'])
                age = int(state['key_headers']['age'])
                self.assertTrue(1 <= age <= 4999)
                info = json.loads(next(pathlib.Path(d).glob('*_info.json')).read_text())
                self.assertEqual(info['decryptionEvidence']['keySource'], 'auto')
        finally:
            srv.shutdown(); srv.server_close()

    def test_dec_key_auto_403_classifies_key_denied(self):
        segs = [ts_packet(0, 0x100)]
        key = bytes(range(16))
        srv, state, enc = self._server(segs, key, key_status=403)
        try:
            with tempfile.TemporaryDirectory() as d:
                url = 'http://127.0.0.1:%d' % srv.server_port
                r = subprocess.run([sys.executable, str(R / 'rplay_dl.py'), 'a' * 24,
                                    '--api', url + '/api', '--m3u8', url + '/live.m3u8',
                                    '--no-follow', '--no-flv', '--mux', 'no',
                                    '--dec-key', 'auto', '--out', d],
                                   capture_output=True, text=True, timeout=60)
                out = r.stdout + r.stderr
                self.assertIn('HLS_DEC_KEY_DENIED', out)
                self.assertIn('403', out)
                self.assertEqual(list(pathlib.Path(d).glob('*.ts')), [], 'no TS must be written when the key is denied')
        finally:
            srv.shutdown(); srv.server_close()

    def test_encrypted_playlist_without_key_hints_new_flag(self):
        segs = [ts_packet(0, 0x100)]
        key = bytes(range(16))
        srv, state, enc = self._server(segs, key)
        try:
            with tempfile.TemporaryDirectory() as d:
                url = 'http://127.0.0.1:%d' % srv.server_port
                r = subprocess.run([sys.executable, str(R / 'rplay_dl.py'), 'a' * 24,
                                    '--api', url + '/api', '--m3u8', url + '/live.m3u8',
                                    '--no-follow', '--no-flv', '--mux', 'no', '--out', d],
                                   capture_output=True, text=True, timeout=60)
                out = r.stdout + r.stderr
                self.assertIn('HLS_ENCRYPTED_UNSUPPORTED', out)
                self.assertIn('--dec-key', out, 'the hint must point at the v2.37.0 flags')
        finally:
            srv.shutdown(); srv.server_close()


class PackagingGuard(unittest.TestCase):
    def test_rplay_join_py_matches_build_source(self):
        root = R / 'rplay_join.py'
        self.assertTrue(root.exists(), 'rplay_join.py must exist at tree root (v2.15.0 shipped without it)')
        self.assertEqual(root.read_bytes(), (R / 'src' / 'join_parts.py').read_bytes())
        sums = json.loads((R / 'SHA256SUMS.json').read_text())
        self.assertIn('rplay_join.py', sums)


if __name__ == '__main__':
    unittest.main()
