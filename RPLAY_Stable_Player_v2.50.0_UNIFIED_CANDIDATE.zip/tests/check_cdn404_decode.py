"""Reproducible local-HTTP recording/decode acceptance; no external service access."""
from pathlib import Path
import hashlib,http.server,json,subprocess,tempfile,threading
R=Path(__file__).resolve().parents[1]
def run(cmd,**kw):return subprocess.run(cmd,check=True,capture_output=True,text=True,timeout=60,**kw)
with tempfile.TemporaryDirectory(prefix='rsp-cdn404-') as tmp:
 p=Path(tmp);run(['ffmpeg','-v','error','-f','lavfi','-i','testsrc2=size=160x90:rate=25','-f','lavfi','-i','sine=sample_rate=48000','-t','4','-c:v','libx264','-preset','ultrafast','-g','25','-c:a','aac','-f','hls','-hls_time','1','-hls_list_size','0','-hls_segment_filename',str(p/'seg%d.ts'),str(p/'index.m3u8')])
 failures=[0];requests=[]
 class Handler(http.server.SimpleHTTPRequestHandler):
  def __init__(self,*args,**kwargs):super().__init__(*args,directory=tmp,**kwargs)
  def log_message(self,*args):pass
  def do_GET(self):
   requests.append(self.path)
   if self.path=='/seg0.ts' and failures[0]==0:
    failures[0]+=1;self.send_response(404);self.send_header('Content-Length','0');self.end_headers();return
   super().do_GET()
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
 try:
  runner="""const fs=require('node:fs'),{recording}=require('./tests/helpers_hls.cjs');(async()=>{const r=recording(process.argv[1]).video;await r.pollPlaylist();const until=Date.now()+15000;while(r.queue.length&&Date.now()<until){await r.drain();if(r.queue.length)await new Promise(x=>setTimeout(x,50));}await r.closePart();if(r.segFails||r.queue.length||r.parts.length!==1)throw Error('continuity failure');fs.writeFileSync(process.argv[2],Buffer.concat(r.parts));console.log(JSON.stringify({segments:r.segTotal,parts:r.parts.length,retries:r._cdn404Retries,recovered:r._cdn404Recovered}));})().catch(e=>{console.error(e);process.exitCode=1;});"""
  result=json.loads(run(['node','-e',runner,f'http://127.0.0.1:{server.server_port}/index.m3u8',str(p/'recorded.ts')],cwd=R).stdout)
  segments=[p/line.strip() for line in (p/'index.m3u8').read_text().splitlines() if line.strip() and not line.startswith('#')]
  expected=b''.join(x.read_bytes() for x in segments);actual=(p/'recorded.ts').read_bytes();assert actual==expected
  assert result['parts']==1 and result['recovered']==1 and result['retries']==1
  run(['ffmpeg','-v','error','-i',str(p/'recorded.ts'),'-f','null','-'])
  streams=json.loads(run(['ffprobe','-v','error','-show_entries','stream=codec_type','-of','json',str(p/'recorded.ts')]).stdout)['streams'];assert {x['codec_type'] for x in streams}=={'video','audio'}
  print(json.dumps({'local_http_cdn404':'PASS','byte_identity':'PASS','full_decode':'PASS','audio_and_video':'PASS','recording':result,'sha256':hashlib.sha256(actual).hexdigest(),'request_order':requests},indent=2))
 finally:server.shutdown();server.server_close();thread.join()
