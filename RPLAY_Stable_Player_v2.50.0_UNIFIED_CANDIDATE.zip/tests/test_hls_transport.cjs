'use strict';
const {test}=require('node:test'),a=require('node:assert/strict'),H=require('../src/hls_transport.js');
const base='https://fixture/live.m3u8',playlist=s=>'#EXTM3U\n#EXT-X-TARGETDURATION:1\n'+s;
const box=type=>Buffer.concat([Buffer.from([0,0,0,8]),Buffer.from(type)]),init=Buffer.concat([box('ftyp'),box('moov')]),fragment=Buffer.concat([box('moof'),box('mdat')]);
const owner=()=>({seen:new Set(),queue:[],pushData(x){this.partOpen=true;this.writes.push(Buffer.from(x));},writes:[],partOpen:false,async closePart(){this.partOpen=false;this.parts.push(this.writes);this.writes=[];},parts:[]});
test('explicit and implicit ranges resolve only adjacent same resource',()=>{const p=H.parse(playlist('#EXT-X-BYTERANGE:188@0\na.ts\n#EXT-X-BYTERANGE:188\na.ts\n'),base);a.deepEqual(p.segments.map(s=>s.range),[{offset:0,length:188},{offset:188,length:188}]);a.throws(()=>H.parse(playlist('#EXT-X-BYTERANGE:188\na.ts'),base),/IMPLICIT/);a.throws(()=>H.parse(playlist('#EXT-X-BYTERANGE:188@0\na.ts\n#EXT-X-BYTERANGE:188\nb.ts'),base),/IMPLICIT/);});
test('range limits, dangling range and unsafe integers reject whole playlist',()=>{for(const s of ['#EXT-X-BYTERANGE:0@0\na','#EXT-X-BYTERANGE:33554433@0\na','#EXT-X-BYTERANGE:1@9007199254740992\na','#EXT-X-BYTERANGE:188@0'])a.throws(()=>H.parse(playlist(s),base));});
test('MAP quoted commas, discontinuity and GAP are descriptor state',()=>{const p=H.parse(playlist('#EXT-X-DISCONTINUITY-SEQUENCE:7\n#EXT-X-MAP:URI="init,a.mp4",BYTERANGE="16@0"\na.m4s\n#EXT-X-DISCONTINUITY\n#EXT-X-GAP\nb.m4s'),base);a.equal(p.segments[0].map.uri,'https://fixture/init,a.mp4');a.equal(p.segments[1].discontinuity,8);a(p.segments[1].gap);});
test('encryption, unsupported delta and unsafe URL cannot be queued',()=>{for(const s of ['#EXT-X-KEY:METHOD=AES-128,URI="key"\na.ts','#EXT-X-SKIP:SKIPPED-SEGMENTS=2\na.ts','file:///tmp/a','#EXT-X-MAP:URI="init",BYTERANGE="16"\na.m4s'])a.throws(()=>H.parse(playlist(s),base));});
test('signed segment URL changes do not duplicate same sequence; stale rewind no longer re-records',()=>{
 // v2.5.0 generation recovery: same sequence + refreshed signature stays deduped;
 // a rewind to an already-recorded path is classified stale (no epoch bump, no
 // duplicate enqueue); a rewind to an unknown path is a reset (new epoch).
 const o=owner();H.enqueue(o,H.parse(playlist('#EXT-X-MEDIA-SEQUENCE:4\na.ts?sig=old'),base),base);
 H.enqueue(o,H.parse(playlist('#EXT-X-MEDIA-SEQUENCE:4\na.ts?sig=new'),base),base);
 a.equal(o.queue.length,1);
 H.enqueue(o,H.parse(playlist('#EXT-X-MEDIA-SEQUENCE:1\na.ts'),base),base);
 a.equal(o.queue.length,1); // stale: path /a.ts already recorded in this context
 a.equal(o._hlsRecovery.staleResponses,1);
 a.equal(o._hlsRecovery.lastKind,'stale');
 H.enqueue(o,H.parse(playlist('#EXT-X-MEDIA-SEQUENCE:0\nnew1.ts\nnew2.ts'),base),base);
 a.equal(o.queue.length,3); // reset: unknown paths advance the epoch
 a.notEqual(o.queue[0].hls.epoch,o.queue[2].hls.epoch);
 a.equal(o._hlsRecovery.sequenceResets,1);
});
test('v2.5.0 generation recovery: rotation, context switch, uri-bound trim',()=>{
 // rotation: same sequence numbers, entirely new paths → new epoch instead of silent drop
 const o=owner();H.enqueue(o,H.parse(playlist('#EXT-X-MEDIA-SEQUENCE:5\nseg5.ts'),base),base);
 a.equal(o.queue.length,1);
 H.enqueue(o,H.parse(playlist('#EXT-X-MEDIA-SEQUENCE:5\nother5.ts'),base),base);
 a.equal(o.queue.length,2);a.equal(o._hlsRecovery.uriRotations,1);
 a.notEqual(o.queue[0].hls.epoch,o.queue[1].hls.epoch);
 // context switch: a new playlist advances the epoch; the same immutable path is
 // deduped globally, a new path on the new playlist is recorded
 const o2=owner();H.enqueue(o2,H.parse(playlist('a.ts'),base),base);
 H.enqueue(o2,H.parse(playlist('a.ts'),'https://fixture/other.m3u8'),'https://fixture/other.m3u8');
 a.equal(o2.queue.length,1); // same path = already-recorded immutable data
 a.equal(o2._hlsRecovery.contextSwitches,1);
 H.enqueue(o2,H.parse(playlist('b.ts'),'https://fixture/other.m3u8'),'https://fixture/other.m3u8');
 a.equal(o2.queue.length,2);a.notEqual(o2.queue[0].hls.epoch,o2.queue[1].hls.epoch);
 // known-path filter also applies on plain progress (re-declared immutable data)
 const o3=owner();H.enqueue(o3,H.parse(playlist('#EXT-X-MEDIA-SEQUENCE:0\na.ts'),base),base);
 H.enqueue(o3,H.parse(playlist('#EXT-X-MEDIA-SEQUENCE:1\na.ts\nb.ts'),base),base);
 a.equal(o3.queue.length,2); // a.ts(seq0) + b.ts(seq2): a.ts re-declared at seq1 is skipped
 a.equal(o3.queue[1].hls.sequence,2);
});
test('queue overflow fails transactionally without dropping unseen descriptors',()=>{const o=owner();o.queue.length=4096;a.throws(()=>H.enqueue(o,H.parse(playlist('a.ts'),base),base),/QUEUE_LIMIT/);a.equal(o.seen.size,0);a.equal(o._hlsContext,undefined);});
test('GAP skipped, missed window counted and backlog never downloaded',()=>{const o=owner();o._skipBacklog=true;H.enqueue(o,H.parse(playlist('#EXT-X-MEDIA-SEQUENCE:1\na.ts'),base),base);a.equal(o.queue.length,0);const r=H.enqueue(o,H.parse(playlist('#EXT-X-MEDIA-SEQUENCE:4\n#EXT-X-GAP\nb.ts\nc.ts'),base),base);a.equal(r.missing,3);a.equal(o.queue.length,1);});
test('transport sends exact Range and accepts exact 206 body only',async()=>{let headers;const t=H.createTransfer(async(u,o)=>{headers=o.headers;return new Response(Buffer.alloc(188),{status:206,headers:{'content-range':'bytes 188-375/1000','content-length':'188'}})});const r=await t.request({uri:base,range:{offset:188,length:188}});a.equal(headers.Range,'bytes=188-375');a.equal(r.bytes.length,188);a.equal(t.pending,0);});
for(const [name,status,headers,body,error] of [
 ['ignored range',200,{},'x','HLS_RANGE_IGNORED'],['wrong range',206,{'content-range':'bytes 0-187/1000'},Buffer.alloc(188),'HLS_CONTENT_RANGE'],['short range',206,{'content-range':'bytes 188-375/1000'},'x','HLS_RANGE_LENGTH'],['encoded range',206,{'content-encoding':'gzip'},'x','HLS_ENCODING_UNSUPPORTED']])test(name+' is rejected',async()=>{const t=H.createTransfer(async()=>new Response(body,{status,headers}));a.equal((await t.request({uri:base,range:{offset:188,length:188}})).error,error);a.equal(t.pending,0);});
test('unsolicited 206 and header/body size violations are rejected',async()=>{for(const res of [new Response('x',{status:206}),new Response('xxxxx',{headers:{'content-length':'5'}}),new Response('xxxxx')]){const t=H.createTransfer(async()=>res);a((await t.request({uri:base},4)).error);a.equal(t.pending,0);}});
test('timeout covers body consumption even if fetch ignores AbortSignal',async()=>{let canceled=false;const t=H.createTransfer(async()=>new Response(new ReadableStream({cancel(){canceled=true;}})),20);a.equal((await t.request({uri:base})).error,'HLS_TIMEOUT');await new Promise(r=>setTimeout(r,0));a(canceled);a.equal(t.pending,0);});
test('explicit abort settles stalled fetch and cannot reopen transport',async()=>{const t=H.createTransfer(()=>new Promise(()=>{}),1000),p=t.request({uri:base});t.abort();a.equal((await p).error,'HLS_ABORTED');a.equal((await t.request({uri:base})).error,'HLS_ABORTED');a.equal(t.pending,0);});
test('full TS validation checks every packet and complete packet size',()=>{const data=Buffer.alloc(188*6);for(let i=0;i<data.length;i+=188)data[i]=0x47;H.validate(data,'ts');data[188*5]=0;a.throws(()=>H.validate(data,'ts'),/BAD_TS/);a.throws(()=>H.validate(Buffer.from([0x47]),'ts'),/BAD_TS/);});
test('MAP cached once, init repeated on each new part, discontinuity closes in order',async()=>{const o=owner();let maps=0;o._hlsTransfer=H.createTransfer(async u=>new Response(u.endsWith('init.mp4')?(maps++,init):fragment));const parsed=H.parse(playlist('#EXT-X-MAP:URI="init.mp4"\na.m4s\nb.m4s\n#EXT-X-DISCONTINUITY\nc.m4s'),base);H.enqueue(o,parsed,base);for(const item of o.queue){const r=await H.fetchItem(o,item);a(r.bytes);await H.append(o,item,{...r,data:r.bytes});}a.equal(maps,1);a.equal(o.parts.length,1);a.deepEqual(Buffer.concat(o.parts[0]),Buffer.concat([init,fragment,fragment]));a.deepEqual(Buffer.concat(o.writes),Buffer.concat([init,fragment]));a.equal(o.mediaFormat,'mp4');await o.closePart();const item=o.queue[2],r=await H.fetchItem(o,item);await H.append(o,item,{...r,data:r.bytes});a.deepEqual(Buffer.concat(o.writes),Buffer.concat([init,fragment]));});
test('bad init/fragment boxes never yield appendable data',async()=>{for(const payload of [Buffer.from('html'),box('ftyp'),Buffer.from([0,0,0,255,109,111,111,118])]){const o=owner();o._hlsTransfer=H.createTransfer(async()=>new Response(payload));const item={hls:{uri:base,map:{uri:base,range:null}}};a((await H.fetchItem(o,item)).error);a.equal(o.writes.length,0);}});
test('stop or restart during asynchronous part close prevents old segment append',async()=>{const o=owner();o.partOpen=true;o._hlsBoundary='old';let release;o.closePart=()=>new Promise(r=>release=r);const p=H.append(o,{hls:{map:{}}},{data:fragment,init,boundary:'new'});H.reset(o);release();a.equal(await p,false);a.equal(o.writes.length,0);});

test('playlist with missing target duration is rejected before acquiring any segments',()=>{a.throws(()=>H.parse('#EXTM3U\na.ts',base),/HLS_BAD_TARGET/);});
test('I-frame-only playlists cannot be treated as complete video recordings',()=>{a.throws(()=>H.parse(playlist('#EXT-X-I-FRAMES-ONLY\na.ts'),base),/HLS_IFRAMES_UNSUPPORTED/);});
test('ENDLIST must precede no segments and must occur at most once',()=>{a.throws(()=>H.parse(playlist('#EXT-X-ENDLIST\na.ts'),base),/HLS_SEGMENT_AFTER_ENDLIST/);a.throws(()=>H.parse(playlist('a.ts\n#EXT-X-ENDLIST\n#EXT-X-ENDLIST'),base),/HLS_DUPLICATE_ENDLIST/);});
