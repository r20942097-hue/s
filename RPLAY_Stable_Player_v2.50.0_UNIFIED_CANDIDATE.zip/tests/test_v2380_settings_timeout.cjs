'use strict';
const {test}=require('node:test'),a=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const base=path.join(__dirname,'..');
const id='a'.repeat(24);
/* ---- v2.38.0: 設定読込の無応答timeout ----
   実タイマーでBG routerを検証する。__RSP_TEST_SETTINGS_READ_MS=40 は試験専用seam
   (生成物の既定は3000msのまま・試験だけ短縮)。timer解放も漏れなく検査する。 */
function harness(opts={}){
  const h={listener:null,hostMessages:[],scheduled:0,cleared:0,store:opts.store||{},getFn:null};
  if(opts.hang)h.getFn=()=>{}; /* 応答しないstorage */
  const realSetTimeout=setTimeout,realClearTimeout=clearTimeout;
  const api={runtime:{id:'rsp',lastError:null,getURL:n=>'chrome-extension://rsp/'+n,
      onMessage:{addListener:f=>h.listener=f},onStartup:{addListener:()=>{}},onInstalled:{addListener:()=>{}},
      getContexts:async()=>[{}],
      sendMessage:async m=>{h.hostMessages.push(m);return structuredClone(opts.hostReply&&opts.hostReply[m.type]||{ok:true});}},
    offscreen:{createDocument:async()=>{},closeDocument:async()=>{}},
    downloads:{onChanged:{addListener:()=>{}}},alarms:{create:()=>{},clear:()=>{},onAlarm:{addListener:()=>{}}},
    action:{setBadgeText:()=>{}},tabs:{query:async()=>[],sendMessage:async()=>{}}};
  api.storage={local:{get:(k,cb)=>{if(h.getFn)return h.getFn(k,cb);const fire=()=>cb(structuredClone(h.store));opts.delay?realSetTimeout(fire,opts.delay):fire();}}};
  const c=vm.createContext({chrome:api,console,Promise,Date,
    setTimeout:(fn,ms,...rest)=>{h.scheduled++;return realSetTimeout(fn,ms,...rest);},
    clearTimeout:t=>{if(t)h.cleared++;return realClearTimeout(t);},
    __RSP_TEST_SETTINGS_READ_MS:40,
    RspExportManager:{create:()=>({pending:async()=>false,status:async()=>({verified:0}),offer:async()=>({ok:true}),changed:async()=>{},reconcile:async()=>{}})}});
  vm.runInContext(fs.readFileSync(path.join(base,'src/creator_registry.js'),'utf8'),c);
  vm.runInContext(fs.readFileSync(path.join(base,'src/background.js'),'utf8'),c);
  h.message=(msg,sender)=>new Promise(res=>{const keep=h.listener(msg,sender,res);if(keep!==true)res(null);});
  return h;
}
const content={id:'rsp',url:'https://rplay.live/live/'+id,frameId:0,tab:{id:1}};
const dash={id:'rsp',url:'chrome-extension://rsp/dashboard.html'};

test('v2.38.0 hung settings read rejects the start within the bound and never reaches the host',async()=>{
  const h=harness({hang:true});
  const t0=Date.now();
  const r=await h.message({type:'rec.start',payload:{oid:id}},content);
  const elapsed=Date.now()-t0;
  a.deepEqual(JSON.parse(JSON.stringify(r)),{ok:false,error:'START_SETTINGS_UNAVAILABLE'});
  a.ok(elapsed>=35&&elapsed<2000,'bounded rejection timing: '+elapsed);
  a.equal(h.hostMessages.length,0);
  a.equal(h.cleared,h.scheduled,'every scheduled timer was cleared');
});
test('v2.38.0 late storage reply after the timeout settles once and recovery restores starts',async()=>{
  let late=null;
  const h=harness({});
  h.getFn=(k,cb)=>{late=()=>cb(structuredClone(h.store));}; /* 応答を保留したまま */
  const p=h.message({type:'rec.start',payload:{oid:id}},content);
  await new Promise(res=>setTimeout(res,80));
  const r=await p;
  a.equal(r.error,'START_SETTINGS_UNAVAILABLE');
  if(late)late(); /* 遅到着 — 決着済みPromiseを二度触らない・例外も出さない */
  await new Promise(res=>setTimeout(res,20));
  h.getFn=null; /* storage復旧 */
  const r2=await h.message({type:'rec.start',payload:{oid:id}},content);
  a.equal(r2.ok,true);
  a.equal(h.cleared,h.scheduled);
});
test('v2.38.0 reply within the bound is accepted and clears its timer',async()=>{
  const h=harness({delay:10});
  const r=await h.message({type:'rec.start',payload:{oid:id}},content);
  a.equal(r.ok,true);
  a.equal(h.scheduled,1);
  a.equal(h.cleared,1);
});
test('v2.38.0 hung registry read answers an empty list instead of hanging the page',async()=>{
  const h=harness({hang:true,store:{rsp_registered_creators:[id]}});
  const r=await h.message({type:'registry.list'},content);
  a.deepEqual(JSON.parse(JSON.stringify(r)),{ids:[],meta:{}});
  a.equal(h.cleared,h.scheduled);
});
test('v2.38.0 hung registry read fails the dashboard schedule scan safely',async()=>{
  const h=harness({hang:true,store:{rsp_registered_creators:[id]}});
  const r=await h.message({type:'schedules.scan'},dash);
  a.equal(r.ok,false);
  a.equal(r.error,'scan-unavailable');
  a.equal(h.hostMessages.length,0);
});
test('v2.38.0 monitor.status keeps answering when the settings read times out',async()=>{
  const h=harness({hang:true,hostReply:{'rec.status':{recording:false,oid:'',state:'IDLE'}}});
  const r=await h.message({type:'monitor.status'},dash);
  a.equal(r.ok,true);
  a.deepEqual(JSON.parse(JSON.stringify(r.policy)),{unavailable:true});
  a.equal(r.start,null);
});
test('v2.38.0 synchronous throws and non-object replies still reject fail-closed',async()=>{
  const h=harness({});
  h.getFn=()=>{throw Error('unavailable');};
  a.equal((await h.message({type:'rec.start',payload:{oid:id}},content)).error,'START_SETTINGS_UNAVAILABLE');
  h.getFn=(k,cb)=>cb('not-an-object');
  a.equal((await h.message({type:'rec.start',payload:{oid:id}},content)).error,'START_SETTINGS_UNAVAILABLE');
});
