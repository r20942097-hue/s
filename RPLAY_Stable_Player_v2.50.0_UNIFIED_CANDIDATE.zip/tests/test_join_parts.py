import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('rsp_join_tests', ROOT / 'rplay_join.py')
j = importlib.util.module_from_spec(spec)
spec.loader.exec_module(j)


class JoinParts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.media = tempfile.TemporaryDirectory()
        cls.samples = Path(cls.media.name)
        for name, color, size in [('red', 'red', '64x64'), ('blue', 'blue', '64x64'), ('wide', 'red', '96x64')]:
            subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-f', 'lavfi', '-i',
                'color=c=%s:s=%s:r=10' % (color, size), '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=48000',
                '-t', '1', '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p',
                '-c:a', 'aac', '-f', 'mpegts', str(cls.samples / (name + '.ts'))], check=True, timeout=20)

    @classmethod
    def tearDownClass(cls):
        cls.media.cleanup()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.directory = Path(self.temp.name)
        for path in self.samples.glob('*.ts'):
            shutil.copy2(path, self.directory / path.name)

    def tearDown(self):
        self.temp.cleanup()

    def job(self, *names):
        return {'schema': 'rsp.join.v1', 'parts': [
            {'file': n, 'bytes': (self.directory / n).stat().st_size,
             'sha256': j.digest(self.directory / n)} for n in names]}

    def frames(self, path):
        p = subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-i', str(path),
                            '-map', '0:v:0', '-f', 'framemd5', '-'], capture_output=True, check=True, timeout=20)
        return [line.rsplit(',', 1)[-1].strip() for line in p.stdout.decode().splitlines()
                if line and not line.startswith('#')]

    def test_reset_timestamps_join_to_one_mp4_in_declared_order(self):
        job = self.job('blue.ts', 'red.ts')
        before = [j.digest(self.directory / e['file']) for e in job['parts']]
        result = j.join_parts(job, self.directory)
        output = self.directory / result['file']
        self.assertEqual(result['status'], 'JOINED_DECODE_VERIFIED')
        self.assertEqual(result['inputOrder'], ['blue.ts', 'red.ts'])
        self.assertEqual(self.frames(output), self.frames(self.directory / 'blue.ts') + self.frames(self.directory / 'red.ts'))
        self.assertEqual(before, [j.digest(self.directory / e['file']) for e in job['parts']])
        self.assertTrue(result['streamCopy'])
        self.assertTrue(result['originalsRetained'])

    def test_ten_small_parts_become_one_output(self):
        names = []
        for i in range(10):
            name = 'small%02d.ts' % i
            shutil.copy2(self.directory / 'red.ts', self.directory / name)
            names.append(name)
        result = j.join_parts(self.job(*names), self.directory)
        self.assertEqual(result['parts'], 10)
        self.assertEqual(len(list(self.directory.glob('*.mp4'))), 1)
        self.assertEqual(len(self.frames(self.directory / result['file'])), 100)

    def test_resolution_change_is_rejected_without_output(self):
        with self.assertRaisesRegex(j.JoinError, 'INCOMPATIBLE_STREAMS'):
            j.join_parts(self.job('red.ts', 'wide.ts'), self.directory)
        self.assertFalse(list(self.directory.glob('*.mp4')))

    def test_existing_destination_is_untouched(self):
        output = self.directory / 'existing.mp4'
        output.write_bytes(b'original recording')
        with self.assertRaisesRegex(j.JoinError, 'OUTPUT_EXISTS'):
            j.join_parts(self.job('red.ts', 'blue.ts'), self.directory, output)
        self.assertEqual(output.read_bytes(), b'original recording')

    def test_cli_can_join_existing_ts_without_a_job_json(self):
        output = self.directory / 'manual.mp4'
        result = subprocess.run([sys.executable, str(ROOT / 'rplay_join.py'), '--files',
            str(self.directory / 'red.ts'), str(self.directory / 'blue.ts'),
            '--output', str(output)], capture_output=True, text=True, timeout=20)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(json.loads(result.stdout)['parts'], 2)
        self.assertEqual(len(self.frames(output)), 20)

    def test_size_and_hash_mismatch_reject_before_join(self):
        for field, value in [('bytes', 1), ('sha256', '0' * 64)]:
            job = self.job('red.ts')
            job['parts'][0][field] = value
            with self.subTest(field=field), self.assertRaisesRegex(j.JoinError, 'MISMATCH'):
                j.join_parts(job, self.directory)

    def test_bad_paths_duplicates_and_missing_parts_rejected(self):
        for names in [['../outside.ts'], ['http:remote.ts'], ['red.ts', 'red.ts'], ['missing.ts']]:
            with self.subTest(names=names), self.assertRaises(j.JoinError):
                j.join_parts({'parts': [{'file': n} for n in names]}, self.directory)

    def test_incomplete_or_truncated_job_is_not_claimed_complete(self):
        for key in ['incomplete', 'truncated']:
            job = self.job('red.ts', 'blue.ts'); job[key] = True
            with self.assertRaisesRegex(j.JoinError, 'INCOMPLETE_JOB'):
                j.join_parts(job, self.directory)

    def test_separate_audio_is_not_silently_omitted(self):
        job = self.job('red.ts', 'blue.ts')
        job['audioRendition'] = {'parts': [{'file': 'audio.ts'}]}
        with self.assertRaisesRegex(j.JoinError, 'SEPARATE_AUDIO'):
            j.join_parts(job, self.directory)

    def test_low_disk_preserves_originals(self):
        job = self.job('red.ts', 'blue.ts')
        with patch.object(j.shutil, 'disk_usage', return_value=type('Space', (), {'free': 0})()):
            with self.assertRaisesRegex(j.JoinError, 'INSUFFICIENT_SPACE'):
                j.join_parts(job, self.directory)
        self.assertTrue((self.directory / 'red.ts').exists())

    def test_failed_decode_never_publishes_output(self):
        original_run = j.run
        def fail_decode(command, timeout):
            if 'null' in command:
                raise j.JoinError('JOIN_MEDIA_TOOL_FAILED')
            return original_run(command, timeout)
        with patch.object(j, 'run', side_effect=fail_decode):
            with self.assertRaises(j.JoinError):
                j.join_parts(self.job('red.ts', 'blue.ts'), self.directory)
        self.assertFalse(list(self.directory.glob('*.mp4')))
        self.assertFalse(list(self.directory.glob('.rsp-join-*')))

    def test_recording_cli_automatically_joins_discontinuity_parts(self):
        from test_v250_features import SeqServer, run_cli
        playlist = '#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXTINF:1,\nred.ts\n#EXT-X-DISCONTINUITY\n#EXTINF:1,\nblue.ts\n#EXT-X-ENDLIST\n'
        server = SeqServer([playlist], payloads={n: (self.directory / n).read_bytes() for n in ['red.ts', 'blue.ts']})
        output = self.directory / 'recording'
        try:
            result = run_cli(server.url, output, '--split-on-discontinuity', '--mux', 'auto', '--info-json', '--qaudit', 'no', timeout=35)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            info = json.loads(next(output.glob('*_info.json')).read_text())
            self.assertEqual(info['aggregationEvidence']['status'], 'JOINED_DECODE_VERIFIED', result.stdout)
            self.assertEqual(len(info['parts']), 2)
            self.assertEqual(len(list(output.glob('*.mp4'))), 1)
            self.assertEqual(len(list(output.glob('*.ts'))), 2)
        finally:
            server.close()
