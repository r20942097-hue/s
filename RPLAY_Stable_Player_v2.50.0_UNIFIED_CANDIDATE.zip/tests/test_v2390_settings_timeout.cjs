const {test}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const s=fs.readFileSync(require.resolve('../src/background.js'),'utf8');
function harness(mode){let fire,cb,cleared=0;const chrome={runtime:{},storage:{local:{get:(k,f)=>{cb=f;if(mode==='ok')f({});if(mode==='bad')f({rsp_dashboard_defaults:{follow:'yes'}});if(mode==='throw')throw Error('fail');}}}};
 const c=vm.createContext({chrome,setTimeout:(f,ms)=>{a.equal(ms,5000);fire=f;return 9;},clearTimeout:id=>{a.equal(id,9);cleared++;}});
 vm.runInContext(s.slice(s.indexOf('function dashboardDefaults()'),s.indexOf('\nchrome.runtime.onMessage.addListener((msg, sender, reply)')),c);
 return {read:()=>c.dashboardDefaults(),fire:()=>fire(),late:v=>cb(v),cleared:()=>cleared};}
test('unanswered settings read fails at 5 seconds and late response cannot revive it',async()=>{const h=harness('pending'),p=h.read();const rejected=a.rejects(p,/START_SETTINGS_UNAVAILABLE/);h.fire();await rejected;h.late({rsp_dashboard_defaults:{autoStartAllowed:true}});a.equal(h.cleared(),1);await a.rejects(p,/START_SETTINGS_UNAVAILABLE/);});
test('successful read clears timer, a late timeout does not change success',async()=>{const h=harness('ok'),p=h.read();a.deepEqual(JSON.parse(JSON.stringify(await p)),{});a.equal(h.cleared(),1);h.fire();a.deepEqual(JSON.parse(JSON.stringify(await p)),{});a.equal(h.cleared(),1);});
for(const mode of ['bad','throw'])test(mode+' settings rejects and cleans its timer once',async()=>{const h=harness(mode);await a.rejects(h.read(),/START_SETTINGS_UNAVAILABLE/);a.equal(h.cleared(),1);h.fire();a.equal(h.cleared(),1);});
