'use strict';
/* v2.39.0: ページ側配信者名収穫(creator_meta移植) + BG rec.start収穫 + 表示優先順位 */
const {test}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const base=path.join(__dirname,'..');
const user=fs.readFileSync(path.join(base,'src/player.user.js'),'utf8');
const bg=fs.readFileSync(path.join(base,'src/background.js'),'utf8');
const metaMod=require(path.join(base,'src/creator_meta.js'));
const id='a'.repeat(24),id2='b'.repeat(24);
const HID=n=>n.toString(16).padStart(24,'0');

/* ---- creator_meta モジュール単体(v2.31実装の移植検証) ---- */
const HEX=c=>c.repeat(24);
test('v2.39.0 creator_meta normalize sanitizes entries and caps at 500 by oldest timestamp',()=>{
 const now=Date.now();
 const map={};for(let i=0;i<520;i++)map[HID(i+1)]={name:'n'+i,at:i+1};
 a.equal(Object.keys(metaMod.normalize(map,now)).length,500);
 a.ok(Object.keys(metaMod.normalize(map,now)).includes(HID(520)),'newest kept');
 a.ok(!Object.keys(metaMod.normalize(map,now)).includes(HID(1)),'oldest dropped');
 a.equal(metaMod.normalize({[id]:{name:'  bad\x01name\x7f ',at:5}},now)[id].name,'bad name');
 a.equal(metaMod.normalize({[id]:{name:'x'.repeat(200),at:1}},now)[id].name.length,80);
 a.equal(metaMod.normalize(null,now).constructor,Object);
 a.equal(Object.keys(metaMod.normalize({'not-an-id':{name:'x',at:1}},now)).length,0);
});
test('v2.39.0 creator_meta harvest merges names and returns null when nothing changed',()=>{
 const now=Date.now();
 const base0=metaMod.normalize({[id]:{name:'旧名',at:1}},now);
 const changed=metaMod.harvest(base0,[{oid:id,nick:'新名'},{oid:id2,nick:'追加'}],now);
 a.equal(changed[id].name,'新名');a.equal(changed[id2].name,'追加');
 a.equal(metaMod.harvest(changed,[{oid:id,nick:'新名'},{oid:id2,nick:'追加'}],now),null);
 a.equal(metaMod.harvest({},[{oid:'not-an-id',nick:'x'}],now),null);
 a.equal(metaMod.harvest({},[{oid:HID(3),nick:''}],now),null);
});
test('v2.39.0 creator_meta serialize/deserialize roundtrip with guards',()=>{
 const m=metaMod.normalize({[id]:{name:'配信者A',at:1}},1);
 a.deepEqual(metaMod.deserialize(metaMod.serialize(m)),m);
 a.equal(metaMod.deserialize('not json'),null);
 a.equal(metaMod.serialize({'k':{name:'x'.repeat(90000),at:1}})||null,null,'oversized rejected');
});

/* ---- ページ側ヘルパー(実装スライス)のlocalStorage連結 ---- */
function pageHelpers(storage){
 const c=vm.createContext({localStorage:storage,RspCreatorMeta:metaMod,Date,console});
 const i=user.indexOf('  /* ---- v2.39.0: ページ側 配信者名キャッシュ');
 const j=user.indexOf('  function persistChk(',i);
 a.ok(i>0&&j>i,'helper markers');
 vm.runInContext(user.slice(i,j)+';globalThis.remember=rspCreatorMetaRemember;globalThis.nameOf=rspCreatorMetaName;',c);
 return {remember:x=>vm.runInContext('remember('+JSON.stringify(x)+')',c),nameOf:o=>vm.runInContext('nameOf('+JSON.stringify(o)+')',c)};
}
test('v2.39.0 page harvest helpers persist to localStorage and skip unchanged writes',()=>{
 const store={};let writes=0;
 const h=pageHelpers({getItem:k=>store[k]||null,setItem:(k,v)=>{writes++;store[k]=v;}});
 a.equal(h.nameOf(id),'');
 h.remember([{oid:id,nick:'収穫太郎'}]);
 a.equal(h.nameOf(id),'収穫太郎');
 a.ok(store.rsp_creator_meta.includes('収穫太郎'));
 const before=writes;
 h.remember([{oid:id,nick:'収穫太郎'}]);
 a.equal(writes,before,'unchanged harvest skips persistence');
 h.remember([{oid:id,nick:'改名花子'}]);
 a.equal(h.nameOf(id),'改名花子');
 a.equal(writes,before+1);
});
test('v2.39.0 page harvest helpers survive broken localStorage and bad input',()=>{
 const h=pageHelpers({getItem(){throw Error('denied');},setItem(){throw Error('denied');}});
 h.remember([{oid:id,nick:'x'}]);
 a.equal(h.nameOf(id),'x','in-memory cache still serves when localStorage is broken (resilient by design)');
 h.remember([{oid:'zz',nick:'x'},{oid:id2,nick:''}]);
 a.equal(h.nameOf(id2),'');
 a.equal(h.nameOf('zz'),'');
});
test('v2.39.0 harvest call sites wired in discovery paths (page source)',()=>{
 a.ok(user.includes('rspCreatorMetaRemember(items); // v2.39.0: 既知配信の名前'),'authed list harvest call');
 a.ok(user.includes('rspCreatorMetaRemember([item]); // v2.39.0: ライブ走査の結果'),'probe harvest call');
 a.ok(user.includes("creatorMetaName: function (oid) { return rspCreatorMetaName(oid); }"),'test surface');
});

/* ---- 予約一覧の表示優先順位(収穫キャッシュ → 登録metadata → ID前置き) ---- */
function rowHarness(storageValue,regMeta){
 const texts=[];const store={rsp_creator_meta:storageValue};
 const c=vm.createContext({ui:{el:{isConnected:true}},schedBtn:{disabled:false},schedList:{style:{},textContent:'',appendChild(){}},
  favInput:{value:id},current:null,recorder:null,Date,AbortController,SCHED_SCAN_MIN_MS:600000,RspAuth:{probe(){},jwt:'test'},
  globalThis:{RspCreatorRegistry:require(path.join(base,'src/creator_registry.js')),RspCreatorMeta:metaMod},
  localStorage:{getItem:k=>store[k]||null,setItem(){}},
  fetchSchedulesFor:async()=>({items:[{title:'配信',scheduledAt:Date.now()+60000}]}),
  setTimeout:fn=>{fn();},el:()=>({appendChild(){}}),document:{createTextNode:s=>{texts.push(String(s));return s;}},
  chrome:{runtime:{sendMessage:async()=>({ids:[],meta:regMeta})}}});
 const metaStart=user.indexOf('  /* ---- v2.39.0: ページ側 配信者名キャッシュ'),metaEnd=user.indexOf('  function persistChk(',metaStart);
 const start=user.indexOf('    ui.scanSchedules = async function'),end=user.indexOf('    const cancelSched=',start);
 vm.runInContext(user.slice(metaStart,metaEnd)+user.slice(start,end),c);
 return {ui:c.ui,texts};
}
test('v2.39.0 schedule rows prefer harvested name over registry metadata, then fall back',async()=>{
 const cache=metaMod.serialize(metaMod.normalize({[id]:{name:'収穫新太郎',at:1}},1));
 let h=rowHarness(cache,{[id]:{name:'登録旧太郎',url:'https://rplay.live/c/taro',at:1}});
 h.ui.el.isConnected=true;
 await h.ui.scanSchedules(true);
 let line=h.texts.find(t=>t.includes('「配信」'));
 a.ok(line.includes('収穫新太郎'),'harvest name wins');
 a.ok(!line.includes('登録旧太郎'));
 h=rowHarness(null,{[id]:{name:'登録旧太郎',url:'https://rplay.live/c/taro',at:1}});
 h.ui.el.isConnected=true;
 await h.ui.scanSchedules(true);
 line=h.texts.find(t=>t.includes('「配信」'));
 a.ok(line.includes('登録旧太郎'),'registry metadata used when harvest empty');
 h=rowHarness(null,{});
 h.ui.el.isConnected=true;
 await h.ui.scanSchedules(true);
 line=h.texts.find(t=>t.includes('「配信」'));
 a.ok(line.includes(id.slice(0,10)+'…'),'oid prefix when both empty');
});

/* ---- BG rec.start時の名前収穫(background.js rememberCreatorMeta) ---- */
function bgMetaHarness(store,opts={}){
 const writes=[];
 const c=vm.createContext({chrome:{storage:{local:{
   get:(keys,cb)=>{if(opts.throwGet)throw Error('x');cb(structuredClone(store));},
   set:(o,cb)=>{if(opts.throwSet)throw Error('x');Object.assign(store,structuredClone(o));writes.push(o);try{cb();}catch(e){}}}},
  runtime:{id:'rsp'}},
  navigator:opts.noLocks?{locks:undefined}:{locks:{request:async(name,fn)=>{c.lockCalls=(c.lockCalls||0)+1;return fn();}}},
  Date:{now:()=>12345},RspCreatorRegistry:require(path.join(base,'src/creator_registry.js')),console,Promise,Number});
 const i=bg.indexOf('function rememberCreatorMeta(oid, name)');
 const j=bg.indexOf('/* ---- v2.39.0: BG停止後のMP4変換画面',i);
 a.ok(i>0&&j>i,'rememberCreatorMeta markers');
 vm.runInContext(bg.slice(i,j)+';globalThis.remember=rememberCreatorMeta;',c);
 return {run:(oid,name)=>vm.runInContext('remember('+JSON.stringify(oid)+','+JSON.stringify(name===undefined?null:name)+')',c),
  store,writes,lockCalls:()=>c.lockCalls||0};
}
test('v2.39.0 BG harvest: registered-only, url-preserving, unchanged-skip',async()=>{
 const h=bgMetaHarness({rsp_registered_creators:[id]});
 h.run(id,'BG収穫太郎');
 await new Promise(setImmediate);await new Promise(setImmediate);
 a.equal(h.store.rsp_creator_meta[id].name,'BG収穫太郎');
 a.equal(h.store.rsp_creator_meta[id].url,'');
 a.equal(h.writes.length,1);
 h.run(id,'BG収穫太郎');
 await new Promise(setImmediate);await new Promise(setImmediate);
 a.equal(h.writes.length,1,'unchanged name skips persistence');
 h.run(id2,'未登録');
 await new Promise(setImmediate);await new Promise(setImmediate);
 a.ok(!h.store.rsp_creator_meta[id2],'unregistered oid never written');
});
test('v2.39.0 BG harvest: existing url preserved and bad input skipped',async()=>{
 const h=bgMetaHarness({rsp_registered_creators:[id],rsp_creator_meta:{[id]:{name:'旧',url:'https://rplay.live/c/taro',at:1}}});
 h.run(id,'新名');
 await new Promise(setImmediate);await new Promise(setImmediate);
 a.equal(h.store.rsp_creator_meta[id].name,'新名');
 a.equal(h.store.rsp_creator_meta[id].url,'https://rplay.live/c/taro','existing url preserved');
 for(const [oid,name] of [['not-an-id','x'],[id,''],[id,null],[id,'   ']])
  {h.run(oid,name);await new Promise(setImmediate);}
 a.equal(h.writes.length,1,'invalid inputs never write');
});
test('v2.39.0 BG harvest: Web Locks guard is mandatory and lock name matches registry commit',async()=>{
 const h=bgMetaHarness({rsp_registered_creators:[id]},{noLocks:true});
 h.run(id,'x');
 await new Promise(setImmediate);await new Promise(setImmediate);
 a.equal(h.writes.length,0,'no locks → no write (fail-safe)');
 const h2=bgMetaHarness({rsp_registered_creators:[id]});
 h2.run(id,'ロック太郎');
 await new Promise(setImmediate);await new Promise(setImmediate);
 a.equal(h2.lockCalls(),1);
 a.ok(bg.slice(bg.indexOf('function rememberCreatorMeta'),bg.indexOf('function maybeOpenConverter')).includes("'rsp-creator-registry-save-v1'"),'same lock name as registry commit');
});
test('v2.39.0 BG harvest: rec.start wiring passes payload creatorName (source guard)',()=>{
 const i=bg.indexOf("/* v2.39.0: 開始時の名前収穫");
 a.ok(i>0,'harvest call comment present');
 a.ok(bg.includes("rememberCreatorMeta(msg.payload.oid, msg.payload.creatorName);"),'rec.start success path calls harvest');
});
