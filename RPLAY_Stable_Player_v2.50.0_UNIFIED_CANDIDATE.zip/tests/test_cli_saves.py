import hashlib,importlib.util,pathlib,tempfile,threading,time,unittest
from unittest.mock import patch
R=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('candidate',R/'rplay_dl.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Saves(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=pathlib.Path(self.tmp.name)
 def part(self,audio=False,data=b'abc'):
  r=m.Dl.__new__(m.Dl);r.out_dir=str(self.root);r.wlock=threading.Lock();r.log=lambda *a:None;r.save_errors=[];r._failed_media=set();r.state='RUN';r.parts_log=[];r.audio_parts_log=[];r.part_ext='ts';r.seg_part=1
  pre='a_' if audio else '';p=self.root/('audio.part' if audio else 'video.part');f=p.open('wb');f.write(data)
  for k,v in {'part_open':True,'part_name':'target.ts','part_tmp_path':str(p),'fh':f,'bytes_part':len(data),'part_hasher':hashlib.sha256(data),'file_started':time.time(),'part_index':0}.items():setattr(r,pre+k,v)
  return r,p
 def test_non_overwrite(self):
  r,p=self.part();t=self.root/'target.ts';t.write_bytes(b'old');self.assertFalse(r.close_part());self.assertEqual(t.read_bytes(),b'old');self.assertTrue(p.exists());self.assertFalse(r.parts_log)
 def test_video_commit_hash(self):
  r,p=self.part();self.assertTrue(r.close_part());self.assertEqual((self.root/'target.ts').read_bytes(),b'abc');self.assertFalse(p.exists());self.assertEqual(r.parts_log[0]['sha256'],hashlib.sha256(b'abc').hexdigest())
 def test_audio_commit_hash(self):
  r,p=self.part(True);self.assertTrue(r.close_audio_part());self.assertEqual(r.audio_parts_log[0]['kind'],'audio');self.assertFalse(p.exists())
 def test_link_error_not_success(self):
  r,p=self.part()
  with patch.object(m.os,'link',side_effect=OSError('disk')):self.assertFalse(r.close_part())
  self.assertFalse(r.parts_log);self.assertTrue(p.exists());self.assertEqual(r.state,'IDLE')
 def test_audio_link_error_not_success(self):
  r,p=self.part(True)
  with patch.object(m.os,'link',side_effect=OSError('disk')):self.assertFalse(r.close_audio_part())
  self.assertFalse(r.audio_parts_log);self.assertTrue(p.exists())
 def test_fsync_error_not_success(self):
  r,p=self.part()
  with patch.object(m.os,'fsync',side_effect=OSError('sync')):self.assertFalse(r.close_part())
  self.assertFalse(r.parts_log);self.assertTrue(p.exists())
 def test_missing_writable_not_success(self):
  r,p=self.part();r.fh.close();r.fh=None;self.assertFalse(r.close_part());self.assertFalse(r.parts_log);self.assertTrue(p.exists())
 def test_corrupt_staging_not_success(self):
  r,p=self.part();r.fh.flush();p.write_bytes(b'bad');self.assertFalse(r.close_part());self.assertFalse(r.parts_log)
 def test_symlink_staging_rejected(self):
  r,p=self.part();r.fh.close();other=self.root/'other';other.write_bytes(b'abc');p.unlink();p.symlink_to(other);r.fh=other.open('rb');self.assertFalse(r.close_part());self.assertFalse(r.parts_log)
 def test_empty_part_does_not_count(self):
  r,p=self.part(data=b'');self.assertTrue(r.close_part());self.assertFalse(p.exists());self.assertFalse(r.parts_log)
 def test_unlink_failure_after_publication_is_committed_and_audited(self):
  r,p=self.part()
  with patch.object(m.os,'unlink',side_effect=OSError('unlink')):self.assertTrue(r.close_part())
  self.assertEqual((self.root/'target.ts').read_bytes(),b'abc');self.assertTrue(p.exists());self.assertTrue(r.parts_log[0]['tempRetained'])
 def test_recovery_does_not_promote_or_delete_any_part(self):
  r,p=self.part();r.fh.close();q=self.root/'RPLAY_owned.ts.part';q.write_bytes(b'not media');z=self.root/'RPLAY_empty.part';z.write_bytes(b'');r.recover_orphan_parts();self.assertTrue(q.exists());self.assertTrue(z.exists());self.assertTrue(p.exists());self.assertFalse((self.root/'RPLAY_owned.ts').exists());self.assertEqual(len(r.recovered_orphans),2)
 def test_names_unique(self):
  self.assertNotEqual(m.Dl._unique_media_name('test.ts'),m.Dl._unique_media_name('test.ts'))
 def test_duplicate_close_no_double_count(self):
  r,p=self.part();r.close_part();r.close_part();self.assertEqual(len(r.parts_log),1)
 def test_earlier_write_failure_blocks_commit(self):
  r,p=self.part();r._failed_media.add('video');self.assertFalse(r.close_part());self.assertTrue(p.exists());self.assertFalse(r.parts_log)
if __name__=='__main__':unittest.main(verbosity=2)
