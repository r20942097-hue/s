'use strict';
/* v2.9.0 core features (A-09 subtitle support, phase 1: observation & evidence):
   1. parseSubtitleRenditions (JS core): parse #EXT-X-MEDIA:TYPE=SUBTITLES from
      master playlists. URIs are NEVER output (hasUri only) — URL redaction contract.
   2. parseVariants captures the SUBTITLES group attribute (subsGroup, mirror of audioGroup).
   3. rspSubtitleEvidence / rspSubtitleEvidenceBlock: zero-fabrication evidence block —
      emitted only when master playlist text is a non-empty string; policy
      observed_not_fetched; subtitle playlists/segments are never fetched.
   4. Cross-language mirror with Python (subtitle_evidence_block / parse_subtitle_renditions).
   5. Unified 2.9.0 version pin across userscript/manifests/CLI strings. */
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),vm=require('vm');
const {spawnSync}=require('node:child_process');
const ROOT=path.join(__dirname,'..');
const source=fs.readFileSync(path.join(ROOT,'rplay-stable-player.user.js'),'utf8');

function subtitleWorld(){
  const s1=source.slice(source.indexOf('function parseM3u8Attrs'),source.indexOf('function parseVariants'));
  const s2=source.slice(source.indexOf('function parseSubtitleRenditions'),source.indexOf('function audioLabelFor'));
  const s3=source.slice(source.indexOf('function rspSubtitleEvidence('),source.indexOf('async function fetchJsonWithRetry'));
  const c=vm.createContext({JSON,console,RECENV:{pageUrl:()=>'https://rplay.live/live/'+'a'.repeat(24)}});
  vm.runInContext([s1,s2,s3].join('\n')+';globalThis._fns={parseSubtitleRenditions,rspSubtitleEvidence,rspSubtitleEvidenceBlock};',c);
  return c._fns;
}
const MASTER=[
  '#EXTM3U',
  '#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID="subs",NAME="Japanese",LANGUAGE="ja",DEFAULT=YES,AUTOSELECT=YES,FORCED=NO,URI="subs_ja.m3u8?sig=SECRET"',
  '#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID="subs",NAME="English",LANGUAGE="en",CHARACTERISTICS="public.accessibility.transcribes-spoken-dialog"',
  '#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="aud",NAME="Audio",CHANNELS="2"',
  '#EXT-X-STREAM-INF:BANDWIDTH=2000000,RESOLUTION=1920x1080,SUBTITLES="subs",AUDIO="aud"',
  'v.m3u8',
].join('\n');

test('v2.9.0 version pin: userscript @version, both manifests, CLI strings',()=>{
  const us=fs.readFileSync(path.join(ROOT,'rplay-stable-player.user.js'),'utf8');
  assert.match(us,/\/\/ @version\s+2\.(?:9|10|11|12|13|36|37|38|39|40|41|42|43|44|45|46|47|48|49|50)\.0/);
  for(const ext of ['rplay-stable-player-extension','rplay-stable-player-extension-firefox']){
    const m=JSON.parse(fs.readFileSync(path.join(ROOT,ext,'manifest.json'),'utf8'));
    assert.match(m.version,/^2\.(?:9|10|11|12|13|36|37|38|39|40|41|42|43|44|45|46|47|48|49|50)\.0$/,ext);
    if(ext.endsWith('-firefox')) assert.equal(Object.hasOwn(m,'version_name'),false,'Firefox must omit unsupported version_name'); else assert.match(m.version_name,/^2\.(?:9|10|11|12|13|36|37|38|39|40|41|42|43|44|45|46|47|48|49|50)\.0 CANDIDATE$/,ext+' version_name');
  }
  const cli=fs.readFileSync(path.join(ROOT,'rplay_dl.py'),'utf8');
  assert.match(cli,/RPLAY Live Downloader v2\.(?:9|10|11|12|13|36|37|38|39|40|41|42|43|44|45|46|47|48|49|50)\.0 CANDIDATE/);
  assert.match(cli,/rplay_dl\.py v2\.(?:9|10|11|12|13|36|37|38|39|40|41|42|43|44|45|46|47|48|49|50)\.0/);
  assert.match(cli,/\(rplay_dl\.py\) v2\.(?:9|10|11|12|13|36|37|38|39|40|41|42|43|44|45|46|47|48|49|50)\.0/);
});

test('v2.9.0 parseSubtitleRenditions parses EXT-X-MEDIA TYPE=SUBTITLES (JS core)',()=>{
  const fns=subtitleWorld();
  const r=fns.parseSubtitleRenditions(MASTER);
  assert.equal(r.length,2);
  assert.equal(r[0].groupId,'subs');
  assert.equal(r[0].name,'Japanese');
  assert.equal(r[0].language,'ja');
  assert.equal(r[0].assocLanguage,'');
  assert.equal(r[0].default,true);
  assert.equal(r[0].autoselect,true);
  assert.equal(r[0].forced,false);
  assert.equal(r[0].hasUri,true);
  assert.equal(r[1].name,'English');
  assert.equal(r[1].language,'en');
  assert.equal(r[1].hasUri,false);
  // URL秘匿契約: URI値は一切出力しない(署名クエリ混入防止)
  assert.equal(JSON.stringify(r).includes('subs_ja.m3u8'),false);
  assert.equal(JSON.stringify(r).includes('SECRET'),false);
  assert.equal(fns.parseSubtitleRenditions('').length,0);
  assert.equal(fns.parseSubtitleRenditions('#EXTM3U\n#EXTINF:1,\na.ts\n').length,0);
});

test('v2.9.0 parseVariants captures SUBTITLES group attribute (subsGroup)',()=>{
  const s1=source.slice(source.indexOf('function parseM3u8Attrs'),source.indexOf('function parseVariants'));
  const s2=source.slice(source.indexOf('function parseVariants'),source.indexOf('/* 最良variantの選択'));
  const c=vm.createContext({JSON,console,URL,RECENV:{pageUrl:()=>'https://rplay.live/live/x'}});
  vm.runInContext([s1,s2].join('\n')+';globalThis._pv={parseVariants};',c);
  const vs=c._pv.parseVariants(MASTER,'https://rplay.example/master.m3u8');
  assert.equal(vs.length,1);
  assert.equal(vs[0].subsGroup,'subs');
  assert.equal(vs[0].audioGroup,'aud');
});

test('v2.9.0 rspSubtitleEvidence: structure, linkage, zero-URI, observed_not_fetched',()=>{
  const fns=subtitleWorld();
  const rends=fns.parseSubtitleRenditions(MASTER);
  const evd=fns.rspSubtitleEvidence(rends,[{subsGroup:'subs',audioGroup:'aud'},{subsGroup:'other'}]);
  assert.equal(evd.renditionCount,2);
  assert.equal(evd.variantsLinked,1);
  assert.equal(evd.policy,'observed_not_fetched');
  assert.equal(evd.provenance,'master_playlist_ext_x_media');
  assert.deepEqual(evd.renditions,rends);
  const s=JSON.stringify(evd);
  assert.equal(s.includes('subs_ja.m3u8'),false);
  assert.equal(s.includes('http'),false);
  // 虚偽零回避: master playlist未取得(空)では証拠ブロックを出さない
  assert.equal(fns.rspSubtitleEvidenceBlock('',[]),undefined);
  assert.equal(fns.rspSubtitleEvidenceBlock(null,[]),undefined);
  const blk=fns.rspSubtitleEvidenceBlock(MASTER,[{subsGroup:'subs'}]);
  assert.ok(blk);
  assert.equal(blk.renditionCount,2);
});

test('v2.9.0 cross-language mirror: subtitle evidence identical (JS vs Python)',()=>{
  const fns=subtitleWorld();
  const vectors=[MASTER,'#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1\nv.m3u8','',null];
  const jsOut=vectors.map(v=>fns.rspSubtitleEvidenceBlock(v,[{subsGroup:'subs'}]));
  const pycode=[
    "import importlib.util,json,sys,os;",
    "spec=importlib.util.spec_from_file_location('cli',os.path.join(os.getcwd(),'rplay_dl.py'));",
    "m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);",
    "vectors=json.loads(sys.stdin.read());",
    "print(json.dumps([m.subtitle_evidence_block(v,[{'subsGroup':'subs'}]) for v in vectors]))",
  ].join('\n');
  const py=spawnSync('python3',['-c',pycode],
    {input:JSON.stringify(vectors),cwd:ROOT,encoding:'utf8'});
  assert.equal(py.status,0,py.stderr);
  const pyOut=JSON.parse(py.stdout);
  assert.deepEqual(JSON.parse(JSON.stringify(jsOut)),pyOut);
});

test('v2.9.0 saveInfoJson attaches subtitleEvidence via rspSubtitleEvidenceBlock (source pin)',()=>{
  // 情報JSONへの統合箇所を版ピン式に固定(CLI側はE2Eで実測する)
  assert.match(source,/subtitleEvidence:\s*\(\(typeof rspSubtitleEvidenceBlock === 'function'\) \? rspSubtitleEvidenceBlock\(/);
  const cli=fs.readFileSync(path.join(ROOT,'rplay_dl.py'),'utf8');
  assert.match(cli,/subtitle_evidence_block\(self\.master_txt/);
  assert.match(cli,/"subtitleEvidence":\s*subtitle_evidence_block\(/);
});
