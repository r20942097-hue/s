import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import rplay_dl
import rplay_join


@unittest.skipUnless(shutil.which("ffmpeg") and shutil.which("ffprobe"), "ffmpeg/ffprobe required")
class TestV2450CliAuditAndJoinMux(unittest.TestCase):
    def _make_video_ts(self, path: Path, seconds: float = 1.0):
        subprocess.run(
            [
                "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                "-f", "lavfi", "-i", f"testsrc=size=160x120:rate=10:duration={seconds}",
                "-c:v", "libx264", "-bf", "0", "-pix_fmt", "yuv420p", "-g", "10",
                "-f", "mpegts", str(path),
            ],
            check=True,
        )

    def _make_audio_ts(self, path: Path, seconds: float = 1.0):
        subprocess.run(
            [
                "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                "-f", "lavfi", "-i", f"sine=frequency=440:sample_rate=48000:duration={seconds}",
                "-c:a", "aac", "-b:a", "64k",
                "-f", "mpegts", str(path),
            ],
            check=True,
        )

    def test_explicit_post_save_audit_files_cli_mode(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_dir = Path(tmp)
            v_path = tmp_dir / "RPLAY_creator_20261027_p1.ts"
            a_path = tmp_dir / "RPLAY_creator_20261027_audio-p1.ts"
            self._make_video_ts(v_path, 1.0)
            self._make_audio_ts(a_path, 1.0)

            proc = subprocess.run(
                [sys.executable, str(ROOT / "rplay_dl.py"), "--audit-files", str(v_path), str(a_path)],
                capture_output=True,
                text=True,
                timeout=60,
            )
            self.assertEqual(proc.returncode, 0, proc.stderr)
            report = json.loads(proc.stdout)
            self.assertEqual(report["mode"], "explicit_post_save_audit")
            self.assertEqual(report["provenance"], "decoded")
            self.assertTrue(report["allPassed"])
            self.assertEqual(len(report["files"]), 2)
            tracks = {f["file"]: f["track"] for f in report["files"]}
            self.assertEqual(tracks[v_path.name], "video")
            self.assertEqual(tracks[a_path.name], "audio")
            self.assertEqual(report["avCorrelation"]["verdict"], "pass")

    def test_explicit_post_save_audit_fails_closed_on_missing_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            missing = Path(tmp) / "nonexistent_part.ts"
            proc = subprocess.run(
                [sys.executable, str(ROOT / "rplay_dl.py"), "--audit-files", str(missing)],
                capture_output=True,
                text=True,
                timeout=30,
            )
            self.assertEqual(proc.returncode, 2)
            report = json.loads(proc.stdout)
            self.assertFalse(report["allPassed"])
            self.assertEqual(report["files"][0]["verdict"], "missing_or_symlink")

    def test_join_parts_two_track_mux_audio_mode(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_dir = Path(tmp)
            v1 = tmp_dir / "v1.ts"
            v2 = tmp_dir / "v2.ts"
            a1 = tmp_dir / "a1.ts"
            a2 = tmp_dir / "a2.ts"
            self._make_video_ts(v1, 1.0)
            self._make_video_ts(v2, 1.0)
            self._make_audio_ts(a1, 1.0)
            self._make_audio_ts(a2, 1.0)

            job = {
                "parts": [
                    {"file": "v1.ts", "bytes": v1.stat().st_size, "sha256": rplay_join.digest(v1)},
                    {"file": "v2.ts", "bytes": v2.stat().st_size, "sha256": rplay_join.digest(v2)},
                ],
                "audioRendition": {
                    "parts": [
                        {"file": "a1.ts", "kind": "audio", "bytes": a1.stat().st_size, "sha256": rplay_join.digest(a1)},
                        {"file": "a2.ts", "kind": "audio", "bytes": a2.stat().st_size, "sha256": rplay_join.digest(a2)},
                    ]
                },
            }
            # Without mux_audio=True, fail-closed is preserved
            with self.assertRaises(rplay_join.JoinError) as ctx:
                rplay_join.join_parts(job, tmp_dir, output=tmp_dir / "fail.mp4", mux_audio=False)
            self.assertEqual(str(ctx.exception), "JOIN_SEPARATE_AUDIO_REQUIRES_MUX")

            # With mux_audio=True, both video and audio parts are concatenated and muxed into a 2-track MP4
            out_mp4 = tmp_dir / "joined_muxed.mp4"
            res = rplay_join.join_parts(job, tmp_dir, output=out_mp4, mux_audio=True)
            self.assertEqual(res["status"], "JOINED_DECODE_VERIFIED")
            self.assertTrue(res["audioMuxed"])
            self.assertEqual(res["parts"], 2)
            self.assertEqual(res["audioParts"], 2)
            self.assertTrue(out_mp4.is_file())
            # Originals retained
            self.assertTrue(v1.is_file() and v2.is_file() and a1.is_file() and a2.is_file())


class TestV2450PythonCliResilienceParity(unittest.TestCase):
    def _make_dummy_dl(self, tmp_dir: str):
        class Args:
            oid = "0123456789abcdef01234567"
            out = tmp_dir
            m3u8 = "https://cdn.example/live.m3u8"
            flv = ""
            api = "https://api.example"
            ua = "TestUA"
            no_follow = True
            no_flv = True
            no_backlog = False
            first_variant = False
            split_min = 0
            max_size_mb = 600
            standby_min = 0
            max_hours = 0
            info_json = True
            token = ""
            refresh_token = ""
            user_oid = ""
            wait_schedule = False
            split_on_discontinuity = False
            concat_parts = "no"
            inherit_query = False
            join_parts = "no"
            dec_key = ""
            dec_key_file = ""
            dec_key_env = ""
            dec_backend = "auto"
            name_tpl = ""
            mux = "no"
            audio_only = False
            audio_both = True
            min_free_mb = 0
            min_free_inodes = 0
            segindex = False
            webhook = ""
            extinf_mode = "legacy"
            qaudit = "no"

        dl = rplay_dl.Dl(Args())
        dl.state = "RUN"
        dl.live_m3u8 = "https://cdn.example/live.m3u8"
        return dl

    def test_transient_playlist_parse_grace_during_active_recording(self):
        with tempfile.TemporaryDirectory() as tmp:
            dl = self._make_dummy_dl(tmp)
            dl.seg_total = 3  # Already actively recording
            responses = [
                # Poll 1: truncated/empty M3U8 (CDN mid-write glitch)
                (200, b"#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:2\n#EXTINF:2.0,\n", 0),
                # Poll 2: valid next segment
                (200, b"#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:4\n#EXTINF:2.0,\nseg4.ts\n", 0),
            ]
            dl._playlist_get = lambda url: responses.pop(0)
            dl.poll_playlist()
            # Must NOT stop on first transient parse error!
            self.assertEqual(dl.state, "RUN")
            self.assertEqual(dl._bad_playlist_consec, 1)
            self.assertEqual(dl._bad_playlist_total, 1)

            dl.poll_playlist()
            self.assertEqual(dl.state, "RUN")
            self.assertEqual(dl._bad_playlist_consec, 0)
            self.assertEqual(dl._bad_playlist_recovered, 1)
            self.assertEqual(len(dl.queue), 1)

    def test_audio_poll_single_404_grace_and_transient_parse_grace(self):
        with tempfile.TemporaryDirectory() as tmp:
            dl = self._make_dummy_dl(tmp)
            dl.a_running = True
            dl.a_uri = "https://cdn.example/audio.m3u8"
            dl.a_seg_total = 2
            responses = [
                (404, b"", 0),
                (200, b"#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:2\n#EXTINF:2.0,\n", 0),
                (200, b"#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:3\n#EXTINF:2.0,\na3.ts\n", 0),
            ]
            dl.http = lambda url, timeout, headers=None, **kw: responses.pop(0)
            dl.audio_poll(1000)
            self.assertTrue(dl.a_running)
            self.assertEqual(dl.a_c404, 1)

            dl.audio_poll(2000)
            self.assertTrue(dl.a_running)
            self.assertEqual(dl._a_bad_playlist_consec, 1)

            dl.audio_poll(3000)
            self.assertTrue(dl.a_running)
            self.assertEqual(dl.a_c404, 0)
            self.assertEqual(dl._a_bad_playlist_recovered, 1)
            self.assertEqual(len(dl.a_queue), 1)

    def test_segment_truncated_transfer_retries_head_of_line_before_succeeding(self):
        with tempfile.TemporaryDirectory() as tmp:
            dl = self._make_dummy_dl(tmp)
            valid_ts = bytes([0x47, 0x01, 0x00, 0x10] + [0xFF] * 184) * 2
            item = {
                "name": "https://cdn.example/seg1.ts",
                "base": "",
                "tries": 0,
                "hls": {
                    "uri": "https://cdn.example/seg1.ts",
                    "range": None,
                    "map": None,
                    "gap": False,
                    "sequence": 1,
                    "discontinuity": 0,
                    "duration": 2.0,
                    "programDateTimeMs": None,
                    "epoch": 1,
                },
            }
            calls = {"n": 0}
            orig_req = rplay_dl.hls_request

            def fake_hls_request(owner, desc, limit=rplay_dl.HLS_LIMIT):
                calls["n"] += 1
                if calls["n"] == 1:
                    raise ValueError("HLS_BODY_LENGTH")
                return 200, valid_ts, 0

            rplay_dl.hls_request = fake_hls_request
            try:
                data1, retry1 = dl._fetch_hls(item, audio=False)
                self.assertIsNone(data1)
                self.assertTrue(retry1)
                self.assertEqual(dl.seg_fails, 0)
                self.assertEqual(dl._transient_transfer_retries, 1)

                data2, retry2 = dl._fetch_hls(item, audio=False)
                self.assertEqual(data2, valid_ts)
                self.assertFalse(retry2)
                self.assertEqual(dl.seg_fails, 0)
                self.assertEqual(dl._transient_transfer_recovered, 1)
            finally:
                rplay_dl.hls_request = orig_req


if __name__ == "__main__":
    unittest.main()
