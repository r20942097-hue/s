import http.server,threading,tempfile,pathlib,subprocess,sys,json,hashlib,unittest
R=pathlib.Path(__file__).resolve().parents[1]
class HTTPRecording(unittest.TestCase):
 def test_endlist_cli_commits_exact_ts_bytes(self):
  packets=[]
  for value in [1,2,3]:
   packet=bytearray([value]*188);packet[0]=0x47;packets.append(bytes(packet)*5)
  requests=[]
  class Handler(http.server.BaseHTTPRequestHandler):
   def log_message(self,*args):pass
   def do_GET(self):
    path=self.path.split('?')[0];requests.append(path)
    if path=='/live.m3u8':body=b'#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:1\n'+b''.join(b'#EXTINF:1,\nseg%d.ts\n'%i for i in range(3))+b'#EXT-X-ENDLIST\n'
    elif path.startswith('/seg'):
     body=packets[int(path[4])]
    else:body=json.dumps({'streamState':'live','accessible':True,'allowAnonymous':True,'title':'offline-fixture'}).encode()
    self.send_response(200);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
  server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  try:
   with tempfile.TemporaryDirectory() as d:
    url='http://127.0.0.1:'+str(server.server_port)
    result=subprocess.run([sys.executable,str(R/'rplay_dl.py'),'a'*24,'--api',url+'/api','--m3u8',url+'/live.m3u8','--no-follow','--no-flv','--mux','no','--info-json','--out',d],capture_output=True,text=True,timeout=15)
    self.assertEqual(result.returncode,0,result.stdout+result.stderr)
    files=list(pathlib.Path(d).glob('*.ts'));self.assertEqual(len(files),1,result.stdout);data=files[0].read_bytes();self.assertEqual(data,b''.join(packets));self.assertFalse(list(pathlib.Path(d).glob('*.part')))
    info=json.loads(next(pathlib.Path(d).glob('*_info.json')).read_text());self.assertEqual(info['parts'][0]['sha256'],hashlib.sha256(data).hexdigest());self.assertEqual(info['parts'][0]['status'],'committed');self.assertEqual(info['saveErrors'],[])
    self.assertTrue(all(path.startswith(('/api/','/live.m3u8','/seg')) for path in requests))
  finally:server.shutdown();server.server_close();thread.join(2)
if __name__=='__main__':unittest.main()
