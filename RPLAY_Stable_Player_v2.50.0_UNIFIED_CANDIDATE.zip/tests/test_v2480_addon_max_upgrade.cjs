"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const { spawnSync } = require("child_process");

const ROOT = path.resolve(__dirname, "..");
const M = require("../src/media_inspect_core.js");
const C = require("../src/media_catalog.js");
const H = require("../src/hls_transport.js");
const X = require("../src/cross_site_core.js");

// 1. Test RspMediaInspect.inspectMaster & inspectHls.masterAudit + Cross-Language Parity with Python hls_inspect_master
{
  const masterM3u8 = [
    "#EXTM3U",
    "#EXT-X-VERSION:6",
    '#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="aud-hi",NAME="High Audio",LANGUAGE="ja",CHANNELS="2",URI="audio_hi.m3u8?token=SECRET_AUD"',
    '#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="aud-mux",NAME="Muxed Audio",DEFAULT=YES',
    '#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID="subs-ja",NAME="Japanese",LANGUAGE="ja",URI="subs_ja.m3u8?token=SECRET_SUB"',
    '#EXT-X-STREAM-INF:BANDWIDTH=8500000,AVERAGE-BANDWIDTH=8000000,RESOLUTION=1920x1080,FRAME-RATE=60.000,CODECS="avc1.64002a,mp4a.40.2",VIDEO-RANGE=PQ,AUDIO="aud-hi",SUBTITLES="subs-ja"',
    "v1080p60.m3u8?token=SECRET_V1",
    '#EXT-X-STREAM-INF:BANDWIDTH=3200000,RESOLUTION=1280x720,FRAME-RATE=30.000,CODECS="avc1.4d401f,mp4a.40.2",VIDEO-RANGE=SDR,AUDIO="aud-missing",SUBTITLES="subs-missing"',
    "v720p30.m3u8?token=SECRET_V2",
  ].join("\n");

  const ma = M.inspectMaster(masterM3u8);
  assert.strictEqual(ma.variantCount, 2);
  assert.deepStrictEqual(ma.audioGroupIds, ["aud-hi", "aud-mux"]);
  assert.deepStrictEqual(ma.subtitleGroupIds, ["subs-ja"]);
  assert.strictEqual(ma.separateAudioRenditions, 1);
  assert.strictEqual(ma.separateSubtitleRenditions, 1);
  assert.deepStrictEqual(ma.orphanAudioGroups, ["aud-missing"]);
  assert.deepStrictEqual(ma.orphanSubtitleGroups, ["subs-missing"]);
  assert.strictEqual(ma.hdrVariants, 1);
  assert.strictEqual(ma.highFpsVariants, 1);
  assert.deepStrictEqual(ma.maxResolution, { width: 1920, height: 1080 });
  assert.strictEqual(ma.maxBandwidth, 8000000);
  assert.strictEqual(ma.needsSeparateAudioMux, true);
  assert.strictEqual(ma.needsSeparateSubtitleMux, true);
  assert(!JSON.stringify(ma).includes("SECRET"), "Zero-secret policy: no token or URI in inspectMaster");

  const fullHls = M.inspectHls(masterM3u8);
  assert.strictEqual(fullHls.master, true);
  assert.deepStrictEqual(fullHls.masterAudit, ma);

  // Cross-language parity check with Python hls_inspect_master
  const pyRes = spawnSync(
    "python3",
    [
      "-c",
      "import sys, json; sys.path.insert(0, '.'); import rplay_dl; hls_inspect_master = rplay_dl.hls_inspect_master; print(json.dumps(hls_inspect_master(sys.stdin.read())))",
    ],
    { cwd: ROOT, input: masterM3u8, encoding: "utf8" }
  );
  assert.strictEqual(pyRes.status, 0, pyRes.stderr);
  const pyMa = JSON.parse(pyRes.stdout);
  assert.deepStrictEqual(ma, pyMa, "JS inspectMaster and Python hls_inspect_master must be byte-for-byte identical");
}

// 2. Test RspMediaInspect.commands with subtitlesUrl (2-input and 3-input mov_text muxing)
{
  const c3 = M.commands({
    url: "https://cdn.example.com/v.m3u8",
    audioUrl: "https://cdn.example.com/a.m3u8",
    subtitlesUrl: "https://cdn.example.com/s.vtt",
    referer: "https://rplay.live/",
    userAgent: "TestUA/1.0",
    output: "stream_sub.mp4",
    shell: "sh",
  });
  assert(c3.ffmpeg.includes("https://cdn.example.com/s.vtt"), "FFmpeg command must include subtitlesUrl input");
  assert(c3.ffmpeg.includes("-map '2:s?'"), "3-input FFmpeg command must map 2:s?");
  assert(c3.ffmpeg.includes("-c:s mov_text"), "FFmpeg command must transcode WebVTT to mov_text for MP4 container");

  const c2Sub = M.commands({
    url: "https://cdn.example.com/v.m3u8",
    subtitlesUrl: "https://cdn.example.com/s.vtt",
    output: "stream_sub2.mp4",
    shell: "powershell",
  });
  assert(c2Sub.ffmpeg.includes("-map '1:s?'"), "2-input (video+sub) FFmpeg command must map 1:s?");
  assert(c2Sub.ffmpeg.includes("-c:s mov_text"), "FFmpeg command must include -c:s mov_text");

  assert.throws(
    () => M.commands({ url: "https://cdn.example.com/v.m3u8", subtitlesUrl: "javascript:alert(1)" }),
    /INVALID_HTTP_URL/
  );
}

// 3. Test media_inspect.js UI: subtitles row selection into #subtitlesUrl and DASH representationsList rendering
async function testMediaInspectUi() {
  const nodes = new Map();
  function element() {
    return {
      value: "",
      checked: false,
      disabled: false,
      textContent: "",
      children: [],
      events: {},
      addEventListener(n, f) {
        this.events[n] = f;
      },
      replaceChildren() {
        this.children = [];
      },
      appendChild(c) {
        this.children.push(c);
      },
    };
  }
  const field = (id) => {
    if (!nodes.has(id)) nodes.set(id, element());
    return nodes.get(id);
  };
  const masterWithSubs = [
    "#EXTM3U",
    '#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="a1",NAME="MainAudio",URI="https://cdn.invalid/audio.m3u8"',
    '#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID="s1",NAME="JapaneseSub",LANGUAGE="ja",URI="https://cdn.invalid/subs.m3u8"',
    '#EXT-X-STREAM-INF:BANDWIDTH=4000000,RESOLUTION=1920x1080,AUDIO="a1",SUBTITLES="s1"',
    "https://cdn.invalid/video.m3u8",
  ].join("\n");
  const dashMpd = `<?xml version="1.0"?><MPD xmlns="urn:mpeg:dash:schema:mpd:2011" type="static"><Period><AdaptationSet contentType="video" mimeType="video/mp4"><Representation id="v1" width="1920" height="1080" bandwidth="5000000" codecs="avc1.64002a"/></AdaptationSet></Period></MPD>`;

  const ctx = vm.createContext({
    document: {
      getElementById: field,
      createElement: element,
      createTextNode: (t) => ({ textContent: t }),
    },
    location: { hash: "" },
    navigator: {},
    AbortController,
    addEventListener: () => {},
    RspMediaInspect: M,
    RspCrossSite: X,
    RspMediaCatalog: {
      ...C,
      load: (url, opts) => C.load(url, { ...opts, HLS: H, fetchImpl: async () => new Response(masterWithSubs) }),
      loadDASH: (url, opts) => C.loadDASH(url, { ...opts, HLS: H, DASH: X, fetchImpl: async () => new Response(dashMpd) }),
    },
  });
  vm.runInContext(fs.readFileSync(path.join(ROOT, "src/media_inspect.js"), "utf8"), ctx);

  // Load HLS Master with subtitles
  field("url").value = "https://cdn.invalid/master.m3u8";
  field("shell").value = "sh";
  field("filename").value = "out.mp4";
  await field("loadManifest").onclick();
  assert.strictEqual(field("variantList").children.length, 3, "variantList should have video, audio, and subtitles rows");
  // Click video (0), audio (1), subtitles (2)
  field("variantList").children[0].children[1].onclick();
  field("variantList").children[1].children[1].onclick();
  field("variantList").children[2].children[1].onclick();
  assert.strictEqual(field("url").value, "https://cdn.invalid/video.m3u8");
  assert.strictEqual(field("audioUrl").value, "https://cdn.invalid/audio.m3u8");
  assert.strictEqual(field("subtitlesUrl").value, "https://cdn.invalid/subs.m3u8");
  field("generate").events.click();
  assert(field("command").value.includes("-c:s mov_text"), "Generated command must include -c:s mov_text when subtitlesUrl is set");

  // Load DASH MPD and verify representationsList is rendered in variantList
  field("url").value = "https://cdn.invalid/manifest.mpd";
  await field("loadManifest").onclick();
  assert.strictEqual(field("variantList").children.length, 1, "DASH representation row should be rendered in variantList");
  assert(field("variantList").children[0].children[0].textContent.includes("1920x1080"), "DASH representation row must show resolution");

  // Verify player.user.js includes adKeyInput and adFiltered live counter
  const playerSrc = fs.readFileSync(path.join(ROOT, "src/player.user.js"), "utf8");
  assert(playerSrc.includes("adKeyInput"), "player.user.js must include adKeyInput");
  assert(playerSrc.includes("adKeywordValue"), "player.user.js ui must expose adKeywordValue");
  assert(playerSrc.includes("広告除外"), "player.user.js recUpdate must display live ad-filtered segment count");
}

testMediaInspectUi().then(() => {
  console.log("PASS: test_v2480_addon_max_upgrade.cjs");
}).catch((err) => {
  console.error(err);
  process.exit(1);
});
