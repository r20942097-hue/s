const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),vm=require('vm');
test('full UI glue sends refreshed JWT despite identical 12-character header',async()=>{
 let token='eyJhbGciOiJIUzI1NiJ9.'+Buffer.from(JSON.stringify({sub:'test',exp:1})).toString('base64url')+'.one';const first=token,updates=[],timers=[];
 const c={crypto:require('node:crypto').webcrypto,window:{__RSP:{recorder:{id:'creator'},ui:{}}},localStorage:{getItem:k=>k==='_AUTHORIZATION_'?token:null,setItem:()=>{}},document:{documentElement:{setAttribute:()=>{}},querySelector:()=>null,getElementById:k=>k==='rsp-panel'?{}:null},setTimeout:f=>timers.push(f),atob:s=>Buffer.from(s,'base64').toString('binary'),chrome:{runtime:{id:'rsp',onMessage:{addListener:()=>{}},sendMessage:(m,cb)=>{if(m.type==='token.update'){updates.push(m.payload.jwt);cb({ok:true});}else if(m.type==='rec.status')cb({recording:true,oid:'creator',canControl:true,control:{sessionId:'sid',epoch:1,oid:'creator'}});else cb({offscreen:false});}}}};
 vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../rplay-stable-player-extension/ext_glue.js'),'utf8'),c);await new Promise(setImmediate);assert.equal(updates.length,1);
 token='eyJhbGciOiJIUzI1NiJ9.'+Buffer.from(JSON.stringify({sub:'test',exp:2})).toString('base64url')+'.two';assert.equal(first.slice(0,12),token.slice(0,12));timers.pop()();await new Promise(setImmediate);assert.equal(updates.length,2);assert.equal(updates[1],token);
 timers.pop()();await new Promise(setImmediate);assert.equal(updates.length,2);
});
