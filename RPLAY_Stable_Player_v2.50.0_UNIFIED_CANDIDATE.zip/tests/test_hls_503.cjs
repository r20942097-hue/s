'use strict';
const {test}=require('node:test'),a=require('node:assert/strict');
const {recording}=require('./helpers_hls.cjs');
const uri='https://fixture/live.m3u8';
const ts=Buffer.alloc(376);ts[0]=ts[188]=0x47;
for(const track of ['video','audio'])test(`503 Retry-After pauses ${track}, preserves FIFO and resumes verified bytes`,async()=>{
 let calls=0;
 const r=recording(uri,async()=>++calls===1?
  new Response('',{status:503,headers:{'retry-after':'120'}}):new Response(ts))[track];
 const first={tries:0,hls:{uri,range:null,map:null,epoch:1,discontinuity:0}};
 const second={tries:0,hls:{uri:uri+'?second',range:null,map:null,epoch:1,discontinuity:0}};
 r.queue=[first,second];
 const before=Date.now();await r.drain();
 a.equal(calls,1);a.equal(r.queue.length,2);a.equal(r.queue[0],first);
 a.equal(first.tries,1);a.equal(r.segFails,0);a.equal(r.writes.length,0);
 const backoff=track==='audio'?'backoffUntil':'segBackoffUntil';
 a(r[backoff]>=before+120000);
 await r.drain();a.equal(calls,1);
 r[backoff]=0;await r.drain();
 a.equal(calls,3);a.equal(r.queue.length,0);a.equal(r.segTotal,2);
 a.deepEqual(Buffer.concat(r.writes),Buffer.concat([ts,ts]));
});
