'use strict';
/* v2.39.0: 全開始経路のpolicy統一 — resume()/tryFlv()/ui.onLive/RECENV.autoPolicy(ページ/offscreen)/ext_glue autoNow */
const {test}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const base=path.join(__dirname,'..');
const built=fs.readFileSync(path.join(base,'rplay-stable-player-extension/content.js'),'utf8');
const user=fs.readFileSync(path.join(base,'src/player.user.js'),'utf8');
const glue=fs.readFileSync(path.join(base,'src/ext_glue.js'),'utf8');
const pre=fs.readFileSync(path.join(base,'src/offscreen_pre.js'),'utf8');

/* ---- 共通: test_hls_timing流のRecorder実装スライス(build済みcontent.jsから) ---- */
function world(recenv){
 let now=100000,alloc=0;const active=new Set();
 class Clock extends Date {static now(){return now;}}
 const math=Object.create(Math);math.random=()=>0;
 const c=vm.createContext({Blob,URL,TextEncoder,TextDecoder,Date:Clock,Math:math,Set,Promise,console,AbortController,
  setTimeout:()=>{const n=++alloc;active.add(n);return n;},clearTimeout:n=>active.delete(n),
  fetch:async()=>{throw Error('offline')},
  HLS:require(path.join(base,'src/hls_transport.js')),REC_API_TIMEOUT_MS:1000,REC_SESSION_WRITE_EVERY:9999,
  RECENV:recenv||{}});
 const helper=built.slice(built.indexOf('  // Ordinary HLS only'),built.indexOf('  /* Shared per-part writer:'));
 const classes=built.slice(built.indexOf('  class AudioRecorder'),built.indexOf('  /* ==== RSP RECORDING CORE',built.indexOf('  class AudioRecorder')));
 vm.runInContext(helper+classes+';globalThis.Recorder=Recorder;',c);
 return {Recorder:c.Recorder,c,setNow:n=>{now=n;},active};
}
function standbyRecorder(w,logs){
 const r=Object.create(w.Recorder.prototype);
 Object.assign(r,{recording:true,stopped:false,state:'STANDBY',id:'a'.repeat(24),deadVariants:new Set(),bytes:0,filesSaved:0,
  _autoDenyKey:'',ui:{recState:()=>{}},log:m=>logs.push(String(m)),notify:(t)=>{logs.push('notify:'+t);},updateTitle:()=>{},persistSession:()=>{},
  _fResolveMember:async()=>({ok:true,playlist:'https://new/authorized.m3u8'}),pollPlaylist:async()=>{r.polled=true;},drain:async()=>{},
  stop:async()=>{r.stopped=true;r.recording=false;},creatorName:()=>'fixture',flvUrl:()=>'https://fixture/live.flv',pushData:async()=>{}});
 return r;
}
test('v2.39.0 resume(): denied policy keeps STANDBY, logs once, never polls',async()=>{
 const logs=[],w=world({autoPolicy:async()=>({verdict:'denied'})}),r=standbyRecorder(w,logs);
 await r.resume('ts','配信の復帰');
 a.equal(r.state,'STANDBY');a.equal(r.polled,undefined);a.equal(r.stopped,false);
 a.ok(logs.some(l=>l.includes('自動再開は禁止')));
 await r.resume('ts','再検出');
 a.equal(logs.filter(l=>l.includes('自動再開は禁止')).length,1,'denial log throttled per episode');
 a.equal(logs.filter(l=>l.startsWith('notify:')).length,1,'notify once');
});
test('v2.39.0 resume(): unavailable policy is fail-closed and throttled',async()=>{
 const logs=[],w=world({autoPolicy:async()=>({verdict:'unavailable'})}),r=standbyRecorder(w,logs);
 await r.resume('ts','配信の復帰');
 a.equal(r.state,'STANDBY');a.equal(r.polled,undefined);
 a.ok(logs.some(l=>l.includes('確認できないため自動再開しません')));
 await r.resume('ts','再検出');
 a.equal(logs.filter(l=>l.includes('確認できないため自動再開しません')).length,1);
});
test('v2.39.0 resume(): allowed policy proceeds and re-arm resets deny latch',async()=>{
 const logs=[];let verdict='denied';
 const w=world({autoPolicy:async()=>({verdict})}),r=standbyRecorder(w,logs);
 await r.resume('ts','x');
 a.equal(r.polled,undefined);
 verdict='allowed';
 await r.resume('ts','y');
 a.equal(r.polled,true,'resumes after policy re-allow');
});
test('v2.39.0 tryFlv(): denied policy never starts FLV fetch',async()=>{
 const logs=[],fetches=[];
 const w=world({autoPolicy:async()=>({verdict:'denied'})});
 w.c.fetch=async u=>{fetches.push(String(u));return {ok:true,body:{getReader:()=>({read:async()=>({done:true})})}};};
 const r=standbyRecorder(w,logs);r.flvRunning=false;
 const ok=await r.tryFlv();
 a.equal(ok,false);a.equal(fetches.length,0);a.equal(r.flvRunning,false);
 a.ok(logs.some(l=>l.includes('FLV代替の自動開始は禁止')));
});
test('v2.39.0 tryFlv(): allowed policy starts the FLV attempt',async()=>{
 const logs=[],fetches=[];
 const w=world({autoPolicy:async()=>({verdict:'allowed'})});
 w.c.fetch=async u=>{fetches.push(String(u));throw Error('net');};
 const r=standbyRecorder(w,logs);
 await r.tryFlv();
 a.equal(fetches.length,1,'fetch attempted under allowed policy');
});

/* ---- RECENV.autoPolicy ページ実装(src/player.user.js のdefault実装) ---- */
function sliceMethod(src,startMarker,endMarker){
 const i=src.indexOf(startMarker);
 const j=src.indexOf(endMarker,i);
 a.ok(i>0&&j>i,'slice markers');
 return src.slice(i,j).replace(/,\s*$/,'');
}
function pageAutoPolicyCtx(store,opts={}){
 const c=vm.createContext({chrome:opts.noChrome?undefined:{runtime:{id:'rsp'},storage:{local:{get:(k,cb)=>{if(opts.throw)throw Error('x');if(opts.hang)return;if(opts.lastError)c.chrome.runtime.lastError={message:'denied'};cb(store);}}}},
  setTimeout:fn=>{if(opts.fireTimer){queueMicrotask(fn);return 0;}return 1;},clearTimeout:()=>{},
  __RSP_TEST:opts.testHooks||{},console,Promise,Number});
 const body=sliceMethod(user,'    autoPolicy: function () {','    /* v2.39.0: セッション終了フック');
 vm.runInContext('globalThis.RECENV={testHooks:()=>globalThis.__RSP_TEST};globalThis.fn=({'+body+'}).autoPolicy;',c);
 return ()=>vm.runInContext('fn()',c);
}
test('v2.39.0 page autoPolicy: userscript env (no chrome.storage) stays allowed',async()=>{
 a.equal((await pageAutoPolicyCtx({},{noChrome:true})()).verdict,'allowed');
});
test('v2.39.0 page autoPolicy: saved deny yields denied, unset stays allowed',async()=>{
 a.equal((await pageAutoPolicyCtx({rsp_dashboard_defaults:{autoStartAllowed:false}})()).verdict,'denied');
 a.equal((await pageAutoPolicyCtx({rsp_dashboard_defaults:{autoStartAllowed:true}})()).verdict,'allowed');
 a.equal((await pageAutoPolicyCtx({})()).verdict,'allowed');
});
test('v2.39.0 page autoPolicy: malformed settings and mp4Handover type are unavailable (fail-closed)',async()=>{
 for(const bad of [null,[],{autoStartAllowed:'false'},{mp4Handover:'yes'},{splitMin:-1}])
  a.equal((await pageAutoPolicyCtx({rsp_dashboard_defaults:bad})()).verdict,'unavailable',JSON.stringify(bad));
 a.equal((await pageAutoPolicyCtx({rsp_dashboard_defaults:{mp4Handover:true,autoStartAllowed:false}})()).verdict,'denied','new flag accepted when boolean');
});
test('v2.39.0 page autoPolicy: no-reply timeout resolves unavailable via settingsReadMs seam',async()=>{
 a.equal((await pageAutoPolicyCtx({},{testHooks:{settingsReadMs:5},fireTimer:true,hang:true})()).verdict,'unavailable');
});

/* ---- offscreen RSP_RECENV_HOOK.autoPolicy(src/offscreen_pre.js) ---- */
function offPolicyCtx(store,opts={}){
 const c=vm.createContext({chrome:opts.noChrome?undefined:{runtime:{id:'rsp'},storage:{local:{get:(k,cb)=>{if(opts.throw)throw Error('x');if(opts.hang)return;cb(store);}}}},
  setTimeout:fn=>{if(opts.fireTimer){queueMicrotask(fn);return 0;}return 1;},clearTimeout:()=>{},window:{__RSP_TEST:opts.testHooks||{}},console,Promise,Number});
 const i=pre.indexOf('    autoPolicy: function () {',pre.indexOf('RSP_RECENV_HOOK'));
 const j=pre.indexOf('    /* v2.39.0: セッション終了フック',i);
 a.ok(i>0&&j>i,'offscreen autoPolicy markers');
 const body=pre.slice(i,j).replace(/,\s*$/,'');
 vm.runInContext('const HAS_EXT=typeof chrome!==\'undefined\'&&!!(chrome.runtime&&chrome.runtime.id);globalThis.fn=({'+body+'}).autoPolicy;',c);
 return ()=>vm.runInContext('fn()',c);
}
test('v2.39.0 offscreen autoPolicy: deny/allow/unavailable mirror the BG contract',async()=>{
 a.equal((await offPolicyCtx({rsp_dashboard_defaults:{autoStartAllowed:false}})()).verdict,'denied');
 a.equal((await offPolicyCtx({rsp_dashboard_defaults:{follow:true}})()).verdict,'allowed');
 a.equal((await offPolicyCtx({rsp_dashboard_defaults:{mp4Handover:1}})()).verdict,'unavailable');
 a.equal((await offPolicyCtx({})()).verdict,'allowed');
});
test('v2.39.0 offscreen autoPolicy: environment without extension storage stays allowed, timeout is bounded',async()=>{
 a.equal((await offPolicyCtx({},{noChrome:true})()).verdict,'allowed');
 a.equal((await offPolicyCtx({},{testHooks:{settingsReadMs:5},fireTimer:true,hang:true})()).verdict,'unavailable');
});

/* ---- ui.onLive + uiAutoStart(ページ側経路統一) ---- */
function onLiveCtx(bridge,policyFn){
 const evs={started:0,nudged:0,logs:[],intervals:[]};
 let now=1000;
 const c=vm.createContext({recorder:{recording:false,state:'RUN',start(){evs.started++;},nudgeResume(){evs.nudged++;}},
  autoRec:{checked:true},ui:{log:m=>evs.logs.push(String(m))},window:{__RSP_BG__:bridge},
  RECENV:policyFn?{autoPolicy:policyFn}:undefined,
  Date:{now:()=>now},setInterval:fn=>{evs.intervals.push(fn);return 1;},clearInterval:()=>{},console,Promise});
 const src=user.slice(user.indexOf('    /* v2.39.0: 自動開始の経路統一(ui.onLiveから)'),user.indexOf('    /* ---- 操作まわり ---- */'));
 a.ok(src.length>200&&src.length<3000,'ui.onLive slice');
 vm.runInContext(src,c);
 return {evs,ctx:c,fire:()=>vm.runInContext('ui.onLive()',c)};
}
test('v2.39.0 ui.onLive: BG bridge claims the start (autoNow true) — no in-page start',()=>{
 const calls=[];
 const h=onLiveCtx({autoNow:()=>{calls.push(1);return true;}},async()=>({verdict:'allowed'}));
 h.fire();
 a.equal(calls.length,1);a.equal(h.evs.started,0);
});
test('v2.39.0 ui.onLive: autoNow false falls back to the gated in-page start (denied blocks it)',async()=>{
 const h=onLiveCtx({autoNow:()=>false},async()=>({verdict:'denied'}));
 h.fire();await new Promise(setImmediate);
 a.equal(h.evs.started,0);
 a.ok(h.evs.logs.some(l=>l.includes('自動録画は禁止')));
});
test('v2.39.0 ui.onLive: without bridge, allowed policy starts in-page recording once',async()=>{
 const h=onLiveCtx(undefined,async()=>({verdict:'allowed'}));
 h.fire();await new Promise(setImmediate);
 a.equal(h.evs.started,1);
});
test('v2.39.0 ui.onLive: unavailable policy defers with a 30s retry that recovers when policy turns allowed',async()=>{
 let verdict={verdict:'unavailable'};
 let now=1000;
 const evs={started:0,logs:[],intervals:[]};
 const c=vm.createContext({recorder:{recording:false,state:'RUN',start(){evs.started++;}},autoRec:{checked:true},ui:{log:m=>evs.logs.push(String(m))},
  window:{},RECENV:{autoPolicy:async()=>verdict},Date:{now:()=>now},setInterval:fn=>{evs.intervals.push(fn);return 1;},clearInterval:()=>{},console,Promise});
 vm.runInContext(user.slice(user.indexOf('    /* v2.39.0: 自動開始の経路統一(ui.onLiveから)'),user.indexOf('    /* ---- 操作まわり ---- */')),c);
 vm.runInContext('ui.onLive()',c);
 await new Promise(setImmediate);
 a.equal(evs.started,0);a.equal(evs.intervals.length,1,'retry timer armed');
 now+=20000;evs.intervals[0]();
 await new Promise(setImmediate);
 a.equal(evs.started,0,'still within 30s backoff');
 verdict={verdict:'allowed'};
 now+=11000;evs.intervals[0]();
 await new Promise(setImmediate);await new Promise(setImmediate);
 a.equal(evs.started,1,'retries after backoff once policy is readable and allowed');
 a.ok(evs.logs.some(l=>l.includes('30秒後に再確認')));
});
test('v2.39.0 ui.onLive: STANDBY branch still nudges resume (tracking) without starting',async()=>{
 const h=onLiveCtx(undefined,async()=>({verdict:'allowed'}));
 vm.runInContext('recorder.recording=true;recorder.state="STANDBY"',h.ctx);
 h.fire();await new Promise(setImmediate);
 a.equal(h.evs.started,0);a.equal(h.evs.nudged,1);
});

/* ---- ext_glue autoNow ---- */
function autoNowHarness(){
 const evs={sends:0};
 let bgEnabledVal=true;
 const c=vm.createContext({capCache:null,lastAutoKey:'',autoRetryAt:0,Date:{now:()=>100000},
  bgEnabled:()=>bgEnabledVal,window:{__RSP:{recorder:{id:'a'.repeat(24)}}},
  autoRecAsync:function(key){evs.sends++;c.lastAutoKey=key;}});
 const i=glue.indexOf('    autoNow: function () {');
 const j=glue.indexOf('\n  };',i);
 a.ok(i>0&&j>i,'autoNow slice markers');
 const body=glue.slice(i,j);
 vm.runInContext('globalThis.autoNow=({'+body.replace(/,\s*$/,'')+'}).autoNow;',c);
 return {run:()=>vm.runInContext('autoNow()',c),evs,
  setBg:v=>{bgEnabledVal=v;},setCap:v=>{c.capCache=v;},setRetry:v=>{c.autoRetryAt=v;},latch:()=>vm.runInContext('lastAutoKey',c)};
}
test('v2.39.0 ext_glue autoNow: disabled BG or confirmed-unsupported cap returns false without sending',()=>{
 const h=autoNowHarness();
 h.setBg(false);a.equal(h.run(),false);
 h.setBg(true);h.setCap({offscreen:false});a.equal(h.run(),false);
 a.equal(h.evs.sends,0);
});
test('v2.39.0 ext_glue autoNow: normal path triggers immediate BG auto-start and claims the start',()=>{
 const h=autoNowHarness();
 h.setCap({offscreen:true});
 a.equal(h.run(),true);a.equal(h.evs.sends,1);a.equal(h.latch(),'a'.repeat(24)+':LIVE');
 a.equal(h.run(),true);a.equal(h.evs.sends,1,'latched key does not re-send');
});
test('v2.39.0 ext_glue autoNow: in-flight retry backoff still claims (page must not race BG)',()=>{
 const h=autoNowHarness();
 h.setCap({offscreen:true});h.setRetry(200000);
 a.equal(h.run(),true);a.equal(h.evs.sends,0,'backoff suppresses a new send but claims the path');
});
