'use strict';
/* v2.48.0: 汎用取得 段階設計 Stage 1 — disk-backed segment store の単体検証。
   OPFSモック上でペア書き込み・整合性照合・予算退避・孤児清掃を確認する。 */
const {test}=require('node:test'),a=require('node:assert/strict'),{createHash}=require('node:crypto');
const Store=require('../src/segment_store.js');

const digest=async u8=>createHash('sha256').update(u8).digest('hex');

function mockStorage(){
  const areas=new Map(); /* ns -> Map(name -> bytes) */
  const failClose={on:false};
  const dirFor=ns=>{
    if(!areas.has(ns))areas.set(ns,new Map());
    const files=areas.get(ns);
    return {
      getFileHandle:async(name,opt)=>{
        if(!files.has(name)&&!(opt&&opt.create))throw new DOMException('missing','NotFoundError');
        return {
          kind:'file',
          getFile:async()=>{
            if(!files.has(name))throw new DOMException('missing','NotFoundError');
            const bytes=files.get(name);
            return {size:bytes.length,arrayBuffer:async()=>bytes.slice().buffer,text:async()=>new TextDecoder().decode(bytes)};
          },
          createWritable:async()=>{
            if(failClose.on)throw Error('quota');
            let held=null;
            return {write:async b=>{held=Uint8Array.from(b instanceof Uint8Array?b:new Uint8Array(b));},close:async()=>{if(failClose.on)throw Error('close');files.set(name,held);},abort:async()=>{}};
          }
        };
      },
      removeEntry:async name=>{if(!files.has(name))throw new DOMException('missing','NotFoundError');files.delete(name);},
      async *entries(){for(const [name,bytes] of [...files])yield [name,{kind:'file',getFile:async()=>({size:bytes.length})}];}
    };
  };
  return {
    storage:{getDirectory:async()=>({getDirectoryHandle:async(area,opt)=>({getDirectoryHandle:async(ns,opt2)=>dirFor(ns)})})},
    areas,failClose
  };
}
function make(over={}){
  const m=mockStorage();
  const clock={t:1000};
  const store=Store.create({storage:m.storage,digest,now:()=>clock.t,maxBytes:over.maxBytes,maxCount:over.maxCount,maxSegmentBytes:over.maxSegmentBytes,namespace:over.namespace});
  return {store,areas:m.areas,failClose:m.failClose,clock};
}
const U8=n=>new Uint8Array(n).map((_,i)=>i%251+1);

test('v2.48.0 segment store put/get roundtrip records digest and meta',async()=>{
  const {store}=make();
  const bytes=U8(1000);
  const r=await store.put('a'.repeat(32),bytes);
  a.equal(r.id,'a'.repeat(32));
  a.equal(r.bytes,1000);
  a.equal(r.sha256,await digest(bytes));
  a.equal(r.pinned,false);
  const g=await store.get('a'.repeat(32));
  a.equal(g.bytes.length,1000);
  a.equal(g.meta.bytes,1000);
  a.equal(g.meta.pinned,false);
  a.ok(await store.has('a'.repeat(32)));
});

test('v2.48.0 tampered segment bytes fail closed with SEGMENT_DIGEST_MISMATCH',async()=>{
  const {store,areas}=make({namespace:'tamper'});
  await store.put('b'.repeat(32),U8(64));
  /* .binだけ直接書き換えてメタと不整合にする */
  const files=areas.get('tamper');
  files.set('b'.repeat(32)+'.bin',U8(64).map(x=>x^0xff));
  await a.rejects(()=>store.get('b'.repeat(32)),/SEGMENT_DIGEST_MISMATCH/);
});

test('v2.48.0 size mismatch between bin and meta fails closed',async()=>{
  const {store,areas}=make({namespace:'size'});
  await store.put('c'.repeat(32),U8(64));
  const files=areas.get('size');
  files.set('c'.repeat(32)+'.bin',U8(10));
  await a.rejects(()=>store.get('c'.repeat(32)),/SEGMENT_SIZE_MISMATCH/);
});

test('v2.48.0 byte budget evicts the oldest unpinned segment first',async()=>{
  const {store}=make({maxBytes:1200});
  await store.put('d'.repeat(32),U8(500));   /* at:1000 */
  await store.put('e'.repeat(32),U8(500));   /* at:1000(同一時刻・挿入順) */
  const r=await store.put('f'.repeat(32),U8(500)); /* 1500>1200 → dを退避して収める */
  a.equal(r.evicted,1);
  a.equal(await store.has('d'.repeat(32)),false);
  a.equal(await store.has('e'.repeat(32)),true);
  a.equal(await store.has('f'.repeat(32)),true);
});

test('v2.48.0 pinned segments survive eviction while unpinned are removed',async()=>{
  const {store}=make({maxBytes:1200});
  await store.put('1'.repeat(32),U8(500),{pin:true});
  await store.put('2'.repeat(32),U8(500));
  const r=await store.put('3'.repeat(32),U8(500));
  a.equal(r.evicted,1);
  a.equal(await store.has('1'.repeat(32)),true);
  a.equal(await store.has('2'.repeat(32)),false);
});

test('v2.48.0 all-pinned exhaustion fails closed with SEGMENT_BUDGET_EXCEEDED',async()=>{
  const {store}=make({maxBytes:1200});
  await store.put('1'.repeat(32),U8(500),{pin:true});
  await store.put('2'.repeat(32),U8(500),{pin:true});
  await a.rejects(()=>store.put('3'.repeat(32),U8(500)),/SEGMENT_BUDGET_EXCEEDED/);
});

test('v2.48.0 count budget evicts beyond maxCount',async()=>{
  const {store}=make({maxCount:2});
  await store.put('a1'.padEnd(32,'0'),U8(10));
  await store.put('b2'.padEnd(32,'0'),U8(10));
  await store.put('c3'.padEnd(32,'0'),U8(10));
  a.equal(await store.has('a1'.padEnd(32,'0')),false);
  a.equal(await store.has('c3'.padEnd(32,'0')),true);
});

test('v2.48.0 get refreshes recency so reused segments are not evicted',async()=>{
  const {store,clock}=make({maxBytes:1200});
  await store.put('a'.repeat(32),U8(500));  /* at:1000 */
  clock.t=1001;
  await store.put('b'.repeat(32),U8(500));
  clock.t=1002;
  await store.get('a'.repeat(32));          /* aを再利用 → aが最新になる */
  clock.t=1003;
  const r=await store.put('c'.repeat(32),U8(500)); /* 1500>1200 → 最も古いbが退避 */
  a.equal(r.evicted,1);
  a.equal(await store.has('b'.repeat(32)),false);
  a.equal(await store.has('a'.repeat(32)),true);
});

test('v2.48.0 identifiers and byte inputs are validated fail-closed',async()=>{
  const {store}=make();
  await a.rejects(()=>store.put('short',U8(10)),/BAD_SEGMENT_ID/);
  await a.rejects(()=>store.put('z'.repeat(65),U8(10)),/BAD_SEGMENT_ID/);
  await a.rejects(()=>store.put('a'.repeat(32),'nope'),/BAD_SEGMENT_BYTES/);
  await a.rejects(()=>store.put('b'.repeat(32),new Uint8Array(0)),/BAD_SEGMENT_BYTES/);
  await a.rejects(()=>store.put('c'.repeat(32),U8(17*1048576)),/BAD_SEGMENT_BYTES/);
  await a.rejects(()=>store.get('../escape'),/BAD_SEGMENT_ID/);
  await a.rejects(()=>store.delete('no-such-id!'),/BAD_SEGMENT_ID/);
});

test('v2.48.0 delete removes the pair and reports absence honestly',async()=>{
  const {store}=make();
  await store.put('a'.repeat(32),U8(32));
  a.deepEqual(await store.delete('a'.repeat(32)),{ok:true,removed:true});
  a.equal(await store.has('a'.repeat(32)),false);
  a.deepEqual(await store.delete('a'.repeat(32)),{ok:true,removed:false});
});

test('v2.48.0 orphan sweep removes unpaired bin/json and keeps valid pairs',async()=>{
  const {store,areas}=make({namespace:'orph'});
  await store.put('a'.repeat(32),U8(32));
  const files=areas.get('orph');
  files.set('deadbeef'.padEnd(40,'0')+'.bin',U8(8));       /* メタ無しの孤児bin */
  files.set('ff'.padEnd(40,'f')+'.json',new TextEncoder().encode('{}')); /* 本体無しの孤児json(ID不正) */
  const r=await store.sweep();
  a.equal(r.ok,true);
  a.equal(r.orphans,2);
  a.equal(await store.has('a'.repeat(32)),true);
  a.equal(files.has('deadbeef'.padEnd(40,'0')+'.bin'),false);
  a.equal(files.has('ff'.padEnd(40,'f')+'.json'),false);
});

test('v2.48.0 setPinned toggles the meta and get observes it',async()=>{
  const {store}=make();
  await store.put('a'.repeat(32),U8(16));
  a.deepEqual(await store.setPinned('a'.repeat(32),true),{ok:true,pinned:true});
  const g=await store.get('a'.repeat(32));
  a.equal(g.meta.pinned,true);
});

test('v2.48.0 stats report bounded usage per namespace',async()=>{
  const {store}=make({namespace:'stats'});
  await store.put('a'.repeat(32),U8(100));
  await store.put('b'.repeat(32),U8(200));
  const s=await store.stats();
  a.equal(s.count,2);
  a.equal(s.bytes,300);
  a.equal(s.namespace,'stats');
});

test('v2.48.0 namespaces are isolated from each other',async()=>{
  const {store}=make({namespace:'n1'});
  const {store:s2}=make({namespace:'n2'});
  await store.put('a'.repeat(32),U8(16));
  a.equal(await s2.has('a'.repeat(32)),false);
  await s2.put('a'.repeat(32),U8(24));
  const g1=await store.get('a'.repeat(32)),g2=await s2.get('a'.repeat(32));
  a.equal(g1.bytes.length,16);
  a.equal(g2.bytes.length,24);
});

test('v2.48.0 missing storage fails closed at construction',()=>{
  a.throws(()=>Store.create({storage:null}),/STORAGE_UNAVAILABLE/);
  a.throws(()=>Store.create({}),/STORAGE_UNAVAILABLE/);
});

test('v2.48.0 write failure never leaves a meta-only record behind',async()=>{
  const {store,failClose}=make();
  failClose.on=true;
  await a.rejects(()=>store.put('a'.repeat(32),U8(16)),/SEGMENT_WRITE_FAILED/);
  failClose.on=false;
  a.equal(await store.has('a'.repeat(32)),false);
});

test('v2.48.0 oversize single segment beyond maxSegmentBytes is rejected before eviction',async()=>{
  const {store}=make({maxSegmentBytes:100,maxBytes:1000});
  await a.rejects(()=>store.put('a'.repeat(32),U8(101)),/BAD_SEGMENT_BYTES/);
  const s=await store.stats();
  a.equal(s.count,0);
});
