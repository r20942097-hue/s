'use strict';
/* v2.14.0 core features (TS anti-fragmentation & Video DownloadHelper / Stream Recorder / rplay_watcher v0.5.2 learnings):
   1. Unified 2.14.0 version pin across userscript/manifests/CLI strings.
   2. MPEG-TS EXT-X-DISCONTINUITY seamless append by default (no part split on TS discontinuity
      unless splitOnDiscontinuity is enabled), while fMP4 (EXT-X-MAP) still splits on boundary.
   3. Default splitMinutes changed from 20 to 0 (no forced 20-min splitting by default),
      and offscreen OPFS partByteLimit raised from 64 MiB to 512 MiB (2 GiB when FSA dirHandle is active).
   4. Segment 503 Retry-After backoff in both video and audio recorders (integrated from v2.7.1 patch).
   5. Master 200 / Media 404 paywall detection (paywall_blocked) & partContinuityEvidence cross-language parity. */
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),vm=require('vm');
const {spawnSync}=require('node:child_process');
const H=require('../src/hls_transport.js');
const ROOT=path.join(__dirname,'..');
const source=fs.readFileSync(path.join(ROOT,'rplay-stable-player.user.js'),'utf8');

const base='https://fixture/live.m3u8',playlist=s=>'#EXTM3U\n#EXT-X-TARGETDURATION:1\n'+s;
const tsSeg=Buffer.alloc(188*2);tsSeg[0]=0x47;tsSeg[188]=0x47;
const box=type=>Buffer.concat([Buffer.from([0,0,0,8]),Buffer.from(type)]),init=Buffer.concat([box('ftyp'),box('moov')]),fragment=Buffer.concat([box('moof'),box('mdat')]);

test('v2.14.0 version pin: userscript @version, both manifests, CLI strings',()=>{
  const us=fs.readFileSync(path.join(ROOT,'rplay-stable-player.user.js'),'utf8');
  assert.match(us,/\/\/ @version\s+2\.(?:41|42|43|44|45|46|47|48|49|50)\.0/);
  for(const ext of ['rplay-stable-player-extension','rplay-stable-player-extension-firefox']){
    const m=JSON.parse(fs.readFileSync(path.join(ROOT,ext,'manifest.json'),'utf8'));
    assert.match(m.version,/^2\.(?:41|42|43|44|45|46|47|48|49|50)\.0$/,ext);
    if(ext.endsWith('-firefox')) assert.equal(Object.hasOwn(m,'version_name'),false,'Firefox must omit unsupported version_name'); else assert.match(m.version_name,/^2\.(?:41|42|43|44|45|46|47|48|49|50)\.0 CANDIDATE$/,ext+' version_name');
  }
  const cli=fs.readFileSync(path.join(ROOT,'rplay_dl.py'),'utf8');
  assert.match(cli,/RPLAY Live Downloader v2\.(?:41|42|43|44|45|46|47|48|49|50)\.0 CANDIDATE/);
  assert.match(cli,/rplay_dl\.py v2\.(?:41|42|43|44|45|46|47|48|49|50)\.0/);
  assert.match(cli,/\(rplay_dl\.py\) v2\.(?:41|42|43|44|45|46|47|48|49|50)\.0/);
});

test('v2.14.0 MPEG-TS EXT-X-DISCONTINUITY appends seamlessly to single part by default, splits when splitOnDiscontinuity=true',async()=>{
  const makeOwner=(splitDisc=false)=>({
    seen:new Set(),queue:[],writes:[],parts:[],partOpen:false,
    splitOnDiscontinuity:()=>splitDisc,
    pushData(x){this.partOpen=true;this.writes.push(Buffer.from(x));},
    async closePart(){if(this.partOpen)this.parts.push(Buffer.concat(this.writes));this.partOpen=false;this.writes=[];}
  });
  const m3u8=playlist('#EXTINF:1,\na.ts\n#EXT-X-DISCONTINUITY\n#EXTINF:1,\nb.ts\n#EXT-X-DISCONTINUITY\n#EXTINF:1,\nc.ts');
  // 1) Default (splitDisc=false): 3 TS segments across 2 discontinuities stay in 1 continuous part
  const o1=makeOwner(false);
  o1._hlsTransfer=H.createTransfer(async()=>new Response(tsSeg));
  H.enqueue(o1,H.parse(m3u8,base),base);
  for(const item of o1.queue){const r=await H.fetchItem(o1,item);await H.append(o1,item,{...r,data:r.bytes});}
  await o1.closePart();
  assert.equal(o1.parts.length,1,'TS segments across discontinuity must stay in 1 part by default');
  assert.equal(o1.parts[0].length,tsSeg.length*3);
  assert.equal(o1._hlsContinuity.discontinuityMergedCount,2);
  assert.equal(o1._hlsContinuity.discontinuitySplitCount,0);

  // 2) Opt-in splitDisc=true: splits into 3 parts
  const o2=makeOwner(true);
  o2._hlsTransfer=H.createTransfer(async()=>new Response(tsSeg));
  H.enqueue(o2,H.parse(m3u8,base),base);
  for(const item of o2.queue){const r=await H.fetchItem(o2,item);await H.append(o2,item,{...r,data:r.bytes});}
  await o2.closePart();
  assert.equal(o2.parts.length,3,'TS segments must split when splitOnDiscontinuity is true');
  assert.equal(o2._hlsContinuity.discontinuitySplitCount,2);

  // 3) fMP4 (EXT-X-MAP) always splits on discontinuity to preserve init-segment integrity
  const o3=makeOwner(false);
  o3._hlsTransfer=H.createTransfer(async u=>new Response(u.endsWith('init.mp4')?init:fragment));
  const fmp4List=playlist('#EXT-X-MAP:URI="init.mp4"\n#EXTINF:1,\na.m4s\n#EXT-X-DISCONTINUITY\n#EXTINF:1,\nb.m4s');
  H.enqueue(o3,H.parse(fmp4List,base),base);
  for(const item of o3.queue){const r=await H.fetchItem(o3,item);await H.append(o3,item,{...r,data:r.bytes});}
  await o3.closePart();
  assert.equal(o3.parts.length,2,'fMP4 must still split on discontinuity');
});

test('v2.14.0 default splitMin=0 (continuous single-file) and raised offscreen/FSA partByteLimit',()=>{
  const offPre=fs.readFileSync(path.join(ROOT,'src/offscreen_pre.js'),'utf8');
  assert.match(offPre,/splitMin:\s*0\b/);
  assert.match(offPre,/partByteLimit:\s*512\s*\*\s*1048576/);
  const extGlue=fs.readFileSync(path.join(ROOT,'src/ext_glue.js'),'utf8');
  assert.match(extGlue,/s\.splitMin\s*=\s*0/);
  assert.match(source,/value:\s*'0',\s*title:\s*'この分数でファイル自動分割\(0=時間分割なし。保存先選択時はHLSを連続保存\)'/);
  assert.match(source,/fileCapBytes\(\)/);
});

test('v2.14.0 segment 503 Retry-After sets segBackoffUntil / backoffUntil',async()=>{
  const s0=source.slice(source.indexOf('  function recRetryAfterMs'),source.indexOf('  const REC_FILE_CAP_BYTES'));
  const s1=source.slice(source.indexOf('  async function recFetchDescriptor'),source.indexOf('  class AudioRecorder'));
  const code=s0+'\n'+s1;
  let now=100000;
  const c=vm.createContext({
    Date:{now:()=>now,parse:Date.parse},Math, parseInt, isNaN, Promise, setTimeout:f=>f(),
    RECENV:{partByteLimit:600*1048576,testHooks:()=>({}),pageUrl:()=>'https://rplay.live/',makeWorker:()=>null},
    fetch:async()=>({}), REC_REQ_MIN_GAP_MS:0, REC_SEG_TIMEOUT_MS:5000, REC_429_BASE_MS:30000, REC_429_MAX_MS:300000, REC_403_COOLDOWN_MS:60000,
    HLS:{alive:()=>true,createTransfer:()=>({}),fetchItem:async()=>({status:503,retryAfter:'12'})}
  });
  vm.runInContext(code+';globalThis.fn=recFetchDescriptor;',c);
  const videoOwner={_lastReqAt:0,segBackoffUntil:0,segFails:0,log:()=>{}};
  const r1=await c.fn(videoOwner,{tries:0});
  assert.equal(r1.retry,true);
  assert.equal(videoOwner.segBackoffUntil,now+12000);

  const audioOwner={rec:videoOwner,backoffUntil:0,segFails:0,log:()=>{}};
  const r2=await c.fn(audioOwner,{tries:0});
  assert.equal(r2.retry,true);
  assert.equal(audioOwner.backoffUntil,now+12000);
});

test('v2.14.0 partContinuityEvidence & paywall_blocked cross-language parity (JS vs Python)',()=>{
  const s1=source.slice(source.indexOf('function rspDetectPaywallBlocked'),source.indexOf('function parseSubtitleRenditions'));
  const c=vm.createContext({JSON,Number,Boolean,Array});
  vm.runInContext(s1+';globalThis.fns={cont:rspPartContinuityEvidence,pw:rspDetectPaywallBlocked};',c);
  const fns=c.fns;
  assert.equal(fns.pw(200,404),true);
  assert.equal(fns.pw(200,403),true);
  assert.equal(fns.pw(200,200),false);
  assert.equal(fns.pw(404,404),false);

  const sample={splitMinutes:0,maxSizeMb:600,splitOnDiscontinuity:false,discontinuityMergedCount:4,discontinuitySplitCount:0,sameSessionStandbyContinuations:1,partsConcatenated:0,concatOutput:null};
  const jsEv=JSON.parse(JSON.stringify(fns.cont(sample)));
  const py=spawnSync('python3',['-c',
    "import importlib.util,json,pathlib\n"+
    "spec=importlib.util.spec_from_file_location('x',pathlib.Path('rplay_dl.py'))\n"+
    "m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)\n"+
    "s=json.loads('"+JSON.stringify(sample)+"')\n"+
    "print(json.dumps({'ev':m.part_continuity_evidence(s),'pw':[m.detect_paywall_blocked(200,404),m.detect_paywall_blocked(200,200)]}))"],
    {cwd:ROOT,encoding:'utf8'});
  assert.equal(py.status,0,py.stderr);
  const out=JSON.parse(py.stdout);
  assert.deepEqual(jsEv,out.ev);
  assert.deepEqual([fns.pw(200,404),fns.pw(200,200)],out.pw);
});

test('v2.14.0 Recorder standby resume within 600s keeps part open when splitMinutes=0',async()=>{
  assert.match(source,/sameSessionStandbyContinuations/);
  assert.match(source,/partContinuityEvidence:/);
});
