'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),vm=require('vm'),{webcrypto}=require('node:crypto');
const source=fs.readFileSync(require('path').join(__dirname,'../rplay-stable-player-extension/content.js'),'utf8');
const rspPartCommit=vm.runInNewContext(fs.readFileSync(require('path').join(__dirname,'../src/part_commit_core.js'),'utf8')+'\nrspPartCommit',{});
function world(env={}){
 const code=source.slice(source.indexOf('  function recTrackSave'),source.indexOf('  /* ================= v1.11.0: AudioRecorder'));
 const classes=source.slice(source.indexOf('  class AudioRecorder'),source.indexOf('  /* ==== RSP RECORDING CORE',source.indexOf('  class AudioRecorder')));
 const c=vm.createContext({Blob,crypto:webcrypto,Date,Set,Promise,console,HLS:require('../src/hls_transport.js'),RspSha256:require('../src/sha256.js'),rspPartCommit,RECENV:{download:async()=>undefined,...env},REC_FILE_CAP_BYTES:600*1048576,REC_REQ_MIN_GAP_MS:0,REC_QUEUE_WARN_MS:60000});
 vm.runInContext(code+classes+';globalThis.api={RecPartSink,Recorder,AudioRecorder,recTrackSave,recWaitSaves,recSha256Hex}',c);return c.api;
}
function directory(options={}){let data=[],release;const state={size:0,closed:false,aborted:false};
 const writer={write:async b=>{if(options.writeFail)throw Error('disk');data.push(new Uint8Array(b));},close:async()=>{if(options.closeFail)throw Error('close');state.closed=true;state.size=data.reduce((n,b)=>n+b.length,0);},abort:async()=>{state.aborted=true;}};
 const ready=options.delayed?new Promise(r=>release=r):Promise.resolve();
 return {state,release:()=>release(),getFileHandle:async()=>{await ready;if(options.openFail)throw Error('open');return {createWritable:async()=>writer,getFile:async()=>new Blob([options.sizeMismatch?'badsize':Buffer.concat(data.map(Buffer.from))])}}};
}
test('slow writer open is awaited by close and bytes verified',async()=>{const a=world(),dir=directory({delayed:true}),p=new a.RecPartSink('test.ts',dir,'ts');p.push(new Uint8Array([1,2,3]));let done=false;const close=p.close().then(r=>(done=true,r));await Promise.resolve();assert(!done);dir.release();const r=await close;assert(r.confirmed);assert.equal(dir.state.size,3);});
test('different asynchronously opened parts never share writers',async()=>{const a=world(),d1=directory({delayed:true}),d2=directory(),p1=new a.RecPartSink('x.ts',d1,'ts'),p2=new a.RecPartSink('x.ts',d2,'ts');p1.push(new Uint8Array([1]));p2.push(new Uint8Array([2,3]));const c1=p1.close();await p2.close();assert.equal(d2.state.size,2);d1.release();await c1;assert.equal(d1.state.size,1);assert.notEqual(p1.name,p2.name);});
test('write failure aborts part, never confirms',async()=>{const a=world(),d=directory({writeFail:true}),p=new a.RecPartSink('x.ts',d,'ts');p.push(new Uint8Array([1]));await assert.rejects(()=>p.close(),/PART_WRITE_FAILED/);assert(d.state.aborted);});
test('writer close failure rejects confirmation',async()=>{const a=world(),d=directory({closeFail:true}),p=new a.RecPartSink('x.ts',d,'ts');p.push(new Uint8Array([1]));await assert.rejects(()=>p.close());});
test('file size mismatch rejects confirmation',async()=>{const a=world(),d=directory({sizeMismatch:true}),p=new a.RecPartSink('x.ts',d,'ts');p.push(new Uint8Array([1]));await assert.rejects(()=>p.close());});
test('folder open failure falls back with all original bytes',async()=>{let data;const a=world({download:async b=>{data=new Uint8Array(await b.arrayBuffer());return {confirmed:true,stage:'OPFS_STAGED'}}}),p=new a.RecPartSink('x.ts',directory({openFail:true}),'ts');p.push(new Uint8Array([4,5]));const r=await p.close();assert(r.confirmed);assert.deepEqual([...data],[4,5]);});
test('ordinary page anchor request is not confirmed file',async()=>{const a=world(),p=new a.RecPartSink('x.ts',null,'ts');p.push(new Uint8Array([1]));const r=await p.close();assert.equal(r.confirmed,false);assert.equal(r.stage,'DOWNLOAD_REQUESTED');});
test('OPFS stage rejection propagates into part failure',async()=>{const a=world({download:async()=>{throw Error('quota')}}),p=new a.RecPartSink('x.ts',null,'ts');p.push(new Uint8Array([1]));await assert.rejects(()=>p.close());});
function recorder(a,audio=false){const r=Object.create((audio?a.AudioRecorder:a.Recorder).prototype);Object.assign(r,{partOpen:true,bytes:3,segCount:1,partExt:'ts',partName:'x.ts',fileStartedAt:Date.now(),partsLog:[],filesSaved:0,filesByExt:{},partIndex:0,log:()=>{},partIO:{close:async()=>({confirmed:true,stage:'OPFS_STAGED'})}});return r;}
test('actual video recorder counts successful local stage',async()=>{const a=world(),r=recorder(a);await r.closePart();assert.equal(r.filesSaved,1);assert.equal(r.partsLog[0].saveState,'OPFS_STAGED');});
test('actual audio recorder does not count failed staging',async()=>{const a=world(),r=recorder(a,true);r.partIO.close=async()=>{throw Error('quota')};await r.closePart();assert.equal(r.filesSaved,0);assert.equal(r.failedSaves,1);assert.equal(r.partsLog[0].saveState,'failed');});
test('actual video recorder separates unverified request from saved count',async()=>{const a=world(),r=recorder(a);r.partIO.close=async()=>({confirmed:false,stage:'DOWNLOAD_REQUESTED'});await r.closePart();assert.equal(r.filesSaved,0);assert.equal(r.saveRequests,1);});
test('actual stop waits before history and IDLE event',async()=>{const a=world();let release;const gate=new Promise(r=>release=r),r=recorder(a),events=[];r.partOpen=false;Object.assign(r,{recording:true,stopped:false,state:'RUN',abortFlv:()=>{},restoreTitle:()=>{},ui:{recState:(on,s)=>events.push(s)},infoJson:()=>false,saveHistory:()=>events.push('history'),clearSession:()=>{},audio:null});a.recTrackSave(r,gate);const stopping=r.stop(false);await Promise.resolve();assert.deepEqual(events,['DRAINING']);release();await stopping;assert.deepEqual(events,['DRAINING','history','IDLE']);assert.equal(r.isDraining,false);});
test('segment finishing after stop cannot open a new part',async()=>{const a=world(),r=Object.create(a.Recorder.prototype);let release,pushed=0;r.queue=[{}];r.state='RUN';r.stopped=false;r.segBackoffUntil=0;r.fetchSeg=()=>new Promise(x=>release=x);r.pushData=()=>pushed++;const job=r.drain();r.stopped=true;release({data:new Uint8Array([1])});await job;assert.equal(pushed,0);});

test('v2.11 slow disk backpressure prevents HLS append from completing early',async()=>{
 const a=world();let release;const gate=new Promise(r=>release=r),written=[];
 const dir={getFileHandle:async()=>({createWritable:async()=>({write:async b=>{await gate;written.push([...b]);},close:async()=>{}})})};
 const io=new a.RecPartSink('slow.ts',dir,'ts');
 const owner=Object.assign(Object.create(a.Recorder.prototype),{partIO:io,ensurePart(){},bytes:0,bytesTotal:0,partOpen:true});
 let done=false;const task=require('../src/hls_transport.js').append(owner,{}, {data:new Uint8Array([1,2])}).then(()=>done=true);
 await new Promise(r=>setImmediate(r));assert.equal(done,false);assert.equal(io.chunks.length,0);
 release();await task;assert.deepEqual(written,[[1,2]]);assert.equal(owner.bytesTotal,2);
});
test('v2.11 init write stopped in flight cannot append media into a new part',async()=>{
 const H=require('../src/hls_transport.js');let release,calls=0;
 const owner={pushData:async()=>{calls++;await new Promise(r=>release=r);}};
 const job=H.append(owner,{hls:{epoch:0,discontinuity:0,map:{}}},{init:new Uint8Array([1]),data:new Uint8Array([2]),boundary:'b'});
 await new Promise(r=>setImmediate(r));owner.stopped=true;release();assert.equal(await job,false);assert.equal(calls,1);
});
test('v2.11 direct HLS continuous mode exceeds cap while Blob fallback still splits',async()=>{
 const a=world();for(const audio of [false,true])for(const disk of [false,true]){
  const r=recorder(a,audio);let closed=0;
  Object.assign(r,{bytes:3*1024*1048576,splitMinutes:()=>0,fileCapBytes:()=>2048*1048576,
   partIO:{writer:disk?{}:null,continuousDisk:()=>disk},closePart:()=>closed++});
  if(audio)r.rec={splitMinutes:()=>0,fileCapBytes:()=>2048*1048576};
  r.maybeSplit();assert.equal(closed,disk?0:1);
 }
});
test('v2.11 timed splitting and FLV retain their caps',()=>{
 const a=world();for(const ext of ['ts','mp4','flv']){
  const r=recorder(a);let closed=0;const io=new a.RecPartSink('x.'+ext,null,ext);io.writer={};
  Object.assign(r,{partIO:io,bytes:3000,splitMinutes:()=>1,fileCapBytes:()=>2000,closePart:()=>closed++});
  r.maybeSplit();assert.equal(closed,1,ext);
  assert.equal(io.continuousDisk(),ext!=='flv');
 }
});
test('v2.13 large-file hashing uses bounded reads and matches independent SHA256',async()=>{
 const a=world();let max=0,reads=0;const data=new Blob([new Uint8Array(33*1048576)]);
 const input={size:data.size,slice(start,end){max=Math.max(max,end-start);reads++;return data.slice(start,end);},arrayBuffer(){throw Error('full allocation');}};
 assert.equal(await a.recSha256Hex(input),require('node:crypto').createHash('sha256').update(Buffer.alloc(data.size)).digest('hex'));
 assert.equal(max,1048576);assert.equal(reads,33);
});
test('v2.11 disk failure stops producer and rejects append without success',async()=>{
 const a=world(),dir=directory({writeFail:true}),io=new a.RecPartSink('bad.ts',dir,'ts');let stopped=0;
 const owner=Object.assign(Object.create(a.Recorder.prototype),{partIO:io,ensurePart(){},bytes:0,bytesTotal:0,log(){},stop(){stopped++;this.stopped=true;}});
 await assert.rejects(()=>owner.pushData(new Uint8Array([1])),/PART_WRITE_FAILED/);
 assert.equal(stopped,1);await assert.rejects(()=>io.close());assert(dir.state.aborted);
});
