(function(root){'use strict';
/* =====================================================================
   RPLAY Stable Player — Creator Metadata Cache (v2.31.0)
   =====================================================================
   登録済み/既知の配信者IDに対する表示名の小さなキャッシュ(秘密なし)。
   情報源は既に取得済みの応答(配信一覧/ライブ走査/BG録画開始時のcreatorName)
   のみで、このモジュール自体は一切通信しない。
   - normalize: 形状検証(IDは24桁hex・名前は制御文字除去/80字以内)と
     上限500件へのtruncate(古い at から落とす)。壊れた入力は捨てる(安全側)。
   - harvest: {oid,nick} の配列から追加/更新。同名は at を更新するだけ。
   - lookup: 名前(無ければ空文字)。
   - serialize/deserialize: localStorage/chrome.storage用の安全な変換。
     64KiB超過は null(保存しない)。
   ===================================================================== */
const OID_RE=/^[a-f0-9]{24}$/,NAME_MAX=80,MAX_ENTRIES=500,SERIALIZE_LIMIT=64*1024;
function sanitizeName(v){let s=String(v==null?'':v).replace(/[\u0000-\u001f\u007f]/g,' ').trim();return s?s.slice(0,NAME_MAX):'';}
function normalize(map,nowMs){const out={};if(!map||typeof map!=='object')return out;
 const rows=[];
 for(const k of Object.keys(map)){const oid=String(k||'').toLowerCase();if(!OID_RE.test(oid))continue;
  const v=map[k];if(!v||typeof v!=='object')continue;const name=sanitizeName(v.name);
  if(!name)continue;let at=Number(v.at);if(!Number.isFinite(at)||at<=0)at=Number(nowMs)||0;
  rows.push({oid,name,at:Math.floor(at)});}
 rows.sort((a,b)=>a.at-b.at);
 while(rows.length>MAX_ENTRIES)rows.shift();
 for(const r of rows)out[r.oid]={name:r.name,at:r.at};
 return out;}
function harvest(map,items,nowMs){const out=normalize(map,nowMs);const now=Number(nowMs)||0;let changed=false;
 const list=Array.isArray(items)?items:[];
 for(const it of list){if(!it||typeof it!=='object')continue;
  const oid=String(it.oid||'').toLowerCase();if(!OID_RE.test(oid))continue;
  const name=sanitizeName(it.nick!=null?it.nick:it.name);if(!name)continue;
  const cur=out[oid];
  if(cur){if(cur.name!==name){cur.name=name;cur.at=now;changed=true;}else if(now>cur.at){cur.at=now;}}
  else{out[oid]={name:name,at:now};changed=true;}}
 return changed?out:null;/* 変更が無ければnull — 呼び側は保存を省略できる */}
function lookup(map,oid){if(!map||typeof map!=='object')return '';const v=map[String(oid||'').toLowerCase()];
 return v&&typeof v==='object'?sanitizeName(v.name):'';}
function serialize(map){try{const json=JSON.stringify(map);if(!json||json.length>SERIALIZE_LIMIT)return null;return json;}catch(e){return null;}}
function deserialize(str){if(typeof str!=='string'||!str)return null;try{const v=JSON.parse(str);
 if(!v||typeof v!=='object'||Array.isArray(v))return null;const out=normalize(v);return Object.keys(out).length?out:null;}catch(e){return null;}}
const api={normalize:normalize,harvest:harvest,lookup:lookup,serialize:serialize,deserialize:deserialize,sanitizeName:sanitizeName,MAX_ENTRIES:MAX_ENTRIES};
if(typeof module!=='undefined')module.exports=api;root.RspCreatorMeta=api;
})(globalThis);
