# v2.37.0 QA

追加Node8件: 5実行物への同一byte注入(1回だけ)、ソースのmarker/inline残骸不在、生成offscreenコピーの上限契約(UTF8連結+解放)、生成offscreenの超過拒否(再試行なし)、生成offscreen pre領域の旧一括読込不在、5xxの1回再試行と500連続時2回限り、429の不時試行+retry-after透過、本文停止のbody timeout取消と解放。旧本文abort fixture(test_v2310_abort.cjs)とstream契約fixture(test_v2361_json.cjs)はsrc/json_fetch.js直接試験へ移行し、従来の3件+5件を維持しました。生成物をsourceとするv270/v280/v290/v2150/v2160/v291の版ピンと、範囲ピン(v2100/v2120/v260/v270/v280/v290/v291)はlast-2+current方針(35|36|37)へ回転しました。

根拠資料: MDN Using readable streams https://developer.mozilla.org/en-US/docs/Web/API/Streams_API/Using_readable_streams (2026-10-27参照)。response.bodyのstream読込とAbortControllerによる取消を確認し、独自の上限検査を実装しました(v2.36.0と共通)。

2026-10-27: 全回帰680件PASS(Node515/Python165)。Nodeは+8件(旧507に新8件、fixture移行で件数変更なし)。Pythonは165件で変動なし。TS→MP4の独立disk SHA256、FFmpeg全decode、AAC保存、OPFS復旧・取消、64MiB超入力を継承検証。

本環境の限定: 実ブラウザー受入(Firefox/Floorpのtemporary install、native Web Locks、native preview)は本環境では未実施です。設定・登録の競合保護やWeb Locksの実DOM確認はv2.36.0のfirefox-v236/floorp-v236証跡が最新で、本版のコード変更はJSON取得経路のみですが、dashboardは未変更でも受入は本版ZIPでの再実施を推奨します。実RPLAY/Windows/2GiB/長時間も未確認です。

試験対象のruntime・test本体・buildを最終成果物とbyte比較済み。ZIP CRC・全ファイルhash台帳を確認。
