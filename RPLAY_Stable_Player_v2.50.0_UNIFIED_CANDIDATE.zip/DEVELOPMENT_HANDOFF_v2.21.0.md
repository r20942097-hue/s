# v2.21.0 引き継ぎ

現在版: v2.21.0 UNIFIED CANDIDATE。ベースv2.20を保全して別版で更新。

## 編集箇所

src/player.user.js: rspSourceCandidates(共有録画コア内)、Engine.hlsCandidates/transports、Recorder.playlistUrl/source refresh、Discovery parse/scan/lifecycle/CSS。
src/ext_glue.js: BG欄の再注入、配信一覧内の表示、ファイル別状態リスト、対象配信へのリンク、直列poll。
src/offscreen_post.js: bounded recordingParts/lastParts、rec.status返却。
src/export_manager.js: 永続台帳のsummaryに限定メタデータitemsを追加。
一次ソースから scripts/build.py で5録画コアと拡張の派生物を生成する。

## 再検証

python scripts/build.py
python scripts/package_release.py /outside/project/output.zip
python scripts/validate.py --output-dir /outside/project/evidence

ledger照合があるため、編集後はpackageでSHA256SUMSを再生成してからvalidateする。
Node397/Python162の559件。tests/fixtures/discovery_v220.jsは以前の配信一覧ソースを抜粋した不具合再現用fixtureで製品に読み込まない。

## 残る優先課題

1. 実Firefox/Chromeで拡張とタブを再読み込みし、配信一覧API応答の形状を秘密を除いて観測。現行API契約は未確定。session IDをcreator IDに戻す推測はしない。
2. 公式の新旧プレイヤーUIの実DOMを採取し、経路・再接続・音量・バックグラウンド動作を実機比較。
3. BG停止→書込み完了→DLサイズ照合、権限引き継ぎ、タブ閉じ、フォルダ権限失効を実環境で検証。
4. 最終フォルダパート一覧はホストメモリのみ。拡張プロセス再起動後にも履歴を維持したい場合は別の永続メタデータ設計が必要。DL台帳は永続。
5. その他のMP4/SPS/パラメータセット等の制限はv2.20引き継ぎ参照。

BG録画は同時1配信。今回のリスト表示追加を複数配信同時録画と取り違えないこと。
ログインAPIの進行中fetchは既存timeoutまで残りうるが閉じた結果は反映しない。公開fetchはabortし、予約済みの後続要求は閉じた後に開始しない。
