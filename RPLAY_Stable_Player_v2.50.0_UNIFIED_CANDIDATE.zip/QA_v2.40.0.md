# QA v2.40.0 — 2026-10-27 JST

全回帰732件PASS（Node567/Python165）。前版721件から+11件: 巡回の中止・終了10件、BG route1件。構文/manifest参照/共通core/派生コピー/再build byte一致を確認。証拠evidence/v240-current。

追加10件: API飛行中取消、400ms待機取消、別IDの操作拒否、開始前取消、10秒lease失効、進捗renewとtimer cleanup、BG auth→共有JSON→response bodyまでのAbortSignal伝播、実dashboardスクリプトで進捗/取消/遅延行抑止、pagehide cleanup、metadata待機中取消。DOM/ネットワークはmockで実ブラウザではない。
route試験はdashboardのみstatus/cancelを中継し、不正ID/content起点を拒否。旧scan配線試験の期待値をrequestId付きへ更新。旧予約harnessへAbortControllerを提供。

さらに独立確認2件PASS: node --test tests/check_recording_during_scan.cjs。Chrome/Firefox構成の本番生成host/routerを使い、予約HTTPが未完了でもrec.stopが完了し、次に予約を中止できることを確認。Recorderはdouble、storage/ブラウザAPIはmock。初回はharnessのURLSearchParams不足でHTTPへ到達せず、テスト環境へ標準URLSearchParamsを与えて再確認済み。製品コードのネットワーク条件を緩和していない。

実RPLAY・実ブラウザ（現行Firefox/Floorp）・Windows・2GiB・長時間・native preview進行は未合格。旧版のブラウザPASSを本版へ転記しない。CANDIDATE_NO_GO維持。

配布時にZIPのCRCと全ファイルhashを照合しPASSを確認済み。runtimeは全回帰後に変更していない。
