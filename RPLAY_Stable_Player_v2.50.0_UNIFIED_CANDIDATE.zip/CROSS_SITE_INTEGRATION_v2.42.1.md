# Cross-site integration v2.42.1 — technical status

The Firefox and Chromium WebExtension packages are version 2.42.1; their original recorder, userscript, and CLI cores remain at v2.42.0. This is an integration candidate, **not** a full multi-site media downloader.

## Implemented

- `src/media_catalog.js`: classify **observed successful media responses** as HLS, DASH, or MP4 by extension or MIME, including HTTP 206 for MP4 only; bounded per-tab/overall/session-only candidate registry, no persistence of URL signatures in list, no autoplay/fetch on discovery. The inspector alone may retrieve the full selected URL and observed nonsecret metadata.
- `src/cross_site_core.js`: classic-script WebExtension-compatible diagnostic parser. HLS master/rendition/segment counts, sequence and discontinuity, explicit/implicit byte ranges with strict prior-resource checks, init map presence, encryption/DRM flag, LL-HLS PART/SKIP indicators, live-window dedup and suspected sequence gaps.
- `src/media_inspect.html/js`: explicitly requested offline advanced diagnosis and comparison of separately observed snapshots. Page origin classification is based on the **observed page context** if available; otherwise only the media CDN is classified. Signed query/URL paths and authorization values never appear in diagnostic reports.
- Candidate list labels show HLS/DASH/MP4. HLS manifest fetch, cookies, parent query inheritance, output-command creation, RPLAY recording remain on existing v2.42.0 paths.

## Limitations and safety

- This release **does not** implement a generic DASH parser, automatic MP4 downloading, segment fetcher, cross-site stream recorder, Nico session credential acquisition, NicoLive WebSocket heartbeat, or recovery of expired signatures.
- Site classifier is **not** media acquisition. `live.nicovideo.jp/watch/...` is a page address; the authorized media URL must be observed independently in browser network traffic.
- Signed URL query bytes are unchanged on the original fetch/command pipeline; no query rewrite and no cross-origin credential injection added to the new inspector.
- User-selected browser Cookie mode retains v2.42.0 restrictions; not equivalent to reproducing `Referer`, `Origin`, Authorization, partitioned cookies, and private session protocols.
- HLS parser is a bounded diagnostic, not a complete RFC 8216 grammar or a playable-output validator; it never fetches encryption keys or bypasses DRM.
- Candidate permissions are unchanged: https access for observed traffic from existing WebExtension host_permissions, Firefox no added cookies permission. Do not treat the candidate list as authorization to download media.

## Integration

Install the entire `rplay-stable-player-extension-firefox/` or `rplay-stable-player-extension/` directory from the ZIP in a suitable extension test environment, not the standalone v0.1.0 toolkit. Do not copy only `cross_site_core.js` into older versions without adapting the metadata UI and rebuild files. `scripts/build.py` regenerates both extension flavors deterministically.

## External verification required

Test Firefox and Floorp authenticated/non-authenticated pages on actual allowed Nico Video/Nico Live and representative HLS/MP4/DASH sites, including same-site cookies, containers/private browsing, 206 partial content, signed-token rotation, HTTP 401/403/404/429, CORS, LL-HLS and long live stalls. Verify file continuity and AV decode separately for every actual recording. Do not release as universally compatible before those acceptance gates.
