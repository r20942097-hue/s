# cat-catch 解析記録 v2.16.0 — ソフトウェアAES復号器とパケット連続性の知見適用

対象: xifangczy/cat-catch v2.7.3 (`/home/z/my-project/workspace/cat-catch-src`)
本書は v2.16.0 で新たに適用した cat-catch 知見の**全ソース解析記録**である。
v2.12.0 (F-01〜F-05) / v2.15.0 (C-01〜C-03) の解析記録は各版の文書を参照。

---

## 1. lib/m3u8-decrypt.js — ソフトウェアAES-128復号器 (298行)

### 1.1 役割と来歴
cat-catch は hls.js の `AESDecryptor` を分離したものを同梱し、M3U8取得画面
(m3u8.html) で AES-128 暗号化セグメントの復号に使用する。WebCrypto
(`crypto.subtle`) が使えない環境・文脈でも動作させることが目的であり、
RPLAY Stable Player のユーザースクリプト/拡張 (コンテンツスクリプト・
非セキュアコンテキストがあり得る) とまったく同一の動機が存在した。

### 1.2 実装構造の解析
- **テーブル導出 (`initTable`)**: 256エントリの GF(2^8) 倍算テーブル `d` から開始し、
  決定的生成ループで `sBox[x] = sx` / `invSBox[sx] = x` を構築する。
  **注意**: ループ変数 `i` は走査カウンタであり、テーブルのインデックスは
  実行カウンタ `x` (およびそのS-box像 `sx`) である。v2.16.0 の移植時に
  `sBox[i]=sx` と書くと鍵スケジュールが完全に崩壊する(実際に一度バグった)。
- **SubMix / InvSubMix テーブル**: `subMix0[x]` は MixColumns 込み SubByte
  (暗号方向)、`invSubMix0[sx]` は InvMixColumns 込み InvSubByte (復号方向)。
- **鍵スケジュール (`expandKey`)**: 同一鍵の再展開をスキップする同一性チェック付き。
  AES-128 (keySize=4) のみでなく 192/256 にも対応 (RPLAYでは AES-128 専用に限定)。
- **等価逆暗号の合成**: 復号ループは `invSubMix0[s0 >>> 24]` の形で状態バイトを
  直接インデックスする (InvSubByte+InvMixColumns の合成テーブル)。一方
  **invKeySchedule の構築は `invSubMix0[sbox[t >>> 24]]` と前方S-boxを介して行う** —
  `invSubMix0[sbox[b]] == InvMixColumns(b)` という合成により、ラウンド鍵には
  InvMixColumns のみが適用される (RFC 3566 等価逆暗号と一致)。ここを `invSBox`
  で書くと2度目のバグになる (実際に一度バグった)。
- **s-wiring (語順の入れ替え)**: 入力は `s0=iw0, s1=iw3, s2=iw2, s3=iw1`、
  出力は `out0=t0^iv0, out1=t3^iv1, out2=t2^iv2, out3=t1^iv3`。
  この入れ替えは invKeySchedule の語順 (ks[44-r] / ks[44-r-4]) と対をなす。
- **CBC**: `initVector` は初回ブロックでIV、以降は**暗文前ブロック**の語列で更新。
- **removePadding**: 末尾バイトをパディング長として読み切りで除去 (検証なし)。

### 1.3 RPLAY への適用 (N-01)
- `src/hls_transport.js` へ `decryptCbc(key16, iv16, bytes, {padding})` /
  `removePkcs7Padding(bytes)` として移植。相違点:
  1. **PKCS7厳密検証**: cat-catchの読み切りに対し、RPLAYはRFC 5652 §6.3 の厳密検証
     (末尾NバイトがすべてN) を行い、不正は `HLS_DECRYPT_PADDING` で fail-closed。
     WebCryptoは成功時に自動でパディング検証・除去するため、ソフトウェア経路も
     同一セマンティクスに揃えた。
  2. **AES-128 専用**: 鍵16バイト以外は `HLS_DECRYPT_KEY` で拒否。
  3. ブロックサイズ不整 (16の倍数でない・空) は `HLS_DECRYPT_BLOCK_SIZE`。
- **VodDl.decryptSeg のフォールバック**: 従来は `crypto.subtle` が無い/拒否した
  場点で即 `null` (セグメント失敗) だった。v2.16.0 では `webcrypto:unavailable` /
  `webcrypto:OperationError` 等の理由記録後にソフトウェア経路へフォールバックし、
  成功・失敗カウントを `aesFallbackEvidence` として情報JSONへ出力する。
- **検証**: NIST SP 800-38A F.2.5 KAT (4ブロック raw)、WebCryptoクロス検証
  (16/32/188/376/1000/4096バイト、PKCS7込みで原文一致)、厳密パディング拒否、
  引数検証。JS↔Python↔openssl の3実装が同一暗文に対してバイト一致することを
  試験で常時確認 (AES-CBCは決定的であるため一致が仕様上要求される)。

## 2. js/m3u8.js — parseTs の cc (continuity counter) 追跡 (N-03)

### 2.1 cat-catch における cc の使われ方
- `data.fragments[i].cc` (hls.js がプレイリスト/セグメントから抽出) を用いて
  断片を連続性グループ化し、`#EXT-X-ENDLIST` 後の UI で「cc区間選択」を提供する
  (m3u8.js:752-757, 1365)。`data.endCC` で最終ccも表示。
- つまり cat-catch/hls.js は **cc = TSパケット連続性の下流品質指標** として
  断片の欠落・分断を利用者に可視化している。

### 2.2 パケットレベル規格 (ISO/IEC 13818-1 §2.4.3.2)
- 連続性カウンタ (4bit) は **同一PIDでペイロードを持つパケット** のみ +1 (mod 16)。
- adaptation_field_control: `01`=ペイロードのみ / `10`=AFのみ (cc据え置き) /
  `11`=AF+ペイロード / `00`=予約。
- 同一ccの再送 (duplicate) は1回まで許容。ジャンプは discontinuity_indicator や
  ストリーム切替で正当化され得る。
- TEI (transport_error_indicator, バイト1のMSB) は上流で既に誤り検出された印。

### 2.3 RPLAY への適用 (N-03)
- `hls_transport.js` `auditCc(bytes)` / `mergeCcEvidence` / `ccEvidence` と
  `hls_transport.py` `hls_audit_cc` / `hls_merge_cc` / `hls_cc_evidence` を
  **完全鏡像**で実装 (同一入力→同一JSON、試験で常時クロス検証)。
- 分類: `continuityOk`(Δ=+1) / `duplicates`(Δ=0) / `forwardJumps`(1<Δ<8、
  lostPacketEstimate=Δ-1) / `backwardJumps`(Δ>=8) / `noPayloadPackets`(afc=2) /
  `afcReserved`(afc=0) / `teiPackets`。perPid は packets 降順・pid 昇順で
  上位16PIDに截頭 (`perPidTruncated`)。
- **非破壊**: 監査のみでセグメント廃棄は一切行わない (cat-catchの「可視化するだけ」
  方針と同一)。結合TSは既存の 0x47/188 検証と PACK検証のまま。
- 組み込み位置: JS は `fetchItem` のTS検証後 (Recorderの映像/音声の両方)、
  Python CLI は `_fetch_hls` の検証後 (平文TSのみ)。証拠は
  `continuityCounterEvidence` として両者の情報JSONへ出力。

## 3. 鍵取得 (keyContent Map) の確認 — 既存適用済み
- cat-catch は `keyContent` Map で鍵URI→鍵内容をキャッシュする (m3u8.js:78, 704-721)。
- RPLAY ユーザースクリプトの VodDl は `this.keys[uri]` で同一の鍵キャッシュを
  既に実装済み (v1.x)。v2.16.0 CLI (N-02) も `_dec_keys` Map で同一方式を採用。

## 4. 適用対照表 (v2.16.0時点の累積)

| cat-catch 側の機構 | RPLAY 適用 | 版 |
|---|---|---|
| m3u8.downloader.js thread+sequentialPush | F-01 先読み並列取得 (順序厳密) | 2.12.0 |
| autoRetry 線形バックオフ | F-02 | 2.12.0 |
| getM3u8Cache プレイリストキャッシュ | F-03 | 2.12.0 |
| 数据前処理 (PNG/JPG偽装) | F-04 → C-01 拡張 (6種ヘッダ) | 2.12.0/2.15.0 |
| ffmpeg genpts 正規化 | F-05 | 2.12.0 |
| 添加get参数 (クエリ継承) | C-02 | 2.15.0 |
| m3u8dl:// + N_m3u8DL-RE | C-03 | 2.15.0 |
| **m3u8-decrypt.js (AESDecryptor)** | **N-01 ソフトウェアAES-128フォールバック** | **2.16.0** |
| **parseTs cc グループ化** | **N-03 パケット級cc監査 (証拠化)** | **2.16.0** |
| keyContent Map (鍵キャッシュ) | 既存 (this.keys) + N-02 CLI (_dec_keys) | 2.16.0 |

## 5. 移植時に踏んだ落とし穴 (再発防止メモ)
1. `sBox[x]=sx` のインデックスは実行カウンタ `x` (走査変数 `i` ではない)。
2. invKeySchedule は `invSubMix0[sbox[b]]` の**前方S-box**を介する (invSBoxではない)。
3. 入出力の語順入れ替え (s-wiring) は鍵スケジュール側の語順と対である。
4. CBC の初回ブロックはIV、2ブロック目以降は暗文前ブロックとXOR。
5. WebCrypto との一致は「決定的実装である限り」保証される — 一致しない実装は
   即バグ (NIST KATとWebCryptoクロス検証を必ず両方行う)。
