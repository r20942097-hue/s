# QA v2.39.0 — 2026-10-27 JST

全回帰721件PASS（Node556/Python165）。validate.pyの構文・manifest参照・共通core・派生コピー・再build byte一致を確認。配布時にpackage_release.pyでZIPのCRCと全ファイルhashを照合し、PASSを確認済み。

基盤添付v2.38は708件の記録。今回、このチャットv2.37で追加していた8件を復元し、設定読込timeout4件と予約集約1件を追加した。既存ID上限試験は、重複150件から異なるID150件へ入力を変え、100配信者上限を維持することを確認。版ピンは2.39へ更新。

- 自動開始: 禁止解除、成功後の再開始抑制、他設定変更、30秒間隔、遅延拒否競合、Chrome/Firefox routerをVM＋模擬hostで確認。
- 設定読込: 5秒無応答の拒否、late callback無視、成功後late timeout無視、例外/不正値でtimerを1回解放。
- 予約: mixed-case重複IDを1巡回へ正規化、異なるID100件上限、後の配信者の近い予定を含む500件保持、Infinity/Date範囲外の時刻除外。
- 名前metadata・外部予約閲覧・共通JSON取得の既存試験を含む全回帰を実施。

実ブラウザ/実RPLAYは今回未実施。過去のFirefox/Floorp証拠を本版の結果として数えない。Windows・2GiB・長時間・native preview時間進行も未合格。CANDIDATE_NO_GO維持。

入力ZIPはCRC正常。今回の出力は添付v2.38と本チャットv2.37の統合候補であり、元ZIPは変更していない。統合範囲はCONFIRMATION_AND_INTEGRATION_v2.39.0.md、検証ログはevidence/v239-current。
