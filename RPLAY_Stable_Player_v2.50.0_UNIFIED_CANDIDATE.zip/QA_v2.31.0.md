# v2.31.0 QA

追加3件: abort済みで要求0、JSON本文中abortで遅延採用/再試行なし、503再試行待機を即時解除。予約VM試験5件も継続。最終実測はevidence/v231-current/VALIDATION.json。
実RPLAY API/Windows/2GiB/長時間は未受入。Gecko試験はLinux/headless一時profile、試験時のみsandbox調整、製品変更なし。native preview時刻進行は未合格。

全回帰637件PASS（Node472/Python165）。Firefox29 PASS/1 BLOCKED。追加5件を含む。登録cache反映2件を追加検証。ブラウザruntimeは単体試験対象の展開候補と同じコード。最終包装はCRC/全hash台帳を確認。

全回帰637件PASS（Node472/Python165）。Firefox29 PASS/1 BLOCKED。追加5件を含む。登録cache反映2件を追加検証。ブラウザruntimeは単体試験対象の展開候補と同じコード。最終包装はCRC/全hash台帳を確認。
