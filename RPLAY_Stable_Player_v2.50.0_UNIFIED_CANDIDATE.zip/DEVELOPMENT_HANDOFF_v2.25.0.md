# v2.25.0 引き継ぎ

基準v2.24、添付s2.21/d2.22はINPUTSとINTEGRATION参照。src/player.user.jsの両HLS.parse第4引数、UI getter/persist、連続ボタンを更新。src/ext_glue.jsの設定転送、src/offscreen_pre.jsのboolean受入、src/offscreen_post.jsのUI shimを更新。
新規8試験 tests/test_v2250_integration.cjs。HLS local HTTPは実ネットワークだがTSは構造fixture。実FFmpeg素材/Firefoxは従来スイートで別検証。
次: BG一覧再起動復旧、実サービス配信一覧fixture、直接MP4録画の非同期mux/復旧設計、別音声mux、2GiB/長時間。直接MP4録画は今回未実装。TSの保存上限を撤廃しない。
python scripts/build.py / python scripts/validate.py --output-dir /outside/project/evidence / python scripts/package_release.py /outside/project/release.zip
