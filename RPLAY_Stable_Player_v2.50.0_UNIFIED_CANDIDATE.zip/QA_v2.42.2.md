# RPLAY v2.42.2 — QA evidence (2026-10-27)

## Result

- **Node**: 637/637 PASS (`node --test --test-concurrency=4 tests/test_*.cjs`, wall ~32.4 seconds), zero fail/skip. Includes 26 new DASH/HLS-delta/security tests, previous cross-site and broad original recorder regression suite.
- **Python**: 165/165 PASS (`python -m unittest discover -s tests -p 'test_*.py'`, wall ~95.8 seconds); local HTTP tests occasionally logged expected broken-pipe when a client aborted, but the suite returned OK.
- **Chromium DOM-only**: 3/3 smoke scenarios PASS (`python tests/browser/test_v2422_dash_ui.py`): DASH summary sanitization, general inspector summary, explicitly triggered manifest load with original signed URL and Cookie opt-in. Browser load used Playwright `set_content` and test transport stub; **it did not install the WebExtension**.
- **Previous source invariants**: critical recorder/userscript/CLI/MP4 source files exactly byte-identical to the supplied v2.42.1 candidate. Original v2.42.0 recorder engine not revised.
- **Legacy regression guards**: nine inherited checks containing `manifest.version` / `version_name` pins were updated for v2.42.2 without weakening the non-version portions of their tests. One additional inherited v2.15.0 label assertion was found and updated during the final full run; there was no functional failure.

## Changes exercised

- MPD static/dynamic XML counts, SegmentTemplate/SegmentList/SegmentBase/SegmentTimeline, negative/unbounded S@r, ContentProtection, external XLink warning.
- Strict 2 MiB input bound, XML nesting, attribute quoting, duplicate attrs, malformed XML, excessive depth/repetition, reject DTD/entity declarations, output redaction of query tokens/BaseURL.
- Manifest-only transport with signed URL preservation, opt-in Cookie/redirect fail-closed, HTTP 206 partial response fails safely.
- HLS delta `EXT-X-SKIP` visible segment numbers and overlap/gap diagnostics. Original recorder's LL-HLS SKIP policy unchanged.

## Not tested / acceptance gates

- Actual Niconico Video, Nico Live authenticated and nonauthenticated recordings, YouTube/Twitch/Floorp/Firefox extension install, long-lived live feeds, signed token expiration/refresh, real DASH playback or recording, media segment download/decode and file continuity.
- Site identification is categorization, not acquisition. No DRM decryption or auth bypass. Browser cookies may still not be sent due to SameSite, partition or browser configuration.

**STATUS: CANDIDATE / NO_GO.** The new DASH feature is manifest-only diagnostics; full-site and real-browser claims are not supported.
