# RPLAY開発統合台帳（2026-10-26 / v2.9.1）

## コンポーネント・責務の境界

| 系統 | 作業基準 | 所有責務 | 統合許可範囲 | 状態 |
|---|---|---|---|---|
| Stable Player | 2.9.1 CANDIDATE(統合) | 手動プレイヤー、手動ブラウザー録画、単体Python CLI | HLS状態契約、診断仕様 | NO_GO |
| Public Profile Auto Recorder | 1.22.0 CANDIDATE | 公開プロフィール監視・ブラウザ自動録画、最大12（既定2） | 通信予算・保存監査の独立契約 | NO_GO(今回変更なし) |
| Universal Live Watcher | GitHub `r20942097-hue/faaff` | FFmpeg長時間録画、起動監視、SQLiteと復旧 | API/JSONイベント（コード合体しない） | 変更なし |
| Media Download Tools | 系統独立 | 権限がある終了済みVOD、メディアQA | 検証メタデータとffprobe結果 | 変更なし |

## v2.9.0からの引継ぎ（実施状況の書き換え）

| v2.9.0計画の残課題 | v2.9.1での扱い |
|---|---|
| P0 実機受入の実施(ACCEPTANCE.md A1〜A15) | **未実施のままP0維持**。本環境では実Chrome/Firefox/Windows/実RPLAYに接続できない。代わりに受入観察の記録作業を構造化する受入観察支援ツール(B-03)を提供し、ユーザー実施の摩擦を下げる |
| P2 refresh-token応答鍵の実測確定(responseKey) | 未実施(実RPLAYが必要)。形状証拠のまま。実測後にauthEvidence記録鍵を固定 |
| P1 LL-HLS全件形式の実配信評価 | 未実施(実配信が必要)。P1のまま次版へ |
| P2 avCorrelationの実RPLAY較正 | 未実施(実配信が必要)。許容値(2%/0.5s)は合成較正のまま |
| 字幕第二段階（取得・保存・mux） | **着手しない**(統合設計書7.1/9章の規律: A15実測でレンディション実在が確認されるまで取得契約を作らない)。subtitleEvidenceは観測契約として静置 |
| チャンク分割録音・エクスポート経路のメモリ計測 | **着手しない**(統合設計書6.2: 実機計測後に判断)。v2.9.1はBlob URL解放契約のみを契约化 |

## v2.9.1の目標（一文）

**統合設計書（6.2節・6.3節・表5）が条件付き採用とした「Blob URL遅延解放の契約化」と「版ピン運用の改良（直近2版のみ範囲ピン）」を実装し、残る最重要課題である実機受入（P-13）の観察記録を構造化する受入観察支援ツールを追加して、実測主導の次版（v2.10.0字幕分岐）に備える堅牢化リリースとする。**

## v2.9.1で実施する要件

- **B-01 Blob URL遅延解放の契約化（P1・userscript保存経路）** — 実装:
  純関数 `rspBlobHoldMs(bytes)`（床30秒・保守スループット10MiB/s想定のサイズ比例・
  上限600秒）とヘルパー `rspDelayedBlobRelease(url, anchor, bytes)`（保持時間経過後に
  revokeObjectURL+anchor除去。例外は握りつぶさずtryで個別保護）を追加し、
  (1) RECENV.download 既定実装（従来の盲目的10秒）、(2) VOD closePart のメモリ保存
  （従来の盲目的30秒）、(3) VOD 情報JSON保存（同30秒）の3箇所を統一契約へ置換する。
  根拠: MDN「avoid freeing the object URL too early」・Chromium Issue 41380177
  （anchor.click()直後のrevokeでダウンロード破損）・MV3録画業界標準（統合設計書4.4節）。
  長時間録画の末尾保存（600MB級パート）が盲目的タイマーで解放される構造的リスクを、
  サイズ比例の保持時間で排除する。拡張offscreenのOPFS経路
  （`download: opfsSaveAndSalvage`）とexport_host.jsのURLライフサイクル
  （finish時にrevoke・行36）は既に適切であり変更しない（回帰ガード試験で固定）。
  Worker生成のBlob URL（makeWorker・少数KB・1回限り）は変更対象外とし文書化のみ。
- **B-02 版ピン2.9.1統一とピン運用の改良（P1）** — 実装:
  @version・Chrome/Firefox manifest(version/version_name)・CLI表示・tool文字列
  （webhook/ledger/段階/orphan/infoの6箇所）を2.9.1へ統一。
  統合設計書6.3節の政策「直近2版のみ範囲ピン・それより古いピンは現行版への移行」を
  初適用する: test_v290_core.cjsの版ピンは `2\.9\.[01]` 範囲ピンへ（直近2版=
  v2.9.0/v2.9.1）、test_v270/v280_core.cjsの版ピンとtest_v260_core.cjsのtool文字列
  ピンは現行版 `2\.9\.1` 固定へ移行する。新規test_v291_core.cjsが現行版ピンを恒久固定。
  validate.pyの期待値（版・試験数下限）も更新。
- **B-03 受入観察支援ツール（P1・scripts/acceptance_report.py）** — 実装:
  実機受入(A1〜A15)の観察記録を構造化する純ローカルツール。`--dir` の録画成果物
  （`*_info.json`・`RPLAY_*_ledger.json`・`orphan_ledger.json`・partファイル）を走査し、
  T2/T3/T6/T7テンプレートに対応する観察ドラフト（Markdown）を生成する。
  機能: (1) 情報JSONから基礎数値（durationSec/totalBytes/parts/segments/
  missingSuspect/stats）と証拠ブロック10種の在・不在と計数を抽出（A10/A15支援）、
  (2) ledgerの段階順序契約（REQUESTED→FILE_WRITTEN→(BROWSER_DONE)→HASHED→
  DECODED/CONTINUITY・飛び越し検知）を検査（A4支援）、(3) partファイルのsha256再計算
  照合（A4/A2支援）、(4) 秘密ゼロ強制（URL値はorigin+pathへ再秘匿し、出力に
  sig=/token=/key=等の秘密疑い文字列が出たら異常終了するトリップワイヤー）。
  通信は一切行わない（純ローカル・fetch禁止）。虚偽を記録しない: 不在の証拠ブロックは
  「不在」とだけ書き、数値を捏造しない。人間しか観察できない項目（再生確認等）は
  「確認待ち」プレースホルダーを出す。
- **B-04 テストファースト（P1・手順契約）** — 実装:
  test_v291_core.cjs(8試験)・test_v291_features.py(7試験)を先行作成し、
  **失敗を確認してから**実装する。試験内容: B-01（純関数ベクトル・遅延解放挙動・
  RECENV.download統合・VOD経路ソースピン・盲目的revokeパターン残存ゼロ・
  offscreen/export_host回帰ガード・ピン政策移行の固定）、B-02（版ピン）、
  B-03（基礎数値・証拠ブロック・秘密再秘匿・段階契約・sha256照合・異常入力）。

## 実施しないこと（および理由）

- **字幕の取得・保存・mux**: A15実測前の実装は統合設計書9章の規律に反する。
- **チャンク分割録音・エクスポートメモリ計測**: 6.2節が実機計測後判断と裁定。
- **offscreen経路のsubtitleEvidence対称化**: 5.3節がA15実機観察項目と明示。
- **認証系の追加機能**: 6.1節がA12実測まで着手禁止と明示。
- **ドラフト作成系の通信追加**: 本版の変更はすべてローカル契約であり、
  通信予算・取得回数への影響はゼロ（E2E試験で固定済みの値を維持）。

## 期待される検証結果

- 全自動試験: Node 179 + Python 120 = **299 PASS**（v2.9.0の284から+15）。
- 再ビルド5コア同一性・クリーン展開再検証PASS・PACKAGE_HASHES_PASS（ファイル数は
  新規4ファイル追加で142+1）。
- shared_core_sha256 は本版の実測値に更新される（v2.9.0の ee6d1846… からの変更は
  B-01がコア内追加のため必然）。
