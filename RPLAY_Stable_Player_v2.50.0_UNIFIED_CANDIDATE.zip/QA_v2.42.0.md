# QA v2.42.0 — 2026-10-27 JST

全回帰755件PASS（Node590/Python165）。追加Node9件。構文・manifest・core共有・派生copy・再build byte一致を確認。配布ZIPのCRC/全ファイルhash照合PASSを確認済み。

新規試験: 元URLとReferer/Origin/UAの保持、Cookie/Authorization値を保持しない、request/tab/redirect URL違いの不採用、画面clearでpendingも除去、不正ヘッダ/URLの除外、pending TTL/200件上限、root署名のescape/順序/重複保持、credentials明示切替（既定omit）、同origin空queryのみ継承、独自署名/cross-originの保持、不正設定型拒否、production observer配線、inspectorへの元URL/context反映とCookie既定OFF。

独立HTTP: python3 tests/check_request_context_http.py PASS。raw signed queryがサーバーへそのまま到達、匿名policyで403、テストCookie注入を使った明示include policyで成功、子URLの限定query継承を確認。Cookie jarは模擬であり、実ブラウザSameSite/分離/CORSの受入ではない。

継承E2E: python3 tests/check_cdn404_decode.py PASS（先頭404回復、1TS、byte一致、AV/全decode）。node --test tests/check_recording_during_scan.cjs 2件PASS。

実ブラウザ/実RPLAY/Windows/2GiB/長時間/native preview進行は未受入。Cookie includeとReferer/Authorization再現を混同しない。ヘッダ情報は観測であり、全サイト取得を保証しない。CANDIDATE_NO_GO維持。

runtimeは全回帰後に変更していない。証拠はevidence/v242-current。新しい資料とチェックfixtureは署名・Cookieとも試験用データだけを使用。
