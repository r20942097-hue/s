# RPLAY Stable Player v2.23.0 CANDIDATE

添付3系統を照合し、v2.22のFirefox TS/MP4機能を維持して改善しました。

- 配信一覧から開く /live?creatorOid=… を認識。配信者IDだけのSPA切り替えにも追従。
- 署名付きプレイリストURLを変更せずに取得。
- EngineのprobeはHTMLの200をLIVEと誤認せず、有効な代替源を確認。2MiB上限・timeout・abortを適用。
- 「メディア診断」を追加。URL/MIMEと貼り付けたHLS本文をローカルで解析し、秘密を含まない診断JSONを表示。
- 明示操作でPowerShell 7.3以降/POSIX sh向けコマンドを生成。自動実行・URL取得・鍵取得は行いません。

Firefox: rplay-stable-player-extension-firefox/manifest.json を一時アドオンとして読み込みます。既存版は拡張とRPLAYタブを再読み込みしてください。
Chrome: rplay-stable-player-extension を読み込みます。
「メディア診断」はプレイヤー/配信一覧パネルの詳細設定から開きます。ローカルHTTPでは表示URLの末尾を /media_inspect.html に変更します。
拡張なしのTS/MP4変換は open_mp4_converter.cmd または python3 scripts/serve_mp4.py を起動します。

URLに署名やトークンがある場合、生成コマンドにはその値が入ります。診断JSONにはURLのパス/クエリ/フラグメントや元本文を含めません。生成コマンドを共有するときは内容を確認してください。
Media Sniffer原本は参考資料として解析し、新機能を独立実装しました。原本を別の拡張として配布・統合したものではありません。

添付の対応関係と採否は INTEGRATION_REVIEW_v2.23.0.md、全hashは INPUT_RECONCILIATION_v2.23.0.json。
TS/MP4の仕様は MP4_GUIDE_v2.22.0.md、前版は HISTORY_README_v2.22.0.md に保全。
Windows・実RPLAY・2GiB/長時間・プレビュー再生進行は未検証の候補版です。QA_v2.23.0.mdを参照。
