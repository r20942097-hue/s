# v2.32.0 QA

追加6件: 入れ子/重複/整列、未知/過大shape、時刻/タイトル境界、直近未来予約、成功空/失敗で古いリマインドの扱い、中止時の最終pacing競合。スケジュール関数VM試験であり実API受入ではない。
Linux/headlessのFirefox/Floorpは共通Gecko試験、使い捨てprofileで試験のみsandbox level調整。preview進行は未合格。

全回帰643件PASS（Node478/Python165）。Firefox29 PASS/1 BLOCKED。追加6件を含む。予約整列・直近未来選択・空/失敗・中止競合を追加検証。ブラウザruntimeは単体試験対象の展開候補と同じコード。最終包装はCRC/全hash台帳を確認。
