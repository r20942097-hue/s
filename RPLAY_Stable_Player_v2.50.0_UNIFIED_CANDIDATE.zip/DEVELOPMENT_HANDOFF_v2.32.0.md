# v2.32.0

rspScheduleRowsを追加。fetchSchedulesForでshape失敗を区別。scanSchedulesでエラー分類、直近未来予約選択、空成功時の消去、最後の待機後abortガード。次は設定からのAPI連携/名前URL解決/JSON読取上限。
