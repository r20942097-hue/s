# QA v2.42.1 — 2026-10-27

- Based on user supplied v2.42.0 source ZIP; recorder and CLI core unchanged.
- 21 new Node tests for site classification, synthetic Nico/YouTube/Twitch HLS, signed URL redaction, master/audio variants, BYTERANGE continuity/overflow, HLS discontinuity/GAP, encryption/DRM diagnostics, LL-HLS PART/SKIP, snapshot gap accounting, HTTP classification, DASH/MP4 200/206 discovery, permission invariance.
- 19 prior affected tests rerun: PASS. Combined affected tests: **40/40 PASS**.
- Chromium headless DOM/UI smoke through set_content+script injection: **3/3 PASS**. This proves interaction in Chromium DOM only; extension execution and real site media **not** covered. File URL and loopback navigation blocked by browser administrator settings.
- Whole original Node suite attempted but reached environment wall-clock timeout at 297 logged passed tests, no complete summary. Do not report original 755 all passing on this revision.
- Firefox / Floorp actual add-on loading, native authenticated Nico / Twitch / YouTube site tests, Windows, long-run recording, live HLS byte output all NOT TESTED.
- Status CANDIDATE_NO_GO. Report completeness is separate from test pass rate.
