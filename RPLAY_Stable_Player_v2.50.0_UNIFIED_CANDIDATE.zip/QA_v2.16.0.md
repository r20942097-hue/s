# QA v2.16.0 — cat-catch 第3波 (N-01〜N-04)

## 1. 試験サマリ
- **自動試験総数 424 PASS / 0 FAIL**
  - Node.js: 262 PASS (249 既存 + 13 新規 `tests/test_v2160_core.cjs`)
  - Python: 162 PASS (149 既存 + 13 新規 `tests/test_v2160_features.py`)
- `scripts/validate.py` PASS (PACKAGE_HASHES_PASS 331・共有コア5コピー同一・再ビルド同一)

## 2. N-01 ソフトウェアAES-128-CBC復号器
| 試験 | 内容 | 結果 |
|---|---|---|
| NIST KAT | SP 800-38A F.2.5 CBC-AES128.Decrypt 4ブロック (padding=false) | PASS |
| WebCryptoクロス | 16/32/188/376/1000/4096バイトをWebCrypto暗号化→ソフトウェア復号→原文一致 | PASS |
| PKCS7厳密 | 有効1/7/16除去・0/17/非一様拒否 (HLS_DECRYPT_PADDING) | PASS |
| 引数検証 | 鍵/IV長・ブロックサイズ・空入力・切断暗文 fail-closed | PASS |
| VMフォールバック | crypto無し環境でVodDl.decryptSegがソフト経路成功・aesFallbackEvidence記録 / crypto有りではWebCrypto経路 (両経路ともバイト一致) | PASS |
| Python KAT | hls_aes128_cbc_decrypt_py NIST KAT raw | PASS |
| 3バックエンド一致 | openssl / python / JS が同一暗文から同一平文 | PASS |
| openssl不在fallback | _OPENSSL_BIN=Noneでauto→python経路 | PASS |

## 3. N-02 CLI AES-128取得
| 試験 | 内容 | 結果 |
|---|---|---|
| parse allow_aes128 | keyUri/keyIvHex付与・NONEで解除・既定はHLS_ENCRYPTED_UNSUPPORTED維持 | PASS |
| 明示分類 | SAMPLE-AES→HLS_SAMPLE_AES_UNSUPPORTED / 暗号化MAP→HLS_ENCRYPTED_MAP_UNSUPPORTED / KEY無URI→HLS_BAD_KEY / 不正IV→HLS_BAD_KEY_IV | PASS |
| E2E --dec-key | 暗号化プレイリスト+鍵エンドポイント→**バイト一致TS**・decryptionEvidence (keySource=arg, segmentsDecrypted=2, bytesDecrypted)・continuityCounterEvidence | PASS |
| E2E --dec-key-env + --dec-backend python | 鍵をenv経由・純Python強制→バイト一致・segmentsByBackend.python=1 | PASS |
| E2E --dec-key auto | 鍵自動取得 (rplay-private-content-requestor=user-oid・age=1..4999検証)→バイト一致 | PASS |
| 403分類 | 鍵403→HLS_DEC_KEY_DENIED・TS未書込 | PASS |
| ヒント表示 | 鍵なしで暗号化プレイリスト→HLS_ENCRYPTED_UNSUPPORTED+--dec-keyヒント | PASS |
| ゼロシークレット | 出力ディレクトリ全ファイル走査→鍵hex/鍵生バイト不在 | PASS |

## 4. N-03 TS連続性カウンタ監査
| 試験 | 内容 | 結果 |
|---|---|---|
| 分類単体 | ok/dup/fwd(lost推定)/back/noPayload/afcReserved/TEI/複数PID/ラップ=15→0はok | PASS |
| **JS↔Py完全一致** | 同一バイナリ→auditCc==hls_audit_cc・merge2回→ccEvidence==hls_cc_evidence (perPid順含む) | PASS |
| perPid截頭 | 20PID→16件+perPidTruncated | PASS |
| fetchItemフック | Recorder経路でowner._hlsCcAudit累積 | PASS |
| E2E統合 | CLI情報JSONのcontinuityCounterEvidence (segmentsAudited=2・continuityOk=2) | PASS |

## 5. 配布修正・版ピン
- rplay_join.py: root存在・src/join_parts.pyバイト一致・SHA256SUMS網羅 (JS/Py両試験)
- 版ピン 2.16.0: @version・両manifest (version/version_name)・CLI3箇所・acceptance・build・package_release・validate
- 旧試験のピン正規表現を16対応 (v2.9.1の「last-2 range」方針試験も更新・挙動検査は未変更)

## 6. 性能実測 (参考・環境依存)
- 純Python復号: ~0.97 MB/s (1024KB×40ブロック測定・本QA環境)
- openssl復号 (サブプロセス込): ~11.6 MB/s (同一入力・spawnオーバーヘッド込み)
- 大容量VODでは openssl auto (既定) を推奨。ユーザースクリプトはWebCrypto。

## 7. 既知の限界
- SAMPLE-AES/SAMPLE-AES-CTR は対応外 (明示分類のみ)。
- 暗号化 EXT-X-MAP (fMP4 init暗号化) は対応外 (HLS_ENCRYPTED_MAP_UNSUPPORTED)。
- JSトランスポートのparseは引き続き鍵取得なし・fail-closed (ブラウザ側の復号は
  VodDl/WebCrypto+ソフトウェアフォールバックが担当)。
- 実RPLAY配信・実ブラウザー拡張・Windows・長時間運用は未検証 (ACCEPTANCE追補参照)。
