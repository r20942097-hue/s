# Floorp検証

公式Floorp v12.20.2 Linux x86_64、配布SHA-256一致。実行体表記Ablaze Floorp 158.0.1。共通Gecko runnerで29 PASS/1 BLOCKED。外部管理画面・設定/登録保存、Worker/OPFS、約77MB TS→MP4・独立SHA・FFmpeg全decode。
チェック名のFirefox表記は共通runner由来、実行体はFloorp。詳細はevidence/floorp-v230/FLOORP_ACCEPTANCE.json。未合格はnative preview時刻進行。試験のみ使い捨てprofileのsandbox levelを調整、製品変更なし。Windows Floorp/実RPLAY/2GiB/長時間は未確認。
