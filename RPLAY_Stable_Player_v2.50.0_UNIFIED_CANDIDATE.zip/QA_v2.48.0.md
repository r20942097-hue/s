# QA & Verification Report — RPLAY Stable Player v2.48.0 (`CANDIDATE_NO_GO`)

## 1. Test & Validation Summary
- **Version**: `2.48.0` (`CANDIDATE_NO_GO`)
- **Node.js Tests**: `873 / 873 PASS`（v2.47.0 継承 811件 + 統合モジュール単体 54件 + 結線回帰 8件）
- **Python Tests**: `177 / 177 PASS`
- **Total Automated Tests**: `1050 / 1050 PASS`
- **Shared Core SHA-256**: `2f6eea8f54f107e3956309ed05675310d664f1b0ff04d93fa8d59a1994ceddca`（5 copies identical、統合により v2.47.0 から変化 — join schema tool string `RPLAY Stable Player v2.48.0` がコア領域に含まれるため）。
- **Standalone E2E Scripts**（継承・再実行を推奨）:
  - `tests/check_request_context_http.py`: `PASS` (`exact_query_and_order: PASS`)
  - `tests/check_cdn404_decode.py`: `PASS` (`byte_identity: PASS`, `full_decode: PASS`, `audio_and_video: PASS`)
  - `tests/check_recording_during_scan.cjs`: `2 / 2 PASS` (Chrome + Firefox hosts)

## 2. Integrated Capabilities from the Parallel v2.44.0 Line (`v2.48.0`)
1. **BG-stop MP4 auto handoff (`src/mp4_handoff.js`, 15 unit tests)**:
   - Queued TS parts remaining in the OPFS staging area (`rsp_rec`) after a recording stop or abnormal end are converted to MP4 and offered through the export journal. Non-destructive (source TS untouched), default OFF (`mp4AutoHandoff`), single-flight (no new recording starts while converting), zero-secret bounded evidence (`mp4-handoff.status` / `rec.event` kind `mp4-handoff`).
   - Wiring verified by the 8 integration wiring tests: offscreen host creation, `bg-stop` enqueue, `mp4-handoff.sweep` startup path from `background.js recoverExports`, offscreen close guard (`st.mp4Handoff.busy || queued`), `export_host.inFlightNames()` exclusion, conversion-library preload order in Chrome offscreen.html and Firefox background.scripts.
2. **OPFS disk-backed segment store (`src/segment_store.js`, 17 unit tests)**:
   - Pair-write of `.bin` + `.json` with digest verification (fail-closed on tamper/size mismatch), byte/count budget LRU eviction with pinning, orphan sweep, per-namespace stats. Standalone save primitive: no network, no acquisition path coupling (asserted by test).
3. **Native preview failure-factor diagnostics (`src/preview_diag.js`, 22 unit tests)**:
   - `classifyPreview` (NO_DECODER / AUTOPLAY_BLOCKED / DECODE_ERROR / FROZEN_CLOCK / PLAYBACK_OK / UNKNOWN), `videoState` probing, `watchClock` clock-advance watchdog; wired into `src/mp4_convert.js` page events with legacy fixed-message fallback when the module is absent. Display-only — conversion, save, verification and download paths are unaffected.
4. **Settings contract coexistence (`mp4Handover` × `mp4AutoHandoff`)**:
   - `dashboard_settings.js` flag list accepts both booleans (defaults OFF); `dashboard.html` exposes both toggles with independent explanations; `offscreen_pre.js` validates and applies the new flag; `background.js` dashboardDefaults validation and `rec.start` propagation include `mp4AutoHandoff`.

## 3. Remaining Unverified Boundaries (`CANDIDATE_NO_GO`)
- Real live-service endurance on RPLAY / Niconico / YouTube / Twitch, real Chrome/Firefox extension installation, Windows native filesystem behavior, and the `mp4AutoHandoff` ON path on a real browser (real OPFS + real mux.js conversion after a real BG recording) remain outside container simulation and require human acceptance observation per `ACCEPTANCE.md`.
