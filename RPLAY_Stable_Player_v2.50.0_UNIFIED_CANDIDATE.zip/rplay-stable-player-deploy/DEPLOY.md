# RPLAY Stable Player CLI — 無人運用ガイド (v2.7.0)

rplay_dl.py v2.7.0 の運用堅牢化機能(原子的書込 / stop-file / heartbeat /
ディスクガード二重確認 / segindex / webhook / 保存確定イベント台帳 /
ffprobe品質監査)を組み合わせた無人録画の導入手順。

## 1. コンテナ(Docker)

```bash
cd rplay-stable-player-deploy
# rplay_dl.py をこのフォルダへコピーしてから:
docker compose up -d --build
```

- 録画ファイル: `./recordings/main/` (ホスト側)
- **優雅な停止**(パート確定・info.json書込まで完走):
  `docker compose exec rplay-rec touch /rec/main/.rplay_stop`
- 状態: `docker compose exec rplay-rec cat /rec/main/heartbeat.json`
- ヘルス: `docker inspect --format '{{.State.Health.Status}}' rplay-rec`
  (heartbeat.jsonが120秒以上更新されなければ unhealthy)
- `--out /rec/main` と `RSP_OUT=/rec/main` は一致させてください(HEALTHCHECK参照先)

## 2. systemd(ホスト直置き)

```bash
sudo mkdir -p /opt/rplay && sudo cp rplay_dl.py /opt/rplay/
# rplay-rec.service の TARGET_URL を編集してから:
sudo cp rplay-rec.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now rplay-rec
journalctl -u rplay-rec -f          # ログ追跡
sudo systemctl stop rplay-rec       # SIGTERMで優雅停止
```

- 優雅な停止は `touch /var/lib/rplay-rec/main/.rplay_stop` でも可
- `Restart=always` でプロセス異常終了時に自動再開。再開時は
  **segindex** が前回書込済みURLを覚えているため、重複録画しない

## 3. 機能早見表

| 機能 | 内容 | 使い方 |
|------|------|--------|
| 原子的書込 | `*.part`へ書込→fsync→最終名へrename | 自動(常時有効) |
| クラッシュ回復 | 残った`*.part`を起動時に最終名へ回復 | 自動(起動時) |
| stop-file | 優雅な外部停止 | `touch <out>/.rplay_stop` |
| heartbeat | 15秒間隔の生存通知(状態/seg/bytes/pid) | `<out>/heartbeat.json` |
| --healthcheck DIR | heartbeat鮮度判定(0=健康/1=異常) | 監視/cron/HEALTHCHECK |
| --min-free-mb N | 空き容量下限で安全停止(既定512) | `--min-free-mb 1024` |
| --segindex | 書込済みURL永続化(再起動で重複防止) | `--segindex` |
| --webhook URL | start/part/endをJSON POST | `--webhook http://...` |
| fMP4対応 | EXT-X-MAP検出→initをパート先頭に書込 | 自動(.m4s保存) |
| 標準入力 | URL/IDをパイプ | `echo URL \| rplay_dl.py -` |
| --min-free-inodes N | 空きinode下限で安全停止(既定0=無効・POSIX) | `--min-free-inodes 10000` |
| 保存確定台帳 | REQUESTED→FILE_WRITTEN→HASHED→DECODED/CONTINUITY | `<out>/RPLAY_<ID>_ledger.json` |
| --qaudit | 停止時にffprobeでPTS/DTS・全編デコードを監査(既定auto) | `--qaudit auto` |
| --extinf-mode rfc | RFC 8216厳格モード(EXTINF未宣言を拒否) | `--extinf-mode rfc` |
| 世代復旧 | 旧playlist再配信を重複排除・正当なresetを判別 | 自動(情報JSON generationRecovery) |
| URL秘匿 | 情報JSON・ログ・webhookから署名/key2を除去 | 自動 |
| 孤立part台帳 | sha256付きで報告のみ(昇格・削除なし) | `<out>/orphan_ledger.json` |

## 4. webhookイベント形式

`--webhook URL` を指定すると以下のJSONをPOSTします(3回再試行・非同期)。

```json
{"event": "start", "creatorOid": "...", "outDir": "...", "pid": 123, "tool": "rplay_dl.py v2.4.0"}
{"event": "part",  "creatorOid": "...", "file": "RPLAY_..._p1.ts", "bytes": 123456789, "segments": 240, "part": 1}
{"event": "end",   "creatorOid": "...", "reason": "stop-file(.rplay_stop)検出 — ...", "bytes": 123456789, "segments": 240, "files": 3, "missingSuspect": 0}
```

Discord/Slackへの転送例(Webhook Siteやwebhook_bridge等の中継で利用可)。

## 5. クラッシュ安全性の設計

- 録画中のファイルは常に `*.part`(一時名)。クラッシュ/停電/kill -9 が
  起きても「壊れた完成品」は残らない
- 次回起動時に `*.part` は自動で最終名へ回復(TS連結にはそのまま使える)
- fsyncでディスクへ確定してからrenameするため、rename済みファイルは
  停電後も内容が保証される
- segindexにより再起動後のバックログ再取得で同じセグメントを二重に
  保存しない(完全URL単位の照合)

## 6. 注意

- 個人利用を想定(認証回避機能なし・--tokenは自分のJWTのみ)
- サーバー配慮設計(適応ポーリング±10%ジッタ・429=Retry-After優先・
  403=60秒待機)はコンテナ運用でも維持される

## v2.7.0: 認証の無人運用(--refresh-token)

長時間の無人録画で静的JWTの期限切れが課題だったv2.6.0以前と異なり、
Refresh-Tokenを指定すると短命JWTを自動更新できる(leeway 300秒前に再取得・
失敗3回再試行)。秘密はコマンド履歴に残さない供給方法を推奨:

```
# 環境変数から(systemdのEnvironmentFileと相性が良い)
RPLAY_REFRESH_TOKEN=<自分のRefresh-Token>
ExecStart=/usr/bin/python3 rplay_dl.py <URL> --refresh-token env:RPLAY_REFRESH_TOKEN --info-json ...

# ファイルから(権限0600を推奨)
--refresh-token file:/etc/rplay/refresh_token.txt
```

- `--token`（明示的なJWT）を併用した場合、--tokenが一次資格となり
  401時だけ--refresh-tokenへ自動切替する。
- webhookに auth_failed(level=error) が追加され、資格の失効を即座に通知できる。
- authEvidence(供給源種別・更新回数・401分類)が情報JSON/ledgerへ記録される
  (秘密の値は出ない)。
