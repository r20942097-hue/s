# RPLAY Stable Player v2.17.0 UNIFIED CANDIDATE

同名v2.16.0の統合版とAUDIO_TIMELINE版を統合し、大容量TS→MP4変換にも先頭AAC保持と共通時刻原点補正を適用しました。既存の録画・チェックポイント復旧・CLI AES-128・TS連続性監査を維持します。

状態は **CANDIDATE / NO_GO**。実RPLAY、Windows、拡張インストール、実OSファイル選択・保存、長時間運用は未検証です。今回の音声・映像一致はFFmpegで生成した合成素材の結果です。

## 使い方

1. ZIPを新しいフォルダーへ展開します。旧版は保持してください。
2. ブラウザ拡張はChrome系 `rplay-stable-player-extension`、Firefox系 `rplay-stable-player-extension-firefox`。未署名の開発候補です。インストール方式は各ブラウザの開発者機能を使用します。
3. 保存済みTSの変換は録画完了後、同梱 `mp4_convert.html` をFile System Access APIに対応したブラウザで開きます。拡張からの変換画面入口も継承しています。
4. TSを選び、表示順を確認し、別のMP4へ保存します。入力は1ファイル2GiBまで、最大4096本。H.264と同じTS内の最大1つのAACが対象です。
5. API非対応のブラウザでは変換できません。Firefox拡張を収録していることは、Firefoxでこの保存APIが使える保証ではありません。

CLIは `python rplay_dl.py --help`、録画結合は `rplay_join.py` と既存CMDを継承しています。権限のあるメディアを対象に利用してください。

## 今回の変更

- 大容量経路にもAUDIO_TIMELINEの修正を統合。AAC先頭フレームを保持し、映像・音声を共通時刻原点へ補正。
- PSI CRC、複数パケットのPAT/PMT、TS連続性を分割読込みでも検査。全入力を検査してから出力を開きます。
- 変換前後の入力SHA-256を照合し、同サイズの入力変化を検出。入力の別名ハンドルによる重複も拒否。
- 既定8MiBの読込み、16MiBを目安とするGOP/PES境界処理、32MiBの保持TS上限。これは全プロセスメモリの上限ではありません。
- 検査中の中止、API非対応時のボタン、画面の容量説明を修正。
- 音声ADTS一致・映像framemd5一致、65MiB入力、33bit時刻折返し、障害時中止を回帰検証。

詳細: [MP4操作説明](MP4_GUIDE_v2.17.0.md)、[検証報告](QA_v2.17.0.md)、[開発継続資料](DEVELOPMENT_HANDOFF_v2.17.0.md)。旧版の説明は [履歴](HISTORY_README_v2.16.0.md) に保持しています。旧QA・evidenceは各記載バージョンの履歴です。

## 検証の再実行

Node.js 24+、Python 3.11+、FFmpeg/ffprobe（libx264）を用意し、展開先で実行します。

```sh
python scripts/validate.py
```

検証は生成メディア・ローカルHTTP・API/DOMモックを使用し、RPLAYへのアクセスは行いません。Pythonの待機・HTTP試験を含むため数分かかる場合があります。
