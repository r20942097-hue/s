# v2.22.0 引き継ぎ

現行: UNIFIED CANDIDATE v2.22.0。ベースv2.21を保持。

src/mp4_convert.js/html: File picker代替、Worker RPC、進捗/中止、出力準備/保存完了区別、復元/削除、動画プレビューとJSONレポート。
src/mp4_convert_worker.js: 既存strict convertStreamedをWorker内で実行。single active task、AbortController、進捗節流。
src/mp4_browser_io.js: readonly File adapters、fresh OPFS、asyncまたはsync access writer、64MiB/128MiBメモリfallback、receipt/hash復元、Web Locks、明示的な未完了ジョブ削除。
既存convertStreamedの安全性判定を緩めていません。入力TS/元ファイルの削除は追加しない。

ビルド: python scripts/build.py
検証前のledger更新: python scripts/package_release.py /outside/project/output.zip
回帰: python scripts/validate.py --output-dir /outside/project/evidence
実Firefox: scripts/test_firefox_mp4.py（QA参照）

576自動試験。Firefox 158.0.1の実拡張:21 PASS/1 BLOCKED。Windows/実RPLAYは未検証。
候補版のCANDIDATE_NO_GOを維持し、全プレビュー再生の合格を捏造しないこと。

次の優先課題: Windows Firefoxでの保存/復元/プレビュー再生/AV同期、2GiBと長時間、実Chromeのhandle structured cloneと直接保存、クロスPES AACの設計。
OPFSのreceiptなしデータは「未完了」として明示削除できるが、部分出力の再開・復旧MP4としては出さない。
一時領域はバックアップの代替ではない。ダウンロード結果を確認した後、ユーザーが明示的に消す。
ブラウザ内完了/サイズ確認と、試験側の実OSファイルSHA-256照合は別の証拠。
