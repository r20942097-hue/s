# RPLAY v2.42.4 QA summary

## Performed

- `python scripts/build.py`: complete; generated userscript, Chromium and Firefox content/offscreen mirrors.
- `node --test tests/test_*.cjs`: **657 / 657 PASS** (2026-10-27).
- New `tests/test_v2424_part_commit.cjs`: **10 / 10 PASS** (included in 657).
- Targeted Python tests: **43 / 43 PASS** across `test_hls_timing` (6), `test_join_parts` (12), `test_cli_timing` (7), `test_hls_503` (3), `test_cli_saves` (15).
- Full Python regression: **NOT COMPLETED**; process exceeded execution timeout after partial progress. Do not claim 165/165 PASS on this release.
- `rplay_dl.py`, `rplay_join.py`, `src/cli.py`, `src/hls_transport.py`, `src/mp4_convert_core.js` and `src/cross_site_core.js` are byte-identical to the supplied v2.42.3 ZIP.
- The full release ZIP is created via `scripts/package.py` with SHA256SUMS manifest and ZIP CRC verification.

## Evidence semantics

Part integrity block attaches to saved-recording JSON **after** `RecPartSink.close()`. It is not a transactionally persisted, segment-by-segment durable journal.

- `fileCommitted=true` only after actual folder-writer close, file size readback and confirmed sink receipt (not fsync guarantee).
- For extension download/Blob fallback paths, a blob hash may be available but **is not evidence of a saved file**.
- `checkpoint` provides bounded proof metadata from existing verified checkpoint chunks, not the actual per-segment mapping.
- `acceptedHls` are per-part counter interval differences. Segments queued across part boundaries may make strict attribution impossible; this is flagged as approximate.
- No full decode nor timestamp A/V sync is performed in this patch; `avDecoded=false`.
- Signed query strings/Cookie/Authorization remain absent from the new evidence block. Request transport is unchanged.

## Acceptance gate

**NO_GO** until manual isolated browser tests and actual permitted HLS recording, output file hash readback, ffprobe decoding/timestamp audit, long-running resilience tests and license audit have passed. No authorization/DRM circumvention added.
