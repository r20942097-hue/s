# v2.20.0 QA

2026-10-26 JST / CANDIDATE_NO_GO。

**534件PASS / 0 FAIL**（Node 372、Python 162）。前版500件から34件追加。5録画コア一致・再ビルドランタイム一致・MP4/復旧等8モジュールの24派生コピー一致・manifest/JS構文PASS。

## コーデック異常の注入

正常な4秒mono AAC/H264素材のmux後ASCチャンネル設定を1から3へ変更しました。前版は189サンプル・圧縮音声hash一致のままconfirmed=true。新版はMP4_AAC_CONFIG_MISMATCHで確定前に拒否します。これは異常注入で、実配信で自然発生した事故の記録ではありません。再現ツールはscripts/reproduce_codec_metadata.cjsで、引数に展開済みv2.19.0を指定します。

新規codec試験32件: mp4a/descriptor/ASC/avcC/SPS/PPS/寸法等の27異常を両APIに注入し、abort・未確定・以前のモック出力保持を確認。Baseline/Main/Highの3素材はSPSから得た寸法と音声設定をffprobeと照合。入力内parameter set変化の先行拒否、SPSパーサーの上限/切断/未対応profileも検証。

## Firefox manifest

ユーザーからversion_name警告の報告があり、Firefox用キーを除去しました。正式version・Chrome用ラベル・Firefox background/Gecko ID保持を静的検証。新モジュールの配布とload順/3派生コピーの検査を含め、新規manifest/配布試験は2件です。改修版の実Firefox再読み込みは未確認です。

## 合成メディア再検証

| 条件 | 入力bytes | AACフレーム | 1tick音声補正回数 | AV開始差の変化 秒 |
|---|---:|---:|---:|---:|
| 120秒 / 44100Hz / 2ch | 6,897,532 | 5,169 | 4 | -0.00002100 |
| 120秒 / 48000Hz / 1ch | 5,948,884 | 5,626 | 0 | 0.00000000 |
| 50秒 / 48000Hz / 2ch | 77,606,776 | 2,345 | 0 | 0.00000000 |

全条件でAAC圧縮サンプルhash・ADTSバイト・映像framemd5一致、FFmpeg -xerrorデコードPASS。1MiB以下の読込みを使う実ディスク用Nodeアダプターでの試験です。50秒は12Mbps CBR 320x180/25fpsのfiller NALを含む合成素材で、任意の実配信の代用ではありません。

## 証拠と限界

evidence/v220-current/VALIDATION.json、node.log、python.log、MEDIA_MATRIX.json、CODEC_METADATA_BEFORE_AFTER.json。旧evidenceは各記載版の履歴です。

完全なMP4/SPS/PPSの意味検証・本番全デコードではありません。File System Access APIはモックで、改修版の実Firefox/OS保存、Windows、実RPLAY、数時間/2GiBは未検証。利用者の警告報告と、こちらの改修後受入結果を混同していません。
