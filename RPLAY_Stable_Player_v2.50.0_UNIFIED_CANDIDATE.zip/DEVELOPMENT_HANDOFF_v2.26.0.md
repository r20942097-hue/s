# v2.26.0

Recorder.probePlaylist(candidate)を通常監視と再探索で共用。probeSourceOkはlive結果だけ採用。添付別系統2.23のMP4全量結合は大容量設計と異なり保留。次はmember/VOD通信上限統一、BG永続一覧、直接MP4 streaming mux設計。
