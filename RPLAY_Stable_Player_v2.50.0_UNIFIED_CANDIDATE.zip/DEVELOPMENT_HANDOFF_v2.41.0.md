# v2.41.0 引継ぎ

media_catalog.js: RAM候補(create)、属性parser再利用のmanifest、既存bounded HLS transportのload。webRequest追加。backgroundは監視・tab lifecycle・trusted extension画面のlist/get/open/clear。署名URLを返すのはinspector.getだけ、画面遷移はID fragment。Firefoxのbackground scriptsとChrome importScriptsへcatalogを登録。
media_inspect: URL/body入力＋明示load/cancel、variant/audio列、2入力コマンド生成。audioUrl選択は映像入力と独立。汎用fetchはcredentials omit、redirect error。
録画: recFetchDescriptorで404の最初2回に1秒待ち・retry。drainの既存FIFO契約維持。成功は_cdn404Recovered、断念は_cdn404Drops、映像infoのsegment404Evidenceへ記録。maybeQualityUpgradeはbytesTotal>0で抑制。fallbackは不変。

次: 実Firefox/Floorp/Chromeで観察・候補選択・permissions受入。認証付き汎用入力とDRMは混同しない。停止後MP4自動引渡し、汎用disk-backed取得は保存/復旧契約を設計してから段階実装。
