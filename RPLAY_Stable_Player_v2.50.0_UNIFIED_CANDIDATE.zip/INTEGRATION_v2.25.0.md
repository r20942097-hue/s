# 統合・改善判断

基準v2.24.0を保持。添付s系2.21/d系2.22と引き継ぎZIPのCRC・hash・内包ZIP hashを INPUTS_v2.25.0.json に整理。別系統の自己申告テスト数は本版へ加算しない。

採用: d系AA-04で指摘されたHLS.parse第4引数漏れを現行版で再現。既存inheritQueryアクセサにUI getter・永続化・BG設定・offscreen shim・音声/video parserを接続し直した。既定OFF。原本を丸ごと移植しない。

UI: 時間分割なしボタンを録画欄へ追加。設定値0と保存上限を区別し、MP4変換への手順を説明。MP4は既存の変換/検証/保存を保持。TS拡張子の変更だけでMP4とはしない。

維持: 自動時間分割0、同一TSのDISCONTINUITY継続、OPFS/FSA連続保存、Worker MP4変換、署名URL保持、復旧台帳。
保留: d系の自動codec swap/live追従率、永続stream table、BG強制split、別音声muxは実配信fixtureと寿命/移行/同期検証が必要。強制分割機能は今回の連続保存要求と優先順位が異なる。
残課題: 実サービス配信一覧/BGリスト、Windows/2GiB、長時間、native preview進行。全量読取が残る旧probe経路の統一。

一次資料: https://www.ffmpeg.org/ffmpeg-formats.html （MP4 fragmentation/concat）; https://developer.mozilla.org/en-US/docs/Web/API/Window/showSaveFilePicker ; https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/downloads/download （Firefox保存API）。既存のFirefox OPFS+downloads経路を維持する判断。
