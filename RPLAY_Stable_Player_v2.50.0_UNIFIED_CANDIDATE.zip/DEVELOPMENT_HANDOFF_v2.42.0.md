# v2.42.0 引継ぎ

catalog.captureRequest/forgetRequestを追加。onBeforeSendHeadersのrequestHeaders/extraHeaders（非対応時fallback）、onError cleanup。pending200件/60秒、requestId+tabIdキー、response URL一致でのみcontext採用。allowlist Referer/Origin/UA＋documentUrl/originUrl/initiatorと認証有無。Cookie/Authorizationの値は保持しない。
inspector.getは元URL/context/capturedAtを返す。listにはcontextも署名も出さない。
load: useCookies defaultfalse→include/omit、redirect error維持。manifest第4引数inheritQueryは同originでqueryなし子へraw parent searchのみ付加。子query再構成をしない。
UI: 元ページorigin、ヘッダ取得状況/認証利用有無、Referer/UA autofill、Cookie/queryの独立チェック、401/403説明。

次: 実ブラウザCookie/Referer/partition条件の受入、サービス別の正規認証契約、汎用disk-backed動画取得。ヘッダ観測と同条件再送を同一視しない。
