# RPLAY Stable Player v2.19.0 UNIFIED CANDIDATE

MP4の音声数照合を、圧縮音声データ・フレーム境界・サンプル表/実データ範囲・トラック時刻の検査まで拡張しました。既存の録画、AES-128、CLI、復旧、入力TS検査、MP4変換を維持しています。

状態: **CANDIDATE / NO_GO**。実RPLAY・Windows・実ブラウザ導入/OSピッカー/保存API・数時間/2GiB運用は未検証です。

## 今回の変更

- 入力と出力のAACを「サンプル長4バイト＋圧縮データ」の順でSHA-256照合。音声数が一致していても、内容の変化・境界のずれ・順序の違いを検出します。
- 同梱mux.js 6.3.0の出力契約に対し、trun/mdatの位置・サイズ・表の長さ、AVCサンプル内NAL長、時刻の重なり、sequence、トラッククロックを検査。
- AACクロックへの換算で生じる1 tickだけの負方向の重なりは補正して記録。2 tick以上や映像の重なりは拒否します。無制限に時刻を詰める機能ではありません。
- 互換64MiB convert APIにも入力全体のハッシュ照合と保存確定直前のキャンセル検査を追加。
- 画面に音声データ照合済みと表示します。録画中MP4直接出力・別音声同期合成は未実装です。

## 使用手順

1. ZIPを新しいフォルダーへ展開し、旧版は保持してください。
2. Chrome系拡張はrplay-stable-player-extension、Firefox系はrplay-stable-player-extension-firefox。未署名の開発候補です。
3. 保存済みTSは、File System Access APIに対応したブラウザでmp4_convert.htmlを開き、入力選択→順序確認→別のMP4保存先を指定します。元TSは削除しません。
4. 1入力2GiBまで・最大4096本、H.264映像と同じTS内のAACが対象。実2GiB入力は未検証で、未対応構造は明示的に拒否します。
5. 完了後に再生・シーク・同期を確認してください。確定後の照合失敗は自動ロールバックしません。

API非対応ブラウザでは変換できません。Firefox拡張の収録は、このMP4保存APIの対応を保証するものではありません。CLIはpython rplay_dl.py --help、結合はrplay_join.pyを継承しています。

## 検証

**500件PASS / 0 FAIL**（Node.js 338、Python 162）。120秒の44.1kHzステレオ/48kHzモノラル、77.6MB・50秒・12Mbpsの符号化TSでADTSバイト一致・映像framemd5一致・FFmpegデコードを確認。合成メディアの結果です。

```sh
python scripts/validate.py
```

Node.js 24+、Python 3.11+、FFmpeg/ffprobe（libx264）が検証用に必要です。利用者のブラウザ内変換は同梱mux.jsを使います。検証は生成メディア、ローカルHTTP、API/DOMモックを使用し、RPLAYへ接続しません。

詳細: [操作・制約](MP4_GUIDE_v2.19.0.md)、[QA](QA_v2.19.0.md)、[継続資料](DEVELOPMENT_HANDOFF_v2.19.0.md)。旧版README/QA/evidenceは各記載版の履歴です。
