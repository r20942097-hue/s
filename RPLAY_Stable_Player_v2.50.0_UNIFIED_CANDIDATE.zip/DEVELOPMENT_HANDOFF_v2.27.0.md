# v2.27.0

VOD.fetchPlaylistTextをHLS.createTransferへ移行。2MiB上限、本文timeout、cancel時abort、UTF-8/EXTM3U検査。追加4試験。
添付d2.23は停止時OPFS結合/自動MP4方式の別系統。既存Workerの保存/台帳/復旧契約との移行検証を要し今回は移植しない。旧統合2.23の全量メモリremuxとは別の実装。
次: BG保存→変換の自動引渡し、永続一覧、実配信fixture。旧版証拠は履歴。今回Firefox未再試験。
