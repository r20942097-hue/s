# QA v2.49.0 — RPLAY Stable Player 候補版の品質観察項目

## 1. 自動テスト結果
- 総テスト数: **1077 / 1077 PASS**
  - Node.js: 898件
  - Python: 179件
- 共有録画コア SHA256: `18d1060d4644b287da223e3249b3fadae6da606a996e2e969e3ba9f9ea2fcedb`（5コピー一致）
- 再構築バイト同一性: PASS（build.py 再実行で生成物のバイト列不変）
- マニフェスト・構文検査: PASS
- 派生コピー検査: PASS（24種モジュールが src/ → 両拡張とルートへ同一バイトで配布）

## 2. v2.49.0 で新規追加された検証
### 2.1 Line B addon-max 統合（並行系統マージ）
- `tests/test_v2480_addon_max_upgrade.cjs` — マスタープレイリスト監査 `inspectMaster` / `hls_inspect_master` のJS/Python鏡像、orphan audio/subtitle group 検出、HDR/high-FPS variant 計数、`needsSeparateAudioMux` 判定
- `tests/test_v2480_cli_addon_max.py` — `--join-files` CLI の同ディレクトリ制約・symlink拒否・上書き拒否・`--mux-audio` 併用・`--subtitle` / `--subtitle-lang` 併用・ffprobe ベースの mov_text 字幕トラック存在確認
### 2.2 segment_acquire Stage 2
- `tests/test_v2490_segment_acquire.cjs`（22件）— happy path / default OFF / RAM 1-segment cap / cancel残留 / restart継続 / zero-secret scan / fail-closed各種 / bounded acquisition / GAP skip / restore再構築 / ledger永続化 / 依存必須ガード
### 2.3 dashboard policy 拡張
- `tests/test_v2380_start_policy.cjs` — `mp4Handover` / `mp4AutoHandoff` を含む外部設定構造の期待値更新
- `tests/test_v2480_integration_wiring.cjs` — v2.49.0 統合2件（policy表示とsegment_acquire配線）

## 3. 紀律維持の確認
- **CANDIDATE_NO_GO**: 実ブラウザ・実サービスでの受入観察が完了するまで本番配布不可
- **remote_published=false**: リモート配布サーバーへ未公開
- **ゼロシークレット**: 全証拠ブロック・台帳・segment meta・acquire status に URL/トークン/Cookie 含有を scan で確認
- **非破壊**: discard() は on-disk セグメントを削除しない・mp4_handoff は元TSを変更しない・mp4AutoHandoff は既定OFF
- **fail-closed**: digest不一致・サイズ不一致・予算超過・依存未注入は全てエラーとして伝播（中途半端なデータを返さない）
- **既定OFF**: segment_acquire は本番配線になし・mp4AutoHandoff は既定OFF・`--join-files` は明示起動のみ

## 4. 実ブラウザ受入（未実施・環境依存）
- A-10: mp4_handoff BG停止後MP4自動引渡し（実OPFS残留 + 実mux.js変換 + 実download journal）
- A-11: mp4AutoHandoff ON時の実変換（実変換失敗時の復旧経路含む）
- A-12: segment_acquire の実ネットワーク取得（実HLS候補選択 → 実セグメント取得 → 実disk-backed保存 → 実再開）
- 旧A-01..A-09: 実ブラウザCookie条件/実RPLAY/実Nico/Windows/2GiB/長時間/native preview進行
