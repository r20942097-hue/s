# v2.18.0 開発継続資料

基準はこのチャットで作成したv2.17.0 UNIFIED CANDIDATE。旧版は変更せず、新しい候補として保存します。入力ZIPのSHA-256はINPUTS_v2.18.0.json、変更はCHANGES_v2.18.0.patch。

src/mp4_convert_core.jsにcreatePesAuditor/createNalAuditor、strict media preflight、MP4 trun音声サンプル数照合を実装。tsPlanの構造検査APIは既定で維持し、変換APIはmedia:trueで厳密検査します。ブラウザ画面・互換convert・convertStreamedに同じ保全方針を適用します。

tests/test_v2180_integrity.cjsの22件はPES/ADTS/NAL基本検査・音声数照合・異常出力を注入した保存確定前拒否。tests/test_v2180_media.cjsの3件は120秒素材2条件と50秒12Mbps実ディスク変換。前版の疑似巨大GOP試験は、新しいNAL検査を通る連続ペイロードに変更し、32MiBの保持上限を引き続き検証しています。

証拠はevidence/v218-current。AAC_TRUNCATION_BEFORE_AFTER.jsonに旧版での音声189→178フレームと新しい拒否、MEDIA_MATRIX.jsonに生成メディア実測値があります。基準素材の生成・切断操作は回帰試験から再現できます。

## 次工程

1. 実機確認を行う段階で、Windows・実OSピッカー・拡張・実RPLAY・大容量/数時間の受入を実施。未実施だけを理由にローカル開発を止めない。
2. PESを跨ぐAACを安全に処理するには、PES/ADTS再構成かflush境界の再設計が必要。現状は明示拒否とし、緩和だけで通さない。
3. H.264 slice/RBSPの完全性、AAC payload/CRC、MP4 sample table/mdatの全整合監査を追加検討。現状のカウンタ照合を全デコード保証と混同しない。
4. Worker移譲、録画中MP4出力、別音声合成は別工程。既存の保存/復旧契約と確定済み出力の非削除を維持。
5. PSI pointer・PMT改訂等の複雑な構造も追加反証する。

CANDIDATE_NO_GOを維持します。120秒/77.6MBの合成メディア試験は、数時間/2GiBや実サービスの代用ではありません。
