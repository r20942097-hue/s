# v2.35.0

creator_registry.snapshot/commit、rsp-creator-registry-save-v1 lock。Dashboardでロード時baselineを保持し、commit時に現在storageと比較。差異はエラー。成功後のみbaseline更新。初期load失敗では保存不可。明示reloadで編集入力を置換。
次: 設定にも同じ競合保護、登録者の名前/元URLmetadata設計、外部予約閲覧、実サービスfixture。
