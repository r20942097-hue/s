# v2.23.0 検証範囲

2026-10-26 JST / CANDIDATE_NO_GO

最終ZIP展開試験は Node 432 + Python 165 = **597 PASS / 0 FAIL**。最終結果/ログを evidence/v223-current に収録。追加機能21件の単独試験も実行済み（added-tests.log）。

## 追加した21件

ルート/probe/署名URLが12件、メディア診断/コマンドが9件。
- /live/<24桁ID> と /live?creatorOid=…、大小文字、重複/矛盾パラメータ、無関係ページの拒否。
- IDだけ変わるSPA遷移と、追跡パラメータだけの変更を区別。
- 200 HTMLをliveとせず、優先masterのvariantが404なら次のbaseを確認。
- 401/403は認証状態として返し、公開URLへの試行を継続しない。全源失敗ではcached liveInfoを破棄し次回APIで新基盤を探索。
- Engineの署名URLの文字列保持、streaming本文2MiB制限、body読取中timeout、destroy時abortとタイマー解放。
- 録画側の署名URLも実際のfetch引数で保持し、全ブラウザplaylist経路から_rsp付加を除去。
- MIMEがaudio/x-mpegurlでもHLS候補と判定。候補判定と本文/構文/再生検証を区別。
- HLSのタグ件数・暗号化方式を診断し、鍵/セグメントURL・元本文・path/query/fragmentをJSONへ出さない。未知のMETHOD文字列もUNKNOWNへ限定。
- 制御文字・非HTTP(S)・URL資格情報・未対応シェル拒否、Windows予約名/出力パス対策。
- POSIXは実shへ偽ffmpegを渡し、$()・バッククォート・一重引用を含むURL/ヘッダー/出力名が文字列のままargvへ渡り、外部コマンドが実行されないことを確認。
- 生成POSIXコマンドを実FFmpeg＋ローカルHTTP TSへ実行。正確なURL/Referer/User-Agent、h264/aac MP4、既存の番兵出力の保持を確認。
- PowerShellは7.3以降向け文字列の単体試験。Windows上のnative argv/実行は未検証。

## Firefox

Firefox 158.0.1/Linux/headless、一時拡張の実行試験を再実施。
最終ZIPから再実行し、27項目中 **26 PASS / 1 BLOCKED**。証拠は evidence/firefox-v223。
追加5項目:
1. メディア診断画面のJSONに秘密URLのpath/query/fragmentを含めず、fetch要求0件。
2. 明示的なPowerShellコマンド生成。コマンドはブラウザ内で実行しない。
3. 生成済みcontent.js全体を実Firefox DOMで実行し、query形式のlive URLにパネルをマウント。
4. クエリIDだけが変わるSPA遷移で配信者を切り替え、パネル数1を維持。
5. 追跡クエリだけなら同じプレイヤーインスタンスを維持。

3〜5はAPI応答/HLS対応判定をスタブ化したルート/UI試験。実RPLAYでの受入ではない。
既存22項目は実TS/Worker/OPFS/DL/ハッシュ/改変拒否/中止/複数パート/約77MB/実FFmpegデコード等。
未合格はプレビュー再生時刻の進行。通常flat MP4の対照でも進まない実行環境で、メタデータ読込は確認済み。詳細条件は QA_v2.22.0.md。
試験用の使い捨てプロファイルのみsandbox levelを調整。製品は設定を変更しない。

## 配布検証

ZIP CRC・全ファイルSHA-256・生成物のバイト一致・5録画コア鏡像を確認する。ZIP展開先で全回帰/Firefox試験を実施し、その後の証拠ログ収録のみの再パッケージでも全コード・テスト・設定の同一性を照合する。
最終ZIP内にはブラウザのスクリーンショットや大容量試験素材を含めない。

## 残る受入

Windows、PowerShell実行、実Chrome、実RPLAY、2GiB境界、時間単位の長時間、プレビューの実再生/音声同期。
別系統添付の557件は資料上の申告で、今回の597件とは足し合わせない。
