# v2.19.0 継続資料

基準は同じチャットのv2.18.0 UNIFIED。INPUTS_v2.19.0.jsonに元ZIPの正確なSHA-256を記録し、旧版を維持します。

src/mp4_convert_core.jsの変更: ADTS→raw AACの長さ付きストリームhash、auditFragment/createOutputAudit/checkTrackClocks、サンプル表/mdat/AVC基本構造監査、1 audio tickだけの重なり補正、sourceごとの入力/出力AAC照合。legacy convertへ入力全体hashとprecommit中止を追加。src/mp4_convert.jsは音声データ照合済みの表示を追加。

tests/test_v2190_mp4.cjsは23件。出力payload変更・同じ総サイズの境界ずらし・負/不正offset・巨大count・範囲逸脱・余剰mdat・duration・flags・NAL・sdtp・clock・sequence・decode重なり等を注入。test_v2180_integrity.cjsにCRC付きADTSのhash境界をNode cryptoと独立照合する1件を追加。計24件増加です。

AAC_PAYLOAD_BEFORE_AFTER.jsonは正常な合成入力のmux出力へ1バイト変化を注入した結果です。v2.18.0は189→189音声フレームのままconfirmed=true、新版はMP4_AAC_PAYLOAD_HASH_MISMATCHで確定拒否。実サービスで同じ自然故障が発生したとの記録ではありません。

## 次工程

1. Worker移譲と実ブラウザ/OS保存、長時間/2GiBの実機受入。実機待ちだけを理由にローカル開発を止めない。
2. esds/avcC等の全意味整合、入力SPS/PPSとの対応、映像の内容保持・完全性を追加検討。今回の監査を完全なMP4準拠証明や全デコード保証と扱わない。
3. PESを跨ぐAACへの対応は再構成/flush境界を設計してから実装。現状の拒否だけを緩和しない。
4. PSI pointer/改訂/複数section等の反証、数時間の相対同期、音声1tick補正の上限と統計を継続監査。
5. 録画中MP4直接出力と別音声合成は別工程。既存の保存・復旧契約を維持する。

ソースsrc/→scripts/build.py→scripts/validate.py→scripts/package_release.py。CHANGES_v2.19.0.patchにv2.18.0との差分。ライセンス/外部アセットは変更していません。実機・サービス・長時間は未検証につきCANDIDATE_NO_GO。
