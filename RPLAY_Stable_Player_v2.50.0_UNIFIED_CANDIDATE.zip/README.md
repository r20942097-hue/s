# RPLAY v2.50.0 UNIFIED CANDIDATE

`v2.49.0` 統合ベースに **segment_store Stage 3（明示取得の本番結線）** を実装した v2.50.0 統合候補版です。dashboard の `segmentAcquire` フラグ（既定OFF）をONにすると、検出したHLS候補への明示的な「取得」が可能になり、セグメントをRAM常駐1件に抑えながらOPFS（disk）へ確定書き込みします。再起動後は台帳で復元・続行でき、取消後も取得済みセグメントはdiskに残ります（非破壊）。URL・トークンは一切記録しません。

## 版の来歴
- v2.48.0: 並行系統2系統の統合（mp4AutoHandoff + segment_store Stage 1 + preview_diag ／ addon-max upgrade）
- v2.49.0: addon-max統合の完成 + segment_store Stage 2（取得エンジン `RspSegmentAcquire`）+ dashboard policy表示拡張
- v2.50.0: **Stage 3 結線**（`src/acquire_host.js`・offscreen/BG/dashboard の明示取得経路・24新規テスト）

## 自動テスト

**1101 / 1101 PASS**（Node.js 922件 + Python 179件）。

## v2.48.0 の主な統合・改良内容

1. **BG録画停止後のMP4自動引渡し (`src/mp4_handoff.js` — v2.44.0並行系統から統合)**:
   - 録画停止・異常終了・ブラウザ再起動後にOPFS退避（`rsp_rec`）へ未完了のまま残ったTSパートをMP4へ自動変換し、保存台帳（export journal）へ引き渡す編成モジュールです。
   - 紀律は統合後も不変: **元TSは削除・変更しない（非破壊）**、**既定OFF**（`mp4AutoHandoff` 設定）、**単発実行**（変換中は新規録画を開始しない）、**秘密ゼロ**（URL/トークン等を証拠へ出力しない）。
   - 結線: `src/offscreen_post.js`（MP4_HANDOFF ホスト・bg-stop enqueue・`mp4-handoff.status` / `mp4-handoff.sweep` メッセージ）、`src/background.js`（起動時 sweep 呼び出し・handoff中のoffscreen保持ガード・`rec.start` への設定伝播）、`src/export_host.js`（`inFlightNames()` — 書き込み途中パートの変換対象除外）、両拡張のライブラリ事前読み込み（Chrome offscreen.html / Firefox manifest background.scripts）。
   - v2.39.0系統の `mp4Handover`（停止後の変換画面自動表示・手動案内）と**共存**します（dashboard に両方のトグル）。
2. **OPFS disk-backed segment store (`src/segment_store.js` — 段階設計 Stage 1 基盤)**:
   - OPFS上の名前空間ディレクトリへセグメント本体（`.bin`）とメタ（`.json`）をペア書き込みし、digest照合は fail-closed、容量/件数予算のLRU退避・pin・孤児清掃を持つ保存プリミティブです。
   - 取得経路・ネットワーク・URLは一切扱わないため、本版では録画経路へは未接続（今後の汎用取得段階設計 Stage 2 以降の土台）。ネットワーク API を参照しない構造を結線試験で固定しました。
3. **native preview環境要因の切分け (`src/preview_diag.js`)**:
   - 変換画面のMP4プレビューが再生できない要因を、環境（NO_DECODER / FROZEN_CLOCK）/ 操作（AUTOPLAY_BLOCKED）/ 内容（DECODE_ERROR）へ分類して表示します。診断は表示のみで、変換・保存・照合・ダウンロードの経路には影響しません。
   - `src/mp4_convert.html` / `src/mp4_convert.js` へ統合（`watchClock` による時計前進監視付き）。v2.39.0系統の「直近BG録画セッション（引渡し）」台帳表示と共存します。
4. **結線回帰試験 (`tests/test_v2480_integration_wiring.cjs` — 新規8件)**:
   - offscreen.html / Firefox manifest の読み込み順、MP4_HANDOFF ホスト結線の非破壊ガード、background の保持ガードと sweep 呼び出し、dashboard 設定契約（`mp4Handover` と `mp4AutoHandoff` の併存）、mp4_convert ページの両機能共存、segment_store の取得経路非結合、build/validate の派生コピー網羅を検査し、今後の改変で統合が静かに外れることを防ぎます。

## 自動テスト

**1101 / 1101 PASS**（Node.js 922件 + Python 179件）。内訳: v2.49.0 継承 1077件 + v2.50.0 追加 24件（取得結線試験）。

## 検証コマンド

```bash
python3 scripts/build.py
python3 scripts/validate.py --output-dir evidence/v248-current
python3 tests/check_request_context_http.py
python3 tests/check_cdn404_decode.py
node tests/check_recording_during_scan.cjs
```


---

# RPLAY v2.49.0 UNIFIED CANDIDATE（最新版）

`v2.48.0` 統合ベース（mp4AutoHandoff + segment_store Stage 1 + preview_diag）に、ユーザー提供の並行系統 v2.48.0 (addon max upgrade) を非衝突マージし、加えて `segment_acquire` Stage 2（汎用取得エンジン）と dashboard policy 拡張を実装した v2.49.0 統合候補版です。

## v2.49.0 の主な統合・改良内容
- **並行系統 v2.48.0 (addon max) の統合**: master playlist audit / `--join-files` CLI / `--mux-audio` / VTT字幕mux / 広告除外キーワード / crash復帰 / `--audit-files` を非衝突マージ
- **segment_store Stage 2 実装**: `src/segment_acquire.js`（`RspSegmentAcquire`）— 明示候補のみを disk-backed で取得する汎用エンジン（RAM 1セグメント上限・再起動継続・cancel残留・非破壊・fail-closed・ゼロシークレット・既定OFF）
- **dashboard policy 拡張**: 実効policy行に `mp4Handover` と `mp4AutoHandoff` を列挙
- v2.48.0 までの全機能を完全維持

## テスト結果
**1077 / 1077 PASS**（Node.js 898件 + Python 179件）。内訳: v2.48.0 統合ベース 1050件 + Line B addon-max 2件 + segment_acquire Stage 2 22件 + dashboard policy 統合検証 2件 + 期待値更新分。

## 成果物
`RPLAY_Stable_Player_v2.49.0_UNIFIED_CANDIDATE.zip`（4.30MB・1995ファイル・zip sha256 `602b5487…`）。`CANDIDATE_NO_GO` / `remote_published=false` として紀律を維持。
