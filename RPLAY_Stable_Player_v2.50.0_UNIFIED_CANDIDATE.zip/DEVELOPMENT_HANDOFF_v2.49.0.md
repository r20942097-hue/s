# Development Handoff — RPLAY Stable Player v2.49.0 (`CANDIDATE_NO_GO`)

## 1. Release Overview
- **Artifact**: `RPLAY_Stable_Player_v2.49.0_UNIFIED_CANDIDATE.zip`（zip sha256 `602b5487…`・4.30MB・1995ファイル）
- **Version**: `2.49.0` (`CANDIDATE_NO_GO`)
- **Base**: 前回作成の v2.48.0 統合ベース（1050/1050 PASS）に、ユーザー提供の並行系統 v2.48.0 (addon max upgrade, 991/991 PASS) を非衝突マージ
- **Validation**: `1077 / 1077` 自動テスト（`898` Node.js + `179` Python）+ クリーンルーム PACKAGE_HASHES_PASS

## 2. Integration Performed in `v2.49.0`（統合案の実行）
並行2系統の v2.48.0 が存在した:
- **Line A（前回作成）**: mp4AutoHandoff + segment_store Stage 1 + preview_diag 統合済み（1050テスト）
- **Line B（ユーザー提供）**: addon max upgrade（master playlist audit / `--join-files` CLI / `--mux-audio` / VTT字幕mux / 広告除外キーワード / crash復帰 / `--audit-files`）（991テスト）

差分分析の結果、Line B が触るファイル（player.user.js・part_io.js・cli.py・hls_transport.py・join_parts.py・media_inspect.*）と Line A が触るファイル（background.js・offscreen_post.js・dashboard.*・mp4_convert.*）は完全に非衝突であることを確認。これにより conflict-free の統合が可能となった。

| 側 | 由来 | ファイル | 新規テスト |
|---|---|---|---|
| Line A → v2.49.0 | 前回作成 v2.48.0 | mp4_handoff.js / segment_store.js / preview_diag.js + 結線 | 54件 (test_v2480_*) |
| Line B → v2.49.0 | ユーザー提供 v2.48.0 | player.user.js / part_io.js / cli.py / hls_transport.py / join_parts.py / media_inspect.html / .js / _core.js | 2件 (test_v2480_addon_max_*) |
| v2.49.0 新規 | 本リリース | segment_acquire.js + dashboard.js policy 拡張 + background.js rspEffectivePolicy 拡張 | 22+2件 (test_v2490_*, integration_wiring 追加2) |

### バージョンピン更新
- マニフェスト2件・userscript `@version`・`rplay_dl.py v2.49.0` 文字列5箇所・`rplay_join.py v2.49.0`・`acceptance_report.py v2.49.0`・build/validate/package_release の各スクリプト出力 → 全て `2.49.0` へ
- レンジピン（`|48|49)\.0` 形式と `|48\.0|49\.0)` 形式の2種を網羅）7ファイル拡張
- 完全一致ピン（test_v2150_core / test_v2160_core / test_v2422_dash / test_v2424_part_commit / test_v2450_crash_parts / test_v291_core migration literal / test_v2150_features / test_v291_features）更新
- 履歴コメント（`v2.48.0:` 等の changelog コメント）は規約通り保持

## 3. New Features in v2.49.0
### 3.1 segment_store Stage 2: RspSegmentAcquire（汎用取得エンジン）
`src/segment_acquire.js`（新規・348行）— Stage 1 segment_store の保存プリミティブの上に、明示候補のみを処理する disk-backed 取得エンジン。設計は `GENERIC_DISK_BACKED_DESIGN_v2.44.0.md` Stage 2 に準拠。

**契約**:
- 入力: `MediaCandidateRegistry.list()` の観測候補（RAM・15分失効）を唯一の入力とし、ユーザーが明示的に選択した候補のみ処理。自動取得・巡回取得は行わない。
- 取得: 既存 `fetchJsonWithRetry`（2MiB上限・共有モジュール）と `LiveSegmentLedger` の契約を流用。セグメント受信は即座に segment store へ確定書き込みし、RAM常駐量を「現処理中の1セグメント」に限定。
- 再起動後: 台帳（ledger JSON）と store のメタで継続を判定（`restore()` + `continueFrom()`）。
- 取消・停止: 任意時点で中断でき、中断時点のセグメントが disk に残る（クラッシュ復旧と同じ形態）。自動削除はしない。
- 組立: Stage 3 で既存の `RspMp4Convert`（TS→MP4）または無劣化連結へ引き渡す（本リリースでは未配線）。

**API**:
- `start({id, candidate, initialPlaylistUrl, signal})` — 明示候補のみ開始
- `continueFrom({id, playlistUrl, signal})` — 再開
- `cancel(id)` / `discard(id)` / `status(id)` / `list()` / `listResidue(id)` / `restore({...})` / `zeroSecretScan(id)`

**紀律**:
- 非破壊・fail-closed・虚偽零なし・ゼロシークレット・既定OFF（全段階で不変）
- discard() は on-disk セグメントを削除しない（store.sweep は呼び出し側の責務）
- zeroSecretScan は status 出力に URL/トークン/Cookie/secret キーワードが含まれないことを検証

### 3.2 dashboard policy 拡張
- `background.js rspEffectivePolicy` の `external` オブジェクトに `mp4Handover` と `mp4AutoHandoff` を追加（null許容・boolean）
- `dashboard.js` policy 行の filter 配列に両フラグを追加（null は「値なし」で非表示）
- これにより、ダッシュボードの「実効policy」行に「`mp4Handover=ON`・`mp4AutoHandoff=OFF`」のように両フラグの適用状態が表示される

### 3.3 Line B addon max 統合
- `rplay_dl.py --join-files PART_FILE...` スタンドアロン無劣結合CLI（`--join-audio-files` / `--join-subtitle` / `--join-subtitle-lang` / `--join-out` オプション）
- `rplay_join.py` WebVTT 字幕検証（`JOIN_BAD_SUBTITLE` / `JOIN_BAD_SUBTITLE_LANG` fail-closed）+ mov_text 字幕トラック mux（digest検証 staging）
- `hls_inspect_master` Python 側マスタープレイリスト構造監査（JS `inspectMaster` と完全鏡像・ゼロURI出力）
- URL録画の広告除外キーワード正規表現フィルタ（`adFiltered` / `scte35` ステータスカウンタ追加）

## 4. Remaining Unverified Boundaries (`CANDIDATE_NO_GO`)
- 実 live-service 耐久（RPLAY / Niconico / YouTube / Twitch）、実 Chrome 拡張インストール、Windows ネイティブ FS 挙動は container simulation の外であり、`ACCEPTANCE.md` に基づく人間受入観察が必要
- `mp4AutoHandoff` ON パスは実ブラウザ受入（A-11）が必要: 実OPFS残留 + 実mux.js変換 + 実download journal
- `segment_acquire` Stage 2 エンジンは実ブラウザ受入（A-12）が必要: 実HLS候補選択 → 実セグメント取得 → 実disk-backed保存 → 実再開

## 5. Suggested Next Steps
- `ACCEPTANCE.md` 項目（A-10・A-11・A-12 含む）を実ブラウザで実施
- `segment_store` Stage 3: `RspSegmentAcquire` を dashboard の候補一覧から「この候補を取得」で明示起動する経路を実装。進捗・中断・再開は録画UIと同じイベント経路（`rec.event` 系）で可視化し、保存は export journal 経由（blob URL は永続化しない）。失敗時の案内は既存診断（401/403/404/410/429・視聴ページ判別）と統一
- Stage 3 完了まで `segment_acquire` は本番配線に現れない（既定OFF・紀律維持）
