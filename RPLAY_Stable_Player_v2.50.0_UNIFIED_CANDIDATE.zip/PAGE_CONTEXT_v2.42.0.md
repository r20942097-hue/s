# ページ取得条件と署名の保持 — v2.42.0 / 2026-10-27 JST

## 取得経路

1. ページが使ったmedia URLをそのまま候補へ保存。URL一覧ではoriginだけ表示し、選択した診断画面では元URLを利用できる。
2. リクエスト情報はrequestId＋tabIdで対応付け、応答URLが一致する場合だけ採用。別URLへredirectした時に旧ヘッダを誤って結び付けない。
3. Referer/Origin/User-Agentはallowlist方式。URLのuser:password、制御文字、不正形式、過大ヘッダは採用しない。Cookie/Authorizationは存在のbooleanだけ。
4. ブラウザ目録取得ではユーザーのCookie利用選択をcredentialsに反映。原URLは変更しない。Referer/Origin/Authorizationの再現やブラウザCookie方針の回避は行わない。
5. 保存コマンドでは観測Referer/UAを入力へ反映し、元署名URLをquoteして出力。Refererもクエリ等を含み得るため、生成内容を共有する前に確認する。観測ヘッダが別originの音声/映像にも適切とは限らず、各入力の条件を確認する。

## 親クエリ継承の境界

既定ではHLS標準の相対URL解決を使い、親queryは自動継承しない。明示ON時だけ、同一originでqueryが空の子URLへ親raw queryを付加する。子の独自署名を上書きしない。鍵取得やアクセス権追加を意味しない。

## 試験の範囲

ローカルHTTP fixtureで、匿名モードの403、Cookie利用を模擬したモードでの成功、raw queryのescape/順序/重複保持、子への限定継承を確認。Cookie jarはテスト用注入であり、実Firefox/Chrome/Floorpの送信条件を再現したと主張しない。

根拠（2026-10-27参照）:
https://developer.mozilla.org/en-US/docs/Web/API/Request/credentials
https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/webRequest/onBeforeSendHeaders
https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch

MDNはcredentialsが認証情報の送受信方針を決めること、includeでもCookie制約が残ることを説明している。実サービス受入ではこの条件差を別途確認する。
