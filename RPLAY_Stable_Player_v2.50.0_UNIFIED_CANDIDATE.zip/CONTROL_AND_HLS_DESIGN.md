# セッション操作権とHLS録画ループ：v2.2.0実装仕様 / v2.5.0追記 / v2.6.0追記

v2.6.0追記: fMP4 MAP宣言証拠(fmp4Evidence)・LL-HLS安全側仕様(HLS_LLHLS_SKIP拒否・指標計数)・avCorrelation実測を追記(HLS_TRANSPORT_DESIGN.md参照)。
v2.5.0追記: 診断出力(情報JSON・ログ・webhook)から署名/key2クエリを除去
する(redact)。RAM内の取得経路は変更しない。セグメント取得順のFIFO不変を
shadow実測する(queueOrder)。CLIの保存確定はledger.jsonのイベント契約に
従う(詳細はHLS_TRANSPORT_DESIGN.md)。

## 制御の境界

content scriptはロードごとに32桁のランダムclientIdを作り、送信ごとに添付する。背景ルーターはbrowserが返すsender.tab.id、sender.documentId、sender.frameIdを使い、controlフィールドを構築し直す。呼出payloadのtabId等を信頼しない。トップフレーム以外、正規RPLAY origin以外、他拡張のメッセージは制御できない。

文書識別：[Chrome MessageSender](https://developer.chrome.com/docs/extensions/reference/api/runtime/)、[MDN MessageSender](https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/runtime/MessageSender)。documentIdがない環境でも、tabId＋ロード時clientIdで前文書の操作を分離する。

hostはsessionId、単調増加epoch、creator、owner、phaseを持つ。phaseはSTARTING→ACTIVE→DRAINING→IDLE。localStorageにはepochの数値だけを事前確定し、JWT/Cookie/URLは保存しない。sessionIdはhostの新しいセッションごとにランダム生成する。SW再生成ではhostが真実源として残る。host再生成では旧sessionIdを再利用しない。

stop/token.updateは、現在のownerとsessionId/epoch/creatorすべてが一致する場合だけ受け付ける。claimは現在のsessionId/epoch/creatorが一致する場合に限りownerを置換しepochを進める。新所有者は最新statusでcontrolを得る。古いclaimの再送は現在epochと一致せず拒否される。

録画開始・停止・claim・token更新は一つのPromiseキューで直列化する。停止の保存待ち中は次の開始を実行しない。read statusは待機中も返し、操作不能・DRAININGを示せる。各Recorderインスタンスは自身のbindingを参照してイベントを送るため、旧Recorderの遅延イベントが新録画の識別子を借用することはない。

## 画面の動作

録画を起動した文書が最初の所有者となる。同じcreatorを別タブで表示しても、自動で所有者を置き換えない。明示的な「録画を引き継ぐ」だけで操作権を移動する。RECクリックと手動分割は操作直前に最新statusを取得し、canControl=trueのcontrolを送る。古いキャッシュだけで停止しない。

イベントのcreator/sessionId/epochを検証し、他配信や古い世代によるタイトル・状態の上書きを防ぐ。イベント受信だけでcanControlを付与しない。JWTは所有者タブからだけ更新する。

## HLSの時間制御

[RFC8216 §6.3.4](https://www.rfc-editor.org/rfc/rfc8216.html#section-6.3.4)の通常HLSの待機下限を録画ループに反映した。media URIと本文をRAM中で比較し、初回/変更ありはTD、変更なしは0.5 TDを基本待機にする。ジッタは0〜10%を加算する方向で、以前の最長10秒clampや負方向ジッタで下限を短縮しない。

待機期限は前回media要求開始時刻＋算出間隔。master取得や本文取得が長引いても、応答完了時から同じ間隔をもう一度加算しない。fetch例外・本文例外ともfinallyでタイマーを解放する。署名付きURI/本文はタイミング比較にRAMで保持するだけで、新しい永続台帳には書かない。

この変更は通常の録画pollループに適用する。接続探査や再生ライブラリの全要求を含む統一スケジューラー、LL-HLS blocking reloadの実装ではない。

ENDLISTは新規playlist取得を止める合図として扱い、セグメント再試行キューと音声キューを排出してから終了する。音声tickも終了待ちの間に進める。取得順は既存FIFOを維持する。

## チェックポイントと復帰

新しい録画チェックポイントへmemberPlaylistを保存しない。旧チェックポイントを読む際も該当フィールドを除去して書き戻す。会員モードの復帰は現在の認証アダプタで再解決し、成功するまで録画tickを保留する。拒否・失敗時は録画を停止し、未認証の取得経路へ暗黙に切り替えない。再解決中に停止した場合、遅れて返った成功応答から新たなメディア要求を出さない。

従来の情報JSONは利用者向けメタデータ出力であり、クラッシュ用チェックポイントとは別。出力内容の秘匿性を本変更で一律保証しない。
