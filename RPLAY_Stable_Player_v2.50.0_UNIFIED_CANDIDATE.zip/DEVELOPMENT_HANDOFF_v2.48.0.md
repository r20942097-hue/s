# Development Handoff — RPLAY Stable Player v2.48.0 (`CANDIDATE_NO_GO`)

## 1. Release Overview
- **Artifact**: `RPLAY_Stable_Player_v2.48.0_UNIFIED_CANDIDATE.zip`
- **Version**: `2.48.0` (`CANDIDATE_NO_GO`)
- **Base**: user-lineage `v2.47.0` (988/988 PASS baseline re-verified before integration)
- **Validation**: `1050 / 1050` automated tests (`873` Node.js + `177` Python) + 3 standalone E2E scripts (`check_request_context_http.py`, `check_cdn404_decode.py`, `check_recording_during_scan.cjs`).

## 2. Integration Performed in `v2.48.0`（統合案の実行）
Two parallel lineages existed for `v2.44.0`: the user-lineage continued to `v2.45→v2.47` (crash-part persistence, `--audit-files`, `--mux-audio`, transient-grace parity, creator meta, CrossSite v0.1.0, addon synthesis), while the local lineage had implemented `mp4_handoff.js` + `segment_store.js` + `preview_diag.js` on its own v2.44.0 base. This release merges the local modules into the newer user base:

| Module | Origin | New tests | Wiring re-applied on the v2.47.0 base |
|---|---|---|---|
| `src/mp4_handoff.js` | local v2.44.0 | 15 | offscreen_post (host + enqueue + 2 msg cases + status + test bridge), background (sweep + close guard + defaults + propagation), export_host (`inFlightNames`), offscreen.html ×2 preload, Firefox manifest scripts |
| `src/segment_store.js` | local v2.44.0 | 17 | derived copies only (standalone Stage 1 primitive by design) |
| `src/preview_diag.js` | local v2.44.0 | 22 | mp4_convert.html script order, mp4_convert.js event wiring merged with the v2.39.0 session-ledger UI |

- **Naming**: the user-lineage flag `mp4Handover` (conversion-screen auto-open) and the integrated flag `mp4AutoHandoff` (automatic conversion + journal handoff) intentionally coexist; both default OFF and are separately explained in the dashboard.
- **Version pins**: userscript `@version`, both manifests, `rplay_dl.py` / `acceptance_report.py` tool strings, join schema tool string, `scripts/build.py` / `validate.py` / `package_release.py` — all moved to `2.48.0`; range-pin regexes in 8 test files extended; exact pins in 5 test files updated. Historical `v2.47.0:` changelog comments are preserved by convention.
- **New regression guard**: `tests/test_v2480_integration_wiring.cjs` (8 tests) locks the integration points listed above.

## 3. Remaining Unverified Boundaries (`CANDIDATE_NO_GO`)
- Real live-service endurance on RPLAY / Niconico / YouTube / Twitch, real Chrome extension installation, and Windows native filesystem behavior remain outside container simulation and require human acceptance observation per `ACCEPTANCE.md`.
- `mp4AutoHandoff` ON path requires real-browser acceptance (A-11): real OPFS leftovers + real mux.js conversion + real download journal.

## 4. Suggested Next Steps
- Execute `ACCEPTANCE.md` items (including the new A-11) on a real browser.
- `segment_store.js` Stage 2: connect the store to a generic acquisition path behind an agreement gate (design: `GENERIC_DISK_BACKED_DESIGN_v2.44.0.md`).
- Optional: extend the dashboard policy display to enumerate `mp4AutoHandoff` in the applied-external-settings line.
