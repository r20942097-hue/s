# RPLAY v2.16.0 UNIFIED CANDIDATE

cat-catch解析第3波として、(1) ソフトウェアAES-128復号フォールバック、(2) CLIのAES-128取得
(`--dec-key` / `--dec-key auto` / `--dec-key-file` / `--dec-key-env`)、(3) TS連続性カウンタ監査
(証拠のみ・非破壊) を追加。v2.15.0で配布物から漏れていた `rplay_join.py` を復元し、
同梱漏れを試験で恒久検査する。自動試験は424件全PASS (Node 262 + Python 162)。

- AES-128復号: ブラウザ側は `crypto.subtle` が使えない環境でも復号可能
  (hls.js/cat-catch系譜の等価逆暗号・NIST SP 800-38AとWebCrypto・opensslとバイト一致を常時検証)。
  CLI側は openssl (既定・高速) または純Python (~1MB/s・`--dec-backend python`)。
  鍵値は情報JSONにもログにも一切記録しない (ゼロシークレット・出力全ファイル走査試験あり)。
- `continuityCounterEvidence`: TSパケットの連続性規則 (ISO/IEC 13818-1 2.4.3.2) を
  監査し、欠落推定・重複・逆方向ジャンプを数値証拠化。録画は中断しない。
- 詳細: [RPLAY_DEVELOPMENT_PLAN_v2.16.0.md](RPLAY_DEVELOPMENT_PLAN_v2.16.0.md) /
  [QA_v2.16.0.md](QA_v2.16.0.md) / [CAT_CATCH_ANALYSIS_v2.16.0.md](CAT_CATCH_ANALYSIS_v2.16.0.md)。

以下は前版の説明です。

# RPLAY v2.15.0 MP4 CANDIDATE

保存済みTSからブラウザ内でMP4へ変換する画面を追加。H.264と同じTS内のAAC、1入力64MiBまでの初版です。録画中のMP4直接出力は未実装。実ブラウザの導入・操作は未検証。

手順と制約: [MP4_GUIDE_v2.14.0.md](MP4_GUIDE_v2.15.0.md)。

以下は前版の説明です。

# RPLAY v2.13.0 HASH VERIFY CANDIDATE

大容量ファイルのSHA-256とチェックポイントの内容照合を追加。復旧時に同サイズの破損も検出します。

導入と制約: [HASH_GUIDE_v2.13.0.md](HASH_GUIDE_v2.13.0.md)。再添付v2.10.0の差分はintake/BRANCH_REVIEW.md。

以下は前版から継承した説明です。

# RPLAY v2.12.0 CHECKPOINT CANDIDATE

保存先を選択したTS/fMP4録画に、確定済みデータの復旧用チャンクと台帳を追加しました。復旧画面から別ファイルへ救出できます。実ブラウザ強制終了・長時間録画は未検証です。

使用手順と制約: [CHECKPOINT_GUIDE_v2.12.0.md](CHECKPOINT_GUIDE_v2.12.0.md)。今回の対象外: ブラウザ内MP4変換・別音声合成・録画の自動再開。

以下は前版の説明です。

# RPLAY v2.11.0 SINGLE FILE CANDIDATE

保存先フォルダ選択＋録画分割0で、直接保存するHLSの容量分割を抑制します。書き込み待ちと大容量メモリ読み戻しの抑止を追加しました。実ブラウザ・実RPLAY・Windows・長時間録画は未検証です。

導入と制約: [SINGLE_FILE_GUIDE_v2.11.0.md](SINGLE_FILE_GUIDE_v2.11.0.md)。以下は入力v2.10.0の既存説明を保持したものです。

# RPLAY Stable Player — 統合バンドル v2.10.0

==========================================================
◆ v2.10.0 — TS細切れ分割の抜本改善 & Video DownloadHelper / Streamlink / rplay_watcher v0.5.2 知見統合
  (MPEG-TS EXT-X-DISCONTINUITY連続追記・splitMin既定0・OPFS 512MB/FSA 2GB・
   --concat-parts無劣化結合・セグメント503 Retry-After・paywall_blocked検出)
==========================================================

本バンドルはv2.9.0 UNIFIED CANDIDATE(284試験)を基盤に、「TSファイルが分割録画・細かいファイルになる」問題の全5要因を解消し、Video DownloadHelper (`vdhcoapp`)・Stream Recorder・N_m3u8DL-RE・Streamlink・yt-dlp および `rplay_watcher` v0.5.1/v0.5.2 の知見を統合した候補版です(Node 177 + Python 119 = **296試験PASS**)。

----------------------------------------------------------
【v2.10.0 P1: MPEG-TS EXT-X-DISCONTINUITY シームレス連続追記 (W-05)】
----------------------------------------------------------
  - 従来は `#EXT-X-DISCONTINUITY` タグのたびに `closePart()` / `close_part()` で別ファイルへ強制分割していたため、OBSフレーム落ちやエンコーダ微調整が多い配信で数KB〜数MBの細切れ `.ts` ファイルが大量発生していた。
  - MPEG-TS（`!d.map`）は188バイトパケット毎にPAT/PMT/PCRを持つ自己同期ストリームであるため、既定では `EXT-X-DISCONTINUITY` を跨いでもパートを閉じず **1つの `.ts` ファイルへ連続追記** し、`partContinuityEvidence.discontinuityMergedCount` にマージ回数を記録。
  - 明示的に分割したい場合は `--split-on-discontinuity`（CLI）または `splitOnDiscontinuity` で従来どおり分割可能。fMP4（`EXT-X-MAP` あり）と世代境界（`epoch`）は初期化ボックス整合・世代分離のため境界分割を維持。

----------------------------------------------------------
【v2.10.0 P1: 時間分割既定0化・OPFS/FSA上限拡大・複数パート無劣化自動結合 (W-06)】
----------------------------------------------------------
  - `splitMin` / `--split-min` の既定値を `20`（20分ごと強制分割）から **`0`（時間分割なし・容量上限または配信終了まで単一ファイル継続）** へ変更。
  - 拡張バックグラウンド録画（`offscreen_pre.js`）の `partByteLimit` を `64 MiB` から **`512 MiB`** へ引き上げ、さらに File System Access API の保存先フォルダ直書き（`dirHandle`）時は **`2 GiB`（2048 MiB）** まで単一ファイルを維持する `fileCapBytes()` を実装。
  - CLI に `--concat-parts {auto,mp4,ts,no}` および `concat_media_parts()` を追加。画質昇格や追跡再開で複数パートが生じた場合でも、Video DownloadHelper CoApp (`vdhcoapp`) や `N_m3u8DL-RE` と同じ FFmpeg concat demuxer (`-f concat -safe 0 -i list.txt -c copy -movflags +faststart+use_metadata_tags`) または TSバイナリ連結によって単一ファイル（`_merged.mp4` / `_merged.ts`）へ無劣化結合。

----------------------------------------------------------
【v2.10.0 P1: セグメントHTTP 503 Retry-After対応 & Paywall検出 (W-07)】
----------------------------------------------------------
  - `v2.7.1` パッチの知見を統合し、セグメント取得で HTTP 503 が返った際も `Retry-After` ヘッダを解釈して映像・音声それぞれのバックオフへ設定。
  - `rplay_watcher` v0.5.2 の知見を統合し、Master playlist が 200 を返しつつ Media playlist（バリアント）が 404/403 を返す非対称応答を `paywall_blocked` として検出し、`ErrorKind.AUTH` 計上と明示ログ出力を実施。


==========================================================
◆ v2.9.0 — A-09 字幕対応 第一段階「観測と証拠」
  (EXT-X-MEDIA TYPE=SUBTITLES観測・subsGroup結合・subtitleEvidence
   observed_not_fetched契約・URI秘匿・相互言語鏡像)
==========================================================

本バンドルはv2.8.0 UNIFIED CANDIDATE(272試験)を基盤に、v2.7.0完成報告で
次版候補とされたA-09字幕対応の第一段階(観測と証拠)を実装した候補版です
(Node 171 + Python 113 = **284試験PASS**)。

----------------------------------------------------------
【v2.8.0 P1: 拡張offscreen/backgroundホストの証拠対称化 (W-04)】
----------------------------------------------------------
  - `ext_glue.js`が`rec.start`および`token.update`送信時に、ページ側の
    `window.__RSP.authEvidence()` / `canaryEvidence()` から秘密を含まない
    計数・種別情報のみを抽出しホストへ中継。
  - `offscreen_pre.js`が中継された計数とホスト自身の401分類・key2解決・
    Butter送出・live/play応答形状canaryを統合し、バックグラウンド録画時の
    情報JSONにもページ内録画と同一鍵構造の`authEvidence`/`canaryEvidence`を記録。

----------------------------------------------------------
【v2.8.0 P1: Butter署名生成とM3U8 403自動再試行 (W-01)】
----------------------------------------------------------
  - `rplay_watcher` v0.5.0 (`core/api_client.py` / `ROOT_CAUSE_ANALYSIS.md`)の
    知見を反映し、CLI(`rplay_dl.py`)・拡張offscreen・ページ内録画コアの全経路で
    M3U8が403を返した際にAES-128-CBC `Butter`署名ヘッダ付きで自動再試行。
  - WebCrypto実装とPython実装(`generate_butter_token`)の128桁hex完全バイト一致を
    相互言語試験で固定。送出時は`authEvidence.butterSent=true`を記録。

----------------------------------------------------------
【v2.8.0 P1: streamStartTime 10分(600秒)閾値セッション追跡 (W-02)】
----------------------------------------------------------
  - `rplay_watcher` v0.5.0 (`SessionManager` / `LiveStatus.is_new_session`)の
    セッション継続判定を統合: `live/play`の`streamStartTime`(または`startedAt`)を
    追跡し、変化幅が600秒以内なら`same_session_resumed`(瞬断復帰)、600秒超なら
    `new_session_split`(新配信枠)として`sessionTrackingEvidence`に記録。

----------------------------------------------------------
【v2.8.0 P1: 4層ErrorKind分類体系 (W-03)】
----------------------------------------------------------
  - `rplay_watcher` v0.5.0 (`core/errors.py`)のエラー分類を統合し、
    `SOURCE`(5xx) / `NETWORK`(接続・timeout) / `AUTH`(401/403) /
    `PLATFORM`(429) / `COMPATIBILITY`(暗号化・LL-HLS SKIP等) / `INTERNAL`(書込失敗)
    の6分類と`recoverableCount`・`sourceFailureCount`を`errorTaxonomyEvidence`に記録。

==========================================================
◆ v2.7.0 — 追加提案A-01〜A-08を採用しサイト変化への追従力を
  証拠駆動で強化(認証Refresh-Token移行・auth_store抽象・canary検知・
  通知拡充・MP4メタデータ・合成APIリグレッション)
==========================================================

本バンドルはv2.6.0 UNIFIED CANDIDATE(230試験)を基盤に、開発指示プロンプト集
v1.0の追加提案から実機を要しない要件を実装した統合候補版です(262試験PASS)。

----------------------------------------------------------
【v2.7.0 P1: 認証の段階移行とauth_store抽象 (A-01/A-02)】
----------------------------------------------------------
  CLIに新オプション:
  - `--refresh-token SPEC` — 自分のRefresh-Token。値直接 / `env:<環境変数名>` /
    `file:<パス>` の三種で供給(秘密をコマンド履歴に残さない運用が可能)。
  - `--user-oid OID` — APIクエリのrequestorOid補完(未指定時はJWT主張から補完)。
  AuthStore契約(両コア鏡像・JSはRspAuth):
  - 短命JWTの更新ループ: expのleeway(300秒)前に再取得・失敗は3回再試行
    (指数バックオフ)・60秒クールダウンで連打防止。
  - `--token`(明示指定)が一次資格。401時だけ--refresh-tokenへ自動切替し
    1回だけ再試行(公式interceptorと同一戦略)。
  - 401分類: no_credentials / invalid_or_expired / refreshed / refresh_failed。
  - 認証の回避は行わない(自分の資格のみ・権限の無い配信にはアクセスしない)。
  - authEvidence(認証方式・供給源種別・更新回数・401分類計数・key2再解決回数・
    応答鍵)を情報JSON/ledgerへ記録。**秘密(トークン値)は一切出さない**。
  - 応答鍵(jwt/token/…)は非公式情報のため形状証拠として記録し、
    実測(P-02)で確定してから採用判断する。

----------------------------------------------------------
【v2.7.0 P1: サイト更新検知のcanary (A-03)】
----------------------------------------------------------
  live/play応答の「鍵の一覧」だけを既知鍵と照合(canary_check):
  - ok(既知鍵あり) / shape_change(辞書だが既知鍵ゼロ) / unreachable。
  - shape_changeでも録画を止めない(警告ログのみ・安全側継続)。
  - canaryEvidence(観察鍵一覧・値は出さない)を情報JSONへ記録。
  - Python/JS両コアで同一判定(相互言語比較試験で固定)。
  - A-07合成リグレッションと併せ、サイト変化を開発時・実行時の二重で検知。

----------------------------------------------------------
【v2.7.0 P2: 通知の豊富化 (A-04)】
----------------------------------------------------------
  webhookイベントを拡充:
  - 既存: start / part / audio_part / end
  - 新規: **auth_failed**(level=error) / **save_error**(error) /
    **capacity_warning**(warn・ディスク/inode) / **merge_completed**(info)
  - 全イベントにlevel(info/warn/error)とts(ISO)を付与。
  - 429応答のRetry-After退避を優先(上限30秒)。
  - notificationEvidence(イベント別計数・429遭遇回数)を情報JSONへ記録。
  - ペイロード契約(秘密の完全除去)は維持。

----------------------------------------------------------
【v2.7.0 P2: MP4メタデータタグ (A-05)】
----------------------------------------------------------
  `--mux auto|mp4`時のリマックス/2トラックmuxに
  rplay_metadata_version=1互換タグを埋め込み:
  - creator_oid / title / artist / recording_started_at
    (stream_oid・stream_start_timeは分かる場合のみ)
  - **未知の値は埋めない契約**(分かる値だけを埋める)。
  - `-movflags +use_metadata_tags`でカスタム鍵を書込み、
    ffprobe -show_entries format_tagsで確認する手順を試験に組込み済み。
  - metadataEvidence(埋め込みタグ鍵一覧)を情報JSONへ記録。

----------------------------------------------------------
【v2.7.0 P1: 合成APIリグレッション (A-07)】
----------------------------------------------------------
  認証フローをローカルHTTP合成試験として固定(実ネットワーク不要):
  - refresh-tokenエンドポイントの形状・401→更新→1回再試行のフロー
  - --token優先と401自動切替・env/file供給・auth_failed通知
  - live/play形状canary(ok/shape_change/unreachable)
  サイト側でAPI形状が変わった場合は、合成側の期待の差分として
  変化点が明示される(開発時の検知。実行時はcanaryが担う)。

----------------------------------------------------------
【v2.7.0 横断: 証拠ブロックの拡張 (A-08)】
----------------------------------------------------------
  v2.6.0の証拠体系(generationRecovery・fmp4Evidence・llhlsEvidence・
  avCorrelation)に4ブロックを同形式で追加:
  authEvidence / canaryEvidence / notificationEvidence / metadataEvidence
  全ブロックで「虚偽零(gapは未実施と書く)・出所明示・URL秘匿」を適用。
  ブラウザー側はRECENVフック経由で供給(offscreen等で未供給なら
  証拠ブロックを出さない — 虚偽のゼロを捏造しない)。

==========================================================
◆ v2.6.0 — 開発計画v2.5.0の残課題を消化(P1 fMP4 MAP監査・
  P1 分離音声PTS相関・P2 LL-HLS安全側仕様・P2 予算境界文書化・P0 実受入準備)
==========================================================

----------------------------------------------------------
【v2.6.0 P1: fMP4複数MAPの宣言証拠 (fmp4Evidence)】
----------------------------------------------------------
  `EXT-X-MAP`(fMP4初期化セグメント)の宣言を数値証拠として記録:
  - `mapDeclarations`  playlist内の宣言数(再宣言を含む)
  - `mapSwitches`      URI/rangeが変わった切替回数
  - `mapSwitchesWithoutDiscontinuity`
    セグメントを挟まずDISCONTINUITY無しで切替った回数(品質リスク指標)
  - `crossPollMapSwitches` / `...WithoutDiscontinuity`
    poll間で初期化セグメントが変わった回数(同一世代の継続中のみ計上)
  - **切替時の動作は従来どおりパート境界分割**(初期化セグメント混在の
    防止)。本機能は「既に守っている保証」の実測証拠化であり動作変更なし。
  - DISCONTINUITY無し切替を拒否しない(仕様上合法)。計数のみ。
  - FFmpeg生成2世代の実メディアでE2E検証: 2パート分割・各パートが
    自分のinitで開始・証拠計数一致(両言語・ブラウザー情報JSON同形式)。

----------------------------------------------------------
【v2.6.0 P1: 分離音声との実デコード時間相関 (avCorrelation)】
----------------------------------------------------------
  `--qaudit`(既定auto)停止時、映像トラックと音声レンディションの
  両方に実測証拠があるとき:
  - パート毎の実デコード時間(decodedDurationSec = durationTs×timebase)
    を測定し、トラック集計のドリフトをledger.json/情報JSONへ記録。
  - verdict: pass(|drift| ≤ max(映像時間×2%, 0.5s)) /
    av_drift_suspect / insufficient(両トラック証拠が揃わない)。
  - PTS原点はトラック毎に独立 — **原点差ではなく量の整合**で判定。
    同期の最終確認は2トラックmux後の再生で行う。
  - 実メディア検証: 3.0s/3.0sでpass・3.0s/2.2sでav_drift_suspect。

----------------------------------------------------------
【v2.6.0 P2: LL-HLS安全側仕様 (llhlsEvidence)】
----------------------------------------------------------
  - `EXT-X-SKIP`(差分playlist)は専用コード `HLS_LLHLS_SKIP` で拒否
    (差分は鍵計算が成り立たないため。両言語同一コードに統一)。
  - `EXT-X-PRELOAD-HINT` / `EXT-X-SERVER-CONTROL` / `EXT-X-RENDITION-REPORT`
    / `EXT-X-PART` / `EXT-X-PART-INF` は**取得せず計数証拠のみ**
    (PRELOAD-HINTの先走り取得は二重取得リスクがあるため安全側で待つ)。
  - LL-HLS配信でも差分playlistが無い(全件リスト形式)なら録画継続。
    その場合も指標タグ計数が記録され、事後分析でLL-HLS源と判別できる。
  - 仕様詳細は HLS_TRANSPORT_DESIGN.md「v2.6.0: LL-HLS安全側仕様」。

----------------------------------------------------------
【v2.6.0 P2/P0: 境界設計と実受入準備(新規文書2点)】
----------------------------------------------------------
  - COMMUNICATION_BUDGET_BOUNDARY.md — Stable PlayerとAuto Recorderの
    通信予算を独立契約のまま境界明文化(全体4通信枠の勝手な共通化をしない)。
    共有可/不可・将来統合の合意ゲートを定義。
  - ACCEPTANCE.md — 実Chrome/Firefox/Windows受入の手順(A1〜A10)・
    観察記録テンプレート(T1〜T7)・判定プロトコル。
    モック試験のPASSを受入に含めない。
  - userscript `@version`の版ずれ(2.4.0のまま)を2.6.0へ修正
    (manifestと一致させて更新判定を正しくする。実挙動は不変)。

==========================================================
◆ v2.5.0 — 2つのv2.4.0系統の統合 + 開発計画P1/P2実装
==========================================================

- **TIMELINE系統** (RPLAY_Stable_Player_v2.4.0_TIMELINE_CANDIDATE / SHA 02266adc…):
  HLS時刻タグ検証・JS/Python双コア・ビルドシステム・183試験
- **運用堅牢化系統** (rplay-stable-player-v2.4.0-bundle):
  stop-file / heartbeat / ディスクガード / segindex / webhook

----------------------------------------------------------
【P1: EXTINFモード分離 (--extinf-mode legacy|rfc)】
----------------------------------------------------------
  - 既定 `legacy`: EXTINFの無いセグメントを診断計数(missingExtinf)して
    継続。旧入力との互換性を維持(v2.4.0までの挙動)。
  - `rfc`: RFC 8216 4.3.2.3とおり、EXTINFの無いセグメントを含む
    プレイリストを丸ごと拒否(HLS_EXTINF_REQUIRED)。
  - JS/Python両コアで同一挙動。ブラウザーUIは「RFC 8216厳格」チェック
    ボックス(既定OFF)。両モード別々の試験で検証。

----------------------------------------------------------
【P1: プレイリスト世代復旧 (数値証拠つき分類)】
----------------------------------------------------------
  毎pollを証拠に基づいて分類し、情報JSON `generationRecovery` へ記録:
  - `initial`   初回
  - `progress`  通常進行(または変化なし)
  - `stale`     **旧playlistの再配信**(sequence巻き戻し+全既知path):
    エポックを進めず、重複録画しない。v2.4.0はこれを新世代と誤認して
    二重録画する潜在危険があった — 修正。
  - `reset`     正当な世代逆行(巻き戻し+未知path): 新世代として録画。
    既知pathは不変データとして重複排除。
  - `rotation`  同一番号の新path(エンコーダー再起動): v2.4.0はこれを
    「既知」と誤って黙殺する潜在危険があった — 新世代として記録。
  - `context`   playlist源の切替。
  - 推測で旧セグメントを削除しない。不変path重複排除のみで安全側。
  - 追跡再開(resume)は録画済みpath記録を引き継ぎ、復帰windowの
    同一配信を二重録画しない。
  - segindexの永続鍵を「署名なしURL+range」に変更 — 再署名されても
    同一セグメントを重複取得せず、ディスクに秘密を残さない。

----------------------------------------------------------
【P1: 実メディア品質監査 (--qaudit auto|no)】
----------------------------------------------------------
  停止時に各パートをffprobe/ffmpegで実測(既定auto = ffprobeがあれば実施):
  - ストリーム構成(codec/timebase/開始PTS/長さ/フレーム数・音声サンプル)
  - PTS/DTS単調性(減少=破損証拠、前方ジャンプ=不連続の記録)
  - 全編デコードのエラーライン(最大5件)
  - 証拠は `provenance: "decoded"`。マニフェスト宣言値(PDT/EXTINF)との
    一致だけでは品質合格扱いにしない(開発計画P1のDone基準どおり)。
  - 監査結果は ledger.json と情報JSON `qualityAudit` に記録。
    ffprobe不在時は「未監査」を明示し、成功扱いにしない。

----------------------------------------------------------
【P1: 保存確定イベント契約 (ledger.json)】
----------------------------------------------------------
  各パートの段階を実測時刻付きで `<out>/RPLAY_<ID>_ledger.json` へ記録:
    REQUESTED → FILE_WRITTEN → BROWSER_DONE → HASHED → DECODED/CONTINUITY
  - 段階を飛ばしてSUCCESS扱いにしない。SUCCESSは
    「適用可能な全段階が実測された」場合のみ
    (SUCCESS_DECODED_CONTINUOUS)。
  - CLIでは BROWSER_DONE は適用外と明示(browserStageApplicable:false)。
  - ブラウザーコアも同じ契約: RecPartSinkが実ハッシュを計算し、
    OPFS確定=FILE_WRITTEN、DL経由=BROWSER_DONE、暗号API不可環境では
    HASHEDを付けない(偽らない)。
  - webhook part/audio_partイベントにsha256を含める。

----------------------------------------------------------
【P2: URL秘密の非出力 / FIFO shadow / 復旧】
----------------------------------------------------------
  - 情報JSON・ログ・webhookから署名クエリとkey2を除去(origin+pathのみ)。
    RAM内の取得経路は変更しない(出力のみの変換)。
  - キュー登録順と取得順の一致を実測(情報JSON `queueOrder`。
    違反カウンタは常時監視)。ブラウザー側は試験で取得順を証明。
  - 孤立*.partはsha256つき台帳(orphan_ledger.json)へ報告のみ。
    昇格・削除はしない。
  - ENOSPC/EDQUOTを保存失敗コードとして区別記録。
  - heartbeat.json に saveErrors 数を含める。

----------------------------------------------------------
【運用堅牢化(運用系統から移植統合)】
----------------------------------------------------------
  - stop-file `.rplay_stop`(Docker/nohup等からの優雅停止)
  - heartbeat.json(15秒壁時計)+ `--healthcheck DIR`(0=健康/1=異常)
  - `--min-free-mb`(既定512)/ `--min-free-inodes`(既定0=無効):
    保守ガード述語guard_low(None/NaN/非数値=危険側)+二重確認。
    一時的な測定失敗で録画を打ち切らない。
  - `--segindex`(取得済みURI鍵の永続化・再起動時の重複防止)
  - `--webhook URL`(start/part/audio_part/endをJSON POST)
  - 標準入力から対象を読込(`echo URL | rplay_dl.py -`)
  - Docker/systemd運用: rplay-stable-player-deploy/ (DEPLOY.md)

----------------------------------------------------------
【CLI 使い方(主要)】
----------------------------------------------------------
  python rplay_dl.py <配信URLまたはクリエイターID> [オプション]
    --out DIR / --split-min 分 / --max-size-mb MB / --mux {auto,mp4,no}
    --audio-only / --audio-both / --token <自分のJWT> / --wait-schedule
    --refresh-token <値|env:変数名|file:パス> / --user-oid <自分のOID>(v2.7.0)
    --discover [--watch 秒] / --json
  無人運用:
    --info-json / --min-free-mb 512 / --min-free-inodes N / --segindex /
    --webhook URL / --qaudit auto
    python rplay_dl.py --healthcheck ./rplay_dl/<ID>
    録画停止: 保存先へ .rplay_stop を作成(Docker/nohup等から優雅停止)
  検証モード:
    --extinf-mode {legacy,rfc} / --qaudit {auto,no}
  Docker/systemd: rplay-stable-player-deploy/ (DEPLOY.md) 参照

----------------------------------------------------------
【付属ゲーム — Web Game #18「See-Saw Resonance」v1.0】
----------------------------------------------------------
  運用系統バンドルからバイト同一で継承。
  games/web_game_18/index.html(単一HTML・オフライン動作)。

----------------------------------------------------------
【v2.7.0 検証記録】
----------------------------------------------------------
  Node.js: **160 PASS**(既存154 + v2.7.0新規6)
  Python: **102 PASS**(既存76 + v2.7.0新規26)
  合計 **262 PASS**。再ビルド5コア同一ハッシュ・クリーン展開再検証済み。

  v2.7.0新規試験の主なシナリオ:
  - 秘密供給3種(値直接/env:/file:)の解析と供給源種別の記録
  - leeway(300秒)前更新ループ・再試行3回・クールダウン連打防止
  - 401分類マトリクス(4分類・切替・再読込再試行)
  - E2E: refresh-token単独フロー/--token優先401自動切替/auth_failed通知
  - canary判定3種の相互言語比較(node実行・同一結果)
  - webhook: level/ts契約・429 Retry-After退避実測・新イベント4種
  - MP4メタデータ: ffprobe実測(未知値は埋め込まれない)
  - authEvidence鍵構造がPython AuthStoreとJS RspAuthで完全一致
  - saveInfoJsonへのauthEvidence/canaryEvidence統合(未供給時は非出力)

  v2.6.0の230試験(fMP4 MAP・avCorrelation・LL-HLS安全側・証拠ブロック・
  E2E実メディア)とv2.5.0の全試験はすべて維持・再実行PASS。

----------------------------------------------------------
【v2.6.0 検証記録】
----------------------------------------------------------
  Node.js: **154 PASS**(既存148 + v2.6.0新規6)
  Python: **76 PASS**(既存64 + v2.6.0新規12)
  合計 **230 PASS**。再ビルド5コア同一ハッシュ・クリーン展開再検証済み。

  v2.6.0新規試験の主なシナリオ:
  - fMP4 MAP証拠: 宣言/切替/no-disc計数・同一再宣言=非切替(両言語)
  - poll間切替(crossPollMapSwitches)の累積(両言語・相互比較)
  - FFmpeg実メディア2世代のMAP切替E2E: 2パート・init分離・audit pass
  - DISCONTINUITY無し切替: 計数のみで拒否しない
  - LL-HLS: SKIP専用拒否(両言語)・指標タグ計数・PRELOAD-HINT非取得
  - avCorrelation: 実メディアpass/suspect・片側証拠insufficient
  - 情報JSON証拠ブロック: generationRecovery/fmp4Evidence/llhlsEvidence
    (ブラウザーVM・URL秘匿との共存)

  v2.5.0の212試験(EXTINF/世代復旧/ledger/qaudit/segindex/heartbeat/
  stop-file/webhook/URL秘匿/FIFO/孤立part/ENOSPC/stdin/相互比較)は
  すべて維持・再実行PASS。

----------------------------------------------------------
【既知の制約 / 判定】
----------------------------------------------------------
  - hardlink非対応FSでは非上書き確定が安全側で失敗する。
  - サイズ/sha256一致は「書込経路の完全性」の証明であり、
    デコード成功とは別物 — DECODED段階は--qauditの実測による。
  - 実配信RPLAY・実Chrome/Firefox拡張インストール・Windows・
    長時間耐久は未受入(ACCEPTANCE.md A1〜A10の実施が次課題)。
    **判定は CANDIDATE / NO_GO のまま**。
  - 暗号化HLS・LL-HLS差分playlist(EXT-X-SKIP)・MAP暗黙offsetは
    引き続き安全側に拒否。

【注意】
個人利用を想定したツールです。認証の回避機能はありません。
詳細は GUIDE.txt(拡張GUIDE.txt) / rplay-stable-player-deploy/DEPLOY.md /
ACCEPTANCE.md / COMMUNICATION_BUDGET_BOUNDARY.md を参照してください。
