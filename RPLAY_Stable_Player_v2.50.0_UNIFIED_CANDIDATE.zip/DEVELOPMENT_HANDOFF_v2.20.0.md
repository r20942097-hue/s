# v2.20.0 継続資料

基準は同じチャットのv2.19.0 UNIFIED。旧版は保持し、INPUTS_v2.20.0.jsonに元ZIPのSHA-256を記録します。

src/mp4_codec_core.jsを新設。MP4初期化情報のsample entry/esds/ASC/avcC/tkhdと入力設定を照合し、限定SPSパーサーでcropping込みの寸法を取得します。src/mp4_convert_core.jsは4096バイト上限の単一SPS/PPSを取得し、入力内変化を拒否。build.pyが新モジュールをroot/Chrome/Firefoxへコピーし、HTMLはcoreより先にloadします。CJSも相対requireで同じモジュールを使用します。

Firefox version_name警告への対応を同時反映。Firefox用からキーを削除、Chrome用は維持し、旧版の両ブラウザ共通version_nameテストをブラウザ別要件に変更。権限は追加していません。

新規test_v2200_codecs.cjs 32件、test_v2200_manifest.cjs 2件。534件PASS。24派生コピーと5録画コア、再ビルド一致も検証。codec異常再現ツールはscripts/reproduce_codec_metadata.cjs。BASELINE引数は既存v2.19.0展開先です。

## 次工程

1. 利用者が実機確認を行う段階で、修正版Firefox manifestの警告、録画、実OS保存・変換を観察。実機待ちだけでローカル開発全体を停止しない。
2. Worker移譲と、File System Access API非対応時のUI/保存方式を検討。現在のFirefox版収録とMP4保存API対応を混同しない。
3. 複数SPS/PPS・PPS参照関係・VUI等は未実装。単一parameter set拒否を緩める前に設計/反証が必要。
4. PES跨ぎAAC、録画中MP4出力、別音声合成は別工程。既存の保存/復旧契約を維持。
5. 数時間/2GiB、長期同期、複雑なPSI pointer等の反証を継続。

CANDIDATE_NO_GO。SPSの全構文や映像全内容の保存を保証しません。実Firefox/実RPLAY/Windows/長時間は改修後未検証です。
