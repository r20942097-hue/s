(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.RspMp4Codecs=api;})(globalThis,function(){
 'use strict';
 const fail=code=>{throw Error(code);};
 function boxes(data,start=0,end=data.length){const view=new DataView(data.buffer,data.byteOffset,data.byteLength),out=[];for(let p=start;p<end;){if(p+8>end)fail('MP4_CODEC_BOX');const size=view.getUint32(p);if(size<8||p+size>end)fail('MP4_CODEC_BOX');out.push({type:String.fromCharCode(...data.subarray(p+4,p+8)),start:p+8,end:p+size});p+=size;}return out;}
 function one(items,type){const found=items.filter(b=>b.type===type);if(found.length!==1)fail('MP4_CODEC_CARDINALITY');return found[0];}
 function hex(data){return Array.from(data,b=>b.toString(16).padStart(2,'0')).join('');}
 function spsGeometry(nal){
  if(nal.length<5||nal.length>4096||(nal[0]&0x9f)!==7)fail('AVC_SPS_INVALID');
  const rbsp=[];let zeros=0;
  for(let i=1;i<nal.length;i++){const b=nal[i];if(b===3&&zeros>=2){if(i+1>=nal.length||nal[i+1]>3)fail('AVC_SPS_ESCAPE');zeros=0;continue;}rbsp.push(b);zeros=b===0?zeros+1:0;}
  let pos=0;function bits(n){if(pos+n>rbsp.length*8)fail('AVC_SPS_TRUNCATED');let v=0;for(let i=0;i<n;i++,pos++)v=v*2+((rbsp[pos>>3]>>(7-(pos&7)))&1);return v;}
  function ue(){let n=0;while(bits(1)===0){if(++n>24)fail('AVC_SPS_GOLOMB_LIMIT');}return 2**n-1+(n?bits(n):0);}
  function se(){const v=ue();return v&1?(v+1)/2:-v/2;}
  const profile=bits(8),compatibility=bits(8),level=bits(8);ue();let chroma=1;
  if(profile===100){chroma=ue();if(chroma>1)fail('AVC_SPS_CHROMA_UNSUPPORTED');if(ue()!==0||ue()!==0)fail('AVC_SPS_DEPTH_UNSUPPORTED');bits(1);if(bits(1)){for(let i=0;i<8;i++)if(bits(1)){let last=8,next=8;for(let j=0;j<(i<6?16:64);j++){if(next)next=((last+se())%256+256)%256;last=next||last;}}}}
  else if(![66,77,88].includes(profile))fail('AVC_SPS_PROFILE_UNSUPPORTED');
  if(ue()>12)fail('AVC_SPS_INVALID');const poc=ue();if(poc===0){if(ue()>12)fail('AVC_SPS_INVALID');}else if(poc===1){bits(1);se();se();const n=ue();if(n>256)fail('AVC_SPS_LIMIT');for(let i=0;i<n;i++)se();}else if(poc!==2)fail('AVC_SPS_INVALID');
  ue();bits(1);const widthMbs=ue()+1,heightMaps=ue()+1,frameOnly=bits(1);if(!frameOnly)bits(1);bits(1);
  let left=0,right=0,top=0,bottom=0;if(bits(1)){left=ue();right=ue();top=ue();bottom=ue();}
  const cropX=chroma?2:1,cropY=(chroma?2:1)*(2-frameOnly),width=widthMbs*16-(left+right)*cropX,height=heightMaps*16*(2-frameOnly)-(top+bottom)*cropY;
  if(!Number.isSafeInteger(width)||!Number.isSafeInteger(height)||width<1||height<1||width>65535||height>65535)fail('AVC_SPS_DIMENSIONS');
  return {width,height,profile,compatibility,level};
 }
 function descriptor(data,at,end){if(at>=end)fail('MP4_ESDS_DESCRIPTOR');const tag=data[at++];let length=0,done=false;for(let i=0;i<4;i++){if(at>=end)fail('MP4_ESDS_DESCRIPTOR');const b=data[at++];length=length*128+(b&127);if(!(b&128)){done=true;break;}}if(!done||at+length>end)fail('MP4_ESDS_DESCRIPTOR');return {tag,start:at,end:at+length};}
 function audioConfig(data,entry,source){
  const view=new DataView(data.buffer,data.byteOffset,data.byteLength);if(entry.type!=='mp4a'||entry.end-entry.start<28)fail('MP4_AUDIO_ENTRY');
  if(view.getUint16(entry.start+6)!==1||view.getUint32(entry.start+8)!==0||view.getUint32(entry.start+12)!==0||view.getUint16(entry.start+18)!==16)fail('MP4_AUDIO_ENTRY');
  const channels=view.getUint16(entry.start+16),rate=view.getUint32(entry.start+24)/65536;
  const esds=one(boxes(data,entry.start+28,entry.end),'esds');if(esds.start+4>esds.end||view.getUint32(esds.start)!==0)fail('MP4_ESDS_DESCRIPTOR');
  const es=descriptor(data,esds.start+4,esds.end);if(es.tag!==3||es.end!==esds.end||es.start+3>es.end||data[es.start+2]!==0)fail('MP4_ESDS_DESCRIPTOR');
  const decoder=descriptor(data,es.start+3,es.end);if(decoder.tag!==4||decoder.start+13>decoder.end||data[decoder.start]!==0x40||data[decoder.start+1]!==0x15)fail('MP4_ESDS_DECODER');
  const asc=descriptor(data,decoder.start+13,decoder.end);if(asc.tag!==5||asc.end!==decoder.end||asc.end-asc.start!==2)fail('MP4_ASC_UNSUPPORTED');
  const sl=descriptor(data,decoder.end,es.end);if(sl.tag!==6||sl.end!==es.end||sl.end-sl.start!==1||data[sl.start]!==2)fail('MP4_ESDS_DESCRIPTOR');
  const a=data[asc.start],b=data[asc.start+1],objectType=a>>3,sampleIndex=((a&7)<<1)|(b>>7),ascChannels=(b>>3)&15;
  const cfg=source.aacConfig&&source.aacConfig.split(':').map(Number),rates=[96000,88200,64000,48000,44100,32000,24000,22050,16000,12000,11025,8000,7350];
  if(!cfg||(b&7)||objectType!==cfg[0]+1||sampleIndex!==cfg[1]||ascChannels!==cfg[2]||channels!==cfg[2]||rate!==rates[cfg[1]])fail('MP4_AAC_CONFIG_MISMATCH');
  return {channels,sampleRate:rate,objectType,sampleIndex};
 }
 function videoConfig(data,entry,tkhd,source){
  const view=new DataView(data.buffer,data.byteOffset,data.byteLength);if(entry.type!=='avc1'||entry.end-entry.start<78||view.getUint16(entry.start+6)!==1)fail('MP4_VIDEO_ENTRY');
  const avcc=one(boxes(data,entry.start+78,entry.end),'avcC');if(avcc.end-avcc.start<7||data[avcc.start]!==1||(data[avcc.start+4]&3)!==3||(data[avcc.start+5]&31)!==1)fail('MP4_AVCC_UNSUPPORTED');
  let at=avcc.start+6;function parameter(type){if(at+2>avcc.end)fail('MP4_AVCC_LENGTH');const n=view.getUint16(at);at+=2;if(!n||n>4096||at+n>avcc.end||(data[at]&0x9f)!==type)fail('MP4_AVCC_LENGTH');const bytes=data.subarray(at,at+n);at+=n;return bytes;}
  const sps=parameter(7);if(at>=avcc.end||data[at++]!==1)fail('MP4_AVCC_UNSUPPORTED');const pps=parameter(8);if(at!==avcc.end)fail('MP4_AVCC_UNSUPPORTED');
  if(!source.avcParameterSets||hex(sps)!==source.avcParameterSets.sps||hex(pps)!==source.avcParameterSets.pps)fail('MP4_AVC_PARAMETER_SET_MISMATCH');
  const geometry=spsGeometry(sps);if(data[avcc.start+1]!==geometry.profile||data[avcc.start+2]!==geometry.compatibility||data[avcc.start+3]!==geometry.level)fail('MP4_AVCC_PROFILE_MISMATCH');
  const width=view.getUint16(entry.start+24),height=view.getUint16(entry.start+26);if(tkhd.end-tkhd.start<84||width!==geometry.width||height!==geometry.height||view.getUint32(tkhd.end-8)!==width*65536||view.getUint32(tkhd.end-4)!==height*65536)fail('MP4_AVC_DIMENSIONS_MISMATCH');
  return {width,height,profile:geometry.profile,level:geometry.level,nalLengthBytes:4,parameterSetsMatched:true};
 }
 function auditInit(data,source){
  const top=boxes(data),moov=one(top,'moov'),view=new DataView(data.buffer,data.byteOffset,data.byteLength),tracks=[];
  if(top.length!==2||top[0].type!=='ftyp'||top[1].type!=='moov')fail('MP4_INIT_LAYOUT');
  for(const trak of boxes(data,moov.start,moov.end).filter(b=>b.type==='trak')){
   const tk=boxes(data,trak.start,trak.end),tkhd=one(tk,'tkhd'),mdia=one(tk,'mdia'),md=boxes(data,mdia.start,mdia.end),hdlr=one(md,'hdlr'),minf=one(md,'minf');if(hdlr.end-hdlr.start<12)fail('MP4_CODEC_BOX');
   const kind=String.fromCharCode(...data.subarray(hdlr.start+8,hdlr.start+12)),stbl=one(boxes(data,minf.start,minf.end),'stbl'),stsd=one(boxes(data,stbl.start,stbl.end),'stsd');
   if(stsd.end-stsd.start<8||view.getUint32(stsd.start)!==0||view.getUint32(stsd.start+4)!==1)fail('MP4_STSD_UNSUPPORTED');const entries=boxes(data,stsd.start+8,stsd.end);if(entries.length!==1)fail('MP4_STSD_UNSUPPORTED');
   tracks.push({kind,...(kind==='soun'?audioConfig(data,entries[0],source):kind==='vide'?videoConfig(data,entries[0],tkhd,source):fail('MP4_CODEC_KIND'))});
  }
  if(tracks.filter(t=>t.kind==='vide').length!==1||tracks.filter(t=>t.kind==='soun').length!==(source.aacConfig?1:0))fail('MP4_CODEC_TRACKS');
  return {policy:'bundled_mux_6_3_codec_contract',tracks,inputSettingsMatched:true,spsGeometryParsed:true,fullDecode:false};
 }
 return {auditInit,spsGeometry};
});
