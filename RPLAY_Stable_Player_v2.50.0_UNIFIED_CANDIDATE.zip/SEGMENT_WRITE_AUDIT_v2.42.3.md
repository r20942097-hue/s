# v2.42.3 Browser HLS Segment Write-Acceptance Audit

Status: **CANDIDATE / NO_GO** (2026-10-27 JST)
Base: v2.42.2 DASH Cross-Site Candidate. Previous ZIP untouched.

## Scope and rationale

Prior diagnostics only measured manifest-derived gaps and the recorder's aggregate segTotal/segFails, which could be misread as proof of persisted media. The new **write-acceptance** audit links discovered segment descriptors to `HLS.append()` and retains numerical outcomes independently for video and selected audio renditions.

- `src/hls_transport.js`: bounded, ephemeral `writeEvidence`, `noteTerminal`, `clearWriteEvidence`; record queue additions, manifest missing and declared gaps, accepted media/init bytes, terminal failures, pending entries, sequence discontinuities and suspected accepted-sequence holes. The tail holds at most 96 event descriptors `{epoch,discontinuity,sequence,status,mediaBytes?}`. No segment URL, signed query, headers or Cookie content is included.
- `src/player.user.js`: note terminal drop only after actual 404/410/auth/validation rejection or retries exhausted; new `segmentWriteEvidence` appears in `saveInfoJson()` and `audioRendition.segmentWriteEvidence`. Standby/URL refresh leaves counters in the same recorder instance, while explicit `start` or `resumeFromCrash` begins a new audit. A crashed session does not pretend to have a complete audit of the prior process lifetime.
- Generated `rplay-stable-player.user.js`, `content.js` (both), `offscreen.js` (both), `hls_transport.js` (root and both extensions) are rebuilt from `src` with `scripts/build.py`.
- Manifest versions are `2.42.3`; Chromium includes `version_name`, Firefox excludes it. Existing host permissions unchanged. Cross-site DASH remains diagnostic-only; it is **not** a DASH media recorder.

## Evidence contract (important)

`provenance="writer_acceptance_not_file_commit"` means the `pushData()` promise finished, not that a user file was committed/flushed or decoded. The report explicitly sets `fileCommitted=false, avDecoded=false`. The difference between `queued` and `accepted+terminal` is `unresolved` and can include a stopped/cancelled queue or a pending save, not a definite media gap. `suspectedManifestMissing` and `suspectedAcceptedSequenceGaps` are heuristic, not ground-truth loss or A/V timestamp continuity. Discontinuity and generation boundaries are excluded from accepted-sequence gap estimates. `tail` is a bounded sample; total counters remain cumulative per recorder instance.

Failure to append bytes does not increment `accepted`. When `pushData` writes init bytes then media append fails, init bytes may be partially accepted and the new media segment is not recorded as accepted. This audit does not replace part sink hash/receipt verification or full demux/decode quality checks.

## Validation and limits

- Node.js new audit test suite: 10 cases, including audio/video, 404 recovery, terminal 410, write failure, pending entries, discontinuity resets, fMP4 init, signed URL non-disclosure, and bounded tail.
- Historical Node.js: 637 existing cases; combined goal: 647 (rerun with `node --test tests/test_*.cjs`). Python 165 existing regression tests, CLI source unchanged.
- Not tested against logged-in Nico, Niconico Live, Twitch, YouTube, RPLAY, real Firefox/Floorp extension installation, Windows, long-duration live file decode or site-specific session protocol.

## Next gates

1. In isolated Firefox/Floorp and Chromium profiles, inspect actual HLS requests; validate `Referer`, `Origin`, `User-Agent`, Cookie/Authorization behavior (values must stay out of reports) and renderer/extension lifecycle.
2. Run permitted public/owned Nico Live HLS sample recording through browser; compare `segmentWriteEvidence` to real part receipts and per-part hashes, then `ffprobe`/decode/timestamp checks.
3. Implement a separate persisted, versioned segment commit journal correlated with output file hashes and writer errors, with bounded storage, no signed URLs, and explicit recoverability semantics. Never equate manifest seen with saved media.
4. Consider site adapters only for documented, permitted session mechanisms; DRM/protected media acquisition remains out of scope.
