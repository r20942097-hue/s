# v2.18.0 QA

2026-10-26 JST / CANDIDATE_NO_GO。

**476件PASS / 0 FAIL**。Node.js 314、Python 162。前回451件から25件追加。5つの録画コア同一・再ビルドランタイム一致・MP4/復旧等7モジュールの21派生コピー一致・manifest/JS構文検査PASS。

## 再現した旧版の欠損見逃し

4秒H.264/AACを生成し、末尾音声TSパケット1つだけを取り除きました。TSの188バイト整列・CC構造検査は通ります。v2.17.0はconfirmed=trueを返しましたが、元の189 AACフレームに対して出力は178。v2.18.0はTS_PES_TRUNCATEDで保存前に拒否します。欠損の修復や元データ回復を行ったものではありません。

## 新規反証

PES prefix/長さ/ヘッダー切断/PTSマーカー、ADTS sync/長さ/構成/複数block/PES境界、分割TSヘッダー、NAL forbidden bit/開始コード/末尾ヘッダー等を検査。出力muxへ音声sample_count欠損を注入し、両convert APIで保存確定前に拒否することを確認しました。

## 合成メディア実測

| 入力条件 | 入力bytes | 出力bytes | AACフレーム | GOPチャンク | AV開始差の変化 秒 |
|---|---:|---:|---:|---:|---:|
| 120秒 / 44100Hz / 2ch | 6,897,532 | 5,954,498 | 5,169 | 12 | -0.00002100 |
| 120秒 / 48000Hz / 1ch | 5,948,884 | 5,081,425 | 5,626 | 10 | 0.00000000 |
| 50秒 / 48000Hz / 2ch | 77,606,776 | 75,563,373 | 2,345 | 50 | 0.00000000 |

全条件で入力/出力ADTSバイト一致・映像framemd5一致・FFmpeg -xerrorデコードPASS・音声サンプルレート/チャネル保持。開始差の変化は2音声サンプル未満。Bフレームの並べ替え遅延を保つため、最初の2条件の表示開始は約0.057秒です。

50秒条件はFFmpeg libx264 12Mbps CBR（nal-hrd=cbr）の320x180/25fps。前版のTS nullパディング容量試験に加え、実際の符号化メディア77.6MBを入力と出力の実ディスクファイルで扱いました。読込みは全条件1MiB以下。ピークRAMの測定ではありません。CBRのfiller NALを含む合成素材であり、任意の高精細実配信の試験ではありません。

## 証拠と未実施

evidence/v218-current/VALIDATION.json、node.log、python.log、MEDIA_MATRIX.json、AAC_TRUNCATION_BEFORE_AFTER.json。旧evidenceは各記載版の履歴。

実RPLAY・Windows・実OSファイル選択と保存・実拡張導入・数時間・2GiBは未検証。File System Access APIはモックで、ディスク処理はNodeのテスト用アダプターです。H.264全デコード/AAC CRCを本番コンバーターが実施するわけではありません。前版の実ブラウザ記録を今回の実績には加算していません。
