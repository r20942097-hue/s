# VDH・HLS取得の調査と開発反映

確認日: 2026-10-26 JST。資料/公開READMEの調査であり、現行VDHの内部ソース全体を解析したという意味ではありません。ソースをコピーしていません。

## 星について

公式Basic Usageのサンプル画像には、動画サムネイルの下に黄色い星が見えます。ただし本文は星の意味を説明しておらず、利用者の画面の星と同じ位置/版かは未確認です。星だけでpremium、DRM、画質推奨、お気に入りと断定しません。
公式のNon-premium restrictionsは、単一ファイルをnon-advanced、HLS/m3u8/DASH/MPDのように再構成する方式をadvancedと区別しています。この区別と星との対応は直接の根拠が未取得。星にカーソルを置いた説明、表示位置、VDH版が分かれば追加照合できます。
https://help.downloadhelper.net/article/4-basic-usage
https://help.downloadhelper.net/article/29-non-premium-restrictions

2026-07-24更新の公式説明では通常取得は無料無制限、advancedは初回3回、その後2時間ごと1回の無料枠。これはVDH製品側の制限であり、HLSプロトコルそのものの制限ではありません。
旧CoAppの公開READMEはアーカイブされ、v10はCompanionを不要と明示。古いCoApp前提の解説を現行仕様に流用しません。
https://github.com/aclap-dev/vdhcoapp

## HLSの取得手順

1. URL/MIME/通信で候補を見つける（検出だけでは再生・保存可否を証明しない）。
2. masterなら画質variantと別音声/字幕renditionを選択する。
3. media playlistからsequence、duration、URI、Range、MAP、discontinuityを読む。
4. VODは有限一覧、LIVEは窓を更新して新しいsegmentを取り込む。古い窓が消えた部分は取り戻せない場合がある。
5. 正規のアクセス条件でsegment/初期化データを取得。認証・暗号方式を区別し、HTTP失敗/不完全本文を拒否する。
6. 検証したTS/fMP4を順番と形式境界に従って保存し、必要ならMP4へremuxする。TSの拡張子を変えるだけでは変換にならない。
7. 取得完了、書込完了、ダウンロード完了、hash、デコードは別々に確認する。

このリリースのHLS診断へ上記の工程表示を追加。master/media、LIVE/VOD、Range/MAP、暗号化、LL-HLSの必要事項を表示。診断画面は通信/鍵取得/保存を行わず、生成したFFmpegコマンドも自動実行しない。

## 他の参照先と採否

|参照元|確認した設計|現行への判断|
|---|---|---|
|puemos/hls-downloader|画質/音声選択、disk-backed保存とffmpeg.wasm mux（MIT）|メモリ全量保持を避ける設計と選択UIを優先。今回は新mux導入なし|
|cssnr/hls-video-downloader|Native FFmpegを別clientへ委譲、別音声が別DLになる制限（GPL-3.0）|ブラウザと外部処理を分離する比較対象。native実行は今回追加しない|
|yt-dlp|fragmentごとのretry、retry-sleep|既存の上限/中止/429配慮を維持。無制限再試行は採用しない|
|N_m3u8DL-RE|segment数検査、取得/結合/mux分離、元データ保持|取得と保存検証を分ける工程説明へ反映。別音声自動muxは別工程|
|Streamlink|サービス別pluginと共通stream処理（BSD-2-Clause）|RPLAY adapterと汎用engineの分離方針を継続|
|cat-catch|HLS候補/診断・各種メディア処理の公開実装|既存の由来記録を維持。全サイトcaptureは権限/状態寿命/上限設計後|
|hls.js|再生用HLS解析・音声/quality処理|再生成功と取得/保存成功を分ける。vendor更新の即時移植はしない|
|FFmpeg|container/concat/fragmented MP4の公式仕様|汎用保存コマンドと独立decode試験を継続|

https://github.com/puemos/hls-downloader
https://github.com/cssnr/hls-video-downloader
https://github.com/yt-dlp/yt-dlp
https://github.com/nilaoda/N_m3u8DL-RE
https://github.com/streamlink/streamlink
https://github.com/xifangczy/cat-catch
https://github.com/video-dev/hls.js
https://ffmpeg.org/ffmpeg-formats.html

## 未実装/未確認

VDHの星の確定意味、任意サイトのブラウザ内録画、汎用capture、別音声mux、DRM、Windows/実サービス/2GiB/長時間/preview進行。今回、VDHの料金制限を書き換えたり回避する改造は実施していません。
