/* Read-only File inputs and private, fresh conversion staging. No source handles are written. */
(function(root){
'use strict';
const AREA='rsp_mp4_v222',MEMORY_INPUT_LIMIT=64*1048576,MEMORY_OUTPUT_LIMIT=128*1048576,ID=/^[a-f0-9]{32}$/;
const fail=code=>{throw Error(code);};
function fileInputs(files){
 const seen=new Set();return files.map(file=>{if(!file||typeof file.slice!=='function'||!Number.isSafeInteger(file.size)||file.size<1)fail('BAD_INPUT_FILE');if(seen.has(file))fail('DUPLICATE_INPUT');seen.add(file);return {getFile:async()=>file,isSameEntry:async other=>other===file};});
}
async function openWriter(handle,limit=Number.MAX_SAFE_INTEGER){
 if(typeof handle.createWritable==='function'){
  const writer=await handle.createWritable();let count=0;
  return {async write(data){if(!(data instanceof Uint8Array))fail('BAD_WRITE');if(count+data.byteLength>limit)fail('OUTPUT_LIMIT');await writer.write(data);count+=data.byteLength;},close:()=>writer.close(),abort:()=>writer.abort()};
 }
 if(typeof handle.createSyncAccessHandle!=='function')fail('OPFS_WRITER_UNSUPPORTED');
 const writer=await handle.createSyncAccessHandle();let position=0,ended=false;
 const release=()=>{if(!ended){ended=true;writer.close();}};
 try{writer.truncate(0);}catch(e){release();throw e;}
 return {async write(data){if(ended)fail('WRITER_CLOSED');if(!(data instanceof Uint8Array))fail('BAD_WRITE');if(position+data.byteLength>limit)fail('OUTPUT_LIMIT');let at=0;while(at<data.length){const n=writer.write(data.subarray(at),{at:position});if(!Number.isSafeInteger(n)||n<=0||n>data.length-at)fail('OPFS_SHORT_WRITE');at+=n;position+=n;}},async close(){try{writer.flush();}finally{release();}},async abort(){release();}};
}
function memoryStage(){
 let output=null,chunks=[],size=0,opened=false;
 const stage={mode:'memory',id:null,destination:{isSameEntry:async()=>false,async createWritable(){if(opened)fail('WRITER_REOPEN');opened=true;return {async write(data){if(!(data instanceof Uint8Array))fail('BAD_WRITE');if(size+data.length>MEMORY_OUTPUT_LIMIT)fail('MEMORY_OUTPUT_LIMIT');chunks.push(data.slice());size+=data.length;},async close(){output=new Blob(chunks,{type:'video/mp4'});chunks=[];},async abort(){chunks=[];output=null;size=0;}};},async getFile(){if(!output)fail('OUTPUT_NOT_CLOSED');return output;}},async finalize(result){return receipt(null,'memory',result);},async destroy(){chunks=[];output=null;}};
 return stage;
}
function receipt(id,mode,result){
 if(!result||result.confirmed!==true||!Number.isSafeInteger(result.bytes)||result.bytes<1||!/^[a-f0-9]{64}$/.test(result.sha256))fail('BAD_RECEIPT');
 return {schema:1,id,mode,bytes:result.bytes,sha256:result.sha256,createdAt:new Date().toISOString(),audio:!!result.audio,aacFrames:result.mediaIntegrityEvidence&&result.mediaIntegrityEvidence.aacFrames||0,aacPayloadHashVerified:!!(result.mediaIntegrityEvidence&&result.mediaIntegrityEvidence.aacPayloadHashVerified),decoded:false};
}
function validateReceipt(r,id){if(!r||r.schema!==1||r.id!==id||!ID.test(id)||r.mode!=='opfs'||!Number.isSafeInteger(r.bytes)||r.bytes<1||!/^[a-f0-9]{64}$/.test(r.sha256)||typeof r.createdAt!=='string'||!Number.isFinite(Date.parse(r.createdAt))||typeof r.audio!=='boolean'||!Number.isSafeInteger(r.aacFrames)||r.aacFrames<0||typeof r.aacPayloadHashVerified!=='boolean')fail('INVALID_STAGED_RECEIPT');return r;}
async function acquireLease(id,locks=globalThis.navigator&&navigator.locks){
 if(!locks||typeof locks.request!=='function')return async()=>{};
 return new Promise((resolve,reject)=>{let unlock;const hold=new Promise(r=>unlock=r);const pending=locks.request('rsp-mp4-job-'+id,{mode:'exclusive',ifAvailable:true},async lock=>{if(!lock){reject(Error('STAGED_JOB_BUSY'));return;}resolve(async()=>{unlock();await pending;});await hold;});pending.catch(reject);});
}
async function createStage({storage=globalThis.navigator&&navigator.storage,id,inputBytes=0,forceMemory=false,locks=globalThis.navigator&&navigator.locks}={}){
 if(forceMemory||!storage||typeof storage.getDirectory!=='function'){if(inputBytes>MEMORY_INPUT_LIMIT)fail('MEMORY_INPUT_LIMIT_64_MIB');return memoryStage();}
 if(!ID.test(id||''))fail('BAD_JOB_ID');
 const root=await storage.getDirectory(),area=await root.getDirectoryHandle(AREA,{create:true});
 try{await area.getDirectoryHandle(id);fail('JOB_ALREADY_EXISTS');}catch(e){if(e.message==='JOB_ALREADY_EXISTS'||e.name!=='NotFoundError')throw e;}
 const release=await acquireLease(id,locks);
 let dir,stage;
 try{
  dir=await area.getDirectoryHandle(id,{create:true});
  const file=await dir.getFileHandle('output.mp4',{create:true});let opened=false;
  stage={id,mode:'opfs',destination:{isSameEntry:async()=>false,async createWritable(){if(opened)fail('WRITER_REOPEN');opened=true;return openWriter(file);},getFile:()=>file.getFile()},
   async finalize(result){const r=receipt(id,'opfs',result),data=new TextEncoder().encode(JSON.stringify(r));const meta=await dir.getFileHandle('receipt.json',{create:true}),w=await openWriter(meta,65536);try{await w.write(data);await w.close();}catch(e){try{await w.abort();}catch(ignore){}throw e;}await release();return r;},
   async destroy(){try{await area.removeEntry(id,{recursive:true});}finally{await release();}}};
  return stage;
 }catch(e){try{await area.removeEntry(id,{recursive:true});}catch(ignore){}await release();throw e;}
}
async function getArea(storage){const root=await storage.getDirectory();return root.getDirectoryHandle(AREA);}
async function readReceipt(dir,id){const meta=await (await dir.getFileHandle('receipt.json')).getFile();if(meta.size>65536)fail('INVALID_STAGED_RECEIPT');return validateReceipt(JSON.parse(await meta.text()),id);}
async function listStages(storage){if(!storage||typeof storage.getDirectory!=='function')return {jobs:[],invalid:0,incomplete:[]};let area;try{area=await getArea(storage);}catch(e){if(e.name==='NotFoundError')return {jobs:[],invalid:0,incomplete:[]};throw e;}const jobs=[],incomplete=[];let invalid=0,scanned=0;for await(const [id,dir]of area.entries()){if(++scanned>200)break;if(!ID.test(id)||dir.kind!=='directory')continue;try{jobs.push(await readReceipt(dir,id));}catch(e){invalid++;if(incomplete.length<100)incomplete.push(id);}if(jobs.length>=100)break;}jobs.sort((a,b)=>b.createdAt.localeCompare(a.createdAt));return {jobs,invalid,incomplete};}
async function recoverStage(storage,id,hashing,onProgress=()=>{},locks=globalThis.navigator&&navigator.locks){if(!ID.test(id||''))fail('BAD_JOB_ID');const release=await acquireLease(id,locks);try{const area=await getArea(storage),dir=await area.getDirectoryHandle(id),r=await readReceipt(dir,id),file=await (await dir.getFileHandle('output.mp4')).getFile();if(file.size!==r.bytes)fail('STAGED_SIZE_MISMATCH');onProgress({phase:'verify',bytes:file.size});if(await hashing.hashBlob(file)!==r.sha256)fail('STAGED_HASH_MISMATCH');return {receipt:r,file};}finally{await release();}}
async function discardStage(storage,id,locks=globalThis.navigator&&navigator.locks){if(!ID.test(id||''))fail('BAD_JOB_ID');const release=await acquireLease(id,locks);try{const area=await getArea(storage);await area.removeEntry(id,{recursive:true});}finally{await release();}}
const value={fileInputs,openWriter,createStage,listStages,recoverStage,discardStage,validateReceipt,MEMORY_INPUT_LIMIT,MEMORY_OUTPUT_LIMIT};if(typeof module!=='undefined')module.exports=value;root.RspMp4BrowserIO=value;
})(typeof globalThis==='undefined'?this:globalThis);
