# RPLAY Stable Player v2.20.0 UNIFIED CANDIDATE

Firefox用manifestからversion_nameを削除し、利用者から報告された警告の原因キーを除去しました。Chrome用はversion_nameを維持し、ブラウザ別の検査で再混入を防止します。

MP4変換には、AACコーデック設定と入力ADTSの照合、入力SPS/PPSとavcCの照合、SPS由来寸法とavc1/tkhdの照合を追加しました。音声データhash、サンプル表/mdat監査、録画・復旧・CLIは継承しています。

状態: **CANDIDATE / NO_GO**。改修版の実Firefox再読み込み・実RPLAY・Windows・実OSファイル保存・数時間/2GiB運用は未検証です。

## Firefoxで更新する

1. ZIPを新しいフォルダーへ展開します。
2. Firefox用のrplay-stable-player-extension-firefox/manifest.jsonを指定して、拡張を読み込み直してください。
3. 表示バージョン2.20.0と、報告されたversion_name警告の有無を確認する手順です。こちらでの実Firefox確認は未実施です。

manifestのversionは維持しています。Chrome用はrplay-stable-player-extensionです。詳細は[FIREFOX_MANIFEST_FIX_v2.20.0.md](FIREFOX_MANIFEST_FIX_v2.20.0.md)。

## MP4変換

録画完了後、File System Access API対応ブラウザでmp4_convert.htmlを開き、TS選択→表示順確認→別のMP4保存先を指定します。元TSは保持します。1入力2GiBまで、最大4096本。H.264と同じTS内のAACを対象とし、未対応構造は明示拒否します。

Firefox拡張の収録は、このMP4ファイル保存APIのFirefox対応を保証するものではありません。録画中MP4直接出力・別音声同期合成は未実装です。

## 検証

**534件PASS / 0 FAIL**（Node.js 372 + Python 162）。新規34件（codec 32 + manifest/配布2）。Baseline/Main/Highの寸法をffprobeと独立比較。120秒の44.1kHzステレオ/48kHzモノラル、77.6MB・50秒・12Mbpsの合成素材で音声/映像一致・デコードを確認しています。

```sh
python scripts/validate.py
```

検証用にNode.js 24+、Python 3.11+、FFmpeg/ffprobe（libx264）が必要です。生成メディア・ローカルHTTP・API/DOMモックによる試験で、RPLAYへ接続しません。

[操作と制約](MP4_GUIDE_v2.20.0.md)、[QA](QA_v2.20.0.md)、[継続資料](DEVELOPMENT_HANDOFF_v2.20.0.md)。旧版README/QA/evidenceは各記載版の履歴です。
