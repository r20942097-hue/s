# Development handoff v2.42.3

Baseline ZIP: RPLAY_Stable_Player_v2.42.2_DASH_CROSSSITE_CANDIDATE.zip.
Output ZIP: RPLAY_Stable_Player_v2.42.3_SEGMENT_AUDIT_CANDIDATE.zip.

Changed sources: `src/hls_transport.js`, `src/player.user.js`; added `tests/test_v2423_writer_audit.cjs`, and updated manifest, version pin tests, packaging scripts, readme and new audit specification.

Build: `python scripts/build.py`
Tests: `node --test tests/test_*.cjs` and `python -m unittest discover -s tests -p 'test_*.py'`
Verification: `python scripts/validate.py --output-dir <path>` (runs all tests and validates mirror hashes and ZIP ledger, if present).

No new site permissions or background auto-record paths; legacy CLI unchanged at v2.42.0. Do not mark public deployment GO before browser/Nico/live acceptance and file-commit/decoded validation. Preserve v2.42.2 as a rollback.
