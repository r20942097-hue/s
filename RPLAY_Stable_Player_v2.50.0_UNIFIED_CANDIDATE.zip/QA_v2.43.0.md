# QA v2.43.0 — 2026-10-27 JST

全回帰818件PASS（Node 651 / Python 167）。追加Node 61件・追加Python 2件（合計63件）。構文・manifest・5実行体core共有（`2c0e5d6cc73fc0f73a521ace4716a35013462e5fba9035a36b59f580dd237975`）・派生copy（19ファイル×3箇所）・再build byte一致を確認。配布ZIPのCRC/全ファイルhash照合PASSを確認済み。

新規統合・不具合修正（v2.42.0 + CrossSite_Compatibility_v0.1.0 + v2.23.0 統合）:
1. **fMP4初期化セグメント(`moov`)の未確定duration(`0xFFFFFFFF`)正規化 (`src/mp4_convert_core.js`)**: `mux.js` 6.3.0 が `mvhd`/`tkhd`/`mdhd` に書き込む `0xFFFFFFFF` により FFmpeg 5.1.9 (`ffprobe`) でコンテナdurationが `89478.485313s` と算出されていた不具合（v2.42.0で5件失敗）を `normalizeInitHeaderDurations` で `0` に正規化し解消。
2. **Node 18 / VM スコープでの `crypto.randomUUID` 参照エラー修正 (`src/media_catalog.js`)**: グローバル `crypto` 未定義環境でも `require('node:crypto')` へ安全にフォールバックする `defaultUuid()` を導入し、v2.42.0で7件失敗していたテストを解消。
3. **ローカル配信サーバー (`scripts/serve_mp4.py`) の改善**: `media_inspect.html` が読み込む `hls_transport.js`・`media_catalog.js`・`cross_site_compat.js` を `ALLOWED` に追加（HTTP 404解消）し、クライアント早期切断時の `BrokenPipeError`/`ConnectionResetError` を安全に捕捉。
4. **Cross-Site Compatibility v0.1.0 Phase 1 統合 (`src/cross_site_compat.js`, `src/cross-site/*.mjs`, `src/media_catalog.js`, `src/media_inspect_core.js`, `src/media_inspect.js`, `src/media_inspect.html`)**:
   - URL署名保護（AWS CloudFront / S3 SigV4 / Google / Akamai / Fastly / Generic token のバイト単位保持）と非署名子URLへの親クエリ継承の精密化（既存の非署名クエリを持つ相対子URLにも不足キーのみを補完）。
   - サイト種別判定（RPLAY / ニコニコ動画 / ニコニコ生放送 / YouTube / Twitch / 汎用HLS・DASH・MP4）および視聴ページURL直接入力時の案内表示。
   - HTTPステータス診断（200 / 401 / 403 / 404 / 410 / 429 / 500 / 503）のローカル診断画面への統合。
   - `LiveSegmentLedger`・`NicoLiveSessionObserver`・`MediaCandidateRegistry` の統合および `RspMediaCatalog` の `updates` カウンタ・`markFailure` 追跡。
5. **チェックポイント復旧 `verifyTs` 検証 (`src/recovery_core.js`) & WebVTT検証/結合・PSI CRC監査 (`src/hls_transport.js`, `src/hls_transport.py`)**: `v2.23.0` 分岐の復旧時TSパケット境界検査オプション (`verifyTs: true`)、WebVTT検証・境界重複排除結合 (`validateWebVtt`/`mergeWebVttSegments`)、および Python 側 `hls_audit_psi` を統合。

独立HTTP・継承E2E:
- `python3 tests/check_request_context_http.py` PASS（raw signed query保持、匿名403、明示Cookie policy成功、子URLの限定query継承）。
- `python3 tests/check_cdn404_decode.py` PASS（先頭404回復、1TS、byte一致、AV/全decode）。
- `node --test tests/check_recording_during_scan.cjs` 2件PASS（Chrome/Firefox両ホストで予約走査中の録画停止が即時完了）。

実ブラウザ/実RPLAY/実外部配信サイト/Windows/2GiB/長時間耐久は未受入。DRM回避・認証回避・有料壁突破は一切行わない。CANDIDATE_NO_GO維持。証拠は `evidence/v243-current`。
