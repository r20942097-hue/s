# v2.23.0 引き継ぎ

主ベースv2.22.0を保持し、添付4点を照合した上で選択的に改善。
INTEGRATION_REVIEW_v2.23.0.md / INPUT_RECONCILIATION_v2.23.0.json に入力原本と採否を整理。

src/player.user.js: rspLiveRouteId/rspRouteKey、Engine.fetchProbe/probe、各playlist経路の署名URL保持。
src/offscreen_pre.js: member probe URL保持。
src/media_inspect_core.js/html/js: 通信しない診断と明示的コマンド生成。本文サイズ2MiB。生URLはコマンドにのみ入り、診断JSONにpath/queryを含めない。
background.js/ext_glue.js: 既存の権限/トップフレーム判定を通して診断画面を開く導線。
serve_mp4.py: 診断の静的3アセットもloopback配信。全サイト捕捉権限は追加していない。

build: python scripts/build.py
ledger/package: python scripts/package_release.py /outside/project/output.zip
unit: python scripts/validate.py --output-dir /outside/project/evidence
browser: python scripts/test_firefox_mp4.py --firefox /path/firefox --geckodriver /path/geckodriver --output-dir /outside/project/evidence --large

最終回帰597件構成。Firefox27項目構成（26 PASS/1 BLOCKED）。以前の候補/素材は保全。
新しい診断はHLS完全構文検査や再生合格ではない。PowerShell文字列をWindowsで実行したとは扱わない。

次の優先課題: 実RPLAYのAPI/DOM fixture、Windows保存/再生同期、2GiB/長時間、BG永続台帳移行、時刻mapが異なるWebVTT、別音声mux、capture系の権限/寿命/総量設計。
Sniffer原本のMAIN fetchフックは本文全量読取り、無制限の状態蓄積、文字列コマンド生成に課題があり、そのまま導入していない。
