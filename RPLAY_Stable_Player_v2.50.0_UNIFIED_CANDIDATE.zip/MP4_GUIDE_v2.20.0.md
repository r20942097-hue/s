# v2.20.0 コーデック設定の照合

操作と制限はv2.19.0を継承します。入力検査、入力/出力AACサンプルhash、MP4サンプル表/mdat範囲、時刻監査、保存後SHA-256に加え、最初のMP4初期化情報を入力と照合します。

## 追加検査

- mp4aのチャンネル数・固定小数点サンプルレート・sample size・data reference・対応entry形式。
- esdsのdescriptor長と境界、ES/DecoderConfig/DecoderSpecific/SLConfigの対応形式。
- AudioSpecificConfigのAAC object type・sampling index・channel configurationを入力ADTSと照合。未対応flagsは拒否。
- avcCのNAL length size、単一SPS/PPSの長さ・NAL typeと、入力から取得したSPS/PPSのバイト列の一致。
- avcCのprofile/compatibility/levelとSPSの一致。
- SPSの一部を解析してcroppingを含む寸法を求め、avc1とtkhdの幅・高さを照合。

mp4IntegrityEvidence.codecMetadataに照合した設定を返します。専用のsrc/mp4_codec_core.jsを共通モジュールとし、単体画面と両拡張へ同じ内容を収録しています。

## 対応範囲

同梱mux.js 6.3.0の出力契約を対象とした検査です。一般的なMP4の全準拠検証器ではありません。avc1/mp4a、単一SPS/PPS、2バイトAudioSpecificConfig等に限定します。未知のdescriptor形式や複数parameter setを推測して受理しません。

SPSは1個4096バイトまで。入力1本内で異なるSPS/PPSへ変化するとTS_AVC_PARAMETER_SET_CHANGEで先行拒否します。同じparameter setの繰返しは受理します。合法な入力でも未対応構造として拒否する場合があります。

寸法パーサーはBaseline/Main/Extended相当の基本構造と、8bit・chroma format 0/1のHigh profile分岐を扱います。Baseline/Main/Highの4:2:0素材はffprobeで照合済み。Extendedやmonochrome等の全分岐を実メディア検証したものではありません。High10/High422/High444等は今回の対象外です。

全SPS/PPS/VUI/RBSP/slice構文や、映像全内容の保存を証明するものではありません。PPSの全意味や参照関係の解析、AAC CRC、本番での全デコードも行っていません。音声圧縮データの保持を、元音声が正常であるとの保証と混同しないでください。

## エラー例

| コード | 意味 |
|---|---|
| MP4_AAC_CONFIG_MISMATCH | 音声設定が入力ADTSと不一致 |
| MP4_ESDS_DESCRIPTOR / MP4_ESDS_DECODER | descriptorの境界/対応形式が不正 |
| MP4_AVC_PARAMETER_SET_MISMATCH | 出力SPS/PPSが入力と異なる |
| MP4_AVC_DIMENSIONS_MISMATCH | SPS/avc1/tkhdの寸法が不一致 |
| AVC_SPS_PROFILE_UNSUPPORTED | 寸法解析の対象外profile |
| TS_AVC_PARAMETER_SET_CHANGE | 入力内の設定変化を検出 |

保存確定前の失敗はabortします。確定後の読戻し失敗は、既に置換された出力を自動復元しません。入力2GiB上限・保持TS32MiB上限・PES跨ぎAAC拒否・1 audio tick補正方針は継承。実Firefox/OS保存・実RPLAY・数時間/2GiBは未検証です。
