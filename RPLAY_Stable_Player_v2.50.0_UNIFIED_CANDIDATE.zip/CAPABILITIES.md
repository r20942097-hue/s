# 機能範囲 v2.49.0

|項目|状態|
|---|---|
|署名URL|表示と取得を分離。実通信URL（絶対署名URL含む）を変更せず使う|
|ページ情報|request/tab/URL照合、Referer/Origin/UA・取得元・認証の有無をRAM保持|
|Cookie/Authorization値|未収集・未保存・未出力|
|Cookie利用|明示ON時のみブラウザのcredentials include、送信条件はブラウザ依存|
|Referer/UA|観測値をFFmpegコマンド欄へ反映。fetch強制ではない|
|親query継承|明示ON時、同一originかつ未署名の子URLへ不足キーのみraw付加。署名済み子URLは維持|
|Cross-Site診断|Nico/YouTube/Twitch/RPLAY視聴ページ判別、LL-HLS/BYTERANGE/暗号化診断、HTTP応答診断|
|録画継続・耐障害|JS/Python双方で一時M3U8破損猶予(2回)・転送寸断FIFO再試行・404猶予・パート単位の書込/順序監査(`partIntegrity`)|
|断点復帰パート保持|`persistSession` v2 / `resumeFromCrash` により再読込前の確定パート(`partsLog`・`checkpoint`)を最終JSON/結合リストへ引継ぎ|
|保存後デコード監査・2トラック結合|`rplay_dl.py --audit-files` による単体デコード監査、`rplay_join.py --mux-audio` による分離音声2トラックMP4結合|
|MP4変換・復旧|fMP4初期ヘッダ `0xFFFFFFFF` 継続時間を0へ正規化、復旧時 `verifyTs` 対応|
|BG停止後のMP4引渡し|手動案内（`mp4Handover`・変換画面自動表示）＋ 自動変換・台帳引渡し（`mp4AutoHandoff`・既定OFF・非破壊・単発実行・秘密ゼロ）の併存|
|preview環境診断|変換画面のMP4プレビュー失敗要因を環境/操作/内容へ分類表示（`preview_diag.js`・表示のみで保存経路に影響しない）|
|disk-backed segment store|OPFS保存プリミティブ Stage 1（ペア書き込み・digest fail-closed・予算LRU退避・pin・孤児清掃）。取得経路には未接続|
|全サービス認証/ブラウザ内汎用動画DL|未対応|


## v2.49.0 追加機能
- **汎用 disk-backed 取得エンジン Stage 2** (`src/segment_acquire.js`): `RspSegmentAcquire` — 明示候補のみを disk-backed で取得。RAM常駐1セグメント上限・再起動継続・cancel残留・非破壊・fail-closed・ゼロシークレット・既定OFF。Stage 3 UI統合は未実装（本番配線なし）。
- **`rplay_dl.py --join-files`** スタンドアロン無劣結合CLI: 複数TSパートを同ディレクトリ制約のもと FFmpeg concat で無劣化結合。`--join-audio-files` で分離音声パートの2トラックMP4 mux、`--join-subtitle` / `--join-subtitle-lang` で VTT 字幕の mov_text 字幕トラック mux、`--join-out` で出力先指定（上書き拒否）。
- **`hls_inspect_master`** Python 側マスタープレイリスト構造監査: JS `RspMediaInspect.inspectMaster` と完全鏡像。variant 数・audio/subtitle group 検出・orphan group・HDR/high-FPS variant 計数・max resolution/bandwidth・`needsSeparateAudioMux` 判定。ゼロURI出力。
- **広告除外キーワードフィルタ** (URL録画): ユーザー指定の正規表現に合致するセグメントURIをスキップし、`adFiltered` / `scte35` ステータスカウンタで件数を可視化。
- **dashboard policy 拡張**: 実効policy行に `mp4Handover` と `mp4AutoHandoff` の適用状態（ON/OFF/値なし）を列挙。

## v2.50.0 追加機能
- **segment_store Stage 3（明示取得の結線）** (`src/acquire_host.js`): `RspSegmentAcquire` を実OPFS store・実HLSパーサ・境界つきfetchへ束縛。dashboard の `segmentAcquire` フラグ（既定OFF）がONのときのみ、検出HLS候補への明示「取得」が可能。RAM常駐1セグメント・即時disk確定書き込み・再起動台帳復元・取消残存列挙・ゼロシークレット。変換・保存は未配線（次版以降）。
- **取得ジョブパネル** (dashboard): 状態・セグメント数・バイト数の表示、取消・再開（候補再選択）・残存確認・状態破棄。最大8件の境界表示。
- **BG取得ルーティング**: dashboard 送信者限定・`mediaCatalog` 観測候補のみを入口化（HLS型ガード・`CANDIDATE_EXPIRED`・`ACQUIRE_UNSUPPORTED_TYPE`）・オフスクリーンへの明示ターゲット中継。
