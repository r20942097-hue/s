# v2.37.0 開発引継ぎ

src/json_fetch.js: fetchJsonWithRetry単一実装(2 MiB上限・宣言長/実受信byte検査・fatal UTF-8・本文完了までtimeout・finallyでctl.abortとreader.cancel/releaseLock・JSON_TOO_LARGE/JSON_STREAM_UNAVAILABLEはterminal・再試行はstatus0/5xxのみ1回・429はretry-after透過)。module.exports付きでNode試験が直接可能。build.pyがplayer.user.jsとoffscreen_pre.jsの`/* RSP_JSON_FETCH_MODULE */`へ同一byte注入し、5実行物(userscript+2拡張のcontent/offscreen)へ展開。注入先ソースに関数本体を残さない(単一ソース保証・test_v2370_json_common.cjsが検査)。

offscreen_pre.js: 旧fetchJsonWithRetry(res.json()一括読込・ヘッダでtimeout解除)を廃止。authedJson/詮索/限定/key2/予約は呼び出し契約不变(401分類・token.stale通知維持)。BG経路のJSONも2 MiB超は再取得せず失敗。生成物をsourceとするslice試験(v270/v280/v290)は'async function fetchJsonWithRetry'境界のまま、ソースをsourceとするv2310/v2361はjson_fetch.js直接試験へ移行。

今後: 登録配信者の名前metadata(rsp_registered_creatorsはID配列のまま・名前/元URLは別key設計)と外部予約閲覧(BG経由のschedules巡回)、本物のRPLAY fixture/受入、native preview環境要因の切分け、Windows/2 GiB/長時間。実ブラウザー受入は本環境未実施のため次環境で再実施。VDH星は位置と実際のtooltipが確認できるまで意味を断定しない。
