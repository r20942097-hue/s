# 現行受入 v2.49.0

CANDIDATE / NO_GO。旧手順は `history/v242_ACCEPTANCE.md`。
1. 拡張版/OS/ブラウザ/ZIP hash/日時を記録。
2. ページ実通信URLの署名・パラメータ順/重複/escapeと、取得URL・生成コマンドを照合。
3. Referer/Origin/UA・取得元・Cookie/Authorization有無の観測。request/tab/URL違いで情報を混ぜない。値を保存/ログ出力しない。
4. Cookie OFF/ON、SameSite/分離/redirect、401/403/404/410/429の診断表示を環境別に確認。ONだけで認証再現済みとは扱わない。
5. query継承OFF/ON、同一originかつ未署名の子URLへの不足親query付加（独自署名付き子URLと別originを変更しない）を確認。
6. 視聴ページURL（Nico/YouTube/Twitch/RPLAY）入力時に、直接メディアURLではない旨の案内が出ることを確認。
7. クラッシュ/再読込復帰後に、復帰前に確定保存されたパートが最終 `_info.json` と `_join_*.json` に保持されることを確認。
8. 保存済みパートに対する `rplay_dl.py --audit-files` の単体デコード監査および `rplay_join.py --mux-audio` の2トラックMP4結合を確認。
9. 既存の録画/変換（`mvhd`/`tkhd`/`mdhd` 0正規化後のMP4継続時間）/復旧/予約取消、実RPLAY/Windows/2GiB/長時間/native preview受入を継続。
10. `mp4Handover`（変換画面自動表示）と `mp4AutoHandoff`（自動変換・引渡し）が dashboard に独立したトグルとして併存し、どちらも既定OFFであることを確認。
11. `mp4AutoHandoff` ON の実機受入: BG録画を停止（またはブラウザを再起動）し、残存TSパートが自動でMP4変換・保存台帳引渡しされること。**元TSが削除・変更されないこと**、変換中は録画を開始できないこと、完了/失敗が通知されること、`mp4-handoff.status` の証拠にURL等の秘密が含まれないことを確認。失敗時は手動のTS→MP4変換で救済できること。
12. `segment_acquire` Stage 2 の実機受入: dashboard（未配線・Stage 3で実装予定）を経由せず、単体テスト用ブリッジから明示候補を指定して取得を開始し、(a) RAM常駐が1セグメント上限であること、(b) 取得済セグメントが OPFS `rsp_seg/<namespace>/` 配下に `.bin`+`.json` ペアで書き込まれること、(c) cancel 後もdiskにセグメントが残り `listResidue()` で列挙できること、(d) 再起動後 `restore()`+`continueFrom()` で未取得セグメントのみ再開できること、(e) `zeroSecretScan()` が clean を返すこと。

13. `segment_acquire` Stage 3 の実機受入: dashboard のフラグ（既定OFF）をONにすると候補一覧に「候補を取得」が現れること。OFFのときは全操作が `ACQUIRE_DISABLED` で拒否されること。明示開始後 (a) 取得ジョブパネルに状態・件数・バイト数が現れること (b) 取り消すとdiskに残存があり「残存確認」で列挙できること (c) ブラウザ再起動後に「再起動分を復元」で台帳が復元され、候補の再選択による「再開」で未取得分のみ続行すること (d) 状態・残存・台帳にURL/トークン/Cookieが一切含まれないこと (e) 非HLS候補・失効候補は `ACQUIRE_UNSUPPORTED_TYPE` / `CANDIDATE_EXPIRED` で案内されること。取得したセグメントの変換・保存は本版では未提供であること（保存を約束しない）。
fixture Cookieおよび合成M3U8は実サービス・実ブラウザ受入の代用としない。秘密を証拠へ転記しない。
