"""Serve only the local conversion tool on loopback. No upload endpoint."""
from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from urllib.parse import urlsplit,unquote
import argparse,webbrowser
ROOT=Path(__file__).resolve().parents[1]
ALLOWED={'mp4_convert.html','mp4_convert.js','mp4_convert_worker.js','mp4_browser_io.js','mp4_convert_core.js','mp4_codec_core.js','sha256.js','libs/mux.min.js','media_inspect.html','media_inspect.js','media_inspect_core.js','hls_transport.js','media_catalog.js','cross_site_compat.js','cross_site_core.js','creator_meta.js'}
class Handler(SimpleHTTPRequestHandler):
 extensions_map={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8'}
 def __init__(self,*a,**k):super().__init__(*a,directory=str(ROOT),**k)
 def _allowed(self):
  parsed=urlsplit('//'+self.headers.get('Host',''))
  try:valid_host=parsed.hostname in {'127.0.0.1','localhost'} and parsed.port==self.server.server_port
  except ValueError:valid_host=False
  path=unquote(urlsplit(self.path).path).lstrip('/')
  if not valid_host or path not in ALLOWED|{''}:self.send_error(404);return False
  self.path='/'+(path or 'mp4_convert.html');return True
 def do_GET(self):
  try:
   if self._allowed():super().do_GET()
  except (BrokenPipeError,ConnectionResetError):pass
 def do_HEAD(self):
  try:
   if self._allowed():super().do_HEAD()
  except (BrokenPipeError,ConnectionResetError):pass
 def end_headers(self):self.send_header('Cache-Control','no-store');super().end_headers()
def create_server(port=0):return ThreadingHTTPServer(('127.0.0.1',port),Handler)
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--port',type=int,default=0);p.add_argument('--no-browser',action='store_true');a=p.parse_args()
 with create_server(a.port) as server:
  url=f'http://127.0.0.1:{server.server_port}/mp4_convert.html';print('Local TS -> MP4: '+url,flush=True);print('Keep this terminal open. Press Ctrl+C to stop. Source TS stays in your browser.',flush=True)
  if not a.no_browser:webbrowser.open(url)
  try:server.serve_forever()
  except KeyboardInterrupt:pass
if __name__=='__main__':main()
