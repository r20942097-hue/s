#!/usr/bin/env python3
"""acceptance_report.py v2.50.0 — RPLAY Stable Player 受入観察支援ツール(B-03)。

ACCEPTANCE.md(A1〜A15)の実機受入観察の記録作業を構造化する純ローカルツール。
実機で録画した成果物ディレクトリ(情報JSON・ledger.json・partファイル)を走査し、
T2/T3/T6/T7テンプレートに対応する観察ドラフト(Markdown)を生成する。

契約:
  - 通信は一切行わない(純ローカル・fetch禁止)。出力先はstdoutまたは--out文件。
  - 秘密ゼロ: 入力内のURL値はorigin+pathへ再秘匿し、出力全文に秘密疑いクエリ
    (sig= / token= / key= / jwt= / signature= 等)が残っていれば異常終了する
    トリップワイヤーを備える(ACCEPTANCE.md §0.3/§0.4の機械強制)。
  - 虚偽を記録しない: 不在の証拠ブロックは「不在」とだけ書き、数値を捏造しない
    (A-08契約の継承)。人間しか観察できない項目は「確認待ち」プレースホルダー。
  - このドラフトは数値証拠の転記のみ。合格判定はACCEPTANCE.md §5のプロトコルに
    よる(本ツールはPASS/FAILを判定しない)。

使い方:
  python3 scripts/acceptance_report.py --dir <録音成果物ディレクトリ> [--out report.md] [--json]
戻り値: 0=報告生成 / 2=対象ファイルなし / 3=秘密トリップワイヤー発火
"""
import argparse
import hashlib
import json
import pathlib
import re
import sys

TOOL = "acceptance_report.py v2.50.0"

EVIDENCE_BLOCKS = [
    "generationRecovery", "fmp4Evidence", "llhlsEvidence", "authEvidence",
    "canaryEvidence", "sessionTrackingEvidence", "errorTaxonomyEvidence",
    "notificationEvidence", "metadataEvidence", "subtitleEvidence",
    "partContinuityEvidence", "partBoundaryEvidence", "aggregationEvidence",
    "externalDownloaderEvidence", "decryptionEvidence",
    "continuityCounterEvidence", "playlistParseGraceEvidence",
    "segmentTransferRetryEvidence", "adFilterEvidence",
]

# 保存確定イベント契約の段階順序(ACCEPTANCE.md A4 / ledger contract)
# BROWSER_DONE はブラウザー経路のみ(CLIでは出ない)。飛び越し・逆行を検知する。
STAGE_RANK = {"REQUESTED": 0, "FILE_WRITTEN": 1, "BROWSER_DONE": 2, "HASHED": 3,
              "DECODED/CONTINUITY": 4}

_SECRET_QUERY_RE = re.compile(
    r"[?&](sig|signature|token|jwt|key|key2|access_token|auth|x-amz-signature)=",
    re.IGNORECASE)
_URL_RE = re.compile(r"https?://[^\s\"'<>\\)]+")


def redact_url_str(s):
    """URL値をorigin+pathへ再秘匿(クエリ・断片を除去)。非URL文字列は無変換。
    情報JSONは既にredact済みだが、防御的に本ツール出力側でも再適用する。"""
    def _one(m):
        u = m.group(0)
        cut = len(u)
        for sep in ("#", "?"):
            i = u.find(sep)
            if i >= 0:
                cut = min(cut, i)
        return u[:cut]
    return _URL_RE.sub(_one, s)


def secret_tripwire(text):
    """出力全文に秘密疑いクエリが残っていないか検査するトリップワイヤー。
    戻り値=検出されたパターン文字列のリスト(空=安全)。"""
    return sorted(set(m.group(0) for m in _SECRET_QUERY_RE.finditer(text)))


def _fmt(v):
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, dict):
        return ",".join("%s=%s" % (k, _fmt(vv)) for k, vv in sorted(v.items()))
    if isinstance(v, list):
        return ",".join(_fmt(x) for x in v)
    return redact_url_str(str(v))


def _evidence_summary(name, blk):
    """証拠ブロック毎の要点行(在のときのみ呼ばれる・秘密は含まない鍵のみ転記)。
    video/audio両トラック構造(generationRecovery/fmp4Evidence・ブラウザー版
    llhlsEvidence等)は トラック内の実鍵をそのまま列挙(CLI/ブラウザーで鍵形状が
    異なるブロックに対応)。平坦構造は既知鍵を転記する。"""
    if not isinstance(blk, dict):
        return _fmt(blk)
    flat_keys = {
        "llhlsEvidence": ["videoIndicators", "audioIndicators"],
        "authEvidence": ["mode", "tokenSource", "refreshSource", "responseKey",
                         "key2Resolutions", "classifications401"],
        "canaryEvidence": ["result", "action"],
        "sessionTrackingEvidence": ["sameSessionResumes", "newSessionSplits",
                                    "thresholdSec"],
        "errorTaxonomyEvidence": ["counts"],
        "notificationEvidence": ["sent", "failed", "rateLimited429"],
        "metadataEvidence": ["embedded", "version"],
        "subtitleEvidence": ["renditionCount", "variantsLinked", "policy"],
        "partContinuityEvidence": ["splitMinutes", "splitOnDiscontinuity", "discontinuityMergedCount", "partsConcatenated"],
        "partBoundaryEvidence": ["video_hls_boundary", "size_limit", "time_limit", "hlsBoundary", "sizeLimit", "timeLimit"],
        "aggregationEvidence": ["status", "file", "partsJoined"],
        "externalDownloaderEvidence": ["protocolScheme", "tsDisguiseStrippedCount", "queryInheritedCount"],
        "decryptionEvidence": ["enabled", "method", "keySource", "segmentsDecrypted", "segmentsFailed"],
        "continuityCounterEvidence": ["packets", "discontinuities", "corruptionSuspected"],
        "playlistParseGraceEvidence": ["videoTransientErrors", "videoRecovered", "audioTransientErrors", "audioRecovered"],
        "segmentTransferRetryEvidence": ["videoRetries", "videoRecovered", "audioRetries", "audioRecovered"],
        "adFilterEvidence": ["adKeywordConfigured", "videoScte35Indicators", "videoFilteredSegments"],
    }.get(name, [])
    parts = []
    if any(isinstance(blk.get(t), dict) for t in ("video", "audio")):
        for track in ("video", "audio"):
            tv = blk.get(track)
            if not isinstance(tv, dict):
                continue
            sub = ["%s=%s" % (kk, _fmt(tv.get(kk)))
                   for kk in sorted(tv) if not str(kk).startswith("_")][:8]
            if sub:
                parts.append("%s: %s" % (track, " ".join(sub)))
        if parts:
            return " / ".join(parts)
    for k in flat_keys:
        parts.append("%s=%s" % (k, _fmt(blk.get(k))))
    if not parts:
        parts = ["keys=%s" % ",".join(sorted(blk)[:6])]
    return " ".join(parts)


def _scan_targets(directory):
    """対象ファイルを分類: 情報JSON / 台帳(ledger・orphan_ledger) / 未分類。
    分類はファイル名ヒューリスティック(優先)+内容鍵で行う。"""
    directory = pathlib.Path(directory)
    infos, ledgers, others = [], [], []
    for p in sorted(directory.glob("*.json")):
        if p.name == "SHA256SUMS.json":
            continue
        kind = None
        if p.name.endswith("_ledger.json") or p.name == "orphan_ledger.json":
            kind = "ledger"
        elif p.name.endswith("_info.json") or p.name.endswith("info.json"):
            kind = "info"
        if kind is None:
            try:
                d = json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                d = None
            if isinstance(d, dict) and isinstance(d.get("parts"), list) \
                    and d["parts"] and isinstance(d["parts"][0], dict) \
                    and isinstance(d["parts"][0].get("stages"), list):
                kind = "ledger"
            elif isinstance(d, dict) and "durationSec" in d and isinstance(d.get("parts"), list):
                kind = "info"
        if kind == "info":
            infos.append(p)
        elif kind == "ledger":
            ledgers.append(p)
        else:
            others.append(p)
    return infos, ledgers, others


def ledger_stage_violations(ledger):
    """段階順序契約(REQUESTED→FILE_WRITTEN→(BROWSER_DONE)→HASHED→
    DECODED/CONTINUITY)の逆行・飛び越し誤登録・重複を検知する。
    戻り値=違反説明文字列のリスト(空=違反なし)。
    段階の欠落(HASHED無し等)はstatus側の問題でありここでは違反としない
    (ACCEPTANCE.mdの「飛ばし無し」検知は登録された段階の順序に対するもの)。"""
    out = []
    for part in (ledger or {}).get("parts", []):
        name = part.get("file") or "(无名)"
        stages = [s.get("stage") for s in part.get("stages", [])
                  if isinstance(s, dict) and s.get("stage")]
        seen = []
        prev_rank = None
        prev_stage = None
        for st in stages:
            rank = STAGE_RANK.get(st)
            if rank is None:
                out.append("%s: 未知段階 %s" % (name, st))
                continue
            if st in seen:
                out.append("%s: 段階重複 %s" % (name, st))
            if prev_rank is not None and rank < prev_rank:
                out.append("%s: 順序違反 %s→%s (段階契約の逆行・ACCEPTANCE.md A4)"
                           % (name, prev_stage, st))
            seen.append(st)
            prev_rank = rank
            prev_stage = st
    return out


def sha256_crosscheck(ledger, directory):
    """ledger HASHED段階のsha256と実ファイルの再計算を照合する(A2/A4支援)。
    戻り値=[{file, expected, actual, result}]。result: 一致/不一致/ファイル不在/
    sha256記録なし。虚偽を記録しない: 比較できないものは比較不能として記録。"""
    directory = pathlib.Path(directory)
    rows = []
    for part in (ledger or {}).get("parts", []):
        name = part.get("file")
        if not name:
            continue
        expected = None
        for s in part.get("stages", []):
            if isinstance(s, dict) and s.get("stage") == "HASHED" and s.get("sha256"):
                expected = s["sha256"]
                break
        path = directory / name
        if expected is None:
            rows.append({"file": name, "expected": None, "actual": None,
                         "result": "sha256記録なし"})
            continue
        if not path.is_file():
            rows.append({"file": name, "expected": expected[:12] + "…", "actual": None,
                         "result": "ファイル不在"})
            continue
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        actual = h.hexdigest()
        rows.append({"file": name, "expected": expected[:12] + "…",
                     "actual": actual[:12] + "…",
                     "result": "一致" if actual == expected else "不一致"})
    return rows


def _info_section(p, d, lines):
    lines.append("")
    lines.append("## 観察: %s" % p.name)
    lines.append("")
    lines.append("- tool: %s" % _fmt(d.get("tool")))
    lines.append("- creatorOid: %s / accessMode: %s / sourceKind: %s" % (
        _fmt(d.get("creatorOid")), _fmt(d.get("accessMode")),
        _fmt(d.get("sourceKind"))))
    lines.append("- playlist(origin+path再秘匿): %s" % redact_url_str(
        _fmt(d.get("playlist") or "")))
    lines.append("- 開始: %s / 終了: %s / durationSec: %s" % (
        _fmt(d.get("startedAt")), _fmt(d.get("endedAt")),
        _fmt(d.get("durationSec"))))
    lines.append("- totalBytes: %s / パート数: %s / segments: %s / missingSuspect: %s"
                 % (_fmt(d.get("totalBytes")), _fmt(len(d.get("parts")) if isinstance(d.get("parts"), list) else d.get("parts")),
                    _fmt(d.get("segments")), _fmt(d.get("missingSuspect"))))
    stats = d.get("stats") or {}
    if isinstance(stats, dict) and stats:
        lines.append("- stats: %s" % _fmt(stats))
    qa = d.get("qaudit")
    lines.append("- qaudit: %s" % (_fmt(qa.get("verdict"))
                                   if isinstance(qa, dict) and qa.get("verdict")
                                   else "不在"))
    av = d.get("avCorrelation")
    lines.append("- avCorrelation: %s" % (_fmt(av.get("verdict"))
                                          if isinstance(av, dict) and av.get("verdict")
                                          else "不在(音声両録画時のみ)"))
    lines.append("")
    lines.append("### 証拠ブロック(A10/A15支援)")
    lines.append("")
    lines.append("| ブロック | 在/不在 | 要点 |")
    lines.append("|---|---|---|")
    for name in EVIDENCE_BLOCKS:
        blk = d.get(name)
        if blk:
            lines.append("| %s | 在 | %s |" % (name, _evidence_summary(name, blk)))
        else:
            lines.append("| %s | 不在 | - |" % name)
    qo = d.get("queueOrder")
    if isinstance(qo, dict):
        lines.append("")
        lines.append("- queueOrder: %s" % _fmt(qo))
    lines.append("")
    lines.append("### 確認待ち(人間観察のみ・ドラフトは記入しない)")
    lines.append("")
    lines.append("- [ ] 再生確認(全編視聴・途切れ箇所の有無) — T6")
    lines.append("- [ ] 漏れ数・欠落率の所見確認 — T6")
    lines.append("- [ ] 所見記入 — T2/T3/T6/T7")


def _ledger_section(p, d, directory, lines):
    lines.append("")
    lines.append("## 台帳: %s" % p.name)
    lines.append("")
    parts = d.get("parts") or []
    lines.append("- パート数: %s" % _fmt(len(parts)))
    statuses = [x.get("status") for x in parts if isinstance(x, dict)]
    if statuses:
        lines.append("- status一覧: %s" % ",".join(_fmt(s) for s in statuses))
    violations = ledger_stage_violations(d)
    lines.append("- 段階契約(飛び越し・逆行検知): %s"
                 % ("違反なし" if not violations else "違反 %d件" % len(violations)))
    for v in violations:
        lines.append("  - %s" % v)
    rows = sha256_crosscheck(d, directory)
    if rows:
        lines.append("")
        lines.append("| パート | sha256照合 | 期待(先頭12) | 実測(先頭12) |")
        lines.append("|---|---|---|---|")
        for r in rows:
            lines.append("| %s | %s | %s | %s |" % (
                r["file"], r["result"], r["expected"] or "-",
                r["actual"] or "-"))


def build_report(directory):
    """録画成果物ディレクトリから観察ドラフト(Markdown)を生成して返す。
    対象ファイルが1つも無いときはValueError(虚偽の報告をしないため)。"""
    directory = pathlib.Path(directory)
    if not directory.is_dir():
        raise ValueError("ディレクトリが存在しません: %s" % directory)
    infos, ledgers, others = _scan_targets(directory)
    if not infos and not ledgers:
        raise ValueError("対象ファイル(情報JSON/台帳)が見つかりません: %s" % directory)
    lines = [
        "# RPLAY 受入観察ドラフト (%s)" % TOOL,
        "",
        "対象ディレクトリ: %s" % redact_url_str(str(directory)),
        "対象ファイル: 情報JSON %d件 / 台帳 %d件" % (len(infos), len(ledgers)),
        "生成方法: 純ローカル(通信なし)・秘密ゼロ(URL再秘匿+トリップワイヤー)",
        "",
        "このドラフトは数値証拠の転記のみ。合格判定は ACCEPTANCE.md §5 のプロトコルによる。",
    ]
    for p in infos:
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
            if not isinstance(d, dict):
                raise ValueError("top-levelがオブジェクトでない")
        except Exception as e:
            lines.append("")
            lines.append("## 観察: %s" % p.name)
            lines.append("")
            lines.append("- 読み込み失敗(破損JSON): %s — 手動確認が必要" % type(e).__name__)
            continue
        _info_section(p, d, lines)
    for p in ledgers:
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
            if not isinstance(d, dict):
                raise ValueError("top-levelがオブジェクトでない")
        except Exception as e:
            lines.append("")
            lines.append("## 台帳: %s" % p.name)
            lines.append("")
            lines.append("- 読み込み失敗(破損JSON): %s — 手動確認が必要" % type(e).__name__)
            continue
        _ledger_section(p, d, directory, lines)
    if others:
        lines.append("")
        lines.append("## 未分類JSON(%d件・対象外)" % len(others))
        for p in others:
            lines.append("- %s" % p.name)
    report = "\n".join(lines) + "\n"
    if secret_tripwire(report):
        # トリップワイヤー: 秘密疑いが出力に残った場合は報告しない(§0.4機械強制)
        raise RuntimeError("秘密トリップワイヤー発火: %s"
                           % ",".join(secret_tripwire(report)))
    return report


def main(argv=None):
    ap = argparse.ArgumentParser(description="RPLAY 受入観察支援ツール(純ローカル)")
    ap.add_argument("--dir", required=True, help="録画成果物ディレクトリ")
    ap.add_argument("--out", help="出力先ファイル(省略時はstdout)")
    ap.add_argument("--json", action="store_true",
                    help="機械可読サマリー(JSON)も標準出力へ")
    args = ap.parse_args(argv)
    try:
        report = build_report(args.dir)
    except ValueError as e:
        print("対象なし: %s" % e, file=sys.stderr)
        return 2
    except RuntimeError as e:
        print("中止: %s" % e, file=sys.stderr)
        return 3
    if args.out:
        pathlib.Path(args.out).write_text(report, encoding="utf-8")
    else:
        sys.stdout.write(report)
    if args.json:
        infos, ledgers, others = _scan_targets(args.dir)
        summary = {"tool": TOOL, "dir": str(pathlib.Path(args.dir)),
                   "infoFiles": [p.name for p in infos],
                   "ledgerFiles": [p.name for p in ledgers],
                   "unclassified": [p.name for p in others],
                   "tripwire": "PASS"}
        print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
