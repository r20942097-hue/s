from pathlib import Path
import hashlib,json,zipfile,argparse
R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('output');args=ap.parse_args()
def files():return [p for p in sorted(R.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.pyc','.zip'] and p.name!='SHA256SUMS.json']
manifest={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files()}
(R/'SHA256SUMS.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
p=Path(args.output).resolve();p.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
 for source in sorted(files()+[R/'SHA256SUMS.json']):
  i=zipfile.ZipInfo('rplay-stable-player-v2.6.0/'+str(source.relative_to(R)),(2026,10,25,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,source.read_bytes())
print(json.dumps({'file':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'files':len(manifest)+1}))
