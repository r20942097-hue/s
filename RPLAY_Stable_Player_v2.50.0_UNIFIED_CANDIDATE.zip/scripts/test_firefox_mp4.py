"""Real Firefox WebDriver acceptance. Stdlib client; Firefox, geckodriver and FFmpeg required.
External binaries are supplied explicitly, never downloaded by this script.
"""
from pathlib import Path
import argparse,subprocess,urllib.request,urllib.error,json,socket,time,zipfile,base64,hashlib,os,tempfile
R=Path(__file__).resolve().parents[1]
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--firefox',required=True);ap.add_argument('--geckodriver',required=True);ap.add_argument('--output-dir',required=True);ap.add_argument('--relax-content-sandbox',action='store_true');ap.add_argument('--large',action='store_true');args=ap.parse_args()
 out=Path(args.output_dir).resolve();out.mkdir(parents=True,exist_ok=True);scratch=tempfile.TemporaryDirectory(prefix='rplay-firefox-test-');work=Path(scratch.name);media=work/'media';media.mkdir();downloads=work/'downloads';downloads.mkdir()
 checks=[];sid=None;process=None;log=None
 def check(name,detail=True):checks.append({'test':name,'pass':True,'detail':detail});print('PASS',name,flush=True)
 def run(cmd):return subprocess.run(cmd,check=True,capture_output=True,text=True,timeout=180).stdout
 def make(name,rate=44100,channels=1,video_only=False,duration=4,cbr=False):
  p=media/name;cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi','-i','testsrc2=size=320x180:rate=25']
  if not video_only:cmd+=['-f','lavfi','-i',f'sine=frequency=750:sample_rate={rate}']
  cmd+=['-t',str(duration),'-c:v','libx264','-preset','ultrafast','-profile:v','baseline','-pix_fmt','yuv420p','-g','25']
  if cbr:cmd+=['-b:v','12M','-minrate','12M','-maxrate','12M','-bufsize','12M','-x264-params','nal-hrd=cbr:force-cfr=1']
  if not video_only:cmd+=['-c:a','aac','-ac',str(channels),'-b:a','96k']
  cmd+=['-f','mpegts',str(p)];run(cmd);return p
 av=make('mono44100.ts');control=media/'control_flat.mp4';run(['ffmpeg','-v','error','-y','-i',str(av),'-c','copy','-movflags','+faststart',str(control)]);stereo=make('stereo48000.ts',48000,2);video=make('video_only.ts',video_only=True)
 initial_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [av,stereo,video]}
 with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 log=(out/'geckodriver.log').open('w');process=subprocess.Popen([str(Path(args.geckodriver).resolve()),'--allow-system-access','--host','127.0.0.1','--port',str(port)],stdout=log,stderr=log)
 opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));base=f'http://127.0.0.1:{port}'
 def req(method,path,data=None):
  try:response=opener.open(urllib.request.Request(base+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json'},method=method),timeout=90)
  except urllib.error.HTTPError as e:raise RuntimeError(e.read().decode()) from e
  result=json.load(response);value=result.get('value')
  if isinstance(value,dict) and isinstance(value.get('error'),str) and 'message' in value:raise RuntimeError(value)
  return value
 def cmd(method,path,data=None):return req(method,'/session/'+sid+path,data)
 def js(script,args=[]):return cmd('POST','/execute/sync',{'script':script,'args':args})
 def async_js(script,args=[]):return cmd('POST','/execute/async',{'script':script,'args':args})
 def wait(script,timeout=60):
  end=time.monotonic()+timeout
  while time.monotonic()<end:
   value=js(script)
   if value:return value
   time.sleep(.08)
  raise AssertionError('Browser timeout: '+script+' / '+str(js("return document.getElementById('status')?.textContent;")))
 def screenshot(name):(out/name).write_bytes(base64.b64decode(cmd('GET','/screenshot')))
 def choose(paths):
  js("document.getElementById('file-chooser').value='';")
  element=cmd('POST','/element',{'using':'css selector','value':'#file-chooser'})['element-6066-11e4-a52e-4f735466cecf']
  cmd('POST','/element/'+element+'/value',{'text':'\n'.join(str(p) for p in paths)})
  wait("return !document.getElementById('choose').disabled;")
 last_receipt=None
 def convert(p,timeout=90):
  nonlocal last_receipt
  choose([p]);assert js("return !document.getElementById('start').disabled;");js("document.getElementById('start').click();")
  wait("return !document.getElementById('choose').disabled;",timeout)
  assert js("return !document.getElementById('download').hidden;"),js("return document.getElementById('status').textContent;")
  last_receipt=list_jobs()['jobs'][0]
  return {'receipt':last_receipt}
 def download_file():
  js("document.getElementById('download').click();")
  wait("return document.getElementById('status').textContent.includes('ダウンロード完了とサイズ一致');")
  data=async_js("const done=arguments[arguments.length-1];browser.downloads.search({orderBy:['-startTime'],limit:1}).then(done);")
  p=Path(data[0]['filename']);assert p.is_file(),p
  r=last_receipt;assert p.stat().st_size==r['bytes'];assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
  return p
 def list_jobs():return async_js("const done=arguments[arguments.length-1];run('list').then(done,e=>done({error:e.message}));")
 try:
  for _ in range(100):
   try:req('GET','/status');break
   except Exception:time.sleep(.1)
  prefs={'browser.download.folderList':2,'browser.download.dir':str(downloads),'browser.download.useDownloadDir':True,'browser.helperApps.neverAsk.saveToDisk':'video/mp4,application/octet-stream','browser.download.always_ask_before_handling_new_types':False}
  if args.relax_content_sandbox:prefs.update({'security.sandbox.content.level':0,'security.sandbox.rdd.level':0,'security.sandbox.utility.level':0})
  session=req('POST','/session',{'capabilities':{'alwaysMatch':{'browserName':'firefox','moz:firefoxOptions':{'binary':str(Path(args.firefox).resolve()),'args':['-headless'],'prefs':prefs}}}})
  sid=session['sessionId'];caps=session['capabilities'];cmd('POST','/timeouts',{'script':90000,'pageLoad':30000,'implicit':0})
  xpi=out/'tested-extension.xpi';ext=R/'rplay-stable-player-extension-firefox'
  with zipfile.ZipFile(xpi,'w',zipfile.ZIP_DEFLATED) as z:
   for f in sorted(ext.rglob('*')):
    if f.is_file():z.write(f,f.relative_to(ext))
  addon=cmd('POST','/moz/addon/install',{'path':str(xpi),'temporary':True});check('Firefox temporary extension installation',{'addonId':addon,'version':caps['browserVersion']})
  cmd('POST','/moz/context',{'context':'chrome'});uuid=js("return JSON.parse(Services.prefs.getCharPref('extensions.webextensions.uuids'))[arguments[0]];",[addon]);cmd('POST','/moz/context',{'context':'content'})
  cmd('POST','/url',{'url':f'moz-extension://{uuid}/dashboard.html'})
  wait("return document.getElementById('state').textContent!=='確認中';")
  assert js("return document.getElementById('state').textContent;")=='録画していません';check('external dashboard real status works outside RPLAY')
  wait("return !document.getElementById('save').disabled;")
  js("document.getElementById('safe').click();document.getElementById('save').click();")
  wait("return document.getElementById('saved').textContent.includes('保存しました');")
  cmd('POST','/refresh',{});wait("return document.getElementById('enabled').checked;")
  assert js("return !document.getElementById('inheritQuery').checked && document.getElementById('splitMin').value==='0';");check('external dashboard recommended settings persist and query defaults OFF')
  js("document.getElementById('creators').value='https://rplay.live/profile/'+ 'a'.repeat(24);document.getElementById('register').click();")
  wait("return document.getElementById('registered').textContent.includes('1人を保存');")
  cmd('POST','/refresh',{});wait("return document.getElementById('creators').value==='a'.repeat(24);")
  check('external profile URL registration persists canonical creator ID')
  js("window.fetch=async()=>new Response(JSON.stringify({_id:'b'.repeat(24)}),{status:200});document.getElementById('creators').value='https://rplay.live/c/test/live';document.getElementById('register').click();")
  wait("return document.getElementById('creators').value==='b'.repeat(24);")
  check('custom profile URL registration resolves and saves canonical ID in real DOM with mocked API')
  js("window.fetch=(u,o)=>new Promise((resolve,reject)=>o.signal.addEventListener('abort',()=>reject(Error('aborted'))));document.getElementById('creators').value='https://rplay.live/c/slow';document.getElementById('register').click();")
  wait("return !document.getElementById('cancelRegister').disabled;")
  js("document.getElementById('cancelRegister').click();")
  wait("return document.getElementById('registered').textContent.includes('中止');")
  assert js("return !document.getElementById('register').disabled && !document.getElementById('creators').disabled;")
  cmd('POST','/refresh',{});wait("return document.getElementById('creators').value==='b'.repeat(24);")
  check('cancelled custom profile registration retains previously saved IDs in real browser')
  async_js("const done=arguments[arguments.length-1];chrome.storage.local.set({rsp_registered_creators:['c'.repeat(24)]}).then(()=>done(true));")
  js("document.getElementById('creators').value='d'.repeat(24);document.getElementById('register').click();")
  wait("return document.getElementById('registered').textContent.includes('別の画面');")
  js("document.getElementById('reloadRegistry').click();")
  wait("return document.getElementById('creators').value==='c'.repeat(24);")
  check('stale registration view cannot overwrite newer saved IDs; reload restores current list with real Web Locks')
  async_js("const done=arguments[arguments.length-1];chrome.storage.local.set({rsp_dashboard_defaults:{autoStartAllowed:true,enabled:false,splitMin:12}}).then(()=>done(true));")
  js("document.getElementById('splitMin').value='5';document.getElementById('save').click();")
  wait("return document.getElementById('saved').textContent.includes('別の画面');")
  assert js("return document.getElementById('splitMin').value==='5';")
  js("document.getElementById('reloadSettings').click();")
  wait("return document.getElementById('splitMin').value==='12' && !document.getElementById('save').disabled;")
  assert js("return document.getElementById('savedPolicy').textContent.includes('BG自動開始 許可');")
  check('stale settings save cannot overwrite newer settings; explicit reload restores saved policy with native Web Locks')
  async_js("const done=arguments[arguments.length-1];chrome.storage.local.set({rsp_dashboard_defaults:{splitMin:'invalid'}}).then(()=>done(true));")
  js("document.getElementById('reloadSettings').click();")
  wait("return document.getElementById('saved').textContent.includes('読み込めません');")
  assert js("return document.getElementById('save').disabled;")
  async_js("const done=arguments[arguments.length-1];chrome.storage.local.set({rsp_dashboard_defaults:{autoStartAllowed:false,enabled:true,splitMin:0}}).then(()=>done(true));")
  js("document.getElementById('reloadSettings').click();")
  wait("return !document.getElementById('save').disabled && document.getElementById('savedPolicy').textContent.includes('BG自動開始 禁止');")
  check('malformed saved settings disable save; reload after repair restores editing without silently overwriting data')
  # Real Firefox DOM tests for the local inspector and full generated player route watcher.
  cmd('POST','/url',{'url':f'moz-extension://{uuid}/media_inspect.html'})
  js("window.__diagnosticFetches=0;window.__originalFetch=window.fetch;window.fetch=()=>{window.__diagnosticFetches++;throw Error('unexpected diagnostic fetch');};document.getElementById('url').value='https://example.invalid/private/live.m3u8?token=DO_NOT_EXPORT#fragment';document.getElementById('mime').value='audio/mpegurl';document.getElementById('body').value='#EXTM3U\\n#EXTINF:2,\\nsegment.ts?token=DO_NOT_EXPORT';document.getElementById('inspect').click();")
  diagnostic=js("return document.getElementById('result').textContent;");parsed=json.loads(diagnostic);assert parsed['classification']['type']=='hls' and parsed['hls']['segments']==1 and 'DO_NOT_EXPORT' not in diagnostic and 'private' not in diagnostic
  js("document.getElementById('generate').click();")
  generated=js("return document.getElementById('command').value;");assert 'ffmpeg -n ' in generated and 'curl.exe' in generated and '--no-clobber' in generated and 'DO_NOT_EXPORT' in generated
  assert js('return window.__diagnosticFetches;')==0;check('real Firefox local media inspector omits URL secrets from diagnostics and makes zero fetch requests')
  check('real Firefox explicit PowerShell command generation keeps -n and no-clobber; does not execute commands')
  js("window.Hls={isSupported:()=>true};window.flvjs=undefined;window.fetch=async url=>String(url).includes('/live/play')?new Response(JSON.stringify({streamState:'offline'}),{status:200,headers:{'content-type':'application/json'}}):new Response('',{status:404});history.replaceState(null,'','/live?creatorOid='+arguments[0]);",['a'*24])
  js((R/'rplay-stable-player-extension-firefox/content.js').read_text())
  wait("return window.__RSP&&window.__RSP.engine&&window.__RSP.engine.id==='"+'a'*24+"';")
  assert js("return document.querySelectorAll('#rsp-panel').length;")==1;check('full generated player mounts /live?creatorOid in real Firefox DOM with mocked API/HLS')
  js("history.pushState(null,'','/live?creatorOid='+arguments[0]);",['b'*24]);wait("return window.__RSP&&window.__RSP.engine&&window.__RSP.engine.id==='"+'b'*24+"';")
  assert js("return document.querySelectorAll('#rsp-panel').length;")==1;check('full generated SPA watcher switches creator on query-only navigation')
  js("window.__priorRSP=window.__RSP;history.pushState(null,'','/live?creatorOid='+arguments[0]+'&tracking=changed');",['b'*24]);time.sleep(1.7);assert js('return window.__RSP===window.__priorRSP;');check('tracking-only query change preserves current player instance')
  url=f'moz-extension://{uuid}/mp4_convert.html';cmd('POST','/url',{'url':url});wait("return !document.getElementById('choose').disabled;")
  capability=js("return {picker:typeof showSaveFilePicker,worker:typeof Worker,opfs:typeof navigator.storage.getDirectory,ua:navigator.userAgent};");assert capability['picker']=='undefined';assert capability['worker']=='function';check('Firefox file-input/Worker/OPFS path enabled without native picker',capability)
  first=convert(av);assert first['receipt']['audio'] and first['receipt']['aacFrames']>0 and first['receipt']['aacPayloadHashVerified'];check('real Worker mono 44.1kHz conversion and source/output AAC conservation',first)
  p=download_file();check('real extension downloads API completion + size + independent disk SHA-256',{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
  probe=json.loads(run(['ffprobe','-v','error','-show_streams','-of','json',str(p)]));assert {s['codec_name'] for s in probe['streams']}=={'h264','aac'};audio=next(s for s in probe['streams'] if s['codec_type']=='audio');assert audio['channels']==1 and audio['sample_rate']=='44100';run(['ffmpeg','-v','error','-xerror','-i',str(p),'-f','null','-']);check('downloaded MP4 ffprobe stream settings and FFmpeg full decode',{'streams':len(probe['streams']),'audio_rate':audio['sample_rate']})
  expected=run(['ffmpeg','-v','error','-i',str(av),'-map','0:v:0','-f','framemd5','-']).splitlines();actual=run(['ffmpeg','-v','error','-i',str(p),'-map','0:v:0','-f','framemd5','-']).splitlines();hashes=lambda lines:[line.split(',')[-1].strip() for line in lines if not line.startswith('#')];assert hashes(expected)==hashes(actual);check('decoded video frame MD5 equals source TS')
  # Independent flat MP4 control separates container failure from missing host decoder.
  original_url=js("return document.getElementById('download').href;")
  choose([control]);js("const v=document.getElementById('preview');v.src=URL.createObjectURL(document.getElementById('file-chooser').files[0]);v.muted=true;v.play().catch(()=>{});")
  time.sleep(2)
  control_state=js("const v=document.getElementById('preview');return {time:v.currentTime,width:v.videoWidth,error:v.error&&v.error.code,can:v.canPlayType('video/mp4; codecs=\"avc1.42E01E,mp4a.40.2\"')};")
  print('CONTROL_MEDIA',control_state,flush=True)
  js("const v=document.getElementById('preview');v.pause();v.src=arguments[0];v.muted=true;v.play().catch(()=>{});",[original_url]);time.sleep(2)
  media_state=js("const v=document.getElementById('preview');return {time:v.currentTime,width:v.videoWidth,height:v.videoHeight,error:v.error&&v.error.code,ready:v.readyState,network:v.networkState};")
  print('CONVERTED_MEDIA',media_state,flush=True)
  if media_state['width']==320 and media_state['height']==180 and media_state['ready']>=1:check('Firefox native preview parses generated MP4 video metadata',media_state)
  if not control_state.get('error') and control_state['time']>0:
   assert not media_state.get('error') and media_state['time']>0 and media_state['width']==320 and media_state['height']==180
   check('Firefox H.264/AAC preview decodes and playback time advances',media_state)
  else:
   checks.append({'test':'Firefox native H.264/AAC preview','pass':False,'status':'BLOCKED_PREVIEW_ENVIRONMENT','detail':{'control_flat_mp4':control_state,'converted':media_state}})
  js("document.getElementById('preview').pause();");screenshot('firefox158-converted.png')
  jobs=list_jobs();job=first['receipt']['id'];assert any(j['id']==job for j in jobs['jobs'])
  cmd('POST','/refresh',{});wait("return !document.getElementById('choose').disabled;");assert js("return document.getElementById('staged').textContent.includes('照合して保存');")
  js("document.querySelector('#staged button').click();");wait("return !document.getElementById('choose').disabled;");assert first['receipt']['sha256'] in js("return document.getElementById('status').textContent;");check('page reload retains OPFS output; recovery rehash succeeds')
  before=len(list_jobs()['jobs']);bad=media/'bad.ts';bad.write_bytes(b'broken');choose([bad]);js("document.getElementById('start').click();");wait("return !document.getElementById('choose').disabled;");assert js("return document.getElementById('download').hidden;");assert len(list_jobs()['jobs'])==before;check('invalid TS does not expose stale download or leave new completed stage')
  # Equal-length tampering must not be accepted during recovery.
  tamper=async_js("const id=arguments[0],done=arguments[arguments.length-1];(async()=>{const root=await navigator.storage.getDirectory(),area=await root.getDirectoryHandle('rsp_mp4_v222'),dir=await area.getDirectoryHandle(id),h=await dir.getFileHandle('output.mp4'),f=await h.getFile(),bytes=new Uint8Array(await f.arrayBuffer());bytes[0]^=1;const w=await h.createWritable();await w.write(bytes);await w.close();return true;})().then(done,e=>done({error:e.name+':'+e.message}));",[job]);assert tamper is True,tamper
  js("document.querySelector('#staged button').click();");wait("return !document.getElementById('choose').disabled;");assert js("return document.getElementById('status').textContent.includes('ハッシュが一致しません');");assert js("return document.getElementById('download').hidden;");check('equal-length OPFS tampering rejected before download')
  # Remove only the explicit corrupt job, then reconvert another codec configuration.
  discarded=async_js("const done=arguments[arguments.length-1];run('discard',{jobId:arguments[0]}).then(done,e=>done({error:e.message}));",[job]);assert discarded.get('type')=='discarded'
  second=convert(stereo);assert second['receipt']['aacPayloadHashVerified'];p2=download_file();s2=json.loads(run(['ffprobe','-v','error','-show_streams','-of','json',str(p2)]));a2=next(s for s in s2['streams'] if s['codec_type']=='audio');assert a2['sample_rate']=='48000' and a2['channels']==2;check('48kHz stereo TS converts and downloads with correct AAC configuration')
  silent=convert(video);assert silent['receipt']['audio'] is False;pv=download_file();sv=json.loads(run(['ffprobe','-v','error','-show_streams','-of','json',str(pv)]));assert len(sv['streams'])==1 and sv['streams'][0]['codec_type']=='video';check('video-only TS converts without phantom AAC track')
  # Codec/config changes must not silently create a mixed output.
  before=len(list_jobs()['jobs']);choose([av,stereo]);js("document.getElementById('start').click();");wait("return !document.getElementById('choose').disabled;")
  assert js("return document.getElementById('download').hidden;");assert len(list_jobs()['jobs'])==before;check('incompatible TS codec configuration rejected without committing output')
  segments=media/'segments';segments.mkdir(exist_ok=True)
  run(['ffmpeg','-v','error','-y','-i',str(av),'-map','0','-c','copy','-f','segment','-segment_time','2','-reset_timestamps','0',str(segments/'part%02d.ts')])
  parts=sorted(segments.glob('*.ts'));assert len(parts)>=2
  choose(list(reversed(parts)));names=js("return Array.from(document.querySelectorAll('#items li span')).map(n=>n.textContent.split(' / ')[0]);");assert names==[p.name for p in parts]
  js("document.getElementById('start').click();");wait("return !document.getElementById('choose').disabled;");assert js("return !document.getElementById('download').hidden;"),js("return document.getElementById('status').textContent;")
  last_receipt=list_jobs()['jobs'][0];multi=download_file();run(['ffmpeg','-v','error','-xerror','-i',str(multi),'-f','null','-'])
  combined=run(['ffmpeg','-v','error','-i',str(multi),'-map','0:v:0','-f','framemd5','-']).splitlines();assert hashes(combined)==hashes(expected);check('multiple continuous TS parts naturally sorted, combined and decoded video matches original',{'parts':len(parts),'bytes':multi.stat().st_size})
  # Select video-only again for the bounded-memory worker test.
  choose([video])
  # Read-only File, real Worker, bounded in-memory fallback (no private disk stage).
  memory=async_js("const done=arguments[arguments.length-1],file=document.getElementById('file-chooser').files[0];run('convert',{inputs:[file],fileInputs:true,forceMemory:true}).then(m=>done({type:m.type,receipt:m.receipt,size:m.file&&m.file.size}),e=>done({error:e.message}));");assert memory['type']=='ready' and memory['receipt']['mode']=='memory' and memory['receipt']['bytes']==memory['size'];check('actual Firefox Worker memory fallback converts without OPFS',memory)
  padded=media/'cancel_large.ts';packet=bytes([0x47,0x1f,0xff,0x10])+bytes([0xff])*184
  with padded.open('wb') as f:
   f.write(av.read_bytes());block=packet*4096
   for _ in range(128):f.write(block)
  before=len(list_jobs()['jobs']);choose([padded]);js("window.__heartbeat=0;window.__beat=setInterval(()=>window.__heartbeat++,20);document.getElementById('start').click();")
  wait("return !document.getElementById('cancel').disabled;",10);js("document.getElementById('cancel').click();");wait("return !document.getElementById('choose').disabled;",90);assert js("return document.getElementById('status').textContent.includes('中止しました');");assert len(list_jobs()['jobs'])==before;beats=js("clearInterval(window.__beat);return window.__heartbeat;");check('real Worker cancellation aborts conversion and keeps staged outputs unchanged',{'input_bytes':padded.stat().st_size,'ui_heartbeat':beats})
  # A live Web Lock protects a conversion job from another view's cleanup.
  protected=list_jobs()['jobs'][0]['id']
  js("window.__lockGranted=false;window.__holdJob=new Promise(r=>window.__releaseJob=r);navigator.locks.request('rsp-mp4-job-'+arguments[0],async()=>{window.__lockGranted=true;await window.__holdJob;});",[protected]);wait("return window.__lockGranted;")
  refusal=async_js("const done=arguments[arguments.length-1];run('discard',{jobId:arguments[0]}).then(done,e=>done({error:e.message}));",[protected]);assert refusal.get('error')=='STAGED_JOB_BUSY';js("window.__releaseJob();");check('real Web Locks refuse cross-view deletion of an active staged job')
  orphan=async_js("const done=arguments[arguments.length-1],w=new Worker('mp4_convert_worker.js'),file=document.getElementById('file-chooser').files[0];w.onmessage=({data:m})=>{if(m.type==='progress'&&m.progress.phase==='preflight'){w.terminate();done(true);}else if(m.type==='error'){w.terminate();done({error:m.error});}};w.onerror=e=>{w.terminate();done({error:e.message});};w.postMessage({id:'crash-test',type:'convert',inputs:[file],fileInputs:true});")
  assert orphan is True,orphan
  assert len(list_jobs()['incomplete'])==1
  async_js("const done=arguments[arguments.length-1];refreshStages().then(()=>done(true),e=>done({error:e.message}));")
  js("document.querySelector('.orphan-delete').click();");wait("return !document.getElementById('choose').disabled;");assert not list_jobs()['incomplete'];check('terminated Worker leaves a discoverable owned partial job; explicit UI cleanup removes it safely')
  cmd('POST','/window/rect',{'width':600,'height':900});assert js("return document.documentElement.scrollWidth<=window.innerWidth;");screenshot('firefox158-narrow.png');check('600px window layout has no horizontal overflow')
  if args.large:
   large=make('large_cbr.ts',rate=48000,channels=1,duration=50,cbr=True);assert large.stat().st_size>64*1048576
   choose([large]);js("window.__heartbeat=0;window.__beat=setInterval(()=>window.__heartbeat++,20);document.getElementById('start').click();");wait("return !document.getElementById('choose').disabled;",180);assert js("return !document.getElementById('download').hidden;"),js("return document.getElementById('status').textContent;");beats=js("clearInterval(window.__beat);return window.__heartbeat;");assert beats>10;last_receipt=list_jobs()['jobs'][0];pbig=download_file();run(['ffmpeg','-v','error','-xerror','-i',str(pbig),'-f','null','-']);check('actual Firefox large >64MiB TS -> verified OPFS -> downloaded MP4 full decode; UI responsive',{'input_bytes':large.stat().st_size,'output_bytes':pbig.stat().st_size,'ui_heartbeat':beats})
  for p in [av,stereo,video]:assert hashlib.sha256(p.read_bytes()).hexdigest()==initial_hashes[p.name]
  check('all source TS hashes unchanged after conversions/cancellation/recovery')
  blocked=sum(not c['pass'] for c in checks)
  summary={'status':'PARTIAL' if blocked else 'PASS','passed_checks':len(checks)-blocked,'blocked_checks':blocked,'browser':'Firefox '+caps['browserVersion'],'geckodriver':'explicit CLI binary','os':os.uname().sysname,'headless':True,'content_sandbox_relaxed':args.relax_content_sandbox,'extension_install':'temporary unsigned (test profile)','checks':checks,'total_checks':len(checks),'not_tested':['Windows','real RPLAY','2GiB input boundary','hours-long conversion','hardware-specific AV sync'],'date_jst':'2026-10-27'}
  (out/'FIREFOX_FAILURE.json').unlink(missing_ok=True)
  (out/'FIREFOX_ACCEPTANCE.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print('FIREFOX_ACCEPTANCE_DONE',len(checks)-blocked,'PASS',blocked,'BLOCKED',flush=True)
 except Exception as e:
  (out/'FIREFOX_FAILURE.json').write_text(json.dumps({'error':str(e),'passed':checks},ensure_ascii=False,indent=2)+'\n')
  if sid:
   try:screenshot('firefox-failure.png')
   except Exception:pass
  raise
 finally:
  if sid:
   try:req('DELETE','/session/'+sid)
   except Exception:pass
  if process:
   process.terminate()
   try:process.wait(5)
   except subprocess.TimeoutExpired:process.kill();process.wait()
  if log:log.close()
  scratch.cleanup()
if __name__=='__main__':main()
