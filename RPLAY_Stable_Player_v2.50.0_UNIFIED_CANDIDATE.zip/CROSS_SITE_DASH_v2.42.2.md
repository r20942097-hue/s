# Cross-site DASH candidate v2.42.2

## Changes from v2.42.1

- Uses the existing user-triggered HLS inspector workflow to fetch a DASH MPD as well, if the observed URL ends with `.mpd` or the candidate has DASH MIME metadata. The original signed URL bytes are retained in the request and do not appear in the serialized diagnosis. Cookie sending is **off by default**, opt-in per click; redirects are disabled. No new browser permissions.
- Bounded XML tokenizer reads a maximum 2 MiB MPD locally; no DTD/entity expansion, no XLink or segment fetching. Measures Period, AdaptationSet, Representation, audio/video, SegmentTemplate/List/Base, Timeline S repeat counts and unbounded `r=-1`, ContentProtection and possible external XLink. Dynamic MPD `minimumUpdatePeriod` is reported but **never automatically polled**. MPD inheritance, namespace validation, DRM, rendering and clock availability are **not** fully implemented. Only a diagnostic summary is produced; not a full MPEG-DASH parser.
- `media_inspect_core` and cross-site page offer an MPD diagnostic when the text body is XML or DASH-typed; HLS behavior stays unchanged.
- HLS LL delta `#EXT-X-SKIP` diagnostics now account for `SKIPPED-SEGMENTS` when numbering visible segments. This change applies only to `cross_site_core.js` diagnostics: the original recorder's `hls_transport.js` continues to reject delta SKIP; no new recorder execution path is introduced.

## Explicitly not implemented

- DASH stream download, SegmentTemplate substitution, live media acquisition, licence/key retrieval, access-control bypass, automatic signed-URL refresh or Nico session protocol support.
- Verification on logged-in Niconico/YouTube/Twitch and Firefox/Floorp real browser, long live recording, AV continuity decoding.
- Actual HLS downloaded-segment accounting: observed manifest indices are not evidence of completed recording.

## Acceptance

Use `node --test tests/test_v2422_dash.cjs tests/test_cross_site_integration.cjs tests/test_v2420_request_context.cjs tests/test_v2410_media_catalog.cjs` and `python tests/browser/test_v2422_dash_ui.py` for changed-surface checks. The Chromium DOM test does not install an extension and stubs the transport to avoid external fetching.

Status: **CANDIDATE / NO_GO** until real browser/site capture and media validation are completed. Use on user-authorized media only.
