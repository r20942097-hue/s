# VDH・HLS取得の調査と開発反映 — 2026-10-27 JST

調査範囲は公式Web資料と公開README。VDHの内部ソース全体や非公開engineを取得・逆解析したという意味ではない。コードのコピーは行っていない。

|参照|確認した要点|今回の開発判断|
|---|---|---|
|VDH Basic Usage|検出候補の一覧、取得操作、形式選択|候補→目録確認→画質/音声選択の操作を独立実装|
|VDH Non-premium restrictions|単一ファイルと、HLS等の再構成取得を区別|拡張子変更を変換完了と扱わない。VDHの料金制御は変更しない|
|RFC8216|セグメント順序、目録更新間隔、別renditionの独立sequence、discontinuity|FIFO取得と形式境界を維持。異なる画質の同じsequenceを同じ映像と決めつけない|
|puemos/hls-downloader 公開README|画質・音声選択、disk-backed merge|選択UIとRAM上限を優先。wasm muxは今回追加しない|
|FFmpeg公式 HTTP protocol|再接続設定、Retry-After等|無制限再試行を推奨しない。今回のブラウザ404猶予は独自の限定設計|

https://help.downloadhelper.net/article/4-basic-usage
https://help.downloadhelper.net/article/29-non-premium-restrictions
https://www.rfc-editor.org/rfc/rfc8216.html
https://github.com/puemos/hls-downloader
https://ffmpeg.org/ffmpeg-protocols.html#http

HLS取得は、masterを読む→variant/音声を選ぶ→選択したmedia playlistを読む→segmentと必要なMAP/Rangeを順番に取得→容器に応じて保存/結合→必要ならremux→独立検証、という手順に分ける。候補検出、目録取得、動画取得、ディスク保存、デコード成功は別の段階。

今回: 既存権限のHTTPS範囲内で応答URL/MIMEを観察（webRequest追加）、候補URLをメモリ内だけに保持。ユーザーが選んでから目録を明示取得。汎用目録取得はCookie/JWT/Butterを付けず、鍵や動画本体を自動取得しない。別音声は任意の第2入力としてFFmpegコマンドへ明記。

星の意味は今回も未確定。公式Basic Usage本文だけでは星の位置・版との対応を特定できず、tooltip等の直接根拠なしにpremium/DRM/推奨画質とは断定しない。
