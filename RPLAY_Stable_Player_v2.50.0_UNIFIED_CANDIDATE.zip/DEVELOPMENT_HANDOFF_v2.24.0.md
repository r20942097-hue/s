# v2.24.0 引き継ぎ

v2.23.0からの限定修正。src/player.user.js の Recorder.probePlaylist と fetchPlaylistOnce、src/hls_transport.js の明示的Butterヘッダーに変更。

録画判定は200だけではliveにしない。EXTM3U先頭、EXTINF、ENDLIST優先、master childのHTTP/本文を判定する。
Butter再試行は同じ_hlsPlaylistTransferと2MiB制限を利用し、本文中timeout・stop時abort・HLS.alive世代判定を維持する。

追加9件は tests/test_v2240_recording.cjs。helpers_hls.cjsは任意のRECENVを注入可能にした。5つの生成録画コアはbuild.pyで統一。

改善候補と採否は IMPROVEMENTS_v2.24.0.md。古いQA/evidenceは各旧版の履歴。現在版の結果は QA_v2.24.0.md と evidence/v224-current、evidence/firefox-v224 を参照。

python scripts/build.py
python scripts/validate.py --output-dir /outside/project/evidence
python scripts/test_firefox_mp4.py --firefox /path/firefox --geckodriver /path/geckodriver --output-dir /outside/project/evidence --relax-content-sandbox --large
python scripts/package_release.py /outside/project/output.zip

Firefoxのsandbox調整は隔離された使い捨て試験プロファイルだけ。製品は変更しない。実RPLAY・Windows・長時間・2GiB・preview進行の合格は未取得。
