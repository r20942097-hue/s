(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.RspPreviewDiag=api;})(globalThis,function(){
 'use strict';
 /* ---- v2.44.0: native preview環境要因の切分け (parallel line v2.39.0実装の統合) ----
    変換後MP4のプレビュー(<video id="preview">)が失敗・停止するとき、保存・
    構造照合とは独立に「なぜ再生できないか」を分類して表示する。診断は表示
    のみで、変換・保存・照合・ダウンロードの経路には影響しない。
    - 分類: NO_DECODER(環境: canPlayType空 or MEDIA_ERR_SRC_NOT_SUPPORTED=4) /
      AUTOPLAY_BLOCKED(操作: play()がNotAllowedError) /
      DECODE_ERROR(内容確認: MEDIA_ERR_DECODE=3) /
      FROZEN_CLOCK(環境: 再生中なのにcurrentTimeが進まない) /
      PLAYBACK_OK(前進を確認) / UNKNOWN。
    - 優先順位は NO_DECODER > AUTOPLAY_BLOCKED > DECODE_ERROR > FROZEN_CLOCK。
    - canPlayTypeは荒い指標のため「対応している」とは断定せず、空のときのみ
      非対応とみなす。FROZEN_CLOCKも「〜とみられます」までの表現とする
      (v2.36.0受入では制御MP4でも時計が0のまま=環境要因の観察がある)。
    - watchClockはplay後の時計監視(既定 interval 250ms・判定しきい値1500ms・
      前進判定0.2秒。テスト用にopts.interval/opts.threshold/opts.advanceで
      縮小可)。pause/ended/errorでは呼び出し側がstop()する。 */
 const CODEC='video/mp4; codecs="avc1.42E01E,mp4a.40.2"';
 function codecSupport(v){
  const ask=t=>{try{return v&&typeof v.canPlayType==='function'?String(v.canPlayType(t)):'';}catch(e){return '';}};
  return {video:ask('video/mp4; codecs="avc1.42E01E"'),audio:ask('audio/mp4; codecs="mp4a.40.2"'),combined:ask(CODEC)};
 }
 function classifyPreview(s){
  if(!s)s={};
  if(s.errorCode===4||s.canPlay==='')return {factor:'environment',code:'NO_DECODER',message:'プレビュー診断: このブラウザーはH.264/AACの再生に対応していないため、プレビューを表示できません（環境要因）。変換結果の保存・構造照合には影響しません。VLCなどの対応プレイヤーで確認してください。'};
  if(s.playRejection==='NotAllowedError')return {factor:'policy',code:'AUTOPLAY_BLOCKED',message:'プレビュー診断: ブラウザーが自動再生をブロックしました（操作要因）。動画のコントロールで再生を押してください。'};
  if(s.errorCode===3)return {factor:'content',code:'DECODE_ERROR',message:'プレビュー診断: 再生中にデコードエラーが発生しました（内容の確認が必要）。「検証レポートを保存」で記録を確認し、対応プレイヤーでの再生も確認してください。'};
  if(s.timeAdvanced===false)return {factor:'environment',code:'FROZEN_CLOCK',message:'プレビュー診断: 再生を開始しましたが再生時刻が進んでいません。この環境での映像デコード・描画の制限とみられます（環境要因）。変換結果の保存・構造照合には影響しません。対応プレイヤーで確認してください。'};
  if(s.timeAdvanced===true)return {factor:'none',code:'PLAYBACK_OK',message:'プレビューは再生されています。映像・音声の同期を確認してください。'};
  return {factor:'unknown',code:'UNKNOWN',message:'この環境ではプレビューを再生できません。MP4の保存・構造照合とは別に、対応プレイヤーで確認してください。'};
 }
 function videoState(v,extra){
  const s={canPlay:codecSupport(v).combined,errorCode:v&&v.error?v.error.code:null,playRejection:null,timeAdvanced:null,readyState:v?v.readyState:0,paused:v?!!v.paused:true};
  if(extra)for(const k in extra)s[k]=extra[k];
  return s;
 }
 function watchClock(v,opts){
  opts=opts||{};
  const interval=Math.max(1,opts.interval||250),threshold=Math.max(1,opts.threshold||1500),advance=Math.max(0.01,opts.advance||0.2);
  let stopped=false,elapsed=0,best=-Infinity,base=null,done=false,timer=null;
  const finish=()=>{if(stopped)return;stopped=true;if(timer!==null&&typeof clearInterval==='function')clearInterval(timer);};
  const tick=()=>{
   if(stopped)return;
   const t=Number(v&&v.currentTime)||0;
   if(base===null)base=t;
   if(t>best+1e-4){best=t;elapsed=0;}else{elapsed+=interval;}
   if(!done&&t-base>=advance){done=true;finish();if(opts.onOk)opts.onOk();return;}
   if(!done&&elapsed>=threshold&&!v.paused&&(v.readyState===undefined||v.readyState>=2)){done=true;finish();if(opts.onFrozen)opts.onFrozen(videoState(v,{timeAdvanced:false}));}
  };
  timer=setInterval(tick,interval);
  return {stop:finish};
 }
 return {CODEC:CODEC,codecSupport:codecSupport,classifyPreview:classifyPreview,videoState:videoState,watchClock:watchClock};
});
