# v2.30.0

scanSchedulesにbusy/finallyとUI detachガード、最大100件、進捗。現在ページと同じお気に入りも保存するよう修正。ensurePoolは登録集合を毎回読み、basePoolキャッシュと合流。公開IDは登録解除でも公共候補として残る。
次: schedule APIのAbortSignal所有、完了後即時再試行UX、公式の名前URL解決、登録者メタデータcache、BG自動組立の移行設計。
