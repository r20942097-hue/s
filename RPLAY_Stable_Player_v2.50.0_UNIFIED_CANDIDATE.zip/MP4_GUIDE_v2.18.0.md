# v2.18.0 MP4変換・検査

操作はmp4_convert.htmlでTS選択→順序確認→別のMP4保存先を指定します。保存先は既存の重要ファイルを避けてください。検査中/変換中に中止できます。元TSは保持します。

## 保存前の検査

従来のPSI CRC・PAT/PMT・CC・コーデック検査と入力ハッシュに加え、映像/音声PIDに対して以下を検査します。

- PES start code、stream ID、MPEG-2ヘッダー、スクランブルフラグ、宣言長、オプションヘッダー長、PTS/DTSのフラグとマーカービット。
- 音声PESの宣言長と実際のバイト数。途中で切れたPESを拒否します。
- ADTS同期語、ヘッダー/フレーム長、サンプルレート/チャネル構成、1フレーム1 raw_data_block、PES境界でのフレーム完結。
- H.264 Annex-B開始コード、NALヘッダーのforbidden_zero_bitと基本type範囲、末尾で切れたヘッダー、空NALの一部。

入力が完全に正常であるとの証明ではありません。H.264 slice/RBSPの全構文、映像フレーム内容、AAC圧縮データの意味やADTS CRCはデコード/照合していません。

## 出力を確定する前の照合

入力ADTSフレーム数と、mux.jsが出力した音声トラックのtrun sample_countの合計を照合します。1 ADTSフレームに複数raw_data_blockを持つ入力は受理しません。不一致はMP4_AAC_FRAME_COUNT_MISMATCHとしてwriter.abort()し、保存確定を行いません。音声のビット内容が同一であることを本番画面で全デコード検証する機能ではありません。

mediaIntegrityEvidenceにはvideoPes/audioPes/aacFrames/aacPayloadBytes/nalUnits/outputAacSamples/aacFrameCountConserved等を記録します。aacPayloadBytesは音声PESのペイロードであるADTSヘッダーを含むフレーム列のバイト数です。h264Decoded=false、aacCrcVerified=falseを明記します。画面では音声フレーム数を表示します。

出力確定後、サイズとSHA-256を読戻して照合します。確定後の検証失敗では、既存出力が既に置換されている場合があり、自動ロールバックはしません。

## 互換性と制限

- 入力1本2GiBまで・最大4096本、H.264映像1トラックと同じTS内AAC最大1トラック。2GiB実入力と数時間運用は未検証です。
- 既定8MiB読込み・16MiB目安のGOP/PES区切り・保持TS32MiB上限。ブラウザ全体の使用メモリ上限ではありません。
- AACフレームがPESを跨ぐ構造はTS_AAC_PES_BOUNDARY_UNSUPPORTEDで拒否します。合法なTSでも今回の変換方式に対応しない場合があります。
- AAC構成変更、PCEによるチャネル構成0、複数raw_data_block、無長音声PES等は拒否します。未対応入力を黙って変換しません。
- 不明長の映像PES内で切れたNAL/RBSPの全てを検出できるわけではありません。破損修復や全プレイヤー互換性は保証しません。
- DTSを共通原点に補正し、Bフレームの並べ替え遅延と音声/映像の開始差を保持します。今回のBフレーム素材では表示開始が約0.057秒残り、これは音声を削って0へ詰める処理ではありません。
- File System Access API非対応ブラウザでは変換不可です。拡張導入・OSダイアログは今回も未検証です。

## エラーの例

| 表示コード | 意味 |
|---|---|
| TS_PES_TRUNCATED | PES宣言長に対して入力が不足 |
| TS_PES_HEADER_TRUNCATED | PESヘッダーが途中で終了 |
| TS_AAC_TRUNCATED | 最後のAACフレームが未完 |
| TS_AAC_PES_BOUNDARY_UNSUPPORTED | AACフレームがPES境界を跨ぐ |
| TS_H264_NAL_HEADER / TS_H264_HEADER_TRUNCATED | NALヘッダーが不正/不足 |
| MP4_AAC_FRAME_COUNT_MISMATCH | 入力AACと出力MP4音声サンプル数が不一致 |

入力異常時は元の録画を確認してください。任意のバイト位置でTSを切り貼りしての修復は想定していません。
