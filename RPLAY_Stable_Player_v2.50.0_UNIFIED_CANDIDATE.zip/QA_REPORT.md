# RPLAY Stable Player v2.10.0 — 統合開発・品質報告

2026-10-26 JST。直前版: v2.9.0 UNIFIED CANDIDATE(284試験)。
旧ZIPは保持。**CANDIDATE / NO_GO**。

## 変更範囲（開発計画v2.10.0：TS細切れ防止 & Video DownloadHelper / Streamlink / rplay_watcher v0.5.2 知見統合）

1. **W-05 MPEG-TS EXT-X-DISCONTINUITY 連続追記（P1・両コア鏡像）**:
   `src/hls_transport.js`(`partBoundary` / `append`) と `src/hls_transport.py`(`hls_part_boundary` / `Dl._append_hls`) を更新。MPEG-TS(`!d.map`)では既定(`splitOnDiscontinuity=false`)で `EXT-X-DISCONTINUITY` によるパート分割を行わず単一 `.ts` ファイルへ連続追記し、`discontinuityMergedCount` を計上。fMP4(`d.map`)および世代変化(`epoch`)は従来どおりパート境界分割を維持。
2. **W-06 時間分割既定0化・OPFS/FSA上限拡大・複数パート無劣化自動結合（P1）**:
   - `player.user.js` / `offscreen_pre.js` / `ext_glue.js` / `cli.py` の `splitMin` / `--split-min` 既定値を `20` から `0`(時間分割なし)へ変更。
   - `offscreen_pre.js` の `partByteLimit` を `64 MiB` から `512 MiB` へ拡大し、FSA `dirHandle` 直書き時は `fileCapBytes()` で `2048 MiB`(2 GiB)まで単一ファイルを継続。
   - `cli.py` に `concat_media_parts()` と `--concat-parts {auto,mp4,ts,no}` を追加し、FFmpeg concat demuxer(`-f concat -safe 0 -c copy`)またはバイナリTS連結で単一ファイルへ無劣化結合。
3. **W-07 セグメントHTTP 503 Retry-After対応 & Master 200 / Media 404 Paywall検出（P1）**:
   - `recFetchDescriptor`(JS) と `Dl._hls_status`(Python) で HTTP 503 の `Retry-After` ヘッダ退避を実装。
   - `rspDetectPaywallBlocked`(JS) と `detect_paywall_blocked`(Python) で Master 200 / Variant 404(または403)の非対称応答を検出し、`AUTH` 分類計上と `paywall_blocked` ログ出力を実装。
4. **W-08 `partContinuityEvidence` 証拠ブロック & 版ピン2.10.0統一（P1）**:
   - 情報JSONおよび `ledger.json` に `partContinuityEvidence` を出力し、JS/Python相互言語一致試験で固定。全館の版表記を `2.10.0` に統一。

## 実測検証(作業環境)

| 種類 | 今回の結果 | 注記 |
|---|---|---|
| Node.js | **177 PASS** | 既存171 + 新規6(版ピン/TS DISCONTINUITY連続追記/splitMin=0・512MB上限/503 Retry-After/相互言語鏡像/連続性証拠) |
| Python | **119 PASS** | 既存113 + 新規6(hls_part_boundary/503 Retry-After/paywall・証拠/concat_media_parts/単一TS連続記録E2E/paywall_blocked E2E) |
| 総数 | **296 PASS** | 同一試験の再実行を加算しない |
| 生成録画コア | 5か所同一ハッシュ | `5786f4e3dc71d826f10db44934ec40214b3bcbb0b5199492fac7c8a7e63a9271` |
| TS不連続単一ファイルE2E | 3seg/2不連続→1ファイル | 従来3ファイルに細切れ化していたケースが1本の連続TSに保存されることを実測 |
| クリーン展開 | 再検証PASS | ZIP展開→ハッシュ照合→296試験再実行 |

## 前版までの報告

# RPLAY Stable Player v2.9.0 — 統合開発・品質報告

2026-10-26 JST。直前版: v2.8.0 UNIFIED CANDIDATE(272試験)。
旧ZIPは保持。**CANDIDATE / NO_GO**。

## 変更範囲（開発計画v2.9.0のA-09字幕対応 第一段階「観測と証拠」）

1. **A-09-1 字幕レンディション解析（P1・両コア鏡像）**: master playlistの
   `#EXT-X-MEDIA:TYPE=SUBTITLES` を解析する `parse_subtitle_renditions`(Python) /
   `parseSubtitleRenditions`(JS) を追加。レンディション毎に groupId・name・language・
   assocLanguage・default・autoselect・forced・hasUri の固定鍵集合を記録。
   **URI値は一切出力しない**(署名クエリ混入防止・URL秘匿契約。取得可否のみhasUri)。
   未知の属性(CHARACTERISTICS等)は埋め込まない(A-05未知値非埋込契約の継承)。
   GROUP-ID必須(EXT-X-MEDIA仕様・音声解析と同一契約)。
2. **A-09-2 variant結合属性（P1）**: `#EXT-X-STREAM-INF` の `SUBTITLES="gid"` 属性を
   variant辞書の `subsGroup` として記録(音声AUDIO属性と同形式の鏡像)。
3. **A-09-3 subtitleEvidence証拠ブロック（P1・情報JSON）**: CLI情報JSONと
   ブラウザー情報JSONに `subtitleEvidence`(renditions/renditionCount/variantsLinked/
   policy/provenance/note)を出力。policy=`observed_not_fetched` を契約として明記。
   **master playlist取得済み(非空)のときのみ出力**し、未取得なら証拠ブロックを
   出さない(虚偽のゼロを捏造しない・A-08契約の継承)。JS側は
   `typeof` ガード付き防御的呼び出し(旧試験ハーネスとの互換維持)。
4. **A-09-4 安全側契約（取得しない）**: 字幕レンディションは観測と計数のみ。
   字幕playlist・セグメントの取得は行わない(録画経路・通信量に影響しない)。
   E2E試験で字幕playlistへの取得要求が0回であることを実測で固定。
5. **A-09-5 版ピン2.9.0統一**: @version・Chrome/Firefox manifest(version/
   version_name)・CLI表示・tool文字列・情報JSON toolを2.9.0へ統一。
   旧版ピン試験(v270/v280)は範囲拡張(2.[789].0 / 2.[89].0)で維持、
   新規版ピン試験(v290)で2.9.0を恒久固定。validate.pyの期待値も更新。
6. **文書ギャップ解消**: v2.8.0で未作成だったQA_REPORTのv2.8.0セクションを
   本版で補完(前版として追記)。

## 実測検証(作業環境)

| 種類 | 今回の結果 | 注記 |
|---|---|---|
| Node.js | **171 PASS** | 既存165 + 新規6(版ピン/字幕解析/subsGroup/証拠構造/相互言語/統合ピン) |
| Python | **113 PASS** | 既存107 + 新規6(字幕解析2/結合/契約/相互言語/E2E) |
| 総数 | **284 PASS** | 同一試験の再実行を加算しない |
| 生成録画コア | 5か所同一ハッシュ | `scripts/build.py`再実行でバイト一致 |
| 相互言語鏡像 | 4ベクトル一致 | master/非字幕/空文字/未取得(None)のsubtitleEvidence完全一致 |
| 字幕playlist無取得 | 実測0回 | E2Eで字幕URIへの取得要求が発生しないことを確認 |
| URL秘匿 | SECRET非出力 | 字幕URI(?sig=SECRET)が情報JSON・証拠ブロックに出ない文字列照合 |
| 未知属性非埋込 | 固定鍵集合 | CHARACTERISTICS等が証拠に混入しないことを鍵集合で固定 |
| クリーン展開 | 再検証PASS | ZIP展開→ハッシュ照合→284試験再実行 |

## 秘密の非出力（v2.9.0の検証）

- subtitleEvidenceはURI値を保持しない(hasUriのみ)。E2Eで字幕URIに署名風
  クエリ(?sig=SECRET)を付与し、情報JSON全体に文字列が出ないことを検証した。
- レンディションのname/language等は秘密ではないが、未知の属性は契約により
  埋め込まない(鍵集合試験で恒久固定)。

## 既知の制約（v2.9.0時点）

- 字幕レンディションの実在・言語・形式は実RPLAY配信での観測待ち
  (subtitleEvidenceが実機受入時に答える。ACCEPTANCE.md A15)。
- 字幕の取得・保存・mux(mov_text等)は本版のスコープ外(第二段階で設計)。
  現時点で字幕playlistの取得契約は存在しない。
- 実配信RPLAY・実Chrome/Firefox拡張インストール・Windows・長時間耐久は
  未受入(ACCEPTANCE.md A1〜A15)。**判定はCANDIDATE / NO_GOのまま**。
- refresh-token応答鍵の実測確定(responseKey)はP2のまま(実RPLAYが必要)。

## 前版までの報告

# RPLAY Stable Player v2.8.0 — 統合開発・品質報告(前版・本版で補完)

2026-10-26 JST。直前版: v2.7.0 UNIFIED CANDIDATE(262試験)。
旧ZIPは保持。**CANDIDATE / NO_GO**。

## 変更範囲（rplay_watcher v0.5.0知見統合 & 拡張ホスト証拠対称化 W-01〜W-05）

1. **W-01 Butter署名生成とM3U8 403自動再試行(P1)**: `rplay_watcher` v0.5.0
   (`core/api_client.py`/`ROOT_CAUSE_ANALYSIS.md` §1.1)で解明されたM3U8 403の
   主因(Butterヘッダ欠落/期限切れ)に対処。AES-128-CBCによる128桁hex署名を
   CLI(`generate_butter_token`)とWebCrypto(`butterToken()`)で完全バイト一致実装
   (360秒バケットキャッシュ)。M3U8が初回403を返した際にButterヘッダを付与して
   1回自動再試行し、`authEvidence.butterSent`を記録。
2. **W-02 streamStartTime 10分(600秒)閾値セッション追跡(P1)**: 8状態
   SessionManagerの10分ルールを `rspClassifySessionChange`(JS) /
   `classify_session_change`(Python)として両コアに鏡像実装。600秒以内の
   変化は `same_session_resumed`(瞬断復帰)、600秒超は `new_session_split`
   (別配信枠)。`sessionTrackingEvidence`に記録。
3. **W-03 4層ErrorKind分類体系(P1)**: `core/errors.py`の分類(SOURCE/NETWORK/
   AUTH/PLATFORM/COMPATIBILITY/INTERNAL)を両コアに導入し、recoverableCountと
   sourceFailureCountを`errorTaxonomyEvidence`に記録。
4. **W-04 拡張offscreen/backgroundホストの証拠対称化(P1)**: v2.7.0の残課題
   (拡張録画でauthEvidence未中継)を解消。`ext_glue.js`がrec.start/token.update時に
   秘密ゼロのauthStatsとcanaryEvidenceを中継し、`offscreen_pre.js`がホスト自身の
   401分類・key2再解決・Butter送出・live/play canaryとマージして出力。
5. **W-05 版ピン2.8.0統一(P1)**: @version・manifest×2・CLI文字列・情報JSON toolを
   2.8.0へ統一し、版ピン試験で恒久固定。

## 実測検証(作業環境)

| 種類 | 今回の結果 | 注記 |
|---|---|---|
| Node.js | **165 PASS** | 既存160 + 新規5(版ピン/ext_glue中継/offscreenホスト/相互言語/統合) |
| Python | **107 PASS** | 既存102 + 新規5(Butter単位/セッション/分類/E2E) |
| 総数 | **272 PASS** | 同一試験の再実行を加算しない |
| 生成録画コア | 5か所同一ハッシュ | `scripts/build.py`再実行でバイト一致 |
| Butter相互言語 | 完全バイト一致 | WebCryptoとPython AES-128-CBCが128桁hex一致 |
| Butter再試行E2E | 403→1回再試行成功 | authEvidence.butterSent=Trueを情報JSONで実測 |
| セッション追跡 | 600秒閾値 | 300秒=same_session_resumed・900秒=new_session_split実測 |
| クリーン展開 | 再検証PASS | ZIP展開→ハッシュ照合→272試験再実行 |

## 技術判断

- **Butterの360秒バケットキャッシュ**: 署名は時間バケット単位で決定的であるため、
  同一バケット内の再生成を省略(試験で同値・次バケットで異値を固定)。
- **600秒閾値はrplay_watcher v0.5.0の実測値を継承**: それ未満の再開は同一配信枠、
  超えた場合は別枠としてledgerを分割する(台帳の連続性を壊さない)。
- **ErrorKindは虚偽零を出さない**: 分類できた分だけ計数し、未分類は0と書かない。

## 既知の制約（v2.8.0時点・v2.9.0で一部解消）

- 拡張offscreen録画のauthEvidence/canaryEvidenceはW-04で対称化済み。
- 実配信RPLAY・実Chrome/Firefox拡張インストール・Windows・長時間耐久は
  未受入(ACCEPTANCE.md A1〜A14)。**判定はCANDIDATE / NO_GOのまま**。
- A-03 canaryはlive/play形状のみ観察(認証仕様・署名方式の変化は検知対象外)。

# RPLAY Stable Player v2.7.0 — 統合開発・品質報告

2026-10-25 JST。直前版: v2.6.0 UNIFIED CANDIDATE(230試験)。
旧ZIPは保持。**CANDIDATE / NO_GO**。

## 変更範囲（開発指示プロンプト集v1.0の追加提案A-01〜A-08から実機不要要件を採用）

1. **A-01 認証Refresh-Tokenの段階実装（P1・最優先）**: CLIに`--refresh-token`
   (値直接/env:変数名/file:パスの三種供給)と`--user-oid`(requestorOid補完)を追加。
   AuthStoreが短命JWTの更新ループ(expのleeway 300秒前に再取得・失敗3回再試行・
   60秒クールダウン)を契約化。`--token`(明示指定)が一次で401時だけ自動切替+1回
   再試行(公式interceptorと同一戦略・連打しない)。認証の回避は行わない
   (自分の資格のみ)。応答鍵(jwt/token/…)は非公式情報のため形状証拠として記録。
2. **A-02 auth_store抽象とauthEvidence（P1）**: AuthStore(CLI)/RspAuth(ブラウザー)
   の認証イベントを計数し、authEvidence(認証方式・供給源種別・更新試行/成功/失敗・
   401分類計数・key2再解決回数・応答鍵・butterSent)を情報JSON・ledgerへ統合。
   秘密(トークン値)は一切出さない。両コアで同一鍵構造(相互言語比較試験で固定)。
3. **A-03 サイト更新検知のcanary化（P1）**: live/play応答形状を既知鍵と照合し
   ok/shape_change/unreachableに分類。shape_changeは警告のみで安全側継続
   (録画を止めない)。canaryEvidence(観察鍵一覧・値は出さない)を情報JSONへ記録。
   両コア鏡像(相互言語比較試験で同一判定を固定)。
4. **A-04 通知の豊富化（P2）**: webhookイベントにauth_failed/save_error/
   capacity_warning/merge_completedを追加。全イベントにlevel(info/warn/error)と
   ts(ISO)を付与。429応答のRetry-After退避を優先(上限30秒)。
   notificationEvidence(イベント別計数・429遭遇回数)を情報JSONへ記録。
5. **A-05 MP4メタデータタグ（P2）**: --mux auto|mp4時のリマックス/2トラックmuxに
   rplay_metadata_version=1互換タグ(creator_oid/title/artist/recording_started_at等)を
   埋め込み。**未知の値は埋めない契約**。`-movflags +use_metadata_tags`でカスタム
   鍵を書込み、ffprobe -show_entries format_tagsによる確認手順を試験に組込み。
   metadataEvidence(埋め込みタグ鍵一覧)を情報JSONへ記録。
6. **A-07 合成APIリグレッション（P1・試験資産）**: 認証フロー(refresh-token形状・
   401→更新→再試行・--token優先切替・env/file供給)とlive/play形状canaryを
   ローカルHTTP合成試験として固定。サイト側の形状変化が合成側期待との差分として
   可視化される(開発時の検知・実行時はcanaryが担う二重化)。
7. **A-08 証拠ブロックの拡張（横断）**: authEvidence・canaryEvidence・
   notificationEvidence・metadataEvidenceを既存証拠体系と同形式(虚偽零・出所明示・
   URL秘匿)で追加。ブラウザー側はRECENVフック経由で供給し、offscreen等で
   未供給なら証拠ブロックを出さない(虚偽のゼロを捏造しない)。
8. **版ずれ修正**: manifest version_name(2.5.0のまま)と情報JSON tool文字列
   (v2.5.0のまま)を2.7.0へ統一。版ピン試験(test_v270_core.cjs)で
   @version・manifest×2・CLI文字列を恒久的に固定。

## 実測検証(作業環境)

| 種類 | 今回の結果 | 注記 |
|---|---|---|
| Node.js | **160 PASS** | 既存154 + 新規6(版ピン/authEvidence/canary鏡像/統合) |
| Python | **102 PASS** | 既存76 + 新規26(認証単位11 + 機能単位7 + E2E 8) |
| 総数 | **262 PASS** | 同一試験の再実行を加算しない |
| 生成録画コア | 5か所同一ハッシュ | `scripts/build.py`再実行でバイト一致 |
| 合成認証E2E | 4シナリオ | refresh単独/token優先切替/env・file供給/auth_failed通知 |
| canary相互言語 | 5ベクトル一致 | node実行のrspCanaryCheckとPython canary_checkが同一結果 |
| authEvidence鏡像 | 鍵構造完全一致 | Python AuthStoreとJS RspAuthで同一鍵集合(spawn比較) |
| webhook 429退避 | Retry-After実測 | 1秒指定で1回目→2回目の間隔≥0.9秒・上限内 |
| MP4メタデータ | ffprobe実測 | rplay_metadata_version=1・creator_oid・title・artist確認 |
| クリーン展開 | 再検証PASS | ZIP展開→ハッシュ照合→262試験再実行 |

## 秘密の非出力（v2.7.0の追加検証）

- authEvidenceには供給源の「種別」(value/env/file)のみを記録し値を出さない
  (合成E2EでENVSECRETVALUE/FILESECRETVALUE/STALETOKEN/RTVALUEが情報JSON・
  ログに出ないことを文字列照合で検証)。
- refresh-token応答の鍵名は形状証拠(responseKey)として記録するが、値は保持しない。
- canaryのobservedKeysはAPI応答の「鍵一覧」のみ(値・秘密は扱わない)。
- webhookペイロードに秘密を含めない契約は維持(ファイル名・分類・計数のみ)。

## 既知の制約（v2.7.0時点）

- refresh-token APIの応答鍵・要求形状は非公式情報に基づく設計のため、実測
  (P-02・実RPLAY)で鍵を確定してからauthEvidenceの記録鍵を更新する必要がある。
- offscreen/backgroundホストの拡張録画ではauthEvidenceは未中継
  (STATE.authStats未設定なら証拠ブロック自体を出さない)。ページ側録画の
  情報JSONには残る。中継実装は次版候補。
- 実配信RPLAY・実Chrome/Firefox拡張インストール・Windows・長時間耐久は
  未受入(ACCEPTANCE.md A1〜A10)。**判定はCANDIDATE / NO_GOのまま**。
- A-03 canaryはlive/play形状のみ観察(認証仕様・署名方式の変化は検知対象外)。

## 前版までの報告

# RPLAY Stable Player v2.6.0 — 統合開発・品質報告(前版)

2026-10-25 JST。直前版: v2.5.0 UNIFIED CANDIDATE(212試験)。
旧ZIPは保持。**CANDIDATE / NO_GO**。

## 変更範囲（開発計画v2.5.0の残課題 P1/P2/P0 を消化）

1. **P1 fMP4複数MAP監査**: `EXT-X-MAP`の宣言数(mapDeclarations)・切替回数
   (mapSwitches)・DISCONTINUITY無し切替(mapSwitchesWithoutDiscontinuity)・
   poll間切替(crossPollMapSwitches*)を数値証拠として記録(情報JSON fmp4Evidence)。
   MAP切替のパート境界分割(初期化セグメント混在防止)は従来挙動の実測化。
   Python/JS両コア鏡像・ブラウザー情報JSONにも同形式で出力。
2. **P1 分離音声PTS相関のqaudit統合**: qaudit_partがストリーム毎の実デコード
   時間(durationTs×timebase→durationSec)とパート代表値(decodedDurationSec)を
   測定。映像/音声トラックの集計ドリフトをavCorrelationとしてledger.jsonと
   情報JSONへ記録。verdictはpass/av_drift_suspect/insufficient
   (許容=max(映像時間×2%, 0.5s))。原点差ではなく量の整合で判定。
3. **P2 LL-HLS安全側仕様**: `EXT-X-SKIP`(差分playlist)は専用コード
   `HLS_LLHLS_SKIP`で拒否(旧: STREAM-INFと同一コード/JSでは
   HLS_DELTA_UNSUPPORTEDだったのを両言語で統一)。`EXT-X-PRELOAD-HINT`/
   `EXT-X-SERVER-CONTROL`/`RENDITION-REPORT`/`PART`/`PART-INF`は取得せず
   計数証拠(llhlsEvidence)のみ。仕様をHLS_TRANSPORT_DESIGN.mdに固定。
4. **P2 通信予算境界の文書化**: COMMUNICATION_BUDGET_BOUNDARY.md —
   Stable PlayerとAuto Recorderの予算を独立契約のまま明文化
   (全体4通信枠の共通化を行わない)。共有可/不可・将来統合の合意ゲート。
5. **P0 実受入準備**: ACCEPTANCE.md — 実Chrome/Firefox/Windows受入の
   手順(A1〜A10)・観察記録テンプレート(T1〜T7)・判定プロトコル。
6. userscript `@version`の版ずれ(2.4.0のまま)を2.6.0へ修正
   (manifestとは独立に1版遅れていた)。バージョン表記を全館2.6.0へ統一。

## 実測検証(作業環境)

| 種類 | 今回の結果 | 注記 |
|---|---|---|
| Node.js | **154 PASS** | 既存148 + 新規6(fMP4/LL-HLS/情報JSON証拠/MAP分割) |
| Python | **76 PASS** | 既存64 + 新規12(単位7 + E2E実メディア5) |
| 総数 | **230 PASS** | 同一試験の再実行を加算しない |
| 生成録画コア | 5か所同一ハッシュ | `scripts/build.py` 再実行でバイト一致 |
| fMP4 MAP切替E2E | 2パート・初期化断片分離 | FFmpeg生成2世代(init1/init2)を1playlistに結合 |
| poll間MAP切替 | crossPollMapSwitches=1 | 同一世代替続中のinit切替を検出 |
| avCorrelation実測 | pass(3.0s/3.0s)・suspect(3.0s/2.2s) | FFmpeg sine/testsrc2実メディア |
| LL-HLS SKIP | exit 2・HLS_LLHLS_SKIP | 専用コードで拒否・全言語一致 |
| LL-HLS指標 | videoIndicators=2・録画継続 | PRELOAD-HINTは取得しない |
| 相互言語一致 | parse fmp4/llhls・累積値 | node -e比較でPython=JS |

## 技術判断

- **MAP切替の検出は宣言列とpoll間の両方**: 切替が1回のpoll内で見えるか
  複数pollにまたがるかの差であり、二重計上にはならない(各pollの先頭segmentの
  MAPと前poll末尾のMAP比較はprogress時のみ実施)。
- **DISCONTINUITY無しMAP切替を拒否しない**: 仕様上合法であり、拒否は
  正常配信を止めるリスク。パート境界分割が整合を守るため、計数のみ。
- **avCorrelationは量の整合**: PTS原点はトラック毎に独立。原点差(同期ズレ)
  の判定はmux後再生確認に委ね、ここでは虚偽の合格を書かない(insufficient)。
- **PRELOAD-HINTを先走り取得しない**: 二重取得と冪等性リスクを避ける安全側。
  正式なEXTINF付きURIの到着を待つ。
- **userscript @version修正は破壊的変更なし**: Tampermonkey等の更新判定が
  正しく2.6.0になるようにする修正(実挙動は不変)。
- 実RPLAY・実Chrome/Firefox拡張・Windows・長時間耐久は未受入(ACCEPTANCE.md
  A1〜A10の実施が次課題)。外部公開・GitHub反映なし。GO判定は別承認。

## 再現

```bash
python scripts/build.py
python scripts/validate.py --output-dir /tmp/rplay-evidence
python scripts/package_release.py <出力先>.zip
```

Node.js 24.21.0、Python 3.12.15、FFmpeg 7.1.5で実施。
実メディア回帰にはlibx264対応FFmpeg/ffprobeが必要(fMP4 E2Eは
`-hls_segment_type fmp4`対応を含む)。
