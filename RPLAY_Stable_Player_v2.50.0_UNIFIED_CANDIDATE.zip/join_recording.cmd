@echo off
setlocal
if "%~1"=="" (
  echo Drop the recording join JSON file onto this command file.
  pause
  exit /b 2
)
where py >nul 2>nul
if errorlevel 1 goto python
py -3 "%~dp0rplay_join.py" "%~1"
set "join_result=%errorlevel%"
goto done
:python
python "%~dp0rplay_join.py" "%~1"
set "join_result=%errorlevel%"
:done
pause
exit /b %join_result%
