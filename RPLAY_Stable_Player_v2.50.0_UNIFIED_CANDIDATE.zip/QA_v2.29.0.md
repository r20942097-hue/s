# v2.29.0 QA

追加4件: URL/ID正規化・重複、誤ID/悪意origin拒否、全件atomic validation/100件上限、tracking除外。最終結果はevidence/v229-current。外部プロフィールURL登録→ID保存→再読込を実Firefoxで追加確認。実RPLAY APIは未受入。

最終ZIPはCRC・全SHA台帳を検査し、包装後に追加した証拠/資料以外の全ファイルを試験済み展開ツリーとバイト照合。独立再包装も同一SHAを確認。全コードを全件試験対象とバイト照合し、同一コードでFirefoxも再試験。
