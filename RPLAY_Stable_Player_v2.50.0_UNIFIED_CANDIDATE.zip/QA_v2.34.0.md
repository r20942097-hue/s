# v2.34.0 QA

追加5件: 事前abort、遅延lookup後abort、重複progress、最終progress時abort、本文中abort。ブラウザ追加1件は名前登録中止→旧ID維持→再読み込み。名前APIはmock。実サービス受入ではない。
Gecko試験はLinux/headless/一時profile、試験のみsandbox level調整。native preview進行は未合格。

全回帰653件PASS（Node488/Python165）。Firefox31 PASS/1 BLOCKED。追加5件を含む。登録中止・遅延結果拒否・progress条件を追加検証。ブラウザruntimeは単体試験対象の展開候補と同じコード。最終包装はCRC/全hash台帳を確認。
