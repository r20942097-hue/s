/* HLS descriptor parsing and bounded HTTP transport. No key retrieval (key bytes are
   caller-supplied). v2.37.0(N-01): software AES-128-CBC decryption primitive adapted from
   cat-catch lib/m3u8-decrypt.js (hls.js AESDecryptor lineage) for environments where
   WebCrypto is unavailable or rejects the operation. v2.37.0(N-03): TS packet
   continuity-counter audit (ISO/IEC 13818-1 2.4.3.2) — the packet-level knowledge behind
   cat-catch/hls.js parseTs cc grouping, exposed as non-destructive quality evidence. */
(function(root,factory){const api=Object.freeze(factory());if(typeof module!=='undefined'&&module.exports)module.exports=api;root.RspHlsTransport=api;})(typeof globalThis==='undefined'?this:globalThis,function(){
'use strict';
const fail=code=>{throw Error(code);},uint=s=>{if(!/^\d+$/.test(s))fail('HLS_BAD_INTEGER');const n=Number(s);if(!Number.isSafeInteger(n))fail('HLS_BAD_INTEGER');return n;};
const URI_CACHE_MAX=4096; // v2.5.0: generation-recovery URI identity cache bound
// v2.42.3: bounded, URL-free recording acceptance audit (not disk/fsync or AV decode proof).
// Never retain playlist/segment URLs, request headers, cookies, or segment byte arrays.
const LEDGER_TAIL_LIMIT=96;
function audit(owner){
 if(!owner._hlsWriteAudit)owner._hlsWriteAudit={schema:1,provenance:'writer_acceptance_not_file_commit',scope:'recording_instance',
  queued:0,accepted:0,acceptedMediaBytes:0,acceptedInitBytes:0,terminal:0,
  suspectedManifestMissing:0,declaredGaps:0,backlogSkipped:0,sequenceDiscontinuities:0,
  suspectedAcceptedSequenceGaps:0,unresolved:0,tail:[],last:null};
 return owner._hlsWriteAudit;
}
function stamp(item){
 const d=item&&item.hls;
 if(!d||![d.epoch,d.discontinuity,d.sequence].every(Number.isSafeInteger))return null;
 return {epoch:d.epoch,discontinuity:d.discontinuity,sequence:d.sequence};
}
function pushAudit(a,status,item,mediaBytes=0){
 const v=stamp(item);
 if(!v)return;
 a.tail.push({...v,status,...(status==='accepted'?{mediaBytes}: {})});
 if(a.tail.length>LEDGER_TAIL_LIMIT)a.tail.shift();
}
function noteQueue(owner,items,missing=0,declaredGaps=0,backlogSkipped=0){
 const a=audit(owner);a.queued+=items.length;
 a.suspectedManifestMissing+=Math.max(0,missing-declaredGaps);
 a.declaredGaps+=declaredGaps;
 a.backlogSkipped+=backlogSkipped;
 a.unresolved+=items.length;
 for(const item of items)pushAudit(a,'queued',item);
}
function freshPartAudit(){
 return {segments:0,mediaBytes:0,initBytes:0,firstSequence:null,lastSequence:null,
  firstEpoch:null,lastEpoch:null,firstDiscontinuity:null,lastDiscontinuity:null,
  sequenceGaps:0,discontinuities:0,prev:null};
}
function startPartAudit(owner){
 if(!owner||typeof owner!=='object')return null;
 owner._hlsPartAudit=freshPartAudit();
 return owner._hlsPartAudit;
}
function takePartAudit(owner){
 if(!owner||typeof owner!=='object')return null;
 const pa=owner._hlsPartAudit;
 owner._hlsPartAudit=null;
 if(!pa)return null;
 return {segments:pa.segments,mediaBytes:pa.mediaBytes,initBytes:pa.initBytes,
  firstSequence:pa.firstSequence,lastSequence:pa.lastSequence,
  firstEpoch:pa.firstEpoch,lastEpoch:pa.lastEpoch,
  firstDiscontinuity:pa.firstDiscontinuity,lastDiscontinuity:pa.lastDiscontinuity,
  sequenceGaps:pa.sequenceGaps,discontinuities:pa.discontinuities};
}
function noteAccepted(owner,item,mediaBytes,initBytes){
 if(!item||!item.hls)return;
 const a=audit(owner),v=stamp(item);
 if(!v)return;
 if(a.last&&a.last.epoch===v.epoch&&a.last.discontinuity===v.discontinuity&&v.sequence>a.last.sequence+1)
  a.suspectedAcceptedSequenceGaps+=v.sequence-a.last.sequence-1;
 if(a.last&&(a.last.epoch!==v.epoch||a.last.discontinuity!==v.discontinuity))a.sequenceDiscontinuities++;
 a.last=v;
 a.accepted++;a.unresolved=Math.max(0,a.unresolved-1);
 a.acceptedMediaBytes+=mediaBytes;a.acceptedInitBytes+=initBytes;
 pushAudit(a,'accepted',item,mediaBytes);
 const pa=owner._hlsPartAudit||(owner._hlsPartAudit=freshPartAudit());
 pa.segments++;pa.mediaBytes+=mediaBytes;pa.initBytes+=initBytes;
 if(pa.firstSequence===null){
  pa.firstSequence=v.sequence;pa.firstEpoch=v.epoch;pa.firstDiscontinuity=v.discontinuity;
 }
 if(pa.prev){
  if(pa.prev.epoch===v.epoch&&pa.prev.discontinuity===v.discontinuity&&v.sequence>pa.prev.sequence+1)
   pa.sequenceGaps+=v.sequence-pa.prev.sequence-1;
  if(pa.prev.epoch!==v.epoch||pa.prev.discontinuity!==v.discontinuity)pa.discontinuities++;
 }
 pa.lastSequence=v.sequence;pa.lastEpoch=v.epoch;pa.lastDiscontinuity=v.discontinuity;
 pa.prev=v;
}
function clearWriteEvidence(owner){owner._hlsWriteAudit=null;owner._hlsPartAudit=null;}
function noteTerminal(owner,item){
 if(!item||!item.hls)return;
 const a=audit(owner);a.terminal++;a.unresolved=Math.max(0,a.unresolved-1);
 pushAudit(a,'terminal',item);
}
function writeEvidence(owner){
 const a=owner&&owner._hlsWriteAudit;
 if(!a)return {schema:1,provenance:'writer_acceptance_not_file_commit',scope:'recording_instance',queued:0,accepted:0,terminal:0,unresolved:0,
  acceptedMediaBytes:0,acceptedInitBytes:0,suspectedManifestMissing:0,declaredGaps:0,
  backlogSkipped:0,sequenceDiscontinuities:0,suspectedAcceptedSequenceGaps:0,
  tail:[],tailLimit:LEDGER_TAIL_LIMIT,truncated:0,fileCommitted:false,avDecoded:false};
 return {schema:1,provenance:a.provenance,scope:a.scope,queued:a.queued,accepted:a.accepted,terminal:a.terminal,
  unresolved:a.unresolved,acceptedMediaBytes:a.acceptedMediaBytes,acceptedInitBytes:a.acceptedInitBytes,
  suspectedManifestMissing:a.suspectedManifestMissing,declaredGaps:a.declaredGaps,
  backlogSkipped:a.backlogSkipped,sequenceDiscontinuities:a.sequenceDiscontinuities,
  suspectedAcceptedSequenceGaps:a.suspectedAcceptedSequenceGaps,tail:a.tail.map(e=>({...e})),
  tailLimit:LEDGER_TAIL_LIMIT,truncated:Math.max(0,a.queued+a.terminal+a.accepted-a.tail.length),
  fileCommitted:false,avDecoded:false};
}
// v2.6.0(P2): LL-HLS safe-side policy — delta playlists (EXT-X-SKIP) reject with a
// dedicated code; PRELOAD-HINT/SERVER-CONTROL etc. are never fetched but counted.
const LLHLS_INDICATOR_TAGS=['#EXT-X-SERVER-CONTROL:','#EXT-X-PRELOAD-HINT:','#EXT-X-RENDITION-REPORT:','#EXT-X-PART:','#EXT-X-PART-INF:'];
const SCTE35_INDICATOR_TAGS=['#EXT-X-CUE-OUT','#EXT-X-CUE-IN','#EXT-X-SCTE35','#EXT-OATCLS-SCTE35','#EXT-X-DATERANGE:'];
const uriKey=d=>d.uri.split('?')[0].split('#')[0]+(d.range?'|'+JSON.stringify(d.range):'');
function attrs(s){const out={};let i=0;while(i<s.length){const m=/^([A-Z0-9-]+)=/.exec(s.slice(i));if(!m||m[1] in out)fail('HLS_BAD_ATTRIBUTES');i+=m[0].length;let value;if(s[i]==='"'){const end=s.indexOf('"',++i);if(end<0)fail('HLS_BAD_ATTRIBUTES');value=s.slice(i,end);i=end+1;}else{const end=s.indexOf(',',i);value=s.slice(i,end<0?s.length:end);i=end<0?s.length:end;}out[m[1]]=value;if(i<s.length){if(s[i++]!==','||i===s.length)fail('HLS_BAD_ATTRIBUTES');}}return out;}
// v2.12.0(C-02): cat-catch "添加get参数" (inheritQuery) — when inheritQuery=true and the
// base playlist URL carries query parameters (e.g. token/key2), append missing query keys
// onto same-origin segment/MAP URLs without overwriting segment-specific query parameters.
function url(raw,base,inheritQuery=false){
 if(typeof raw!=='string'||raw!==raw.trim()||/[\x00-\x1f\x7f]/.test(raw))fail('HLS_BAD_URL');
 const u=new URL(raw,base);
 if(!['http:','https:'].includes(u.protocol)||u.username||u.password)fail('HLS_BAD_URL');
 u.hash='';
 if(inheritQuery){
  try{
   const b=new URL(base);
   if(b.search&&u.origin===b.origin){
    for(const [k,v] of b.searchParams)if(!u.searchParams.has(k))u.searchParams.append(k,v);
   }
  }catch(e){}
 }
 return u.href;
}
function range(raw,previous,uri,map=false){if(raw===null)return null;const m=/^(\d+)(?:@(\d+))?$/.exec(raw);if(!m)fail('HLS_BAD_RANGE');const length=uint(m[1]);if(!length||length>32*1048576)fail('HLS_RANGE_LIMIT');let offset;if(m[2]!==undefined)offset=uint(m[2]);else{if(map||!previous||previous.uri!==uri||!previous.range)fail('HLS_IMPLICIT_RANGE');offset=previous.range.offset+previous.range.length;}if(!Number.isSafeInteger(offset+length-1))fail('HLS_RANGE_LIMIT');return {offset,length};}
function parse(text,base,mode='legacy',inheritQuery=false){
 // v2.5.0: mode='legacy' (default) accepts a segment URI without EXTINF as a
 // diagnostic (pre-v2.5 input compatibility); mode='rfc' rejects it
 // (RFC 8216 4.3.2.1 EXTINF is REQUIRED for every media segment).
 // v2.12.0(C-02): inheritQuery=true appends base playlist query params to same-origin URIs.
 if(typeof text!=='string'||text.length>2*1048576||!/^\uFEFF?#EXTM3U(?:\r?\n|$)/.test(text))fail('HLS_BAD_PLAYLIST');
 let sequence=0,discontinuity=0,target=0,map=null,encrypted=false,pendingRange=null,gap=false,previous=null,pendingDuration=null,pendingClock=null;const segments=[];let endList=false;let seenSeq=false,seenDisc=false,seenTarget=false,seenVersion=false;
 // v2.6.0(P1): fMP4 init-segment (EXT-X-MAP) declaration evidence. A switch splits
 // the part boundary so init segments never mix; a switch without an intervening
 // EXT-X-DISCONTINUITY is counted as a quality-risk indicator (not rejected).
 let mapDecls=0,mapSwitches=0,mapSwitchNoDisc=0,discSinceSeg=true,llhlsTags=0,scte35Tags=0,queryInherited=0;
 for(const raw of text.replace(/^\uFEFF/,'').split(/\r?\n/)){const line=raw.trim();if(!line)continue;if(line[0]!=='#'&&raw!==line)fail('HLS_BAD_URL');
  if(line.startsWith('#EXT-X-STREAM-INF:'))fail('HLS_EXPECT_MEDIA');
  if(line.startsWith('#EXT-X-VERSION:')){if(seenVersion)fail('HLS_BAD_VERSION');seenVersion=true;uint(line.slice(15));}
  if(line==='#EXT-X-I-FRAMES-ONLY')fail('HLS_IFRAMES_UNSUPPORTED');
  if(line.startsWith('#EXT-X-SKIP:'))fail('HLS_LLHLS_SKIP'); // v2.6.0(P2): dedicated delta-playlist rejection
  if(LLHLS_INDICATOR_TAGS.some(t=>line.startsWith(t)))llhlsTags++; // v2.6.0(P2): counted, never fetched
  if(SCTE35_INDICATOR_TAGS.some(t=>line.startsWith(t)))scte35Tags++;
  if(line.startsWith('#EXT-X-MEDIA-SEQUENCE:')){if(segments.length||seenSeq)fail('HLS_BAD_SEQUENCE');seenSeq=true;sequence=uint(line.slice(22));}
  else if(line.startsWith('#EXT-X-DISCONTINUITY-SEQUENCE:')){if(segments.length||seenDisc)fail('HLS_BAD_SEQUENCE');seenDisc=true;discontinuity=uint(line.slice(30));}
  else if(line==='#EXT-X-DISCONTINUITY'){discontinuity++;discSinceSeg=true;}
  else if(line.startsWith('#EXT-X-TARGETDURATION:')){if(seenTarget||segments.length)fail('HLS_BAD_TARGET');seenTarget=true;target=uint(line.slice(22));if(!target)fail('HLS_BAD_TARGET');}
  else if(line.startsWith('#EXTINF:')){if(endList||pendingDuration!==null)fail('HLS_BAD_EXTINF');const v=line.slice(8).split(',')[0];if(!/^(?:\d+(?:\.\d+)?|\.\d+)$/.test(v))fail('HLS_BAD_EXTINF');pendingDuration=Number(v);if(!Number.isFinite(pendingDuration)||pendingDuration<=0||pendingDuration>86400)fail('HLS_BAD_EXTINF');}
  else if(line.startsWith('#EXT-X-PROGRAM-DATE-TIME:')){if(endList||pendingClock!==null)fail('HLS_BAD_PROGRAM_DATE_TIME');const v=line.slice(25);if(!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2})$/.test(v))fail('HLS_BAD_PROGRAM_DATE_TIME');const m=/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d{1,3})?(?:Z|([+-])(\d{2}):(\d{2}))$/.exec(v);const yr=+m[1],mo=+m[2],day=+m[3],hr=+m[4],mi=+m[5],sec=+m[6];const leap=yr%4===0&&(yr%100!==0||yr%400===0);const lengths=[31,leap?29:28,31,30,31,30,31,31,30,31,30,31];if(yr<1||mo<1||mo>12||day<1||day>lengths[mo-1]||hr>23||mi>59||sec>59||(m[8]!==undefined&&(+m[8]>23||+m[9]>59)))fail('HLS_BAD_PROGRAM_DATE_TIME');pendingClock=Date.parse(v);if(!Number.isSafeInteger(pendingClock))fail('HLS_BAD_PROGRAM_DATE_TIME');}
  else if(line.startsWith('#EXT-X-KEY:')){const a=attrs(line.slice(11));if(!a.METHOD)fail('HLS_BAD_KEY');encrypted=a.METHOD!=='NONE';}
  else if(line.startsWith('#EXT-X-MAP:')){if(encrypted)fail('HLS_ENCRYPTED_UNSUPPORTED');const a=attrs(line.slice(11));if(!a.URI)fail('HLS_BAD_MAP');const plainMap=url(a.URI,base,false),uri=inheritQuery?url(a.URI,base,true):plainMap;if(inheritQuery&&uri!==plainMap)queryInherited++;const newMap={uri,range:range(a.BYTERANGE===undefined?null:a.BYTERANGE,null,uri,true)};mapDecls++;if(map&&JSON.stringify(map)!==JSON.stringify(newMap)){mapSwitches++;if(!discSinceSeg)mapSwitchNoDisc++;}map=newMap;}
  else if(line.startsWith('#EXT-X-BYTERANGE:')){if(pendingRange!==null)fail('HLS_BAD_RANGE');pendingRange=line.slice(17);}
  else if(line==='#EXT-X-GAP')gap=true;
  else if(line==='#EXT-X-ENDLIST'){if(endList)fail('HLS_DUPLICATE_ENDLIST');endList=true;}
  else if(line[0]!=='#'){
   if(endList)fail('HLS_SEGMENT_AFTER_ENDLIST');
   if(encrypted)fail('HLS_ENCRYPTED_UNSUPPORTED');if(segments.length>=4096)fail('HLS_SEGMENT_LIMIT');
   if(mode==='rfc'&&pendingDuration===null)fail('HLS_EXTINF_REQUIRED');
   const plainUri=url(line,base,false),uri=inheritQuery?url(line,base,true):plainUri;if(inheritQuery&&uri!==plainUri)queryInherited++;
   const r=range(pendingRange,previous,uri);const item={uri,range:r,map,gap,sequence:sequence+segments.length,discontinuity,duration:pendingDuration,programDateTimeMs:pendingClock};
   if(!Number.isSafeInteger(item.sequence)||!Number.isSafeInteger(discontinuity))fail('HLS_BAD_INTEGER');segments.push(item);previous=item;pendingRange=null;gap=false;pendingDuration=null;pendingClock=null;discSinceSeg=false;
  }
 }
 if(pendingRange!==null)fail('HLS_DANGLING_RANGE');if(pendingDuration!==null||pendingClock!==null||gap)fail('HLS_DANGLING_TAG');if(!target)fail('HLS_BAD_TARGET');for(const d of segments)if(d.duration!==null&&Math.floor(d.duration+0.5)>target)fail('HLS_DURATION_OVER_TARGET');return {sequence,discontinuity,target,endList,segments,queryInherited,fmp4:{mapDeclarations:mapDecls,mapSwitches,mapSwitchesWithoutDiscontinuity:mapSwitchNoDisc},llhls:{indicatorTags:llhlsTags},scte35:{indicatorTags:scte35Tags}};
}
// Advisory only: manifest wall-clock metadata is never proof of decoded PTS continuity.
function timingEvidence(parsed,toleranceMs=500){
 const result={provenance:'manifest_declared_only',segments:parsed.segments.length,explicitAnchors:0,checkedIntervals:0,suspectedGapIntervals:0,suspectedOverlapIntervals:0,maxAbsDeviationMs:0,unmeasuredIntervals:0,missingExtinf:0,declaredGaps:0,discontinuityBoundaries:0};
 let anchor=null,elapsed=0,complete=false,previousDisc=null;
 for(const d of parsed.segments){
  if(d.duration===null||d.duration===undefined)result.missingExtinf++;
  if(d.gap)result.declaredGaps++;
  if(previousDisc!==null&&previousDisc!==d.discontinuity){result.discontinuityBoundaries++;anchor=null;complete=false;elapsed=0;}
  previousDisc=d.discontinuity;
  if(d.programDateTimeMs!==null&&d.programDateTimeMs!==undefined){
   result.explicitAnchors++;
   if(anchor!==null){if(complete){const delta=d.programDateTimeMs-(anchor+elapsed);result.checkedIntervals++;result.maxAbsDeviationMs=Math.max(result.maxAbsDeviationMs,Math.abs(delta));if(delta>toleranceMs)result.suspectedGapIntervals++;else if(delta< -toleranceMs)result.suspectedOverlapIntervals++;}else result.unmeasuredIntervals++;}
   anchor=d.programDateTimeMs;elapsed=0;complete=true;
  }
  if(anchor!==null){if(d.duration===null||d.duration===undefined)complete=false;else elapsed+=d.duration*1000;}
 }
 return result;
}
const descriptorKey=d=>d?JSON.stringify([d.uri,d.range]):'';
// v2.12.0(W-05): MPEG-TS is a self-synchronizing 188-byte packet stream (PAT/PMT/PCR embedded).
// Unlike fMP4 (which requires EXT-X-MAP init boxes at the start of every part), MPEG-TS
// segments across EXT-X-DISCONTINUITY can be concatenated seamlessly into the same .ts file
// by default (matching Video DownloadHelper / Stream Recorder / Streamlink / yt-dlp / cat-catch).
function partBoundary(d,splitDisc=false){
 if(d&&d.map)return JSON.stringify([d.epoch,d.discontinuity,true,descriptorKey(d.map)]);
 return JSON.stringify(['ts',d?d.epoch:0,splitDisc?(d?d.discontinuity:0):0]);
}
function enqueue(owner,parsed,base){
 // v2.5.0: playlist generation recovery — mirrors the Python core classification
 // (initial/progress/stale/reset/rotation/context) with numeric evidence. A stale
 // re-serve never re-enqueues recorded data; a legitimate reset advances the epoch;
 // an encoder restart reusing sequence numbers is detected as uri rotation.
 const u=new URL(base);const context=u.origin+u.pathname;
 const uris=owner._hlsUris||(owner._hlsUris=new Map());
 const keys=parsed.segments.map(uriKey);
 let knownN=0;for(const k of keys)if(uris.has(k))knownN++;
 const hasFirst=owner._hlsFirst!==undefined;
 const rewind=hasFirst&&parsed.sequence<owner._hlsFirst;
 const sameContext=owner._hlsContext===context;
 let kind='progress';
 if(!hasFirst||owner._hlsContext===undefined)kind='initial';
 else if(!sameContext)kind='context';
 else if(rewind&&keys.length)kind=knownN===keys.length?'stale':'reset';
 let fresh=kind==='initial'||kind==='context'||kind==='reset';
 let epoch=(owner._hlsEpoch||0)+(fresh?1:0);const skip=owner._skipBacklog===true;
 const key=d=>'H:'+epoch+':'+d.discontinuity+':'+d.sequence+':'+JSON.stringify(d.range);
 let unseen=parsed.segments.filter(d=>!owner.seen.has(key(d)));
 if(kind==='progress'&&hasFirst&&sameContext&&!unseen.length&&keys.length&&knownN===0){
  kind='rotation';fresh=true;epoch=(owner._hlsEpoch||0)+1;
  unseen=parsed.segments.filter(d=>!owner.seen.has(key(d)));
 }
 if(uris.size)unseen=unseen.filter(d=>!uris.has(uriKey(d)));
 let incoming=skip?[]:unseen.filter(d=>!d.gap);
 let adFiltered=0;
 const adRe=(owner&&owner._adKeywordRe instanceof RegExp)?owner._adKeywordRe:(owner&&owner.rec&&owner.rec._adKeywordRe instanceof RegExp?owner.rec._adKeywordRe:null);
 if(adRe&&incoming.length){
  const kept=[];
  for(const d of incoming){
   if(adRe.test(d.uri.split("?")[0].split("#")[0]))adFiltered++;
   else kept.push(d);
  }
  incoming=kept;
 }
 const timing=timingEvidence(parsed);
 if(owner.queue.length+incoming.length>4096)fail('HLS_QUEUE_LIMIT');
 let missing=!fresh&&owner._hlsLast!==undefined&&parsed.sequence>owner._hlsLast+1?parsed.sequence-owner._hlsLast-1:0;
 for(const d of unseen){owner.seen.add(key(d));if(d.gap&&!skip)missing++;}
 for(const k of keys)uris.set(k,true);
 while(uris.size>URI_CACHE_MAX)uris.delete(uris.keys().next().value);
 const newItems=incoming.map(d=>({name:d.uri,base:'',tries:0,hls:{...d,epoch}}));
 for(const item of newItems)owner.queue.push(item);
 const declaredGapCount=skip?0:unseen.filter(d=>d.gap).length;
 // Ignore the deliberate backlog skip as a recording failure; keep it separately visible.
 if(newItems.length||missing||skip)noteQueue(owner,newItems,missing,declaredGapCount,skip?unseen.length:0);
 const rec=owner._hlsRecovery||(owner._hlsRecovery={staleResponses:0,suspectedResets:0,sequenceResets:0,uriRotations:0,contextSwitches:0,lastKind:kind,lastSequence:null});
 if(kind==='stale')rec.staleResponses++;
 else if(kind==='reset')rec.sequenceResets++;
 else if(kind==='rotation')rec.uriRotations++;
 else if(kind==='context')rec.contextSwitches++;
 rec.lastKind=kind;rec.lastSequence=keys.length?parsed.sequence:null;
 // v2.6.0(P1/P2): accumulate fMP4 MAP declaration and LL-HLS indicator evidence per context
 const f=parsed.fmp4||{};
 const ev=owner._hlsFmp4||(owner._hlsFmp4={mapDeclarations:0,mapSwitches:0,mapSwitchesWithoutDiscontinuity:0,crossPollMapSwitches:0,crossPollMapSwitchesWithoutDiscontinuity:0});
 ev.mapDeclarations+=f.mapDeclarations||0;ev.mapSwitches+=f.mapSwitches||0;ev.mapSwitchesWithoutDiscontinuity+=f.mapSwitchesWithoutDiscontinuity||0;
 // v2.6.0(P1): cross-poll MAP handoff — the same generation continuing with a changed
 // init segment between polls (the switch is only visible across playlist windows).
 if(kind==='progress'&&parsed.segments.length){
  const mk=parsed.segments[0].map?JSON.stringify(parsed.segments[0].map):null;
  if(mk!==null&&owner._hlsEvMapSig&&mk!==owner._hlsEvMapSig){
   ev.crossPollMapSwitches=(ev.crossPollMapSwitches||0)+1;
   if(parsed.segments[0].discontinuity===owner._hlsEvMapDisc)ev.crossPollMapSwitchesWithoutDiscontinuity=(ev.crossPollMapSwitchesWithoutDiscontinuity||0)+1;
  }
 }
 if(parsed.segments.length){
  const lastSeg=parsed.segments.at(-1);
  owner._hlsEvMapSig=lastSeg.map?JSON.stringify(lastSeg.map):null;
  owner._hlsEvMapDisc=lastSeg.discontinuity;
 }
 owner._hlsLlhlsIndicators=(owner._hlsLlhlsIndicators||0)+((parsed.llhls&&parsed.llhls.indicatorTags)||0);
 owner._hlsScte35Indicators=(owner._hlsScte35Indicators||0)+((parsed.scte35&&parsed.scte35.indicatorTags)||0);
 owner._hlsAdFilteredSegments=(owner._hlsAdFilteredSegments||0)+adFiltered;
 owner._hlsQueryInherited=(owner._hlsQueryInherited||0)+(parsed.queryInherited||0);
 owner._hlsTiming=timing;owner._skipBacklog=false;owner._hlsRecovery=rec;
 owner._hlsContext=context;owner._hlsEpoch=epoch;
 if(kind!=='stale')owner._hlsFirst=parsed.sequence;
 if(parsed.segments.length)owner._hlsLast=fresh?parsed.segments.at(-1).sequence:Math.max(owner._hlsLast??0,parsed.segments.at(-1).sequence);
 if(owner.seen.size>30000){let n=owner.seen.size-12000;for(const k of owner.seen){owner.seen.delete(k);if(--n<=0)break;}}
 return {added:incoming.length,missing,skipped:skip?parsed.segments.length:0};
}
function boxes(bytes){const out=[];let at=0;while(at<bytes.length){if(bytes.length-at<8)fail('HLS_BAD_MP4');const v=new DataView(bytes.buffer,bytes.byteOffset+at,bytes.length-at);let size=v.getUint32(0),header=8;if(size===1){if(bytes.length-at<16)fail('HLS_BAD_MP4');size=v.getUint32(8)*4294967296+v.getUint32(12);header=16;}else if(size===0)size=bytes.length-at;if(!Number.isSafeInteger(size)||size<header||at+size>bytes.length)fail('HLS_BAD_MP4');out.push(String.fromCharCode(...bytes.subarray(at+4,at+8)));at+=size;}return out;}
// v2.12.0(C-01): cat-catch "数据预处理" (TS image/header disguise stripping).
// Strips leading PNG/GIF/BMP/JPEG/WEBP/ID3 headers prepended before valid 188-byte
// MPEG-TS packets (0x47 sync byte on every 188-byte stride). Arbitrary non-disguised
// garbage is NOT stripped so fail-closed HLS_BAD_TS rejection remains intact.
function stripDisguisedTs(bytes){
 if(!bytes||!bytes.length)return {bytes,strippedBytes:0,magic:null};
 let magic=null;
 if(bytes.length>=8&&bytes[0]===0x89&&bytes[1]===0x50&&bytes[2]===0x4E&&bytes[3]===0x47)magic='png';
 else if(bytes.length>=6&&bytes[0]===0x47&&bytes[1]===0x49&&bytes[2]===0x46&&bytes[3]===0x38&&(bytes[4]===0x37||bytes[4]===0x39)&&bytes[5]===0x61)magic='gif';
 else if(bytes.length>=2&&bytes[0]===0x42&&bytes[1]===0x4D)magic='bmp';
 else if(bytes.length>=3&&bytes[0]===0xFF&&bytes[1]===0xD8&&bytes[2]===0xFF)magic='jpeg';
 else if(bytes.length>=12&&bytes[0]===0x52&&bytes[1]===0x49&&bytes[2]===0x46&&bytes[3]===0x46&&bytes[8]===0x57&&bytes[9]===0x45&&bytes[10]===0x42&&bytes[11]===0x50)magic='webp';
 else if(bytes.length>=3&&bytes[0]===0x49&&bytes[1]===0x44&&bytes[2]===0x33)magic='id3';
 if(!magic)return {bytes,strippedBytes:0,magic:null};
 const maxScan=Math.min(bytes.length-188,4096);
 for(let off=1;off<=maxScan;off++){
  if(bytes[off]===0x47&&(bytes.length-off)%188===0){
   let ok=true;
   for(let i=off+188;i<bytes.length;i+=188)if(bytes[i]!==0x47){ok=false;break;}
   if(ok)return {bytes:bytes.subarray(off),strippedBytes:off,magic};
  }
 }
 return {bytes,strippedBytes:0,magic};
}
/* ---------------------------------------------------------------- v2.37.0(N-01): software AES-128-CBC
   cat-catch lib/m3u8-decrypt.js と同一系譜(hls.js AESDecryptor)のテーブル駆動逆暗号。
   WebCrypto(crypto.subtle)が利用不可の環境(非セキュアコンテキスト等)や、WebCryptoが
   OperationErrorで拒否した場合のフォールバックとしてRecorderから呼ばれる。
   AES-CBC復号は仕様上決定的なため、正しい実装はWebCryptoとバイト一致する(NIST SP 800-38A
   KATとWebCryptoクロス検証をtests/test_v2160_core.cjsで常時実施)。 */
const AES_SBOX=new Uint8Array(256),AES_INV_SBOX=new Uint8Array(256),AES_SUB_MIX0=new Uint32Array(256),AES_SUB_MIX1=new Uint32Array(256),AES_SUB_MIX2=new Uint32Array(256),AES_SUB_MIX3=new Uint32Array(256),AES_INV_SUB_MIX0=new Uint32Array(256),AES_INV_SUB_MIX1=new Uint32Array(256),AES_INV_SUB_MIX2=new Uint32Array(256),AES_INV_SUB_MIX3=new Uint32Array(256);
(function initAesTables(){
 const d=new Uint32Array(256);let x=0,xi=0;
 for(let i=0;i<256;i++)d[i]=i<128?i<<1:(i<<1)^0x11b;
 for(let i=0;i<256;i++){
  let sx=xi^(xi<<1)^(xi<<2)^(xi<<3)^(xi<<4);sx=(sx>>>8)^(sx&0xff)^0x63;
  AES_SBOX[x]=sx;AES_INV_SBOX[sx]=x; // cat-catch initTableと同一(インデックスは実行カウンタx・鍵スケジュール展開は前方S-Boxを使用)
  const x2=d[x],x4=d[x2],x8=d[x4];
  let t=(d[sx]*0x101)^(sx*0x1010100);
  AES_SUB_MIX0[x]=(t<<24)|(t>>>8);AES_SUB_MIX1[x]=(t<<16)|(t>>>16);AES_SUB_MIX2[x]=(t<<8)|(t>>>24);AES_SUB_MIX3[x]=t;
  t=(x8*0x1010101)^(x4*0x10001)^(x2*0x101)^(x*0x1010100);
  AES_INV_SUB_MIX0[sx]=(t<<24)|(t>>>8);AES_INV_SUB_MIX1[sx]=(t<<16)|(t>>>16);AES_INV_SUB_MIX2[sx]=(t<<8)|(t>>>24);AES_INV_SUB_MIX3[sx]=t;
  if(!x){x=xi=1;}else{x=x2^d[d[d[x8^x2]]];xi^=d[d[xi]];}
 }
})();
const AES_RCON=[0x00,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36];
function aesWords16(b){const v=new DataView(b.buffer,b.byteOffset,b.byteLength);const out=new Uint32Array(4);for(let i=0;i<4;i++)out[i]=v.getUint32(i*4);return out;}
function aesExpandInvKey(key){
 const k=aesWords16(key);const ks=new Uint32Array(44);const iks=new Uint32Array(44);
 for(let i=0;i<4;i++)ks[i]=k[i];
 for(let i=4;i<44;i++){
  let t=ks[i-1];
  if(i%4===0){t=(t<<8)|(t>>>24);t=((AES_SBOX[(t>>>24)&0xff]<<24)|(AES_SBOX[(t>>>16)&0xff]<<16)|(AES_SBOX[(t>>>8)&0xff]<<8)|AES_SBOX[t&0xff])>>>0;t^=AES_RCON[i/4]<<24;}
  ks[i]=(ks[i-4]^t)>>>0;
 }
 for(let r=0;r<44;r++){
  const ksRow=44-r;let t;
  if(r&3)t=ks[ksRow];else t=ks[ksRow-4];
  if(r<4||ksRow<=4)iks[r]=t;
  /* cat-catch/hls.jsの等価逆暗号: invSubMix0[sbox[b]] == InvMixColumns(b) なる合成により、
     ラウンド鍵にはInvMixColumnsのみ適用される(sbox→invSubMixの二段構成)。 */
  else iks[r]=(AES_INV_SUB_MIX0[AES_SBOX[(t>>>24)&0xff]]^AES_INV_SUB_MIX1[AES_SBOX[(t>>>16)&0xff]]^AES_INV_SUB_MIX2[AES_SBOX[(t>>>8)&0xff]]^AES_INV_SUB_MIX3[AES_SBOX[t&0xff]])>>>0;
 }
 return iks;
}
/* PKCS7(RFC 5652 6.3)厳密検証付き除去。WebCryptoは成功時に自動除去するため、
   ソフトウェア経路も同一セマンティクスに揃える(不正パディングはfail-closed)。 */
function removePkcs7Padding(bytes){
 const n=bytes[bytes.length-1];
 if(!n||n>16)fail('HLS_DECRYPT_PADDING');
 for(let i=bytes.length-n;i<bytes.length;i++)if(bytes[i]!==n)fail('HLS_DECRYPT_PADDING');
 return bytes.subarray(0,bytes.length-n);
}
function decryptCbc(key,iv,bytes,opts){
 const removePadding=!opts||opts.padding!==false;
 if(!(key&&key.length===16))fail('HLS_DECRYPT_KEY');
 if(!(iv&&iv.length===16))fail('HLS_DECRYPT_IV');
 if(!bytes||!bytes.length||bytes.length%16)fail('HLS_DECRYPT_BLOCK_SIZE');
 const iks=aesExpandInvKey(key),iV=aesWords16(iv);
 let iV0=iV[0],iV1=iV[1],iV2=iV[2],iV3=iV[3];
 const input=new Int32Array(bytes.buffer,bytes.byteOffset,bytes.length>>2);
 const output=new Int32Array(input.length);
 const swap=w=>(w<<24)|((w&0xff00)<<8)|((w&0xff0000)>>8)|(w>>>24);
 for(let off=0;off<input.length;off+=4){
  let s0=swap(input[off])^iks[0],s1=swap(input[off+3])^iks[1],s2=swap(input[off+2])^iks[2],s3=swap(input[off+1])^iks[3];
  let t0,t1,t2,t3,ksRow=4;
  for(let r=1;r<10;r++){
   t0=AES_INV_SUB_MIX0[s0>>>24]^AES_INV_SUB_MIX1[(s1>>>16)&0xff]^AES_INV_SUB_MIX2[(s2>>>8)&0xff]^AES_INV_SUB_MIX3[s3&0xff]^iks[ksRow];
   t1=AES_INV_SUB_MIX0[s1>>>24]^AES_INV_SUB_MIX1[(s2>>>16)&0xff]^AES_INV_SUB_MIX2[(s3>>>8)&0xff]^AES_INV_SUB_MIX3[s0&0xff]^iks[ksRow+1];
   t2=AES_INV_SUB_MIX0[s2>>>24]^AES_INV_SUB_MIX1[(s3>>>16)&0xff]^AES_INV_SUB_MIX2[(s0>>>8)&0xff]^AES_INV_SUB_MIX3[s1&0xff]^iks[ksRow+2];
   t3=AES_INV_SUB_MIX0[s3>>>24]^AES_INV_SUB_MIX1[(s0>>>16)&0xff]^AES_INV_SUB_MIX2[(s1>>>8)&0xff]^AES_INV_SUB_MIX3[s2&0xff]^iks[ksRow+3];
   s0=t0;s1=t1;s2=t2;s3=t3;ksRow+=4;
  }
  t0=((AES_INV_SBOX[s0>>>24]<<24)^(AES_INV_SBOX[(s1>>>16)&0xff]<<16)^(AES_INV_SBOX[(s2>>>8)&0xff]<<8)^AES_INV_SBOX[s3&0xff])^iks[ksRow];
  t1=((AES_INV_SBOX[s1>>>24]<<24)^(AES_INV_SBOX[(s2>>>16)&0xff]<<16)^(AES_INV_SBOX[(s3>>>8)&0xff]<<8)^AES_INV_SBOX[s0&0xff])^iks[ksRow+1];
  t2=((AES_INV_SBOX[s2>>>24]<<24)^(AES_INV_SBOX[(s3>>>16)&0xff]<<16)^(AES_INV_SBOX[(s0>>>8)&0xff]<<8)^AES_INV_SBOX[s1&0xff])^iks[ksRow+2];
  t3=((AES_INV_SBOX[s3>>>24]<<24)^(AES_INV_SBOX[(s0>>>16)&0xff]<<16)^(AES_INV_SBOX[(s1>>>8)&0xff]<<8)^AES_INV_SBOX[s2&0xff])^iks[ksRow+3];
  output[off]=swap(t0^iV0);output[off+1]=swap(t3^iV1);output[off+2]=swap(t2^iV2);output[off+3]=swap(t1^iV3);
  iV0=swap(input[off]);iV1=swap(input[off+1]);iV2=swap(input[off+2]);iV3=swap(input[off+3]);
 }
 const out=new Uint8Array(output.buffer);
 return removePadding?removePkcs7Padding(out):out;
}
/* ---------------------------------------------------------------- v2.37.0(N-03): TS continuity-counter audit
   ISO/IEC 13818-1 2.4.3.2 の連続性規則をパケット単位で検査する(cat-catch/hls.jsが
   プレイリスト断片のccグループ化に使う知識のパケットレベル適用)。監査のみで非破壊:
   欠落検出(forwardJumps)・重複(duplicates)・逆方向(backwardJumps)・TEIを計数し、
   セグメント廃棄は一切行わない。JS/Python鏡像実装で証拠スキーマは完全一致。 */
function emptyCcAudit(){return {segmentsAudited:0,bytesAudited:0,packets:0,pids:0,payloadPackets:0,noPayloadPackets:0,afcReserved:0,teiPackets:0,continuityOk:0,duplicates:0,forwardJumps:0,backwardJumps:0,lostPacketEstimate:0,maxSingleJump:0,perPid:{},perPidTruncated:false};}
function auditCc(bytes){
 const seg=emptyCcAudit();
 if(!bytes||bytes.length<188||bytes.length%188)return seg;
 seg.packets=bytes.length/188;
 const state={};let distinct=0;
 for(let at=0;at<bytes.length;at+=188){
  const b1=bytes[at+1],b2=bytes[at+2],b3=bytes[at+3];
  const pid=((b1&0x1f)<<8)|b2;
  const afc=(b3>>4)&3,cc=b3&0xf;
  const tei=(b1&0x80)!==0;
  if(tei)seg.teiPackets++;
  let st=state[pid];
  if(!st){st=state[pid]={lastCc:-1,packets:0,payload:0,ok:0,dup:0,fwd:0,back:0,lost:0};distinct++;}
  st.packets++;
  if(afc===0){seg.afcReserved++;continue;}
  if(afc===2){seg.noPayloadPackets++;continue;}
  seg.payloadPackets++;st.payload++;
  if(st.lastCc<0){st.lastCc=cc;continue;}
  const delta=(cc-st.lastCc)&0xf;
  if(delta===1)seg.continuityOk++,st.ok++;
  else if(delta===0)seg.duplicates++,st.dup++;
  else if(delta<8){seg.forwardJumps++;st.fwd++;const lost=delta-1;seg.lostPacketEstimate+=lost;st.lost+=lost;if(lost>seg.maxSingleJump)seg.maxSingleJump=lost;}
  else{seg.backwardJumps++;st.back++;}
  st.lastCc=cc;
 }
 seg.pids=distinct;
 for(const pid in state){const st=state[pid];seg.perPid[pid]={pid:parseInt(pid,10),packets:st.packets,payload:st.payload,ok:st.ok,dup:st.dup,fwd:st.fwd,back:st.back,lost:st.lost};}
 return seg;
}
function mergeCcEvidence(acc,seg){
 acc.segmentsAudited++;acc.bytesAudited+=seg.packets*188;
 for(const k of ['packets','pids','payloadPackets','noPayloadPackets','afcReserved','teiPackets','continuityOk','duplicates','forwardJumps','backwardJumps','lostPacketEstimate'])acc[k]+=seg[k]||0;
 if(seg.maxSingleJump>acc.maxSingleJump)acc.maxSingleJump=seg.maxSingleJump;
 for(const pid in seg.perPid){
  const s=seg.perPid[pid];let dst=acc.perPid[pid];
  if(!dst){dst=acc.perPid[pid]={pid:parseInt(pid,10),packets:0,payload:0,ok:0,dup:0,fwd:0,back:0,lost:0};acc._pidCount=(acc._pidCount||0)+1;}
  for(const k of ['packets','payload','ok','dup','fwd','back','lost'])dst[k]+=s[k]||0;
 }
 return acc;
}
function ccEvidence(acc){
 if(!acc)return undefined;
 const out={segmentsAudited:acc.segmentsAudited,bytesAudited:acc.bytesAudited,packets:acc.packets,pids:acc.pids,payloadPackets:acc.payloadPackets,noPayloadPackets:acc.noPayloadPackets,afcReserved:acc.afcReserved,teiPackets:acc.teiPackets,continuityOk:acc.continuityOk,duplicates:acc.duplicates,forwardJumps:acc.forwardJumps,backwardJumps:acc.backwardJumps,lostPacketEstimate:acc.lostPacketEstimate,maxSingleJump:acc.maxSingleJump,
  perPid:Object.values(acc.perPid).sort((a,b)=>b.packets-a.packets||a.pid-b.pid).slice(0,16).map(e=>({pid:e.pid,packets:e.packets,payload:e.payload,ok:e.ok,dup:e.dup,fwd:e.fwd,back:e.back,lost:e.lost}))};
 out.perPidTruncated=Object.keys(acc.perPid).length>16;
 return out;
}
function validate(bytes,kind){
 if(!bytes||!bytes.length)fail('HLS_EMPTY_BODY');
 if(kind==='ts'){
  if(bytes.length%188||bytes[0]!==0x47){const st=stripDisguisedTs(bytes);if(st.strippedBytes>0)bytes=st.bytes;}
  if(bytes.length%188||bytes[0]!==0x47)fail('HLS_BAD_TS');
  for(let i=188;i<bytes.length;i+=188)if(bytes[i]!==0x47)fail('HLS_BAD_TS');
 }else{
  const b=boxes(bytes);
  if(kind==='init'&&(!b.includes('ftyp')||!b.includes('moov')))fail('HLS_BAD_INIT');
  if(kind==='fragment'&&(!b.includes('moof')||!b.includes('mdat')))fail('HLS_BAD_FRAGMENT');
 }
 return bytes;
}
function createTransfer(fetchImpl=fetch,timeout=15000){
 const pending=new Set();let closed=false;
 return {abort(){closed=true;for(const e of pending)e.abort();},get pending(){return pending.size;},get closed(){return closed;},
  async request(d,limit=32*1048576){
   if(closed)return {status:0,error:'HLS_ABORTED'};
   const controller=new AbortController();let timer,reader,response;let rejectDeadline;
   const deadline=new Promise((_,reject)=>rejectDeadline=reject);
   const entry={abort(){controller.abort();rejectDeadline(Error('HLS_ABORTED'));}};pending.add(entry);
   timer=setTimeout(()=>{controller.abort();rejectDeadline(Error('HLS_TIMEOUT'));},timeout);
   try{
    const operation=(async()=>{
     const headers=d.range?{Range:'bytes='+d.range.offset+'-'+(d.range.offset+d.range.length-1)}:{};
     if(d.butter){if(typeof d.butter!=='string'||/[\r\n]/.test(d.butter))fail('HLS_BAD_AUTH_HEADER');headers.Butter=d.butter;}
     const res=response=await fetchImpl(d.uri,{cache:'no-store',headers,signal:controller.signal});
     if(controller.signal.aborted)fail('HLS_ABORTED');
     if(d.range&&res.status===200)fail('HLS_RANGE_IGNORED');
     if(res.status!==200&&res.status!==206){if(res.body)await res.body.cancel();return {status:res.status,retryAfter:res.headers.get('retry-after')};}
     const encoded=res.headers.get('content-encoding')&&!/^identity$/i.test(res.headers.get('content-encoding'));
     if(d.range&&encoded)fail('HLS_ENCODING_UNSUPPORTED');
     if(!d.range&&res.status===206)fail('HLS_UNEXPECTED_RANGE');
     if(d.range){const m=/^bytes (\d+)-(\d+)\/(\d+|\*)$/.exec(res.headers.get('content-range')||'');if(!m||Number(m[1])!==d.range.offset||Number(m[2])!==d.range.offset+d.range.length-1||(m[3]!=='*'&&Number(m[3])<=Number(m[2])))fail('HLS_CONTENT_RANGE');}
     const cl=encoded?null:res.headers.get('content-length');if(cl!==null&&(!/^\d+$/.test(cl)||Number(cl)>limit))fail('HLS_BODY_LIMIT');
     const chunks=[];let size=0;
     if(!res.body||!res.body.getReader)fail('HLS_STREAM_UNAVAILABLE');reader=res.body.getReader();
     while(true){if(controller.signal.aborted)fail('HLS_ABORTED');const value=await reader.read();if(value.done)break;size+=value.value.byteLength;if(size>limit||(d.range&&size>d.range.length))fail('HLS_BODY_LIMIT');chunks.push(value.value);}
     if(cl!==null&&size!==Number(cl))fail('HLS_BODY_LENGTH');if(d.range&&size!==d.range.length)fail('HLS_RANGE_LENGTH');
     const bytes=new Uint8Array(size);let at=0;for(const chunk of chunks){bytes.set(chunk,at);at+=chunk.byteLength;}return {status:res.status,bytes};
    })();
    return await Promise.race([operation,deadline]);
   }catch(e){controller.abort();return {status:0,error:/^HLS_[A-Z_]+$/.test(e.message)?e.message:'HLS_NETWORK'};}
   finally{clearTimeout(timer);pending.delete(entry);if(reader||response&&response.body)try{const p=reader?reader.cancel():response.body.cancel();if(p&&p.catch)p.catch(()=>{});}catch(e){}}
  }
 };
}
async function fetchItem(owner,item){
 if(!owner._hlsTransfer)owner._hlsTransfer=createTransfer();
 const transfer=owner._hlsTransfer,d=item.hls,generation=owner._hlsGeneration||0;
 let init=null;const mapKey=descriptorKey(d.map);
 if(d.map){
  if(owner._hlsMapKey===mapKey)init=owner._hlsMapBytes;
  else{const r=await transfer.request(d.map,8*1048576);if(r.error||!r.bytes)return r;
   try{init=validate(r.bytes,'init');}catch(e){return {status:0,error:e.message};}
   if(!alive(owner,generation))return {error:'HLS_ABORTED',status:0};
   owner._hlsMapKey=mapKey;owner._hlsMapBytes=init;
  }
 }
 const r=await transfer.request(d);if(r.error||!r.bytes)return r;
 let cleanBytes=r.bytes;
 if(!d.map&&cleanBytes&&(cleanBytes.length%188||cleanBytes[0]!==0x47)){
  const st=stripDisguisedTs(cleanBytes);
  if(st.strippedBytes>0){
   cleanBytes=st.bytes;
   owner._hlsDisguiseStripped=(owner._hlsDisguiseStripped||0)+1;
   owner._hlsDisguiseBytes=(owner._hlsDisguiseBytes||0)+st.strippedBytes;
  }
 }
 try{cleanBytes=validate(cleanBytes,d.map?'fragment':'ts');}catch(e){return {status:0,error:e.message};}
 /* v2.37.0(N-03): TS連続性カウンタ監査(平文TSのみ・監査のみで非破壊)。 */
 if(!d.map&&cleanBytes.length&&cleanBytes.length%188===0&&cleanBytes[0]===0x47){
  try{mergeCcEvidence(owner._hlsCcAudit||(owner._hlsCcAudit=emptyCcAudit()),auditCc(cleanBytes));}catch(e){}
 }
 const splitDisc=!!(owner&&typeof owner.splitOnDiscontinuity==='function'&&owner.splitOnDiscontinuity());
 return {...r,bytes:cleanBytes,init,boundary:partBoundary(d,splitDisc)};
}
function abort(owner){owner._hlsGeneration=(owner._hlsGeneration||0)+1;if(owner._hlsTransfer)owner._hlsTransfer.abort();if(owner._hlsPlaylistTransfer)owner._hlsPlaylistTransfer.abort();}
function reset(owner,keepUris){abort(owner);owner._hlsTransfer=null;owner._hlsPlaylistTransfer=null;owner._hlsMapKey=null;owner._hlsMapBytes=null;owner._hlsContext=null;owner._hlsFirst=undefined;owner._hlsLast=undefined;owner._hlsBoundary=null;owner._hlsLastDiscKey=undefined;owner.mediaFormat='ts';/* v2.5.0: keepUris=true (standby resume) keeps the recorded-path cache so the
   recovering window is not duplicated; a fresh start() clears it intentionally. */
 if(keepUris!==true)owner._hlsUris=null;
 if(owner._hlsWriteAudit)owner._hlsWriteAudit.last=null;}
function alive(owner,generation){return (owner._hlsGeneration||0)===generation&&!owner.stopped&&!(owner.rec&&owner.rec.stopped)&&(!owner.rec||owner.running!==false);}
async function append(owner,item,result,generation=owner._hlsGeneration||0){
 if(!alive(owner,generation))return false;
 if(!item.hls){await owner.pushData(result.data);return alive(owner,generation);}
 const cont=owner._hlsContinuity||(owner._hlsContinuity={discontinuityMergedCount:0,discontinuitySplitCount:0});
 const discKey=item.hls.epoch+':'+item.hls.discontinuity;
 if(owner.partOpen&&owner._hlsLastDiscKey!==undefined&&owner._hlsLastDiscKey!==discKey){
  if(owner._hlsBoundary!==result.boundary)cont.discontinuitySplitCount++;
  else cont.discontinuityMergedCount++;
 }
 owner._hlsLastDiscKey=discKey;
 if(owner.partOpen&&owner._hlsBoundary!==result.boundary){
  const ev=owner._hlsPartBoundaries||(owner._hlsPartBoundaries={hlsBoundary:0});
  ev.hlsBoundary=(ev.hlsBoundary||0)+1;
  await owner.closePart();
 }
 if(!alive(owner,generation))return false;
 owner.mediaFormat=item.hls.map?'mp4':'ts';owner._hlsBoundary=result.boundary;
 const wasPartOpen=!!owner.partOpen;
 if(!owner.partOpen&&result.init)await owner.pushData(result.init);
 if(!alive(owner,generation))return false;
 await owner.pushData(result.data);
 if(!alive(owner,generation))return false;
 // pushData accepted the bytes; a later file write/rename can still fail.
 noteAccepted(owner,item,result.data.byteLength??result.data.length??0,
  !wasPartOpen&&result.init?(result.init.byteLength??result.init.length??0):0);
 return true;
}
function validateWebVtt(text){
 if(typeof text!=='string')fail('WEBVTT_HEADER');
 const clean=text.replace(/^\uFEFF/,'').replace(/\r\n/g,'\n').replace(/\r/g,'\n');
 const blocks=clean.split(/\n{2,}/);
 const header=(blocks[0]||'').trim();
 if(!/^WEBVTT(?:[ \t\n]|$)/.test(header))fail('WEBVTT_HEADER');
 let timestampMap=null;
 for(const line of header.split('\n').slice(1)){
  if(line.startsWith('X-TIMESTAMP-MAP='))timestampMap=line.slice(16).trim();
 }
 const cues=[];
 const timingRe=/^(?:(?:\d{2,}:)?\d{2}:\d{2}\.\d{3})\s+-->\s+(?:(?:\d{2,}:)?\d{2}:\d{2}\.\d{3})(?:[ \t].*)?$/;
 for(let i=1;i<blocks.length;i++){
  const raw=blocks[i].trim();
  if(!raw||raw.startsWith('NOTE')||raw.startsWith('STYLE')||raw.startsWith('REGION'))continue;
  const lines=raw.split('\n');
  let timingIdx=-1,cueId=null;
  if(timingRe.test(lines[0]))timingIdx=0;
  else if(lines.length>=2&&timingRe.test(lines[1])){cueId=lines[0];timingIdx=1;}
  if(timingIdx<0)fail('WEBVTT_BAD_CUE');
  const timing=lines[timingIdx].trim();
  const payload=lines.slice(timingIdx+1).join('\n').trim();
  if(!payload)continue;
  cues.push({id:cueId,timing,payload});
 }
 return {valid:true,timestampMap,cues};
}
function mergeWebVttSegments(segments){
 if(!Array.isArray(segments)||!segments.length)fail('WEBVTT_EMPTY');
 const seen=new Set(),merged=[];
 let duplicatesRemoved=0,timestampMap=null;
 for(const seg of segments){
  const v=validateWebVtt(seg);
  if(timestampMap===null&&v.timestampMap)timestampMap=v.timestampMap;
  for(const cue of v.cues){
   const key=cue.timing+'\n'+cue.payload;
   if(seen.has(key)){duplicatesRemoved++;continue;}
   seen.add(key);
   merged.push(cue);
  }
 }
 const head=timestampMap?'WEBVTT\nX-TIMESTAMP-MAP='+timestampMap:'WEBVTT';
 const body=merged.map(c=>(c.id?c.id+'\n':'')+c.timing+'\n'+c.payload).join('\n\n');
 const text=body?head+'\n\n'+body+'\n':head+'\n';
 return {segmentsProcessed:segments.length,cuesMerged:merged.length,duplicatesRemoved,timestampMap,text};
}
return {parse,enqueue,timingEvidence,attrs,descriptorKey,partBoundary,stripDisguisedTs,validate,createTransfer,fetchItem,append,abort,reset,alive,decryptCbc,removePkcs7Padding,auditCc,mergeCcEvidence,ccEvidence,emptyCcAudit,writeEvidence,noteTerminal,clearWriteEvidence,startPartAudit,takePartAudit,validateWebVtt,mergeWebVttSegments};
});
