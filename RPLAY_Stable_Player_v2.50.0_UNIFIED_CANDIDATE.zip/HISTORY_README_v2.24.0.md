# RPLAY Stable Player v2.24.0 CANDIDATE

BG録画の配信判定と認証付きHLS再試行を修正した候補版です。
Firefoxでは rplay-stable-player-extension-firefox/manifest.json を一時拡張として読み込みます。version_nameはFirefox版から除外済みです。
TS/MP4変換は拡張の変換画面、または open_mp4_converter.cmd（Python必要）から開けます。

- 今回の変更・改善優先順位: IMPROVEMENTS_v2.24.0.md
- 現在の検証結果: QA_v2.24.0.md
- 開発引き継ぎ: DEVELOPMENT_HANDOFF_v2.24.0.md
- 添付の系統比較: INTEGRATION_REVIEW_v2.23.0.md
- 従来の詳細操作: HISTORY_README_v2.23.0.md

旧版の資料・証拠は履歴として同梱しています。現在版の合格を示すものではありません。
実RPLAY・Windows・長時間/2GiB処理とnative previewの再生進行は未検証のため、CANDIDATE_NO_GOです。
