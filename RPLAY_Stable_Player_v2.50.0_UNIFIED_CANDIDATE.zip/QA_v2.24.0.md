# v2.24.0 検証範囲

2026-10-26 JST / CANDIDATE_NO_GO。

追加9件は録画probe、終了タグ優先、master child、HTTP分類、Butter署名URL保持、本文超過/停止/timeout、stop abort、ヘッダー改行拒否。
ZIP展開後の全回帰はNode441 + Python165 = **606 PASS / 0 FAIL**。最終実測は evidence/v224-current/VALIDATION.json。

Firefox158.0.1/Linux/headlessの一時拡張: 27項目中26 PASS / 1 BLOCKED。TS/MP4 Worker、OPFS保存/復旧/改変検出/中断、77MB素材、downloadサイズと独立SHA、FFmpeg全デコード、600px UIを含む。証拠は evidence/firefox-v224。
ルート試験は実Firefox DOM + mocked API/HLS。実RPLAY受入ではない。
BLOCKEDはnative previewの再生時刻の進行。通常MP4対照も時刻0。メタデータは読めるが再生/AV同期の合格と扱わない。
使い捨てプロファイルのみsandboxレベルを調整。製品の設定は変更しない。

初回の作業ツリー検証では包装台帳未生成のため既存packaging guardが1件失敗（Node440/441）。台帳付きZIPで再試験する。製品コードの試験失敗ではない。
Windows・実Chrome・実RPLAY・2GiB境界・長時間は未検証。旧版evidenceは履歴。

最終ZIPはCRC・全SHA台帳を検査し、包装後に追加した証拠/資料以外の全ファイルを試験済み展開ツリーとバイト照合。独立再包装も同一SHAを確認。FirefoxもZIP展開ツリーから再試験済み。
