# RPLAY Stable Player — v2.16.0 開発計画 (cat-catch 第3波)

親計画: RPLAY_DEVELOPMENT_PLAN_v2.15.0 (M-01〜M-03 / C-01〜C-03) の後継。
基礎: v2.15.0 UNIFIED CANDIDATE (398試験・CANDIDATE_NO_GO) をベースラインとし、
cat-catch (xifangczy/cat-catch v2.7.3) の残存知見から4特徴量を実装する。

## 0. ベースラインと配布修正
- v2.15.0 配布ZIPに `rplay_join.py` が欠落 (validate.py の runtime 参照・
  join_recording.cmd の参照があるのに SHA256SUMS 329エントリに含まれない)。
  v2.10.0 AGGREGATE から同文件を復元 (src/join_parts.py とバイト一致)。
- **再発防止**: build.py が `rplay_join.py` を再生成することを前提に、
  「root直下に存在・src/join_parts.pyとバイト一致・SHA256SUMSに含まれる」を
  v2.16.0 試験で常時検証する。

## 1. N-01: ソフトウェアAES-128-CBC復号器 (JS)
- 出典: cat-catch lib/m3u8-decrypt.js (= hls.js AESDecryptor 系譜)。
  解析詳細は CAT_CATCH_ANALYSIS_v2.16.0.md §1。
- 実装: `src/hls_transport.js` に `decryptCbc` / `removePkcs7Padding` を追加し
  RspHlsTransport からexport。PKCS7厳密検証 (RFC 5652 §6.3) で fail-closed。
- 組み込み: VodDl.decryptSeg が `crypto.subtle` 欠落/OperationError時に
  ソフトウェア経路へフォールバック。理由・成否を `aesFallbackEvidence`
  `{attempts, webcryptoOk, softwareSuccesses, softwareFailures, lastReason}` として
  情報JSONへ出力。
- 検証: NIST SP 800-38A KAT、WebCryptoクロス検証 (PKCS7込み原文一致)、
  厳密パディング拒否、引数fail-closed、VM内でのフォールバック経路実測。

## 2. N-02: CLI AES-128取得 (--dec-key系)
- 現状: CLIは `HLS_ENCRYPTED_UNSUPPORTED` で暗号化プレイリストを一括拒否。
  ユーザースクリプト側のみWebCrypto復号に対応。
- 実装:
  - `hls_parse(..., allow_aes128=False)` — True時のみ METHOD=AES-128 を受理し
    セグメントへ `keyUri` / `keyIvHex` を付与。SAMPLE-AES* は
    `HLS_SAMPLE_AES_UNSUPPORTED`、暗号化EXT-X-MAPは `HLS_ENCRYPTED_MAP_UNSUPPORTED`、
    未知METHODは `HLS_BAD_KEY` で明示分類 (無暗号化通過は絶対にしない)。
  - 鍵供給: `--dec-key HEX|auto` / `--dec-key-file PATH` / `--dec-key-env NAME`
    (相互排他)。`auto` は鍵URIから公式プレイヤー相当ヘッダ
    (`rplay-private-content-requestor` + `age` 乱数1..4999) で取得。
    403は `HLS_DEC_KEY_DENIED`、429は指数退避、長大応答は拒否。
  - IV: プレイリスト `IV=0x...` またはメディアシーケンス番号 (64bit big-endian、
    ユーザースクリプト ivFor と同一)。
  - 復号バックエンド: `--dec-backend auto|openssl|python`。
    auto = openssl サブプロセス (`enc -d -aes-128-cbc -nopad`・数百MB/s級) を
    優先し無ければ純Python (Tテーブル等価逆暗号・実測 ~1MB/s)。
    どちらもNIST KATとJS/opensslとバイト一致を試験で常時確認。
  - 経路: `_fetch_hls` で取得直後に復号 → 既存の偽装ヘッダ剥離 → 0x47/188検証。
    復号失敗はリトライ無意味としてValueError分類。
  - 証拠: `decryptionEvidence` `{enabled, method, keySource, keyCount,
    segmentsDecrypted, segmentsFailed, bytesDecrypted, elapsedMs, approxMbps,
    segmentsByBackend, zeroSecret}`。**鍵値は一切記録しない** (ゼロシークレット、
    試験で全出力ファイルを走査)。
- 既知限界 (正直な文書化): 純Pythonバックエンドは ~1MB/s。大容量VODは
  openssl (自動) またはユーザースクリプト (WebCrypto) を推奨。ffmpegを
  用いた高速経路は既存 (--normalize-ts) と同様の無劣化リマクスで代替可能。

## 3. N-03: TS連続性カウンタ監査
- 出典: cat-catch/hls.js parseTs の cc グループ化知見 + ISO/IEC 13818-1 §2.4.3.2。
- 実装: JS `auditCc` / Python `hls_audit_cc` を完全鏡像で実装し、
  `fetchItem` / `_fetch_hls` のTS検証後に監査 (非破壊・廃棄ゼロ)。
- 証拠: `continuityCounterEvidence` (JS/Py同一スキーマ、perPid上位16截頭)。

## 4. N-04: クロス検証試験
- NIST KAT (JS/Py/openssl) + WebCryptoクロス検証 + JS↔Py cc監査同一性
  (同一バイナリ→同一JSON) + CLI E2E (ローカルHTTP・暗号化プレイリスト・
  鍵エンドポイント・auto/403分類・ゼロシークレット走査)。

## 5. 版ピン・文書
- 2.16.0 への版ピン更新 (ユーザースクリプト/両manifest/CLI/acceptance/build/
  package_release/validate)。旧版試験のピン正規表現を 16 対応へ拡張
  (挙動検査は未変更)。
- 文書: 本計画 / CAT_CATCH_ANALYSIS_v2.16.0.md / QA_v2.16.0.md /
  ACCEPTANCE追補 (A21〜A24) / README / SOURCE_MANIFEST / DEPENDENCIES /
  THIRD_PARTY_NOTICES (hls.js系譜の起源表示) / CHANGES_v2.16.0.patch。

## 6. 紀律 (従来踏襲)
- 既定値は現行動作維持 (dec-key未指定→従来通りのfail-closed・cc監査は
  証拠のみで出力バイト不変・JSフォールバックはWebCrypto失敗時のみ)。
- 順序厳密維持、虚偽零なし (測定できないものは記載しない)、非破壊。
- CANDIDATE_NO_GO 維持 (実機受入 A21〜A24 を追補)。
