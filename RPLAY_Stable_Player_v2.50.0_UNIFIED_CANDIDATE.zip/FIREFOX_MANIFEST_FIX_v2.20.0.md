# Firefox version_name警告への対応

報告: Reading manifest: Warning processing version_name: An unexpected property was found in the WebExtension manifest.

v2.19.0のFirefox用manifestにはversion_name: 2.19.0 CANDIDATEが含まれていました。v2.20.0ではFirefox用からそのキーを削除しました。正式なversionは2.20.0を維持し、Chrome用version_nameは残しています。

展開したrplay-stable-player-extension-firefox/manifest.jsonを指定して読み込み直す手順です。修正版を実Firefoxで再読み込みした結果は、こちらでは未確認です。

Mozillaの既知問題に同じ警告が記録されています。
- https://bugzilla.mozilla.org/show_bug.cgi?id=1380219
- https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/manifest.json/version_name

自動検証はFirefox用のキー不在・Chrome用の表示ラベル・正式version一致・Firefox background/scriptsとGecko ID保持を確認します。Chrome/Firefox双方にversion_nameを要求していた旧テストも、ブラウザ別の要件へ変更しました。既存の実行権限は追加していません。
