# RPLAY Stable Player v2.21.0 CANDIDATE

配信一覧の取得・更新、新旧配信基盤の選択、BG録画の保存リストを改善した候補版です。

## 変更点

- 配信一覧はログイン済みAPIを先に取得。公開curationの403でログイン済み一覧まで止まる経路を修正。
- 「更新」と自動更新で一覧APIを再取得。空の一覧から新規配信が始まった場合も更新を続けます。
- creatorOidと配信セッションの_idを区別。入れ子レスポンスとcreatorListを防御的に解釈。
- 検索・視聴者数/配信者名順、Enterキーで配信を開く操作を追加。
- BG録画・保存リストは最新100件。録画中/音声/保存処理中/ローカル保存確定/DL未確認/サイズ照合済み/失敗を区別。
- 録画停止後も直近セッションのファイルを表示。「録画中の配信を開く」を追加。配信一覧パネルからもBG状態を確認可能。
- 公式live/playの基盤フラグとURLを優先し、旧固定CDNは最後に試す。再生側はprobeで確認したURLを実際のtransportへ渡します。
- 一覧の独立配色、画面高への収まり、フォーカス表示、低モーション設定を改善。
- Firefox manifestのversion_name削除を維持。

## 利用

Chrome: rplay-stable-player-extension を「パッケージ化されていない拡張機能」として読み込みます。
Firefox: rplay-stable-player-extension-firefox/manifest.json を一時的なアドオンとして読み込みます。
既存版がある場合は更新/再読み込みし、RPLAYタブも再読み込みしてください。新旧の拡張を同時に有効にしないでください。

配信一覧は「🔭」から開きます。BG保存リストはプレイヤーまたは配信一覧パネル内に表示されます。
ユーザースクリプト単体には拡張機能のBG録画機能はありません。BG録画は同時に1配信です。

## 検証範囲

QA_v2.21.0.md と evidence/v221-current を参照してください。
実RPLAY・実Chrome/Firefoxの拡張再読み込み・実保存先・Windowsは未検証。CANDIDATE_NO_GOを維持します。
MP4変換等の既存仕様は MP4_GUIDE_v2.20.0.md、従来説明は HISTORY_README_v2.20.0.md に残しています。
