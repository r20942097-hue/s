/* RPLAY generic disk-backed acquisition engine v1 (v2.49.0 — 汎用取得 段階設計 Stage 2).
   Stage 1 の segment_store(保存プリミティブ)の上に、明示選択候補のみを
   disk-backed で取得するエンジンを載せる。紀律は Stage 0..1 と完全不変:
     - 非破壊・fail-closed・虚偽零なし・ゼロシークレット・既定OFF
     - 入力は MediaCandidateRegistry が観測した候補(明示選択のみ・自動巡回なし)
     - RAM常駐は「現処理中の1セグメント」のみ(受信完了即 store.put → 参照解放)
     - 再起動後は台帳(ledger)と store メタで継続を判定
     - 任意時点で取消可能・取消時点のセグメントはdiskに残る(自動削除しない)
     - URL・トークン・Cookieは一切保持しない(候補ID・通し番号・バイト数・時刻のみ)
   本モジュールは保存・取得・取消・列挙・再開のみを行う。変換・連結・エクスポートは
   Stage 3 で既存の録画系経路へ接続するまでは呼ばれない(既定OFF・本番配線なし)。 */
(function(root){
'use strict';
function create(deps){
 deps=deps||{};
 const store=deps.store;
 const fetcher=typeof deps.fetcher==='function'?deps.fetcher:null;
 const fetchSegment=typeof deps.fetchSegment==='function'?deps.fetchSegment:null;
 const playlistParser=typeof deps.playlistParser==='function'?deps.playlistParser:null;
 const now=typeof deps.now==='function'?deps.now:Date.now;
 const ledger=deps.ledger||null;  // {read(),write(state)} JSON-backed state for restart
 const acquireTimeoutMs=Number.isSafeInteger(deps.acquireTimeoutMs)&&deps.acquireTimeoutMs>0?deps.acquireTimeoutMs:20000;
 const segmentTimeoutMs=Number.isSafeInteger(deps.segmentTimeoutMs)&&deps.segmentTimeoutMs>0?deps.segmentTimeoutMs:30000;

 if(!store||typeof store.put!=='function'||typeof store.get!=='function'||typeof store.list!=='function')throw Error('STORE_REQUIRED');
 if(!fetcher)throw Error('FETCHER_REQUIRED');
 if(!fetchSegment)throw Error('SEGMENT_FETCHER_REQUIRED');
 if(!playlistParser)throw Error('PLAYLIST_PARSER_REQUIRED');

 // Per-acquisition runtime state (RAM-only, bounded).
 // acquires[id] = {id, candidate, status, startedAt, updatedAt, segments:{seq->meta},
 //                  endListReached, cancelRequested, error, bytesAcquired, segmentsAcquired, segmentsSkipped}
 const acquires=new Map();
 const MAX_ACQUIRES=4;
 const MAX_SEGMENTS_PER=4096;
 const MAX_SEGMENTS_PER_ACQUIRE_HARDCAP=MAX_SEGMENTS_PER;

 function zeroSecret(o){
  if(typeof o!=='object'||!o)return o;
  const out={};
  for(const k of Object.keys(o)){
   if(k==='url'||k==='token'||k==='cookie'||k==='authorization'||k==='secret')continue;
   const v=o[k];
   if(typeof v==='string'&&(v.length>512||/bearer|token|secret|password/i.test(v)))continue;
   out[k]=v;
  }
  return out;
 }

 function newAcquire(id,candidate){
  if(acquires.size>=MAX_ACQUIRES)throw Error('TOO_MANY_ACQUIRES');
  if(acquires.has(id))throw Error('ID_EXISTS');
  const acq={
   id:String(id),
   candidate:{id:candidate.id,type:candidate.type||'unknown',source:candidate.source||'unknown'},
   status:'created',
   startedAt:null,
   updatedAt:now(),
   segments:new Map(),
   endListReached:false,
   cancelRequested:false,
   error:null,
   bytesAcquired:0,
   segmentsAcquired:0,
   segmentsSkipped:0,
   lastSequence:null,
   lastDiscontinuitySequence:0
  };
  acquires.set(id,acq);
  return acq;
 }

 function publicStatus(acq){
  if(!acq)return null;
  return {
   id:acq.id,
   candidate:acq.candidate,
   status:acq.status,
   startedAt:acq.startedAt,
   updatedAt:acq.updatedAt,
   endListReached:acq.endListReached,
   cancelRequested:acq.cancelRequested,
   error:acq.error?(typeof acq.error==='string'?acq.error:(acq.error.code||acq.error.message||'ERROR')):null,
   bytesAcquired:acq.bytesAcquired,
   segmentsAcquired:acq.segmentsAcquired,
   segmentsSkipped:acq.segmentsSkipped,
   lastSequence:acq.lastSequence,
   lastDiscontinuitySequence:acq.lastDiscontinuitySequence,
   segments:acq.segments.size
  };
 }

 function persistLedger(acq){
  if(!ledger)return;
  try{
   ledger.write({
    id:acq.id,
    candidate:acq.candidate,
    status:acq.status,
    startedAt:acq.startedAt,
    updatedAt:acq.updatedAt,
    endListReached:acq.endListReached,
    lastSequence:acq.lastSequence,
    lastDiscontinuitySequence:acq.lastDiscontinuitySequence,
    bytesAcquired:acq.bytesAcquired,
    segmentsAcquired:acq.segmentsAcquired,
    segmentsSkipped:acq.segmentsSkipped,
    error:acq.error?(typeof acq.error==='string'?acq.error:(acq.error.code||acq.error.message||'ERROR')):null,
    segmentIds:[...acq.segments.keys()]
   });
  }catch(e){ /* ledger persistence is best-effort but does not abort acquisition */ }
 }

 async function fetchPlaylistOnce(acq,url,signal){
  const r=await fetcher(url,{},acquireTimeoutMs,null,signal);
  if(!r||!r.ok||r.status!==200||!r.json){
   const code=r&&r.status?('HTTP_'+r.status):'PLAYLIST_FETCH_FAILED';
   const e=Error(code);e.code=code;throw e;
  }
  if(r.aborted){const e=Error('ABORTED');e.code='ABORTED';throw e;}
  return r.json;
 }

 async function fetchSegmentOnce(acq,url,signal){
  // Single in-flight segment cap: this Uint8Array is the only RAM-resident segment.
  // Caller must put() to the store and release the reference before fetching next.
  const r=await fetchSegment(url,{timeoutMs:segmentTimeoutMs,signal});
  if(!r||!r.ok||r.status!==200||!r.bytes){
   const code=r&&r.status?('HTTP_'+r.status):'SEGMENT_FETCH_FAILED';
   const e=Error(code);e.code=code;throw e;
  }
  if(r.aborted){const e=Error('ABORTED');e.code='ABORTED';throw e;}
  return r.bytes;
 }

 function segIdFor(acq,seq,discSeq){
  // Stable 16-hex id derived from acquisition id + sequence + discontinuity.
  // No URL/secret embedded.
  const buf=new Uint8Array(16);
  const acqHash=acq.id.length<=16?acq.id.padEnd(16,'0').slice(0,16):acq.id.slice(-16);
  for(let i=0;i<16;i++)buf[i]=acqHash.charCodeAt(i)&0xff;
  // Mix sequence + discSeq into the last 8 bytes (deterministic, no randomness).
  const seqNum=Number.isSafeInteger(seq)?seq:0;
  const discNum=Number.isSafeInteger(discSeq)?discSeq:0;
  for(let i=0;i<4;i++){buf[8+i]=(seqNum>>>(24-i*8))&0xff;buf[12+i]=(discNum>>>(24-i*8))&0xff;}
  const hex=[...buf].map(b=>b.toString(16).padStart(2,'0')).join('');
  // Force into [a-f0-9]{8,64} contract required by segment_store.
  return hex.replace(/[^a-f0-9]/g,'0');
 }

 async function ingestSegment(acq,seg,bytes,signal){
  if(acq.cancelRequested){const e=Error('CANCELLED');e.code='CANCELLED';throw e;}
  if(signal&&signal.aborted){const e=Error('ABORTED');e.code='ABORTED';throw e;}
  if(!(bytes instanceof Uint8Array)&&!(bytes instanceof ArrayBuffer)&&!ArrayBuffer.isView(bytes))
   {const e=Error('SEGMENT_BYTES_INVALID');e.code='SEGMENT_BYTES_INVALID';throw e;}
  const byteLen=bytes.byteLength||0;
  if(byteLen<=0){const e=Error('SEGMENT_EMPTY');e.code='SEGMENT_EMPTY';throw e;}
  if(byteLen>16*1048576){const e=Error('SEGMENT_TOO_LARGE');e.code='SEGMENT_TOO_LARGE';throw e;}
  const seq=Number.isSafeInteger(seg.sequence)?seg.sequence:null;
  const discSeq=Number.isSafeInteger(seg.discontinuitySequence)?seg.discontinuitySequence:0;
  if(seq===null){const e=Error('SEGMENT_NO_SEQUENCE');e.code='SEGMENT_NO_SEQUENCE';throw e;}
  const sid=segIdFor(acq,seq,discSeq);
  if(acq.segments.has(seq)){
   // Already acquired — skip non-destructively (don't re-fetch, don't overwrite).
   acq.segmentsSkipped++;
   acq.updatedAt=now();
   return {skipped:true,id:sid,sequence:seq};
  }
  // Immediate disk-backed put. RAM residency ends here.
  const put=await store.put({id:sid,bytes:bytes,
   digest:store.digest?await store.digest(bytes):null,
   pinned:true});
  acq.segments.set(seq,{id:sid,sequence:seq,bytes:byteLen,at:now(),
   discontinuity:Boolean(seg.discontinuity),discontinuitySequence:discSeq});
  acq.bytesAcquired+=byteLen;
  acq.segmentsAcquired++;
  acq.lastSequence=seq;
  acq.lastDiscontinuitySequence=discSeq;
  acq.updatedAt=now();
  persistLedger(acq);
  return {skipped:false,id:sid,sequence:seq,bytes:byteLen};
 }

 async function processPlaylist(acq,playlist,signal){
  if(!playlist||playlist.kind!=='media'||!Array.isArray(playlist.segments))
   {const e=Error('PLAYLIST_NOT_MEDIA');e.code='PLAYLIST_NOT_MEDIA';throw e;}
  for(const seg of playlist.segments){
   if(acq.cancelRequested){const e=Error('CANCELLED');e.code='CANCELLED';throw e;}
   if(signal&&signal.aborted){const e=Error('ABORTED');e.code='ABORTED';throw e;}
   if(acq.segmentsAcquired+acq.segmentsSkipped>=MAX_SEGMENTS_PER)
    {const e=Error('SEGMENT_LIMIT_REACHED');e.code='SEGMENT_LIMIT_REACHED';throw e;}
   if(seg.gap){acq.segmentsSkipped++;acq.updatedAt=now();continue;}
   if(acq.segments.has(seg.sequence)){acq.segmentsSkipped++;acq.updatedAt=now();continue;}
   // Resolve segment URL via playlist's own resolver (provided by parser).
   const url=typeof seg.uri==='function'?seg.uri():seg.uri;
   if(typeof url!=='string'||!url){const e=Error('SEGMENT_NO_URI');e.code='SEGMENT_NO_URI';throw e;}
   const bytes=await fetchSegmentOnce(acq,url,signal);
   await ingestSegment(acq,seg,bytes,signal);
  }
  if(playlist.endList)acq.endListReached=true;
  acq.updatedAt=now();
  persistLedger(acq);
 }

 return {
  MAX_ACQUIRES,
  MAX_SEGMENTS_PER,
  // start({id,candidate,initialPlaylistUrl,signal}) — explicit-candidate-only entry point.
  // Caller provides candidate observed by MediaCandidateRegistry; we do not iterate.
  async start({id,candidate,initialPlaylistUrl,signal,fetchPlaylist=true}={}){
   if(!id||typeof id!=='string'||id.length<1||id.length>128)throw Error('INVALID_ID');
   if(!candidate||typeof candidate.id!=='string')throw Error('INVALID_CANDIDATE');
   if(!initialPlaylistUrl||typeof initialPlaylistUrl!=='string')throw Error('INVALID_PLAYLIST_URL');
   const acq=newAcquire(id,candidate);
   acq.status='starting';
   acq.startedAt=now();
   acq.updatedAt=now();
   persistLedger(acq);
   try{
    if(fetchPlaylist){
     const plJson=await fetchPlaylistOnce(acq,initialPlaylistUrl,signal);
     const playlist=playlistParser(plJson,initialPlaylistUrl);
     acq.status='acquiring';
     persistLedger(acq);
     await processPlaylist(acq,playlist,signal);
     acq.status=acq.endListReached?'complete':'paused';
    }else{
     acq.status='paused';
    }
    acq.updatedAt=now();
    persistLedger(acq);
    return publicStatus(acq);
   }catch(e){
    acq.status=e.code==='CANCELLED'?'cancelled':'failed';
    acq.error=e;
    acq.updatedAt=now();
    persistLedger(acq);
    return publicStatus(acq);
   }
  },
  // continueFrom({id,playlistUrl,signal}) — restart continuation from persisted ledger.
  // Reads existing segment ids from store and skips them on re-fetch.
  async continueFrom({id,playlistUrl,signal}={}){
   if(!acquires.has(id))throw Error('NOT_FOUND');
   const acq=acquires.get(id);
   if(acq.status!=='paused'&&acq.status!=='failed')throw Error('NOT_RESUMABLE');
   acq.cancelRequested=false;
   acq.status='acquiring';
   acq.updatedAt=now();
   persistLedger(acq);
   try{
    const plJson=await fetchPlaylistOnce(acq,playlistUrl,signal);
    const playlist=playlistParser(plJson,playlistUrl);
    await processPlaylist(acq,playlist,signal);
    acq.status=acq.endListReached?'complete':'paused';
    acq.updatedAt=now();
    persistLedger(acq);
    return publicStatus(acq);
   }catch(e){
    acq.status=e.code==='CANCELLED'?'cancelled':'failed';
    acq.error=e;
    acq.updatedAt=now();
    persistLedger(acq);
    return publicStatus(acq);
   }
  },
  cancel(id){
   if(!acquires.has(id))return false;
   const acq=acquires.get(id);
   acq.cancelRequested=true;
   acq.status='cancelling';
   acq.updatedAt=now();
   persistLedger(acq);
   return true;
  },
  status(id){return publicStatus(acquires.get(id));},
  list(){return [...acquires.values()].map(publicStatus);},
  // listResidue(id) — enumerate on-disk segments remaining after cancel/crash.
  // Returns zero-secret meta only (no URLs, no secrets).
  async listResidue(id){
   if(!acquires.has(id))return null;
   const acq=acquires.get(id);
   const items=[];
   for(const [seq,meta] of acq.segments){
    items.push({sequence:seq,id:meta.id,bytes:meta.bytes,at:meta.at,
     discontinuity:meta.discontinuity,discontinuitySequence:meta.discontinuitySequence});
   }
   return {id:acq.id,status:acq.status,segments:items,bytesAcquired:acq.bytesAcquired,
    segmentsAcquired:acq.segmentsAcquired,lastSequence:acq.lastSequence};
  },
  // restore({id,candidate,ledgerState,knownSegmentIds}) — rehydrate from persisted ledger
  // after a browser restart. Acquire object's segment map is rebuilt from store.list()
  // filtered by knownSegmentIds. Status is 'paused' (caller may continueFrom).
  async restore({id,candidate,ledgerState,knownSegmentIds}={}){
   if(!id||!candidate)throw Error('INVALID_RESTORE');
   if(acquires.has(id))throw Error('ID_EXISTS');
   const acq=newAcquire(id,candidate);
   if(ledgerState){
    acq.status=ledgerState.status==='failed'?'paused':(ledgerState.status||'paused');
    acq.startedAt=ledgerState.startedAt||null;
    acq.endListReached=Boolean(ledgerState.endListReached);
    acq.lastSequence=ledgerState.lastSequence;
    acq.lastDiscontinuitySequence=ledgerState.lastDiscontinuitySequence||0;
    acq.bytesAcquired=ledgerState.bytesAcquired||0;
    acq.segmentsAcquired=ledgerState.segmentsAcquired||0;
    acq.segmentsSkipped=ledgerState.segmentsSkipped||0;
   }
   // Rebuild segment map from store (filtered by known ids or namespace).
   if(Array.isArray(knownSegmentIds)){
    for(const sid of knownSegmentIds){
     if(typeof sid!=='string')continue;
     try{
      const meta=await store.meta(sid);
      if(meta&&Number.isSafeInteger(meta.bytes)){
       // Reconstruct sequence from segIdFor convention (last 4 bytes = seq).
       // This is a deterministic reverse — no URL/secret needed.
       const buf=hexToBytes(sid);
       const seq=(buf[8]<<24|buf[9]<<16|buf[10]<<8|buf[11])>>>0;
       const discSeq=(buf[12]<<24|buf[13]<<16|buf[14]<<8|buf[15])>>>0;
       acq.segments.set(seq,{id:sid,sequence:seq,bytes:meta.bytes,at:meta.at||now(),
        discontinuity:false,discontinuitySequence:discSeq});
      }
     }catch(e){ /* skip meta read failure — non-destructive */ }
    }
   }
   acq.updatedAt=now();
   persistLedger(acq);
   return publicStatus(acq);
  },
  // discard(id) — drop acquire state. Does NOT delete on-disk segments (non-destructive).
  // Caller must invoke store.sweep() separately to reclaim space.
  discard(id){
   if(!acquires.has(id))return false;
   const acq=acquires.get(id);
   if(acq.status==='acquiring')throw Error('ACQUIRE_IN_PROGRESS');
   acquires.delete(id);
   if(ledger){try{ledger.clear();}catch(e){}}
   return true;
  },
  // zeroSecretScan(id) — verify no URL/token/cookie/secret leaks into acquire state.
  // Returns list of suspect fields (empty = clean). Used as acceptance test.
  zeroSecretScan(id){
   if(!acquires.has(id))return null;
   const acq=acquires.get(id);
   const suspect=[];
   const flat=JSON.stringify(publicStatus(acq));
   if(/https?:\/\//i.test(flat))suspect.push('url-in-status');
   if(/bearer|authorization|cookie|secret|password/i.test(flat))suspect.push('secret-keyword-in-status');
   return {clean:suspect.length===0,suspect};
  },
  _internal:{newAcquire,ingestSegment,processPlaylist,segIdFor,zeroSecret}
 };
}
function hexToBytes(hex){
 const out=new Uint8Array(hex.length/2);
 for(let i=0;i<hex.length;i+=2)out[i/2]=parseInt(hex.substr(i,2),16);
 return out;
}
if(typeof module!=='undefined')module.exports={create};
if(typeof root!=='undefined')root.RspSegmentAcquire={create};
})(typeof globalThis!=='undefined'?globalThis:this);
