/* =====================================================================
   RPLAY Stable Player — rec_worker.js (v2.0 Step2)
   =====================================================================
   MV3拡張ページ(offscreen document)のCSP(script-src 'self')はBlob URL
   Workerをブロックするため、録画コアのタイマー(ticker)とTS検証
   (verifier)をこの実ファイルWorkerで代替する。
   コア側のREC_TICK_WORKER_SRC/REC_VERIFY_WORKER_SRCと同じプロトコル:
     - {cmd:'start', ms} → ms間隔で {tick:true} を送り返す
     - {cmd:'stop'}     → 間隔タイマーを停止
     - {id, buf}        → TS先頭同期バイト(0x47)を検証して {id, ok} を返す
   ===================================================================== */
'use strict';

self.onmessage = function (e) {
  const d = e.data || {};
  if (d.cmd === 'start' && d.ms > 0) {
    self.__rspTick = setInterval(function () {
      self.postMessage({ tick: true });
    }, d.ms);
  } else if (d.cmd === 'stop') {
    if (self.__rspTick) { clearInterval(self.__rspTick); self.__rspTick = null; }
  } else if (d.buf) {
    const u8 = new Uint8Array(d.buf);
    let ok = u8.length > 188 && u8[0] === 0x47;
    if (ok && u8.length >= 376) ok = u8[188] === 0x47;
    if (ok && u8.length >= 564) ok = u8[376] === 0x47;
    self.postMessage({ id: d.id, ok: ok });
  }
};
