/* Recording ownership stays with the host, surviving router/SW recreation. */
(function(root){
'use strict';
function create(uuid, nextEpoch){
 let current=null;
 const oidOK=x=>typeof x==='string'&&/^[a-f0-9]{16,40}$/i.test(x);
 const ownerOK=x=>x&&Number.isInteger(x.tabId)&&x.tabId>=0&&typeof x.clientId==='string'&&/^[a-f0-9]{32}$/.test(x.clientId)&&typeof x.documentId==='string'&&x.documentId.length<=200;
 const same=(a,b)=>ownerOK(a)&&ownerOK(b)&&a.tabId===b.tabId&&a.documentId===b.documentId&&a.clientId===b.clientId;
 const ref=s=>s?{sessionId:s.sessionId,epoch:s.epoch,oid:s.oid}:null;
 const matches=(p,s)=>!!(p&&s&&p.sessionId===s.sessionId&&p.epoch===s.epoch&&p.oid===s.oid);
 return {
  begin(owner,oid){
   if(!ownerOK(owner)||!oidOK(oid))return {ok:false,error:'bad-control-identity'};
   oid=oid.toLowerCase();
   if(current){if(current.phase==='ACTIVE'&&current.oid===oid&&same(current.owner,owner))return {ok:true,existing:true,binding:current};return {ok:false,error:current.phase==='DRAINING'?'draining':'busy'};}
   // The epoch checkpoint is committed before any recording begins. No credentials.
   const epoch=nextEpoch();if(!Number.isSafeInteger(epoch)||epoch<1)throw Error('CONTROL_EPOCH_FAILED');
   current={sessionId:uuid(),epoch,oid,owner:{...owner},phase:'STARTING'};
   return {ok:true,binding:current};
  },
  activate(binding){if(current!==binding)throw Error('STALE_START');binding.phase='ACTIVE';},
  authorize(owner,p){return !!(current&&current.phase==='ACTIVE'&&same(current.owner,owner)&&matches(p,current));},
  claim(owner,p){
   if(!ownerOK(owner)||!current||current.phase!=='ACTIVE'||!matches(p,current))return {ok:false,error:'stale-session'};
   const epoch=nextEpoch();if(!Number.isSafeInteger(epoch)||epoch<=current.epoch)throw Error('CONTROL_EPOCH_FAILED');
   current.owner={...owner};current.epoch=epoch;return {ok:true,control:ref(current)};
  },
  draining(binding){if(current!==binding)throw Error('STALE_STOP');binding.phase='DRAINING';},
  end(binding){if(current===binding)current=null;},
  status(owner,oid){const s=current;const matching=!!(s&&s.oid===oid);return {canControl:!!(matching&&s.phase==='ACTIVE'&&same(s.owner,owner)),control:matching&&same(s.owner,owner)?ref(s):null,claim:matching&&s.phase==='ACTIVE'?ref(s):null,phase:s?s.phase:'IDLE',sessionId:s?s.sessionId:null,epoch:s?s.epoch:null};},
  binding(){return current;}
 };
}
const value={create};if(typeof module!=='undefined')module.exports=value;root.RspSessionGate=value;
})(typeof globalThis==='undefined'?this:globalThis);
