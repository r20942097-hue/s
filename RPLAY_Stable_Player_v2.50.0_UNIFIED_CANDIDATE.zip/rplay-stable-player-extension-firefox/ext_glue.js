/* =====================================================================
   RPLAY Stable Player — Extension Glue (ext_glue.js) v2.3.1 (Chrome Offscreen + Firefox Event Page Step3)
   =====================================================================
   Chrome拡張専用のcontent script(content.jsの後に読み込まれる)。
   user.js(=content.js)が公開する window.__RSP / RECボタンフック
   (window.__RSP_BG__)を介して、録画をoffscreen documentへ中継する。

   - RECボタン: user.jsが __RSP_BG__.routeClick() を呼ぶ → 本スクリプトが
     rec.start/rec.stop をSWへ送る(offscreenが実行)。
     二重録画の構造的排除: バックグラウンド録画中は常に中継を主張する。
   - 詳細設定へ「🖥 バックグラウンド録画」トグル(既定ON)+状態行を注入。
   - rec.eventで状態/統計/タイトル(●REC表示)をUIタブへ反映。
   - perm.request(保存先の権限失効)は案内と「📁 BG保存先」ボタンで再取得。
   ===================================================================== */
(function () {
  'use strict';
  const EXT_OK = typeof chrome !== 'undefined' && !!(chrome.runtime && chrome.runtime.id && chrome.runtime.sendMessage);
  if (!EXT_OK) return;

  const CLIENT_ID=crypto.randomUUID().replace(/-/g,'');
  let capCache = null;                 /* {offscreen:boolean} — 事前取得 */
  let statusCache = { recording: false };
  let starting = false;
  let lastSentJwt = '';
  let lastAutoKey = '';
  let autoRetryAt = 0;
  let autoPolicyRevision = 0;
  // Re-arm only when a saved prohibition is lifted. Other setting edits must
  // not undo the latch after a successful recording or a deliberate stop.
  if(chrome.storage && chrome.storage.onChanged){
    chrome.storage.onChanged.addListener(function(changes,area){
      const c=changes.rsp_dashboard_defaults;
      if(area!=='local'||!c||!c.oldValue||c.oldValue.autoStartAllowed!==false)return;
      const next=c.newValue;
      if(next!==undefined&&(!next||typeof next!=='object'||Array.isArray(next)||
        (next.autoStartAllowed!==undefined&&next.autoStartAllowed!==true)))return;
      autoPolicyRevision++;lastAutoKey='';autoRetryAt=0;
    });
  }

  function send(msg) {
    return new Promise(function (res) {
      try {
        chrome.runtime.sendMessage({...msg,clientId:CLIENT_ID}, function (r) {
          void chrome.runtime.lastError;
          res(r || null);
        });
      } catch (e) { res(null); }
    });
  }
  function bgEnabled() { try { return localStorage.getItem('rsp_bg_rec') !== '0'; } catch (e) { return true; } }
  function setBgEnabled(v) { try { localStorage.setItem('rsp_bg_rec', v ? '1' : '0'); } catch (e) {} }
  function opfsBackupEnabled() { try { return localStorage.getItem('rsp_opfs_backup') !== '0'; } catch (e) { return true; } }
  function setOpfsBackupEnabled(v) { try { localStorage.setItem('rsp_opfs_backup', v ? '1' : '0'); } catch (e) {} }
  async function cap() {
    if (capCache == null) {
      const r = await send({ type: 'bg.cap' });
      capCache = (r && typeof r.offscreen === 'boolean') ? r : { offscreen: false };
      try { document.documentElement.setAttribute('data-rsp-bg-cap', capCache.offscreen ? '1' : '0'); } catch (e) {}
    }
    return capCache;
  }
  function readJwt() {
    try {
      const v = localStorage.getItem('_AUTHORIZATION_');
      if (v && v.indexOf('.') > 0 && v.length > 20) return v;
    } catch (e) {}
    return '';
  }
  function readUserOid() {
    try {
      const jwt = readJwt();
      if (!jwt) return '';
      const p = JSON.parse(atob(jwt.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
      return (p && p.sub) ? p.sub : '';
    } catch (e) { return ''; }
  }
  function collectSettings(ui) {
    const s = {};
    const b = function (fn, d) { try { const v = fn(); return typeof v === 'boolean' ? v : d; } catch (e) { return d; } };
    if (ui) {
      s.follow = b(ui.followChecked, true);
      s.flv = b(ui.flvFallbackChecked, true);
      s.inheritQuery = b(ui.inheritQueryChecked, false);
      s.backlog = b(ui.backlogChecked, true);
      s.infoJson = b(ui.infoJsonChecked, false);
      s.notify = b(ui.notifyChecked, true);
      s.bestQ = b(ui.bestQualityChecked, true);
      s.recAudio = b(ui.recAudioChecked, false);
      s.csv = b(ui.csvChecked, false);
      try { s.nameTpl = String(ui.nameTplValue() || ''); } catch (e) { s.nameTpl = ''; }
      try { s.remind = String(ui.remindValue() || 'both'); } catch (e) { s.remind = 'both'; }
      try { s.splitMin = Math.max(0, Number(ui.splitMinutes()) || 0); } catch (e) { s.splitMin = 0; }
    }
    s.opfsBackup = opfsBackupEnabled();
    return s;
  }
  function panelLog(m) {
    try { if (window.__RSP && window.__RSP.ui && window.__RSP.ui.log) window.__RSP.ui.log(m); } catch (e) {}
  }
  function readAuthStats() {
    try {
      if (window.__RSP && typeof window.__RSP.authEvidence === 'function') {
        const ev = window.__RSP.authEvidence();
        if (ev && typeof ev === 'object') return ev;
      }
    } catch (e) {}
    const hasJwt = !!readJwt();
    const hasOid = !!readUserOid();
    if (!hasJwt && !hasOid) return undefined;
    return {
      mode: 'localStorage-interceptor',
      tokenSource: hasJwt ? 'localStorage' : null,
      refreshSource: null,
      userOidSupplied: hasOid,
      switchedToRefresh: false,
      refreshAttempts: 0,
      refreshSuccesses: 0,
      refreshFailures: 0,
      responseKey: null,
      classifications401: {},
      key2Resolutions: 0,
      butterSent: false,
      provenance: 'rspauth_counters'
    };
  }
  function readCanaryEvidence() {
    try {
      if (window.__RSP && typeof window.__RSP.canaryEvidence === 'function') {
        const ce = window.__RSP.canaryEvidence();
        if (ce && typeof ce === 'object') return ce;
      }
    } catch (e) {}
    return undefined;
  }
  function buildStartPayload(oid) {
    let creatorName = '';
    try {
      const m = document.querySelector('meta[property="og:title"]');
      creatorName = (m && m.getAttribute('content') || '').trim();
    } catch (e) {}
    let customM3u8 = '';
    try {
      if (window.__RSP && window.__RSP.engine && window.__RSP.engine.customM3u8) {
        customM3u8 = String(window.__RSP.engine.customM3u8);
      }
    } catch (e) {}
    const payload = {
      oid: oid,
      pageUrl: location.href,
      creatorName: creatorName,
      customM3u8: customM3u8,
      customFlv: '',
      titleBase: (document.title || '').slice(0, 200),
      jwt: readJwt(),
      userOid: readUserOid(),
      settings: collectSettings(window.__RSP ? window.__RSP.ui : null)
    };
    const authStats = readAuthStats();
    if (authStats) payload.authStats = authStats;
    const canaryEvidence = readCanaryEvidence();
    if (canaryEvidence) payload.canaryEvidence = canaryEvidence;
    return payload;
  }

  /* ---- 自動録画(v2.0: ページの「LIVE後に自動録画」がONでBG録画が有効なとき)。
     手動クリック(recClickAsync)と異なり「開始のみ」を行う — 停止は絶対にしない。
     (statusCacheの更新遅れによる、開始直後の誤停止を構造的に排除) ---- */
  async function autoRecAsync(key) {
    if (starting) return;
    starting = true;
    const revision=autoPolicyRevision;
    autoRetryAt=Date.now()+30000;
    try {
      const rsp = window.__RSP;
      const oid = (rsp && rsp.recorder) ? rsp.recorder.id.toLowerCase() : '';
      if (!oid) return;
      const st = await send({ type: 'rec.status', payload: { oid: oid } });
      if (st && st.recording) {lastAutoKey=key;return;} // 既に録画中 → 何もしない(停止は手動のみ)
      const c = await cap();
      if (!c.offscreen) return;
      panelLog('[BG] LIVEを検出 — 自動録画をバックグラウンドで開始します');
      const r = await send({ type: 'rec.start', payload: {...buildStartPayload(oid),automatic:true} });
      if(r && r.ok)lastAutoKey=key;
      else if(r && r.error==='AUTO_START_DISABLED' && revision===autoPolicyRevision)lastAutoKey=key;
      if (!(r && r.ok)) {
        const reason=r&&r.error;
        panelLog('[BG] '+(reason==='AUTO_START_DISABLED'?'保存済み設定により自動開始は禁止されています':reason==='START_SETTINGS_UNAVAILABLE'?'開始設定を確認できないため録画を開始しません。管理画面で保存済み設定を確認してください':'自動録画を開始できませんでした（30秒後以降に再確認）'));
      }
    } finally { starting = false; }
  }

  /* ---- RECクリック(非同期本体・手動: トグル動作) ---- */
  async function recClickAsync() {
    if (starting) return;
    starting = true;
    try {
      const rsp = window.__RSP;
      const oid = (rsp && rsp.recorder) ? rsp.recorder.id.toLowerCase() : '';
      const st = await send({ type: 'rec.status', payload: { oid: oid } });
      if (st && st.recording) {
        if(!st.canControl || st.oid!==oid){panelLog('[BG] このタブには録画の操作権がありません。対象配信で「録画を引き継ぐ」を選んでください');return;}
        const ack=await send({type:'rec.stop',payload:st.control});
        if(!ack || !ack.ok)panelLog('[BG] 停止を受け付けられませんでした。録画状態を再確認してください');
        return;
      }
      if (!oid) { panelLog('[BG] 対象IDを取得できません — ページを再読み込みしてからお試しください'); return; }
      if (!bgEnabled()) return;
      const c = await cap();
      if (!c.offscreen) { panelLog('[BG] このブラウザはoffscreen非対応のためページ内録画を使用します'); return; }
      const r = await send({ type: 'rec.start', payload: buildStartPayload(oid) });
      if (r && r.ok) {
        lastSentJwt = readJwt();
        panelLog('[BG] バックグラウンド録画へ移譲 — タブを閉じても録画は継続します'
          + (r.resumed ? '(前回セッションから復帰)' : ''));
      } else {
        const err = (r && r.error) ? '(' + r.error + ')' : '';
        if (r && r.error === 'busy') {
          panelLog('[BG] 他の配信(' + (r.oid || '') + ')をバックグラウンド録画中です — そちらを停止してから開始してください');
        } else {
          panelLog('[BG] バックグラウンド録画を開始できませんでした' + err + ' — ページ内録画(⏹/●)を再度お試しください');
        }
      }
    } finally {
      starting = false;
    }
  }

  /* ---- user.jsへの公開API(同期判定・非同期実行)。
     content scriptは分離ワールドで動くため、ページ側からも状態が見えるよう
     DOMマーカー(data-rsp-bg)も公開する(E2E/デバッグ用)。 ---- */
  try { document.documentElement.setAttribute('data-rsp-bg', 'ready'); } catch (e) {}
  window.__RSP_BG__ = {
    capability: function () { return cap(); },
    enabled: function () { return bgEnabled(); },
    setEnabled: function (v) { setBgEnabled(v); },
    routeClick: function () {
      if (!capCache || !capCache.offscreen) return false;        /* 非対応/未確定 → ページ内 */
      if (statusCache && statusCache.recording) { recClickAsync(); return true; } /* BG中 → 停止へ中継 */
      if (!bgEnabled()) return false;                            /* トグルOFF → ページ内 */
      recClickAsync();
      return true;
    },
    routeSplit: function () {
      if (!(statusCache && statusCache.recording)) return false;
      if(starting)return true;starting=true;
      (async function(){
        try{
          const oid=(window.__RSP && window.__RSP.recorder)?window.__RSP.recorder.id.toLowerCase():'';
          const st=await send({type:'rec.status',payload:{oid}});
          if(!st || !st.canControl || st.oid!==oid){panelLog('[BG] 分割にはこの録画の操作権が必要です');return;}
          const stopped=await send({type:'rec.stop',payload:st.control});
          if(!stopped || !stopped.ok)return;
          const started=await send({type:'rec.start',payload:buildStartPayload(oid)});
          if(!started || !started.ok)panelLog('[BG] 分割後の開始を確認できません。録画状態を確認してください');
        }finally{starting=false;}
      })();return true;
    },
    /* v2.39.0: ui.onLiveからの即時BG自動開始(ページ内録画との二重開始の構造的
       排除+即時性)。BGがこの自動開始を担うときtrueを返す(呼び出し側はページ内
       開始をしない)。trueには「処理済み/保存済み禁止latch/再試行待ち」も含む —
       禁止policyは全経路共通のためページ内へ逃がさない。BG無効(トグルOFF)や
       非対応確定時のみfalse → 呼び出し側はページ内開始を共通policyで判定。 */
    autoNow: function () {
      try {
        if (!bgEnabled()) return false;
        if (capCache && capCache.offscreen === false) return false;
        const rsp = window.__RSP;
        if (!rsp || !rsp.recorder || !rsp.recorder.id) return false;
        const key = rsp.recorder.id + ':LIVE';
        if (lastAutoKey === key) return true;      /* BG側で処理済み(成功/禁止) — ページ内開始させない */
        if (Date.now() < autoRetryAt) return true; /* 送信中/一時失敗の30秒バックオフ中もBG側へ任せる */
        autoRecAsync(key);
        return true;
      } catch (e) { return false; }
    }
  };

  /* ---- 詳細設定へのトグル注入 ---- */
  function ensureBgRow() {
    if (document.getElementById('rsp-bg-row')) return;
    const details = document.querySelector('#rsp-panel details.rsp-details') || document.querySelector('#rsp-disc details.rsp-dfoot');
    if (!details) return;
    const row = document.createElement('div');
    row.className = 'rsp-ctrls';
    row.id = 'rsp-bg-row';
    const chk = document.createElement('input');
    chk.type = 'checkbox';
    chk.checked = bgEnabled();
    const lbl = document.createElement('label');
    lbl.className = 'rsp-auto';
    lbl.title = '録画をタブの外(offscreen document)で実行します。タブを閉じても配信追跡・録画が継続します(保存先は「📁 BG保存先」で選択)。OFFにすると従来どおりページ内録画';
    lbl.appendChild(chk);
    lbl.appendChild(document.createTextNode('🖥 バックグラウンド録画(タブを閉じても継続)'));
    const stat = document.createElement('span');
    stat.className = 'rsp-lbl';
    stat.id = 'rsp-bg-stat';
    stat.style.cssText = 'font-size:10.5px;color:var(--rsp-muted);flex:1 1 100%;white-space:normal;';
    const bkChk = document.createElement('input');
    bkChk.type = 'checkbox';
    bkChk.checked = opfsBackupEnabled();
    const bkLbl = document.createElement('label');
    bkLbl.className = 'rsp-auto';
    bkLbl.title = '設計書§4.3: パート保存ごとにOPFS(rsp_backup/)へ最新2パートの複製を退避し、クラッシュ再起動時の保全と復旧記録を行います(既定ON)';
    bkLbl.appendChild(bkChk);
    bkLbl.appendChild(document.createTextNode('🛡 OPFS退避'));
    bkChk.addEventListener('change', function () {
      setOpfsBackupEnabled(bkChk.checked);
      panelLog(bkChk.checked ? '[BG] OPFS最新2パート退避を有効化(クラッシュ保全ON)'
                             : '[BG] OPFS最新2パート退避を無効化');
    });
    const folderBtn = document.createElement('button');
    folderBtn.className = 'rsp-btn';
    folderBtn.id = 'rsp-bg-folder-btn';
    if (capCache && capCache.fsa === false) {
      folderBtn.textContent = '📥 RPLAY/へ自動DL';
      folderBtn.disabled = true;
      folderBtn.title = 'Firefox版バックグラウンド録画(Step3)ではOPFS確定書込後にブラウザのダウンロード(RPLAY/フォルダ)へ自動保存します';
    } else {
      folderBtn.textContent = '📁 BG保存先';
      folderBtn.title = 'バックグラウンド録画の保存先フォルダを選択(拡張ページでFile System Accessにより選択し、offscreen録画と共有します)';
      folderBtn.addEventListener('click', function () { send({ type: 'pick.open' }); });
    }
    chk.addEventListener('change', function () {
      setBgEnabled(chk.checked);
      panelLog(chk.checked ? '[BG] バックグラウンド録画を有効化 — 次回の●録画開始からバックグラウンドで実行します'
                           : '[BG] バックグラウンド録画を無効化 — ページ内録画に戻します');
    });
    row.appendChild(lbl);
    row.appendChild(bkLbl);
    row.appendChild(stat);
    row.appendChild(folderBtn);
    const claimBtn=document.createElement('button');claimBtn.id='rsp-bg-claim';claimBtn.className='rsp-btn';claimBtn.textContent='録画を引き継ぐ';
    claimBtn.title='同じ配信のバックグラウンド録画を、このタブから操作できるようにします。前のタブの操作権は失効します';
    claimBtn.addEventListener('click',async()=>{
      const oid=(window.__RSP&&window.__RSP.recorder)?window.__RSP.recorder.id.toLowerCase():'';
      const st=await send({type:'rec.status',payload:{oid}});
      if(!st || !st.claim || st.oid!==oid){panelLog('[BG] 引き継げる録画がありません');return;}
      if(st.canControl){panelLog('[BG] このタブが録画を操作しています');return;}
      const ack=await send({type:'rec.claim',payload:st.claim});
      if(ack&&ack.ok){lastSentJwt='';panelLog('[BG] 録画の操作をこのタブへ引き継ぎました');}
      else panelLog('[BG] 録画の状態が変わったため引き継げませんでした。再確認してください');
      const fresh=await send({type:'rec.status',payload:{oid}});if(fresh){statusCache=fresh;renderStatus();}
    });row.appendChild(claimBtn);
    const retryBtn=document.createElement('button');retryBtn.className='rsp-btn';retryBtn.textContent='保存を再試行';retryBtn.title='OPFSに保持した失敗パートを再保存します';retryBtn.addEventListener('click',()=>send({type:'export.retry'}).then(()=>panelLog('[BG] 保存再試行を要求しました。完了/失敗の件数を確認してください')));row.appendChild(retryBtn);
    const recoveryBtn=document.createElement('button');recoveryBtn.className='rsp-btn';recoveryBtn.textContent='録画データを復旧';recoveryBtn.addEventListener('click',()=>send({type:'recovery.open'}));row.appendChild(recoveryBtn);
    const mp4Btn=document.createElement('button');mp4Btn.className='rsp-btn';mp4Btn.textContent='TSをMP4へ変換';mp4Btn.addEventListener('click',()=>send({type:'mp4.open'}));row.appendChild(mp4Btn);
    const openBtn = document.createElement('button'); openBtn.className = 'rsp-btn'; openBtn.id = 'rsp-bg-open'; openBtn.textContent = '録画中の配信を開く';
    openBtn.addEventListener('click', () => { const oid = statusCache.oid; if (/^[0-9a-f]{24}$/i.test(oid || '')) window.open('/live?creatorOid=' + encodeURIComponent(oid), '_blank', 'noopener'); });
    row.appendChild(openBtn);
    const inspectBtn=document.createElement('button');inspectBtn.className='rsp-btn';inspectBtn.textContent='メディア診断';inspectBtn.addEventListener('click',()=>send({type:'media.inspect.open'}));row.appendChild(inspectBtn);
    details.appendChild(row);
    const listBox = document.createElement('details');
    listBox.id = 'rsp-bg-listbox'; listBox.open = true;
    const summary = document.createElement('summary'); summary.textContent = 'BG録画・保存リスト（最新100件）';
    const list = document.createElement('ul'); list.id = 'rsp-bg-list'; list.className = 'rsp-bg-list';
    listBox.appendChild(summary); listBox.appendChild(list);
    const body = document.querySelector('#rsp-panel .rsp-body');
    (body || details.parentNode).appendChild(listBox);

  }

  function renderPartList() {
    const list = document.getElementById('rsp-bg-list'); if (!list) return;
    const ex = statusCache.exports || {};
    const downloads = (ex.items || []).map(p => ({...p,track:'DL'}));
    const names = new Set(downloads.map(p => p.name.replace(/_a\d+(\.[^.]+)$/, '$1')));
    const parts = (statusCache.parts || []).filter(p => p.status !== 'OPFS_STAGED' || !names.has(p.name));
    const items = parts.slice().reverse().concat(downloads).slice(0,100);
    const labels = {OPFS_STAGED:'一時退避済み・DL状態を確認',DOWNLOAD_REQUESTED:'DL要求・未確認',recording:'録画中',pending:'保存処理中',FILE_CLOSED:'ローカル保存確定',BROWSER_DONE:'DL完了',verified:'DLサイズ照合済み',requested:'DL要求・未確認',unverified:'完了未確認',complete_unknown:'DL完了・サイズ未確認',interrupted:'DL中断',size_mismatch:'サイズ不一致',request_failed:'DL要求失敗',failed:'保存失敗'};
    list.textContent = '';
    if (!items.length) { const row = document.createElement('li'); row.textContent = '録画パートはありません。録画開始後にここへ表示します'; list.appendChild(row); }
    for (const part of items) {
      const row = document.createElement('li');
      row.textContent = '[' + (part.track || 'video') + '] ' + String(part.name || '') + ' — ' + (Number(part.size || 0)/1048576).toFixed(1) + 'MB / ' + (labels[part.status] || '保存状態: ' + part.status);
      list.appendChild(row);
    }
  }
  function renderStatus() {
    renderPartList();
    const openBtn = document.getElementById('rsp-bg-open');
    if (openBtn) openBtn.disabled = !statusCache.recording || !/^[0-9a-f]{24}$/i.test(statusCache.oid || '');
    const claimBtn = document.getElementById('rsp-bg-claim');
    const myOid = window.__RSP && window.__RSP.recorder ? window.__RSP.recorder.id.toLowerCase() : '';
    if (claimBtn) claimBtn.disabled = !statusCache.recording || !myOid || myOid !== statusCache.oid || !!statusCache.canControl;
    const el = document.getElementById('rsp-bg-stat');
    if (!el) return;
    if (statusCache && statusCache.recording) {
      const s = statusCache.stats || {};
      const myOid = (window.__RSP && window.__RSP.recorder) ? window.__RSP.recorder.id.toLowerCase() : '';
      if (statusCache.oid && myOid && statusCache.oid !== myOid) {
        el.textContent = '🖥 別の配信を録画中(' + statusCache.oid.slice(0, 8) + '…)';
        el.title = '他のクリエイターのバックグラウンド録画が進行中です';
        return;
      }
      if (s.state === 'STANDBY') {
        el.textContent = '🖥⏸ 追跡待機中・保存' + (s.files || 0) + '本';
      } else {
        el.textContent = '🖥● ' + (s.totalMb || 0).toFixed(1) + 'MB・' + (s.seg || 0) + 'seg' +
          (s.medium === 'flv' ? '・FLV' : '') + '・保存' + (s.files || 0) + '本';
      }
      const ex=statusCache.exports||{};el.textContent+='・DL完了'+(ex.verified||0)+'・未確認'+((ex.unknown||0)+(ex.requested||0))+'・失敗'+(ex.failed||0);
      el.textContent+=statusCache.canControl?'・操作中':'・操作権なし';
      el.title='保存本数はローカル確定。DL件数は累計。別タブからの操作は明示的な引き継ぎが必要です';
    } else {
      const ex=statusCache.exports||{},h=statusCache.exportHost||{};el.textContent=statusCache.draining?'保存処理中':('DL完了'+(ex.verified||0)+'・未確認'+((ex.unknown||0)+(ex.requested||0))+'・失敗'+(ex.failed||0)+'・保持'+(h.retained||0));
      el.title=statusCache.exportError?'保存台帳を確認できません': '保存結果を確認し、失敗時は再試行できます';
    }
  }

  /* ---- イベント受信(SW → 全タブ配信) ---- */
  chrome.runtime.onMessage.addListener(function (msg, sender, reply) {
    if (!msg || typeof msg !== 'object') return false;
    if (msg.type === 'rec.event' || msg.type === 'rec.stopped') {
      const oid=(window.__RSP&&window.__RSP.recorder)?window.__RSP.recorder.id.toLowerCase():'';
      if(msg.oid && msg.oid!==oid)return false;
      if(msg.sessionId && statusCache.sessionId && msg.sessionId!==statusCache.sessionId)return false;
      if(msg.sessionId===statusCache.sessionId && Number.isInteger(msg.epoch) && Number.isInteger(statusCache.epoch) && msg.epoch<statusCache.epoch)return false;
      if(msg.sessionId===statusCache.sessionId && msg.epoch!==statusCache.epoch){statusCache.canControl=false;statusCache.control=null;}
    }
    if (msg.type === 'rec.event') {
      if (msg.kind === 'stats') {
        statusCache = {...statusCache,recording:true,oid:msg.oid,sessionId:msg.sessionId,epoch:msg.epoch,stats:msg.stats||{}};
        try { if (statusCache.oid === undefined) statusCache.oid = (window.__RSP && window.__RSP.recorder) ? window.__RSP.recorder.id.toLowerCase() : ''; } catch (e) {}
      } else if (msg.kind === 'state') {
        statusCache={...statusCache,recording:!!msg.on,draining:msg.state==='DRAINING',oid:msg.oid,sessionId:msg.sessionId,epoch:msg.epoch};
        if (!msg.on) panelLog('[BG] バックグラウンド録画が停止しました');
      } else if (msg.kind === 'title') {
        try { document.title = String(msg.title || ''); } catch (e) {}
      } else if (msg.kind === 'log') {
        const line = String(msg.line || '');
        const i = line.indexOf('[REC]');
        if (i >= 0) panelLog('[BG]' + line.slice(i + 5));
      }
      renderStatus();
      return false;
    }
    if (msg.type === 'rec.stopped') {
      statusCache = {recording:false,exports:statusCache.exports};
      renderStatus();
      return false;
    }
    if (msg.type === 'perm.request') {
      panelLog('[BG] 保存先フォルダの権限が失効しました — 詳細設定の「📁 BG保存先」で再選択してください(その間の録画はダウンロード方式で退避します)');
      renderStatus();
      return false;
    }
    if (msg.type === 'pick.stored') {
      panelLog('[BG] 保存先フォルダを設定しました: ' + (msg.name || 'folder'));
      return false;
    }
    return false;
  });

  /* ---- 常駐監視: トグル注入/状態更新/自動録画/トークン新鮮化 ---- */
  (function loop() {
    try {
      ensureBgRow();
    } catch (e) {}
    (async function () {
      /* パネルがあるライブページでのみステータスを取る(不要な通信をしない) */
      if (document.getElementById('rsp-panel') || document.getElementById('rsp-disc')) {
        const st = await send({ type: 'rec.status', payload: { oid: (window.__RSP && window.__RSP.recorder) ? window.__RSP.recorder.id.toLowerCase() : '' } });
        if (st) {
          statusCache = st;
          renderStatus();
          /* BG録画中の配信にライブタブがある → 最新トークンを受け渡す(短命JWT追従) */
          if (st.recording && st.canControl && st.control && readJwt()) {
            const mine = readJwt();
            if (st.oid === ((window.__RSP && window.__RSP.recorder) ? window.__RSP.recorder.id.toLowerCase() : '') && mine !== lastSentJwt) {
              const ack = await send({type:'token.update',payload:{...st.control,jwt:mine,userOid:readUserOid(),authStats:readAuthStats(),canaryEvidence:readCanaryEvidence()}});
              if (ack && ack.ok) lastSentJwt = mine;
            }
          }
        }
      }
      /* v2.0: 自動録画(開始専用のautoRecAsync — statusCacheの遅れに依存しない) */
      try {
        const rsp = window.__RSP;
        if (rsp && rsp.ui && rsp.recorder && rsp.ui.state === 'LIVE' &&
            rsp.ui.autoRecChecked && rsp.ui.autoRecChecked() &&
            bgEnabled() && !starting) {
          const key = rsp.recorder.id + ':LIVE';
          if (lastAutoKey !== key && Date.now()>=autoRetryAt) {
            autoRecAsync(key);
          }
        }
      } catch (e) {}
    })().catch(() => {}).finally(() => setTimeout(loop, 3000));
  })();

  /* 機能判別を先回りで取得(RECクリックの同期判定に間に合わせる) */
  cap();
})();
