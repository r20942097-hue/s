/* RPLAY disk-backed segment store v1 (v2.44.0 — 汎用取得 段階設計 Stage 1 基盤).
   OPFS上の名前空間ディレクトリへセグメント本体(.bin)とメタ(.json)を
   ペアで書き込み、容量・件数予算の範囲で古い未ピン留めセグメントから退避する。
   紀律: 検証失敗・書き込み失敗はfail-closed(中途半端なデータを返さない)。
   取得経路・ネットワーク・URLは一切扱わない(保存プリミティブのみ)。 */
(function(root){
'use strict';
function create(deps){
 deps=deps||{};
 const storage=deps.storage&&typeof deps.storage.getDirectory==='function'?deps.storage:null;
 const digest=typeof deps.digest==='function'?deps.digest:null;
 const now=typeof deps.now==='function'?deps.now:Date.now;
 const NS=/^[a-z0-9_-]{1,40}$/i;
 const ID=/^[a-f0-9]{8,64}$/i;
 const namespace=NS.test(deps.namespace||'')?deps.namespace:'default';
 const maxBytes=Number.isSafeInteger(deps.maxBytes)&&deps.maxBytes>0?deps.maxBytes:512*1048576;
 const maxCount=Number.isSafeInteger(deps.maxCount)&&deps.maxCount>0?deps.maxCount:2048;
 const maxSegmentBytes=Number.isSafeInteger(deps.maxSegmentBytes)&&deps.maxSegmentBytes>0?deps.maxSegmentBytes:16*1048576;
 if(!storage)throw Error('STORAGE_UNAVAILABLE');
 const AREA='rsp_seg';
 async function dir(){const rootDir=await storage.getDirectory();return rootDir.getDirectoryHandle(AREA,{create:true}).then(a=>a.getDirectoryHandle(namespace,{create:true}));}
 function toU8(bytes){
  if(bytes instanceof Uint8Array)return bytes;
  if(bytes instanceof ArrayBuffer)return new Uint8Array(bytes);
  if(ArrayBuffer.isView(bytes))return new Uint8Array(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  return null;
 }
 async function readJson(name){
  const d=await dir();
  const fh=await d.getFileHandle(name);
  const f=await fh.getFile();
  if(f.size>4096)throw Error('SEGMENT_META_INVALID');
  const meta=JSON.parse(await f.text());
  if(!meta||!ID.test(meta.id||'')||!Number.isSafeInteger(meta.bytes)||meta.bytes<0||typeof meta.at!=='number'||!Number.isFinite(meta.at))throw Error('SEGMENT_META_INVALID');
  return meta;
 }
 async function writeJson(name,obj,limit){
  const d=await dir();
  const fh=await d.getFileHandle(name,{create:true});
  let w=null;
  try{
   w=await fh.createWritable();
   const data=new TextEncoder().encode(JSON.stringify(obj));
   if(data.length>(limit||4096))throw Error('SEGMENT_META_INVALID');
   await w.write(data);
   await w.close();w=null;
  }catch(e){if(w)try{await w.abort();}catch(ignored){}throw e;}
 }
 async function removeQuiet(d,name){try{await d.removeEntry(name);}catch(e){}}
 async function evict(d,reserveId,needBytes,needCount){
  const entries=await list();
  let used=entries.filter(e=>e.id!==reserveId).reduce((s,e)=>s+e.bytes,0);
  let count=entries.filter(e=>e.id!==reserveId).length;
  let evicted=0;
  for(const e of entries){
   if(used+needBytes<=maxBytes&&count+needCount<=maxCount)break;
   if(e.id===reserveId||e.pinned)continue;
   await removeQuiet(d,e.id+'.bin');await removeQuiet(d,e.id+'.json');
   used-=e.bytes;count--;evicted++;
  }
  if(used+needBytes>maxBytes||count+needCount>maxCount)throw Error('SEGMENT_BUDGET_EXCEEDED');
  return evicted;
 }
 async function list(){
  const d=await dir();
  const out=[];let scanned=0;
  for await(const [name,h] of d.entries()){
   if(++scanned>4*maxCount)break;
   if(h.kind!=='file'||!name.endsWith('.json'))continue;
   const id=name.slice(0,-5);
   if(!ID.test(id))continue;
   try{const meta=await readJson(name);out.push({id:meta.id,bytes:meta.bytes,at:meta.at,pinned:meta.pinned===true});}
   catch(e){}
   if(out.length>=maxCount)break;
  }
  out.sort((a,b)=>a.at-b.at);
  return out;
 }
 return {
  async put(id,bytes,opts){
   if(!ID.test(id||''))throw Error('BAD_SEGMENT_ID');
   const u8=toU8(bytes);
   if(!u8||!u8.length||u8.length>maxSegmentBytes)throw Error('BAD_SEGMENT_BYTES');
   const at=now();
   const meta={id:id,bytes:u8.length,at:at,pinned:!!(opts&&opts.pin)};
   if(digest)meta.sha256=await digest(u8);
   const d=await dir();
   const evicted=await evict(d,id,u8.length,1);
   let w=null;
   try{
    const fh=await d.getFileHandle(id+'.bin',{create:true});
    w=await fh.createWritable();
    await w.write(u8);
    await w.close();w=null;
   }catch(e){if(w)try{await w.abort();}catch(ignored){}throw Error('SEGMENT_WRITE_FAILED');}
   try{
    await writeJson(id+'.json',meta);
   }catch(e){
    await removeQuiet(d,id+'.bin');
    throw Error('SEGMENT_WRITE_FAILED');
   }
   return {id:id,bytes:u8.length,at:at,pinned:meta.pinned,sha256:meta.sha256||null,evicted:evicted};
  },
  async get(id){
   if(!ID.test(id||''))throw Error('BAD_SEGMENT_ID');
   const d=await dir();
   const meta=await readJson(id+'.json');
   const fh=await d.getFileHandle(id+'.bin');
   const f=await fh.getFile();
   if(f.size!==meta.bytes)throw Error('SEGMENT_SIZE_MISMATCH');
   const u8=new Uint8Array(await f.arrayBuffer());
   if(digest&&meta.sha256){
    if(await digest(u8)!==meta.sha256)throw Error('SEGMENT_DIGEST_MISMATCH');
   }
   if(now()-meta.at>0){try{await writeJson(id+'.json',{...meta,at:now()});}catch(e){}}
   return {bytes:u8,meta:meta};
  },
  async has(id){
   if(!ID.test(id||''))return false;
   try{await readJson(id+'.json');return true;}catch(e){return false;}
  },
  async setPinned(id,pinned){
   if(!ID.test(id||''))throw Error('BAD_SEGMENT_ID');
   const meta=await readJson(id+'.json');
   await writeJson(id+'.json',{...meta,pinned:pinned===true});
   return {ok:true,pinned:pinned===true};
  },
  async delete(id){
   if(!ID.test(id||''))throw Error('BAD_SEGMENT_ID');
   const d=await dir();
   let removed=false;
   for(const suffix of ['.bin','.json']){
    try{await d.getFileHandle(id+suffix);await d.removeEntry(id+suffix);removed=true;}
    catch(e){}
   }
   return {ok:true,removed:removed};
  },
  list,
  async sweep(){
   const d=await dir();
   const names=new Set();let scanned=0;
   for await(const [name,h] of d.entries()){
    if(++scanned>4*maxCount)break;
    if(h.kind==='file')names.add(name);
   }
   let orphans=0;
   for(const name of names){
    if(name.endsWith('.bin')){
     const id=name.slice(0,-4);
     if(!ID.test(id)||!names.has(id+'.json')){await removeQuiet(d,name);orphans++;}
    }else if(name.endsWith('.json')){
     const id=name.slice(0,-5);
     if(!ID.test(id)||!names.has(id+'.bin')){await removeQuiet(d,name);orphans++;}
    }
   }
   return {ok:true,orphans:orphans};
  },
  async stats(){
   const entries=await list();
   return {count:entries.length,bytes:entries.reduce((s,e)=>s+e.bytes,0),maxBytes,maxCount,namespace};
  }
 };
}
const value={create};
if(typeof module!=='undefined')module.exports=value;
root.RspSegmentStore=value;
})(typeof globalThis==='undefined'?this:globalThis);
