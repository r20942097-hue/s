# v2.25.0 検証

2026-10-26 JST / CANDIDATE_NO_GO。現在版は evidence/v225-current と evidence/firefox-v225。旧版証拠は履歴。
追加8件: 実HTTP映像/音声クエリ継承ON/OFF、子値保持/別origin拒否、連続diskの容量分割抑止、UI/BG配線、BG boolean設定反映。
全回帰はNode449 + Python165 = 614件。最終実測はVALIDATION.json。
Firefox158.0.1/Linux/headless一時拡張で27項目（26 PASS / 1 BLOCKED）。Worker/OPFS/復旧/改変拒否/中断/約77MB/独立disk SHA/FFmpeg全decode/600px。ルートUIは実DOMとAPIスタブ。実RPLAY受入ではない。
BLOCKEDはnative preview再生時刻進行（通常MP4対照も時刻0）。sandbox調整は使い捨て試験profileのみ、製品変更なし。
Windows・実RPLAY・2GiB・長時間は未合格。連続diskの3GiB条件は状態モックであり実大容量の保存試験ではない。

最終ZIPはCRC・全SHA台帳を検査し、包装後に追加した証拠/資料以外の全ファイルを試験済み展開ツリーとバイト照合。独立再包装も同一SHAを確認。FirefoxもZIP展開ツリーから再試験済み。
