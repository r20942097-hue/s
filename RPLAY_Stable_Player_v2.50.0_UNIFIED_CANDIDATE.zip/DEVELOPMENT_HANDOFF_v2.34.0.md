# v2.34.0

resolveList第3引数signal/onProgress、lookupCustom第3引数signal。dashboardでAbortController所有、pagehideで中断、storage commit前にsignal最終確認。storage書込み開始後はcancel disabled。入力ロックで実行中編集の喪失防止。
次: 複数windowの登録更新競合、名前/元URLmetadataの保持、実API fixture、予約一覧外部化。
