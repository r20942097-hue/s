# 添付整理・統合判断（2026-10-26 JST）

## 原本と系統

|添付|判定|開発での扱い|
|---|---|---|
|Stable Player v2.21.0 (1)|SHA-256 18e4c992…、本チャットのv2.21と完全一致|既知スナップショットとして保全|
|dRPLAY v2.21.0|SHA-256 d998a5b0…、別実装系統|差分を選択確認|
|Development Handoff v2.21|内包ZIPがdRPLAYとバイト一致|同じ系統の引き継ぎ資料|
|Media Sniffer 1.0.0|全サイト捕捉型のChrome MV3拡張、22エントリ|参考資料として解析。製品へのコードコピーはしない|

正確な全SHA-256・サイズ・ZIP CRC・内包ledger照合は INPUT_RECONCILIATION_v2.23.0.json。
主ベースは本チャットのv2.22.0（Firefox Worker/OPFS/MP4検査を含む）を維持しました。
dRPLAYのREADMEとSOURCE_MANIFESTはv2.20表記が残り、引き継ぎ資料はv2.21/557件を申告しています。557件は添付資料の記録で、今回その別系統テスト一式を再実行した値ではありません。

## 取り込みと見送り

|項目|判断・実装|
|---|---|
|/live?creatorOid=…が対象にならない|採用。24桁IDとURL形状を明確にする独立実装で修正|
|クエリだけ変わるSPAルート|採用。配信者変更を検出し、追跡パラメータだけなら既存インスタンスを保持|
|署名付きURL|全プレイリスト取得経路で余分な_rspクエリを削除。cache:no-storeを使用|
|200 HTMLをLIVEとする判定|修正。Engineは先頭EXTM3Uとメディア/variantを確認し、壊れた優先源から次候補へ進む|
|probe本文の無制限読み込み|Engineのprobeに2MiB上限、本文読取り中のtimeout、destroy時abortを追加|
|MIME/拡張子/本文の診断|Snifferから機能要件を参考に、通信しないローカル診断を独立実装|
|curl/ffmpeg生成|PowerShell 7.3以降/POSIX shを明示。リテラル引用、制御文字拒否、ffmpeg -n、curl --no-clobber|
|全サイトのMAIN-world捕捉|今回取り込まない。既存のサイト処理・権限・秘密情報保持への影響を別途検証する必要あり|
|4タブUI/BG永続セッション台帳|別系統の機能候補として整理。既存v2.22の所有権/保存台帳との統合検証を先に行う|
|WebVTT結合|異なるX-TIMESTAMP-MAPを扱う前に時刻変換と重複判定を検証する。元forkは先頭mapを保持してcueを結合する実装|
|別音声mux・PSI検査|次候補。forkのverify_ts_psiはファイル全体read_bytesを行うため、そのまま大容量経路へ入れない|
|LL-HLS差分/暗号化等の制限|現行の安全側判定を維持。診断機能が付いても、録画/変換側の未対応が自動的に解消したとは扱わない|

## Media Sniffer 1.0.0の具体的な改善点

- typeFromMimeは汎用audio/*を先に返すため、拡張子のないaudio/x-mpegurlはaudio判定になります。
- .tsが拡張子表ではvideo、MIME video/mp2tではtsのため、MIMEなしのTSがtsフィルタから外れます。
- commands.jsの二重引用は引用符だけを置換し、POSIXの$()やバッククォート展開を防いでいません。ffmpeg -yも既存出力を上書きします。
- fetchフックはclone().text()で本文全体を読んでからsliceするため、MAX_TEXTが読取メモリ上限にはなりません。さらに元のfetch応答を返すまで本文取得を待ちます。
- tabState/pending/SENTに総件数/TTL上限がなく、parseCacheはライブ本文の鮮度期限を持ちません。長時間の状態管理を要改善。
- MAIN-worldのpostMessage内容はページ自身も生成できます。内部APIへ渡す前の型・サイズ・発信元権限の検証が必要です。
- blob:の利用可否はオブジェクトの実体と生成元の文脈によります。「blobは常にダウンロード不可」と一般化しません。
- READMEに上流MITへの言及はありますが、ZIP内にはLICENSEファイルがありません。今回の機能は独立実装で、元コードのライセンスを推定してコピーしていません。

## 公式資料の検索結果と適用

- MDN webRequest.onHeadersReceived: https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/webRequest/onHeadersReceived
- Chrome webRequest: https://developer.chrome.com/docs/extensions/reference/api/webRequest
  観測とブロッキングを区別し、ブラウザ固有の本文捕捉機構を同一視しません。
- Microsoft PowerShell引用規則: https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_quoting_rules
  一重引用のリテラルと連続一重引用によるエスケープを使用。Windows実機でのnative argv検証は未実施。
- FFmpeg: https://ffmpeg.org/ffmpeg.html
  -nで既存MP4の上書きを拒否。MP4/AAC用ビットストリーム変換と他コーデックを区別し、全入力へAACフィルターを強制しません。

今後の優先順: Windows/実RPLAY受入 → 大容量/長時間 → BG永続台帳の移行設計 → WebVTT/別音声 → 捕捉系の権限/保存/寿命設計。
