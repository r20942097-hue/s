# v2.36.0 QA

追加Node10件: 設定既定値/不正type/並行保存/未読込・lock非対応/再編集、JSON UTF8境界/宣言長超過/実受信超過/上限ちょうど/stream非対応。旧本文abort fixtureをstream契約へ更新しました。

ブラウザ追加2件: 別画面更新後の設定保存拒否と明示再読込、保存済み設定不正時の保存無効化と修復後再読込。native Web Locksを使用。API fixtureはmockで実サービス受入ではありません。テスト用の使い捨てLinux profileだけsandboxを調整しました。配布版は設定を変更しません。

根拠資料: MDN Using readable streams https://developer.mozilla.org/en-US/docs/Web/API/Streams_API/Using_readable_streams （2026-10-27参照）。response.bodyのstream読込とAbortControllerによる取消を確認し、独自の上限検査を実装しました。

2026-10-27: 全回帰672件PASS（Node507/Python165）。Firefox 158.0.1/LinuxとFloorp v12.20.2/Linuxはそれぞれ34 PASS/1 BLOCKED。保存済み設定の競合・不正データ回復を実DOM/native Web Locksで確認。TS→MP4の独立disk SHA256、FFmpeg全decode、AAC保存、OPFS復旧・取消、64MiB超入力を継承検証。native previewの時間進行はcontrol MP4でも0のままのため未合格。実RPLAY/Windows/2GiB/長時間も未確認。

試験対象のruntime・test本体・buildを最終成果物とbyte比較済み。検証スクリプトの固定日付と結果説明だけ試験後に訂正し、Python構文確認済み。報告日も同様に訂正。ZIP CRC・全ファイルhash台帳を確認。
