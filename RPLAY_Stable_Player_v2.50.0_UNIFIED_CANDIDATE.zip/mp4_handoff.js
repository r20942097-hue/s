/* RPLAY MP4 auto handoff v1 (v2.44.0).
   BG録画停止・異常終了後にOPFS退避へ残ったTSパートをMP4へ自動変換し、
   保存台帳(export journal)へ引き渡す編成モジュール。
   紀律: 元TSパートを削除・変更しない(非破壊)。URL/トークン/Cookie等の
   秘密は一切保持・出力しない。既定は無効(現行動作維持)。単発実行。 */
(function(root){
'use strict';
const MAX_PARTS=4096,MAX_PART_BYTES=2*1024**3,MAX_TOTAL_BYTES=64*1024**3;
function create(deps){
 deps=deps||{};
 const now=typeof deps.now==='function'?deps.now:Date.now;
 const settings=typeof deps.settings==='function'?deps.settings:()=>({enabled:false});
 const isRecording=typeof deps.isRecording==='function'?deps.isRecording:()=>false;
 const listParts=typeof deps.listParts==='function'?deps.listParts:(async()=>[]);
 const openInputs=typeof deps.openInputs==='function'?deps.openInputs:(async()=>{throw Error('OPEN_INPUTS_UNAVAILABLE');});
 const createDestination=typeof deps.createDestination==='function'?deps.createDestination:(async()=>{throw Error('DESTINATION_UNAVAILABLE');});
 const convert=typeof deps.convert==='function'?deps.convert:(async()=>{throw Error('CONVERTER_UNAVAILABLE');});
 const handoff=typeof deps.handoff==='function'?deps.handoff:(async()=>{throw Error('HANDOFF_UNAVAILABLE');});
 const emit=typeof deps.emit==='function'?deps.emit:()=>{};
 const notify=typeof deps.notify==='function'?deps.notify:()=>{};
 const excludeNames=typeof deps.excludeNames==='function'?deps.excludeNames:()=>[];
 const bootAt=Number.isFinite(deps.bootAt)?deps.bootAt:now();
 const IS_TS=/\.ts$/i;
 const badName=n=>typeof n!=='string'||!n.length||n.length>180||/[\\/\x00-\x1f]/.test(n)||!IS_TS.test(n);
 function jobId(){
  if(deps.crypto&&typeof deps.crypto.randomUUID==='function')return deps.crypto.randomUUID().replace(/-/g,'');
  let s='';for(let i=0;i<32;i++)s+='0123456789abcdef'[Math.floor(Math.random()*16)];
  return s;
 }
 const jobs=[];let running=false,serial=Promise.resolve();
 const counters={enqueued:0,completed:0,failed:0,skipped:0,bytesIn:0,bytesOut:0};
 let last=null,lastPhase='',lastProgressAt=0,partsTotal=0;
 function outputName(at){
  const d=new Date(at),p=n=>String(n).padStart(2,'0');
  return 'RPLAY_auto_'+d.getFullYear()+p(d.getMonth()+1)+p(d.getDate())+p(d.getHours())+p(d.getMinutes())+p(d.getSeconds())+'.mp4';
 }
 function onProgress(p){
  if(!p)return;
  const t=now(),changed=p.phase&&p.phase!==lastPhase;
  if(!changed&&t-lastProgressAt<900)return;
  lastPhase=p.phase||lastPhase;lastProgressAt=t;
  try{emit({phase:lastPhase,index:Number.isInteger(p.index)?p.index:null,partsTotal});}catch(e){}
 }
 function trimmed(list){return list.slice(0,50);}
 function enqueue(job){
  job=job||{};
  const trigger=job.trigger==='bg-stop'||job.trigger==='orphan-sweep'?job.trigger:null;
  if(!trigger)return {ok:false,error:'bad-trigger'};
  const parts=[...new Set((Array.isArray(job.parts)?job.parts:[]).filter(n=>!badName(n)))];
  if(!parts.length)return {ok:false,error:'no-parts'};
  if(parts.length>MAX_PARTS)return {ok:false,error:'too-many-parts'};
  const entry={id:jobId(),trigger,parts,queuedAt:now()};
  jobs.push(entry);counters.enqueued++;
  kick();
  return {ok:true,id:entry.id,queued:jobs.length};
 }
 async function runJob(job){
  const startedAt=now();partsTotal=job.parts.length;
  const code=v=>String(v&&v.message||v||'FAILED').slice(0,64);
  const fail=v=>{
   counters.failed++;
   last={trigger:job.trigger,partsTotal:job.parts.length,parts:trimmed(job.parts),status:'failed',errorCode:code(v),startedAt,finishedMs:now()-startedAt};
   try{notify('MP4自動引渡しに失敗しました','理由: '+last.errorCode+'。元TSは保持しています。手動変換をご利用ください。');}catch(e){}
   try{emit({phase:'failed',errorCode:last.errorCode,trigger:job.trigger});}catch(e){}
  };
  const skip=reason=>{
   counters.skipped++;
   last={trigger:job.trigger,partsTotal:job.parts.length,parts:trimmed(job.parts),status:'skipped',reason:String(reason).slice(0,64),startedAt,finishedMs:now()-startedAt};
   try{emit({phase:'skipped',reason:last.reason,trigger:job.trigger});}catch(e){}
  };
  try{
   if(!settings().enabled)return skip('disabled');
   if(isRecording())return skip('busy-recording');
   onProgress({phase:'preflight'});
   const opened=await openInputs(job.parts);
   const inputs=(opened&&Array.isArray(opened.inputs)?opened.inputs:[]).filter(x=>x&&typeof x.getFile==='function');
   const missing=opened&&Number.isSafeInteger(opened.missing)?opened.missing:job.parts.length-inputs.length;
   const totalBytes=inputs.reduce((s,x)=>s+(Number.isSafeInteger(x.size)?x.size:0),0);
   if(!inputs.length)return skip(missing>0?'parts-missing':'no-parts');
   if(inputs.length>MAX_PARTS)return skip('too-many-parts');
   if(!Number.isSafeInteger(totalBytes)||totalBytes<1)return skip('bad-input-size');
   if(inputs.some(x=>x.size>MAX_PART_BYTES))return skip('part-too-large');
   if(totalBytes>MAX_TOTAL_BYTES)return skip('total-limit');
   if(isRecording())return skip('busy-recording');
   onProgress({phase:'convert',index:0});
   const stage=await createDestination({inputBytes:totalBytes});
   let result,receipt=null,file=null;
   try{
    result=await convert({inputs,destination:stage.destination,signal:null,onProgress});
    receipt=await stage.finalize(result);
    if(!receipt||receipt.confirmed!==undefined&&!receipt.confirmed&&!receipt.bytes)throw Error('BAD_RECEIPT');
    file=await stage.file();
    if(!file||file.size!==receipt.bytes)throw Error('OUTPUT_SIZE_MISMATCH');
   }catch(e){
    try{if(typeof stage.destroy==='function')await stage.destroy();}catch(ignored){}
    return fail('CONVERT_'+code(e));
   }
   try{
    onProgress({phase:'export'});
    const outName=outputName(startedAt);
    await handoff(file,outName);
    counters.completed++;counters.bytesIn+=totalBytes;counters.bytesOut+=receipt.bytes;
    last={trigger:job.trigger,partsTotal:job.parts.length,parts:trimmed(job.parts),missing:missing,inputBytes:totalBytes,
     outputBytes:receipt.bytes,sha256:receipt.sha256,audio:receipt.audio===true,aacFrames:Number(receipt.aacFrames)||0,
     stageId:typeof receipt.id==='string'?receipt.id.slice(0,32):null,status:'complete',outputName:outName,startedAt,finishedMs:now()-startedAt};
    try{notify('MP4自動引渡しが完了しました',outName+' / '+(receipt.bytes/1048576).toFixed(1)+' MiB (元TSは保持)');}catch(e){}
    try{emit({phase:'complete',outputName:outName,outputBytes:receipt.bytes,trigger:job.trigger});}catch(e){}
   }catch(e){return fail('EXPORT_'+code(e));}
  }catch(e){fail(e);}
 }
 function kick(){
  if(running)return;
  running=true;
  serial=serial.then(async()=>{
   try{while(jobs.length)await runJob(jobs.shift());}
   finally{running=false;}
  }).catch(()=>{running=false;});
 }
 async function sweep(){
  if(!settings().enabled)return {ok:false,error:'disabled'};
  if(isRecording())return {ok:false,error:'busy-recording'};
  const excluded=new Set(excludeNames());
  const all=await listParts();
  const orphans=all.filter(x=>x&&typeof x.name==='string'&&!badName(x.name)&&Number(x.size)>0
    &&!(Number(x.lastModified)>bootAt)&&!excluded.has(x.name))
   .sort((a,b)=>String(a.name).localeCompare(String(b.name),'en',{numeric:true}))
   .map(x=>x.name);
  if(!orphans.length)return {ok:true,skipped:'no-orphans'};
  if(orphans.length>MAX_PARTS)return {ok:false,error:'too-many-parts'};
  const r=enqueue({trigger:'orphan-sweep',parts:orphans});
  return r.ok?{ok:true,id:r.id,queued:r.queued,parts:orphans.length}:r;
 }
 return {
  enqueue,sweep,
  status(){return {enabled:settings().enabled===true,queued:jobs.length,busy:running,counters:{...counters},last:last?{...last}:null};},
  settled(){return serial;},
  MAX_PARTS,MAX_PART_BYTES,MAX_TOTAL_BYTES
 };
}
const value={create,MAX_PARTS,MAX_PART_BYTES,MAX_TOTAL_BYTES};
if(typeof module!=='undefined')module.exports=value;
root.RspMp4Handoff=value;
})(typeof globalThis==='undefined'?this:globalThis);
