# v2.33.0 QA

追加5件: customURL解析/解決重複、全入力先行検証とorigin/credentials拒否、解決失敗/20人制限、固定endpoint/無資格情報、巨大stream拒否。追加ブラウザ1件は実DOM+API mockで名前URL→ID保存。実RPLAYのアカウント確認APIを実際に受入したとは扱わない。
Firefox/FloorpはLinux/headless/一時profile、試験のみsandbox level調整。native preview進行は未合格。最終件数はevidence JSON参照。

全回帰648件PASS（Node483/Python165）。Firefox30 PASS/1 BLOCKED。追加5件を含む。名前URL解析・API境界・atomic保存の条件を追加検証。ブラウザruntimeは単体試験対象の展開候補と同じコード。最終包装はCRC/全hash台帳を確認。
