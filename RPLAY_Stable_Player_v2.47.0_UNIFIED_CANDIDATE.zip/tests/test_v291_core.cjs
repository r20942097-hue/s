'use strict';
/* v2.9.1 core features (hardening release: delayed Blob URL release, pin policy,
   acceptance observation support):
   1. rspBlobHoldMs (pure, deterministic): floor 30s / size-proportional at a
      conservative 10 MiB/s / cap 600s — replaces blind 10s/30s revoke timers.
   2. rspDelayedBlobRelease: revokeObjectURL + anchor removal scheduled at the
      size-aware hold time; individual failures are swallowed (never break saving).
   3. RECENV.download default implementation uses the delayed-release contract;
      the VOD closePart / info-JSON paths are unified on the same helper.
   4. offscreen OPFS save path and export_host.js finish-time revoke lifecycle
      are unchanged (regression guards).
   5. Version pin 2.9.1 + pin policy migration (last-2 range for v290 file,
      exact current pin for v260/v270/v280 files — 統合設計書6.3節). */
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),vm=require('vm');
const ROOT=path.join(__dirname,'..');
const source=fs.readFileSync(path.join(ROOT,'rplay-stable-player.user.js'),'utf8');
const MIB=1024*1024;

function blobWorld(){
  const s1=source.slice(source.indexOf('function rspBlobHoldMs'),source.indexOf('function rspDelayedBlobRelease'));
  const s2=source.slice(source.indexOf('function rspDelayedBlobRelease'),source.indexOf('const RECENV = (typeof'));
  const c=vm.createContext({setTimeout:()=>1});
  vm.runInContext([s1,s2].join('\n')+';globalThis._fns={rspBlobHoldMs,rspDelayedBlobRelease};',c);
  return c._fns;
}
function recenvWorld(){
  const s1=source.slice(source.indexOf('function rspBlobHoldMs'),source.indexOf('function rspDelayedBlobRelease'));
  const s2=source.slice(source.indexOf('function rspDelayedBlobRelease'),source.indexOf('const RECENV = (typeof'));
  const s3=source.slice(source.indexOf('const RECENV = (typeof'),source.indexOf('/* v2.0 Step2: RSP_RECENV_HOOK'));
  const timers=[];
  const revoked=[];
  const anchors=[];
  let created=0,appended=0;
  const c=vm.createContext({
    setTimeout:(fn,delay)=>{timers.push({fn,delay});return timers.length;},
    URL:{createObjectURL:()=>{created++;return 'blob:mock-'+created;},revokeObjectURL:(u)=>{revoked.push(u);}},
    document:{
      createElement:()=>{
        const a={href:'',download:'',removed:0,click(){this.clicked=true;},remove(){this.removed++;}};
        anchors.push(a);return a;
      },
      body:{appendChild:()=>{appended++;}}
    }
  });
  vm.runInContext([s1,s2,s3].join('\n')+';globalThis._recenv=RECENV;globalThis._fns={rspBlobHoldMs};',c);
  return {timers,revoked,anchors,get appended(){return appended;},RECENV:c._recenv,rspBlobHoldMs:c._fns.rspBlobHoldMs};
}

test('v2.9.1 version pin: userscript @version, both manifests, CLI strings',()=>{
  const us=fs.readFileSync(path.join(ROOT,'rplay-stable-player.user.js'),'utf8');
  assert.match(us,/\/\/ @version\s+2\.(?:9\.1|12\.0|15\.0|16\.0|17\.0|18\.0|19\.0|20\.0|21\.0|22\.0|23\.0|24\.0|25\.0|26\.0|27\.0|28\.0|29\.0|30\.0|31\.0|32\.0|33\.0|35\.0|36\.0|37\.0|38\.0|39\.0|40\.0|41\.0|42\.0|43\.0|44\.0|45\.0|46\.0|47\.0)/);
  for(const ext of ['rplay-stable-player-extension','rplay-stable-player-extension-firefox']){
    const m=JSON.parse(fs.readFileSync(path.join(ROOT,ext,'manifest.json'),'utf8'));
    assert.match(m.version,/^2\.(?:9\.1|12\.0|15\.0|16\.0|17\.0|18\.0|19\.0|20\.0|21\.0|22\.0|23\.0|24\.0|25\.0|26\.0|27\.0|28\.0|29\.0|30\.0|31\.0|32\.0|33\.0|35\.0|36\.0|37\.0|38\.0|39\.0|40\.0|41\.0|42\.0|43\.0|44\.0|45\.0|46\.0|47\.0)$/,ext);
    if(ext.endsWith('-firefox')) assert.equal(Object.hasOwn(m,'version_name'),false,'Firefox must omit unsupported version_name'); else assert.match(m.version_name,/^2\.(?:9\.1|12\.0|15\.0|16\.0|17\.0|18\.0|19\.0|20\.0|21\.0|22\.0|23\.0|24\.0|25\.0|26\.0|27\.0|28\.0|29\.0|30\.0|31\.0|32\.0|33\.0|35\.0|36\.0|37\.0|38\.0|39\.0|40\.0|41\.0|42\.0|43\.0|44\.0|45\.0|46\.0|47\.0) CANDIDATE$/,ext+' version_name');
  }
  const cli=fs.readFileSync(path.join(ROOT,'rplay_dl.py'),'utf8');
  assert.match(cli,/RPLAY Live Downloader v2\.(?:9\.1|12\.0|15\.0|16\.0|17\.0|18\.0|19\.0|20\.0|21\.0|22\.0|23\.0|24\.0|25\.0|26\.0|27\.0|28\.0|29\.0|30\.0|31\.0|32\.0|33\.0|35\.0|36\.0|37\.0|38\.0|39\.0|40\.0|41\.0|42\.0|43\.0|44\.0|45\.0|46\.0|47\.0) CANDIDATE/);
  assert.match(cli,/rplay_dl\.py v2\.(?:9\.1|12\.0|15\.0|16\.0|17\.0|18\.0|19\.0|20\.0|21\.0|22\.0|23\.0|24\.0|25\.0|26\.0|27\.0|28\.0|29\.0|30\.0|31\.0|32\.0|33\.0|35\.0|36\.0|37\.0|38\.0|39\.0|40\.0|41\.0|42\.0|43\.0|44\.0|45\.0|46\.0|47\.0)/);
  assert.match(cli,/\(rplay_dl\.py\) v2\.(?:9\.1|12\.0|15\.0|16\.0|17\.0|18\.0|19\.0|20\.0|21\.0|22\.0|23\.0|24\.0|25\.0|26\.0|27\.0|28\.0|29\.0|30\.0|31\.0|32\.0|33\.0|35\.0|36\.0|37\.0|38\.0|39\.0|40\.0|41\.0|42\.0|43\.0|44\.0|45\.0|46\.0|47\.0)/);
});

test('v2.9.1 rspBlobHoldMs: floor, size-proportional, cap, monotonic (deterministic contract)',()=>{
  const fns=blobWorld();
  const h=fns.rspBlobHoldMs;
  // 床30秒: 小容量・無効値(NaN/負/0)はすべて床へ(失敗安全側)
  assert.equal(h(0),30000);
  assert.equal(h(-5),30000);
  assert.equal(h(NaN),30000);
  assert.equal(h(100*MIB),30000);            // 100MiB @ 10MiB/s = 10s < floor
  // サイズ比例(保守スループット10MiB/s想定)
  assert.equal(h(600*MIB),60000);            // 600MiB → 60s
  assert.equal(h(4*1024*MIB),409600);        // 4GiB → 409.6s
  // 上限600秒(異常に大きなblobでも無限待ちにしない)
  assert.equal(h(8*1024*MIB),600000);
  // 単調非減少
  assert.ok(h(1)<=h(100*MIB));
  assert.ok(h(100*MIB)<=h(600*MIB));
  assert.ok(h(600*MIB)<=h(8*1024*MIB));
});

test('v2.9.1 rspDelayedBlobRelease: revoke at hold time (never immediate), errors swallowed',()=>{
  const fns=blobWorld();
  const timers=[];const revoked=[];let removed=0;
  const helperSrc=source.slice(source.indexOf('function rspBlobHoldMs'),source.indexOf('const RECENV = (typeof'));
  const c=vm.createContext({
    setTimeout:(fn,delay)=>{timers.push({fn,delay});return timers.length;},
    URL:{createObjectURL:()=>'blob:x',revokeObjectURL:(u)=>{revoked.push(u);}}
  });
  vm.runInContext(helperSrc+';globalThis._fns={rspDelayedBlobRelease};',c);
  const anchor={href:'blob:u',remove(){removed++;}};
  const hold=c._fns.rspDelayedBlobRelease('blob:u',anchor,600*MIB);
  assert.equal(hold,60000);                  // 見込み保持時間を返す(契約値)
  assert.equal(timers.length,1);
  assert.equal(timers[0].delay,60000);
  assert.equal(revoked.length,0);            // 即時revokeはしない(Chromium 41380177)
  timers[0].fn();
  assert.deepEqual(revoked,['blob:u']);      // 保持時間経過後に解放
  assert.equal(removed,1);                   // anchorも除去
  // 個別失敗の握り潰し: revokeObjectURLが例外でもremoveは実行され全体は例外にならない
  const c2=vm.createContext({
    setTimeout:(fn)=>{fn();},
    URL:{createObjectURL:()=>'blob:x',revokeObjectURL:()=>{throw new Error('boom');}}
  });
  vm.runInContext(helperSrc+';globalThis._fns={rspDelayedBlobRelease};',c2);
  let removed2=0;
  const a2={href:'blob:u2',remove(){removed2++;}};
  c2._fns.rspDelayedBlobRelease('blob:u2',a2,1); // 即時実行タイマーで同時に検証
  assert.equal(removed2,1);
  // anchor=nullでも例外にしない
  const c3=vm.createContext({setTimeout:(fn)=>{fn();},URL:{createObjectURL:()=>'blob:x',revokeObjectURL:()=>{}}});
  vm.runInContext(helperSrc+';globalThis._fns={rspDelayedBlobRelease};',c3);
  c3._fns.rspDelayedBlobRelease('blob:u3',null,1);
});

test('v2.9.1 RECENV.download default: anchor flow + size-aware hold (VM integration)',()=>{
  const w=recenvWorld();
  const blob={size:600*MIB};
  w.RECENV.download(blob,'RPLAY_part_p1.ts');
  assert.equal(w.anchors.length,1);
  assert.equal(w.anchors[0].download,'RPLAY_part_p1.ts');
  assert.equal(w.anchors[0].clicked,true);
  assert.equal(w.appended,1);
  assert.equal(w.timers.length,1);
  assert.equal(w.timers[0].delay,w.rspBlobHoldMs(600*MIB)); // 契約値と同一(盲目的10秒ではない)
  assert.notEqual(w.timers[0].delay,10000);
  assert.equal(w.revoked.length,0);
  w.timers[0].fn();
  assert.deepEqual(w.revoked,['blob:mock-1']);
  assert.equal(w.anchors[0].removed,1);
  // 小容量blobは床30秒
  const w2=recenvWorld();
  w2.RECENV.download({size:1000},'a.json');
  assert.equal(w2.timers[0].delay,30000);
});

test('v2.9.1 VOD save paths unified on the delayed-release helper (source pins)',()=>{
  // RECENV.download既定実装 + VOD closePart(TS) + VOD情報JSON の3呼び出し site
  // (関数定義それ自体は呼び出しに数えない・完全一致で数える)
  assert.equal(source.split('rspDelayedBlobRelease(url, a, blob.size)').length-1,1);   // RECENV.download
  assert.equal(source.split('rspDelayedBlobRelease(a.href, a, blob.size)').length-1,2); // VOD closePart + info JSON
  // VOD情報JSON経路: Blob生成 → anchor → 遅延解放の順で書かれている
  const infoIdx=source.indexOf("a.download = 'RPLAY_VOD_' + safeName(this.title) + '_info.json'");
  assert.ok(infoIdx>0);
  const region=source.slice(infoIdx,infoIdx+400);
  assert.match(region,/rspDelayedBlobRelease\(a\.href,\s*a,\s*blob\.size\)/);
});

test('v2.9.1 blind revoke timers eliminated: URL.revokeObjectURL call appears exactly once (inside the helper)',()=>{
  // 旧実装は RECENV.download=10000ms・VOD経路=30000ms の盲目的タイマーでrevokeしていた
  const n=(source.match(/URL\.revokeObjectURL\(/g)||[]).length;
  assert.equal(n,1);  // rspDelayedBlobRelease内の1箇所のみ(コメント内の言及は呼び出しではない)
  assert.equal(/URL\.revokeObjectURL\(a\.href\);\s*a\.remove\(\);\s*\},\s*(?:10000|30000)\)/.test(source),false);
  assert.equal(/setTimeout\(function \(\) \{ URL\.revokeObjectURL/.test(source),false);
  // ヘルパー定義は RECENV定義の直前(コア内=5形態で共有される位置)
  assert.ok(source.indexOf('function rspBlobHoldMs')<source.indexOf('const RECENV = (typeof'));
  assert.ok(source.indexOf('function rspBlobHoldMs')>source.indexOf('==== RSP RECORDING CORE'));
});

test('v2.9.1 offscreen OPFS path and export_host lifecycle unchanged (regression guards)',()=>{
  // offscreenホストはRECENV.downloadをOPFS保存へ差し替え(Blob URLを作らない)=影響なし
  const off=fs.readFileSync(path.join(ROOT,'rplay-stable-player-extension','offscreen.js'),'utf8');
  assert.match(off,/download: function \(blob, name\) \{ return opfsSaveAndSalvage\(blob, name\); \}/);
  // export_host.js は offer時に生成したURLをfinish時にrevoke(既存の適切なライフサイクル)
  const eh=fs.readFileSync(path.join(ROOT,'rplay-stable-player-extension','export_host.js'),'utf8');
  assert.match(eh,/if\(e\.url\)\{env\.URL\.revokeObjectURL\(e\.url\);e\.url=null;\}/);
  assert.match(eh,/entry\.url=env\.URL\.createObjectURL\(file\)/);
});

test('v2.9.1 pin policy migration: last-2 range for v2100, unified pins for older files',()=>{
  const v2100=fs.readFileSync(path.join(ROOT,'tests','test_v2100_core.cjs'),'utf8');
  assert.ok(v2100.includes('2\\.(?:41|42|43|44|45|46|47)\\.0'),'v2100 pin must include 2.43.0');
  for(const f of ['test_v270_core.cjs','test_v280_core.cjs','test_v290_core.cjs']){
    const s=fs.readFileSync(path.join(ROOT,'tests',f),'utf8');
    assert.ok(s.includes('44'),f+' pin must include 2.43.0');
  }
  const v260=fs.readFileSync(path.join(ROOT,'tests','test_v260_core.cjs'),'utf8');
  assert.ok(v260.includes('44'),'v260 tool-string pin must include 2.43.0');
});
