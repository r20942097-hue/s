"""Offline product validation. --output-dir writes optional fresh evidence."""
from pathlib import Path
import argparse,ast,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--output-dir');args=ap.parse_args()
output=Path(args.output_dir).resolve() if args.output_dir else None
if output:output.mkdir(parents=True,exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(label,cmd,timeout=360):
 p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,timeout=timeout)
 text=p.stdout+p.stderr
 if output:(output/(label+'.log')).write_text(text)
 if p.returncode:print(text);raise SystemExit(label+' FAILED')
 return text
if (R/'SHA256SUMS.json').exists():
 entries=json.loads((R/'SHA256SUMS.json').read_text())
 for name,want in entries.items():
  if digest(R/name)!=want:raise SystemExit('PACKAGE_HASH_MISMATCH '+name)
 print('PACKAGE_HASHES_PASS',len(entries))
exts=[R/'rplay-stable-player-extension',R/'rplay-stable-player-extension-firefox']
for ext in exts:
 m=json.loads((ext/'manifest.json').read_text());assert m['version']=='2.47.0'
 if ext.name.endswith('-firefox'):assert 'version_name' not in m
 else:assert m['version_name']=='2.47.0 CANDIDATE'
 refs=[]
 for cs in m.get('content_scripts',[]):refs+=cs.get('js',[])
 bg=m['background'];refs+=bg.get('scripts',[])
 if bg.get('service_worker'):refs.append(bg['service_worker'])
 refs+=list(m.get('icons',{}).values())
 for name in refs:assert (ext/name).is_file(),name
 for script in ext.glob('*.js'):run('syntax_'+ext.name+'_'+script.stem,['node','--check',str(script)])
 for html in ext.glob('*.html'):
  for name in re.findall(r'<script[^>]*src="([^"]+)"',html.read_text()):assert(ext/name).is_file(),name
for name in ['background.js','offscreen.js','content.js','ext_glue.js','export_host.js','export_manager.js','session_gate.js','hls_transport.js','rec_worker.js','libs/hls.min.js','libs/flv.min.js']:
 assert digest(exts[0]/name)==digest(exts[1]/name),name
# Every derived local tool must match its source in both extensions and the root.
for name in ['recovery_core.js','recovery.js','recovery.html','sha256.js','mp4_convert.html','mp4_convert.js','mp4_convert_core.js','mp4_codec_core.js','mp4_browser_io.js','mp4_convert_worker.js','media_inspect.html','media_inspect.js','media_inspect_core.js','dashboard.html','dashboard.js','creator_registry.js','creator_meta.js','dashboard_settings.js','media_catalog.js','cross_site_compat.js','cross_site_core.js']:
 want=digest(R/'src'/name)
 for directory in [R]+exts:
  assert digest(directory/name)==want,'DERIVED_COPY_MISMATCH '+str(directory/name)
ast.parse((R/'rplay_dl.py').read_text())
runtime=[R/'rplay-stable-player.user.js',R/'rplay_dl.py',R/'rplay_join.py']+[p for ext in exts for p in ext.rglob('*') if p.is_file()]
before={str(p.relative_to(R)):digest(p) for p in runtime}
run('build',[sys.executable,'scripts/build.py'])
after={str(p.relative_to(R)):digest(p) for p in runtime};assert before==after,'build changed generated runtime bytes'
cores=[]
for p in [R/'rplay-stable-player.user.js',exts[0]/'content.js',exts[1]/'content.js',exts[0]/'offscreen.js',exts[1]/'offscreen.js']:
 s=p.read_text();a=s.index('/* ============================================================\n     ==== RSP RECORDING CORE');b=s.index('  /* ==== RSP RECORDING CORE',a);b=s.index('\n',b)+1;cores.append(hashlib.sha256(s[a:b].encode()).hexdigest())
assert len(set(cores))==1
node=run('node',['node','--test']+[str(p) for p in sorted((R/'tests').glob('test_*.cjs'))])
py=run('python',[sys.executable,'-m','unittest','discover','-s','tests','-p','test_*.py'])
m=re.search(r'(?:ℹ tests |# tests )(\d+)',node)
if not m:raise SystemExit('NODE_TEST_COUNT_UNAVAILABLE')
nt=int(m[1]);pt=int(re.search(r'Ran (\d+) tests?',py)[1])
assert nt>=750 and pt>=165,(nt,pt)
result={'version':'2.47.0','status':'CANDIDATE_NO_GO','date_jst':'2026-10-27','node_tests':nt,'python_tests':pt,'total_tests':nt+pt,'shared_core_sha256':cores[0],'shared_core_copies':len(cores),'rebuild_byte_identity':True,'manifest_and_syntax':'PASS','derived_artifact_copies':'PASS','scope':'API/OPFS mocks + generated recorder VM + actual CLI local HTTP + FFmpeg-generated TS/fMP4 byte identity, ffprobe PTS/DTS audit, fMP4 MAP-switch two-generation E2E, AV decoded-duration correlation, LL-HLS safe-side (SKIP rejection + indicator counting), ledger contract, generation recovery, segindex restart dedup, stop-file/heartbeat/webhook ops; v2.7.0: synthetic auth regression (refresh-token loop, 401 classification, token priority fallback, env/file secret supply), canary shape detection, enriched webhook events (levels, 429 Retry-After), MP4 metadata tags with ffprobe verification, authEvidence/canaryEvidence/notificationEvidence/metadataEvidence blocks; v2.8.0: offscreen authEvidence/canaryEvidence relay & host counters, Butter AES-128-CBC M3U8 403 auto-retry, streamStartTime 10-min (600s) session tracking (same_session_resumed vs new_session_split), 4-layer ErrorKind taxonomy (sessionTrackingEvidence/errorTaxonomyEvidence); v2.9.0: A-09 subtitle rendition observation (EXT-X-MEDIA TYPE=SUBTITLES parsing, subsGroup variant linkage, subtitleEvidence with observed_not_fetched policy, zero URI output, cross-language mirror, subtitle playlists never fetched); v2.10.0: MPEG-TS EXT-X-DISCONTINUITY seamless single-part append (anti-fragmentation), splitMin=0 continuous default, raised OPFS/FSA part limits (512MB/2GB), multi-part FFmpeg concat demuxer (--concat-parts), segment HTTP 503 Retry-After backoff, Master 200 / Media 404 paywall_blocked detection, partContinuityEvidence cross-language mirror; v2.15.0: checkpoint chunks/journal, recovery guards and generated TS recovery/decode, GOP/PES-aligned streaming fMP4 conversion, hash-verify, cat-catch C-01..C-03; v2.16.0: software AES-128-CBC decryptor (NIST SP 800-38A KAT + WebCrypto cross-check, cat-catch m3u8-decrypt.js lineage), CLI AES-128 acquisition (--dec-key/-file/-env/auto with official-equivalent key headers, openssl fast path + pure-Python fallback, decryptionEvidence zero-secret), TS continuity-counter audit (ISO 13818-1 2.4.3.2, JS/Py mirror parity, continuityCounterEvidence, non-destructive), rplay_join.py packaging regression guard; v2.17.0: unified audio timeline + bounded rolling PSI preflight, input-hash mutation guard, 65MiB null-padded media, 33bit timestamp wrap, 32MiB GOP retention guard, mocked DOM cancellation/API controls; v2.18.0: strict PES length/header/PTS, ADTS framing and per-PES boundaries, Annex-B/NAL-header sanity (not decoded), input AAC to output MP4 trun sample-count conservation, 120sec 44.1/48kHz and 77.6MB CBR on-disk media regressions; v2.19.0: mux 6.3 fragment sample-table/mdat/AVC/clock audit + bounded one-audio-tick normalization, per-source length-prefixed raw AAC SHA256 equality, legacy input hash and precommit cancellation parity, fault injection (same-count payload flip, offset/range/table/clock/sequence/overlap); v2.20.0: bounded source SPS/PPS capture + codec configuration audit (mp4a/esds/ASC/avcC/tkhd geometry), Baseline/Main/High SPS dimensions vs ffprobe, explicit single parameter-set limitation, Firefox version_name omission and packaging guards; v2.21.0: discovery authenticated-first/refresh/empty-list/lifecycle regression with archived v2.20 code reproduction, nested creator identity parsing, source preference and probed transport URL, bounded BG file/export metadata and both real-script routers with mocked browser APIs, SPA reinjection; v2.22.0: Worker-based local conversion, File input adapters, fresh OPFS job staging and sync/async writers, bounded memory fallback, receipt/hash recovery and cross-view Web Locks, download completion UI, loopback static-only launcher; separate real Firefox acceptance evidence; v2.37.0: dashboard settings concurrency, saved-policy display and bounded page JSON; inherited semantic live query routing, signed URL preservation, bounded cancellable Engine probes and local metadata/command diagnostics; v2.37.0: BG-side JSON fetch commonization (single shared stream/2MiB fetchJsonWithRetry module injected into both page and offscreen, old offscreen whole-body json() buffering and header-only timeout removed, 8 new Node tests); v2.47.0: registered creator name metadata (rsp_creator_meta separate key, ID list contract unchanged, slug-resolution captures name/canonical /c/ URL, single-lock dual-key commit with prune, BG registry.list returns sanitized meta, page schedule rows display names; 12 new Node tests) and external schedule viewing via BG route (offscreen schedules.scan with own-session JWT only, nologin/busy/rate-limit guards, 400ms pacing, dashboard UI with guidance; 16 new Node tests); v2.47.0: CrossSite Compatibility v0.1.0 integration (src/cross_site_compat.js + src/cross-site/*.mjs + synthetic fixtures, URL signature preservation & unsigned-child query inheritance, site/watch-page classification, HTTP error diagnostics, LiveSegmentLedger, NicoLiveSessionObserver, MediaCandidateRegistry), fMP4 moov 0xFFFFFFFF duration normalization (normalizeInitHeaderDurations), Node 18 crypto.randomUUID fallback, local static server allowlist & BrokenPipe hardening, checkpoint recovery verifyTs option, WebVTT validation/merge parity; unit suite is not browser acceptance','not_tested':['RPLAY','actual Chrome extension install (separate Firefox evidence exists)','Windows','long endurance']}
if output:(output/'VALIDATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
