'use strict';
/* v2.8.0 core features:
   1. Offscreen/background extension host authEvidence & canaryEvidence relay and
      in-host counter tracking (closing the v2.7.0 known asymmetry).
   2. Butter token generation and M3U8 403 retry integration (learned from rplay_watcher v0.5.0).
   3. Session streamStartTime 10-minute threshold tracking (same_session_resumed vs new_session_split)
      and errorTaxonomyEvidence (SOURCE/NETWORK/AUTH/PLATFORM/COMPATIBILITY/INTERNAL) across both cores.
   4. Unified 2.8.0 version pin across userscript/manifests/CLI strings. */
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),vm=require('vm'),{webcrypto}=require('node:crypto');
const {spawnSync}=require('node:child_process');
const {system}=require('./helpers_runtime.cjs');
const ROOT=path.join(__dirname,'..');
const source=fs.readFileSync(path.join(ROOT,'rplay-stable-player-extension/content.js'),'utf8');

function b64u(o){return Buffer.from(JSON.stringify(o)).toString('base64url');}
const JWT=b64u({alg:'none'})+'.'+b64u({oid:'b'.repeat(24),exp:Math.floor(Date.now()/1000)+3600})+'.sig';

test('v2.8.0 version pin: userscript @version, both manifests, CLI strings',()=>{
  const us=fs.readFileSync(path.join(ROOT,'rplay-stable-player.user.js'),'utf8');
  assert.match(us,/\/\/ @version\s+2\.(?:[89]|10|11|12|13|36|37|38|39|40|41|42|43|44|45|46)\.0/);
  for(const ext of ['rplay-stable-player-extension','rplay-stable-player-extension-firefox']){
    const m=JSON.parse(fs.readFileSync(path.join(ROOT,ext,'manifest.json'),'utf8'));
    assert.match(m.version,/^2\.(?:[89]|10|11|12|13|36|37|38|39|40|41|42|43|44|45|46)\.0$/,ext);
    if(ext.endsWith('-firefox')) assert.equal(Object.hasOwn(m,'version_name'),false,'Firefox must omit unsupported version_name'); else assert.match(m.version_name,/^2\.(?:[89]|10|11|12|13|36|37|38|39|40|41|42|43|44|45|46)\.0 CANDIDATE$/,ext+' version_name');
  }
  const cli=fs.readFileSync(path.join(ROOT,'rplay_dl.py'),'utf8');
  assert.match(cli,/RPLAY Live Downloader v2\.(?:[89]|10|11|12|13|36|37|38|39|40|41|42|43|44|45|46)\.0 CANDIDATE/);
  assert.match(cli,/rplay_dl\.py v2\.(?:[89]|10|11|12|13|36|37|38|39|40|41|42|43|44|45|46)\.0/);
  assert.match(cli,/\(rplay_dl\.py\) v2\.(?:[89]|10|11|12|13|36|37|38|39|40|41|42|43|44|45|46)\.0/);
});

test('v2.8.0 ext_glue relays authStats (zero secrets) on rec.start and token.update',async()=>{
  let token=JWT,sent=[];
  const authEv={mode:'localStorage-interceptor',tokenSource:'localStorage',refreshSource:'localStorage-scan',
    userOidSupplied:true,switchedToRefresh:false,refreshAttempts:0,refreshSuccesses:0,
    refreshFailures:0,responseKey:null,classifications401:{'auth-expired':1},key2Resolutions:2,
    butterSent:true,provenance:'rspauth_counters'};
  const timers=[];
  const c={crypto:webcrypto,window:{__RSP:{recorder:{id:'a'.repeat(24)},ui:{},authEvidence:()=>authEv}},
    localStorage:{getItem:k=>k==='_AUTHORIZATION_'?token:null,setItem:()=>{}},
    location:{href:'https://rplay.live/live/'+'a'.repeat(24)},
    document:{title:'T',documentElement:{setAttribute:()=>{}},querySelector:()=>null,getElementById:k=>k==='rsp-panel'?{}:null},
    setTimeout:f=>timers.push(f),atob:s=>Buffer.from(s,'base64').toString('binary'),
    chrome:{runtime:{id:'rsp',onMessage:{addListener:()=>{}},sendMessage:(m,cb)=>{
      sent.push(m);
      if(m.type==='bg.cap')cb({offscreen:true,mode:'offscreen',fsa:true});
      else if(m.type==='rec.status')cb({recording:false,oid:'a'.repeat(24),canControl:true,control:{sessionId:'sid',epoch:1,oid:'a'.repeat(24)}});
      else cb({ok:true});
    }}}};
  vm.runInNewContext(fs.readFileSync(path.join(ROOT,'rplay-stable-player-extension/ext_glue.js'),'utf8'),c);
  await new Promise(setImmediate);
  c.window.__RSP_BG__.routeClick();
  for(let i=0;i<6;i++) await new Promise(setImmediate);
  const startMsg=sent.find(m=>m.type==='rec.start');
  assert.ok(startMsg,'rec.start sent');
  assert.deepEqual(JSON.parse(JSON.stringify(startMsg.payload.authStats)),authEv);
  assert.equal(JSON.stringify(startMsg.payload.authStats).includes(JWT),false);
});

test('v2.8.0 offscreen host populates RECENV.authStats and canaryEvidence with zero secrets',async()=>{
  const h=system(false,true);
  await h.start();
  const oid='a'.repeat(24);
  const authStats={mode:'localStorage-interceptor',tokenSource:'localStorage',refreshSource:'localStorage-scan',
    userOidSupplied:true,switchedToRefresh:false,refreshAttempts:0,refreshSuccesses:0,
    refreshFailures:0,responseKey:null,classifications401:{'auth-expired':1},key2Resolutions:1,
    butterSent:true,provenance:'rspauth_counters'};
  const started=await h.command('rec.start',{oid,jwt:JWT,userOid:'b'.repeat(24),authStats});
  assert.equal(started.ok,true);
  const hostEv=JSON.parse(vm.runInContext('JSON.stringify(window.__RSP_BG_HOST__.authStats())',h.host));
  assert.equal(hostEv.tokenSource,'localStorage');
  assert.equal(hostEv.refreshSource,'localStorage-scan');
  assert.equal(hostEv.userOidSupplied,true);
  assert.equal(hostEv.key2Resolutions,1);
  assert.equal(hostEv.butterSent,true);
  assert.deepEqual(hostEv.classifications401,{'auth-expired':1});
  assert.equal(JSON.stringify(hostEv).includes(JWT),false);
  // keystructure matches Python AuthStore.evidence()
  const py=spawnSync('python3',['-c',
    "import importlib.util,json,pathlib\n"+
    "spec=importlib.util.spec_from_file_location('x',pathlib.Path('rplay_dl.py'))\n"+
    "m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)\n"+
    "a=m.AuthStore('',http_fn=lambda *a,**k:(200,b'{}',0),token='t')\n"+
    "print(json.dumps(a.evidence()))"],
    {cwd:ROOT,encoding:'utf8'});
  assert.equal(py.status,0,py.stderr);
  assert.deepEqual(Object.keys(hostEv).sort(),Object.keys(JSON.parse(py.stdout)).sort());
});

test('v2.8.0 streamStartTime session tracking and errorTaxonomy cross-language parity',()=>{
  const code=source.slice(source.indexOf('function rspParseStreamStartSec'),source.indexOf('async function fetchJsonWithRetry'));
  const c=vm.createContext({JSON,console,Date,Math});
  vm.runInContext(code+';globalThis.fns={parse:rspParseStreamStartSec,classify:rspClassifySessionChange,evd:rspSessionTrackingEvidence,tax:rspErrorTaxonomyEvidence};',c);
  const fns=c.fns;
  const rt=x=>JSON.parse(JSON.stringify(x));
  assert.equal(fns.parse('2026-10-25T10:00:00Z'),1792922400);
  assert.equal(fns.parse(1792922400),1792922400);
  assert.equal(fns.parse(1792922400000),1792922400);
  // within 600s -> same_session_resumed
  assert.deepEqual(rt(fns.classify(1792922400,1792922700,600)),{changed:true,gapSec:300,classification:'same_session_resumed',thresholdSec:600});
  // > 600s -> new_session_split
  assert.deepEqual(rt(fns.classify(1792922400,1792923100,600)),{changed:true,gapSec:700,classification:'new_session_split',thresholdSec:600});
  // unchanged -> unchanged
  assert.deepEqual(rt(fns.classify(1792922400,1792922400,600)),{changed:false,gapSec:0,classification:'unchanged',thresholdSec:600});

  const py=spawnSync('python3',['-c',
    "import importlib.util,json,pathlib\n"+
    "spec=importlib.util.spec_from_file_location('x',pathlib.Path('rplay_dl.py'))\n"+
    "m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)\n"+
    "c1=m.classify_session_change(1792922400,1792922700,600)\n"+
    "c2=m.classify_session_change(1792922400,1792923100,600)\n"+
    "c3=m.classify_session_change(1792922400,1792922400,600)\n"+
    "print(json.dumps([c1,c2,c3]))"],
    {cwd:ROOT,encoding:'utf8'});
  assert.equal(py.status,0,py.stderr);
  const [p1,p2,p3]=JSON.parse(py.stdout);
  assert.deepEqual(rt(fns.classify(1792922400,1792922700,600)),p1);
  assert.deepEqual(rt(fns.classify(1792922400,1792923100,600)),p2);
  assert.deepEqual(rt(fns.classify(1792922400,1792922400,600)),p3);
});

test('v2.8.0 Butter token cross-language byte identity (WebCrypto vs Python)',async()=>{
  const butterCode=source.slice(source.indexOf('function hexU8'),source.indexOf('const RspAuth = {'));
  const c=vm.createContext({TextEncoder,Uint8Array,crypto:webcrypto,Date:{now:()=>1792946308000},Math,String});
  vm.runInContext(butterCode+';globalThis.bt=butterToken;',c);
  const jsHex=await c.bt();
  assert.equal(jsHex.length,128);
  const py=spawnSync('python3',['-c',
    "import importlib.util,pathlib\n"+
    "spec=importlib.util.spec_from_file_location('x',pathlib.Path('rplay_dl.py'))\n"+
    "m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)\n"+
    "print(m.generate_butter_token(now_s=1792946308))"],
    {cwd:ROOT,encoding:'utf8'});
  assert.equal(py.status,0,py.stderr);
  assert.equal(py.stdout.trim(),jsHex);
});
