"""v2.7.0 feature acceptance: canary site-shape detection (ok / shape_change /
unreachable with safe-side continue), enriched webhook notifications (new event
types, level/ts contract, 429 Retry-After backoff, notificationEvidence), MP4
metadata tags (rplay_metadata_version=1-compatible, unknown values never
embedded, metadataEvidence), and the browser-core mirrors of the evidence
blocks. Local HTTP + FFmpeg only — VM-safe."""
import http.server,threading,tempfile,pathlib,subprocess,sys,json,os,unittest,time
import unittest.mock
import importlib.util
R=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('v270feat',R/'rplay_dl.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


class UnitV270Features(unittest.TestCase):
    def test_canary_check_shapes(self):
        ok=m.canary_check({'streamState':'live','accessible':True,'brandNew':'x'})
        self.assertEqual(ok['result'],'ok')
        self.assertIn('streamState',ok['knownKeys'])
        self.assertIn('brandNew',ok['observedKeys'])
        changed=m.canary_check({'totallyNewSchema':1})
        self.assertEqual(changed['result'],'shape_change')
        self.assertEqual(changed['knownKeys'],[])
        self.assertEqual(m.canary_check(None)['result'],'unreachable')
        self.assertEqual(m.canary_check({})['result'],'unreachable')
        self.assertEqual(m.canary_check('not-a-dict')['result'],'unreachable')
    def test_canary_evidence_block(self):
        res=m.canary_check({'streamState':'live'})
        ev=m.canary_evidence(res)
        self.assertEqual(ev['result'],'ok')
        self.assertIn('streamState',ev['knownKeys'])
        self.assertEqual(ev['action'],'warn_only')
        self.assertEqual(ev['provenance'],'live_play_response_shape')
        self.assertIn('checkedAt',ev)
    def test_mp4_metadata_args_unknown_values_not_embedded(self):
        full={'creatorOid':'a'*24,'title':'配信タイトル','artist':'nick',
              'recordingStartedAt':'2026-10-25T10:00:00+00:00','streamOid':'s'*24}
        args=m.mp4_metadata_args(full)
        pairs=[args[i+1] for i in range(0,len(args),2)]
        self.assertIn('rplay_metadata_version=1',pairs)
        self.assertIn('creator_oid='+'a'*24,pairs)
        self.assertIn('title=配信タイトル',pairs)
        self.assertIn('artist=nick',pairs)
        self.assertIn('recording_started_at=2026-10-25T10:00:00+00:00',pairs)
        self.assertIn('stream_oid='+'s'*24,pairs)
        # unknown values are never embedded (contract)
        partial=m.mp4_metadata_args({'creatorOid':'a'*24})
        pairs=[partial[i+1] for i in range(0,len(partial),2)]
        self.assertEqual(pairs,['rplay_metadata_version=1','creator_oid='+'a'*24])
        empty=m.mp4_metadata_args({})
        self.assertEqual([empty[i+1] for i in range(0,len(empty),2)],['rplay_metadata_version=1'])
        self.assertEqual(m.mp4_metadata_tags({}),['rplay_metadata_version'])
    def test_metadata_evidence_block(self):
        ev=m.metadata_evidence([])
        self.assertEqual(ev['embedded'],False)
        ev=m.metadata_evidence([{'file':'a.mp4','tags':['rplay_metadata_version','creator_oid','title']},
                                {'file':'b.mp4','tags':['rplay_metadata_version']}])
        self.assertEqual(ev['embedded'],True)
        self.assertEqual(ev['version'],1)
        self.assertEqual(len(ev['files']),2)
        self.assertEqual(ev['provenance'],'ffmpeg_metadata_args')
    def test_webhook_post_payload_contract_and_stats(self):
        m.notification_stats(reset=True)
        received=[]
        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self,*a):pass
            def do_POST(s):
                ln=int(s.headers.get('Content-Length') or 0)
                received.append(json.loads(s.rfile.read(ln).decode()))
                s.send_response(200);s.send_header('Content-Length','0');s.end_headers()
        srv=http.server.ThreadingHTTPServer(('127.0.0.1',0),H)
        threading.Thread(target=srv.serve_forever,daemon=True).start()
        try:
            m.webhook_post('http://127.0.0.1:%d/h'%srv.server_port,'save_error',
                           {'code':'ENOSPC','file':'x.ts'},wait=True,level='error')
            for _ in range(60):  # 1通目の到着を確定してから2通目を送る(順序固定)
                if received:break
                time.sleep(0.05)
            m.webhook_post('http://127.0.0.1:%d/h'%srv.server_port,'capacity_warning',
                           {'freeMb':12.0},wait=True,level='warn')
            time.sleep(0.8)  # 送信スレッドの完了を待つ(wait=Trueは非daemon化のみ)
            self.assertEqual(len(received),2)
            self.assertEqual(received[0]['event'],'save_error')
            self.assertEqual(received[0]['level'],'error')
            self.assertEqual(received[0]['code'],'ENOSPC')
            self.assertIn('ts',received[0])
            self.assertRegex(received[0]['tool'],r'rplay_dl\.py v2\.(?:[89]|10|11|12|13|36|37|38|39|40|41|42|43|44|45|46)\.0')
            self.assertEqual(received[1]['level'],'warn')
            st=m.notification_stats()
            self.assertEqual(st['events'].get('save_error'),1)
            self.assertEqual(st['events'].get('capacity_warning'),1)
            self.assertEqual(st['lastEvent']['event'],'capacity_warning')
            self.assertEqual(st['sent'],2)
            self.assertEqual(st['failed'],0)
        finally:srv.shutdown();srv.server_close()
    def test_webhook_429_retry_after_respected(self):
        m.notification_stats(reset=True)
        hits=[]
        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self,*a):pass
            def do_POST(s):
                ln=int(s.headers.get('Content-Length') or 0)
                s.rfile.read(ln)
                hits.append(time.monotonic())
                if len(hits)==1:
                    s.send_response(429);s.send_header('Retry-After','1')
                    s.send_header('Content-Length','0');s.end_headers()
                else:
                    s.send_response(200);s.send_header('Content-Length','0');s.end_headers()
        srv=http.server.ThreadingHTTPServer(('127.0.0.1',0),H)
        threading.Thread(target=srv.serve_forever,daemon=True).start()
        try:
            t0=time.monotonic()
            m.webhook_post('http://127.0.0.1:%d/h'%srv.server_port,'part',{},wait=True)
            time.sleep(2.5)  # Retry-After(1秒)を含む再送の完了を待つ
            self.assertEqual(len(hits),2)
            self.assertGreaterEqual(hits[1]-hits[0],0.9)   # Retry-After honoured
            self.assertLess(hits[1]-t0,8.0)                 # but never wedged
            st=m.notification_stats()
            self.assertEqual(st['rateLimited429'],1)
            self.assertEqual(st['sent'],1)
        finally:srv.shutdown();srv.server_close()
    def test_save_error_and_capacity_fire_webhook_events(self):
        """_save_errorとdisk_guard停止経路が save_error / capacity_warning を送る。"""
        m.notification_stats(reset=True)
        received=[]
        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self,*a):pass
            def do_POST(s):
                ln=int(s.headers.get('Content-Length') or 0)
                received.append(json.loads(s.rfile.read(ln).decode()))
                s.send_response(200);s.send_header('Content-Length','0');s.end_headers()
        srv=http.server.ThreadingHTTPServer(('127.0.0.1',0),H)
        threading.Thread(target=srv.serve_forever,daemon=True).start()
        try:
            with tempfile.TemporaryDirectory() as d:
                stopped=[]
                obj=types_simple(out_dir=d,oid='a'*24,min_free_mb=1e9,
                                 webhook='http://127.0.0.1:%d/h'%srv.server_port,
                                 stop=lambda reason:stopped.append(reason),log=lambda msg:None)
                obj._last_free_mb=None;obj._disk_low_n=0
                with unittest.mock.patch.object(m,'free_mb',lambda p:50.0):
                    m.Dl.disk_guard(obj)
                self.assertEqual(len(stopped),1)
                obj2=types_simple(out_dir=d,oid='a'*24,webhook='http://127.0.0.1:%d/h'%srv.server_port,
                                  log=lambda msg:None)
                obj2.save_errors=[]
                m.Dl._save_error(obj2,'video','/x/part1.ts','ENOSPC')
                self.assertEqual(obj2.save_errors[0]['code'],'ENOSPC')
                self.assertEqual(obj2.state,'IDLE')
            time.sleep(0.6)
            events=[r['event'] for r in received]
            self.assertIn('capacity_warning',events)
            self.assertIn('save_error',events)
            cap=[r for r in received if r['event']=='capacity_warning'][0]
            self.assertEqual(cap['level'],'warn')
            se=[r for r in received if r['event']=='save_error'][0]
            self.assertEqual(se['level'],'error')
            self.assertEqual(se['code'],'ENOSPC')
            self.assertEqual(se['file'],'part1.ts')
        finally:srv.shutdown();srv.server_close()
    def test_browser_evidence_blocks_mirror_python(self):
        """相互言語比較: canary_check と rspCanaryEvidence がPython/JS両コアで同一結果。"""
        vectors=[{'streamState':'live','accessible':True,'newKey':1},
                 {'totallyNew':2},None,{},'x']
        js=("const fs=require('fs');let src=fs.readFileSync('rplay-stable-player.user.js','utf8');"
            "const a=src.indexOf('function rspCanaryCheck');"
            "const b=src.indexOf('async function fetchJsonWithRetry');"
            "const code=src.slice(a,b);const vm=require('vm');"
            "const c=vm.createContext({JSON,console,Date});"
            "vm.runInContext(code+';globalThis._fns={check:rspCanaryCheck,evd:rspCanaryEvidence};',c);"
            "const fns=c._fns;"
            "let s='';process.stdin.on('data',x=>s+=x);process.stdin.on('end',()=>{"
            "const v=JSON.parse(s);"
            "process.stdout.write(JSON.stringify({checks:v.map(x=>fns.check(x)),"
            "evd:fns.evd(fns.check(v[0]))}));});")
        p=subprocess.run(['node','-e',js],input=json.dumps(vectors),text=True,capture_output=True,cwd=R)
        self.assertEqual(p.returncode,0,p.stderr)
        got=json.loads(p.stdout)
        for vec,want in zip(vectors,got['checks']):
            self.assertEqual(m.canary_check(vec),want,repr(vec))
        py_ev=m.canary_evidence(m.canary_check(vectors[0]))
        self.assertEqual(py_ev['result'],got['evd']['result'])
        self.assertEqual(py_ev['action'],got['evd']['action'])
        self.assertEqual(py_ev['provenance'],got['evd']['provenance'])
        self.assertEqual(set(py_ev),set(got['evd']))


def types_simple(**kw):
    import types
    return types.SimpleNamespace(**kw)


class E2EV270Features(unittest.TestCase):
    """CLI E2E through the real rplay_dl.py with a local HTTP source."""
    @classmethod
    def setUpClass(cls):
        cls.ffmpeg=bool(m.ffmpeg_tool())
        cls.tmp=tempfile.TemporaryDirectory()
        cls.seg=b'\x47'*(188*40)
        subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-f','lavfi',
                        '-i','testsrc2=size=160x90:rate=12','-t','1','-c:v','libx264',
                        '-preset','ultrafast','-f','mpegts',str(pathlib.Path(cls.tmp.name)/'src.ts')],
                       check=True,capture_output=True,timeout=30)
        cls.seg=pathlib.Path(cls.tmp.name)/'src.ts'
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()
    def _server(self,play_body):
        playlist=('#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:0\n'
                  '#EXTINF:1,\na.ts\n#EXT-X-ENDLIST\n')
        seg=self.seg.read_bytes()
        hook=[]
        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self,*a):pass
            def _send(s,code,body=b'',headers=None):
                s.send_response(code)
                for k,v in (headers or {}).items():s.send_header(k,v)
                s.send_header('Content-Length',str(len(body)));s.end_headers();s.wfile.write(body)
            def do_POST(s):
                ln=int(s.headers.get('Content-Length') or 0)
                hook.append(json.loads(s.rfile.read(ln).decode()))
                s._send(200)
            def do_GET(s):
                path=s.path.split('?')[0]
                if path=='/api/live/play':s._send(200,json.dumps(play_body).encode())
                elif path=='/live.m3u8':s._send(200,playlist.encode())
                elif path=='/a.ts':s._send(200,seg)
                else:s._send(404)
        srv=http.server.ThreadingHTTPServer(('127.0.0.1',0),H)
        threading.Thread(target=srv.serve_forever,daemon=True).start()
        return srv,'http://127.0.0.1:%d'%srv.server_port,hook
    def _run(self,url,out,*extra,timeout=60):
        cmd=[sys.executable,str(R/'rplay_dl.py'),'a'*24,'--api',url+'/api','--m3u8',url+'/live.m3u8',
             '--no-follow','--no-flv','--out',str(out),'--info-json']+list(extra)
        return subprocess.run(cmd,capture_output=True,text=True,timeout=timeout)
    def test_canary_ok_and_shape_change_continue_recording(self):
        for body,want in (({'streamState':'live','accessible':True,'allowAnonymous':True,'title':'タ'},'ok'),
                          ({'totallyDifferentApi':True},'shape_change')):
            srv,url,hook=self._server(body)
            try:
                with tempfile.TemporaryDirectory() as d:
                    p=self._run(url,pathlib.Path(d))
                    self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                    self.assertEqual(len(list(pathlib.Path(d).glob('*.ts'))),1)
                    info=json.loads(next(pathlib.Path(d).glob('*_info.json')).read_text())
                    self.assertEqual(info['canaryEvidence']['result'],want)
                    if want=='shape_change':
                        self.assertEqual(info['canaryEvidence']['knownKeys'],[])
                        self.assertIn('totallyDifferentApi',info['canaryEvidence']['observedKeys'])
                    else:
                        self.assertIn('streamState',info['canaryEvidence']['knownKeys'])
                    self.assertEqual(info['canaryEvidence']['action'],'warn_only')
            finally:srv.shutdown();srv.server_close()
    def test_webhook_events_and_notification_evidence(self):
        if not self.ffmpeg:self.skipTest('ffmpeg required')
        srv,url,hook=self._server({'streamState':'live','accessible':True,'allowAnonymous':True,'title':'配信T'})
        try:
            with tempfile.TemporaryDirectory() as d:
                p=self._run(url,pathlib.Path(d),'--mux','mp4',
                            '--webhook','http://127.0.0.1:%d/hook'%srv.server_port)
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                time.sleep(1.2)
                events=[h['event'] for h in hook]
                self.assertIn('start',events)
                self.assertIn('merge_completed',events)
                self.assertIn('end',events)
                for h in hook:
                    self.assertIn(h['event'],('start','part','audio_part','end','merge_completed',
                                              'auth_failed','save_error','capacity_warning'))
                    self.assertIn('level',h);self.assertIn('ts',h)
                merged=[h for h in hook if h['event']=='merge_completed'][0]
                self.assertEqual(merged['level'],'info')
                self.assertTrue(merged.get('file','').endswith('.mp4'))
                self.assertGreater(merged.get('bytes',0),0)
                self.assertIn('tags',merged)
                info=json.loads(next(pathlib.Path(d).glob('*_info.json')).read_text())
                nev=info['notificationEvidence']
                self.assertEqual(nev['events'].get('start'),1)
                self.assertGreaterEqual(nev['events'].get('merge_completed'),1)
                self.assertEqual(nev['provenance'],'webhook_delivery_counters')
                self.assertEqual(nev['failed'],0)
        finally:srv.shutdown();srv.server_close()
    def test_mp4_metadata_e2e_ffprobe(self):
        if not self.ffmpeg:self.skipTest('ffmpeg required')
        if not m.ffprobe_tool():self.skipTest('ffprobe required')
        srv,url,hook=self._server({'streamState':'live','accessible':True,'allowAnonymous':True,
                                   'title':'メタ実測配信','nickname':'作成者ニック'})
        try:
            with tempfile.TemporaryDirectory() as d:
                p=self._run(url,pathlib.Path(d),'--mux','mp4')
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)
                mp4s=list(pathlib.Path(d).glob('*.mp4'))
                self.assertEqual(len(mp4s),1)
                r=subprocess.run(['ffprobe','-v','error','-show_entries','format_tags',
                                  '-of','json',str(mp4s[0])],capture_output=True,text=True,timeout=30)
                tags=json.loads(r.stdout)['format']['tags'] or {}
                self.assertEqual(tags.get('rplay_metadata_version'),'1')
                self.assertEqual(tags.get('creator_oid'),'a'*24)
                self.assertEqual(tags.get('title'),'メタ実測配信')
                self.assertEqual(tags.get('artist'),'作成者ニック')
                self.assertIn('recording_started_at',tags)
                info=json.loads(next(pathlib.Path(d).glob('*_info.json')).read_text())
                ev=info['metadataEvidence']
                self.assertEqual(ev['embedded'],True)
                self.assertEqual(ev['version'],1)
                self.assertIn('creator_oid',ev['files'][0]['tags'])
                self.assertIn('title',ev['files'][0]['tags'])
                # unknown streamStartTime must NOT be embedded
                self.assertNotIn('stream_start_time',ev['files'][0]['tags'])
        finally:srv.shutdown();srv.server_close()


if __name__=='__main__':unittest.main()
