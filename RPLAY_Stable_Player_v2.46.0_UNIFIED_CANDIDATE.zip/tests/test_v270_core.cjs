'use strict';
/* v2.7.0 core features: RspAuth authEvidence (mirror of the CLI AuthStore block),
   browser canary (rspCanaryCheck / rspCanaryEvidence — same shape as Python),
   saveInfoJson integration of authEvidence/canaryEvidence via RECENV hooks, and
   the unified 2.7.0 version pin across userscript/manifests/CLI strings. */
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),vm=require('vm'),{webcrypto}=require('node:crypto');
const {spawnSync}=require('node:child_process');
const ROOT=path.join(__dirname,'..');
const source=fs.readFileSync(path.join(ROOT,'rplay-stable-player-extension/content.js'),'utf8');

function authWorld(lsEntries){
  const code=source.slice(source.indexOf('const RspAuth = {'),source.indexOf('async function fetchJsonWithRetry'));
  const map=new Map(Object.entries(lsEntries||{}));
  const ls={getItem:k=>map.has(k)?map.get(k):null,
    setItem:(k,v)=>map.set(k,String(v)),
    key:i=>Array.from(map.keys())[i]||null,
    get length(){return map.size;}};
  const parseJwtPayload=jwt=>{
    try{
      const parts=String(jwt).split('.');
      if(parts.length<2)return null;
      return JSON.parse(Buffer.from(parts[1],'base64url').toString('utf8'));
    }catch(e){return null;}
  };
  const c=vm.createContext({localStorage:ls,parseJwtPayload,JSON,console,Date});
  vm.runInContext(code+';globalThis.RspAuth=RspAuth;',c);
  return c.RspAuth;
}
function world(env={}){
  const code=source.slice(source.indexOf('  function recTrackSave'),source.indexOf('  /* ================= v1.11.0: AudioRecorder'));
  const classes=source.slice(source.indexOf('  class AudioRecorder'),source.indexOf('  /* ==== RSP RECORDING CORE',source.indexOf('  class AudioRecorder')));
  const stubs={safeName:s=>String(s==null?'':s).replace(/[^A-Za-z0-9_-]+/g,'_').slice(0,64),stampNow:()=>'20261025_120000'};
  const c=vm.createContext({Blob,crypto:webcrypto,Date,Set,Map,Promise,console,HLS:{},...stubs,
    RECENV:{download:async()=>undefined,backupPart:async()=>{},...env},REC_REQ_MIN_GAP_MS:0,REC_QUEUE_WARN_MS:60000});
  vm.runInContext(code+classes+';globalThis.api={RecPartSink,Recorder,AudioRecorder,recTrackSave,recWaitSaves,recRedactUrl,recLedgerStage,recLedgerStatus,recSha256Hex,recRecoveryEvidence};',c);return c.api;
}
function b64u(o){return Buffer.from(JSON.stringify(o)).toString('base64url');}
const JWT=b64u({alg:'none'})+'.'+b64u({oid:'b'.repeat(24),exp:Math.floor(Date.now()/1000)+3600})+'.sig';
const REFRESH='R'.repeat(48);

test('v2.7.0 version pin: userscript @version, both manifests, CLI strings',()=>{
  const us=fs.readFileSync(path.join(ROOT,'rplay-stable-player.user.js'),'utf8');
  assert.match(us,/\/\/ @version\s+2\.(?:[789]|10|11|12|13|36|37|38|39|40|41|42|43|44|45|46)\.0/);
  for(const ext of ['rplay-stable-player-extension','rplay-stable-player-extension-firefox']){
    const m=JSON.parse(fs.readFileSync(path.join(ROOT,ext,'manifest.json'),'utf8'));
    assert.match(m.version,/^2\.(?:[789]|10|11|12|13|36|37|38|39|40|41|42|43|44|45|46)\.0$/,ext);
    if(ext.endsWith('-firefox')) assert.equal(Object.hasOwn(m,'version_name'),false,'Firefox must omit unsupported version_name'); else assert.match(m.version_name,/^2\.(?:[789]|10|11|12|13|36|37|38|39|40|41|42|43|44|45|46)\.0 CANDIDATE$/,ext+' version_name');
  }
  const cli=fs.readFileSync(path.join(ROOT,'rplay_dl.py'),'utf8');
  assert.match(cli,/RPLAY Live Downloader v2\.(?:[789]|10|11|12|13|36|37|38|39|40|41|42|43|44|45|46)\.0 CANDIDATE/);
  assert.match(cli,/rplay_dl\.py v2\.(?:[789]|10|11|12|13|36|37|38|39|40|41|42|43|44|45|46)\.0/);
  assert.match(cli,/\(rplay_dl\.py\) v2\.(?:[789]|10|11|12|13|36|37|38|39|40|41|42|43|44|45|46)\.0/);
});
test('v2.7.0 RspAuth.authEvidence: counters, structure, and zero secrets',()=>{
  const R=authWorld({'_AUTHORIZATION_':JWT});
  R.probe();
  const rt=x=>JSON.parse(JSON.stringify(x));  // VM realm → plain objects
  let ev=rt(R.authEvidence());
  assert.equal(ev.mode,'localStorage-interceptor');
  assert.equal(ev.tokenSource,'localStorage');
  assert.equal(ev.refreshSource,null);            // no refresh-token-looking key present
  assert.equal(ev.userOidSupplied,true);          // oid came from the JWT payload
  assert.equal(ev.switchedToRefresh,false);
  assert.equal(ev.refreshAttempts,0);
  assert.equal(ev.refreshSuccesses,0);
  assert.equal(ev.refreshFailures,0);
  assert.equal(ev.responseKey,null);
  assert.deepEqual(ev.classifications401,{});
  assert.equal(ev.key2Resolutions,0);
  assert.equal(ev.butterSent,false);
  assert.equal(ev.provenance,'rspauth_counters');
  const dump=JSON.stringify(ev);
  assert.equal(dump.includes(JWT),false);
  assert.equal(dump.includes('b'.repeat(24)),false); // oid value is not the secret, but never leaked either
  // counters bump and flow into the evidence
  R.note401('auth-expired');R.note401('auth-expired');R.noteKey2();
  ev=rt(R.authEvidence());
  assert.deepEqual(ev.classifications401,{'auth-expired':2});
  assert.equal(ev.key2Resolutions,1);
});
test('v2.7.0 RspAuth.authEvidence: refresh-token presence recorded as source kind only',()=>{
  const map=new Map([['_AUTHORIZATION_',JWT],
    ['vuex',JSON.stringify({account:{auth:{refreshToken:REFRESH}}})]]);
  const R2=(function(){
    const code=source.slice(source.indexOf('const RspAuth = {'),source.indexOf('async function fetchJsonWithRetry'));
    const ls={getItem:k=>map.has(k)?map.get(k):null,key:i=>Array.from(map.keys())[i]||null,get length(){return map.size;}};
    const parseJwtPayload=jwt=>JSON.parse(Buffer.from(String(jwt).split('.')[1],'base64url').toString('utf8'));
    const c=vm.createContext({localStorage:ls,parseJwtPayload,JSON,console,Date});
    vm.runInContext(code+';globalThis.RspAuth=RspAuth;',c);return c.RspAuth;})();
  R2.probe();
  const ev=R2.authEvidence();
  assert.equal(ev.refreshSource,'localStorage-scan');
  assert.equal(ev.tokenSource,'localStorage');
  assert.equal(JSON.stringify(ev).includes(REFRESH),false);  // kind only, never the value
});
test('v2.7.0 authEvidence key structure mirrors the Python AuthStore block',()=>{
  const R=authWorld({'_AUTHORIZATION_':JWT});
  R.probe();
  const jsKeys=Object.keys(R.authEvidence()).sort();
  const py=spawnSync('python3',['-c',
    "import importlib.util,json,pathlib\n"+
    "spec=importlib.util.spec_from_file_location('x',pathlib.Path('rplay_dl.py'))\n"+
    "m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)\n"+
    "a=m.AuthStore('',http_fn=lambda *a,**k:(200,b'{}',0),token='t')\n"+
    "print(json.dumps(a.evidence()))"],
    {cwd:ROOT,encoding:'utf8'});
  assert.equal(py.status,0,py.stderr);
  const pyKeys=Object.keys(JSON.parse(py.stdout)).sort();
  assert.deepEqual(jsKeys,pyKeys);   // one contract, two languages
});
test('v2.7.0 browser canary: same verdicts and evidence block as the Python core',()=>{
  const code=source.slice(source.indexOf('function rspCanaryCheck'),source.indexOf('async function fetchJsonWithRetry'));
  const c=vm.createContext({JSON,console,Date});
  vm.runInContext(code+';globalThis.out={check:rspCanaryCheck,evd:rspCanaryEvidence};',c);
  const out=c.out;
  const rt=x=>JSON.parse(JSON.stringify(x));  // VM realm → plain objects
  assert.deepEqual(rt(out.check({streamState:'live',accessible:true,newKey:1})),
    {result:'ok',observedKeys:['accessible','newKey','streamState'],knownKeys:['accessible','streamState']});
  assert.deepEqual(rt(out.check({totallyNew:2})),{result:'shape_change',observedKeys:['totallyNew'],knownKeys:[]});
  assert.deepEqual(rt(out.check(null)),{result:'unreachable',observedKeys:[],knownKeys:[]});
  assert.deepEqual(rt(out.check({})),{result:'unreachable',observedKeys:[],knownKeys:[]});
  assert.deepEqual(rt(out.check('x')),{result:'unreachable',observedKeys:[],knownKeys:[]});
  const evd=rt(out.evd(out.check({streamState:'live'})));
  assert.equal(evd.result,'ok');
  assert.equal(evd.action,'warn_only');
  assert.equal(evd.provenance,'live_play_response_shape');
  assert.deepEqual(Object.keys(evd).sort(),['action','checkedAt','knownKeys','observedKeys','provenance','result']);
});
test('v2.7.0 saveInfoJson embeds authEvidence/canaryEvidence via RECENV hooks (no fake zeros)',async()=>{
  const blobs=[];
  const authStats=()=>({mode:'localStorage-interceptor',tokenSource:'localStorage',refreshSource:null,
    userOidSupplied:true,switchedToRefresh:false,refreshAttempts:0,refreshSuccesses:0,
    refreshFailures:0,responseKey:null,classifications401:{'auth-expired':1},key2Resolutions:2,
    butterSent:true,provenance:'rspauth_counters'});
  const canaryEvidence=()=>({result:'ok',observedKeys:['streamState'],knownKeys:['streamState'],
    checkedAt:new Date('2026-10-25T12:00:00Z').toISOString(),action:'warn_only',
    provenance:'live_play_response_shape'});
  const a=world({download:async(b,n)=>{blobs.push({b,n});return {confirmed:true,stage:'DOWNLOAD_REQUESTED'};},
    authStats,canaryEvidence});
  const r=Object.create(a.Recorder.prototype);
  Object.assign(r,{
    id:'testoid',partsLog:[{file:'x.ts',ext:'ts',bytes:5,segments:1}],startedAt:Date.now()-2000,
    bytesTotal:5,segTotal:1,segFails:0,gapCount:0,resumes:0,byerangeSkipped:0,
    audioTxt:'',audio:null,selVariant:null,variants:[],liveInfo:null,schedItem:null,
    sourceKind:'legacy',accessMode:'legacy',log:()=>{},
    creatorName:()=>'creator A',playlistUrl:()=>'https://x.example/hls/live.m3u8?sig=SECRET',
    recTitle:()=>'t',nameTpl:()=>'',csvOut:()=>false,statsBlock:()=>({missingRate:0}),
  });
  r.saveInfoJson();
  await new Promise(res=>setTimeout(res,20));
  const info=JSON.parse(await blobs[0].b.text());
  assert.match(info.tool,/^RPLAY Stable Player v2\.(?:[89]|10|11|12|13|36|37|38|39|40|41|42|43|44|45|46)\.0$/);
  assert.deepEqual(info.authEvidence,authStats());
  assert.deepEqual(info.canaryEvidence,canaryEvidence());
  assert.equal(JSON.stringify(info).includes('SECRET'),false);
  // without the RECENV hooks the blocks are absent — never faked with zeros
  const b=world({download:async(b2,n)=>{blobs.push({b:b2,n});return {confirmed:true,stage:'DOWNLOAD_REQUESTED'};}});
  const r2=Object.create(b.Recorder.prototype);
  Object.assign(r2,JSON.parse(JSON.stringify({
    id:'testoid',partsLog:[{file:'x.ts',ext:'ts',bytes:5,segments:1}],startedAt:Date.now()-2000,
    bytesTotal:5,segTotal:1,segFails:0,gapCount:0,resumes:0,audioTxt:'',audio:null,
    selVariant:null,variants:[],liveInfo:null,schedItem:null,sourceKind:'legacy',accessMode:'legacy'})),
    {log:()=>{},creatorName:()=>'creator A',playlistUrl:()=>'https://x.example/hls/live.m3u8',
     recTitle:()=>'t',nameTpl:()=>'',csvOut:()=>false,statsBlock:()=>({missingRate:0})});
  r2.saveInfoJson();
  await new Promise(res=>setTimeout(res,20));
  const info2=JSON.parse(await blobs[1].b.text());
  assert.equal(info2.authEvidence,undefined);
  assert.equal(info2.canaryEvidence,undefined);
});
