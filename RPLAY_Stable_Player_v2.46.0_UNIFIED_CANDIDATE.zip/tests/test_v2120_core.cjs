'use strict';
/* v2.15.0 core features (4-branch unification [v2.9.1 + v2.10.0 AGGREGATE + v2.10.0 UNIFIED + v2.11.0 SINGLE FILE] + cat-catch learnings):
   1. Unified 2.12.0 version pin across userscript/manifests/CLI/rplay_join.py/acceptance_report.py.
   2. cat-catch TS disguise header stripping (PNG/GIF/BMP/JPEG/WEBP disguise prefix before 0x47 sync bytes) in RspHlsTransport.stripDisguisedTs & validate(bytes, 'ts').
   3. cat-catch M3U8 query-parameter inheritance (inheritQuery / --inherit-query) appending playlist query parameters to relative segment & EXT-X-MAP URIs without overwriting existing segment keys.
   4. cat-catch m3u8dl:// protocol URI & N_m3u8DL-RE command builder (rspBuildM3u8dlExport) with secret-redacted evidence (rspExternalDownloaderEvidence).
   5. Cross-language parity between JS and Python for TS disguise stripping, query-param inheritance, m3u8dl:// protocol generation, and externalDownloaderEvidence.
   6. Full coexistence of v2.9.1 (rspBlobHoldMs/rspDelayedBlobRelease), v2.10.0 AGGREGATE (recJoinJob/saveJoinJob/partBoundaryEvidence), v2.10.0 UNIFIED (MPEG-TS discontinuity seamless append/partContinuityEvidence), and v2.11.0 SINGLE FILE (RecPartSink.flush/continuousDisk). */
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),vm=require('vm');
const {spawnSync}=require('node:child_process');
const H=require('../src/hls_transport.js');
const ROOT=path.join(__dirname,'..');
const source=fs.readFileSync(path.join(ROOT,'rplay-stable-player.user.js'),'utf8');

test('v2.15.0 version pin: userscript @version, both manifests, CLI strings, join & acceptance tools',()=>{
  const us=fs.readFileSync(path.join(ROOT,'rplay-stable-player.user.js'),'utf8');
  assert.match(us,/\/\/ @version\s+2\.(?:12|36|37|38|39|40|41|42|43|44|45|46)\.0/);
  for(const ext of ['rplay-stable-player-extension','rplay-stable-player-extension-firefox']){
    const m=JSON.parse(fs.readFileSync(path.join(ROOT,ext,'manifest.json'),'utf8'));
    assert.match(m.version,/^2\.(?:12|36|37|38|39|40|41|42|43|44|45|46)\.0$/,ext);
    if(ext.endsWith('-firefox')) assert.equal(Object.hasOwn(m,'version_name'),false,'Firefox must omit unsupported version_name'); else assert.match(m.version_name,/^2\.(?:12|36|37|38|39|40|41|42|43|44|45|46)\.0 CANDIDATE$/,ext+' version_name');
  }
  const cli=fs.readFileSync(path.join(ROOT,'rplay_dl.py'),'utf8');
  assert.match(cli,/RPLAY Live Downloader v2\.(?:12|36|37|38|39|40|41|42|43|44|45|46)\.0 CANDIDATE/);
  assert.match(cli,/rplay_dl\.py v2\.(?:12|36|37|38|39|40|41|42|43|44|45|46)\.0/);
  assert.match(cli,/\(rplay_dl\.py\) v2\.(?:12|36|37|38|39|40|41|42|43|44|45|46)\.0/);
  assert.ok(fs.existsSync(path.join(ROOT,'rplay_join.py')),'rplay_join.py must be built at root');
  assert.ok(fs.existsSync(path.join(ROOT,'scripts','acceptance_report.py')),'acceptance_report.py must exist');
});

test('v2.15.0 cat-catch TS image-header disguise stripping (PNG/GIF/BMP/JPEG/WEBP prefix before 188-byte 0x47 packets)',()=>{
  const validTs=Buffer.alloc(188*3);
  validTs[0]=0x47;validTs[188]=0x47;validTs[376]=0x47;
  // 1) PNG magic header (8 bytes) + 24 bytes fake IHDR = 32 bytes prefix before valid TS
  const pngPrefix=Buffer.from([0x89,0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A,...Buffer.alloc(24,0x11)]);
  const disguisedPng=Buffer.concat([pngPrefix,validTs]);
  const resPng=H.stripDisguisedTs(disguisedPng);
  assert.equal(resPng.strippedBytes,32);
  assert.equal(resPng.magic,'png');
  assert.equal(resPng.bytes.length,validTs.length);
  assert.equal(resPng.bytes[0],0x47);
  // validate(disguisedPng, 'ts') automatically strips disguise and returns clean TS bytes
  const validated=H.validate(disguisedPng,'ts');
  assert.equal(validated.length,validTs.length);
  assert.equal(validated[0],0x47);

  // 2) GIF89a header (16 bytes) before valid TS
  const gifPrefix=Buffer.from('GIF89a0123456789','ascii');
  const validatedGif=H.validate(Buffer.concat([gifPrefix,validTs]),'ts');
  assert.equal(validatedGif.length,validTs.length);

  // 3) Random non-magic garbage before TS MUST STILL BE REJECTED (fail-closed safety)
  const randomGarbage=Buffer.concat([Buffer.from([0x00,0x01,0x02,0x03]),validTs]);
  assert.throws(()=>H.validate(randomGarbage,'ts'),/HLS_BAD_TS/);
});

test('v2.15.0 cat-catch M3U8 query-parameter inheritance (inheritQuery option in parse)',()=>{
  const m3u8='#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-MAP:URI="init.mp4"\n#EXTINF:1,\nseg0.ts\n#EXTINF:1,\nseg1.ts?custom=1&sig=OVERRIDE\n';
  const baseWithQuery='https://cdn.example/live/stream.m3u8?sig=BASE_TOKEN&key2=K2';
  // Default (inheritQuery=false): relative segment URLs do not inherit base query
  const pDefault=H.parse(m3u8,baseWithQuery,'legacy',false);
  assert.equal(pDefault.segments[0].uri,'https://cdn.example/live/seg0.ts');
  assert.equal(pDefault.segments[0].map.uri,'https://cdn.example/live/init.mp4');

  // inheritQuery=true (cat-catch "添加get参数" mode): inherits missing query params from playlist URL
  const pInherit=H.parse(m3u8,baseWithQuery,'legacy',true);
  assert.equal(pInherit.segments[0].uri,'https://cdn.example/live/seg0.ts?sig=BASE_TOKEN&key2=K2');
  assert.equal(pInherit.segments[0].map.uri,'https://cdn.example/live/init.mp4?sig=BASE_TOKEN&key2=K2');
  // Existing segment query param (sig=OVERRIDE) is preserved while missing key2=K2 is appended
  assert.equal(pInherit.segments[1].uri,'https://cdn.example/live/seg1.ts?custom=1&sig=OVERRIDE&key2=K2');
});

test('v2.15.0 cat-catch m3u8dl:// protocol URI & N_m3u8DL-RE command builder with zero-secret evidence',()=>{
  const s1=source.slice(source.indexOf('function rspBuildM3u8dlExport'),source.indexOf('function rspDetectPaywallBlocked'));
  const c=vm.createContext({Buffer,btoa:s=>Buffer.from(s,'utf8').toString('base64'),encodeURIComponent,URL,JSON,Array,Object,String,Boolean,Number});
  vm.runInContext(s1+';globalThis.fns={build:rspBuildM3u8dlExport,evd:rspExternalDownloaderEvidence};',c);
  const exp=c.fns.build({
    url:'https://cdn.example/live/stream.m3u8?sig=SECRET_SIG',
    saveName:'RPLAY_creator_20261026',
    headers:{Referer:'https://rplay.live/','User-Agent':'TestUA',Butter:'BUTTER_HEX'},
    liveRealTimeMerge:true
  });
  assert.match(exp.protocolUri,/^m3u8dl:\/\//);
  const decoded=Buffer.from(exp.protocolUri.slice('m3u8dl://'.length),'base64').toString('utf8');
  assert.ok(decoded.includes('https://cdn.example/live/stream.m3u8?sig=SECRET_SIG'));
  assert.ok(decoded.includes('--save-name "RPLAY_creator_20261026"'));
  assert.ok(decoded.includes('--live-real-time-merge'));
  assert.ok(exp.command.startsWith('N_m3u8DL-RE '));

  // Evidence block MUST NEVER contain secret query strings or header values
  const ev=JSON.parse(JSON.stringify(c.fns.evd(exp,{tsDisguiseStrippedCount:2,tsDisguiseBytesTotal:64,queryInheritedCount:5})));
  assert.equal(ev.targetUrl,'https://cdn.example/live/stream.m3u8');
  assert.equal(JSON.stringify(ev).includes('SECRET_SIG'),false);
  assert.equal(JSON.stringify(ev).includes('BUTTER_HEX'),false);
  assert.deepEqual(ev.headerKeys,['Butter','Referer','User-Agent']);
  assert.equal(ev.tsDisguiseStrippedCount,2);
  assert.equal(ev.queryInheritedCount,5);
});

test('v2.15.0 cross-language parity: JS vs Python m3u8dl export & externalDownloaderEvidence',()=>{
  const s1=source.slice(source.indexOf('function rspBuildM3u8dlExport'),source.indexOf('function rspDetectPaywallBlocked'));
  const c=vm.createContext({Buffer,btoa:s=>Buffer.from(s,'utf8').toString('base64'),encodeURIComponent,URL,JSON,Array,Object,String,Boolean,Number});
  vm.runInContext(s1+';globalThis.fns={build:rspBuildM3u8dlExport,evd:rspExternalDownloaderEvidence};',c);
  const opts={
    url:'https://cdn.example/live/stream.m3u8?sig=SECRET123',
    saveName:'RPLAY_test_stream',
    headers:{Referer:'https://rplay.live/','User-Agent':'Mozilla/5.0'},
    liveRealTimeMerge:true
  };
  const jsExp=c.fns.build(opts);
  const jsEv=JSON.parse(JSON.stringify(c.fns.evd(jsExp,{tsDisguiseStrippedCount:1,tsDisguiseBytesTotal:32,queryInheritedCount:3})));

  const py=spawnSync('python3',['-c',
    "import importlib.util,json,pathlib\n"+
    "spec=importlib.util.spec_from_file_location('x',pathlib.Path('rplay_dl.py'))\n"+
    "m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)\n"+
    "opts=json.loads('"+JSON.stringify(opts)+"')\n"+
    "exp=m.build_m3u8dl_export(opts['url'],opts['saveName'],opts['headers'],opts['liveRealTimeMerge'])\n"+
    "ev=m.external_downloader_evidence(exp,{'tsDisguiseStrippedCount':1,'tsDisguiseBytesTotal':32,'queryInheritedCount':3})\n"+
    "print(json.dumps({'exp':exp,'ev':ev}))"],
    {cwd:ROOT,encoding:'utf8'});
  assert.equal(py.status,0,py.stderr);
  const out=JSON.parse(py.stdout);
  assert.equal(jsExp.protocolUri,out.exp.protocolUri);
  assert.equal(jsExp.command,out.exp.command);
  assert.deepEqual(jsEv,out.ev);
});

test('v2.15.0 4-branch integration check: v2.9.1 Blob hold + v2.10.0 AGGREGATE joinJob + v2.10.0 UNIFIED continuity + v2.11.0 flush all present',()=>{
  assert.match(source,/function rspBlobHoldMs\(/);
  assert.match(source,/function rspDelayedBlobRelease\(/);
  assert.match(source,/function recJoinJob\(/);
  assert.match(source,/async saveJoinJob\(\)/);
  assert.match(source,/function rspPartContinuityEvidence\(/);
  assert.match(source,/continuousDisk\(\)/);
  assert.match(source,/function rspBuildM3u8dlExport\(/);
});
