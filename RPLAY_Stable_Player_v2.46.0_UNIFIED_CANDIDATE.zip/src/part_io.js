  /* RSP_SHA256_MODULE */
  /* RSP_PART_COMMIT_MODULE */
  /* Shared per-part writer: an asynchronously opened writer belongs only to this part. */
  function recTrackSave(owner, promise) {
    if (!owner._saveJobs) owner._saveJobs = new Set();
    owner._saveJobs.add(promise);
    promise.then(() => owner._saveJobs.delete(promise), () => owner._saveJobs.delete(promise));
    return promise;
  }
  async function recWaitSaves(owner) {
    while (owner._saveJobs && owner._saveJobs.size) await Promise.allSettled([...owner._saveJobs]);
  }
  /* v2.46.0: Sanitize persisted part entries across browser reload/crash resume (zero URLs/secrets, bounded size). */
  function recSanitizePersistedParts(list) {
    if (!Array.isArray(list)) return [];
    const out = [];
    for (const raw of list.slice(-128)) {
      if (!raw || typeof raw !== "object") continue;
      const file = typeof raw.file === "string" ? raw.file.slice(0, 260) : "";
      const ext = typeof raw.ext === "string" ? raw.ext.slice(0, 12) : "ts";
      const bytes = Number.isSafeInteger(raw.bytes) && raw.bytes > 0 ? raw.bytes : 0;
      if (!file || !bytes || /^(?:https?|wss?|blob|data):/i.test(file) || /[\\/]/.test(file)) continue;
      const entry = {
        file,
        ext,
        bytes,
        segments: Number.isSafeInteger(raw.segments) && raw.segments >= 0 ? raw.segments : 0,
        startedAt: typeof raw.startedAt === "string" ? raw.startedAt.slice(0, 40) : "",
        endedAt: typeof raw.endedAt === "string" ? raw.endedAt.slice(0, 40) : "",
        saveState: typeof raw.saveState === "string" ? raw.saveState.slice(0, 32) : "FILE_CLOSED",
        hashState: typeof raw.hashState === "string" ? raw.hashState.slice(0, 32) : "unavailable",
        structureValidated: !!raw.structureValidated,
        resumedFromPriorRun: true
      };
      if (raw.kind === "audio") entry.kind = "audio";
      if (typeof raw.sha256 === "string" && /^[0-9a-f]{64}$/i.test(raw.sha256)) entry.sha256 = raw.sha256.toLowerCase();
      if (typeof raw.ledgerStatus === "string") entry.ledgerStatus = raw.ledgerStatus.slice(0, 32);
      if (Array.isArray(raw.stages)) entry.stages = raw.stages.slice(0, 16);
      if (raw.partIntegrity && typeof raw.partIntegrity === "object") entry.partIntegrity = raw.partIntegrity;
      out.push(entry);
    }
    return out;
  }
  // Recovery uses committed chunks alongside the final writer. Only a journal
  // closed after verified chunks advertises recoverable bytes. No remote URLs.
  class RecCheckpointStore {
    constructor(directory,name,ext,options={}) {
      this.name=name;this.ext=ext;this.parts=[];this.bytes=0;this.pending=0;this.writer=null;
      this.limit=options.checkpointBytes||64*1048576;this.interval=options.checkpointMs||30000;this.last=Date.now();
      this.ready=directory.getDirectoryHandle('rsp-recovery',{create:true}).then(d=>d.getDirectoryHandle(name+'.checkpoint',{create:true}));
      // ready is awaited by write/finish; attach a handler for early open failure.
      this.ready.catch(()=>{});
    }
    async write(data) {
      const dir=await this.ready;
      if(!this.writer){this.current='chunk-'+String(this.parts.length+1).padStart(8,'0')+'.bin';this.handle=await dir.getFileHandle(this.current,{create:true});this.writer=await this.handle.createWritable();this.chunkHash=new RspSha256.Sha256();}
      await this.writer.write(data);this.chunkHash.update(data);this.pending+=data.byteLength;
      if(this.pending>=this.limit||Date.now()-this.last>=this.interval)await this.checkpoint();
    }
    async journal(status) {
      const dir=await this.ready;const h=await dir.getFileHandle('journal.json',{create:true});const w=await h.createWritable();
      try{await w.write(JSON.stringify({schema:2,file:this.name,ext:this.ext,status,committedBytes:this.bytes,parts:this.parts,updatedAt:new Date().toISOString()}));await w.close();}
      catch(e){try{await w.abort();}catch(ignore){}throw e;}
    }
    async checkpoint() {
      if(!this.writer||!this.pending)return;
      await this.writer.close();this.writer=null;
      const file=await this.handle.getFile();if(file.size!==this.pending)throw Error('CHECKPOINT_SIZE_MISMATCH');
      const sha256=await RspSha256.hashBlob(file);
      if(sha256!==this.chunkHash.digest())throw Error('CHECKPOINT_HASH_MISMATCH');
      this.parts.push({file:this.current,bytes:this.pending,sha256});this.bytes+=this.pending;this.pending=0;
      if(this.parts.length>4096)throw Error('CHECKPOINT_PART_LIMIT');
      await this.journal('active');this.last=Date.now();
    }
    async finish(){await this.checkpoint();}
    async complete(){await this.journal('complete');}
    async abort(){if(this.writer)try{await this.writer.abort();}catch(ignore){}this.writer=null;}
  }
  class RecPartSink {
    constructor(name, directory, ext, options={}) {
      const suffix = typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID().replace(/-/g,'') : Date.now().toString(36)+Math.random().toString(36).slice(2);
      this.name = name.replace(/(\.[^.]+)$/, '_'+suffix+'$1');
      this.ext = ext; this.bytes = 0; this.chunks = []; this.writer = null; this.error = null; this.closed = false;
      this.checkpoints=directory && typeof directory.getDirectoryHandle==='function' && ['ts','mp4'].includes(ext) ? new RecCheckpointStore(directory,this.name,ext,options) : null;
      this.tail = Promise.resolve();
      this.ready = directory ? directory.getFileHandle(this.name, {create:true}).then(fh => {
        this.handle=fh; return fh.createWritable();
      }).then(w => {
        this.writer=w; const chunks=this.chunks;this.chunks=[];for(const chunk of chunks)this.enqueue(chunk);
      }).catch(() => { this.writer=null; }) : Promise.resolve();
    }
    enqueue(chunk) {
      this.tail=this.tail.then(async()=>{if(this.error)return;try{await this.writer.write(chunk);if(this.checkpoints)await this.checkpoints.write(chunk);}catch(e){this.error=e;}});
    }
    push(chunk) {
      if(this.closed)throw Error('PART_CLOSED');
      this.bytes+=chunk.length;
      if(this.writer)this.enqueue(chunk);else this.chunks.push(chunk);
    }
    // Producers await this before fetching another segment; slow disks cannot build
    // an unbounded chain of writes. Open failure keeps the bounded Blob fallback.
    async flush() {
      await this.ready; await this.tail;
      if (this.error) throw Error('PART_WRITE_FAILED');
    }
    continuousDisk() {
      return !!this.writer && !this.error && !this.closed && (this.ext==='ts'||this.ext==='mp4');
    }
    async close() {
      if(this.closed)throw Error('PART_ALREADY_CLOSED');this.closed=true;
      await this.ready;await this.tail;
      if(this.error){try{await this.writer.abort();}catch(e){}if(this.checkpoints)await this.checkpoints.abort();throw Error('PART_WRITE_FAILED');}
      if(this.writer){
        try{if(this.checkpoints)await this.checkpoints.finish();await this.writer.close();const file=await this.handle.getFile();if(file.size!==this.bytes)throw Error('PART_SIZE_MISMATCH');
          if(this.checkpoints)await this.checkpoints.complete();
          /* v2.5.0(P1): 保存確定イベント契約 — HASHED段階の実測値(計算不能時はnullを返し、
             偽のハッシュ段階を記録しない。計算は保存完了後に行い、保存経路を遅らせない) */
          const hashHex=await recSha256Hex(file);
          if(typeof RECENV.backupPart==='function'&&this.bytes>0)try{await RECENV.backupPart(file,this.name,{file:this.name,bytes:this.bytes});}catch(e){}
          return {confirmed:true,stage:'FILE_CLOSED',file:this.name,hashHex,...(this.checkpoints?{checkpoint:{status:'complete',chunks:this.checkpoints.parts.length,committedBytes:this.checkpoints.bytes}}:{})};
        }catch(e){if(this.checkpoints)await this.checkpoints.abort();try{await this.writer.abort();}catch(ignore){}throw Error('PART_CLOSE_FAILED');}
      }
      if(this.bytes===0)return {confirmed:false,stage:'EMPTY',file:this.name};
      const blob=new Blob(this.chunks,{type:this.ext==='flv'?'video/x-flv':(this.ext==='mp4'?'video/mp4':'video/mp2t')});
      const result=await RECENV.download(blob,this.name);
      if(result&&result.confirmed&&typeof RECENV.backupPart==='function')try{await RECENV.backupPart(blob,this.name,{file:this.name,bytes:this.bytes});}catch(e){}
      const hashHex=await recSha256Hex(blob); // v2.5.0(P1): HASHED段階の実測値
      return {file:this.name,confirmed:!!(result&&result.confirmed),stage:result&&result.stage||'DOWNLOAD_REQUESTED',hashHex};
    }
  }
  /* v2.5.0(P2): 診断出力用URL秘匿 — クエリ(署名/key2)とフラグメントを除去し
     origin+pathだけを残す。RAM内の取得経路は変更しない(出力のみの変換)。 */
  function recRedactUrl(u) {
    try {
      const s = String(u || '');
      if (!s) return s;
      const i = s.search(/[?#]/);
      return i < 0 ? s : s.slice(0, i);
    } catch (e) { return String(u || ''); }
  }

  /* v2.5.0(P1): 保存確定イベント契約 — パート台帳の段階記録。
     REQUESTED → FILE_WRITTEN → BROWSER_DONE → HASHED → DECODED/CONTINUITY の順で
     各段階の実測時のみ追記し、段階を飛ばしてSUCCESS扱いにしない。
     (ブラウザー側はDECODED/CONTINUITYをffprobeなしでは達成できないため
     structureValidated=セグメント単位の構造検査証拠として記録し、
     完全デコード監査はCLI --qauditの担当と明示分離する) */
  function recLedgerStage(entry, stage, detail) {
    if (!entry) return;
    if (!entry.stages) entry.stages = [];
    const last = entry.stages[entry.stages.length - 1];
    if (last && last.stage === stage) return; // 同段階の二重追記をしない
    entry.stages.push(Object.assign({ stage: stage, at: new Date().toISOString() }, detail || {}));
  }
  function recLedgerStatus(entry) {
    if (!entry || !entry.stages || !entry.stages.length) return 'unknown';
    if (entry.saveState === 'failed') return 'failed';
    const names = entry.stages.map(function (s) { return s.stage; });
    const confirmed = names.indexOf('BROWSER_DONE') >= 0 || names.indexOf('FILE_WRITTEN') >= 0;
    const hashed = names.indexOf('HASHED') >= 0;
    /* SUCCESSは「適用可能な全段階が実測された」場合のみ。ブラウザーでは
       DECODED/CONTINUITYが適用外のため、 confirmed+hashed を最高到達段階とし
       saveState(検証済み段階)と共に明示する(飛ばし無し) */
    if (entry.saveState === 'failed') return 'failed';
    if (confirmed && hashed && entry.structureValidated) return 'CONFIRMED_HASHED_STRUCTURE';
    if (confirmed && hashed) return 'CONFIRMED_HASHED';
    if (confirmed) return 'CONFIRMED_UNHASHED';
    return 'PENDING_' + entry.saveState;
  }
  /* v2.5.0(P1): パート本体のsha256(crypto.subtle不可環境はnull — 偽らない) */
  async function recSha256Hex(blobOrFile) {
    try { return await RspSha256.hashBlob(blobOrFile); }
    catch(e) { return null; } // A read failure must not become a fake HASHED stage.
  }

  /* v2.6.0(P1/P2): HLSコアが文脈単位で累積した数値証拠(世代復旧・fMP4 MAP宣言・
     LL-HLS指標タグ)を情報JSON用に整形する。証拠が1つも無いときはundefinedを返し
     偽の零を作らない(ブラウザー側はffprobe不在のためDECODED相関はCLI --qaudit担当)。 */
  function recRecoveryEvidence(owner, audioOwner) {
    function recov(o) { return (o && o._hlsRecovery) ? o._hlsRecovery : undefined; }
    function fmp(o) { return (o && o._hlsFmp4) ? o._hlsFmp4 : undefined; }
    function llh(o) { return (o && o._hlsLlhlsIndicators) ? { indicatorTags: o._hlsLlhlsIndicators } : undefined; }
    const v = recov(owner) || fmp(owner) || llh(owner);
    const a = recov(audioOwner) || fmp(audioOwner) || llh(audioOwner);
    if (!v && !a) return undefined;
    return {
      generationRecovery: {
        video: recov(owner), audio: recov(audioOwner),
        provenance: 'manifest_sequence_and_uri_classification'
      },
      fmp4Evidence: {
        video: fmp(owner), audio: fmp(audioOwner),
        provenance: 'manifest_map_declarations',
        note: 'MAP切替はパート境界分割で初期化セグメント混在を防止。DISCONTINUITY無し切替は計数(拒否しない)'
      },
      llhlsEvidence: {
        video: llh(owner), audio: llh(audioOwner),
        policy: 'EXT-X-SKIP(差分playlist)はHLS_LLHLS_SKIPで拒否。PRELOAD-HINT/SERVER-CONTROL等は取得せず計数のみ',
        provenance: 'manifest_tag_counts'
      }
    };
  }

  // A join job contains local file identities only. It is not proof of playback quality.
  function recJoinJob(owner) {
    const parts=owner._joinParts&&owner._joinParts.length?owner._joinParts:(owner.partsLog||[]);
    if(!parts.length)throw Error('JOIN_NO_PARTS');
    return {schema:'rsp.join.v1',tool:'RPLAY Stable Player v2.46.0',
      truncated:!!owner._joinTruncated,
      incomplete:!!((owner.segFails||0)+(owner.gapCount||0)+(owner.failedSaves||0)),
      parts:parts.map(p=>({file:p.file,bytes:p.bytes,...(p.sha256?{sha256:p.sha256}:{})})),
      ...(owner.audio&&owner.audio.partsLog&&owner.audio.partsLog.length?{audioRendition:{parts:owner.audio.partsLog.map(p=>({file:p.file,bytes:p.bytes}))}}:{})};
  }
