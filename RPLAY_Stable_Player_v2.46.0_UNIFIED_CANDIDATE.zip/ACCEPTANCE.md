# 現行受入 v2.46.0

CANDIDATE / NO_GO。旧手順は `history/v242_ACCEPTANCE.md`。
1. 拡張版/OS/ブラウザ/ZIP hash/日時を記録。
2. ページ実通信URLの署名・パラメータ順/重複/escapeと、取得URL・生成コマンドを照合。
3. Referer/Origin/UA・取得元・Cookie/Authorization有無の観測。request/tab/URL違いで情報を混ぜない。値を保存/ログ出力しない。
4. Cookie OFF/ON、SameSite/分離/redirect、401/403/404/410/429の診断表示を環境別に確認。ONだけで認証再現済みとは扱わない。
5. query継承OFF/ON、同一originかつ未署名の子URLへの不足親query付加（独自署名付き子URLと別originを変更しない）を確認。
6. 視聴ページURL（Nico/YouTube/Twitch/RPLAY）入力時に、直接メディアURLではない旨の案内が出ることを確認。
7. クラッシュ/再読込復帰後に、復帰前に確定保存されたパートが最終 `_info.json` と `_join_*.json` に保持されることを確認。
8. 保存済みパートに対する `rplay_dl.py --audit-files` の単体デコード監査および `rplay_join.py --mux-audio` の2トラックMP4結合を確認。
9. 既存の録画/変換（`mvhd`/`tkhd`/`mdhd` 0正規化後のMP4継続時間）/復旧/予約取消、実RPLAY/Windows/2GiB/長時間/native preview受入を継続。

fixture Cookieおよび合成M3U8は実サービス・実ブラウザ受入の代用としない。秘密を証拠へ転記しない。
