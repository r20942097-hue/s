# Development Handoff — RPLAY Stable Player v2.46.0 (`CANDIDATE_NO_GO`)

## 1. Release Overview
- **Artifact**: `RPLAY_Stable_Player_v2.46.0_UNIFIED_CANDIDATE.zip`
- **Version**: `2.46.0` (`CANDIDATE_NO_GO`)
- **Shared Core SHA-256**: `53ea2ddebf59b82a6aad5773710265e15e2506b9c5f475a3f33eda4739b7592a`
- **Validation**: `985 / 985` automated tests (`810` Node.js + `175` Python) + 3 standalone E2E scripts (`check_request_context_http.py`, `check_cdn404_decode.py`, `check_recording_during_scan.cjs`).

## 2. Key Architectural Additions in `v2.46.0`
- **Multi-Tool Command Generator (`src/media_inspect_core.js`, `src/media_inspect.js`)**:
  - `RspMediaInspect.commands(...)` now generates literal-quoted `N_m3u8DL-RE`, `yt-dlp`, and `streamlink` commands alongside `ffmpeg` and `curl`.
- **Master Variant & Rendition Enrichment (`src/media_catalog.js`)**:
  - `RspMediaCatalog.manifest()` extracts `frameRate`, `codecs`, `videoRange`, `subtitlesGroup`, `channels`, `language`, `defaultTrack`, `autoselect`, and `TYPE=SUBTITLES` rows.
- **SCTE-35 / CUE Ad Marker Diagnostics & `--ad-keyword` Filtering (`src/media_inspect_core.js`, `src/hls_transport.js`, `src/hls_transport.py`, `src/cli.py`)**:
  - Cross-language `scte35.indicatorTags` counting in `hls_parse` / `HLS.parse`, `adMarkers` in `inspectHls`, and `--ad-keyword <REGEX>` filtering (`adFilterEvidence`) in `rplay_dl.py`.
- **Dashboard Candidate -> URL Recording Bridge (`src/dashboard.js`, `src/background.js`)**:
  - Direct one-click population of `#urlRecInput` and `#urlRecLabel` from observed HLS candidates in `dashboard.html`.
- **Recovery UI TS Packet Verification (`src/recovery.html`, `src/recovery.js`)**:
  - Exposed `#verifyTs` checkbox in `recovery.html` and passed `{ verifyTs }` to `RspRecovery.recover(...)`.
- **CLI Two-Track Join & Acceptance Report Parity (`src/cli.py`, `scripts/acceptance_report.py`)**:
  - Added `--mux-audio-parts` in `rplay_dl.py` (`Dl.stop()`) and expanded `EVIDENCE_BLOCKS` in `scripts/acceptance_report.py`.

## 3. Remaining Unverified Boundaries (`CANDIDATE_NO_GO`)
- Real live-service endurance on RPLAY / Niconico / YouTube / Twitch, real Chrome extension installation, and Windows native filesystem behavior remain outside container simulation and require human acceptance observation per `ACCEPTANCE.md`.
