# v2.49.0 状況 — 2026-10-27 JST

CANDIDATE_NO_GO / remote_published=false
完了:
- **並行系統 v2.48.0 (addon max upgrade) の統合**: 上流 v2.47.0 系統から派生した「addon max upgrade」系統 v2.48.0（991テスト・crash復帰パート引継ぎ・`--audit-files` 実メディア品質監査・`--mux-audio` 2トラック無劣化MP4結合・Python CLI途切れ防止パリティ）の機能資産を、v2.48.0 統合ベース（mp4AutoHandoff + segment_store + preview_diag）へ非衝突マージ
  - `rplay_dl.py --join-files` スタンドアロン無劣結合CLI（同ディレクトリ/symlink/上書き fail-closed ガード）
  - `rplay_join.py` WebVTT 字幕検証 + mov_text 字幕トラック mux（digest検証 staging）
  - `hls_inspect_master` マスタープレイリスト構造監査（JS/Python完全鏡像・ゼロURI出力・HDR/high-FPS/orphan group 検出）
  - URL録画の広告除外キーワード正規表現フィルタ（`adFiltered` / `scte35` ステータスカウンタ追加）
- **segment_store Stage 2 実装**: 汎用 disk-backed 取得エンジン `src/segment_acquire.js`（`RspSegmentAcquire`）を新規作成
  - Stage 1 segment_store（保存プリミティブ）の上に明示候補のみを処理する取得エンジンを載せる
  - RAM常駐は「現処理中の1セグメント」のみ（受信完了即 `store.put` → 参照解放）
  - 再起動後は台帳（ledger JSON）と store メタで継続を判定（`restore()` / `continueFrom()`）
  - 任意時点で取消可能・取消時点のセグメントは disk に残る（自動削除しない・非破壊）
  - 既定 OFF・本番配線なし（Stage 3 で dashboard の候補一覧から「この候補を取得」を明示起動するまで現れない）
  - 紀律完全不変: 非破壊・fail-closed・虚偽零なし・ゼロシークレット・既定OFF
  - 単体試験 `tests/test_v2490_segment_acquire.cjs`（22件）追加 — happy path・RAM上限・cancel残留・restart継続・zero-secret scan・fail-closed各種・bounded acquisition・GAP skip・restore再構築・ledger永続化
- **dashboard policy 表示へ mp4AutoHandoff 列挙**: 実効policy行の外部設定列挙に `mp4Handover` と `mp4AutoHandoff` を追加
  - `background.js rspEffectivePolicy` の `external` オブジェクトへ両フラグを公開
  - `dashboard.js` policy 行の filter 配列へ両フラグを追加（null は「値なし」で非表示）
  - `test_v2380_start_policy.cjs` の期待値を更新
  - `test_v2480_integration_wiring.cjs` へ v2.49.0 統合検証2件を追加（policy表示とsegment_acquire配線）
- v2.48.0 までの全機能（mp4AutoHandoff・preview_diag・mp4_handoff・segment_store・クラッシュ復帰・`--audit-files`・`--mux-audio`・途切れ防止パリティ・CrossSite Compatibility v0.1.0・fMP4正規化・creator meta・BG予約確認・URL録画・広告除外）を完全維持
- 自動テスト合計 **1077 / 1077 PASS**（Node.js 898件 + Python 179件）

維持: v2.48のmp4AutoHandoff/segment_store Stage 1/preview_diag/mp4_handoff統合、v2.47のクラッシュ復帰・保存後監査・2トラック結合・途切れ防止、v2.47のCrossSite統合とfMP4継続時間正規化、v2.44の録画エラー・パート確定監査、v2.43のページ通信文脈、v2.49のaddon max機能（join-files/mux-audio/master audit/ad filter）。
未完: 汎用ブラウザ内動画DL（Stage 2 エンジンは実装済・Stage 3 UI統合は未実装）、全サービスの認証再現。
未受入: 実ブラウザCookie条件/実RPLAY/実Nico/Windows/2GiB/長時間/native preview進行/mp4AutoHandoff ON時の実変換/segment_acquire の実ネットワーク取得。

CANDIDATE_NO_GO 維持: 実サービス・実ブラウザの受入観察がUnit suiteの代用にならないため（紀律: fixtureとモックで契約を固定するに留める）。
