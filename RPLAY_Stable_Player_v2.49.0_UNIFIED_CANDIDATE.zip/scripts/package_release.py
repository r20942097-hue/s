"""Deterministic source bundle. Invoke only after scripts/validate.py has passed."""
from pathlib import Path
import sys, json, hashlib, zipfile
R=Path(__file__).resolve().parents[1]
def files():
    return sorted((p for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'} and p.name!='SHA256SUMS.json'),key=lambda x:x.relative_to(R).as_posix())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def release(out):
    ledger={p.relative_to(R).as_posix():digest(p) for p in files()}
    (R/'SHA256SUMS.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
    out=Path(out).resolve();out.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(out,'w') as z:
        for p in files()+[R/'SHA256SUMS.json']:
            name=p.relative_to(R).as_posix();info=zipfile.ZipInfo(name,date_time=(2026,10,26,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
            z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    with zipfile.ZipFile(out) as z:
        assert z.testzip() is None
        for name,d in ledger.items():assert hashlib.sha256(z.read(name)).hexdigest()==d,name
    print(json.dumps({'zip':str(out),'bytes':out.stat().st_size,'files':len(ledger),'zip_sha256':digest(out),'crc':'PASS','source_hashes':'PASS'},indent=2))
if __name__=='__main__':release(sys.argv[1] if len(sys.argv)>1 else '/mnt/data/RPLAY_Stable_Player_v2.49.0_UNIFIED_CANDIDATE.zip')
