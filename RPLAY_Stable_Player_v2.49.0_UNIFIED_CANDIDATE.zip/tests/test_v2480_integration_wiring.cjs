'use strict';
/* v2.48.0: 統合結線の回帰試験 — 並行系統(v2.44.0)モジュールをユーザー系統
   (v2.47.0)へ統合した際の結線を固定する。モジュール単体の挙動は
   test_v2480_mp4_handoff.cjs / test_v2480_segment_store.cjs /
   test_v2480_preview_diag.cjs が担う。本試験は「読み込み順・配線の存在・
   設定契約の一貫」を検査し、今後の改変で統合が静かに外れることを防ぐ。 */
const {test}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const ROOT=path.join(__dirname,'..');
const read=p=>fs.readFileSync(path.join(ROOT,p),'utf8');

test('v2.48.0 integration: Chrome offscreen.html preloads conversion libraries before offscreen.js',()=>{
  const html=read('rplay-stable-player-extension/offscreen.html');
  const order=['export_host.js','session_gate.js','sha256.js','mp4_codec_core.js','mp4_convert_core.js','libs/mux.min.js','mp4_browser_io.js','mp4_handoff.js','offscreen.js'];
  let last=-1;
  for(const name of order){
    const i=html.indexOf(`<script src="${name}"></script>`);
    a.ok(i>=0,`${name} must be referenced by offscreen.html`);
    a.ok(i>last,`${name} must appear after the previous script`);
    last=i;
  }
});

test('v2.48.0 integration: Firefox manifest background.scripts preload mp4_handoff before offscreen.js',()=>{
  const m=JSON.parse(read('rplay-stable-player-extension-firefox/manifest.json'));
  const sc=m.background.scripts;
  for(const name of ['sha256.js','mp4_codec_core.js','mp4_convert_core.js','libs/mux.min.js','mp4_browser_io.js','mp4_handoff.js'])
    a.ok(sc.includes(name),`${name} must be in Firefox background.scripts`);
  a.ok(sc.indexOf('mp4_handoff.js')<sc.indexOf('offscreen.js'),'mp4_handoff.js loads before offscreen.js');
  a.ok(sc.indexOf('export_host.js')<sc.indexOf('offscreen.js'),'export_host.js loads before offscreen.js');
});

test('v2.48.0 integration: offscreen host wires MP4_HANDOFF with non-destructive guards and bounded evidence',()=>{
  const post=read('src/offscreen_post.js');
  a.match(post,/RspMp4Handoff\.create\(/,'MP4_HANDOFF host factory');
  a.match(post,/settings: function \(\) \{ return \{ enabled: SET\.mp4AutoHandoff === true \}; \}/,'enabled flag mirrors the setting');
  a.match(post,/handoff: function \(file, name\) \{ return EXPORT_HOST\.save\(file, name\); \}/,'handoff goes through the export journal');
  a.match(post,/excludeNames: function \(\) \{ try \{ return EXPORT_HOST\.inFlightNames\(\); \}/,'in-flight staging parts are excluded');
  a.match(post,/case 'mp4-handoff\.sweep':/,'startup sweep message case');
  a.match(post,/case 'mp4-handoff\.status':/,'status message case');
  a.match(post,/MP4_HANDOFF\.enqueue\(\{ trigger: 'bg-stop', parts: handoffNames \}\)/,'bg-stop enqueue');
  a.match(post,/out\.mp4Handoff = MP4_HANDOFF \? MP4_HANDOFF\.status\(\) : null;/,'status exposes bounded handoff evidence');
});

test('v2.48.0 integration: background keeps offscreen alive during handoff and triggers the startup sweep',()=>{
  const bg=read('src/background.js');
  a.match(bg,/st\.mp4Handoff && \(st\.mp4Handoff\.busy \|\| st\.mp4Handoff\.queued\)/,'offscreen close guard considers handoff activity');
  a.match(bg,/type:'mp4-handoff\.sweep'/,'recoverExports triggers the startup sweep');
});

test('v2.48.0 integration: dashboard settings contract accepts both mp4Handover and mp4AutoHandoff flags',()=>{
  const st=read('src/dashboard_settings.js');
  a.match(st,/flags=\['autoStartAllowed','enabled','follow','recAudio','inheritQuery','mp4Handover','mp4AutoHandoff'\]/,'flag list');
  a.match(st,/mp4Handover:false,mp4AutoHandoff:false/,'defaults are OFF');
  const pre=read('src/offscreen_pre.js');
  a.match(pre,/mp4AutoHandoff: false/,'offscreen SET default is OFF');
  a.match(pre,/if \(typeof s\.mp4AutoHandoff === 'boolean'\) SET\.mp4AutoHandoff = s\.mp4AutoHandoff;/,'offscreen applies boolean settings');
  const bg=read('src/background.js');
  a.match(bg,/['follow','recAudio','inheritQuery','mp4AutoHandoff']\]/,'rec.start propagates mp4AutoHandoff with the other external flags');
  const html=read('src/dashboard.html');
  a.match(html,/<input id="mp4AutoHandoff" type="checkbox">/,'dashboard exposes the toggle');
  const js=read('src/dashboard.js');
  a.match(js,/keys=\['autoStartAllowed','enabled','follow','recAudio','inheritQuery','mp4Handover','mp4AutoHandoff'\]/,'dashboard keys list covers both flags');
});

test('v2.48.0 integration: mp4_convert page keeps session guidance and gains preview diagnostics',()=>{
  const page=read('src/mp4_convert.js');
  a.match(page,/stopPreviewWatch\(\);/,'clearURL stops the watch clock');
  a.match(page,/globalThis\.RspPreviewDiag/,'diagnostics module is consulted');
  a.match(page,/rspSessionRender\(await rspSessionManifestRead\(\)\)/,'v2.39.0 session guidance stays wired');
  const html=read('src/mp4_convert.html');
  a.match(html,/<script src="preview_diag\.js"><\/script><script src="mp4_convert\.js"><\/script>/,'preview_diag loads before the page script');
  a.match(html,/id="session-parts"/,'session parts list survives the integration');
});

test('v2.48.0 integration: segment_store stays a standalone save primitive (no acquisition path coupling)',()=>{
  const src=read('src/segment_store.js');
  a.doesNotMatch(src,/fetch\(|XMLHttpRequest|https?:\/\//,'store must not touch the network');
  a.match(src,/function create\(deps\)/,'factory contract');
  for(const loc of ['src/segment_store.js','rplay-stable-player-extension/segment_store.js','rplay-stable-player-extension-firefox/segment_store.js','segment_store.js'])
    a.ok(fs.existsSync(path.join(ROOT,loc)),`${loc} derived copy exists`);
});

test('v2.48.0 integration: build and validate derived-copy lists cover all three integrated modules',()=>{
  const build=read('scripts/build.py');
  for(const name of ['mp4_handoff.js','segment_store.js','preview_diag.js'])
    a.ok(build.split(`'${name}'`).length-1>=2,`build.py copies ${name} into extension and root loops`);
  const val=read('scripts/validate.py');
  for(const name of ['mp4_handoff.js','segment_store.js','preview_diag.js'])
    a.ok(val.includes(`'${name}'`),`validate.py guards ${name} as a derived copy`);
});

test('v2.49.0 integration: dashboard policy line enumerates mp4Handover and mp4AutoHandoff',()=>{
  const dash=read('src/dashboard.js');
  a.match(dash,/mp4Handover.*mp4AutoHandoff|mp4AutoHandoff.*mp4Handover/,'both flags listed in the policy filter array');
  a.match(dash,/policy\.external\[k\]!==null/,'null-skip filter unchanged');
  // background.js must include both flags in rspEffectivePolicy's external object
  const bg=read('src/background.js');
  a.match(bg,/mp4Handover:\(d&&typeof d\.mp4Handover==='boolean'\)\?d\.mp4Handover:null/,'bg exposes mp4Handover');
  a.match(bg,/mp4AutoHandoff:\(d&&typeof d\.mp4AutoHandoff==='boolean'\)\?d\.mp4AutoHandoff:null/,'bg exposes mp4AutoHandoff');
});

test('v2.49.0 integration: segment_acquire Stage 2 module ships as a derived copy (default OFF, no production wiring)',()=>{
  for(const loc of ['src/segment_acquire.js','rplay-stable-player-extension/segment_acquire.js','rplay-stable-player-extension-firefox/segment_acquire.js','segment_acquire.js'])
    a.ok(fs.existsSync(path.join(ROOT,loc)),`${loc} derived copy exists`);
  const sa=read('src/segment_acquire.js');
  a.match(sa,/function create\(deps\)/,'factory contract');
  a.match(sa,/STORE_REQUIRED|FETCHER_REQUIRED|PLAYLIST_PARSER_REQUIRED/,'fail-closed dependency guards');
  a.doesNotMatch(sa,/fetch\(|XMLHttpRequest/,'acquire engine must not call fetch directly — caller injects fetcher');
  // Default OFF: no automatic acquisition — start() requires explicit candidate
  a.match(sa,/INVALID_CANDIDATE/,'start requires explicit candidate');
  // Non-destructive: discard() must not delete on-disk segments
  a.match(sa,/discard\(id\)/,'discard method present');
  a.doesNotMatch(sa,/await store\.sweep\(\)|await store\.remove\(/,'discard does not invoke on-disk deletion');
  // build.py and validate.py include segment_acquire.js
  a.ok(read('scripts/build.py').includes("'segment_acquire.js'"),'build.py copies segment_acquire.js');
  a.ok(read('scripts/validate.py').includes("'segment_acquire.js'"),'validate.py guards segment_acquire.js');
});
