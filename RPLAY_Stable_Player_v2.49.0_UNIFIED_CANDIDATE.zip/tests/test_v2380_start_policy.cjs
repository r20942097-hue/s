'use strict';
const {test}=require('node:test'),a=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const base=path.join(__dirname,'..');
const id='a'.repeat(24),other='b'.repeat(24);
/* ---- v2.38.0: 開始理由と実効policy(表示専用) ----
   rec.start成功時に自動/手動と外部設定適用を記録し、monitor.statusが
   policy/startとして返す。SW再起動はchrome.storage.sessionからの復元で模擬する。 */
function harness(store,sessionData,hostReplies){
  const h={listener:null,hostMessages:[],sessionWrites:[],sessionData:sessionData?structuredClone(sessionData):null};
  const api={runtime:{id:'rsp',lastError:null,getURL:n=>'chrome-extension://rsp/'+n,
      onMessage:{addListener:f=>h.listener=f},onStartup:{addListener:()=>{}},onInstalled:{addListener:()=>{}},
      getContexts:async()=>[{}],
      sendMessage:async m=>{h.hostMessages.push(structuredClone(m));return structuredClone(hostReplies&&hostReplies[m.type]||{ok:true});}},
    offscreen:{createDocument:async()=>{},closeDocument:async()=>{}},
    downloads:{onChanged:{addListener:()=>{}}},alarms:{create:()=>{},clear:()=>{},onAlarm:{addListener:()=>{}}},
    action:{setBadgeText:()=>{}},tabs:{query:async()=>[],sendMessage:async()=>{}}};
  api.storage={local:{get:(k,cb)=>cb(structuredClone(store)),set:(o,cb)=>{Object.assign(store,structuredClone(o));if(cb)cb();}},
    session:{get:(k,cb)=>cb(h.sessionData?{rsp_last_start:h.sessionData}:{}),set:(o,cb)=>{h.sessionWrites.push(structuredClone(o));if(cb)cb();}}};
  const c=vm.createContext({chrome:api,console,Promise,Date,setTimeout:()=>1,clearTimeout:()=>{},
    RspExportManager:{create:()=>({pending:async()=>false,status:async()=>({verified:0}),offer:async()=>({ok:true}),changed:async()=>{},reconcile:async()=>{}})}});
  vm.runInContext(fs.readFileSync(path.join(base,'src/creator_registry.js'),'utf8'),c);
  vm.runInContext(fs.readFileSync(path.join(base,'src/background.js'),'utf8'),c);
  h.message=(msg,sender)=>new Promise(res=>{const keep=h.listener(msg,sender,res);if(keep!==true)res(null);});
  return h;
}
const content={id:'rsp',url:'https://rplay.live/live/'+id,frameId:0,tab:{id:1}};
const dash={id:'rsp',url:'chrome-extension://rsp/dashboard.html'};
const recordingSt=oid=>({'rec.status':{recording:true,oid:oid,state:'RUN',medium:'ts'}});

test('v2.38.0 manual start records its reason and monitor.status exposes it',async()=>{
  const h=harness({},null,recordingSt(id));
  const r=await h.message({type:'rec.start',payload:{oid:id}},content);
  a.equal(r.ok,true);
  a.equal(h.sessionWrites.length,1);
  const saved=h.sessionWrites[0].rsp_last_start;
  a.equal(saved.oid,id);a.equal(saved.reason,'manual');a.equal(saved.appliedExternal,false);
  a.ok(Number.isInteger(saved.at)&&saved.at>0);
  const s=await h.message({type:'monitor.status'},dash);
  a.equal(s.ok,true);
  a.deepEqual(JSON.parse(JSON.stringify(s.start)),{reason:'manual',at:saved.at,appliedExternal:false});
});
test('v2.38.0 automatic start is labeled auto and carries the applied external policy',async()=>{
  const h=harness({rsp_dashboard_defaults:{enabled:true,follow:false}},null,recordingSt(id));
  const r=await h.message({type:'rec.start',payload:{oid:id,automatic:true}},content);
  a.equal(r.ok,true);
  const saved=h.sessionWrites[0].rsp_last_start;
  a.equal(saved.reason,'auto');a.equal(saved.appliedExternal,true);
  a.equal(h.hostMessages[0].payload.settings.follow,false); /* 外部設定が開始へ反映 */
  const s=await h.message({type:'monitor.status'},dash);
  a.equal(s.start.reason,'auto');a.equal(s.start.appliedExternal,true);
});
test('v2.38.0 denied automatic start writes no reason and the policy line reports the block',async()=>{
  const h=harness({rsp_dashboard_defaults:{autoStartAllowed:false}},null,recordingSt(id));
  const r=await h.message({type:'rec.start',payload:{oid:id,automatic:true}},content);
  a.deepEqual(JSON.parse(JSON.stringify(r)),{ok:false,error:'AUTO_START_DISABLED'});
  a.equal(h.sessionWrites.length,0);
  const s=await h.message({type:'monitor.status'},dash);
  a.equal(s.policy.autoStartAllowed,false);
  a.deepEqual(JSON.parse(JSON.stringify(s.start)),{reason:'unknown'}); /* host側の録画だが本経路の開始ではない */
});
test('v2.38.0 monitor.status reports the effective policy merged from saved settings',async()=>{
  const h=harness({rsp_dashboard_defaults:{enabled:true,follow:false,recAudio:true,splitMin:30}},null,recordingSt(id));
  const s=await h.message({type:'monitor.status'},dash);
  a.deepEqual(JSON.parse(JSON.stringify(s.policy)),{autoStartAllowed:true,externalApplied:true,external:{follow:false,recAudio:true,inheritQuery:null,mp4Handover:null,mp4AutoHandoff:null,splitMin:30}});
  const h2=harness({},null,recordingSt(id)); /* 未保存=既定値 */
  const s2=await h2.message({type:'monitor.status'},dash);
  a.deepEqual(JSON.parse(JSON.stringify(s2.policy)),{autoStartAllowed:true,externalApplied:false,external:{follow:null,recAudio:null,inheritQuery:null,mp4Handover:null,mp4AutoHandoff:null,splitMin:null}});
});
test('v2.38.0 invalid saved settings keep starts fail-closed while status answers unavailable policy',async()=>{
  const h=harness({rsp_dashboard_defaults:{follow:'yes'}},null,recordingSt(id));
  a.equal((await h.message({type:'rec.start',payload:{oid:id}},content)).error,'START_SETTINGS_UNAVAILABLE');
  const s=await h.message({type:'monitor.status'},dash);
  a.equal(s.ok,true);
  a.deepEqual(JSON.parse(JSON.stringify(s.policy)),{unavailable:true});
});
test('v2.38.0 SW restart restores the last start reason from session storage',async()=>{
  const h1=harness({},null,recordingSt(id));
  await h1.message({type:'rec.start',payload:{oid:id,automatic:true}},content);
  const saved=h1.sessionWrites[0].rsp_last_start;
  const h2=harness({},saved,recordingSt(id)); /* 新しいcontext=session復元のみ */
  await new Promise(setImmediate);
  const s=await h2.message({type:'monitor.status'},dash);
  a.deepEqual(JSON.parse(JSON.stringify(s.start)),{reason:'auto',at:saved.at,appliedExternal:false});
});
test('v2.38.0 a different creator recording reports unknown instead of a stale reason',async()=>{
  const h=harness({},null,recordingSt(other));
  await h.message({type:'rec.start',payload:{oid:id,automatic:true}},content);
  const s=await h.message({type:'monitor.status'},dash);
  a.deepEqual(JSON.parse(JSON.stringify(s.start)),{reason:'unknown'});
});
test('v2.38.0 draining recordings keep the start reason and idle status carries none',async()=>{
  const h=harness({},null,{'rec.status':{recording:false,draining:true,oid:id,state:'DRAINING'}});
  await h.message({type:'rec.start',payload:{oid:id}},content);
  a.equal((await h.message({type:'monitor.status'},dash)).start.reason,'manual');
  const h2=harness({},null,{'rec.status':{recording:false,oid:'',state:'IDLE'}});
  a.equal((await h2.message({type:'monitor.status'},dash)).start,null);
});
test('v2.38.0 dashboard wiring renders the policy and start reason lines',()=>{
  const js=fs.readFileSync(path.join(base,'src/dashboard.js'),'utf8');
  a.ok(js.includes("$('policyLine')"));
  a.ok(js.includes("$('startLine')"));
  a.ok(js.includes('s.policy.externalApplied'));
  const html=fs.readFileSync(path.join(base,'src/dashboard.html'),'utf8');
  a.ok(html.includes('id="policyLine"'));
  a.ok(html.includes('id="startLine"'));
  const bg=fs.readFileSync(path.join(base,'src/background.js'),'utf8');
  a.ok(bg.includes('storageGetBounded'));
  a.ok(bg.includes('rsp_last_start'));
});
