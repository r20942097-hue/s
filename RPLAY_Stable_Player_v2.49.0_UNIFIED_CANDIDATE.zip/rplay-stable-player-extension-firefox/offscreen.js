/* =====================================================================
   RPLAY Stable Player — offscreen recording host (v2.0 Step2)
   =====================================================================
   このファイルは scripts/build.py が生成します(手で編集しない)。
     offscreen.js = src/offscreen_pre.js
                  + user.js の「RSP RECORDING CORE」領域(そのまま同期)
                  + src/offscreen_post.js
   役割: 拡張機能のoffscreen document内で録画コアを実行する。
   - Service Workerは30秒程度で停止するが、offscreen documentは
     生成後は生存し続ける(長時間処理の受け皿として公式に想定された機能)。
   - コアはuser.jsと同一文字列(RSP_RECENV_HOOKでRECENVだけ差し替え)。
   - chrome.runtime が無い環境(通常ページ)で読み込まれた場合は
     試験ブリッジ(window.__RSP_OFFSCREEN_TEST__)を公開する(E2E用)。
   ===================================================================== */
(function () {
  'use strict';

  const HAS_EXT = typeof chrome !== 'undefined' && !!(chrome.runtime && chrome.runtime.id && chrome.runtime.sendMessage);

  const CONTROL_GATE = RspSessionGate.create(() => crypto.randomUUID(), () => {
    const raw=localStorage.getItem('rsp_control_epoch_v1');
    const old=raw===null?0:Number(raw);
    if(!Number.isSafeInteger(old)||old<0||old>=Number.MAX_SAFE_INTEGER)throw Error('CONTROL_EPOCH_INVALID');
    const next=old+1;localStorage.setItem('rsp_control_epoch_v1',String(next));return next;
  });
  /* ---- メッセージアダプタ(offscreen→SW/テストブリッジ) ----
     拡張: chrome.runtime.sendMessage(片方向・応答不要のイベント)
     ページ: window.postMessage(rspOffscreenEvt) を試験側が受け取る */
  const EVT_LOG = [];
  const MSG = {
    send: function (obj) {
      const binding=CONTROL_GATE.binding();
      if(binding && !obj.sessionId && ['rec.event','rec.stopped','perm.request'].includes(obj.type)) obj={...obj,sessionId:binding.sessionId,epoch:binding.epoch,oid:binding.oid};
      EVT_LOG.push(obj);
      if (EVT_LOG.length > 400) EVT_LOG.shift();
      /* v2.1.0 Step3: Firefox Event Pageでは同一背景ウィンドウ内の__RSP_SW_SINK__へ直接配送 */
      if (typeof window !== 'undefined' && typeof window.__RSP_SW_SINK__ === 'function') {
        try { window.__RSP_SW_SINK__(obj); return; } catch (e) {}
      }
      if (HAS_EXT) {
        try { const p = chrome.runtime.sendMessage(obj); if (p && p.catch) p.catch(function () {}); } catch (e) {}
      } else {
        try { window.postMessage({ rspOffscreenEvt: true, msg: obj }, '*'); } catch (e) {}
      }
    }
  };

  /* ---- 実行状態 ---- */
  const STATE = {
    recorder: null,      // Recorder コアインスタンス(同時に1件 — 二重録画の構造的排除)
    pageUrl: '',         // UIタブのURL(相対m3u8解決の基準)
    creatorName: '',
    customM3u8: '',
    customFlv: '',
    urlMode: false,      // v2.40.0: 任意HLS URL録画セッション(dashboard経由)
    urlSource: '',       // v2.40.0: 録画中URLの表示用ラベル(origin+path・クエリなし)
    handleOk: false,
    handleName: '',
    recoveredParts: []   // v2.1.0(設計書§4.3): OPFS退避から引き継いだ未フラッシュ復旧記録
  };
  const SET = {
    inheritQuery: false, follow: true, flv: true, backlog: true, infoJson: false, notify: true,
    bestQ: true, recAudio: false, nameTpl: '', csv: false, remind: 'both', splitMin: 0,
    opfsBackup: true,    // v2.1.0(設計書§4.3): パートクローズごとのOPFS複製退避(最新2パート・既定ON)
    mp4AutoHandoff: false // v2.48.0(統合): BG停止後に残ったTSパートのMP4自動変換・引渡し(既定OFF・現行動作維持)
  };
  const TITLEC = { base: '', cur: '' };
  const LOGTAIL = [];

  function applySettings(s) {
    if (!s) return;
    if (typeof s.inheritQuery === 'boolean') SET.inheritQuery = s.inheritQuery;
    if (typeof s.follow === 'boolean') SET.follow = s.follow;
    if (typeof s.flv === 'boolean') SET.flv = s.flv;
    if (typeof s.backlog === 'boolean') SET.backlog = s.backlog;
    if (typeof s.infoJson === 'boolean') SET.infoJson = s.infoJson;
    if (typeof s.notify === 'boolean') SET.notify = s.notify;
    if (typeof s.bestQ === 'boolean') SET.bestQ = s.bestQ;
    if (typeof s.recAudio === 'boolean') SET.recAudio = s.recAudio;
    if (typeof s.nameTpl === 'string') SET.nameTpl = s.nameTpl;
    if (typeof s.csv === 'boolean') SET.csv = s.csv;
    if (typeof s.remind === 'string') SET.remind = s.remind;
    if (typeof s.splitMin === 'number' && s.splitMin >= 0) SET.splitMin = s.splitMin;
    if (typeof s.opfsBackup === 'boolean') SET.opfsBackup = s.opfsBackup;
    if (typeof s.mp4AutoHandoff === 'boolean') SET.mp4AutoHandoff = s.mp4AutoHandoff; /* v2.48.0(統合) */
  }

  /* ---- OPFS保存+サルベージ要求(メモリモード保存のoffscreen実装) ----
     パート/情報JSON/CSVのBlobを一度OPFSへ確定書き込みしてからSWへ
     'salvage'を送る。SWは同一originのOPFSから読みchrome.downloadsで
     ユーザーのダウンロードへ書き出す。offscreenがサルベージ前に
     異常終了してもOPFSのファイルは残る(次回SW起動時のsweepで回収)。 */
  function osSafeName(n) {
    return String(n || 'part.bin').replace(/[\\/:*?"<>|]/g, '_').slice(0, 180) || 'part.bin';
  }
  function sendExport(msg) {
    if (typeof window !== 'undefined' && typeof window.__RSP_SW_SINK__ === 'function') {
      return new Promise(resolve => window.__RSP_SW_SINK__(msg, resolve));
    }
    if (HAS_EXT) return chrome.runtime.sendMessage(msg);
    return Promise.resolve({ok:false,error:'NO_EXPORT_ROUTER'});
  }
  const EXPORT_HOST = RspExportHost.create({navigator, URL, crypto, send:sendExport});
  function opfsSaveAndSalvage(blob, name) { const p = EXPORT_HOST.save(blob, name); p.catch(() => {}); return p; }

  /* ---- v2.1.0(設計書§4.3): クラッシュ時のOPFS最新2パート複製退避と復旧記録 ---- */
  const BACKUP_META_KEY = 'rsp_backup_meta_v21';
  const BACKUP_DIRTY_KEY = 'rsp_backup_dirty_v21';
  function readBackupMeta() {
    try {
      const raw = localStorage.getItem(BACKUP_META_KEY);
      const arr = raw ? JSON.parse(raw) : [];
      return Array.isArray(arr) ? arr : [];
    } catch (e) { return []; }
  }
  function writeBackupMeta(arr) {
    try {
      if (!arr || !arr.length) localStorage.removeItem(BACKUP_META_KEY);
      else localStorage.setItem(BACKUP_META_KEY, JSON.stringify(arr.slice(-2)));
    } catch (e) {}
  }
  let backupChain = Promise.resolve();
  function opfsBackupPart(blob,name,meta) {
    const task=backupChain.then(()=>writeBackupPart(blob,name,meta));backupChain=task.catch(()=>{});return task;
  }
  async function writeBackupPart(blob, name, meta) {
    if (!SET.opfsBackup || !blob) return;
    const safe = osSafeName(name);
    const entry = Object.assign({ file: safe, backedUpAt: new Date().toISOString() }, meta || {});
    const list = readBackupMeta();
    list.push(entry);
    const keep = list.slice(-2);
    const keepNames = new Set(keep.map(function (x) { return osSafeName(x.file); }));

    try {
      const root = await navigator.storage.getDirectory();
      const dir = await root.getDirectoryHandle('rsp_backup', { create: true });
      const fh = await dir.getFileHandle(safe, { create: true });
      const w = await fh.createWritable();
      await w.write(blob);
      await w.close();
      writeBackupMeta(keep);
      /* 容量制限のため最新2パートのみ保持し、古い退避ファイルを削除 */
      for await (const [fname, h] of dir.entries()) {
        if (h.kind === 'file' && !keepNames.has(fname)) {
          try { await dir.removeEntry(fname); } catch (e2) {}
        }
      }
    } catch (e) {}
  }
  function markBackupClean() {
    try { localStorage.removeItem(BACKUP_DIRTY_KEY); } catch (e) {}
  }
  function checkBackupRecovery() {
    try {
      const dirty = localStorage.getItem(BACKUP_DIRTY_KEY) === '1';
      const leftover = readBackupMeta();
      if (dirty && leftover.length > 0) {
        STATE.recoveredParts = leftover.map(function (x) {
          return Object.assign({}, x, { recoveredAt: new Date().toISOString() });
        });
      } else {
        STATE.recoveredParts = [];
      }
      localStorage.setItem(BACKUP_DIRTY_KEY, '1');
    } catch (e) { STATE.recoveredParts = []; }
  }

  /* ---- RECENV差し替え実装(v2.0 Step2の核心) ----
     コアがページ環境に依存していた全機能をoffscreen向けに置換する。
     - storage: offscreen文書のlocalStorage(生成し直しても残る拡張origin分)
     - download: OPFS確定書き込み→SWへsalvage(フォルダ直書きはコアが
       dirHandle経由で行うため、ここはメモリ保存モードの退避路のみ)
     - notify: SWがchrome.notificationsでOS通知(ページ権限不要)
     - title: タイトル表示はUIタブへイベント中継(●REC表示)
     - onUnload: offscreenはブラウザのアンロード対象外のため無効化 */
  const RSP_RECENV_HOOK = {
    pageUrl: function () { return STATE.pageUrl || 'https://rplay.live/'; },
    storageGet: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    storageSet: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} },
    storageDel: function (k) { try { localStorage.removeItem(k); } catch (e) {} },
    download: function (blob, name) { return opfsSaveAndSalvage(blob, name); },
    partByteLimit: 512 * 1048576,
    notify: function (title, body) { MSG.send({ type: 'rec.notify', title: title, body: body }); },
    getTitle: function () { return TITLEC.base; },
    setTitle: function (t) { TITLEC.cur = t; MSG.send({ type: 'rec.event', kind: 'title', title: t }); },
    onUnload: function () {},
    offUnload: function () {},
    perfHeap: function () {
      try { if (performance.memory && performance.memory.usedJSHeapSize) return performance.memory.usedJSHeapSize; } catch (e) {}
      return null;
    },
    testHooks: function () { try { return window.__RSP_TEST || {}; } catch (e) { return {}; } },
    backupPart: function (blob, name, meta) { return opfsBackupPart(blob, name, meta); },
    recoveredParts: function () { return STATE.recoveredParts ? STATE.recoveredParts.slice() : []; },
    /* v2.7.0(A-02/A-03): 認証・canary証拠の供給(offscreenホスト版)。
       ページ側のRspAuthはここから直接参照できないため、content側から
       STATE.authStatsへ中継された計数を使う(未中継ならundefined — 証拠ブロック
       を出さない。虚偽のゼロを捏造しない契約)。canaryはoffscreenが独自に
       live/playを呼ばないため常に未供給(ページ側の録画情報JSONに残る)。 */
    authStats: function () { return buildHostAuthStats(); },
    canaryEvidence: function () { return STATE.canaryEvidence || undefined; },
    butterToken: function () { try { return butterToken(); } catch (e) { return Promise.resolve(''); } },
    /* Worker生成: MV3拡張ページのCSPはBlob URL Workerをブロックするため、
       実ファイル(rec_worker.js)のWorkerを使う(プロトコルはコアと同一)。
       失敗時はnull → コアがsetInterval/同期検証へフォールバック。 */
    makeWorker: function (src) {
      if (HAS_EXT) {
        try { return new Worker(chrome.runtime.getURL('rec_worker.js')); } catch (e) { return null; }
      }
      try { return new Worker(URL.createObjectURL(new Blob([src], { type: 'application/javascript' }))); }
      catch (e) { return null; }
    },
    /* v2.39.0: 自動開始の共通policy(offscreen版 — 追跡再開/FLV代替のgate)。
       この文書は拡張ページのためchrome.storage.localを直接読める(3秒有界・
       BGのdashboardDefaultsと同じ検証)。拒否=autoStartAllowed:false、
       読めない/不正=不明(fail-closed: 再開しない)。手動開始は参照しない。 */
    autoPolicy: function () {
      return new Promise(function (resolve) {
        let done = false;
        const finish = function (v) { if (!done) { done = true; resolve(v); } };
        try {
          if (!HAS_EXT || !chrome.storage || !chrome.storage.local || typeof chrome.storage.local.get !== 'function')
            return finish({ verdict: 'allowed' });
          const bound = (function () { try { const v = Number((typeof window !== 'undefined' && window.__RSP_TEST && window.__RSP_TEST.settingsReadMs)); return Number.isFinite(v) && v > 0 ? v : 3000; } catch (e) { return 3000; } })();
          let timer = 0;
          if (typeof setTimeout === 'function') { try { timer = setTimeout(function () { finish({ verdict: 'unavailable' }); }, bound); } catch (e) { timer = 0; } }
          chrome.storage.local.get('rsp_dashboard_defaults', function (v) {
            if (timer) { try { clearTimeout(timer); } catch (e) {} }
            if (chrome.runtime.lastError || !v || typeof v !== 'object') return finish({ verdict: 'unavailable' });
            const d = v.rsp_dashboard_defaults;
            if (d !== undefined && (!d || typeof d !== 'object' || Array.isArray(d) ||
              ['autoStartAllowed', 'enabled', 'follow', 'recAudio', 'inheritQuery', 'mp4Handover', 'mp4AutoHandoff'].some(function (k) { return d[k] !== undefined && typeof d[k] !== 'boolean'; }) || /* v2.48.0(統合): mp4AutoHandoff 追加 */
              (d.splitMin !== undefined && (typeof d.splitMin !== 'number' || !Number.isFinite(d.splitMin) || d.splitMin < 0 || d.splitMin > 1440))))
              return finish({ verdict: 'unavailable' });
            finish({ verdict: (d && d.autoStartAllowed === false) ? 'denied' : 'allowed' });
          });
        } catch (e) { finish({ verdict: 'unavailable' }); }
      });
    },
    /* v2.39.0: セッション終了フック — BG停止後のMP4引渡し台帳(rsp_last_session)を
       chrome.storage.localへ書く。秘密なし(名前/容量/トラック/結合job)。
       64KiB上限・書込失敗は静かに諦める(派生データ・失敗許容)。 */
    sessionEnded: function (rec) {
      if (!HAS_EXT || !chrome.storage || !chrome.storage.local || typeof chrome.storage.local.set !== 'function') return Promise.resolve(false);
      return new Promise(function (resolve) {
        try {
          const m = rspSessionManifest(rec);
          if (!m) return resolve(false);
          chrome.storage.local.set({ rsp_last_session: m }, function () { resolve(!chrome.runtime.lastError); });
        } catch (e) { resolve(false); }
      });
    }
  };

  /* ---- v2.39.0: セッション終了台帳の構築(MP4引渡し用・秘密なし) ----
     停止した録画セッションのパート一覧(名前/容量/トラック)と結合job(順序契約)を
     保存する。変換画面はこれを使って「どのファイルを選べばよいか」を案内する
     (ブラウザーのセキュリティモデル上、ファイル本体はユーザーが選ぶ)。 */
  function rspSessionManifest(rec) {
    try {
      if (!rec || typeof rec !== 'object') return null;
      const parts = [];
      const collect = function (r, track) {
        if (!r) return;
        const log = Array.isArray(r.partsLog) ? r.partsLog : [];
        for (const p of log) parts.push({ name: String(p && p.file || '').slice(0, 180), bytes: Number(p && p.bytes) || 0, track: track });
        if (r.partOpen) parts.push({ name: String(r.partName || '').slice(0, 180), bytes: Number(r.bytes) || 0, track: track });
      };
      collect(rec, 'video'); collect(rec.audio, 'audio');
      let job = null;
      try { job = recJoinJob(rec); } catch (e) { job = null; } /* 0パート等はnull */
      const m = { version: 1, at: Date.now(), oid: String(rec.id || '').toLowerCase(), creatorName: String(STATE.creatorName || '').slice(0, 200), title: String(TITLEC.base || '').slice(0, 200), urlSession: STATE.urlMode === true, sourceUrl: STATE.urlMode === true ? String(STATE.urlSource || '').slice(0, 500) : undefined, parts: parts.slice(0, 512), truncated: parts.length > 512, job: job };
      if (JSON.stringify(m).length > 65536) { m.parts = m.parts.slice(0, 256); m.truncated = true; m.job = null; }
      if (JSON.stringify(m).length > 65536) { m.parts = m.parts.slice(0, 64); m.job = null; }
      return m;
    } catch (e) { return null; }
  }

  /* =====================================================================
     以下、コアが参照するambient依存(ページ実装のoffscreen版)。
     user.jsではページ側にある API_BASE/CDN_BASE/RspAuth/authedJson/
     resolveMemberLive/resolveScheduleInfo/fetchSchedulesFor/memberFailHint/
     liveBaseLabel/_memberResolveCache をここで再定義する。
     ===================================================================== */
  /* API_BASE は録画コア領域内で定義される(__RSP_API_BASE 試験フック付き)。
     CDN_BASE はコアの外(ambient)のためここで定義する。 */
  const CDN_BASE = 'https://livestream.rplay.live/live/';

  /* 認証ホルダ: UIタブが rec.start / token.update で渡した自分のトークンを保持。
     offscreenではページのlocalStorageを読めないため、401時は token.stale イベントで
     UIタブへ再取得を促す(認証回避ではなく自分の会話の受け渡しのみ)。 */
  const BUTTER_KEY = 'S%M@#H#B(!@()a2@';
  const BUTTER_SALT = 'QWI@(!WAS)Dj1AA(!@*DJ#@$@~1)P';
  let _butterCache = { hex: '', at: 0 };
  function hexU8(u8) {
    let s = '';
    for (let i = 0; i < u8.length; i++) s += ('0' + u8[i].toString(16)).slice(-2);
    return s;
  }
  async function butterToken() {
    const now = Date.now();
    if (_butterCache.hex && now - _butterCache.at < 6 * 60 * 1000) return _butterCache.hex;
    try {
      const enc = new TextEncoder();
      const ts = String(Math.floor(now / 1000 / 360));
      const iv = enc.encode(ts.padStart(16, '0'));
      const clear = new Uint8Array(BUTTER_SALT.length + 17 + ts.length);
      let o = 0;
      clear.set(enc.encode(BUTTER_SALT), o); o += BUTTER_SALT.length;
      clear.set(enc.encode('https://rplay.live'), o); o += 17;
      clear.set(enc.encode(ts), o);
      const key = await crypto.subtle.importKey('raw', enc.encode(BUTTER_KEY), { name: 'AES-CBC' }, false, ['encrypt']);
      const cipher = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-CBC', iv: iv }, key, clear));
      _butterCache = { hex: hexU8(cipher), at: now };
      AUTH._butterSends = (AUTH._butterSends || 0) + 1;
      return _butterCache.hex;
    } catch (e) { return ''; }
  }
  function rspCanaryCheck(info) {
    const expected = ['bytePlusPlaybackUrl', 'playUrl', 'streamState',
      'accessible', 'tierHashes', 'useRplayStreamServer', 'allowAnonymous', 'title'];
    if (!info || typeof info !== 'object' || Array.isArray(info) || !Object.keys(info).length)
      return { result: 'unreachable', observedKeys: [], knownKeys: [] };
    const observed = Object.keys(info).map(String);
    const known = observed.filter(function (k) { return expected.indexOf(k) !== -1; });
    return { result: known.length ? 'ok' : 'shape_change',
             observedKeys: observed.slice().sort().slice(0, 24),
             knownKeys: known.slice().sort() };
  }
  function rspCanaryEvidence(res) {
    return { result: res.result, observedKeys: res.observedKeys, knownKeys: res.knownKeys,
             checkedAt: new Date().toISOString(), action: 'warn_only',
             provenance: 'live_play_response_shape' };
  }
  const AUTH = { jwt: '', refreshToken: '', userOid: '', nick: '', exp: 0,
    _401Classes: {}, _key2Resolutions: 0, _butterSends: 0, relayedStats: null };
  function jwtExp(jwt) {
    try {
      const p = JSON.parse(atob(jwt.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
      return (p && p.exp) || 0;
    } catch (e) { return 0; }
  }
  function sanitizeAuthStats(s) {
    if (!s || typeof s !== 'object') return null;
    const cls = {};
    if (s.classifications401 && typeof s.classifications401 === 'object') {
      for (const k of Object.keys(s.classifications401)) {
        const v = Number(s.classifications401[k]);
        if (Number.isFinite(v) && v >= 0) cls[String(k).slice(0, 32)] = v;
      }
    }
    return {
      mode: typeof s.mode === 'string' ? s.mode.slice(0, 40) : 'localStorage-interceptor',
      tokenSource: s.tokenSource === 'localStorage' || s.tokenSource === 'cli' ? s.tokenSource : null,
      refreshSource: s.refreshSource === 'localStorage-scan' || s.refreshSource === 'env' || s.refreshSource === 'file' || s.refreshSource === 'value' ? s.refreshSource : null,
      userOidSupplied: !!s.userOidSupplied,
      switchedToRefresh: !!s.switchedToRefresh,
      refreshAttempts: Number(s.refreshAttempts) || 0,
      refreshSuccesses: Number(s.refreshSuccesses) || 0,
      refreshFailures: Number(s.refreshFailures) || 0,
      responseKey: typeof s.responseKey === 'string' ? s.responseKey.slice(0, 32) : null,
      classifications401: cls,
      key2Resolutions: Number(s.key2Resolutions) || 0,
      butterSent: !!s.butterSent,
      provenance: 'rspauth_counters'
    };
  }
  function buildHostAuthStats() {
    const rel = AUTH.relayedStats;
    const hasLocal = !!(AUTH.jwt || AUTH.userOid || AUTH._key2Resolutions || AUTH._butterSends || Object.keys(AUTH._401Classes || {}).length);
    if (!rel && !hasLocal) return STATE.authStats || undefined;
    const merged401 = Object.assign({}, (rel && rel.classifications401) || {});
    for (const k of Object.keys(AUTH._401Classes || {})) {
      merged401[k] = (merged401[k] || 0) + (AUTH._401Classes[k] || 0);
    }
    return {
      mode: (rel && rel.mode) || 'localStorage-interceptor',
      tokenSource: (rel && rel.tokenSource) || (AUTH.jwt ? 'localStorage' : null),
      refreshSource: (rel && rel.refreshSource) || (AUTH.refreshToken ? 'localStorage-scan' : null),
      userOidSupplied: !!((rel && rel.userOidSupplied) || AUTH.userOid),
      switchedToRefresh: !!(rel && rel.switchedToRefresh),
      refreshAttempts: (rel && rel.refreshAttempts) || 0,
      refreshSuccesses: (rel && rel.refreshSuccesses) || 0,
      refreshFailures: (rel && rel.refreshFailures) || 0,
      responseKey: (rel && rel.responseKey) || null,
      classifications401: merged401,
      key2Resolutions: ((rel && rel.key2Resolutions) || 0) + (AUTH._key2Resolutions || 0),
      butterSent: !!((rel && rel.butterSent) || (AUTH._butterSends || 0) > 0),
      provenance: 'rspauth_counters',
      note: '秘密(トークン値)は含まない。公式interceptorと同一戦略(逐次読・Refresh-Tokenヘッダ送出のみ・本ツールは更新APIを呼ばない)'
    };
  }
  function applyAuth(p) {
    p = p || {};
    AUTH.jwt = p.jwt || '';
    AUTH.refreshToken = p.refreshToken || '';
    AUTH.userOid = p.userOid || '';
    AUTH.nick = p.nick || '';
    AUTH.exp = AUTH.jwt ? jwtExp(AUTH.jwt) : 0;
    if (p.authStats) AUTH.relayedStats = sanitizeAuthStats(p.authStats);
    if (p.canaryEvidence && typeof p.canaryEvidence === 'object') {
      STATE.canaryEvidence = {
        result: String(p.canaryEvidence.result || 'unreachable'),
        observedKeys: Array.isArray(p.canaryEvidence.observedKeys) ? p.canaryEvidence.observedKeys.slice(0, 24) : [],
        knownKeys: Array.isArray(p.canaryEvidence.knownKeys) ? p.canaryEvidence.knownKeys.slice(0, 24) : [],
        checkedAt: String(p.canaryEvidence.checkedAt || new Date().toISOString()),
        action: 'warn_only',
        provenance: 'live_play_response_shape'
      };
    }
  }
  const RspAuth = {
    get jwt() { return AUTH.jwt; },
    probe() { return this; }, /* offscreenでは再読込不可(expはjwtから常時算出) */
    requestorQuery() { return AUTH.userOid ? { requestorOid: AUTH.userOid, loginType: 'rplay' } : {}; },
    jwtHeaders(extra) {
      const h = { 'Platform-Type': 'rplay', Authorization: AUTH.jwt || 'null' };
      if (AUTH.refreshToken) h['Refresh-Token'] = AUTH.refreshToken;
      if (extra) for (const k in extra) h[k] = extra[k];
      return h;
    }
  };
  let _tokenStaleAt = 0;
  function emitTokenStale() {
    const now = Date.now();
    if (now - _tokenStaleAt < 60000) return;
    _tokenStaleAt = now;
    MSG.send({ type: 'rec.event', kind: 'token', msg: 'トークンが期限切れの可能性 — ライブページを開くと最新トークンへ自動更新します' });
  }

  /* ---- v2.37.0: 共通JSON取得(ページ/BG同一実装) ----
     前版までページ側(player.user.js)のみだったstream読込契約をoffscreen_pre.js
     側にも共通適用する。旧offscreen実装(応答をjson()で一括読込・サイズ上限なし・
     ヘッダ受信でtimeout解除)は廃止し、BG経路のJSONも同じ上限契約へ揃える。
     - 2 MiB上限: 宣言Content-Lengthと実受信byte数の両方を検査し、超過は
       JSON_TOO_LARGEとして即失敗(再試行しない)。上限ちょうどは成功。
     - 本文はgetReaderでchunk読込し、fatal UTF-8 TextDecoderで連結する。
       stream非対応はJSON_STREAM_UNAVAILABLEとして即失敗(json()へfallbackしない)。
     - timeoutは本文受信完了まで有効(旧offscreenの「ヘッダで解除」を廃止)。
     - finallyでctl.abortとreader.cancel/releaseLockを必ず実施(部分受信の解放)。
     - 再試行は通信失敗(status 0)と5xxのみ最大1回・800ms間隔。429はretry-afterを
       返して再試行しない。JSON_TOO_LARGE/JSON_STREAM_UNAVAILABLEはterminal。
     - logFnは未使用引数(呼び互換のため保持)。signalは外部停止要求の即時反映。 */
  async function fetchJsonWithRetry(url, headers, timeoutMs, logFn, signal) {
    const cancelled=()=>signal&&signal.aborted;
    const pause=()=>new Promise(resolve=>{let timer;const finish=()=>{clearTimeout(timer);if(signal)signal.removeEventListener('abort',finish);resolve();};timer=setTimeout(finish,800);if(signal){signal.addEventListener('abort',finish,{once:true});if(signal.aborted)finish();}});
    for(let a=0;a<2;a++){
      if(cancelled())return {ok:false,status:0,aborted:true};
      const ctl=new AbortController(),abort=()=>ctl.abort();
      if(signal)signal.addEventListener('abort',abort,{once:true});
      const timer=setTimeout(abort,timeoutMs||8000);
      let result,reader;
      try{
        if(cancelled())ctl.abort();
        const res=await fetch(url,{cache:'no-store',headers:headers||{},signal:ctl.signal});
        if(res.status===200){
          const limit=2*1048576,fail=code=>{const e=Error(code);e.code=code;throw e;};
          if(Number(res.headers.get('content-length'))>limit)fail('JSON_TOO_LARGE');
          if(!res.body||!res.body.getReader)fail('JSON_STREAM_UNAVAILABLE');
          reader=res.body.getReader();let size=0,text='';const decoder=new TextDecoder('utf-8',{fatal:true});
          while(true){const part=await reader.read();if(part.done)break;size+=part.value.byteLength;if(size>limit)fail('JSON_TOO_LARGE');text+=decoder.decode(part.value,{stream:true});}
          text+=decoder.decode();result={ok:true,status:200,json:JSON.parse(text)};
        }
        else result={ok:false,status:res.status,...(res.status===429?{retryAfter:res.headers.get('retry-after')}:{})};
      }catch(e){result={ok:false,status:0,...(e.code?{error:e.code}:{})};}
      finally{ctl.abort();clearTimeout(timer);if(signal)signal.removeEventListener('abort',abort);if(reader){try{const p=reader.cancel();if(p&&p.catch)p.catch(()=>{});}catch(e){}reader.releaseLock();}}

      if(cancelled())return {ok:false,status:0,aborted:true};
      if(result.error||result.ok||result.status>0&&result.status<500||a===1)return result;
      await pause();
    }
  }
  if(typeof module!=='undefined')module.exports={fetchJsonWithRetry};

  /* offscreen版 authedJson: 401時の再読込はできないため token.stale を通知。
     トークンが token.update で更新されていれば、コア側の再試行ループが
     次回試行で新しいトークンを使用する(連打はコアの節流が担保)。 */
  async function authedJson(url, opts) {
    const o = opts || {};
    const r = await fetchJsonWithRetry(url, RspAuth.jwtHeaders(o.extraHeaders), o.timeoutMs || 8000, o.log, o.signal);
    if (r.status === 401) {
      AUTH._401Classes['auth-expired'] = (AUTH._401Classes['auth-expired'] || 0) + 1;
      emitTokenStale();
    }
    return r;
  }
  async function probeM3u8Ok(base) {
    if (!base) return false;
    try {
      const ctl = new AbortController();
      const to = setTimeout(() => ctl.abort(), 6000);
      const res = await fetch(base,
        { cache: 'no-store', signal: ctl.signal });
      clearTimeout(to);
      if (res.status !== 200) return false;
      const txt = await res.text();
      return txt.indexOf('#EXTM3U') >= 0 || txt.indexOf('#EXTINF') >= 0 || txt.indexOf('#EXT-X-STREAM-INF') >= 0;
    } catch (e) { return false; }
  }

  /* ---- 詮索/限定解決/予約(ページ実装と同一ロジック・キャッシュ付き) ---- */
  const _liveInfoCache = { oid: null, at: 0, info: null };
  async function resolveLiveInfo(creatorOid) {
    const now = Date.now();
    if (_liveInfoCache.oid === creatorOid && now - _liveInfoCache.at < 30000 && _liveInfoCache.info) {
      return _liveInfoCache.info;
    }
    const q = new URLSearchParams({ creatorOid: creatorOid });
    for (const k in RspAuth.requestorQuery()) q.set(k, RspAuth.requestorQuery()[k]);
    const r = await authedJson(API_BASE + '/live/play?' + q.toString(), { timeoutMs: 8000 });
    const info = (r && r.ok && r.json) ? r.json : null;
    STATE.canaryEvidence = rspCanaryEvidence(rspCanaryCheck(info));
    if (STATE.recorder && STATE.recorder.noteStreamStart && info) STATE.recorder.noteStreamStart(info);
    _liveInfoCache.oid = creatorOid;
    _liveInfoCache.at = now;
    _liveInfoCache.info = info;
    return info;
  }
  function liveBaseLabel(info) {
    if (!info) return '不明';
    if (info.streamState === 'youtube') return 'YouTube(外部)';
    if (info.useRplayStreamServer) return 'RPLAY自社';
    if (info.bytePlusPlaybackUrl && info.playUrl) return 'BytePlus+IVS併用';
    if (info.bytePlusPlaybackUrl) return 'BytePlus';
    if (info.playUrl) return 'IVS';
    return '不明';
  }
  const _memberResolveCache = { oid: null, at: 0, result: null }; /* コアが参照(キャッシュ無効化) */
  async function resolveMemberLive(creatorOid, logFn) {
    const logger = logFn || function () {};
    const now = Date.now();
    if (_memberResolveCache.oid === creatorOid && now - _memberResolveCache.at < 60000 && _memberResolveCache.result) {
      return _memberResolveCache.result;
    }
    const info = (await resolveLiveInfo(creatorOid)) || {};
    if (info == null || (!info.streamState && !info.oid && !info.creatorOid)) {
      logger('live/play 応答なし — 一時障害の可能性');
      return { ok: false, reason: 'api', status: 0 };
    }
    const st = info.streamState;
    if (st && st !== 'live') {
      if (st === 'youtube') return { ok: false, reason: 'youtube', redirect: info.liveStreamId };
      if (st === 'twitch') return { ok: false, reason: 'twitch', redirect: info.twitchLogin };
      return { ok: false, reason: st };
    }
    if (!info.accessible) {
      const freeTier = info.tierHashes && info.tierHashes.free;
      return { ok: false, reason: 'no-access', freeTier: !!freeTier };
    }
    if (!info.allowAnonymous && !RspAuth.jwt) return { ok: false, reason: 'login-required' };
    let key2 = '';
    if (RspAuth.jwt) {
      const q2 = new URLSearchParams({ creatorOid: creatorOid });
      for (const k in RspAuth.requestorQuery()) q2.set(k, RspAuth.requestorQuery()[k]);
      const r2 = await authedJson(API_BASE + '/live/key2?' + q2.toString(), { timeoutMs: 8000, log: logger });
      if (r2.ok && r2.json) { key2 = r2.json.authKey || ''; if (key2) AUTH._key2Resolutions = (AUTH._key2Resolutions || 0) + 1; }
      else if (r2.status === 401) {
        logger('live/key2 401 — トークンが無効です(UIタブを開くと自動更新します)');
        return { ok: false, reason: 'auth-expired', status: 401 };
      } else if (r2.status === 403) {
        logger('live/key2 403 — この配信への視聴権限がありません');
        return { ok: false, reason: 'no-access', status: 403 };
      } else logger('live/key2 ' + (r2.status || 'error') + ' — 鍵なしで継続を試みます');
    }
    const playlist = API_BASE + '/live/stream/playlist.m3u8?creatorOid=' + encodeURIComponent(creatorOid) +
      (key2 ? '&key2=' + encodeURIComponent(key2) : '');
    if (!(await probeM3u8Ok(playlist))) {
      logger('限定プレイリスト(' + playlist.split('?')[0] + ')が取得不能 — この源は採用しません');
      return { ok: false, reason: 'playlist' };
    }
    const result = { ok: true, playlist: playlist, key2: key2, title: info.title || '',
      allowAnonymous: !!info.allowAnonymous, base: liveBaseLabel(info) };
    _memberResolveCache.oid = creatorOid;
    _memberResolveCache.at = now;
    _memberResolveCache.result = result;
    return result;
  }
  function memberFailHint(r) {
    if (!r) return '限定配信の解決に失敗しました(一時障害の可能性 — 自動で再試行します)';
    switch (r.reason) {
      case 'no-access':
        return r.freeTier
          ? 'この配信は無料プラン加入限定です。プランに加入すると再生/録画できます'
          : 'この配信への視聴権限がありません(プラン加入/鍵/チケットのいずれかが必要)';
      case 'login-required':
        return '会員限定配信です。RPLAYにログインすると視聴権限があれば再生/録画できる可能性があります';
      case 'auth-expired':
        return 'ログイントークンが期限切れです — ライブページを開くと最新トークンへ自動更新します';
      case 'api':
        return 'RPLAY APIが一時的に応答していません — 自動で再試行します';
      case 'playlist':
        return '限定プレイリストを取得できません(配信の準備中/終了直後の可能性) — 自動で再試行します';
      case 'youtube':
      case 'twitch':
        return '外部配信(' + r.reason + ')のためこのプレイヤーでは扱いません';
      case 'offline':
        return '配信はオフラインです(開始を待機します)';
      default:
        return '限定配信を解決できませんでした(' + (r.reason || '不明') + ') — 自動で再試行します';
    }
  }
  const _schedCache = { oid: null, at: 0, item: null };
  function _pickScheduleItem(j) {
    let arr = null;
    if (Array.isArray(j)) arr = j;
    else if (j && typeof j === 'object') {
      for (const k of ['schedules', 'items', 'list', 'data', 'results']) {
        if (Array.isArray(j[k])) { arr = j[k]; break; }
      }
      if (!arr && (j.scheduledAt || j.startsAt || j.startAt)) arr = [j];
    }
    if (!arr) return null;
    const nowMs = Date.now();
    let best = null, bestT = Infinity;
    for (const it of arr) {
      if (!it || typeof it !== 'object') continue;
      const raw = it.scheduledAt || it.startsAt || it.startAt ||
        (it.live && (it.live.scheduledAt || it.live.startsAt));
      let t = 0;
      if (typeof raw === 'number') t = raw < 1e12 ? raw * 1000 : raw;
      else if (typeof raw === 'string') { const d = Date.parse(raw); if (!isNaN(d)) t = d; }
      if (!t) continue;
      if (t > nowMs - 30 * 60 * 1000 && t < bestT) { bestT = t; best = { title: it.title || it.name || '', scheduledAt: t }; }
    }
    return best;
  }
  async function resolveScheduleInfo(creatorOid) {
    const now = Date.now();
    const ttl = _schedCache.item ? 60000 : 20000;
    if (_schedCache.oid === creatorOid && now - _schedCache.at < ttl) return _schedCache.item;
    _schedCache.oid = creatorOid;
    _schedCache.at = now;
    if (!RspAuth.jwt) return null;
    try {
      const q = new URLSearchParams({ creatorOid: creatorOid });
      for (const k in RspAuth.requestorQuery()) q.set(k, RspAuth.requestorQuery()[k]);
      const r = await authedJson(API_BASE + '/live/schedules?' + q.toString(), { timeoutMs: 8000, signal });
      if (signal && signal.aborted) return { err: 'aborted' };
      if (!r.ok) return null;
      const item = _pickScheduleItem(r.json);
      _schedCache.item = item;
      return item;
    } catch (e) { return null; }
  }
  async function fetchSchedulesFor(creatorOid, signal) {
    if (!RspAuth.jwt) return { err: 'nologin' };
    try {
      const q = new URLSearchParams({ creatorOid: creatorOid });
      for (const k in RspAuth.requestorQuery()) q.set(k, RspAuth.requestorQuery()[k]);
      const r = await authedJson(API_BASE + '/live/schedules?' + q.toString(), { timeoutMs: 8000, signal });
      if (signal && signal.aborted) return { err: 'aborted' };
      if (!r.ok) return { err: String(r.status || 'error') };
      const arr = Array.isArray(r.json) ? r.json :
        ((r.json && (r.json.schedules || r.json.items || r.json.list || r.json.data || r.json.results)) || []);
      const nowMs = Date.now();
      const out = [];
      for (const it of arr) {
        if (!it || typeof it !== 'object') continue;
        const raw = it.scheduledAt || it.startsAt || it.startAt ||
          (it.live && (it.live.scheduledAt || it.live.startsAt));
        let t = 0;
        if (typeof raw === 'number') t = raw < 1e12 ? raw * 1000 : raw;
        else if (typeof raw === 'string') { const d = Date.parse(raw); if (!isNaN(d)) t = d; }
        if (!t) continue;
        if (t > nowMs - 30 * 60 * 1000) out.push({ title: it.title || it.name || '', scheduledAt: t });
      }
      return { items: out };
    } catch (e) { return { err: 'exception' }; }
  }

  /* ---- FSAハンドル共有(IndexedDB rsp_handles — 設計書§4.3) ----
     picker.html(拡張origin)が保存した FileSystemDirectoryHandle を復元し、
     コアの dirHandle へ渡す(パートのフォルダ直書きに使用)。 */
  function handlesDb() {
    return new Promise(function (res, rej) {
      const rq = indexedDB.open('rsp_handles', 1);
      rq.onupgradeneeded = function () { try { rq.result.createObjectStore('handles'); } catch (e) {} };
      rq.onsuccess = function () { res(rq.result); };
      rq.onerror = function () { rej(rq.error); };
    });
  }
  async function idbGetHandle() {
    try {
      const db = await handlesDb();
      return await new Promise(function (res, rej) {
        const tx = db.transaction('handles', 'readonly');
        const rq = tx.objectStore('handles').get('recDir');
        rq.onsuccess = function () { res(rq.result || null); };
        rq.onerror = function () { rej(rq.error); };
      });
    } catch (e) { return null; }
  }
  async function restoreHandle() {
    try {
      const dh = await idbGetHandle();
      if (!dh) { STATE.handleOk = false; STATE.handleName = ''; return; }
      let perm = 'granted';
      try { perm = await dh.queryPermission({ mode: 'readwrite' }); } catch (e) {}
      if (perm === 'granted') {
        STATE.handleOk = true;
        STATE.handleName = dh.name || 'folder';
        if (STATE.recorder) {
          STATE.recorder.dirHandle = dh;
          STATE.recorder.dirLabel = STATE.handleName;
        }
      } else {
        STATE.handleOk = false;
        STATE.handleName = dh.name || 'folder';
        MSG.send({ type: 'perm.request', name: STATE.handleName });
      }
    } catch (e) { STATE.handleOk = false; }
  }


  /* ===== ここからuser.jsと同期された録画コア(diff 0検証対象) ===== */
/* ============================================================
     ==== RSP RECORDING CORE — v2.0 Step1 切出し(BEGIN) ====
     このマーカー間が「録画コア」: 三形態(user.js/両拡張content.js)で
     同一文字列を共有し、v2.0 Step2/3ではoffscreen document(Chrome)/
     background event page(Firefox)へそのまま持ち出す単位。
     コアがページ環境に依存する箇所はすべてRECENV経由に統一してあり、
     Step2ではRECENVの実装差し替えのみで移譲できる。
     コア外へのアンビエント依存(Step2で注入が必要なもの):
       CDN_BASE / API_BASE / resolveMemberLive / resolveScheduleInfo /
       fetchSchedulesFor / memberFailHint / liveBaseLabel /
       idbOpen・idbAddSession・idbListSessions・idbClearSessions
       (履歴IndexdDB) / Recorder生成時のdeps引数(mount()で明示注入)
     ============================================================ */
  /* ================= v2.9.1(B-01): Blob URL遅延解放の契約 =================
     従来のRECENV.download/VOD保存は盲目的タイマー(10秒/30秒)でrevokeObjectURL
     していた。revokeは同期的・ダウンロード開始は非同期であり(Chromium
     Issue 41380177・MDN「avoid freeing the object URL too early」)、
     anchor.click()から取得登録までの間に解放すると保存が破損し得る。
     そこで「ダウンロード開始の確認後に解放する遅延解放」をサイズ比例の
     保持時間で契約化する: 保守スループット10MiB/s想定・床30秒・上限600秒。 */
  function rspBlobHoldMs(bytes) {
    var RSP_BLOB_FLOOR_MS = 30000;          // 床: 小容量・無効値も最低30秒保持
    var RSP_BLOB_CAP_MS = 600000;           // 上限: 異常に大きなblobでも10分以内
    var RSP_BLOB_BYTES_PER_SEC = 10 * 1024 * 1024; // 保守10MiB/s書込想定
    var n = Number(bytes);
    if (!isFinite(n) || n <= 0) return RSP_BLOB_FLOOR_MS; // 失敗安全側=床
    var hold = Math.ceil(n / RSP_BLOB_BYTES_PER_SEC * 1000);
    return Math.min(RSP_BLOB_CAP_MS, Math.max(RSP_BLOB_FLOOR_MS, hold));
  }
  function rspDelayedBlobRelease(url, anchor, bytes) {
    var holdMs = rspBlobHoldMs(bytes);
    setTimeout(function () {
      try { URL.revokeObjectURL(url); } catch (e) {}
      try { if (anchor && typeof anchor.remove === 'function') anchor.remove(); } catch (e) {}
    }, holdMs);
    return holdMs;
  }
  const RECENV = (typeof RSP_RECENV_HOOK !== 'undefined' && RSP_RECENV_HOOK) ? RSP_RECENV_HOOK : {
    /* ページURL(相対m3u8 URIの絶対化基準) */
    pageUrl: function () { try { return location.href; } catch (e) { return 'https://rplay.live/'; } },
    /* localStorage(セッション永続化・設定フォールバック) */
    storageGet: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    storageSet: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} },
    storageDel: function (k) { try { localStorage.removeItem(k); } catch (e) {} },
    /* ファイルダウンロード(メモリ保存方式) — v2.9.1(B-01): Blob URLは
       サイズ比例の遅延解放契約(rspDelayedBlobRelease)で保持・解放する */
    download: function (blob, name) {
      const a = document.createElement('a');
      const url = URL.createObjectURL(blob);
      a.href = url;
      a.download = name;
      document.body.appendChild(a);
      a.click();
      rspDelayedBlobRelease(url, a, blob.size);
    },
    /* デスクトップ通知(権限確認はRECENV実装側の責務 — v2.0 Step2:
       ページ実装はNotification権限を確認するが、offscreen実装は権限不要の
       chrome.notifications(SW中継)へ送るため確認しない) */
    notify: function (title, body) {
      try {
        if (typeof Notification === 'undefined' || Notification.permission !== 'granted') return;
        new Notification(title, { body: body });
      } catch (e) {}
    },
    /* タブタイトル(●REC表示) */
    getTitle: function () { try { return document.title; } catch (e) { return ''; } },
    setTitle: function (t) { try { document.title = t; } catch (e) {} },
    /* ページ退去時の確認ダイアログ */
    onUnload: function (fn) { try { window.addEventListener('beforeunload', fn); } catch (e) {} },
    offUnload: function (fn) { try { window.removeEventListener('beforeunload', fn); } catch (e) {} },
    /* JSヒープ使用量(監視フック用・非対応環境はnull) */
    perfHeap: function () {
      try { if (performance.memory && performance.memory.usedJSHeapSize) return performance.memory.usedJSHeapSize; } catch (e) {}
      return null;
    },
    /* 試験フック(window.__RSP_TEST) */
    testHooks: function () { try { return window.__RSP_TEST || {}; } catch (e) { return {}; } },
    /* v2.1.0(設計書§4.3): パートクローズ時のOPFS複製退避(最新2パート)&復旧記録フック */
    backupPart: function () {},
    recoveredParts: function () { return []; },
    /* v2.7.0(A-02/A-03): 認証・canary証拠の供給フック。ページ実装はRspAuthと
       直前のcanary結果から組み立てる(秘密は種別と計数のみ)。拡張ホスト
       (offscreen等)は未供給でもよい — その場合は証拠ブロックを出さない
       (虚偽のゼロを捏造しない)。 */
    authStats: function () { try { return RspAuth.authEvidence(); } catch (e) { return undefined; } },
    canaryEvidence: function () { return _lastCanary ? rspCanaryEvidence(_lastCanary) : undefined; },
    butterToken: function () { try { return butterToken(); } catch (e) { return Promise.resolve(''); } },
    /* Worker生成(v2.0 Step2: MV3拡張ページのCSP(script-src 'self')は
       Blob URL Workerをブロックするため、ホストが差し替え可能にする。
       nullを返すと呼び側はフォールバック(ticker=setInterval/検証=同期)へ) */
    makeWorker: function (src) {
      try { return new Worker(URL.createObjectURL(new Blob([src], { type: 'application/javascript' }))); }
      catch (e) { return null; }
    },
    /* v2.39.0: 自動開始の共通policy問い合わせ(全開始経路の統一gate)。
       ページ実装: 拡張content script環境(chrome.storage.local)でのみ保存済み
       rsp_dashboard_defaults を確認する。userscript等の拡張なし環境は
       「許可」(policy源なし — 従来挙動)。設定が読めない/不正な場合は
       「不明」を返し、呼び出し側は自動開始しない(fail-closed — BG側の
       START_SETTINGS_UNAVAILABLEと同じ安全側)。手動開始は問い合わせない。 */
    autoPolicy: function () {
      return new Promise(function (resolve) {
        let done = false;
        const finish = function (v) { if (!done) { done = true; resolve(v); } };
        try {
          if (typeof chrome === 'undefined' || !chrome || !chrome.storage || !chrome.storage.local || typeof chrome.storage.local.get !== 'function')
            return finish({ verdict: 'allowed' });
          const bound = (function () { try { const v = Number(RECENV.testHooks().settingsReadMs); return v > 0 ? v : 3000; } catch (e) { return 3000; } })();
          let timer = 0;
          if (typeof setTimeout === 'function') { try { timer = setTimeout(function () { finish({ verdict: 'unavailable' }); }, bound); } catch (e) { timer = 0; } }
          chrome.storage.local.get('rsp_dashboard_defaults', function (v) {
            if (timer) { try { clearTimeout(timer); } catch (e) {} }
            if (chrome.runtime.lastError || !v || typeof v !== 'object') return finish({ verdict: 'unavailable' });
            const d = v.rsp_dashboard_defaults;
            if (d !== undefined && (!d || typeof d !== 'object' || Array.isArray(d) ||
              ['autoStartAllowed', 'enabled', 'follow', 'recAudio', 'inheritQuery', 'mp4Handover'].some(function (k) { return d[k] !== undefined && typeof d[k] !== 'boolean'; }) ||
              (d.splitMin !== undefined && (typeof d.splitMin !== 'number' || !Number.isFinite(d.splitMin) || d.splitMin < 0 || d.splitMin > 1440))))
              return finish({ verdict: 'unavailable' });
            finish({ verdict: (d && d.autoStartAllowed === false) ? 'denied' : 'allowed' });
          });
        } catch (e) { finish({ verdict: 'unavailable' }); }
      });
    },
    /* v2.39.0: セッション終了フック(offscreen版がBG停止後のMP4引渡し台帳を書く)。
       ページ実装は何もしない。呼び出し側は返りPromiseを待たない(停止表示を
       遅らせない)。 */
    sessionEnded: function () {}
  };
  /* v2.0 Step2: RSP_RECENV_HOOK — 埋め込みホスト(offscreen.js)が録画コアを別環境で
     動かすための差し替え点。ページ環境(user.js/拡張content.js)では未定義のため
     上記のページ実装をそのまま使用する(挙動変化なし)。 */

  /* ================= Recorder v2: 無劣化録画 + 配信切替の自動追跡 =================
   再生エンジンと独立してプレイリストを監視し、新セグメント(.ts)をそのまま取得・
   結合して保存する(再生が止まっても録画は継続する)。

   v1.2.0 の追跡機構:
   - HLS(.ts)録画中に配信終了(ENDLIST / 連続404 / セグメント停止)を検出したら
     「追跡待機(STANDBY)」へ移行。追跡OFF設定のときは従来どおり自動保存して停止
   - 追跡待機では ①同一URLのプレイリスト再probe ②RPLAY API
     (GET /live/stream?creatorOid= — 認証不要・rplay.liveからCORS許可)を監視し、
     同一クリエイターの次の配信が始まると自動で録画を再開する
     (RPLAYの /live/<id> の id はクリエイターOIDそのもの = URLは配信が変わっても不変)
   - HLSが受信できない間にFLVが生きていれば、FLVストリームを無劣化のまま取得して
     録画を継続(配信者側の切り替え/CDN障害のどちらでも取りこぼしを最小化)
   - 保存先: File System Access API対応(Chrome/Edge)ではフォルダへ直接書き込み
     (メモリ制限なし)。非対応はメモリ保持→自動分割ダウンロード
   - セグメント名は <oid>-ss-<セッション>-<連番>-<時刻>.ts で一意のため、
     seen集合の重複排除だけで配信をまたいだ二重取得を防止できる
   - タイマーはWeb Worker内で動くため、タブをバックグラウンドにしても
     ポーリング間隔が劣化しない(Worker生成不可環境では通常タイマー) */

  const REC_POLL_MS = 3000;           // tick間隔(実際のプレイリスト取得は下記の適応間隔でゲート)
  const REC_POLL_MIN_MS = 4000;       // プレイリスト取得の最短間隔
  const REC_POLL_MAX_MS = 10000;      // プレイリスト取得の最長間隔
  const REC_POLL_TARGET_FACTOR = 0.6; // TARGETDURATION×この倍率を基準(公式プレイヤー級の負荷)
  const REC_POLL_JITTER = 0.1;        // 間隔ジッタ(機械的な定期アクセスを避ける)
  const REC_STANDBY_MS = 20000;       // 追跡待機の探索間隔(±10%ジッタ付き)
  const REC_SEG_MAX_TRIES = 8;
  const REC_SEG_TIMEOUT_MS = 15000;   // セグメント1取得のタイムアウト
  const REC_REQ_MIN_GAP_MS = 250;     // 録画リクエスト開始間隔の下限(サーバー負荷配慮)
  const REC_403_COOLDOWN_MS = 60000;  // 403時の待機(連打しない)
  const REC_429_BASE_MS = 30000;      // 429時の指数バックオフ初回
  const REC_429_MAX_MS = 300000;      // 429バックオフ上限
  /* v1.12.0(改善点調査の反映): Retry-After(RFC9110 §10.2.3)準拠。
   429/503応答にサーバー指定の待機秒(またはHTTP日時)があれば、指数バックオフより
   優先してそれを尊重する(yc-dlp/streamlink系クライアントのベストプラクティス)。
   短すぎる値は1秒・長すぎる値は300秒に丸める(既存の退避上限と一致) */
  function recRetryAfterMs(h) {
    if (!h) return 0;
    const n = parseInt(h, 10);
    if (!isNaN(n) && n >= 0) return Math.min(Math.max(n, 1), 300) * 1000;
    const d = Date.parse(h);
    if (!isNaN(d)) return Math.min(Math.max(Math.round((d - Date.now()) / 1000), 1), 300) * 1000;
    return 0;
  }
  const REC_FILE_CAP_BYTES = RECENV.partByteLimit || 600 * 1024 * 1024; // 1ファイル容量上限(超過で分割)
  const REC_404_GIVE_UP = 4;          // 追跡OFF時: 連続404で終了保存
  const REC_404_STANDBY = 3;          // 追跡ON時: 連続404で追跡待機へ
  // Official live/play preference; legacy remains the last HLS fallback.
  function rspSourceCandidates(info, legacy) {
    info = info || {};
    const urls = info.useBytePlusStream === true
      ? [info.bytePlusPlaybackUrl, info.playUrl, legacy]
      : [info.playUrl, info.bytePlusPlaybackUrl, legacy];
    return Array.from(new Set(urls.filter(u => typeof u === 'string' && /^https?:\/\//i.test(u))));
  }

  const REC_END_STALL_MS = 90000;     // 新セグメント停止90秒で終了扱い
  const REC_FLV_COOLDOWN_MS = 30000;  // FLV代替の再試行クールダウン
  const REC_API_TIMEOUT_MS = 6000;
  /* v1.9.0: 画質選択(最高画質)の定数。
   再走査間隔は試験フック(window.__RSP_TEST.qualityRescanMs)で短縮可(5000以上)。 */
  /* v2.0 Step1: 試験フックはRECENV.testHooks()経由(コアのページ依存を集約) */
  const REC_QUALITY_RESCAN_MS = (function () {
    try { const v = Number(RECENV.testHooks().qualityRescanMs); if (v >= 5000) return v; } catch (e) {}
    return 300000; // master再走査(画質昇格チェック)の間隔(既定5分)
  })();
  const REC_QUALITY_FALLBACK_MS = 30000; // variant消失時フォールバックの節流
  /* v1.11.0: AudioRecorder(音声レンディション個別録画)の定数。
   要求オフセットは「同一瞬間の同時2リクエストを避ける」ための設計値(300〜500ms)。 */
  const REC_AUDIO_OFFSET_MS_MIN = 300;  // 映像ループ開始からの要求オフセット(下限)
  const REC_AUDIO_OFFSET_MS_MAX = 500;  // 同・上限
  const REC_AUDIO_STALL_MS = 90000;     // 新音声セグメント停止90秒で停止(映像と同一基準)
  /* v1.10.0: リマインド/メモリ/履歴/予約一覧の定数。
   リマインド閾値は試験フック(window.__RSP_TEST.remind10Ms/remind5Ms)で短縮可。 */
  const REC_SEEN_MAX = 30000;          // seen集合の上限(長時間録画の肥大化抑制)
  const REC_SEEN_KEEP = 12000;         // 上限到達時に残す件数
  const REC_QUEUE_WARN_MS = 60000;     // キュー滞留警告の節流
  const REC_REMIND10_MS = 600000;      // 予約リマインド(10分前)の閾値
  const REC_REMIND5_MS = 300000;       // 予約リマインド(5分前)の閾値
  const SCHED_SCAN_MIN_MS = 600000;    // 予約一覧の自動巡回間隔(10分 — サーバー配慮)
  const HIST_DB = 'rsp_history';       // 録画履歴(IndexedDB)
  const HIST_STORE = 'sessions';
  const HIST_MAX = 50;                 // 履歴保持上限(古いものから自動削除)
  /* v1.6.0: 録画セッションの永続化(クラッシュ/再読み込みからの断点復帰) */
  const REC_SESSION_KEY = 'rsp_rec_session';
  const REC_SESSION_TTL_MS = 15 * 60 * 1000;  // 復帰提案の有効期限(停止後15分以内)
  const REC_SESSION_WRITE_EVERY = 2;          // 永続化間隔(3秒tick×2=約6秒)
  /* APIベースURL(上級フック: window.__RSP_API_BASE または localStorage.rsp_api_base で差し替え可。試験・自己責任用) */
  const API_BASE = (function () {
    try {
      if (typeof window.__RSP_API_BASE === 'string' && window.__RSP_API_BASE) return window.__RSP_API_BASE;
      const v = localStorage.getItem('rsp_api_base');
      if (v) return v;
    } catch (e) {}
    return 'https://api.rplay.live';
  })();

  /* ================= 画質選択(v1.9.0: 最高画質の自動選択) =================
   既存ツール(yt-dlp/streamlink/N_m3u8DL-RE)の画質選択を調査した結果を踏襲:
   - yt-dlpは既定ソートで res(解像度) > fps > br(帯域) の順に比較する
   - streamlink/N_m3u8DL-REはmasterから最良variantへ固定し、高画質出現時の
     昇格とvariant消失時の次画質フォールバックを備える
   → 録画は「解像度(面積) → fps → 帯域」の優先順で最高variantを選ぶ。
     TS無劣化録画ではデコード互換性を気にする必要がなく、ユーザーが知覚する
     解像度/fpsを帯域より優先するのが既存ツールの合意。 */
  function parseM3u8Attrs(str) {
    const out = {};
    const re = /([A-Z0-9-]+)=("[^"]*"|[^,]*)/g;
    let m;
    while ((m = re.exec(String(str)))) {
      let v = m[2];
      if (v.charAt(0) === '"') v = v.slice(1, -1);
      out[m[1]] = v;
    }
    return out;
  }
  function parseVariants(txt, base) {
    // baseが相対パス(custom m3u8等)の場合は先に絶対化する(ページURL基準)。
    // 絶対化しないと new URL(uri, 相対base) が失敗し、救済の location.href では
    // ページディレクトリ(/live/<id>)基準に解決されて誤ったURLになる(v1.9.0修正)。
    let absBase = String(base || '');
    try { absBase = new URL(absBase, RECENV.pageUrl()).href; } catch (e) { /* 相対解決不可 → そのまま */ }
    const lines = String(txt).split('\n');
    const out = [];
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (line.indexOf('#EXT-X-STREAM-INF:') !== 0) continue;
      const attrs = parseM3u8Attrs(line.slice(18));
      let uri = '';
      for (let j = i + 1; j < lines.length; j++) {
        const s = lines[j].trim();
        if (!s) continue;
        if (s.charAt(0) === '#') {
          if (s.indexOf('#EXT-X-STREAM-INF:') === 0) break;
          continue;
        }
        uri = s; break;
      }
      if (!uri) continue;
      const res = String(attrs['RESOLUTION'] || '').split('x');
      const v = {
        url: '',
        bw: parseInt(attrs['BANDWIDTH'], 10) || 0,
        width: parseInt(res[0], 10) || 0,
        height: parseInt(res[1], 10) || 0,
        fps: parseFloat(attrs['FRAME-RATE']) || 0,
        codecs: attrs['CODECS'] || '',
        audioGroup: attrs['AUDIO'] || '',
        subsGroup: attrs['SUBTITLES'] || ''   // v2.9.0(A-09): 字幕グループ結合属性
      };
      v.bwEff = parseInt(attrs['AVERAGE-BANDWIDTH'], 10) || v.bw;
      try {
        v.url = new URL(uri, absBase).href;
      } catch (e) { continue; }
      out.push(v);
    }
    return out;
  }
  /* 最良variantの選択(解像度面積 → fps → 帯域の辞書式比較)。
   exclude: 消失(404等)したvariant URLの集合(フォールバック時に除外)。 */
  function pickBestVariant(vars, exclude) {
    const pool = [];
    for (let i = 0; i < vars.length; i++) {
      if (exclude && typeof exclude.has === 'function' && exclude.has(vars[i].url)) continue;
      pool.push(vars[i]);
    }
    if (!pool.length) return null;
    let best = pool[0];
    for (let i = 1; i < pool.length; i++) {
      const a = best, b = pool[i];
      const pa = a.width * a.height, pb = b.width * b.height;
      if (pb > pa || (pb === pa && (b.fps > a.fps || (b.fps === a.fps && b.bwEff > a.bwEff)))) best = b;
    }
    return best;
  }
  function qualityLabel(v) {
    if (!v) return '';
    let s = (v.height ? (v.height + 'p') : '音声');
    if (v.fps) s += Math.round(v.fps);
    if (v.bwEff) s += '(' + (v.bwEff >= 1000000 ? (v.bwEff / 1000000).toFixed(1) + 'Mbps' : Math.round(v.bwEff / 1000) + 'kbps') + ')';
    return s;
  }
  /* 昇格判定: 解像度/fpsが上なら昇格。同解像度同fpsは帯域30%増のみ
   (チャタリング防止 — streamlinkの固定挙動に寄せた安全側)。 */
  function isBetterVariant(cand, cur) {
    if (!cand || !cur) return false;
    const pxC = cand.width * cand.height, pxCur = cur.width * cur.height;
    if (pxC !== pxCur) return pxC > pxCur;
    if (cand.fps !== cur.fps) return cand.fps > cur.fps;
    return cand.bwEff > cur.bwEff * 1.3;
  }

  /* ================= v1.10.0: 音声レンディション(EXT-X-MEDIA TYPE=AUDIO) =================
   master playlistの音声グループを解析し、映像variant(#EXT-X-STREAM-INFのAUDIO属性)
   と紐付けてREC表示/情報JSONに記録する。yt-dlpがフォーマットソートで音声帯域を
   独立キーとして扱うのに対し、HLS masterは音声帯域を含まないため、ここでは
   「グループ名/チャンネル数」の検出・表示と再生側の最良トラック選択を行う。 */
  /* v1.11.0: URI属性+帯域(AVERAGE-BANDWIDTH優先・無ければBANDWIDTH)の解析を追加。
   戻り値: audioGroupMap[gid] = {name, channels, count, uri, bw}
   同一グループに複数のURI(言語違い等)がある場合は帯域最大の1つを採用する
   (yt-dlpのaudioトラック選択と同じ「最良音声」思想)。baseはURIの相対解決に使う。 */
  function parseAudioGroups(txt, base) {
    const out = {};
    let absBase = String(base || '');
    try { absBase = new URL(absBase, RECENV.pageUrl()).href; } catch (e) { /* 相対解決不可 → そのまま */ }
    const lines = String(txt).split('\n');
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (line.indexOf('#EXT-X-MEDIA:') !== 0) continue;
      const attrs = parseM3u8Attrs(line.slice(13));
      const type = String(attrs['TYPE'] || '').toUpperCase();
      if (type !== 'AUDIO') continue;
      const gid = attrs['GROUP-ID'] || '';
      if (!gid) continue;
      if (!out[gid]) out[gid] = { name: '', channels: '', count: 0, uri: '', bw: 0 };
      const g = out[gid];
      if (!g.name && attrs['NAME']) g.name = attrs['NAME'];
      if (attrs['CHANNELS']) g.channels = attrs['CHANNELS'];
      const uri = attrs['URI'] || '';
      if (uri) {
        const bw = parseInt(attrs['AVERAGE-BANDWIDTH'], 10) || parseInt(attrs['BANDWIDTH'], 10) || 0;
        if (!g.uri || bw > g.bw) {
          g.bw = bw;
          try { g.uri = new URL(uri, absBase).href; } catch (e2) { g.uri = uri; }
        }
      }
      g.count++;
    }
    return out;
  }
  /* ================= v2.11.0: TS細切れ防止(Continuity)とPaywall検出(W-05/W-06) =================
   Video DownloadHelper(vdhcoapp)・Stream Recorder・Streamlink等の知見を統合:
   - MPEG-TSはEXT-X-DISCONTINUITYでパートを強制分割せず単一ファイルへ連続追記(既定)
   - 分割分数(splitMinutes)の既定値を0(分割なし・容量上限まで単一ファイル継続)へ変更
   - Master 200 / Media 404(または403)の非対称応答をpaywall_blockedとして検出(rplay_watcher v0.5.2知見)
   Python側 detect_paywall_blocked / part_continuity_evidence と完全鏡像(相互言語比較試験で固定)。 */
  /* ================= v2.15.0(C-03): cat-catch m3u8dl:// 連携と前処理証拠 =================
   cat-catch(xifangczy/cat-catch)の「调用m3u8DL下载」(m3u8dl://カスタムプロトコル・
   N_m3u8DL-RE引数生成)と「数据预处理」(TS偽装ヘッダ除去)・クエリ継承のゼロ秘密証拠。
   Python側 build_m3u8dl_export / external_downloader_evidence と完全鏡像。 */
  function rspBuildM3u8dlExport(opts) {
    const o = opts || {};
    const url = String(o.url || '').trim();
    const saveName = String(o.saveName || 'RPLAY_stream').replace(/["\\]/g, '_');
    const hdrs = (o.headers && typeof o.headers === 'object') ? o.headers : {};
    const liveMerge = o.liveRealTimeMerge !== false;
    const hKeys = Object.keys(hdrs).filter(function (k) {
      return hdrs[k] !== undefined && hdrs[k] !== null && String(hdrs[k]) !== '';
    }).sort();
    const args = ['"' + url + '"', '--save-name "' + saveName + '"'];
    for (let i = 0; i < hKeys.length; i++) {
      const k = hKeys[i];
      const v = String(hdrs[k]).replace(/"/g, '\\"');
      args.push('--header "' + k + ': ' + v + '"');
    }
    if (liveMerge) {
      args.push('--live-real-time-merge');
      args.push('--live-pipe-mux');
    }
    const paramStr = args.join(' ');
    let b64 = '';
    try {
      if (typeof Buffer !== 'undefined') b64 = Buffer.from(paramStr, 'utf8').toString('base64');
      else b64 = btoa(unescape(encodeURIComponent(paramStr)));
    } catch (e) {}
    return {
      protocolUri: 'm3u8dl://' + b64,
      command: 'N_m3u8DL-RE ' + paramStr,
      targetUrl: url ? url.split('?')[0].split('#')[0] : null,
      saveName: saveName,
      headerKeys: hKeys,
      liveRealTimeMerge: Boolean(liveMerge)
    };
  }
  function rspExternalDownloaderEvidence(exp, stats) {
    const e = exp || {};
    const s = stats || {};
    const rawTarget = String(e.targetUrl || e.url || '');
    const cleanTarget = rawTarget ? rawTarget.split('?')[0].split('#')[0] : null;
    const hKeys = Array.isArray(e.headerKeys) ? e.headerKeys.slice().map(String).sort() : [];
    return {
      protocolScheme: 'm3u8dl',
      targetUrl: cleanTarget,
      saveName: e.saveName ? String(e.saveName) : null,
      headerKeys: hKeys,
      liveRealTimeMerge: Boolean(e.liveRealTimeMerge !== false),
      tsDisguiseStrippedCount: Number(s.tsDisguiseStrippedCount || 0),
      tsDisguiseBytesTotal: Number(s.tsDisguiseBytesTotal || 0),
      queryInheritedCount: Number(s.queryInheritedCount || 0),
      provenance: 'cat_catch_m3u8dl_and_preprocessor_v2120'
    };
  }
  function rspDetectPaywallBlocked(masterStatus, mediaStatus) {
    return Number(masterStatus) === 200 && (Number(mediaStatus) === 404 || Number(mediaStatus) === 403);
  }
  function rspPartContinuityEvidence(c) {
    const o = c || {};
    return {
      splitMinutes: Number(o.splitMinutes || 0),
      maxSizeMb: Number(o.maxSizeMb || 600),
      splitOnDiscontinuity: Boolean(o.splitOnDiscontinuity),
      discontinuityMergedCount: Number(o.discontinuityMergedCount || 0),
      discontinuitySplitCount: Number(o.discontinuitySplitCount || 0),
      sameSessionStandbyContinuations: Number(o.sameSessionStandbyContinuations || 0),
      partsConcatenated: Number(o.partsConcatenated || 0),
      concatOutput: o.concatOutput ? String(o.concatOutput) : null,
      provenance: 'vdh_coapp_and_streamlink_ts_continuity_v2100'
    };
  }

  /* ================= v2.9.0: 字幕レンディション(EXT-X-MEDIA TYPE=SUBTITLES) =================
   master playlistの字幕レンディションを観測・計数する(取得はしない安全側契約)。
   URI値は秘匿し取得可否(hasUri)のみ記録(URL秘匿契約)。未知の属性は埋め込まない
   (固定鍵集合のみ)。Python側 parse_subtitle_renditions と完全鏡像。 */
  function parseSubtitleRenditions(txt) {
    const out = [];
    const lines = String(txt).split('\n');
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (line.indexOf('#EXT-X-MEDIA:') !== 0) continue;
      const attrs = parseM3u8Attrs(line.slice(13));
      if (String(attrs['TYPE'] || '').toUpperCase() !== 'SUBTITLES') continue;
      const gid = attrs['GROUP-ID'] || '';
      if (!gid) continue;
      out.push({
        groupId: gid,
        name: attrs['NAME'] || '',
        language: attrs['LANGUAGE'] || '',
        assocLanguage: attrs['ASSOC-LANGUAGE'] || '',
        default: String(attrs['DEFAULT'] || '').toUpperCase() === 'YES',
        autoselect: String(attrs['AUTOSELECT'] || '').toUpperCase() === 'YES',
        forced: String(attrs['FORCED'] || '').toUpperCase() === 'YES',
        hasUri: !!attrs['URI']
      });
    }
    return out;
  }
  /* v2.9.0(A-09): master playlist取得済み(非空)のときのみ証拠ブロックを出す。
   未取得(空文字/非文字列)はundefined(虚偽のゼロを捏造しない・A-08契約の継承)。
   Python側 subtitle_evidence_block と完全鏡像(相互言語比較試験で固定)。 */
  function rspSubtitleEvidenceBlock(masterTxt, variants) {
    if (typeof masterTxt !== 'string' || !masterTxt) return undefined;
    return rspSubtitleEvidence(parseSubtitleRenditions(masterTxt), variants);
  }

  function audioLabelFor(group, groups) {
    if (!group) return '';
    const g = groups && groups[group];
    if (!g) return '';
    let s = g.name || group;
    if (g.channels) s += '(' + g.channels + 'ch)';
    return s;
  }

  /* ================= v1.10.0: 保存ファイル名テンプレート =================
   {date}{time}{creator}{title}{quality}{part}{ext} を置換して保存名を作る。
   OSで禁止される文字は自動除去し、空になった場合は従来命名へフォールバック
   (後方互換: テンプレ未設定時は現行どおり)。 */
  function recFileName(tpl, ctx, defName) {
    let name = defName;
    const t = String(tpl || '').trim();
    if (t) {
      name = t
        .replace(/\{date\}/g, ctx.date || '')
        .replace(/\{time\}/g, ctx.time || '')
        .replace(/\{creator\}/g, safeName(ctx.creator || ''))
        .replace(/\{title\}/g, safeName(ctx.title || ''))
        .replace(/\{quality\}/g, safeName(ctx.quality || ''))
        .replace(/\{part\}/g, String(ctx.part || 1))
        .replace(/\{ext\}/g, ctx.ext || 'ts');
      name = name.replace(/[\\/:*?"<>|\u0000-\u001f]/g, '').trim();
      if (!name) name = defName;
      if (!new RegExp('\\.' + (ctx.ext || 'ts') + '$', 'i').test(name)) name += '.' + (ctx.ext || 'ts');
    }
    return name;
  }

  /* ================= v1.10.0: TS同期バイト検証のWeb Worker並列化 =================
   0x47多重検証をWorkerへ移譲しUIスレッドの負荷を低減する(N_m3u8DL-RE等の
   並列検証に相当)。Worker生成不可の環境では同期検証へ自動フォールバック。
   検証はセグメントごとに独立しているため、書込順序の厳密保証には影響しない。 */
  function verifyTsSync(u8) {
    let ok = u8.length > 188 && u8[0] === 0x47;
    if (ok && u8.length >= 376) ok = u8[188] === 0x47;
    if (ok && u8.length >= 564) ok = u8[376] === 0x47;
    return ok;
  }
  const REC_VERIFY_WORKER_SRC = [
    'self.onmessage = function (e) {',
    '  var d = e.data || {};',
    '  var u8 = new Uint8Array(d.buf);',
    '  var ok = u8.length > 188 && u8[0] === 0x47;',
    '  if (ok && u8.length >= 376) ok = u8[188] === 0x47;',
    '  if (ok && u8.length >= 564) ok = u8[376] === 0x47;',
    '  self.postMessage({ id: d.id, ok: ok });',
    '};'
  ].join('\n');
  function createTsVerifier() {
    let worker = null;
    let seq = 0;
    const pending = new Map();
    try {
      worker = RECENV.makeWorker(REC_VERIFY_WORKER_SRC); // v2.0 Step2: RECENV経由(CSP対応)
      if (worker) {
        worker.onmessage = function (e) {
          const d = e.data || {};
          const p = pending.get(d.id);
          if (p) { pending.delete(d.id); p(d.ok === true); }
        };
      }
    } catch (e) { worker = null; }
    return {
      usingWorker: function () { return !!worker; },
      async check(u8) {
        if (worker) {
          const id = ++seq;
          try {
            const copy = u8.slice(); // オリジナルを壊さないため複製をtransfer(ゼロコピー)
            const p = new Promise(function (res) {
              pending.set(id, res);
              setTimeout(function () { if (pending.has(id)) { pending.delete(id); res(null); } }, 3000);
            });
            worker.postMessage({ id: id, buf: copy.buffer }, [copy.buffer]);
            const ok = await p;
            if (ok !== null) return ok;
          } catch (e) { /* Worker失敗 → 同期検証へ */ }
        }
        return verifyTsSync(u8);
      }
    };
  }

  /* ================= v1.10.0: 録画履歴(IndexedDB・最大50件) =================
   セッション要約を停止時に保存し、パネルの「🕘 録画履歴」で一覧表示する。
   保存は本体の録画処理に影響させない(失敗時は黙ってスキップ)。 */
  function idbOpen() {
    return new Promise(function (res, rej) {
      try {
        if (typeof indexedDB === 'undefined') return rej(new Error('no idb'));
        const req = indexedDB.open(HIST_DB, 1);
        req.onupgradeneeded = function () { req.result.createObjectStore(HIST_STORE, { autoIncrement: true }); };
        req.onsuccess = function () { res(req.result); };
        req.onerror = function () { rej(req.error || new Error('idb error')); };
      } catch (e) { rej(e); }
    });
  }
  async function idbAddSession(entry) {
    try {
      const db = await idbOpen();
      await new Promise(function (res, rej) {
        const tx = db.transaction(HIST_STORE, 'readwrite');
        tx.objectStore(HIST_STORE).add(entry);
        tx.oncomplete = res; tx.onerror = rej; tx.onabort = rej;
      });
      db.close();
      return true;
    } catch (e) { return false; }
  }
  async function idbListSessions() {
    try {
      const db = await idbOpen();
      const all = await new Promise(function (res, rej) {
        const tx = db.transaction(HIST_STORE, 'readonly');
        const req = tx.objectStore(HIST_STORE).getAll();
        req.onsuccess = function () { res(req.result || []); };
        req.onerror = rej;
      });
      // 上限超過分(古いもの)を削除 — getAllは挿入順で返る
      let del = all.length - HIST_MAX;
      if (del > 0) {
        await new Promise(function (res) {
          const tx = db.transaction(HIST_STORE, 'readwrite');
          const creq = tx.objectStore(HIST_STORE).openCursor();
          creq.onsuccess = function () {
            const cur = creq.result;
            if (!cur || del <= 0) return;
            cur.delete(); del--; cur.continue();
          };
          tx.oncomplete = res; tx.onerror = res;
        });
      }
      db.close();
      return all;
    } catch (e) { return []; }
  }
  async function idbClearSessions() {
    try {
      const db = await idbOpen();
      await new Promise(function (res) {
        const tx = db.transaction(HIST_STORE, 'readwrite');
        tx.objectStore(HIST_STORE).clear();
        tx.oncomplete = res; tx.onerror = res;
      });
      db.close();
    } catch (e) { /* 不可環境 */ }
  }

  /* ================= v1.10.0: UIテーマ(ダーク既定/ライト追従)と言語 =================
   配色はprefers-color-schemeに追従(data-theme="auto")し、手動設定で上書き可能。
   i18nは静的ラベルのみ(ログ文面は日本語固定 — E2Eと案内の安定性のため)。 */
  const RSP_I18N = {
    ja: {
      recStart: '● 録画開始', recStop: '■ 録画停止', save: '💾 保存', follow: '追跡',
      autoRec: 'LIVE後に自動録画', autoStop: 'LIVE後 公式を自動停止',
      reconnect: '再接続', pswitch: 'HLS⇄FLV', fs: '全画面', off: '公式停止',
      details: '詳細設定(URL上書き/録画オプション)', split: '録画分割(分)',
      flv: 'FLV代替', backlog: 'バックログ取得', infoJson: '録画情報JSON', rfcExtinf: 'RFC 8216厳格',
      csv: '統計CSV', notify: '🔔通知', bestQ: '⤒ 最高画質', audioRec: '⤓ 音声トラックも録画', folder: '📁 保存先:未設定',
      history: '🕘 録画履歴', histClear: '消去', resume: '⏵ 録画を復帰', drop: '破棄',
      schedScan: '📡 予約を確認', apply: '適用', playq: '画質:自動', playqBest: '画質:最高',
      discScan: '🔍 全走査', discRefresh: '↻ 更新', discAuto: '自動更新',
      discEmpty: 'ライブ中の配信がありません — 「🔍 全走査」で公式一覧から探索します',
      discFoot: '公開APIのみ使用(認証回避なし)。カードをクリックで配信ページを新規タブで開きます',
      discSrc: '探索ソース(componentOid,カンマ区切り)', discReady: '準備完了 — 「🔍 全走査」で探索',
      discScanning: '走査中…', discCooldown: '退避中(あと%S秒)', discAuthed: '自分の会話の一覧APIを使用'
    },
    en: {
      recStart: '● Record', recStop: '■ Stop', save: '💾 Save', follow: 'Track',
      autoRec: 'Auto-record on LIVE', autoStop: 'Stop official after LIVE',
      reconnect: 'Reconnect', pswitch: 'HLS⇄FLV', fs: 'Fullscreen', off: 'Stop official',
      details: 'Advanced (URL override / record options)', split: 'Split (min)',
      flv: 'FLV fallback', backlog: 'Backlog fetch', infoJson: 'Info JSON', rfcExtinf: 'RFC 8216 strict',
      csv: 'Stats CSV', notify: '🔔 Notify', bestQ: '⤒ Best quality', audioRec: '⤓ Record audio track', folder: '📁 Save folder: unset',
      history: '🕘 History', histClear: 'Clear', resume: '⏵ Resume recording', drop: 'Discard',
      schedScan: '📡 Check schedules', apply: 'Apply', playq: 'Quality:Auto', playqBest: 'Quality:Best',
      discScan: '🔍 Full scan', discRefresh: '↻ Refresh', discAuto: 'Auto refresh',
      discEmpty: 'No live streams — run "🔍 Full scan" to discover from official lists',
      discFoot: 'Public API only (no auth bypass). Click a card to open the live page in a new tab',
      discSrc: 'Sources (componentOid, CSV)', discReady: 'Ready — run "🔍 Full scan"',
      discScanning: 'Scanning…', discCooldown: 'Cooling down (%Ss)', discAuthed: 'Using your own session list'
    }
  };
  function rspLang() {
    try { const v = localStorage.getItem('rsp_lang'); if (v === 'en' || v === 'ja') return v; } catch (e) {}
    return 'ja';
  }
  function rspTheme() {
    try { const v = localStorage.getItem('rsp_theme'); if (v === 'light' || v === 'dark' || v === 'auto') return v; } catch (e) {}
    return 'auto';
  }

  const REC_TICK_WORKER_SRC = [
    'var t = null;',
    'onmessage = function (e) {',
    '  if (e.data && e.data.cmd === "start") {',
    '    if (t) clearInterval(t);',
    '    t = setInterval(function () { postMessage({ tick: Date.now() }); }, e.data.ms || 3000);',
    '  } else if (e.data && e.data.cmd === "stop") {',
    '    if (t) { clearInterval(t); t = null; }',
    '  }',
    '};'
  ].join('\n');

  function createTicker(ms, onTick) {
    let worker = null;
    let timer = null;
    try {
      worker = RECENV.makeWorker(REC_TICK_WORKER_SRC); // v2.0 Step2: RECENV経由(CSP対応)
      if (worker) {
        worker.onmessage = function (e) { if (e.data && e.data.tick) onTick(); };
        worker.postMessage({ cmd: 'start', ms: ms });
      }
    } catch (e) { worker = null; }
    if (!worker) timer = setInterval(onTick, ms); // フォールバック(背景タブでは間欠化の可能性)
    return {
      stop: function () {
        if (worker) { try { worker.postMessage({ cmd: 'stop' }); worker.terminate(); } catch (e2) {} worker = null; }
        if (timer) { clearInterval(timer); timer = null; }
      },
      usingWorker: function () { return !!worker; }
    };
  }

  function u8Concat(a, b) {
    const out = new Uint8Array(a.length + b.length);
    out.set(a, 0); out.set(b, a.length);
    return out;
  }
  function pad2(n) { return (n < 10 ? '0' : '') + n; }
  function stampNow() {
    const d = new Date();
    return '' + d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + '-' +
      pad2(d.getHours()) + pad2(d.getMinutes()) + pad2(d.getSeconds());
  }
  function fmtDur(ms) {
    const s = Math.max(0, Math.floor(ms / 1000));
    return pad2(Math.floor(s / 3600)) + ':' + pad2(Math.floor((s % 3600) / 60)) + ':' + pad2(s % 60);
  }
  function safeName(s) {
    const t = String(s || '').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '').replace(/\s+/g, '_');
    return t.slice(0, 40) || 'live';
  }

  /* v1.6.0: 永続化した録画セッションの読み出し(同一配信ID・TTL以内のみ有効) */
  function loadSavedSession(id) {
    try {
      const s = JSON.parse(RECENV.storageGet(REC_SESSION_KEY) || 'null');
      if(s && Object.prototype.hasOwnProperty.call(s,'memberPlaylist')){delete s.memberPlaylist;RECENV.storageSet(REC_SESSION_KEY,JSON.stringify(s));}
      if (s && (s.v === 1 || s.v === 2) && s.id === id && Date.now() - (s.updatedAt || 0) < REC_SESSION_TTL_MS) return s;
    } catch (e) {}
    return null;
  }

  // Ordinary HLS only (RFC 8216 §6.3.4); not an LL-HLS blocking reload policy.
  function recHlsReloadMs(target,changed,jitter=Math.random()*0.1) {
    const td=Number.isFinite(target)&&target>0?target:9;
    const j=Number.isFinite(jitter)?Math.max(0,Math.min(0.1,jitter)):0;
    return Math.ceil(td*1000*(changed?1:0.5)*(1+j));
  }
/* HLS descriptor parsing and bounded HTTP transport. No key retrieval (key bytes are
   caller-supplied). v2.37.0(N-01): software AES-128-CBC decryption primitive adapted from
   cat-catch lib/m3u8-decrypt.js (hls.js AESDecryptor lineage) for environments where
   WebCrypto is unavailable or rejects the operation. v2.37.0(N-03): TS packet
   continuity-counter audit (ISO/IEC 13818-1 2.4.3.2) — the packet-level knowledge behind
   cat-catch/hls.js parseTs cc grouping, exposed as non-destructive quality evidence. */
(function(root,factory){const api=Object.freeze(factory());if(typeof module!=='undefined'&&module.exports)module.exports=api;root.RspHlsTransport=api;})(typeof globalThis==='undefined'?this:globalThis,function(){
'use strict';
const fail=code=>{throw Error(code);},uint=s=>{if(!/^\d+$/.test(s))fail('HLS_BAD_INTEGER');const n=Number(s);if(!Number.isSafeInteger(n))fail('HLS_BAD_INTEGER');return n;};
const URI_CACHE_MAX=4096; // v2.5.0: generation-recovery URI identity cache bound
// v2.42.3: bounded, URL-free recording acceptance audit (not disk/fsync or AV decode proof).
// Never retain playlist/segment URLs, request headers, cookies, or segment byte arrays.
const LEDGER_TAIL_LIMIT=96;
function audit(owner){
 if(!owner._hlsWriteAudit)owner._hlsWriteAudit={schema:1,provenance:'writer_acceptance_not_file_commit',scope:'recording_instance',
  queued:0,accepted:0,acceptedMediaBytes:0,acceptedInitBytes:0,terminal:0,
  suspectedManifestMissing:0,declaredGaps:0,backlogSkipped:0,sequenceDiscontinuities:0,
  suspectedAcceptedSequenceGaps:0,unresolved:0,tail:[],last:null};
 return owner._hlsWriteAudit;
}
function stamp(item){
 const d=item&&item.hls;
 if(!d||![d.epoch,d.discontinuity,d.sequence].every(Number.isSafeInteger))return null;
 return {epoch:d.epoch,discontinuity:d.discontinuity,sequence:d.sequence};
}
function pushAudit(a,status,item,mediaBytes=0){
 const v=stamp(item);
 if(!v)return;
 a.tail.push({...v,status,...(status==='accepted'?{mediaBytes}: {})});
 if(a.tail.length>LEDGER_TAIL_LIMIT)a.tail.shift();
}
function noteQueue(owner,items,missing=0,declaredGaps=0,backlogSkipped=0){
 const a=audit(owner);a.queued+=items.length;
 a.suspectedManifestMissing+=Math.max(0,missing-declaredGaps);
 a.declaredGaps+=declaredGaps;
 a.backlogSkipped+=backlogSkipped;
 a.unresolved+=items.length;
 for(const item of items)pushAudit(a,'queued',item);
}
function freshPartAudit(){
 return {segments:0,mediaBytes:0,initBytes:0,firstSequence:null,lastSequence:null,
  firstEpoch:null,lastEpoch:null,firstDiscontinuity:null,lastDiscontinuity:null,
  sequenceGaps:0,discontinuities:0,prev:null};
}
function startPartAudit(owner){
 if(!owner||typeof owner!=='object')return null;
 owner._hlsPartAudit=freshPartAudit();
 return owner._hlsPartAudit;
}
function takePartAudit(owner){
 if(!owner||typeof owner!=='object')return null;
 const pa=owner._hlsPartAudit;
 owner._hlsPartAudit=null;
 if(!pa)return null;
 return {segments:pa.segments,mediaBytes:pa.mediaBytes,initBytes:pa.initBytes,
  firstSequence:pa.firstSequence,lastSequence:pa.lastSequence,
  firstEpoch:pa.firstEpoch,lastEpoch:pa.lastEpoch,
  firstDiscontinuity:pa.firstDiscontinuity,lastDiscontinuity:pa.lastDiscontinuity,
  sequenceGaps:pa.sequenceGaps,discontinuities:pa.discontinuities};
}
function noteAccepted(owner,item,mediaBytes,initBytes){
 if(!item||!item.hls)return;
 const a=audit(owner),v=stamp(item);
 if(!v)return;
 if(a.last&&a.last.epoch===v.epoch&&a.last.discontinuity===v.discontinuity&&v.sequence>a.last.sequence+1)
  a.suspectedAcceptedSequenceGaps+=v.sequence-a.last.sequence-1;
 if(a.last&&(a.last.epoch!==v.epoch||a.last.discontinuity!==v.discontinuity))a.sequenceDiscontinuities++;
 a.last=v;
 a.accepted++;a.unresolved=Math.max(0,a.unresolved-1);
 a.acceptedMediaBytes+=mediaBytes;a.acceptedInitBytes+=initBytes;
 pushAudit(a,'accepted',item,mediaBytes);
 const pa=owner._hlsPartAudit||(owner._hlsPartAudit=freshPartAudit());
 pa.segments++;pa.mediaBytes+=mediaBytes;pa.initBytes+=initBytes;
 if(pa.firstSequence===null){
  pa.firstSequence=v.sequence;pa.firstEpoch=v.epoch;pa.firstDiscontinuity=v.discontinuity;
 }
 if(pa.prev){
  if(pa.prev.epoch===v.epoch&&pa.prev.discontinuity===v.discontinuity&&v.sequence>pa.prev.sequence+1)
   pa.sequenceGaps+=v.sequence-pa.prev.sequence-1;
  if(pa.prev.epoch!==v.epoch||pa.prev.discontinuity!==v.discontinuity)pa.discontinuities++;
 }
 pa.lastSequence=v.sequence;pa.lastEpoch=v.epoch;pa.lastDiscontinuity=v.discontinuity;
 pa.prev=v;
}
function clearWriteEvidence(owner){owner._hlsWriteAudit=null;owner._hlsPartAudit=null;}
function noteTerminal(owner,item){
 if(!item||!item.hls)return;
 const a=audit(owner);a.terminal++;a.unresolved=Math.max(0,a.unresolved-1);
 pushAudit(a,'terminal',item);
}
function writeEvidence(owner){
 const a=owner&&owner._hlsWriteAudit;
 if(!a)return {schema:1,provenance:'writer_acceptance_not_file_commit',scope:'recording_instance',queued:0,accepted:0,terminal:0,unresolved:0,
  acceptedMediaBytes:0,acceptedInitBytes:0,suspectedManifestMissing:0,declaredGaps:0,
  backlogSkipped:0,sequenceDiscontinuities:0,suspectedAcceptedSequenceGaps:0,
  tail:[],tailLimit:LEDGER_TAIL_LIMIT,truncated:0,fileCommitted:false,avDecoded:false};
 return {schema:1,provenance:a.provenance,scope:a.scope,queued:a.queued,accepted:a.accepted,terminal:a.terminal,
  unresolved:a.unresolved,acceptedMediaBytes:a.acceptedMediaBytes,acceptedInitBytes:a.acceptedInitBytes,
  suspectedManifestMissing:a.suspectedManifestMissing,declaredGaps:a.declaredGaps,
  backlogSkipped:a.backlogSkipped,sequenceDiscontinuities:a.sequenceDiscontinuities,
  suspectedAcceptedSequenceGaps:a.suspectedAcceptedSequenceGaps,tail:a.tail.map(e=>({...e})),
  tailLimit:LEDGER_TAIL_LIMIT,truncated:Math.max(0,a.queued+a.terminal+a.accepted-a.tail.length),
  fileCommitted:false,avDecoded:false};
}
// v2.6.0(P2): LL-HLS safe-side policy — delta playlists (EXT-X-SKIP) reject with a
// dedicated code; PRELOAD-HINT/SERVER-CONTROL etc. are never fetched but counted.
const LLHLS_INDICATOR_TAGS=['#EXT-X-SERVER-CONTROL:','#EXT-X-PRELOAD-HINT:','#EXT-X-RENDITION-REPORT:','#EXT-X-PART:','#EXT-X-PART-INF:'];
const SCTE35_INDICATOR_TAGS=['#EXT-X-CUE-OUT','#EXT-X-CUE-IN','#EXT-X-SCTE35','#EXT-OATCLS-SCTE35','#EXT-X-DATERANGE:'];
const uriKey=d=>d.uri.split('?')[0].split('#')[0]+(d.range?'|'+JSON.stringify(d.range):'');
function attrs(s){const out={};let i=0;while(i<s.length){const m=/^([A-Z0-9-]+)=/.exec(s.slice(i));if(!m||m[1] in out)fail('HLS_BAD_ATTRIBUTES');i+=m[0].length;let value;if(s[i]==='"'){const end=s.indexOf('"',++i);if(end<0)fail('HLS_BAD_ATTRIBUTES');value=s.slice(i,end);i=end+1;}else{const end=s.indexOf(',',i);value=s.slice(i,end<0?s.length:end);i=end<0?s.length:end;}out[m[1]]=value;if(i<s.length){if(s[i++]!==','||i===s.length)fail('HLS_BAD_ATTRIBUTES');}}return out;}
// v2.12.0(C-02): cat-catch "添加get参数" (inheritQuery) — when inheritQuery=true and the
// base playlist URL carries query parameters (e.g. token/key2), append missing query keys
// onto same-origin segment/MAP URLs without overwriting segment-specific query parameters.
function url(raw,base,inheritQuery=false){
 if(typeof raw!=='string'||raw!==raw.trim()||/[\x00-\x1f\x7f]/.test(raw))fail('HLS_BAD_URL');
 const u=new URL(raw,base);
 if(!['http:','https:'].includes(u.protocol)||u.username||u.password)fail('HLS_BAD_URL');
 u.hash='';
 if(inheritQuery){
  try{
   const b=new URL(base);
   if(b.search&&u.origin===b.origin){
    for(const [k,v] of b.searchParams)if(!u.searchParams.has(k))u.searchParams.append(k,v);
   }
  }catch(e){}
 }
 return u.href;
}
function range(raw,previous,uri,map=false){if(raw===null)return null;const m=/^(\d+)(?:@(\d+))?$/.exec(raw);if(!m)fail('HLS_BAD_RANGE');const length=uint(m[1]);if(!length||length>32*1048576)fail('HLS_RANGE_LIMIT');let offset;if(m[2]!==undefined)offset=uint(m[2]);else{if(map||!previous||previous.uri!==uri||!previous.range)fail('HLS_IMPLICIT_RANGE');offset=previous.range.offset+previous.range.length;}if(!Number.isSafeInteger(offset+length-1))fail('HLS_RANGE_LIMIT');return {offset,length};}
function parse(text,base,mode='legacy',inheritQuery=false){
 // v2.5.0: mode='legacy' (default) accepts a segment URI without EXTINF as a
 // diagnostic (pre-v2.5 input compatibility); mode='rfc' rejects it
 // (RFC 8216 4.3.2.1 EXTINF is REQUIRED for every media segment).
 // v2.12.0(C-02): inheritQuery=true appends base playlist query params to same-origin URIs.
 if(typeof text!=='string'||text.length>2*1048576||!/^\uFEFF?#EXTM3U(?:\r?\n|$)/.test(text))fail('HLS_BAD_PLAYLIST');
 let sequence=0,discontinuity=0,target=0,map=null,encrypted=false,pendingRange=null,gap=false,previous=null,pendingDuration=null,pendingClock=null;const segments=[];let endList=false;let seenSeq=false,seenDisc=false,seenTarget=false,seenVersion=false;
 // v2.6.0(P1): fMP4 init-segment (EXT-X-MAP) declaration evidence. A switch splits
 // the part boundary so init segments never mix; a switch without an intervening
 // EXT-X-DISCONTINUITY is counted as a quality-risk indicator (not rejected).
 let mapDecls=0,mapSwitches=0,mapSwitchNoDisc=0,discSinceSeg=true,llhlsTags=0,scte35Tags=0,queryInherited=0;
 for(const raw of text.replace(/^\uFEFF/,'').split(/\r?\n/)){const line=raw.trim();if(!line)continue;if(line[0]!=='#'&&raw!==line)fail('HLS_BAD_URL');
  if(line.startsWith('#EXT-X-STREAM-INF:'))fail('HLS_EXPECT_MEDIA');
  if(line.startsWith('#EXT-X-VERSION:')){if(seenVersion)fail('HLS_BAD_VERSION');seenVersion=true;uint(line.slice(15));}
  if(line==='#EXT-X-I-FRAMES-ONLY')fail('HLS_IFRAMES_UNSUPPORTED');
  if(line.startsWith('#EXT-X-SKIP:'))fail('HLS_LLHLS_SKIP'); // v2.6.0(P2): dedicated delta-playlist rejection
  if(LLHLS_INDICATOR_TAGS.some(t=>line.startsWith(t)))llhlsTags++; // v2.6.0(P2): counted, never fetched
  if(SCTE35_INDICATOR_TAGS.some(t=>line.startsWith(t)))scte35Tags++;
  if(line.startsWith('#EXT-X-MEDIA-SEQUENCE:')){if(segments.length||seenSeq)fail('HLS_BAD_SEQUENCE');seenSeq=true;sequence=uint(line.slice(22));}
  else if(line.startsWith('#EXT-X-DISCONTINUITY-SEQUENCE:')){if(segments.length||seenDisc)fail('HLS_BAD_SEQUENCE');seenDisc=true;discontinuity=uint(line.slice(30));}
  else if(line==='#EXT-X-DISCONTINUITY'){discontinuity++;discSinceSeg=true;}
  else if(line.startsWith('#EXT-X-TARGETDURATION:')){if(seenTarget||segments.length)fail('HLS_BAD_TARGET');seenTarget=true;target=uint(line.slice(22));if(!target)fail('HLS_BAD_TARGET');}
  else if(line.startsWith('#EXTINF:')){if(endList||pendingDuration!==null)fail('HLS_BAD_EXTINF');const v=line.slice(8).split(',')[0];if(!/^(?:\d+(?:\.\d+)?|\.\d+)$/.test(v))fail('HLS_BAD_EXTINF');pendingDuration=Number(v);if(!Number.isFinite(pendingDuration)||pendingDuration<=0||pendingDuration>86400)fail('HLS_BAD_EXTINF');}
  else if(line.startsWith('#EXT-X-PROGRAM-DATE-TIME:')){if(endList||pendingClock!==null)fail('HLS_BAD_PROGRAM_DATE_TIME');const v=line.slice(25);if(!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2})$/.test(v))fail('HLS_BAD_PROGRAM_DATE_TIME');const m=/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d{1,3})?(?:Z|([+-])(\d{2}):(\d{2}))$/.exec(v);const yr=+m[1],mo=+m[2],day=+m[3],hr=+m[4],mi=+m[5],sec=+m[6];const leap=yr%4===0&&(yr%100!==0||yr%400===0);const lengths=[31,leap?29:28,31,30,31,30,31,31,30,31,30,31];if(yr<1||mo<1||mo>12||day<1||day>lengths[mo-1]||hr>23||mi>59||sec>59||(m[8]!==undefined&&(+m[8]>23||+m[9]>59)))fail('HLS_BAD_PROGRAM_DATE_TIME');pendingClock=Date.parse(v);if(!Number.isSafeInteger(pendingClock))fail('HLS_BAD_PROGRAM_DATE_TIME');}
  else if(line.startsWith('#EXT-X-KEY:')){const a=attrs(line.slice(11));if(!a.METHOD)fail('HLS_BAD_KEY');encrypted=a.METHOD!=='NONE';}
  else if(line.startsWith('#EXT-X-MAP:')){if(encrypted)fail('HLS_ENCRYPTED_UNSUPPORTED');const a=attrs(line.slice(11));if(!a.URI)fail('HLS_BAD_MAP');const plainMap=url(a.URI,base,false),uri=inheritQuery?url(a.URI,base,true):plainMap;if(inheritQuery&&uri!==plainMap)queryInherited++;const newMap={uri,range:range(a.BYTERANGE===undefined?null:a.BYTERANGE,null,uri,true)};mapDecls++;if(map&&JSON.stringify(map)!==JSON.stringify(newMap)){mapSwitches++;if(!discSinceSeg)mapSwitchNoDisc++;}map=newMap;}
  else if(line.startsWith('#EXT-X-BYTERANGE:')){if(pendingRange!==null)fail('HLS_BAD_RANGE');pendingRange=line.slice(17);}
  else if(line==='#EXT-X-GAP')gap=true;
  else if(line==='#EXT-X-ENDLIST'){if(endList)fail('HLS_DUPLICATE_ENDLIST');endList=true;}
  else if(line[0]!=='#'){
   if(endList)fail('HLS_SEGMENT_AFTER_ENDLIST');
   if(encrypted)fail('HLS_ENCRYPTED_UNSUPPORTED');if(segments.length>=4096)fail('HLS_SEGMENT_LIMIT');
   if(mode==='rfc'&&pendingDuration===null)fail('HLS_EXTINF_REQUIRED');
   const plainUri=url(line,base,false),uri=inheritQuery?url(line,base,true):plainUri;if(inheritQuery&&uri!==plainUri)queryInherited++;
   const r=range(pendingRange,previous,uri);const item={uri,range:r,map,gap,sequence:sequence+segments.length,discontinuity,duration:pendingDuration,programDateTimeMs:pendingClock};
   if(!Number.isSafeInteger(item.sequence)||!Number.isSafeInteger(discontinuity))fail('HLS_BAD_INTEGER');segments.push(item);previous=item;pendingRange=null;gap=false;pendingDuration=null;pendingClock=null;discSinceSeg=false;
  }
 }
 if(pendingRange!==null)fail('HLS_DANGLING_RANGE');if(pendingDuration!==null||pendingClock!==null||gap)fail('HLS_DANGLING_TAG');if(!target)fail('HLS_BAD_TARGET');for(const d of segments)if(d.duration!==null&&Math.floor(d.duration+0.5)>target)fail('HLS_DURATION_OVER_TARGET');return {sequence,discontinuity,target,endList,segments,queryInherited,fmp4:{mapDeclarations:mapDecls,mapSwitches,mapSwitchesWithoutDiscontinuity:mapSwitchNoDisc},llhls:{indicatorTags:llhlsTags},scte35:{indicatorTags:scte35Tags}};
}
// Advisory only: manifest wall-clock metadata is never proof of decoded PTS continuity.
function timingEvidence(parsed,toleranceMs=500){
 const result={provenance:'manifest_declared_only',segments:parsed.segments.length,explicitAnchors:0,checkedIntervals:0,suspectedGapIntervals:0,suspectedOverlapIntervals:0,maxAbsDeviationMs:0,unmeasuredIntervals:0,missingExtinf:0,declaredGaps:0,discontinuityBoundaries:0};
 let anchor=null,elapsed=0,complete=false,previousDisc=null;
 for(const d of parsed.segments){
  if(d.duration===null||d.duration===undefined)result.missingExtinf++;
  if(d.gap)result.declaredGaps++;
  if(previousDisc!==null&&previousDisc!==d.discontinuity){result.discontinuityBoundaries++;anchor=null;complete=false;elapsed=0;}
  previousDisc=d.discontinuity;
  if(d.programDateTimeMs!==null&&d.programDateTimeMs!==undefined){
   result.explicitAnchors++;
   if(anchor!==null){if(complete){const delta=d.programDateTimeMs-(anchor+elapsed);result.checkedIntervals++;result.maxAbsDeviationMs=Math.max(result.maxAbsDeviationMs,Math.abs(delta));if(delta>toleranceMs)result.suspectedGapIntervals++;else if(delta< -toleranceMs)result.suspectedOverlapIntervals++;}else result.unmeasuredIntervals++;}
   anchor=d.programDateTimeMs;elapsed=0;complete=true;
  }
  if(anchor!==null){if(d.duration===null||d.duration===undefined)complete=false;else elapsed+=d.duration*1000;}
 }
 return result;
}
const descriptorKey=d=>d?JSON.stringify([d.uri,d.range]):'';
// v2.12.0(W-05): MPEG-TS is a self-synchronizing 188-byte packet stream (PAT/PMT/PCR embedded).
// Unlike fMP4 (which requires EXT-X-MAP init boxes at the start of every part), MPEG-TS
// segments across EXT-X-DISCONTINUITY can be concatenated seamlessly into the same .ts file
// by default (matching Video DownloadHelper / Stream Recorder / Streamlink / yt-dlp / cat-catch).
function partBoundary(d,splitDisc=false){
 if(d&&d.map)return JSON.stringify([d.epoch,d.discontinuity,true,descriptorKey(d.map)]);
 return JSON.stringify(['ts',d?d.epoch:0,splitDisc?(d?d.discontinuity:0):0]);
}
function enqueue(owner,parsed,base){
 // v2.5.0: playlist generation recovery — mirrors the Python core classification
 // (initial/progress/stale/reset/rotation/context) with numeric evidence. A stale
 // re-serve never re-enqueues recorded data; a legitimate reset advances the epoch;
 // an encoder restart reusing sequence numbers is detected as uri rotation.
 const u=new URL(base);const context=u.origin+u.pathname;
 const uris=owner._hlsUris||(owner._hlsUris=new Map());
 const keys=parsed.segments.map(uriKey);
 let knownN=0;for(const k of keys)if(uris.has(k))knownN++;
 const hasFirst=owner._hlsFirst!==undefined;
 const rewind=hasFirst&&parsed.sequence<owner._hlsFirst;
 const sameContext=owner._hlsContext===context;
 let kind='progress';
 if(!hasFirst||owner._hlsContext===undefined)kind='initial';
 else if(!sameContext)kind='context';
 else if(rewind&&keys.length)kind=knownN===keys.length?'stale':'reset';
 let fresh=kind==='initial'||kind==='context'||kind==='reset';
 let epoch=(owner._hlsEpoch||0)+(fresh?1:0);const skip=owner._skipBacklog===true;
 const key=d=>'H:'+epoch+':'+d.discontinuity+':'+d.sequence+':'+JSON.stringify(d.range);
 let unseen=parsed.segments.filter(d=>!owner.seen.has(key(d)));
 if(kind==='progress'&&hasFirst&&sameContext&&!unseen.length&&keys.length&&knownN===0){
  kind='rotation';fresh=true;epoch=(owner._hlsEpoch||0)+1;
  unseen=parsed.segments.filter(d=>!owner.seen.has(key(d)));
 }
 if(uris.size)unseen=unseen.filter(d=>!uris.has(uriKey(d)));
 let incoming=skip?[]:unseen.filter(d=>!d.gap);
 let adFiltered=0;
 const adRe=(owner&&owner._adKeywordRe instanceof RegExp)?owner._adKeywordRe:(owner&&owner.rec&&owner.rec._adKeywordRe instanceof RegExp?owner.rec._adKeywordRe:null);
 if(adRe&&incoming.length){
  const kept=[];
  for(const d of incoming){
   if(adRe.test(d.uri.split("?")[0].split("#")[0]))adFiltered++;
   else kept.push(d);
  }
  incoming=kept;
 }
 const timing=timingEvidence(parsed);
 if(owner.queue.length+incoming.length>4096)fail('HLS_QUEUE_LIMIT');
 let missing=!fresh&&owner._hlsLast!==undefined&&parsed.sequence>owner._hlsLast+1?parsed.sequence-owner._hlsLast-1:0;
 for(const d of unseen){owner.seen.add(key(d));if(d.gap&&!skip)missing++;}
 for(const k of keys)uris.set(k,true);
 while(uris.size>URI_CACHE_MAX)uris.delete(uris.keys().next().value);
 const newItems=incoming.map(d=>({name:d.uri,base:'',tries:0,hls:{...d,epoch}}));
 for(const item of newItems)owner.queue.push(item);
 const declaredGapCount=skip?0:unseen.filter(d=>d.gap).length;
 // Ignore the deliberate backlog skip as a recording failure; keep it separately visible.
 if(newItems.length||missing||skip)noteQueue(owner,newItems,missing,declaredGapCount,skip?unseen.length:0);
 const rec=owner._hlsRecovery||(owner._hlsRecovery={staleResponses:0,suspectedResets:0,sequenceResets:0,uriRotations:0,contextSwitches:0,lastKind:kind,lastSequence:null});
 if(kind==='stale')rec.staleResponses++;
 else if(kind==='reset')rec.sequenceResets++;
 else if(kind==='rotation')rec.uriRotations++;
 else if(kind==='context')rec.contextSwitches++;
 rec.lastKind=kind;rec.lastSequence=keys.length?parsed.sequence:null;
 // v2.6.0(P1/P2): accumulate fMP4 MAP declaration and LL-HLS indicator evidence per context
 const f=parsed.fmp4||{};
 const ev=owner._hlsFmp4||(owner._hlsFmp4={mapDeclarations:0,mapSwitches:0,mapSwitchesWithoutDiscontinuity:0,crossPollMapSwitches:0,crossPollMapSwitchesWithoutDiscontinuity:0});
 ev.mapDeclarations+=f.mapDeclarations||0;ev.mapSwitches+=f.mapSwitches||0;ev.mapSwitchesWithoutDiscontinuity+=f.mapSwitchesWithoutDiscontinuity||0;
 // v2.6.0(P1): cross-poll MAP handoff — the same generation continuing with a changed
 // init segment between polls (the switch is only visible across playlist windows).
 if(kind==='progress'&&parsed.segments.length){
  const mk=parsed.segments[0].map?JSON.stringify(parsed.segments[0].map):null;
  if(mk!==null&&owner._hlsEvMapSig&&mk!==owner._hlsEvMapSig){
   ev.crossPollMapSwitches=(ev.crossPollMapSwitches||0)+1;
   if(parsed.segments[0].discontinuity===owner._hlsEvMapDisc)ev.crossPollMapSwitchesWithoutDiscontinuity=(ev.crossPollMapSwitchesWithoutDiscontinuity||0)+1;
  }
 }
 if(parsed.segments.length){
  const lastSeg=parsed.segments.at(-1);
  owner._hlsEvMapSig=lastSeg.map?JSON.stringify(lastSeg.map):null;
  owner._hlsEvMapDisc=lastSeg.discontinuity;
 }
 owner._hlsLlhlsIndicators=(owner._hlsLlhlsIndicators||0)+((parsed.llhls&&parsed.llhls.indicatorTags)||0);
 owner._hlsScte35Indicators=(owner._hlsScte35Indicators||0)+((parsed.scte35&&parsed.scte35.indicatorTags)||0);
 owner._hlsAdFilteredSegments=(owner._hlsAdFilteredSegments||0)+adFiltered;
 owner._hlsQueryInherited=(owner._hlsQueryInherited||0)+(parsed.queryInherited||0);
 owner._hlsTiming=timing;owner._skipBacklog=false;owner._hlsRecovery=rec;
 owner._hlsContext=context;owner._hlsEpoch=epoch;
 if(kind!=='stale')owner._hlsFirst=parsed.sequence;
 if(parsed.segments.length)owner._hlsLast=fresh?parsed.segments.at(-1).sequence:Math.max(owner._hlsLast??0,parsed.segments.at(-1).sequence);
 if(owner.seen.size>30000){let n=owner.seen.size-12000;for(const k of owner.seen){owner.seen.delete(k);if(--n<=0)break;}}
 return {added:incoming.length,missing,skipped:skip?parsed.segments.length:0};
}
function boxes(bytes){const out=[];let at=0;while(at<bytes.length){if(bytes.length-at<8)fail('HLS_BAD_MP4');const v=new DataView(bytes.buffer,bytes.byteOffset+at,bytes.length-at);let size=v.getUint32(0),header=8;if(size===1){if(bytes.length-at<16)fail('HLS_BAD_MP4');size=v.getUint32(8)*4294967296+v.getUint32(12);header=16;}else if(size===0)size=bytes.length-at;if(!Number.isSafeInteger(size)||size<header||at+size>bytes.length)fail('HLS_BAD_MP4');out.push(String.fromCharCode(...bytes.subarray(at+4,at+8)));at+=size;}return out;}
// v2.12.0(C-01): cat-catch "数据预处理" (TS image/header disguise stripping).
// Strips leading PNG/GIF/BMP/JPEG/WEBP/ID3 headers prepended before valid 188-byte
// MPEG-TS packets (0x47 sync byte on every 188-byte stride). Arbitrary non-disguised
// garbage is NOT stripped so fail-closed HLS_BAD_TS rejection remains intact.
function stripDisguisedTs(bytes){
 if(!bytes||!bytes.length)return {bytes,strippedBytes:0,magic:null};
 let magic=null;
 if(bytes.length>=8&&bytes[0]===0x89&&bytes[1]===0x50&&bytes[2]===0x4E&&bytes[3]===0x47)magic='png';
 else if(bytes.length>=6&&bytes[0]===0x47&&bytes[1]===0x49&&bytes[2]===0x46&&bytes[3]===0x38&&(bytes[4]===0x37||bytes[4]===0x39)&&bytes[5]===0x61)magic='gif';
 else if(bytes.length>=2&&bytes[0]===0x42&&bytes[1]===0x4D)magic='bmp';
 else if(bytes.length>=3&&bytes[0]===0xFF&&bytes[1]===0xD8&&bytes[2]===0xFF)magic='jpeg';
 else if(bytes.length>=12&&bytes[0]===0x52&&bytes[1]===0x49&&bytes[2]===0x46&&bytes[3]===0x46&&bytes[8]===0x57&&bytes[9]===0x45&&bytes[10]===0x42&&bytes[11]===0x50)magic='webp';
 else if(bytes.length>=3&&bytes[0]===0x49&&bytes[1]===0x44&&bytes[2]===0x33)magic='id3';
 if(!magic)return {bytes,strippedBytes:0,magic:null};
 const maxScan=Math.min(bytes.length-188,4096);
 for(let off=1;off<=maxScan;off++){
  if(bytes[off]===0x47&&(bytes.length-off)%188===0){
   let ok=true;
   for(let i=off+188;i<bytes.length;i+=188)if(bytes[i]!==0x47){ok=false;break;}
   if(ok)return {bytes:bytes.subarray(off),strippedBytes:off,magic};
  }
 }
 return {bytes,strippedBytes:0,magic};
}
/* ---------------------------------------------------------------- v2.37.0(N-01): software AES-128-CBC
   cat-catch lib/m3u8-decrypt.js と同一系譜(hls.js AESDecryptor)のテーブル駆動逆暗号。
   WebCrypto(crypto.subtle)が利用不可の環境(非セキュアコンテキスト等)や、WebCryptoが
   OperationErrorで拒否した場合のフォールバックとしてRecorderから呼ばれる。
   AES-CBC復号は仕様上決定的なため、正しい実装はWebCryptoとバイト一致する(NIST SP 800-38A
   KATとWebCryptoクロス検証をtests/test_v2160_core.cjsで常時実施)。 */
const AES_SBOX=new Uint8Array(256),AES_INV_SBOX=new Uint8Array(256),AES_SUB_MIX0=new Uint32Array(256),AES_SUB_MIX1=new Uint32Array(256),AES_SUB_MIX2=new Uint32Array(256),AES_SUB_MIX3=new Uint32Array(256),AES_INV_SUB_MIX0=new Uint32Array(256),AES_INV_SUB_MIX1=new Uint32Array(256),AES_INV_SUB_MIX2=new Uint32Array(256),AES_INV_SUB_MIX3=new Uint32Array(256);
(function initAesTables(){
 const d=new Uint32Array(256);let x=0,xi=0;
 for(let i=0;i<256;i++)d[i]=i<128?i<<1:(i<<1)^0x11b;
 for(let i=0;i<256;i++){
  let sx=xi^(xi<<1)^(xi<<2)^(xi<<3)^(xi<<4);sx=(sx>>>8)^(sx&0xff)^0x63;
  AES_SBOX[x]=sx;AES_INV_SBOX[sx]=x; // cat-catch initTableと同一(インデックスは実行カウンタx・鍵スケジュール展開は前方S-Boxを使用)
  const x2=d[x],x4=d[x2],x8=d[x4];
  let t=(d[sx]*0x101)^(sx*0x1010100);
  AES_SUB_MIX0[x]=(t<<24)|(t>>>8);AES_SUB_MIX1[x]=(t<<16)|(t>>>16);AES_SUB_MIX2[x]=(t<<8)|(t>>>24);AES_SUB_MIX3[x]=t;
  t=(x8*0x1010101)^(x4*0x10001)^(x2*0x101)^(x*0x1010100);
  AES_INV_SUB_MIX0[sx]=(t<<24)|(t>>>8);AES_INV_SUB_MIX1[sx]=(t<<16)|(t>>>16);AES_INV_SUB_MIX2[sx]=(t<<8)|(t>>>24);AES_INV_SUB_MIX3[sx]=t;
  if(!x){x=xi=1;}else{x=x2^d[d[d[x8^x2]]];xi^=d[d[xi]];}
 }
})();
const AES_RCON=[0x00,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36];
function aesWords16(b){const v=new DataView(b.buffer,b.byteOffset,b.byteLength);const out=new Uint32Array(4);for(let i=0;i<4;i++)out[i]=v.getUint32(i*4);return out;}
function aesExpandInvKey(key){
 const k=aesWords16(key);const ks=new Uint32Array(44);const iks=new Uint32Array(44);
 for(let i=0;i<4;i++)ks[i]=k[i];
 for(let i=4;i<44;i++){
  let t=ks[i-1];
  if(i%4===0){t=(t<<8)|(t>>>24);t=((AES_SBOX[(t>>>24)&0xff]<<24)|(AES_SBOX[(t>>>16)&0xff]<<16)|(AES_SBOX[(t>>>8)&0xff]<<8)|AES_SBOX[t&0xff])>>>0;t^=AES_RCON[i/4]<<24;}
  ks[i]=(ks[i-4]^t)>>>0;
 }
 for(let r=0;r<44;r++){
  const ksRow=44-r;let t;
  if(r&3)t=ks[ksRow];else t=ks[ksRow-4];
  if(r<4||ksRow<=4)iks[r]=t;
  /* cat-catch/hls.jsの等価逆暗号: invSubMix0[sbox[b]] == InvMixColumns(b) なる合成により、
     ラウンド鍵にはInvMixColumnsのみ適用される(sbox→invSubMixの二段構成)。 */
  else iks[r]=(AES_INV_SUB_MIX0[AES_SBOX[(t>>>24)&0xff]]^AES_INV_SUB_MIX1[AES_SBOX[(t>>>16)&0xff]]^AES_INV_SUB_MIX2[AES_SBOX[(t>>>8)&0xff]]^AES_INV_SUB_MIX3[AES_SBOX[t&0xff]])>>>0;
 }
 return iks;
}
/* PKCS7(RFC 5652 6.3)厳密検証付き除去。WebCryptoは成功時に自動除去するため、
   ソフトウェア経路も同一セマンティクスに揃える(不正パディングはfail-closed)。 */
function removePkcs7Padding(bytes){
 const n=bytes[bytes.length-1];
 if(!n||n>16)fail('HLS_DECRYPT_PADDING');
 for(let i=bytes.length-n;i<bytes.length;i++)if(bytes[i]!==n)fail('HLS_DECRYPT_PADDING');
 return bytes.subarray(0,bytes.length-n);
}
function decryptCbc(key,iv,bytes,opts){
 const removePadding=!opts||opts.padding!==false;
 if(!(key&&key.length===16))fail('HLS_DECRYPT_KEY');
 if(!(iv&&iv.length===16))fail('HLS_DECRYPT_IV');
 if(!bytes||!bytes.length||bytes.length%16)fail('HLS_DECRYPT_BLOCK_SIZE');
 const iks=aesExpandInvKey(key),iV=aesWords16(iv);
 let iV0=iV[0],iV1=iV[1],iV2=iV[2],iV3=iV[3];
 const input=new Int32Array(bytes.buffer,bytes.byteOffset,bytes.length>>2);
 const output=new Int32Array(input.length);
 const swap=w=>(w<<24)|((w&0xff00)<<8)|((w&0xff0000)>>8)|(w>>>24);
 for(let off=0;off<input.length;off+=4){
  let s0=swap(input[off])^iks[0],s1=swap(input[off+3])^iks[1],s2=swap(input[off+2])^iks[2],s3=swap(input[off+1])^iks[3];
  let t0,t1,t2,t3,ksRow=4;
  for(let r=1;r<10;r++){
   t0=AES_INV_SUB_MIX0[s0>>>24]^AES_INV_SUB_MIX1[(s1>>>16)&0xff]^AES_INV_SUB_MIX2[(s2>>>8)&0xff]^AES_INV_SUB_MIX3[s3&0xff]^iks[ksRow];
   t1=AES_INV_SUB_MIX0[s1>>>24]^AES_INV_SUB_MIX1[(s2>>>16)&0xff]^AES_INV_SUB_MIX2[(s3>>>8)&0xff]^AES_INV_SUB_MIX3[s0&0xff]^iks[ksRow+1];
   t2=AES_INV_SUB_MIX0[s2>>>24]^AES_INV_SUB_MIX1[(s3>>>16)&0xff]^AES_INV_SUB_MIX2[(s0>>>8)&0xff]^AES_INV_SUB_MIX3[s1&0xff]^iks[ksRow+2];
   t3=AES_INV_SUB_MIX0[s3>>>24]^AES_INV_SUB_MIX1[(s0>>>16)&0xff]^AES_INV_SUB_MIX2[(s1>>>8)&0xff]^AES_INV_SUB_MIX3[s2&0xff]^iks[ksRow+3];
   s0=t0;s1=t1;s2=t2;s3=t3;ksRow+=4;
  }
  t0=((AES_INV_SBOX[s0>>>24]<<24)^(AES_INV_SBOX[(s1>>>16)&0xff]<<16)^(AES_INV_SBOX[(s2>>>8)&0xff]<<8)^AES_INV_SBOX[s3&0xff])^iks[ksRow];
  t1=((AES_INV_SBOX[s1>>>24]<<24)^(AES_INV_SBOX[(s2>>>16)&0xff]<<16)^(AES_INV_SBOX[(s3>>>8)&0xff]<<8)^AES_INV_SBOX[s0&0xff])^iks[ksRow+1];
  t2=((AES_INV_SBOX[s2>>>24]<<24)^(AES_INV_SBOX[(s3>>>16)&0xff]<<16)^(AES_INV_SBOX[(s0>>>8)&0xff]<<8)^AES_INV_SBOX[s1&0xff])^iks[ksRow+2];
  t3=((AES_INV_SBOX[s3>>>24]<<24)^(AES_INV_SBOX[(s0>>>16)&0xff]<<16)^(AES_INV_SBOX[(s1>>>8)&0xff]<<8)^AES_INV_SBOX[s2&0xff])^iks[ksRow+3];
  output[off]=swap(t0^iV0);output[off+1]=swap(t3^iV1);output[off+2]=swap(t2^iV2);output[off+3]=swap(t1^iV3);
  iV0=swap(input[off]);iV1=swap(input[off+1]);iV2=swap(input[off+2]);iV3=swap(input[off+3]);
 }
 const out=new Uint8Array(output.buffer);
 return removePadding?removePkcs7Padding(out):out;
}
/* ---------------------------------------------------------------- v2.37.0(N-03): TS continuity-counter audit
   ISO/IEC 13818-1 2.4.3.2 の連続性規則をパケット単位で検査する(cat-catch/hls.jsが
   プレイリスト断片のccグループ化に使う知識のパケットレベル適用)。監査のみで非破壊:
   欠落検出(forwardJumps)・重複(duplicates)・逆方向(backwardJumps)・TEIを計数し、
   セグメント廃棄は一切行わない。JS/Python鏡像実装で証拠スキーマは完全一致。 */
function emptyCcAudit(){return {segmentsAudited:0,bytesAudited:0,packets:0,pids:0,payloadPackets:0,noPayloadPackets:0,afcReserved:0,teiPackets:0,continuityOk:0,duplicates:0,forwardJumps:0,backwardJumps:0,lostPacketEstimate:0,maxSingleJump:0,perPid:{},perPidTruncated:false};}
function auditCc(bytes){
 const seg=emptyCcAudit();
 if(!bytes||bytes.length<188||bytes.length%188)return seg;
 seg.packets=bytes.length/188;
 const state={};let distinct=0;
 for(let at=0;at<bytes.length;at+=188){
  const b1=bytes[at+1],b2=bytes[at+2],b3=bytes[at+3];
  const pid=((b1&0x1f)<<8)|b2;
  const afc=(b3>>4)&3,cc=b3&0xf;
  const tei=(b1&0x80)!==0;
  if(tei)seg.teiPackets++;
  let st=state[pid];
  if(!st){st=state[pid]={lastCc:-1,packets:0,payload:0,ok:0,dup:0,fwd:0,back:0,lost:0};distinct++;}
  st.packets++;
  if(afc===0){seg.afcReserved++;continue;}
  if(afc===2){seg.noPayloadPackets++;continue;}
  seg.payloadPackets++;st.payload++;
  if(st.lastCc<0){st.lastCc=cc;continue;}
  const delta=(cc-st.lastCc)&0xf;
  if(delta===1)seg.continuityOk++,st.ok++;
  else if(delta===0)seg.duplicates++,st.dup++;
  else if(delta<8){seg.forwardJumps++;st.fwd++;const lost=delta-1;seg.lostPacketEstimate+=lost;st.lost+=lost;if(lost>seg.maxSingleJump)seg.maxSingleJump=lost;}
  else{seg.backwardJumps++;st.back++;}
  st.lastCc=cc;
 }
 seg.pids=distinct;
 for(const pid in state){const st=state[pid];seg.perPid[pid]={pid:parseInt(pid,10),packets:st.packets,payload:st.payload,ok:st.ok,dup:st.dup,fwd:st.fwd,back:st.back,lost:st.lost};}
 return seg;
}
function mergeCcEvidence(acc,seg){
 acc.segmentsAudited++;acc.bytesAudited+=seg.packets*188;
 for(const k of ['packets','pids','payloadPackets','noPayloadPackets','afcReserved','teiPackets','continuityOk','duplicates','forwardJumps','backwardJumps','lostPacketEstimate'])acc[k]+=seg[k]||0;
 if(seg.maxSingleJump>acc.maxSingleJump)acc.maxSingleJump=seg.maxSingleJump;
 for(const pid in seg.perPid){
  const s=seg.perPid[pid];let dst=acc.perPid[pid];
  if(!dst){dst=acc.perPid[pid]={pid:parseInt(pid,10),packets:0,payload:0,ok:0,dup:0,fwd:0,back:0,lost:0};acc._pidCount=(acc._pidCount||0)+1;}
  for(const k of ['packets','payload','ok','dup','fwd','back','lost'])dst[k]+=s[k]||0;
 }
 return acc;
}
function ccEvidence(acc){
 if(!acc)return undefined;
 const out={segmentsAudited:acc.segmentsAudited,bytesAudited:acc.bytesAudited,packets:acc.packets,pids:acc.pids,payloadPackets:acc.payloadPackets,noPayloadPackets:acc.noPayloadPackets,afcReserved:acc.afcReserved,teiPackets:acc.teiPackets,continuityOk:acc.continuityOk,duplicates:acc.duplicates,forwardJumps:acc.forwardJumps,backwardJumps:acc.backwardJumps,lostPacketEstimate:acc.lostPacketEstimate,maxSingleJump:acc.maxSingleJump,
  perPid:Object.values(acc.perPid).sort((a,b)=>b.packets-a.packets||a.pid-b.pid).slice(0,16).map(e=>({pid:e.pid,packets:e.packets,payload:e.payload,ok:e.ok,dup:e.dup,fwd:e.fwd,back:e.back,lost:e.lost}))};
 out.perPidTruncated=Object.keys(acc.perPid).length>16;
 return out;
}
function validate(bytes,kind){
 if(!bytes||!bytes.length)fail('HLS_EMPTY_BODY');
 if(kind==='ts'){
  if(bytes.length%188||bytes[0]!==0x47){const st=stripDisguisedTs(bytes);if(st.strippedBytes>0)bytes=st.bytes;}
  if(bytes.length%188||bytes[0]!==0x47)fail('HLS_BAD_TS');
  for(let i=188;i<bytes.length;i+=188)if(bytes[i]!==0x47)fail('HLS_BAD_TS');
 }else{
  const b=boxes(bytes);
  if(kind==='init'&&(!b.includes('ftyp')||!b.includes('moov')))fail('HLS_BAD_INIT');
  if(kind==='fragment'&&(!b.includes('moof')||!b.includes('mdat')))fail('HLS_BAD_FRAGMENT');
 }
 return bytes;
}
function createTransfer(fetchImpl=fetch,timeout=15000){
 const pending=new Set();let closed=false;
 return {abort(){closed=true;for(const e of pending)e.abort();},get pending(){return pending.size;},get closed(){return closed;},
  async request(d,limit=32*1048576){
   if(closed)return {status:0,error:'HLS_ABORTED'};
   const controller=new AbortController();let timer,reader,response;let rejectDeadline;
   const deadline=new Promise((_,reject)=>rejectDeadline=reject);
   const entry={abort(){controller.abort();rejectDeadline(Error('HLS_ABORTED'));}};pending.add(entry);
   timer=setTimeout(()=>{controller.abort();rejectDeadline(Error('HLS_TIMEOUT'));},timeout);
   try{
    const operation=(async()=>{
     const headers=d.range?{Range:'bytes='+d.range.offset+'-'+(d.range.offset+d.range.length-1)}:{};
     if(d.butter){if(typeof d.butter!=='string'||/[\r\n]/.test(d.butter))fail('HLS_BAD_AUTH_HEADER');headers.Butter=d.butter;}
     const res=response=await fetchImpl(d.uri,{cache:'no-store',headers,signal:controller.signal});
     if(controller.signal.aborted)fail('HLS_ABORTED');
     if(d.range&&res.status===200)fail('HLS_RANGE_IGNORED');
     if(res.status!==200&&res.status!==206){if(res.body)await res.body.cancel();return {status:res.status,retryAfter:res.headers.get('retry-after')};}
     const encoded=res.headers.get('content-encoding')&&!/^identity$/i.test(res.headers.get('content-encoding'));
     if(d.range&&encoded)fail('HLS_ENCODING_UNSUPPORTED');
     if(!d.range&&res.status===206)fail('HLS_UNEXPECTED_RANGE');
     if(d.range){const m=/^bytes (\d+)-(\d+)\/(\d+|\*)$/.exec(res.headers.get('content-range')||'');if(!m||Number(m[1])!==d.range.offset||Number(m[2])!==d.range.offset+d.range.length-1||(m[3]!=='*'&&Number(m[3])<=Number(m[2])))fail('HLS_CONTENT_RANGE');}
     const cl=encoded?null:res.headers.get('content-length');if(cl!==null&&(!/^\d+$/.test(cl)||Number(cl)>limit))fail('HLS_BODY_LIMIT');
     const chunks=[];let size=0;
     if(!res.body||!res.body.getReader)fail('HLS_STREAM_UNAVAILABLE');reader=res.body.getReader();
     while(true){if(controller.signal.aborted)fail('HLS_ABORTED');const value=await reader.read();if(value.done)break;size+=value.value.byteLength;if(size>limit||(d.range&&size>d.range.length))fail('HLS_BODY_LIMIT');chunks.push(value.value);}
     if(cl!==null&&size!==Number(cl))fail('HLS_BODY_LENGTH');if(d.range&&size!==d.range.length)fail('HLS_RANGE_LENGTH');
     const bytes=new Uint8Array(size);let at=0;for(const chunk of chunks){bytes.set(chunk,at);at+=chunk.byteLength;}return {status:res.status,bytes};
    })();
    return await Promise.race([operation,deadline]);
   }catch(e){controller.abort();return {status:0,error:/^HLS_[A-Z_]+$/.test(e.message)?e.message:'HLS_NETWORK'};}
   finally{clearTimeout(timer);pending.delete(entry);if(reader||response&&response.body)try{const p=reader?reader.cancel():response.body.cancel();if(p&&p.catch)p.catch(()=>{});}catch(e){}}
  }
 };
}
async function fetchItem(owner,item){
 if(!owner._hlsTransfer)owner._hlsTransfer=createTransfer();
 const transfer=owner._hlsTransfer,d=item.hls,generation=owner._hlsGeneration||0;
 let init=null;const mapKey=descriptorKey(d.map);
 if(d.map){
  if(owner._hlsMapKey===mapKey)init=owner._hlsMapBytes;
  else{const r=await transfer.request(d.map,8*1048576);if(r.error||!r.bytes)return r;
   try{init=validate(r.bytes,'init');}catch(e){return {status:0,error:e.message};}
   if(!alive(owner,generation))return {error:'HLS_ABORTED',status:0};
   owner._hlsMapKey=mapKey;owner._hlsMapBytes=init;
  }
 }
 const r=await transfer.request(d);if(r.error||!r.bytes)return r;
 let cleanBytes=r.bytes;
 if(!d.map&&cleanBytes&&(cleanBytes.length%188||cleanBytes[0]!==0x47)){
  const st=stripDisguisedTs(cleanBytes);
  if(st.strippedBytes>0){
   cleanBytes=st.bytes;
   owner._hlsDisguiseStripped=(owner._hlsDisguiseStripped||0)+1;
   owner._hlsDisguiseBytes=(owner._hlsDisguiseBytes||0)+st.strippedBytes;
  }
 }
 try{cleanBytes=validate(cleanBytes,d.map?'fragment':'ts');}catch(e){return {status:0,error:e.message};}
 /* v2.37.0(N-03): TS連続性カウンタ監査(平文TSのみ・監査のみで非破壊)。 */
 if(!d.map&&cleanBytes.length&&cleanBytes.length%188===0&&cleanBytes[0]===0x47){
  try{mergeCcEvidence(owner._hlsCcAudit||(owner._hlsCcAudit=emptyCcAudit()),auditCc(cleanBytes));}catch(e){}
 }
 const splitDisc=!!(owner&&typeof owner.splitOnDiscontinuity==='function'&&owner.splitOnDiscontinuity());
 return {...r,bytes:cleanBytes,init,boundary:partBoundary(d,splitDisc)};
}
function abort(owner){owner._hlsGeneration=(owner._hlsGeneration||0)+1;if(owner._hlsTransfer)owner._hlsTransfer.abort();if(owner._hlsPlaylistTransfer)owner._hlsPlaylistTransfer.abort();}
function reset(owner,keepUris){abort(owner);owner._hlsTransfer=null;owner._hlsPlaylistTransfer=null;owner._hlsMapKey=null;owner._hlsMapBytes=null;owner._hlsContext=null;owner._hlsFirst=undefined;owner._hlsLast=undefined;owner._hlsBoundary=null;owner._hlsLastDiscKey=undefined;owner.mediaFormat='ts';/* v2.5.0: keepUris=true (standby resume) keeps the recorded-path cache so the
   recovering window is not duplicated; a fresh start() clears it intentionally. */
 if(keepUris!==true)owner._hlsUris=null;
 if(owner._hlsWriteAudit)owner._hlsWriteAudit.last=null;}
function alive(owner,generation){return (owner._hlsGeneration||0)===generation&&!owner.stopped&&!(owner.rec&&owner.rec.stopped)&&(!owner.rec||owner.running!==false);}
async function append(owner,item,result,generation=owner._hlsGeneration||0){
 if(!alive(owner,generation))return false;
 if(!item.hls){await owner.pushData(result.data);return alive(owner,generation);}
 const cont=owner._hlsContinuity||(owner._hlsContinuity={discontinuityMergedCount:0,discontinuitySplitCount:0});
 const discKey=item.hls.epoch+':'+item.hls.discontinuity;
 if(owner.partOpen&&owner._hlsLastDiscKey!==undefined&&owner._hlsLastDiscKey!==discKey){
  if(owner._hlsBoundary!==result.boundary)cont.discontinuitySplitCount++;
  else cont.discontinuityMergedCount++;
 }
 owner._hlsLastDiscKey=discKey;
 if(owner.partOpen&&owner._hlsBoundary!==result.boundary){
  const ev=owner._hlsPartBoundaries||(owner._hlsPartBoundaries={hlsBoundary:0});
  ev.hlsBoundary=(ev.hlsBoundary||0)+1;
  await owner.closePart();
 }
 if(!alive(owner,generation))return false;
 owner.mediaFormat=item.hls.map?'mp4':'ts';owner._hlsBoundary=result.boundary;
 const wasPartOpen=!!owner.partOpen;
 if(!owner.partOpen&&result.init)await owner.pushData(result.init);
 if(!alive(owner,generation))return false;
 await owner.pushData(result.data);
 if(!alive(owner,generation))return false;
 // pushData accepted the bytes; a later file write/rename can still fail.
 noteAccepted(owner,item,result.data.byteLength??result.data.length??0,
  !wasPartOpen&&result.init?(result.init.byteLength??result.init.length??0):0);
 return true;
}
function validateWebVtt(text){
 if(typeof text!=='string')fail('WEBVTT_HEADER');
 const clean=text.replace(/^\uFEFF/,'').replace(/\r\n/g,'\n').replace(/\r/g,'\n');
 const blocks=clean.split(/\n{2,}/);
 const header=(blocks[0]||'').trim();
 if(!/^WEBVTT(?:[ \t\n]|$)/.test(header))fail('WEBVTT_HEADER');
 let timestampMap=null;
 for(const line of header.split('\n').slice(1)){
  if(line.startsWith('X-TIMESTAMP-MAP='))timestampMap=line.slice(16).trim();
 }
 const cues=[];
 const timingRe=/^(?:(?:\d{2,}:)?\d{2}:\d{2}\.\d{3})\s+-->\s+(?:(?:\d{2,}:)?\d{2}:\d{2}\.\d{3})(?:[ \t].*)?$/;
 for(let i=1;i<blocks.length;i++){
  const raw=blocks[i].trim();
  if(!raw||raw.startsWith('NOTE')||raw.startsWith('STYLE')||raw.startsWith('REGION'))continue;
  const lines=raw.split('\n');
  let timingIdx=-1,cueId=null;
  if(timingRe.test(lines[0]))timingIdx=0;
  else if(lines.length>=2&&timingRe.test(lines[1])){cueId=lines[0];timingIdx=1;}
  if(timingIdx<0)fail('WEBVTT_BAD_CUE');
  const timing=lines[timingIdx].trim();
  const payload=lines.slice(timingIdx+1).join('\n').trim();
  if(!payload)continue;
  cues.push({id:cueId,timing,payload});
 }
 return {valid:true,timestampMap,cues};
}
function mergeWebVttSegments(segments){
 if(!Array.isArray(segments)||!segments.length)fail('WEBVTT_EMPTY');
 const seen=new Set(),merged=[];
 let duplicatesRemoved=0,timestampMap=null;
 for(const seg of segments){
  const v=validateWebVtt(seg);
  if(timestampMap===null&&v.timestampMap)timestampMap=v.timestampMap;
  for(const cue of v.cues){
   const key=cue.timing+'\n'+cue.payload;
   if(seen.has(key)){duplicatesRemoved++;continue;}
   seen.add(key);
   merged.push(cue);
  }
 }
 const head=timestampMap?'WEBVTT\nX-TIMESTAMP-MAP='+timestampMap:'WEBVTT';
 const body=merged.map(c=>(c.id?c.id+'\n':'')+c.timing+'\n'+c.payload).join('\n\n');
 const text=body?head+'\n\n'+body+'\n':head+'\n';
 return {segmentsProcessed:segments.length,cuesMerged:merged.length,duplicatesRemoved,timestampMap,text};
}
return {parse,enqueue,timingEvidence,attrs,descriptorKey,partBoundary,stripDisguisedTs,validate,createTransfer,fetchItem,append,abort,reset,alive,decryptCbc,removePkcs7Padding,auditCc,mergeCcEvidence,ccEvidence,emptyCcAudit,writeEvidence,noteTerminal,clearWriteEvidence,startPartAudit,takePartAudit,validateWebVtt,mergeWebVttSegments};
});

  const HLS = globalThis.RspHlsTransport;

// Incremental SHA-256 (FIPS 180-4). Independent implementation for local
// integrity checks. Fixed working state; Blob reads are capped at 1 MiB.
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.RspSha256=api;})(globalThis,function(){
 'use strict';
 const K=new Uint32Array([
  0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
  0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
  0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
  0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
  0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
  0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
  0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
  0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]);
 const rotr=(x,n)=>(x>>>n)|(x<<(32-n));
 class Sha256 {
  constructor(){this.h=new Uint32Array([0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]);this.w=new Uint32Array(64);this.buffer=new Uint8Array(64);this.used=0;this.bytes=0;this.finished=false;}
  block(b,off){
   const w=this.w;
   for(let i=0;i<16;i++){const j=off+i*4;w[i]=(b[j]<<24)|(b[j+1]<<16)|(b[j+2]<<8)|b[j+3];}
   for(let i=16;i<64;i++){const x=w[i-15],y=w[i-2];w[i]=(w[i-16]+(rotr(x,7)^rotr(x,18)^(x>>>3))+w[i-7]+(rotr(y,17)^rotr(y,19)^(y>>>10)))>>>0;}
   let [a,b0,c,d,e,f,g,h]=this.h;
   for(let i=0;i<64;i++){
    const t1=(h+(rotr(e,6)^rotr(e,11)^rotr(e,25))+((e&f)^(~e&g))+K[i]+w[i])>>>0;
    const t2=((rotr(a,2)^rotr(a,13)^rotr(a,22))+((a&b0)^(a&c)^(b0&c)))>>>0;
    h=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b0;b0=a;a=(t1+t2)>>>0;
   }
   const v=[a,b0,c,d,e,f,g,h];for(let i=0;i<8;i++)this.h[i]=(this.h[i]+v[i])>>>0;
  }
  update(data){
   if(this.finished)throw Error('HASH_FINALIZED');
   if(!ArrayBuffer.isView(data)||data.BYTES_PER_ELEMENT!==1)throw Error('HASH_INPUT');
   if(!Number.isSafeInteger(this.bytes+data.byteLength))throw Error('HASH_SIZE');this.bytes+=data.byteLength;
   let at=0;
   if(this.used){const n=Math.min(64-this.used,data.length);this.buffer.set(data.subarray(0,n),this.used);this.used+=n;at=n;if(this.used===64){this.block(this.buffer,0);this.used=0;}}
   while(at+64<=data.length){this.block(data,at);at+=64;}
   if(at<data.length){this.buffer.set(data.subarray(at));this.used=data.length-at;}
   return this;
  }
  digest(){
   if(this.finished)return this.hex;
   const bytes=this.bytes,pad=new Uint8Array(1+((56-(bytes+1)%64+64)%64)+8);pad[0]=128;
   const view=new DataView(pad.buffer);view.setUint32(pad.length-8,Math.floor(bytes/0x20000000),false);view.setUint32(pad.length-4,(bytes*8)>>>0,false);
   this.update(pad);this.finished=true;this.hex=Array.from(this.h,n=>n.toString(16).padStart(8,'0')).join('');return this.hex;
  }
 }
 async function hashBlob(file){
  if(!file||!Number.isSafeInteger(file.size)||file.size<0||typeof file.slice!=='function')throw Error('HASH_BLOB');
  const hash=new Sha256();let n=0;
  for(let at=0;at<file.size;at+=1048576){const end=Math.min(at+1048576,file.size),buf=await file.slice(at,end).arrayBuffer();if(buf.byteLength!==end-at)throw Error('HASH_SHORT_READ');hash.update(new Uint8Array(buf));
   if(++n%8===0&&typeof setTimeout==='function')await new Promise(r=>setTimeout(r,0));
  }
  return hash.digest();
 }
 return {Sha256,hashBlob};
});

  // v2.42.4 per-part audit correlation. Only numerical evidence and local part hashes.
  // Accepted HLS bytes are not proof that a completed media file will decode.
  const rspPartCommit=(function(){'use strict';
    const counters=['queued','accepted','terminal','acceptedMediaBytes','acceptedInitBytes',
      'suspectedManifestMissing','declaredGaps','backlogSkipped',
      'sequenceDiscontinuities','suspectedAcceptedSequenceGaps'];
    function snapshot(owner,transport){
      if(!transport||typeof transport.writeEvidence!=='function')return null;
      const report=transport.writeEvidence(owner),point={schema:1};
      for(const k of counters){const v=report[k];point[k]=Number.isSafeInteger(v)&&v>=0?v:0;}
      return Object.freeze(point);
    }
    function interval(before,after){
      if(!before||!after)return {schema:1,provenance:'no_hls_counter_snapshot',scope:'part_interval',countersAvailable:false,fileCommitted:false,avDecoded:false};
      const delta={};let reset=false;
      for(const k of counters){const a=before[k],b=after[k];
        if(!Number.isSafeInteger(a)||!Number.isSafeInteger(b)||a<0||b<0||b<a){reset=true;break;}
        delta[k]=b-a;
      }
      return reset?{schema:1,provenance:'counter_reset_or_unavailable',scope:'part_interval',countersAvailable:false,fileCommitted:false,avDecoded:false}:
        {schema:1,provenance:'writer_acceptance_counter_interval',scope:'part_interval',countersAvailable:true,
          attribution:'approximate_boundary_snapshot; queued segments can predate part open; acceptance can race part close',
          ...delta,fileCommitted:false,avDecoded:false};
    }
    function normPartSeq(ps){
      if(!ps||typeof ps!=='object')return undefined;
      const nat=v=>Number.isSafeInteger(v)&&v>=0?v:0;
      const optInt=v=>Number.isSafeInteger(v)&&v>=0?v:null;
      return {
        attribution:'exact_pushData_part_binding',
        segments:nat(ps.segments),
        mediaBytes:nat(ps.mediaBytes),
        initBytes:nat(ps.initBytes),
        firstSequence:optInt(ps.firstSequence),
        lastSequence:optInt(ps.lastSequence),
        firstEpoch:optInt(ps.firstEpoch),
        lastEpoch:optInt(ps.lastEpoch),
        firstDiscontinuity:optInt(ps.firstDiscontinuity),
        lastDiscontinuity:optInt(ps.lastDiscontinuity),
        sequenceGaps:nat(ps.sequenceGaps),
        discontinuities:nat(ps.discontinuities)
      };
    }
    function correlate(entry,from,to,result,track,partSeq){
      const counters=interval(from,to),confirmed=!!(result&&result.confirmed),stage=result&&result.stage||'unknown';
      const sha=typeof(result&&result.hashHex)==='string'&&/^[a-f0-9]{64}$/.test(result.hashHex)?result.hashHex:null;
      const fileClosed=confirmed&&stage==='FILE_CLOSED';
      const sinkReceipt=confirmed?(fileClosed?'file_closed_and_readback':'browser_reported_complete'):
        stage==='ERROR'?'write_failed':'not_confirmed';
      const ck=result&&result.checkpoint;
      const check=ck&&fileClosed&&ck.status==='complete'&&Number.isSafeInteger(ck.chunks)&&ck.chunks>=0&&
        Number.isSafeInteger(ck.committedBytes)&&ck.committedBytes>=0&&ck.committedBytes===entry.bytes?
        {chunks:ck.chunks,committedBytes:ck.committedBytes,status:'complete',source:'chunk_hash_verified_at_checkpoint'}:undefined;
      const seqRange=normPartSeq(partSeq);
      const proof={schema:1,track:track==='audio'?'audio':'video',
        provenance:'recording_part_writer_receipt_and_counter_interval',
        acceptedHls:counters,sinkReceipt,fileCommitted:fileClosed,
        browserReportedComplete:confirmed&&!fileClosed,sha256:sha,
        sha256Provenance:sha?(fileClosed?'saved_file_readback':'pre_download_blob'):null,
        ...(check?{checkpoint:check}:{}),...(seqRange?{partSequenceRange:seqRange}:{}),avDecoded:false};
      if(entry&&typeof entry==='object')entry.partIntegrity=proof;
      return proof;
    }
    return Object.freeze({snapshot,interval,correlate});
  })();

  /* Shared per-part writer: an asynchronously opened writer belongs only to this part. */
  function recTrackSave(owner, promise) {
    if (!owner._saveJobs) owner._saveJobs = new Set();
    owner._saveJobs.add(promise);
    promise.then(() => owner._saveJobs.delete(promise), () => owner._saveJobs.delete(promise));
    return promise;
  }
  async function recWaitSaves(owner) {
    while (owner._saveJobs && owner._saveJobs.size) await Promise.allSettled([...owner._saveJobs]);
  }
  /* v2.48.0: Sanitize persisted part entries across browser reload/crash resume (zero URLs/secrets, bounded size). */
  function recSanitizePersistedParts(list) {
    if (!Array.isArray(list)) return [];
    const out = [];
    for (const raw of list.slice(-128)) {
      if (!raw || typeof raw !== "object") continue;
      const file = typeof raw.file === "string" ? raw.file.slice(0, 260) : "";
      const ext = typeof raw.ext === "string" ? raw.ext.slice(0, 12) : "ts";
      const bytes = Number.isSafeInteger(raw.bytes) && raw.bytes > 0 ? raw.bytes : 0;
      if (!file || !bytes || /^(?:https?|wss?|blob|data):/i.test(file) || /[\\/]/.test(file)) continue;
      const entry = {
        file,
        ext,
        bytes,
        segments: Number.isSafeInteger(raw.segments) && raw.segments >= 0 ? raw.segments : 0,
        startedAt: typeof raw.startedAt === "string" ? raw.startedAt.slice(0, 40) : "",
        endedAt: typeof raw.endedAt === "string" ? raw.endedAt.slice(0, 40) : "",
        saveState: typeof raw.saveState === "string" ? raw.saveState.slice(0, 32) : "FILE_CLOSED",
        hashState: typeof raw.hashState === "string" ? raw.hashState.slice(0, 32) : "unavailable",
        structureValidated: !!raw.structureValidated,
        resumedFromPriorRun: true
      };
      if (raw.kind === "audio") entry.kind = "audio";
      if (typeof raw.sha256 === "string" && /^[0-9a-f]{64}$/i.test(raw.sha256)) entry.sha256 = raw.sha256.toLowerCase();
      if (typeof raw.ledgerStatus === "string") entry.ledgerStatus = raw.ledgerStatus.slice(0, 32);
      if (Array.isArray(raw.stages)) entry.stages = raw.stages.slice(0, 16);
      if (raw.partIntegrity && typeof raw.partIntegrity === "object") entry.partIntegrity = raw.partIntegrity;
      out.push(entry);
    }
    return out;
  }
  // Recovery uses committed chunks alongside the final writer. Only a journal
  // closed after verified chunks advertises recoverable bytes. No remote URLs.
  class RecCheckpointStore {
    constructor(directory,name,ext,options={}) {
      this.name=name;this.ext=ext;this.parts=[];this.bytes=0;this.pending=0;this.writer=null;
      this.limit=options.checkpointBytes||64*1048576;this.interval=options.checkpointMs||30000;this.last=Date.now();
      this.ready=directory.getDirectoryHandle('rsp-recovery',{create:true}).then(d=>d.getDirectoryHandle(name+'.checkpoint',{create:true}));
      // ready is awaited by write/finish; attach a handler for early open failure.
      this.ready.catch(()=>{});
    }
    async write(data) {
      const dir=await this.ready;
      if(!this.writer){this.current='chunk-'+String(this.parts.length+1).padStart(8,'0')+'.bin';this.handle=await dir.getFileHandle(this.current,{create:true});this.writer=await this.handle.createWritable();this.chunkHash=new RspSha256.Sha256();}
      await this.writer.write(data);this.chunkHash.update(data);this.pending+=data.byteLength;
      if(this.pending>=this.limit||Date.now()-this.last>=this.interval)await this.checkpoint();
    }
    async journal(status) {
      const dir=await this.ready;const h=await dir.getFileHandle('journal.json',{create:true});const w=await h.createWritable();
      try{await w.write(JSON.stringify({schema:2,file:this.name,ext:this.ext,status,committedBytes:this.bytes,parts:this.parts,updatedAt:new Date().toISOString()}));await w.close();}
      catch(e){try{await w.abort();}catch(ignore){}throw e;}
    }
    async checkpoint() {
      if(!this.writer||!this.pending)return;
      await this.writer.close();this.writer=null;
      const file=await this.handle.getFile();if(file.size!==this.pending)throw Error('CHECKPOINT_SIZE_MISMATCH');
      const sha256=await RspSha256.hashBlob(file);
      if(sha256!==this.chunkHash.digest())throw Error('CHECKPOINT_HASH_MISMATCH');
      this.parts.push({file:this.current,bytes:this.pending,sha256});this.bytes+=this.pending;this.pending=0;
      if(this.parts.length>4096)throw Error('CHECKPOINT_PART_LIMIT');
      await this.journal('active');this.last=Date.now();
    }
    async finish(){await this.checkpoint();}
    async complete(){await this.journal('complete');}
    async abort(){if(this.writer)try{await this.writer.abort();}catch(ignore){}this.writer=null;}
  }
  class RecPartSink {
    constructor(name, directory, ext, options={}) {
      const suffix = typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID().replace(/-/g,'') : Date.now().toString(36)+Math.random().toString(36).slice(2);
      this.name = name.replace(/(\.[^.]+)$/, '_'+suffix+'$1');
      this.ext = ext; this.bytes = 0; this.chunks = []; this.writer = null; this.error = null; this.closed = false;
      this.checkpoints=directory && typeof directory.getDirectoryHandle==='function' && ['ts','mp4'].includes(ext) ? new RecCheckpointStore(directory,this.name,ext,options) : null;
      this.tail = Promise.resolve();
      this.ready = directory ? directory.getFileHandle(this.name, {create:true}).then(fh => {
        this.handle=fh; return fh.createWritable();
      }).then(w => {
        this.writer=w; const chunks=this.chunks;this.chunks=[];for(const chunk of chunks)this.enqueue(chunk);
      }).catch(() => { this.writer=null; }) : Promise.resolve();
    }
    enqueue(chunk) {
      this.tail=this.tail.then(async()=>{if(this.error)return;try{await this.writer.write(chunk);if(this.checkpoints)await this.checkpoints.write(chunk);}catch(e){this.error=e;}});
    }
    push(chunk) {
      if(this.closed)throw Error('PART_CLOSED');
      this.bytes+=chunk.length;
      if(this.writer)this.enqueue(chunk);else this.chunks.push(chunk);
    }
    // Producers await this before fetching another segment; slow disks cannot build
    // an unbounded chain of writes. Open failure keeps the bounded Blob fallback.
    async flush() {
      await this.ready; await this.tail;
      if (this.error) throw Error('PART_WRITE_FAILED');
    }
    continuousDisk() {
      return !!this.writer && !this.error && !this.closed && (this.ext==='ts'||this.ext==='mp4');
    }
    async close() {
      if(this.closed)throw Error('PART_ALREADY_CLOSED');this.closed=true;
      await this.ready;await this.tail;
      if(this.error){try{await this.writer.abort();}catch(e){}if(this.checkpoints)await this.checkpoints.abort();throw Error('PART_WRITE_FAILED');}
      if(this.writer){
        try{if(this.checkpoints)await this.checkpoints.finish();await this.writer.close();const file=await this.handle.getFile();if(file.size!==this.bytes)throw Error('PART_SIZE_MISMATCH');
          if(this.checkpoints)await this.checkpoints.complete();
          /* v2.5.0(P1): 保存確定イベント契約 — HASHED段階の実測値(計算不能時はnullを返し、
             偽のハッシュ段階を記録しない。計算は保存完了後に行い、保存経路を遅らせない) */
          const hashHex=await recSha256Hex(file);
          if(typeof RECENV.backupPart==='function'&&this.bytes>0)try{await RECENV.backupPart(file,this.name,{file:this.name,bytes:this.bytes});}catch(e){}
          return {confirmed:true,stage:'FILE_CLOSED',file:this.name,hashHex,...(this.checkpoints?{checkpoint:{status:'complete',chunks:this.checkpoints.parts.length,committedBytes:this.checkpoints.bytes}}:{})};
        }catch(e){if(this.checkpoints)await this.checkpoints.abort();try{await this.writer.abort();}catch(ignore){}throw Error('PART_CLOSE_FAILED');}
      }
      if(this.bytes===0)return {confirmed:false,stage:'EMPTY',file:this.name};
      const blob=new Blob(this.chunks,{type:this.ext==='flv'?'video/x-flv':(this.ext==='mp4'?'video/mp4':'video/mp2t')});
      const result=await RECENV.download(blob,this.name);
      if(result&&result.confirmed&&typeof RECENV.backupPart==='function')try{await RECENV.backupPart(blob,this.name,{file:this.name,bytes:this.bytes});}catch(e){}
      const hashHex=await recSha256Hex(blob); // v2.5.0(P1): HASHED段階の実測値
      return {file:this.name,confirmed:!!(result&&result.confirmed),stage:result&&result.stage||'DOWNLOAD_REQUESTED',hashHex};
    }
  }
  /* v2.5.0(P2): 診断出力用URL秘匿 — クエリ(署名/key2)とフラグメントを除去し
     origin+pathだけを残す。RAM内の取得経路は変更しない(出力のみの変換)。 */
  function recRedactUrl(u) {
    try {
      const s = String(u || '');
      if (!s) return s;
      const i = s.search(/[?#]/);
      return i < 0 ? s : s.slice(0, i);
    } catch (e) { return String(u || ''); }
  }

  /* v2.5.0(P1): 保存確定イベント契約 — パート台帳の段階記録。
     REQUESTED → FILE_WRITTEN → BROWSER_DONE → HASHED → DECODED/CONTINUITY の順で
     各段階の実測時のみ追記し、段階を飛ばしてSUCCESS扱いにしない。
     (ブラウザー側はDECODED/CONTINUITYをffprobeなしでは達成できないため
     structureValidated=セグメント単位の構造検査証拠として記録し、
     完全デコード監査はCLI --qauditの担当と明示分離する) */
  function recLedgerStage(entry, stage, detail) {
    if (!entry) return;
    if (!entry.stages) entry.stages = [];
    const last = entry.stages[entry.stages.length - 1];
    if (last && last.stage === stage) return; // 同段階の二重追記をしない
    entry.stages.push(Object.assign({ stage: stage, at: new Date().toISOString() }, detail || {}));
  }
  function recLedgerStatus(entry) {
    if (!entry || !entry.stages || !entry.stages.length) return 'unknown';
    if (entry.saveState === 'failed') return 'failed';
    const names = entry.stages.map(function (s) { return s.stage; });
    const confirmed = names.indexOf('BROWSER_DONE') >= 0 || names.indexOf('FILE_WRITTEN') >= 0;
    const hashed = names.indexOf('HASHED') >= 0;
    /* SUCCESSは「適用可能な全段階が実測された」場合のみ。ブラウザーでは
       DECODED/CONTINUITYが適用外のため、 confirmed+hashed を最高到達段階とし
       saveState(検証済み段階)と共に明示する(飛ばし無し) */
    if (entry.saveState === 'failed') return 'failed';
    if (confirmed && hashed && entry.structureValidated) return 'CONFIRMED_HASHED_STRUCTURE';
    if (confirmed && hashed) return 'CONFIRMED_HASHED';
    if (confirmed) return 'CONFIRMED_UNHASHED';
    return 'PENDING_' + entry.saveState;
  }
  /* v2.5.0(P1): パート本体のsha256(crypto.subtle不可環境はnull — 偽らない) */
  async function recSha256Hex(blobOrFile) {
    try { return await RspSha256.hashBlob(blobOrFile); }
    catch(e) { return null; } // A read failure must not become a fake HASHED stage.
  }

  /* v2.6.0(P1/P2): HLSコアが文脈単位で累積した数値証拠(世代復旧・fMP4 MAP宣言・
     LL-HLS指標タグ)を情報JSON用に整形する。証拠が1つも無いときはundefinedを返し
     偽の零を作らない(ブラウザー側はffprobe不在のためDECODED相関はCLI --qaudit担当)。 */
  function recRecoveryEvidence(owner, audioOwner) {
    function recov(o) { return (o && o._hlsRecovery) ? o._hlsRecovery : undefined; }
    function fmp(o) { return (o && o._hlsFmp4) ? o._hlsFmp4 : undefined; }
    function llh(o) { return (o && o._hlsLlhlsIndicators) ? { indicatorTags: o._hlsLlhlsIndicators } : undefined; }
    const v = recov(owner) || fmp(owner) || llh(owner);
    const a = recov(audioOwner) || fmp(audioOwner) || llh(audioOwner);
    if (!v && !a) return undefined;
    return {
      generationRecovery: {
        video: recov(owner), audio: recov(audioOwner),
        provenance: 'manifest_sequence_and_uri_classification'
      },
      fmp4Evidence: {
        video: fmp(owner), audio: fmp(audioOwner),
        provenance: 'manifest_map_declarations',
        note: 'MAP切替はパート境界分割で初期化セグメント混在を防止。DISCONTINUITY無し切替は計数(拒否しない)'
      },
      llhlsEvidence: {
        video: llh(owner), audio: llh(audioOwner),
        policy: 'EXT-X-SKIP(差分playlist)はHLS_LLHLS_SKIPで拒否。PRELOAD-HINT/SERVER-CONTROL等は取得せず計数のみ',
        provenance: 'manifest_tag_counts'
      }
    };
  }

  // A join job contains local file identities only. It is not proof of playback quality.
  function recJoinJob(owner) {
    const parts=owner._joinParts&&owner._joinParts.length?owner._joinParts:(owner.partsLog||[]);
    if(!parts.length)throw Error('JOIN_NO_PARTS');
    return {schema:'rsp.join.v1',tool:'RPLAY Stable Player v2.49.0',
      truncated:!!owner._joinTruncated,
      incomplete:!!((owner.segFails||0)+(owner.gapCount||0)+(owner.failedSaves||0)),
      parts:parts.map(p=>({file:p.file,bytes:p.bytes,...(p.sha256?{sha256:p.sha256}:{})})),
      ...(owner.audio&&owner.audio.partsLog&&owner.audio.partsLog.length?{audioRendition:{parts:owner.audio.partsLog.map(p=>({file:p.file,bytes:p.bytes}))}}:{})};
  }

  /* ================= v1.11.0: AudioRecorder(音声レンディション個別録画) =================
   masterの#EXT-X-MEDIA(TYPE=AUDIO,URI付き)を映像TSとは別のaudio-*.tsへ並行録画する。
   - ポーリング/バックオフのポリシーは映像と同一(TARGETDURATION基準±10%ジッタ・
     403=60秒・429=指数バックオフ最大300秒)だが、カウンタは音声内で独立
   - 要求開始は映像ループから0.3〜0.5秒遅らせ、CDN観測上は1セッションに近似させる
   - 404/410=レンディション欠落とみなし即停止(映像は継続・同URIの自動再開なし)
   - FLV代替へ移行したら即停止(FLVは音声多重のため)。TSへ戻ると再評価する
   - セグメント検証(0x47)/分割(20分/600MB)/テンプレート命名は映像と共通の実装を再利用
   - すべての異常はこのクラス内で吸収し、映像パイプラインへは統計とログ1行のみ通知 */
  async function recFetchDescriptor(owner,item) {
    const REC_TRANSIENT_TRANSFER_ERRORS=['HLS_BODY_LENGTH','HLS_RANGE_LENGTH','HLS_EMPTY_BODY'];
    const generation=owner._hlsGeneration||0;
    const audio=!!owner.rec, clock=owner.rec||owner;
    const wait=REC_REQ_MIN_GAP_MS-(Date.now()-clock._lastReqAt);
    if(wait>0)await new Promise(r=>setTimeout(r,wait));
    if(!HLS.alive(owner,generation))return {};
    clock._lastReqAt=Date.now();item.tries++;
    if(!owner._hlsTransfer)owner._hlsTransfer=HLS.createTransfer(fetch,REC_SEG_TIMEOUT_MS);
    const result=await HLS.fetchItem(owner,item);
    if(!HLS.alive(owner,generation))return {};
    if(result.bytes){
      if(item._cdn404Retries)owner._cdn404Recovered=(owner._cdn404Recovered||0)+1;
      if(item._transientTransferRetries)owner._transientTransferRecovered=(owner._transientTransferRecovered||0)+1;
      return {...result,data:result.bytes};
    }
    if(result.error==='HLS_ABORTED')return {};
    if(result.status===429){
      const count=audio?++owner.c429:++owner.consecutive429;
      const ms=recRetryAfterMs(result.retryAfter)||Math.min(REC_429_BASE_MS*Math.pow(2,count-1),REC_429_MAX_MS);
      owner[audio?'backoffUntil':'segBackoffUntil']=Date.now()+ms;item.tries--;return {retry:true};
    }
    if(result.status===404 && item.tries<3){
      item._cdn404Retries=(item._cdn404Retries||0)+1;owner._cdn404Retries=(owner._cdn404Retries||0)+1;
      owner[audio?'backoffUntil':'segBackoffUntil']=Date.now()+1000;
      owner.log('セグメント404 — CDN反映待ちを最大2回、順序を保って再確認');return {retry:true};
    }
    if(result.status===0 && REC_TRANSIENT_TRANSFER_ERRORS.includes(result.error) && item.tries<3){
      item._transientTransferRetries=(item._transientTransferRetries||0)+1;
      owner._transientTransferRetries=(owner._transientTransferRetries||0)+1;
      owner[audio?'backoffUntil':'segBackoffUntil']=Date.now()+500;
      owner.log('セグメント転送途切れ('+result.error+') — 順序を保って再取得');return {retry:true};
    }
    if(result.status===403)owner[audio?'backoffUntil':'segBackoffUntil']=Date.now()+REC_403_COOLDOWN_MS;
    if(result.status===503){
      const delay=recRetryAfterMs(result.retryAfter);
      if(delay>0)owner[audio?'backoffUntil':'segBackoffUntil']=Date.now()+delay;
    }
    if(result.status===0&&['HLS_NETWORK','HLS_TIMEOUT'].includes(result.error)||result.status>=500)return {retry:true};
    if(result.status===404)owner._cdn404Drops=(owner._cdn404Drops||0)+1;
    if(REC_TRANSIENT_TRANSFER_ERRORS.includes(result.error))owner._transientTransferDrops=(owner._transientTransferDrops||0)+1;
    HLS.noteTerminal(owner,item);owner.segFails++;owner.log('HLSデータを採用せず: '+(result.error||'HTTP '+result.status));return {};
  }

  class AudioRecorder {
    constructor(rec) {
      this.rec = rec;
      this.running = false;
      this.stopReason = '';      // '' | 404 | stall | flv | standby | off | resolve
      this.uri = ''; this.group = ''; this.label = ''; this.channels = ''; this.bw = 0;
      this.deadUri = '';         // 同一URIの自動再開を禁止するための記録(セッション内)
      /* 独立ループ状態 */
      this.seen = new Set();
      this.queue = [];
      this.lastSeq = -1;
      this.targetDur = 0;
      this.lastPollAt = 0; this._playlistBody = null; this._playlistUri = '';
      this.curPollMs = 3000;
      this.backoffUntil = 0;
      this.c429 = 0;
      this.startAt = 0;          // 要求開始許可時刻(オフセット用)
      this.lastNewSegAt = 0;
      this._retryResolve = false;
      this._busy = false;
      /* パート管理(映像と独立・audio-*.ts命名) */
      this.partOpen = false; this.partIndex = 0; this.partName = '';
      this.fileStartedAt = 0;
      this.partsLog = []; this._joinTruncated=false; this._joinParts=[]; this._hlsPartBoundaries={};       // 音声パートの記録(情報JSONのaudioRendition.parts用)
      this.chunks = []; this.bytes = 0; this.bytesTotal = 0; this.writer = null;
      /* 統計 */
      this.segTotal = 0; this.segFails = 0; this.filesSaved = 0; this.saveRequests = 0; this.failedSaves = 0;
      this.stoppedAt = '';
    }

    enabled() { return this.rec.recAudio(); }
    log(m) { this.rec.log('[音声] ' + m); }

    /* 新しい配信セッション(追跡再開/復帰)の開始: 最終停止扱いを解除して再挑戦可に */
    onNewSession() {
      this.pause('');
      this.stopReason = ''; this.stoppedAt = '';
      this.deadUri = '';
      this.seen.clear(); this.queue.length = 0;
      this.lastSeq = -1; this.targetDur = 0; this.curPollMs = 3000;
      this.backoffUntil = 0; this.c429 = 0; this._retryResolve = false;
    }

    /* 映像variantの解決/切替に追従して音声源を(再)解決する。
     グループが同一なら音声録画は継続し、URIが変わったら再解決する(設計§3.2) */
    sync(why) {
      if (this.rec.stopped || !this.enabled()) return;
      const g = parseAudioGroups(this.rec._masterTxt || '', this.rec.masterUrl || '');
      const gid = this.rec.selVariant ? this.rec.selVariant.audioGroup : '';
      const grp = g[gid] || null;
      if (!grp || !grp.uri) {
        if (this.running) {
          this.pause('resolve');
          this.log('音声グループのURIが解決できなくなりました(' + why + ') — 映像のみで録画を継続します');
        }
        return;
      }
      if (this.running && this.uri === grp.uri) return; // 変更なし → 継続
      if (!this.running && grp.uri === this.deadUri) return; // 欠落済みURIの自動再開はしない
      const wasRun = this.running;
      if (wasRun) this.closePart(); // グループ/URIが変わる → パートを区切る
      this.uri = grp.uri; this.group = gid;
      this.label = grp.name || gid; this.channels = grp.channels || ''; this.bw = grp.bw || 0;
      HLS.reset(this);this.seen.clear(); this.queue.length = 0; this.lastSeq = -1;
      this.running = true; this.stopReason = ''; this.stoppedAt = '';
      /* 要求オフセット(0.3〜0.5秒): 映像との同時リクエストを避け1セッションに近似 */
      this.startAt = Date.now() + REC_AUDIO_OFFSET_MS_MIN +
        Math.floor(Math.random() * (REC_AUDIO_OFFSET_MS_MAX - REC_AUDIO_OFFSET_MS_MIN));
      this.lastPollAt = 0; this._playlistBody = null; this._playlistUri = ''; this.backoffUntil = 0; this.c429 = 0;
      this.targetDur = 0; this.curPollMs = 3000; this._retryResolve = false;
      this.lastNewSegAt = Date.now();
      this.log((wasRun ? '音声源を再解決(' + why + ')' : '音声トラックの録画を開始(' + why + ')') + ': ' +
        this.label + (this.channels ? '(' + this.channels + 'ch)' : '') +
        (this.bw ? ' ' + Math.round(this.bw / 1000) + 'kbps' : '') + ' — audio-*.tsとして並行保存');
    }

    /* 再開可能な一時停止(FLV移行/追跡待機/トグルOFF)。パートは確定保存 */
    pause(reason) {
      const was = this.running;
      this.running = false;HLS.abort(this);
      if (reason) this.stopReason = reason;
      if (was && !this.stoppedAt) this.stoppedAt = new Date().toISOString();
      this.closePart();
    }

    /* 最終停止(404/stall): 同一URIの自動再開を禁止 */
    stopFinal(reason, msg) {
      this.pause(reason);
      this.deadUri = this.uri;
      if (msg) this.log(msg);
    }

    /* FLV代替への移行: FLVは映像に音声多重のため音声単独録画の意味が消える */
    onFlvStart() {
      if (this.running) {
        this.pause('flv');
        this.log('FLV代替へ移行 — 音声多重ストリームのため音声個別録画を停止しました(TS復帰時に再評価)');
      }
    }

    /* メインループ(Recorder.tickのRUN/ts時に呼ぶ・非同期で独立・例外は内部吸収) */
    async tick() {
      if (this._busy) return;
      this._busy = true;
      try {
        if (!this.enabled()) { if (this.running) this.pause('off'); return; }
        if (!this.running || this.rec.stopped || this.rec.state !== 'RUN' || this.rec.medium !== 'ts') return;
        const now = Date.now();
        if (now < this.startAt) return; // 要求オフセット(0.3〜0.5秒)
        /* 403後の1回再解決: masterを再取得してからsync(URIが更新されていれば追随) */
        if (this._retryResolve && now >= this.backoffUntil) {
          this._retryResolve = false;
          try {
            if (this.rec.masterUrl) {
              const r = await this.rec.fetchPlaylistOnce(this.rec.masterUrl);
              if (r.status === 200 && r.txt) this.rec._masterTxt = r.txt;
            }
            this.sync('403再解決');
          } catch (e) {}
          return;
        }
        if (now < this.backoffUntil) return; // 403/429バックオフ中(音声のみ)
        if (now - this.lastPollAt >= this.curPollMs) await this.poll(now);
        await this.drain();
        this.checkStall(now);
        this.maybeSplit();
      } catch (e) { /* すべての異常を吸収(映像に影響させない) */ }
      finally { this._busy = false; }
    }

    pollIntervalMs(changed=true) { return recHlsReloadMs(this.targetDur,changed); }

    async poll(now) {
      this.lastPollAt = now;
      const url = this.uri;
      const generation=this._hlsGeneration||0;
      if(!this._hlsPlaylistTransfer)this._hlsPlaylistTransfer=HLS.createTransfer(fetch,REC_API_TIMEOUT_MS);
      const result=await this._hlsPlaylistTransfer.request({uri:url},2*1048576);
      if(!HLS.alive(this,generation))return;
      const status=result.status,txt=result.bytes?new TextDecoder().decode(result.bytes):null,ra=recRetryAfterMs(result.retryAfter);
      if (status === 200 && txt != null) {
        this.c429 = 0;
        this._c404 = 0;
        let parsed,queued;
        try{parsed=HLS.parse(txt,this.uri,(this.rec&&this.rec.extinfMode)?this.rec.extinfMode():'legacy',!!(this.rec&&this.rec.inheritQuery&&this.rec.inheritQuery()));queued=HLS.enqueue(this,parsed,this.uri);}
        catch(e){
          const code=String(e&&e.message||'');
          if(this.segTotal>0&&['HLS_BAD_PLAYLIST','HLS_BAD_TARGET','HLS_DANGLING_TAG','HLS_DANGLING_RANGE','HLS_BAD_EXTINF'].includes(code)){
            this._badPlaylistConsec=(this._badPlaylistConsec||0)+1;
            this._badPlaylistTotal=(this._badPlaylistTotal||0)+1;
            if(this._badPlaylistConsec<=2){
              this.log('音声プレイリスト一時破損('+code+') — 停止せず次回ポーリングで再確認します('+this._badPlaylistConsec+'/2)');
              return;
            }
          }
          this.stopFinal('unsupported','音声HLSを安全に処理できません: '+code);return;
        }
        if(this._badPlaylistConsec>0){this._badPlaylistRecovered=(this._badPlaylistRecovered||0)+1;this._badPlaylistConsec=0;}
        if(parsed.target>0)this.targetDur=parsed.target;
        this.lastSeq=parsed.sequence;this.segFails+=queued.missing;
        if(queued.added)this.lastNewSegAt=Date.now();
        const changed=this._playlistBody!==txt || this._playlistUri!==this.uri;
        this._playlistBody=txt;this._playlistUri=this.uri;
        this.curPollMs = this.pollIntervalMs(changed); // 次の取得間隔(TARGETDURATION基準±ジッタ)
        if (txt.indexOf('ENDLIST') >= 0) {
          // 音声playlistの終端は映像側の終了検出に任せる(ここでは停止しない)
          this.lastNewSegAt = Math.min(this.lastNewSegAt, Date.now() - REC_AUDIO_STALL_MS + 30000);
        }
      } else if (status === 404 || status === 410) {
        if (status === 404 && this.segTotal > 0 && (this._c404 = (this._c404 || 0) + 1) < 2) {
          this.log('音声m3u8が一時404 — CDN更新待ちのため次回ポーリングで再確認します');
          return;
        }
        this.stopFinal('404', '音声m3u8が' + status + ' — レンディション欠落とみなし音声録画を停止(映像は継続・自動再開なし)');
      } else if (status === 403) {
        this.backoffUntil = Date.now() + REC_403_COOLDOWN_MS;
        this._retryResolve = true;
        this.log('音声m3u8が403 — ' + Math.round(REC_403_COOLDOWN_MS / 1000) + '秒待機後に1回再解決を試みます');
      } else if (status === 429) {
        this.c429++;
        const ms = ra || Math.min(REC_429_BASE_MS * Math.pow(2, this.c429 - 1), REC_429_MAX_MS); // v1.12.0: RA優先
        this.backoffUntil = Date.now() + ms;
        this.log('音声m3u8が429 — ' + Math.round(ms / 1000) + '秒待機します(音声のみ・映像は継続)' +
          (ra ? '(Retry-After指定)' : ''));
      }
      // 5xx/0(タイムアウト)は次のポーリングで再試行
    }

    async drain() {
      const rec = this.rec;
      while (this.queue.length && this.running && rec.state === 'RUN' && !rec.stopped) {
        if (Date.now() < this.backoffUntil) return;
        /* 要求間隔の下限はrecFetchDescriptor内で映像と共用(二重待機を排除) */
        const item = this.queue.shift();
        const generation=this._hlsGeneration||0;
        const r = await this.fetchSeg(item);
        if (this.stopped || (this.rec && this.rec.stopped)) return;
        if (r.data) { if(!await HLS.append(this,item,r,generation))return;this.segTotal++;this.segCount++; }
        if (r.retry) {
          if (item.tries < REC_SEG_MAX_TRIES) { this.queue.unshift(item); return; } // 順序厳密
          HLS.noteTerminal(this,item);this.segFails++;
          this.log('音声セグメント取得断念(' + item.tries + '回): ...' + item.name.slice(-28));
        }
      }
    }

    async fetchSeg(item) { return recFetchDescriptor(this,item); }

    checkStall(now) {
      if (!this.queue.length && now - this.lastNewSegAt > REC_AUDIO_STALL_MS) {
        this.stopFinal('stall', '音声セグメントが' + Math.round(REC_AUDIO_STALL_MS / 1000) +
          '秒間停止 — 音声録画を停止(映像は継続)');
      }
    }

    /* ---- パート入出力(映像と同じ分割/命名/保存インフラを音声用に運用) ---- */
    ensurePart() {
      if (this.partOpen) return;
      const rec = this.rec;
      const _d = new Date();
      /* テンプレートの{quality}にaudioラベルを反映(例: 256k(2ch)_audio) */
      const qCtx = (this.label ? this.label + '_audio' : 'audio');
      this.partExt=this.mediaFormat==='mp4'?'mp4':'ts';
      this.partName = recFileName(rec.nameTpl(), {
        date: '' + _d.getFullYear() + pad2(_d.getMonth() + 1) + pad2(_d.getDate()),
        time: pad2(_d.getHours()) + pad2(_d.getMinutes()) + pad2(_d.getSeconds()),
        creator: rec.creatorName(), title: rec.recTitle(),
        quality: qCtx, part: this.partIndex + 1, ext: this.partExt
      }, 'RPLAY_' + safeName(rec.creatorName()) + '_' + stampNow() + '_audio-p' + (this.partIndex + 1) + '.'+this.partExt);
      this.partOpen = true;
      this.bytes = 0; this.segCount = 0; this.chunks = [];
      this.fileStartedAt = Date.now();
      this._partAuditStart=rspPartCommit.snapshot(this,HLS);
      if(typeof HLS.startPartAudit==='function')HLS.startPartAudit(this);
      this.partIO = new RecPartSink(this.partName, rec.dirHandle, this.partExt);
      this.partName = this.partIO.name;
    }

    async pushData(u8) {
      this.ensurePart();const io=this.partIO;
      io.push(u8);this.bytes+=u8.length;this.bytesTotal+=u8.length;
      try { await io.flush(); }
      catch (e) {
        this.log('ディスク書き込み失敗 — 録画を停止します');
        if(this.rec)this.stopFinal('write_error','音声書き込み失敗');
        else this.stop(false);
        throw e;
      }
    }

    waitForSaves() { return recWaitSaves(this); }
    closePart() {
      if (!this.partOpen) return Promise.resolve();
      this.partOpen=false;
      const io=this.partIO, bytes=this.bytes, ext=this.partExt;
      const auditFrom=this._partAuditStart,auditTo=rspPartCommit.snapshot(this,HLS);this._partAuditStart=null;
      const partSeq=typeof HLS.takePartAudit==='function'?HLS.takePartAudit(this):null;
      const entry={file:this.partName,ext,bytes,segments:this.segCount||0,
        startedAt:new Date(this.fileStartedAt).toISOString(),endedAt:new Date().toISOString(),saveState:'pending',
        structureValidated:(ext==='ts'||ext==='mp4')};
      if (true) entry.kind='audio';
      if(bytes>0){if(!this._joinParts)this._joinParts=[];if(this._joinParts.length<4096)this._joinParts.push(entry);else this._joinTruncated=true;if(this.partsLog.length>=500)this.partsLog.shift();this.partsLog.push(entry);}
      this.partIO=null;this.chunks=[];this.bytes=0;this.segCount=0;this.partIndex++;
      const job=io.close().then(result=>{
        rspPartCommit.correlate(entry,auditFrom,auditTo,result,entry.kind||'video',partSeq);
        entry.saveState=result.stage;
        entry.hashState=result.hashHex?'hashed':'unavailable';
        if(bytes>0&&result.confirmed){this.filesSaved++;if(this.filesByExt)this.filesByExt[ext]=(this.filesByExt[ext]||0)+1;}
        else if(bytes>0)this.saveRequests=(this.saveRequests||0)+1;
        if(bytes>0)this.log((result.confirmed?'ローカル保存確定: ':'DL要求・完了未確認: ')+entry.file);
        if(bytes>0)recLedgerStage(entry,'REQUESTED',{at:new Date(this.fileStartedAt).toISOString(),segments:entry.segments});
        if(bytes>0&&result.confirmed){
          recLedgerStage(entry,'FILE_WRITTEN',{bytes:bytes,sinkStage:result.stage});
          if(result.stage!=='FILE_CLOSED')recLedgerStage(entry,'BROWSER_DONE',{sinkStage:result.stage,bytes:bytes});
        }
        if(bytes>0&&result.hashHex){entry.sha256=result.hashHex;recLedgerStage(entry,'HASHED',{sha256:result.hashHex});}
        if(bytes>0)entry.ledgerStatus=recLedgerStatus(entry);
        if(bytes>0&&this.rec&&typeof this.rec.persistSession==='function')this.rec.persistSession();
        return result;
      }).catch(()=>{rspPartCommit.correlate(entry,auditFrom,auditTo,{stage:'ERROR',confirmed:false},entry.kind||'video',partSeq);entry.saveState='failed';if(bytes>0){recLedgerStage(entry,'REQUESTED',{at:new Date(this.fileStartedAt).toISOString(),segments:entry.segments});entry.ledgerStatus='failed';}this.failedSaves=(this.failedSaves||0)+1;this.log('保存失敗: '+entry.file+' — 元データ/復旧状態を確認してください');});
      return recTrackSave(this,job);
    }

    splitOnDiscontinuity() { return this.rec && this.rec.splitOnDiscontinuity ? this.rec.splitOnDiscontinuity() : false; }
    maybeSplit() {
      if (!this.partOpen) return;
      const minMs = this.rec.splitMinutes() * 60000;
      const cap = (this.rec && this.rec.fileCapBytes) ? this.rec.fileCapBytes() : REC_FILE_CAP_BYTES;
      if ((minMs > 0 && Date.now() - this.fileStartedAt >= minMs) ||
          (!(minMs===0 && this.partIO && typeof this.partIO.continuousDisk==='function' && this.partIO.continuousDisk()) && this.bytes >= (this.partIO && this.partIO.writer ? cap : Math.min(cap,REC_FILE_CAP_BYTES)))) {
        const ev=this._hlsPartBoundaries||(this._hlsPartBoundaries={});const reason=this.bytes>=(this.partIO&&this.partIO.writer?cap:Math.min(cap,REC_FILE_CAP_BYTES))?'sizeLimit':'timeLimit';ev[reason]=(ev[reason]||0)+1;
        this.log('自動分割: ' + (this.bytes / 1048576).toFixed(1) + 'MB を保存(音声' + (this.partIndex + 1) + '本目)');
        this.closePart();
      }
    }

    stats() {
      return {
        enabled: this.enabled(), running: this.running,
        stopReason: this.stopReason || '',
        label: this.label || '', group: this.group || '',
        channels: this.channels || '', bw: this.bw || 0,
        uri: this.uri || '',
        segTotal: this.segTotal, segFails: this.segFails,
        bytes: this.bytesTotal, files: this.filesSaved, saveRequests:this.saveRequests||0, failedSaves:this.failedSaves||0,
        parts: this.partIndex,
        partsLog: this.partsLog.slice(),
        stoppedAt: this.stoppedAt || ''
      };
    }
  }

  class Recorder {
    /* v2.0 Step1: deps注入(録画コアが認証/予約レイヤへ依存する関数を明示化)。
     deps省略時は従来どおりアンビエント関数を使用(後方互換・挙動同一)。
     Step2(offscreen)ではmount()と同じ形状のdepsをホスト側から渡す。 */
    constructor(id, ui, deps) {
      const D = deps || {};
      this._fResolveMember = D.resolveMemberLive || resolveMemberLive;
      this._fResolveSched = D.resolveScheduleInfo || resolveScheduleInfo;
      this._fSchedFor = D.fetchSchedulesFor || fetchSchedulesFor;
      this._fMemberHint = D.memberFailHint || memberFailHint;
      this._fBaseLabel = D.liveBaseLabel || liveBaseLabel;
      this.id = id;
      this.ui = ui;
      this.recording = false;
      this.stopped = true;
      this.state = 'IDLE';            // IDLE | RUN | STANDBY
      this.medium = 'ts';             // ts | flv
      this.apiBase = API_BASE;
      /* パート(保存ファイル)管理 */
      this.partOpen = false;
      this.partIndex = 0;
      this.partName = '';
      this.partExt = 'ts';
      this.chunks = [];               // メモリモードの現パート
      this.bytes = 0;                 // 現パートbyte数
      this.bytesTotal = 0;            // セッション累計byte数
      this.writer = null;             // File System Access の書き込み先
      this.dirHandle = null;
      this.dirLabel = '';
      /* 統計 */
      this.segCount = 0;   // 現パート内セグメント数
      this.segTotal = 0;   // セッション累計
      this.segFails = 0;   // 断念したセグメント(累計)
      this.gapCount = 0;   // ポーリング間隔での取りこぼし疑い
      this.byterangeSkipped = 0; // v1.12.0: BYTERANGE防御で取得不能だったセグメント数
      this.filesSaved = 0; this.saveRequests = 0; this.failedSaves = 0;
      this.filesByExt = { ts: 0, flv: 0 };
      this.startedAt = 0;
      this.fileStartedAt = 0;
      this.standbySince = 0;
      this.resumes = 0;    // 追跡による自動再開回数
      /* プレイリスト監視 */
      this.seen = new Set();
      this.queue = [];
      this.consecutive404 = 0;
      this.lastMediaSeq = -1;
      this._skipBacklog = false;
      this.lastNewSegAt = 0;
      this.pendingEnd = null;
      /* サーバー配慮(v1.4.0): 適応ポーリング/バックオフ/リクエスト間隔 */
      this.targetDur = 0;          // プレイリストのTARGETDURATION
      this.lastPollAt = 0; this._playlistBody = null; this._playlistUri = '';         // 最後にプレイリストを取得した時刻
      this.curPollMs = 3000;       // 現在の取得間隔(ジッタ付き・取得のたびに更新)
      this.lastStandbyAt = 0;      // 最後に追跡探索した時刻
      this.plBackoffUntil = 0;     // プレイリスト403/429時のバックオフ期限
      this.segBackoffUntil = 0;    // セグメント403/429時のバックオフ期限
      this.consecutive429 = 0;
      this.lastDisAnchor = null;   // ディスコンティニュイティ検出用アンカー
      this._lastReqAt = 0;         // 最後のリクエスト開始時刻(間隔下限用)
      this._spd = [];              // 転送速度計算用リング
      this.partsLog = []; this._joinTruncated=false; this._joinParts=[]; this._hlsPartBoundaries={};          // 保存済みパートの記録(情報JSON用)
      /* FLV */
      this.flvAbort = null;
      this.flvRunning = false;
      this.flvGotData = false;
      this.flvLastFail = 0;
      /* フック(外部注入可: 試験やカスタム用) */
      this.getCustomM3u8 = null;
      this.getFlvUrl = null;
      this.getCreatorName = null;
      this.getUrlMode = null;       // v2.40.0: 任意HLS URL録画モード(true=URL録画セッション)
      this.m3u8 = CDN_BASE + id + '.m3u8';
      this.memberPlaylist = '';    // 限定配信(会員限定)のplaylist(key2認証)
      this.accessMode = 'public';  // public | member
      this.liveInfo = null;        // 詮索結果(live/play応答) — Engineと共有
      this.liveM3u8 = '';          // 探查で生きたと確認されたHLS源(abr/IVS含む)
      this.sourceKind = '';        // 採用源: member|custom|abr|legacy|ivs|flv
      this.memberResolveAt = 0;    // 限定解決の最終試行(節流・サーバー配慮)
      this.memberReResolveAt = 0;  // v1.8.0: 限定録画中の鍵更新再解決(90秒節流)
      this.schedItem = null;       // v1.8.0: 配信予約(直近1件) {title, scheduledAt}
      this.schedNotifyAt = 0;      // 予約開始の通知済み時刻(重複通知防止)
      this.schedNotified5 = false; // 5分前通知済み
      this.schedNotified10 = false; // v1.10.0: 10分前リマインド済み
      this.schedLastLog = '';      // 予約カウントダウンの重複ログ防止
      /* v1.10.0: 統計レポート(セッション単位の累積 — 追加の通信は発生しない) */
      this.pollCount = 0;          // プレイリスト取得回数
      this.sourceSwitches = 0;     // HLS源(基盤)切替回数
      this.sourceHistory = [];     // 切替履歴(最大20)
      this.qualityFallbacks = 0;   // 画質フォールバック回数
      this.qualityHistory = [];    // 画質変遷(昇格/フォールバック・最大20)
      this.segIntervalSum = 0;     // セグメント取得間隔の累計(ms)
      this.segIntervalN = 0;       // 間隔サンプル数
      this._lastSegAddedAt = 0;
      this._queueWarnAt = 0;
      this.audioTxt = '';          // 音声レンディション表示(例: 256k(2ch))
      this._verifier = null;       // TS検証(Worker・遅延生成)
      this.verifyChecked = 0;      // 検証済みセグメント数
      this._lastInfo = null;       // 最後に保存した情報JSON(試験フック用)
      this._lastCsv = '';          // 最後に保存した統計CSV(試験フック用)
      this._masterTxt = '';        // 最後に取得したmaster playlist原文(音声解析用)
      this.audio = null;           // v1.11.0: AudioRecorder(音声レンディション個別録画)
      /* v1.9.0: 画質選択(最高画質) */
      this._variantOf = '';        // 解決済みvariant URL(直接ポーリング用)
      this.masterUrl = '';         // master playlistのURL(media playlist源では空)
      this.variants = [];          // 最後に取得したmasterのvariant一覧
      this.selVariant = null;      // 録画中のvariant(画質)
      this.qualityTxt = '';        // UI表示用(例: 1080p60(8.5Mbps))
      this.qualityUpgrades = 0;    // 録画中の画質昇格回数
      this.deadVariants = new Set(); // 消失(404/410)したvariant URL(フォールバック除外)
      this._qUpAt = 0;             // 最終の画質昇格チェック時刻
      this._qUpRunning = false;
      this._qFbAt = 0;             // 最終のvariantフォールバック時刻
      this.ticker = null;
      this.tickN = 0;
      this.busy = false;
      this._unload = null;
      this._titleBase = null;
      this._titleMin = -1;
    }

    /* ---- 設定(UI参照) ---- */
    follow() { return this.ui.followChecked ? !!this.ui.followChecked() : true; }
    flvFallback() { return this.ui.flvFallbackChecked ? !!this.ui.flvFallbackChecked() : true; }
    backlog() { return this.ui.backlogChecked ? !!this.ui.backlogChecked() : true; }
    /* v2.5.0: EXTINF検証モード(P1) — 既定legacy(未宣言を診断計数)、RFC 8216厳格モードは拒否 */
    extinfMode() { try { return (this.ui && this.ui.rfcExtinfChecked && this.ui.rfcExtinfChecked()) ? 'rfc' : 'legacy'; } catch (e) { return 'legacy'; } }
    infoJson() { return this.ui.infoJsonChecked ? !!this.ui.infoJsonChecked() : false; }
    /* v1.9.0: 最高画質での録画(既定ON)。OFF時はプレイリスト先頭variant(サーバー指定順) */
    bestQ() { return this.ui.bestQualityChecked ? !!this.ui.bestQualityChecked() : true; }
    /* v1.11.0: 音声トラックの並行録画(既定OFF — 帯域約1.2〜1.5倍増のため明示ON制) */
    recAudio() { return this.ui.recAudioChecked ? !!this.ui.recAudioChecked() : false; }
    /* v1.10.0: 保存ファイル名テンプレート(空=従来命名・後方互換) */
    nameTpl() {
      try { if (this.ui.nameTplValue) return this.ui.nameTplValue() || ''; } catch (e) {}
      return RECENV.storageGet('rsp_name_tpl') || ''; // v2.0 Step1: RECENV経由
      return '';
    }
    /* v1.10.0: 統計CSVの保存(情報JSONと同時に出力) */
    csvOut() { return this.ui.csvChecked ? !!this.ui.csvChecked() : false; }
    /* v1.10.0: 予約リマインドのモード(both|10|5|off) */
    remindMode() {
      try { if (this.ui.remindValue) { const v = this.ui.remindValue(); if (v) return v; } } catch (e) {}
      try { const v = localStorage.getItem('rsp_remind'); if (v) return v; } catch (e) {}
      return 'both';
    }
    /* v1.10.0: 配信タイトル(詮索結果) — ファイル名テンプレートと履歴用 */
    recTitle() {
      try { const t = this.liveInfo && this.liveInfo.title; if (t) return String(t); } catch (e) {}
      return '';
    }
    splitMinutes() { return this.ui && this.ui.splitMinutes ? this.ui.splitMinutes() : 0; }
    splitOnDiscontinuity() { return this.ui && this.ui.splitDiscChecked ? !!this.ui.splitDiscChecked() : false; }
    inheritQuery() { return this.ui && this.ui.inheritQueryChecked ? !!this.ui.inheritQueryChecked() : false; }
    adKeyword() {
      try { if (this.ui && typeof this.ui.adKeywordValue === "function") return String(this.ui.adKeywordValue() || "").trim(); } catch (e) {}
      try { if (typeof RECENV !== "undefined" && RECENV && typeof RECENV.storageGet === "function") return String(RECENV.storageGet("rsp_ad_keyword") || "").trim(); } catch (e) {} return "";
    }
    setAdKeyword(pattern) {
      const clean = String(pattern || "").trim();
      if (!clean) {
        this._adKeyword = "";
        this._adKeywordRe = null;
        return true;
      }
      if (clean.length > 256) throw Error("AD_KEYWORD_TOO_LONG");
      this._adKeywordRe = new RegExp(clean);
      this._adKeyword = clean;
      return true;
    }
    fileCapBytes() { return this.dirHandle ? 2048 * 1048576 : REC_FILE_CAP_BYTES; }
    creatorName() {
      try { const n = this.getCreatorName && this.getCreatorName(); if (n) return n; } catch (e) {}
      return this.id;
    }
    urlMode() { try { return !!(this.getUrlMode && this.getUrlMode()); } catch (e) { return false; } }
    playlistUrl() {
      // 限定配信の解決が済んでいれば最優先(公開URLが403でも確実に録画を継続)
      if (this.memberPlaylist) return this.memberPlaylist;
      const custom = this.getCustomM3u8 ? (this.getCustomM3u8() || '') : '';
      if (custom) return custom;
      // 新旧基盤の多段: 探查で生きた源(liveM3u8)があれば優先、なければ従来源
      if (this.liveM3u8) return this.liveM3u8;
      return rspSourceCandidates(this.liveInfo, this.m3u8)[0] || this.m3u8;
    }
    flvUrl() {
      try { if (this.getFlvUrl) { const u = this.getFlvUrl(); if (u) return u; } } catch (e) {}
      return CDN_BASE + this.id + '_abrhd.flv?creatorId=' + this.id + '&resolution=hd&abr_pts=-800';
    }
    saveTargetLabel() { return this.dirHandle ? 'フォルダ「' + this.dirLabel + '」' : 'ダウンロード'; }

    log(msg) { this.ui.log('[REC] ' + msg); }

    /* ---- 開始 / 停止 ---- */
    start() {
      if (this.recording || this.isDraining) return;
      this.recording = true;
      this.stopped = false;
      HLS.reset(this);HLS.clearWriteEvidence(this);
      this.state = 'RUN';
      this.medium = 'ts';
      this.startedAt = Date.now();
      this.fileStartedAt = Date.now();
      this.lastNewSegAt = Date.now();
      this.partIndex = 0;
      this.resumes = 0;
      this.pendingEnd = null;
      this._skipBacklog = !this.backlog(); // 追跡による再開(resume)では適用しない
      this.resetQualityState(); // v1.9.0: 前回セッションの画質状態を引き継がない
      this.lastPollAt = 0; this._playlistBody = null; this._playlistUri = '';
      this.curPollMs = 3000;
      this.lastStandbyAt = 0;
      this.lastDisAnchor = null;
      this.plBackoffUntil = 0;
      this.segBackoffUntil = 0;
      this.consecutive429 = 0;
      this.partsLog = []; this._joinTruncated=false; this._joinParts=[]; this._hlsPartBoundaries={};
      this._spd = [];
      try { if (!this._adKeywordRe && this.adKeyword()) this.setAdKeyword(this.adKeyword()); } catch (e) { this._adKeywordRe = null; }
      this.resetStatsBlock(); // v1.10.0: セッション統計の初期化(復帰/再開は累積を維持)
      this.audio = new AudioRecorder(this); // v1.11.0: 音声録画(トグルON+URI解決で稼働)
      this.ticker = createTicker(REC_POLL_MS, () => this.tick());
      this.log('録画開始(追跡' + (this.follow() ? 'ON' : 'OFF') +
        (this.follow() && this.flvFallback() ? ' / FLV代替ON' : '') +
        ' / 分割' + (this.splitMinutes() || 'なし') + '分ごと / バックログ' + (this.backlog() ? '取得' : 'スキップ') +
        ' / 画質' + (this.bestQ() ? '最高(自動昇格)' : '先頭(サーバー指定順)') +
        ' / 音声' + (this.recAudio() ? '併録(audio-*.ts)' : 'なし') +
        ' / 保存先: ' + this.saveTargetLabel() +
        ' / タイマー: ' + (this.ticker.usingWorker() ? 'Worker' : '通常') + ')');
      if (this.nameTpl()) this.log('ファイル名テンプレート: ' + this.nameTpl()); // v1.10.0
      this.ui.recState(true, this.state, this.medium);
      const rec = this;
      this._unload = function (e) {
        if (rec.recording && (rec.bytes > 0 || rec.filesSaved > 0)) { e.preventDefault(); e.returnValue = ''; }
      };
      RECENV.onUnload(this._unload); // v2.0 Step1: RECENV経由
      this._titleMin = -1;
      this.updateTitle(true);
      this.persistSession();
    }

    stop(autoSaved) {
      if (!this.recording) return this._stopTask || Promise.resolve();
      this.recording=false;this.stopped=true;this.state='IDLE';this.isDraining=true;HLS.abort(this);
      this.abortFlv();if(this.ticker){this.ticker.stop();this.ticker=null;}
      if(this.audio)this.audio.pause('off');
      if(this._unload){RECENV.offUnload(this._unload);this._unload=null;}
      this.restoreTitle();this.closePart();
      this.ui.recState(false,'DRAINING',this.medium);
      this._stopTask=Promise.all([recWaitSaves(this),this.audio?recWaitSaves(this.audio):Promise.resolve()]).then(async()=>{
        if(this.partsLog.length>1)try{await this.saveJoinJob();}catch(e){this.log('結合リストを保存できませんでした');}
        if(this.infoJson())this.saveInfoJson();this.saveHistory();
        if(!(this.failedSaves||(this.audio&&this.audio.failedSaves)))this.clearSession();
        if(typeof RECENV.sessionEnded==='function'){try{const _p=RECENV.sessionEnded(this);if(_p&&_p.catch)_p.catch(function(){});}catch(e){}}
        this.ui.recState(false,'IDLE',this.medium);
        this.log('録画停止 — ローカル保存'+this.filesSaved+'本 / DL未確認'+(this.saveRequests||0)+'本 / 保存失敗'+(this.failedSaves||0)+'本');
      }).finally(()=>{this.isDraining=false;});
      return this._stopTask;
    }

    toggle() { if (this.recording) this.stop(false); else this.start(); }

    /* ---- v1.6.0: セッション永続化(断点復帰)と通知 ----
     録画状態を約6秒ごとにlocalStorageへ書き、クラッシュ/誤操作でタブを
     失っても、同じ配信ページを開けばワンクリックで録画を引き継げる。
     (メモリ上の未保存チャンクは失われるため、自動分割20分/600MBとの併用
      で最大損失窗を最小化。フォルダ直書きなら即時確定) */
    persistSession() {
      if (!this.recording || this.stopped) return;
      try {
        const cleanParts = typeof recSanitizePersistedParts === 'function'
          ? recSanitizePersistedParts(this.partsLog)
          : [];
        const cleanAudioParts = (this.audio && typeof recSanitizePersistedParts === 'function')
          ? recSanitizePersistedParts(this.audio.partsLog)
          : [];
        const payload = {
          v: 2,
          id: this.id,
          creator: this.creatorName(),
          startedAt: this.startedAt,
          updatedAt: Date.now(),
          state: this.state,             // RUN | STANDBY(追跡待機も引き継ぐ)
          accessMode: this.accessMode,
          segTotal: this.segTotal,
          bytesTotal: this.bytesTotal,
          resumes: this.resumes,
          partIndex: this.partIndex,
          filesSaved: this.filesSaved || 0,
          segFails: this.segFails,
          gapCount: this.gapCount,
          partsLog: cleanParts,
          audioPartsLog: cleanAudioParts
        };
        let json = JSON.stringify(payload);
        if (json.length > 49152) {
          payload.partsLog = cleanParts.slice(-32);
          payload.audioPartsLog = cleanAudioParts.slice(-16);
          json = JSON.stringify(payload);
        }
        RECENV.storageSet(REC_SESSION_KEY, json);
      } catch (e) {}
    }

    clearSession() {
      RECENV.storageDel(REC_SESSION_KEY); // v2.0 Step1: RECENV経由
    }

    /* v1.10.0: セッション統計の初期化(start時のみ — 復帰/再開は累積を維持) */
    resetStatsBlock() {
      this.pollCount = 0; this.sourceSwitches = 0; this.sourceHistory = [];
      this.qualityFallbacks = 0; this.qualityHistory = [];
      this.segIntervalSum = 0; this.segIntervalN = 0; this._lastSegAddedAt = 0;
      this.verifyChecked = 0;
      this._sessionTracker = { initialStreamStartSec: null, latestStreamStartSec: null, thresholdSec: 600, sameSessionResumes: 0, newSessionSplits: 0, transitions: [] };
      this._errTaxonomy = { SOURCE: 0, NETWORK: 0, AUTH: 0, PLATFORM: 0, COMPATIBILITY: 0, INTERNAL: 0 };
      this._sameSessionStandbyContinuations = 0;
    }
    noteStreamStart(info) {
      if (!info || typeof info !== 'object') return;
      const raw = info.streamStartTime || info.startedAt || null;
      const sec = rspParseStreamStartSec(raw);
      if (sec === null) return;
      if (!this._sessionTracker) this._sessionTracker = { initialStreamStartSec: null, latestStreamStartSec: null, thresholdSec: 600, sameSessionResumes: 0, newSessionSplits: 0, transitions: [] };
      const st = this._sessionTracker;
      if (st.initialStreamStartSec === null) {
        st.initialStreamStartSec = sec;
        st.latestStreamStartSec = sec;
        return;
      }
      const cls = rspClassifySessionChange(st.latestStreamStartSec, sec, st.thresholdSec);
      st.latestStreamStartSec = sec;
      if (cls.changed) {
        if (cls.classification === 'same_session_resumed') { st.sameSessionResumes++; this._sameSessionStandbyContinuations = (this._sameSessionStandbyContinuations || 0) + 1; }
        else if (cls.classification === 'new_session_split') st.newSessionSplits++;
        st.transitions.push({ gapSec: cls.gapSec, classification: cls.classification, at: new Date().toISOString() });
      }
    }
    noteErrKind(kind) {
      if (!this._errTaxonomy) this._errTaxonomy = { SOURCE: 0, NETWORK: 0, AUTH: 0, PLATFORM: 0, COMPATIBILITY: 0, INTERNAL: 0 };
      if (Object.prototype.hasOwnProperty.call(this._errTaxonomy, kind)) this._errTaxonomy[kind]++;
    }
    /* v1.10.0: セッション要約を履歴(IndexedDB)へ保存(失敗は無視 — 本体に影響させない) */
    saveHistory() {
      if (this.segTotal <= 0 && this.bytesTotal <= 0) return;
      const entry = {
        endedAt: new Date().toISOString(),
        creator: this.creatorName(),
        creatorOid: this.id,
        title: this.recTitle(),
        durationMs: Date.now() - this.startedAt,
        bytes: this.bytesTotal,
        segTotal: this.segTotal,
        missing: this.segFails + this.gapCount + (this.byterangeSkipped || 0), // v1.12.0
        files: this.filesSaved, saveRequests:this.saveRequests||0, failedSaves:this.failedSaves||0,
        quality: this.qualityTxt,
        audio: this.audioTxt,
        audioSeg: (this.audio && this.audio.segTotal) || 0, // v1.11.0
        resumes: this.resumes,
        sourceSwitches: this.sourceSwitches,
        sourceKind: this.sourceKind,
        accessMode: this.accessMode
      };
      const self = this;
      idbAddSession(entry).then(function (ok) {
        if (ok) self.log('録画履歴を保存(🕘 録画履歴で一覧表示)');
      });
    }
    /* v1.10.0: 統計ブロック(セッション単位の集計) */
    statsBlock() {
      const total = this.segTotal + this.segFails + this.gapCount + (this.byterangeSkipped || 0); // v1.12.0
      return {
        missingRate: total > 0 ? Math.round(((this.segFails + this.gapCount) / total) * 1000) / 1000 : 0,
        missingSuspect: this.segFails + this.gapCount,
        segmentWriteEvidence: ((typeof HLS.writeEvidence === 'function') ? HLS.writeEvidence(this) : undefined),
        byterangeSkipped: this.byterangeSkipped || 0, // v1.12.0
        reconnects: this.resumes,
        sourceSwitches: this.sourceSwitches,
        sourceHistory: this.sourceHistory.slice(),
        qualityUpgrades: this.qualityUpgrades,
        qualityFallbacks: this.qualityFallbacks,
        qualityHistory: this.qualityHistory.slice(),
        avgSegIntervalMs: this.segIntervalN > 0 ? Math.round(this.segIntervalSum / this.segIntervalN) : 0,
        pollCount: this.pollCount,
        verifiedSegs: this.verifyChecked,
        verifyWorker: this._verifier ? this._verifier.usingWorker() : false,
        files: this.filesSaved, saveRequests:this.saveRequests||0, failedSaves:this.failedSaves||0,
        filesByExt: Object.assign({}, this.filesByExt)
      };
    }
    /* v1.10.0: 統計CSVの保存(情報JSONと同じ内容をCSV行に起こす) */
    saveInfoCsv(info) {
      try {
        const q = function (v) { return '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"'; };
        const rows = [['section', 'key', 'value'].join(',')];
        const s = info.stats || {};
        const add = function (k, v) { rows.push(['summary', k, q(v)].join(',')); };
        add('tool', info.tool); add('creator', info.creator); add('accessMode', info.accessMode);
        add('sourceKind', info.sourceKind); add('durationSec', info.durationSec);
        add('totalBytes', info.totalBytes); add('segments', info.segments);
        add('missingSuspect', s.missingSuspect); add('missingRate', s.missingRate);
        add('reconnects', s.reconnects); add('sourceSwitches', s.sourceSwitches);
        add('qualityUpgrades', s.qualityUpgrades); add('qualityFallbacks', s.qualityFallbacks);
        add('avgSegIntervalMs', s.avgSegIntervalMs); add('pollCount', s.pollCount);
        add('qualitySelected', info.quality ? info.quality.selected : '');
        /* v1.11.0: 音声レンディションの列 */
        const ar = info.audioRendition || null;
        add('audioLabel', info.audio || '');
        add('audioRecorded', ar ? (ar.running ? 'yes' : (ar.segTotal ? 'stopped:' + (ar.stopped || '') : 'no')) : 'no');
        add('audioSegTotal', ar ? ar.segTotal : 0);
        add('audioBytes', ar ? ar.bytes : 0);
        add('audioBandwidth', ar ? (ar.bandwidth || 0) : 0);
        (info.parts || []).forEach(function (p) { rows.push(['part', q(p.file), q(p.bytes)].join(',')); });
        (s.qualityHistory || []).forEach(function (h) { rows.push(['qualityChange', q(h.from + ' -> ' + h.to), q(h.why)].join(',')); });
        (s.sourceHistory || []).forEach(function (h) { rows.push(['sourceChange', q(h.to), q(h.at)].join(',')); });
        const csv = rows.join('\r\n');
        this._lastCsv = csv;
        const name = 'RPLAY_' + safeName(this.creatorName()) + '_' + stampNow() + '_stats.csv';
        RECENV.download(new Blob([csv], { type: 'text/csv' }), name); // v2.0 Step1
        this.log('統計CSVを保存: ' + name);
      } catch (e) { this.log('統計CSVの保存に失敗: ' + (e && e.message || e)); }
    }
    notify(title, body) {
      if (!this.ui.notifyChecked || !this.ui.notifyChecked()) return;
      RECENV.notify(title, body); // v2.0 Step2: 権限確認はRECENV実装側の責務(ページ=Notification権限確認/offscreen=SW中継で権限不要)
    }

    /* クラッシュ/再読み込み前のセッションを引き継いで録画を再開 */
    resumeFromCrash(s) {
      if (this.recording || this.isDraining) return;
      this.recording = true;
      this.stopped = false;
      HLS.reset(this);HLS.clearWriteEvidence(this);
      this.state = (s.state === 'STANDBY') ? 'STANDBY' : 'RUN';
      this.medium = 'ts'; // 復帰は必ずHLSから再確立(FLV代替は必要なら自動切替)
      this.startedAt = s.startedAt || Date.now();
      this.fileStartedAt = Date.now();
      this.partIndex = s.partIndex || 0;   // パート番号を引き継ぎ(連番が続く)
      this.segTotal = s.segTotal || 0;
      this.bytesTotal = s.bytesTotal || 0;
      this.resumes = s.resumes || 0;
      this.segFails = s.segFails || 0;
      this.gapCount = s.gapCount || 0;
      this.byterangeSkipped = s.byterangeSkipped || 0; // v1.12.0
      this.accessMode = (s.accessMode === 'member') ? 'member' : 'public';
      this.memberPlaylist = ''; // Re-resolve under the current authorized session, never restore a signed URL.
      this.resetQualityState(); // v1.9.0: 復帰時は画質を再解決
      this.audio = new AudioRecorder(this); // v1.11.0: 音声録画は新規に(セッション統計は映像のみ引継)
      this._skipBacklog = true;  // 復帰直後の既存ウィンドウはスキップ(重複防止)
      this.lastPollAt = 0; this._playlistBody = null; this._playlistUri = '';
      this.curPollMs = 3000;
      this.lastStandbyAt = 0;
      this.lastDisAnchor = null;
      this.plBackoffUntil = 0;
      this.segBackoffUntil = 0;
      this.consecutive429 = 0;
      const restoredParts = (typeof recSanitizePersistedParts === 'function') ? recSanitizePersistedParts(s.partsLog) : [];
      this.partsLog = restoredParts.slice();
      this._joinTruncated = false;
      this._joinParts = restoredParts.slice();
      this._hlsPartBoundaries = {};
      this.filesSaved = (Number.isSafeInteger(s.filesSaved) && s.filesSaved >= restoredParts.length) ? s.filesSaved : restoredParts.length;
      if (restoredParts.length > this.partIndex) this.partIndex = restoredParts.length;
      if (this.audio && Array.isArray(s.audioPartsLog) && typeof recSanitizePersistedParts === 'function') {
        const restoredAudio = recSanitizePersistedParts(s.audioPartsLog);
        this.audio.partsLog = restoredAudio.slice();
        this.audio._joinParts = restoredAudio.slice();
        this.audio.filesSaved = restoredAudio.length;
        if (restoredAudio.length > this.audio.partIndex) this.audio.partIndex = restoredAudio.length;
      }
      this._spd = [];
      this.ticker = createTicker(REC_POLL_MS, () => this.tick());
      this.log('録画セッションを復帰 — 前回: seg' + this.segTotal + ' / ' +
        (this.bytesTotal / 1048576).toFixed(1) + 'MB' +
        (this.resumes ? ' / 再開' + this.resumes + '回' : '') +
        (this.state === 'STANDBY' ? ' / 追跡待機から継続' : '') +
        ' (中断直後の数segは重複/欠落の可能性があります)');
      this.ui.recState(true, this.state, this.medium);
      if (this.state === 'STANDBY') this.standbySince = Date.now();
      const rec = this;
      this._unload = function (e) {
        if (rec.recording && (rec.bytes > 0 || rec.filesSaved > 0)) { e.preventDefault(); e.returnValue = ''; }
      };
      RECENV.onUnload(this._unload); // v2.0 Step1: RECENV経由
      this._titleMin = -1;
      this.updateTitle(true);
      this.persistSession();
      if (this.state === 'RUN') {
        const self = this;
        this._resolvingResume=true;
        this._resumeReady=(async()=>{
          if(self.accessMode==='member'){
            const result=await self._fResolveMember(self.id,m=>self.log(m));
            if(self.stopped)return;
            if(!result || !result.ok){self.log('復帰時の視聴権限を確認できませんでした。録画を停止します');await self.stop(false);return;}
            self.memberPlaylist=result.playlist;self.sourceKind='member';
          }
          if(self.stopped)return;
          await self.pollPlaylist();await self.drain();
        })().catch(async()=>{if(!self.stopped){self.log('復帰処理に失敗しました。録画を停止します');await self.stop(false);}}).finally(()=>{self._resolvingResume=false;});
      }
    }

    async saveJoinJob() {
      if(this.recording) { this.log('結合リストは録画停止後に保存してください'); return; }
      await recWaitSaves(this);
      const job=recJoinJob(this);
      const name='RPLAY_'+this.id+'_join_'+Date.now()+'.json';
      await RECENV.download(new Blob([JSON.stringify(job,null,2)],{type:'application/json'}),name);
      this.log('結合リストを保存: '+name+' — 録画ファイルと同じフォルダーで結合ツールを実行できます');
      return job;
    }

    /* セッションの録画情報JSON(yt-dlpの.info.json相当)を保存 */
    saveInfoJson() {
      if (!this.partsLog.length) return;
      const selfRef = this; // v1.11.0: audioRendition生成用
      const _recov = (typeof RECENV.recoveredParts === 'function') ? RECENV.recoveredParts() : [];
      /* v2.6.0(P1/P2): 世代復旧・fMP4 MAP宣言・LL-HLS指標の数値証拠(CLIと同形式) */
      const _evd = recRecoveryEvidence(this, this.audio);
      /* v2.7.0(A-02/A-03): 認証・canary証拠(RECENVフック経由 — 未供給なら出さない) */
      const _auth = (typeof RECENV.authStats === 'function') ? RECENV.authStats() : undefined;
      const _canary = (typeof RECENV.canaryEvidence === 'function') ? RECENV.canaryEvidence() : undefined;
      const info = {
        partBoundaryEvidence: this._hlsPartBoundaries || {},
        tool: 'RPLAY Stable Player v2.49.0',
        creator: this.creatorName(),
        creatorOid: this.id,
        playlist: recRedactUrl(this.playlistUrl()), // v2.5.0(P2): 署名/key2クエリを出力しない
        sourceKind: this.sourceKind || (this.accessMode === 'member' ? 'member' : 'legacy'),
        accessMode: this.accessMode,
        quality: this.selVariant ? {
          selected: this.qualityTxt,
          url: recRedactUrl(this.selVariant.url), // v2.5.0(P2)
          width: this.selVariant.width,
          height: this.selVariant.height,
          fps: this.selVariant.fps,
          bandwidth: this.selVariant.bwEff,
          upgrades: this.qualityUpgrades,
          available: (this.variants || []).map(function (v) {
            return { label: qualityLabel(v), bandwidth: v.bwEff, url: recRedactUrl(v.url) }; // v2.5.0(P2)
          })
        } : undefined,
        streamBase: this.liveInfo ? this._fBaseLabel(this.liveInfo) : undefined,
        schedule: this.schedItem ? { title: this.schedItem.title, scheduledAt: new Date(this.schedItem.scheduledAt).toISOString() } : undefined,
        startedAt: new Date(this.startedAt).toISOString(),
        endedAt: new Date().toISOString(),
        durationSec: Math.round((Date.now() - this.startedAt) / 1000),
        totalBytes: this.bytesTotal,
        segments: this.segTotal,
        missingSuspect: this.segFails + this.gapCount,
        segmentWriteEvidence: ((typeof HLS.writeEvidence === 'function') ? HLS.writeEvidence(this) : undefined),
        byterangeSkipped: this.byterangeSkipped || 0, // v1.12.0
        trackingResumes: this.resumes,
        recoveredParts: (_recov && _recov.length) ? _recov : undefined, // v2.1.0(設計書§4.3)
        audio: this.audioTxt || undefined, // v1.10.0
        audioRendition: (function () {     // v1.11.0: 音声レンディション録画の記録
          const a = selfRef.audio ? selfRef.audio.stats() : null;
          // トグルOFF等で音声データが1件も無いセッションは記録しない('off'は停止理由扱いにしない)
          if (!a || (!a.running && !a.segTotal && (!a.stopReason || a.stopReason === 'off'))) return undefined;
          return {
            enabled: a.enabled, running: a.running, group: a.group, uri: recRedactUrl(a.uri), // v2.5.0(P2)
            bandwidth: a.bw, channels: a.channels, label: a.label,
            segTotal: a.segTotal, segFails: a.segFails, bytes: a.bytes, files: a.files,
            segmentWriteEvidence: ((typeof HLS.writeEvidence === 'function') ? HLS.writeEvidence(selfRef.audio) : undefined),
            stopped: a.stopReason || undefined, stoppedAt: a.stoppedAt || undefined,
            parts: a.partsLog
          };
        })(),
        stats: this.statsBlock(),          // v1.10.0: 欠落率/再接続/基盤切替/画質履歴/平均間隔
        generationRecovery: _evd && _evd.generationRecovery,  // v2.6.0: 世代復旧の数値証拠
        fmp4Evidence: _evd && _evd.fmp4Evidence,              // v2.6.0(P1): EXT-X-MAP宣言証拠
        llhlsEvidence: _evd && _evd.llhlsEvidence,            // v2.6.0(P2): LL-HLS指標タグ計数
        authEvidence: _auth,                                  // v2.7.0(A-02): 認証方式と401分類
        canaryEvidence: _canary,                              // v2.7.0(A-03): 応答形状canary
        sessionTrackingEvidence: (function () {               // v2.8.0(W-01): streamStartTime 10分閾値追跡
          if (selfRef.liveInfo) selfRef.noteStreamStart(selfRef.liveInfo);
          return selfRef._sessionTracker ? rspSessionTrackingEvidence(selfRef._sessionTracker) : undefined;
        })(),
        errorTaxonomyEvidence: selfRef._errTaxonomy ? rspErrorTaxonomyEvidence(selfRef._errTaxonomy) : undefined, // v2.8.0(W-02): 4層ErrorKind分類
        subtitleEvidence: ((typeof rspSubtitleEvidenceBlock === 'function') ? rspSubtitleEvidenceBlock(this._masterTxt, this.variants) : undefined), // v2.9.0(A-09): 字幕レンディション観測(取得しない・未供給環境では出さない)
        ...(this._cdn404Retries?{segment404Evidence:{retries:this._cdn404Retries,recoveredSegments:this._cdn404Recovered||0,failedSegments:this._cdn404Drops||0}}:{}),
        ...(this._transientTransferRetries?{segmentTransferRetryEvidence:{retries:this._transientTransferRetries,recoveredSegments:this._transientTransferRecovered||0,failedSegments:this._transientTransferDrops||0}}:{}),
        ...(this._badPlaylistTotal?{playlistParseGraceEvidence:{transientFailures:this._badPlaylistTotal,recoveredPolls:this._badPlaylistRecovered||0}}:{}),
        adFilterEvidence:{adKeywordConfigured:!!(this._adKeywordRe||this.adKeyword()),videoScte35Indicators:this._hlsScte35Indicators||0,audioScte35Indicators:(this.audio&&this.audio._hlsScte35Indicators)||0,videoFilteredSegments:this._hlsAdFilteredSegments||0,audioFilteredSegments:(this.audio&&this.audio._hlsAdFilteredSegments)||0},
        partContinuityEvidence: ((typeof rspPartContinuityEvidence === 'function') ? rspPartContinuityEvidence({
          splitMinutes: (typeof this.splitMinutes === 'function') ? this.splitMinutes() : 0,
          maxSizeMb: Math.round(((typeof this.fileCapBytes === 'function') ? this.fileCapBytes() : 600 * 1048576) / 1048576),
          splitOnDiscontinuity: (typeof this.splitOnDiscontinuity === 'function') ? this.splitOnDiscontinuity() : false,
          discontinuityMergedCount: (this._hlsContinuity && this._hlsContinuity.discontinuityMergedCount) || 0,
          discontinuitySplitCount: (this._hlsContinuity && this._hlsContinuity.discontinuitySplitCount) || 0,
          sameSessionStandbyContinuations: this._sameSessionStandbyContinuations || 0,
          partsConcatenated: 0,
          concatOutput: null
        }) : undefined), // v2.11.0(W-05): TS細切れ防止・単一ファイル継続の証拠,
        externalDownloaderEvidence: ((typeof rspExternalDownloaderEvidence === 'function') ? rspExternalDownloaderEvidence(
          rspBuildM3u8dlExport({
            url: this.activePlaylist || '',
            saveName: 'RPLAY_' + this.id,
            headers: { Referer: 'https://rplay.live/' },
            liveRealTimeMerge: true
          }),
          {
            tsDisguiseStrippedCount: this._hlsDisguiseStripped || 0,
            tsDisguiseBytesTotal: this._hlsDisguiseBytes || 0,
            queryInheritedCount: this._hlsQueryInherited || 0
          }
        ) : undefined), // v2.15.0(C-01/C-02/C-03): cat-catch知見(TS偽装ヘッダ除去・クエリ継承・m3u8dl連携)
        aesFallbackEvidence: (this._aesFallback && this._aesFallback.attempts > 0) ? Object.assign({}, this._aesFallback) : undefined, // v2.37.0(N-01)
        continuityCounterEvidence: ((typeof HLS !== 'undefined' && HLS.ccEvidence) ? HLS.ccEvidence(this._hlsCcAudit) : undefined), // v2.37.0(N-03)
        parts: this.partsLog.slice()
      };
      this._lastInfo = info; // v1.10.0: 試験フック用
      try {
        const name = 'RPLAY_' + safeName(this.creatorName()) + '_' + stampNow() + '_info.json';
        RECENV.download(new Blob([JSON.stringify(info, null, 2)], { type: 'application/json' }), name); // v2.0 Step1
        this.log('録画情報JSONを保存: ' + name + ' (パート' + info.parts.length + '本)');
        if (this.csvOut()) this.saveInfoCsv(info); // v1.10.0: 統計CSV
      } catch (e) {
        this.log('情報JSONの保存に失敗: ' + (e && e.message || e));
      }
    }

    /* ---- パート(ファイル)入出力 ---- */
    ensurePart() {
      if (this.partOpen) return;
      this.partExt = (this.medium === 'flv') ? 'flv' : (this.mediaFormat==='mp4'?'mp4':'ts');
      const _d = new Date(); // v1.10.0: テンプレート対応(未設定なら従来命名)
      this.partName = recFileName(this.nameTpl(), {
        date: '' + _d.getFullYear() + pad2(_d.getMonth() + 1) + pad2(_d.getDate()),
        time: pad2(_d.getHours()) + pad2(_d.getMinutes()) + pad2(_d.getSeconds()),
        creator: this.creatorName(), title: this.recTitle(),
        quality: this.qualityTxt || '', part: this.partIndex + 1, ext: this.partExt
      }, 'RPLAY_' + safeName(this.creatorName()) + '_' + stampNow() +
        '_p' + (this.partIndex + 1) + '.' + this.partExt);
      this.partOpen = true;
      this.bytes = 0; this.segCount = 0; this.chunks = [];
      this.fileStartedAt = Date.now();
      this._partAuditStart=rspPartCommit.snapshot(this,HLS);
      if(typeof HLS.startPartAudit==='function')HLS.startPartAudit(this);
      this.partIO = new RecPartSink(this.partName, this.dirHandle, this.partExt);
      this.partName = this.partIO.name;
    }

    async pushData(u8) {
      this.ensurePart();const io=this.partIO;
      io.push(u8);this.bytes+=u8.length;this.bytesTotal+=u8.length;
      try { await io.flush(); }
      catch (e) {
        this.log('ディスク書き込み失敗 — 録画を停止します');
        if(this.rec)this.stopFinal('write_error','音声書き込み失敗');
        else this.stop(false);
        throw e;
      }
    }

    waitForSaves() { return recWaitSaves(this); }
    closePart() {
      if (!this.partOpen) return Promise.resolve();
      this.partOpen=false;
      const io=this.partIO, bytes=this.bytes, ext=this.partExt;
      const auditFrom=this._partAuditStart,auditTo=rspPartCommit.snapshot(this,HLS);this._partAuditStart=null;
      const partSeq=typeof HLS.takePartAudit==='function'?HLS.takePartAudit(this):null;
      const entry={file:this.partName,ext,bytes,segments:this.segCount||0,
        startedAt:new Date(this.fileStartedAt).toISOString(),endedAt:new Date().toISOString(),saveState:'pending',
        structureValidated:(ext==='ts'||ext==='mp4')};
      if (false) entry.kind='audio';
      if(bytes>0){if(!this._joinParts)this._joinParts=[];if(this._joinParts.length<4096)this._joinParts.push(entry);else this._joinTruncated=true;if(this.partsLog.length>=500)this.partsLog.shift();this.partsLog.push(entry);}
      this.partIO=null;this.chunks=[];this.bytes=0;this.segCount=0;this.partIndex++;
      const job=io.close().then(result=>{
        rspPartCommit.correlate(entry,auditFrom,auditTo,result,entry.kind||'video',partSeq);
        entry.saveState=result.stage;
        entry.hashState=result.hashHex?'hashed':'unavailable';
        if(bytes>0&&result.confirmed){this.filesSaved++;if(this.filesByExt)this.filesByExt[ext]=(this.filesByExt[ext]||0)+1;}
        else if(bytes>0)this.saveRequests=(this.saveRequests||0)+1;
        if(bytes>0)this.log((result.confirmed?'ローカル保存確定: ':'DL要求・完了未確認: ')+entry.file);
        if(bytes>0)recLedgerStage(entry,'REQUESTED',{at:new Date(this.fileStartedAt).toISOString(),segments:entry.segments});
        if(bytes>0&&result.confirmed){
          recLedgerStage(entry,'FILE_WRITTEN',{bytes:bytes,sinkStage:result.stage});
          if(result.stage!=='FILE_CLOSED')recLedgerStage(entry,'BROWSER_DONE',{sinkStage:result.stage,bytes:bytes});
        }
        if(bytes>0&&result.hashHex){entry.sha256=result.hashHex;recLedgerStage(entry,'HASHED',{sha256:result.hashHex});}
        if(bytes>0)entry.ledgerStatus=recLedgerStatus(entry);
        if(bytes>0&&typeof this.persistSession==='function')this.persistSession();
        return result;
      }).catch(()=>{rspPartCommit.correlate(entry,auditFrom,auditTo,{stage:'ERROR',confirmed:false},entry.kind||'video',partSeq);entry.saveState='failed';if(bytes>0){recLedgerStage(entry,'REQUESTED',{at:new Date(this.fileStartedAt).toISOString(),segments:entry.segments});entry.ledgerStatus='failed';}this.failedSaves=(this.failedSaves||0)+1;this.log('保存失敗: '+entry.file+' — 元データ/復旧状態を確認してください');});
      return recTrackSave(this,job);
    }

    maybeSplit() {
      if (!this.partOpen) return;
      const minMs = this.splitMinutes() * 60000;
      if ((minMs > 0 && Date.now() - this.fileStartedAt >= minMs) ||
          (!(minMs===0 && this.partIO && typeof this.partIO.continuousDisk==='function' && this.partIO.continuousDisk()) && this.bytes >= (this.partIO && this.partIO.writer ? this.fileCapBytes() : Math.min(this.fileCapBytes(),REC_FILE_CAP_BYTES)))) {
        const ev=this._hlsPartBoundaries||(this._hlsPartBoundaries={});const reason=this.bytes>=(this.partIO&&this.partIO.writer?this.fileCapBytes():Math.min(this.fileCapBytes(),REC_FILE_CAP_BYTES))?'sizeLimit':'timeLimit';ev[reason]=(ev[reason]||0)+1;
        this.log('自動分割: ' + (this.bytes / 1048576).toFixed(1) + 'MB を保存(' + (this.partIndex + 1) + '本目)');
        this.closePart();
      }
    }

    /* ---- メインループ(3秒tick / 実アクセスは適応間隔でゲート) ---- */
    async tick() {
      if (this.stopped || this.busy || this._resolvingResume) return;
      this.busy = true;
      this.tickN++;
      if ((this.tickN % REC_SESSION_WRITE_EVERY) === 0) this.persistSession(); // 約6秒ごとに永続化
      try {
        this._spd.push([Date.now(), this.bytesTotal]);
        if (this._spd.length > 12) this._spd.shift();
        if (this.state === 'RUN' && this.medium === 'ts') {
          if (!this.pendingEnd && Date.now() - this.lastPollAt >= this.curPollMs) await this.pollPlaylist();
          await this.drain();
          if (this.audio) await this.audio.tick();
          if (this.pendingEnd && this.queue.length===0 && (!this.audio || !this.audio.running || (!this.audio._busy && this.audio.queue.length===0))) {
            const r = this.pendingEnd;
            this.pendingEnd = null;
            this.finishRun(r);
          } else if (this.state === 'RUN') {
            this.checkStall();
            this.maybeSplit();
            this.maybeQualityUpgrade(); // v1.9.0: 画質昇格の定期再走査(内部で節流・非同期)

          }
        } else if (this.state === 'RUN' && this.medium === 'flv') {
          this.maybeSplit(); // FLV受信ループが別途動作中。分割判定のみ
        } else if (this.state === 'STANDBY') {
          if (Date.now() - this.lastStandbyAt >= this.standbyInterval()) await this.standbyProbe();
        }
        this.updateTitle();
        this.ui.recUpdate(this.stats());
      } catch (e) {}
      this.busy = false;
    }

    checkStall() {
      if (this.queue.length === 0 && Date.now() - this.lastNewSegAt > REC_END_STALL_MS) {
        this.pendingEnd = '新セグメント' + Math.round(REC_END_STALL_MS / 1000) + '秒間停止';
      }
    }

    finishRun(reason) {
      if (!this.recording) return;
      if (this.follow()) {
        this.state = 'STANDBY';
        this.standbySince = Date.now();
        this.abortFlv();
        if (this.audio) this.audio.pause('standby'); // v1.11.0: 音声も確定保存(次セッションで再評価)
        this.closePart(); // 終了時点までのデータを確定保存
        this.medium = 'ts';
        this.log('配信終了を検出(' + reason + ') → 追跡待機へ。次の配信を自動探索します(' +
          Math.round(REC_STANDBY_MS / 1000) + '秒間隔・ジッタ付き)');
        this.ui.recState(true, 'STANDBY', 'ts');
        this.notify('RPLAY録画 — 追跡待機', '配信終了を検出。次の配信で自動録画を再開します(' + this.creatorName() + ')');
        this.persistSession();
      } else {
        this.stop(true);
      }
    }

    /* ---- プレイリスト監視(HLS録画) ---- */
    async probePlaylist(candidate) {
      const base=candidate||this.playlistUrl();
      try {
        const classify=r=>{
          if(r.status===401||r.status===403)return 'token';
          if(r.status===404||r.status===410)return 'offline';
          if(r.status!==200)return 'server';
          if(!/^\uFEFF?#EXTM3U(?:\r?\n|$)/.test(r.txt||''))return 'offline';
          // An ended media playlist must not keep background recording alive.
          if(/^#EXT-X-ENDLIST(?:\r?$)/m.test(r.txt))return 'offline';
          return /^#EXTINF:/m.test(r.txt)?'live':null;
        };
        const result=await this.fetchPlaylistOnce(base),state=classify(result);
        if(state)return state;
        if(/^#EXT-X-STREAM-INF:/m.test(result.txt||'')){
          const variant=this.resolveVariantUrl(result.txt,base);
          if(variant)return classify(await this.fetchPlaylistOnce(variant))||'offline';
        }
        return 'offline';
      }catch(e){return 'server';}
    }

    /* RPLAY API: {"viewerCount":n,"streamState":"live"|"twitch"|...} */
    async apiStreamState() {
      try {
        const ctl = new AbortController();
        const to = setTimeout(() => ctl.abort(), REC_API_TIMEOUT_MS);
        const res = await fetch(this.apiBase + '/live/stream?creatorOid=' + encodeURIComponent(this.id),
          { cache: 'no-store', signal: ctl.signal });
        clearTimeout(to);
        if (res.status !== 200) return 'off';
        let j = null;
        try { j = await res.json(); } catch (e2) { return 'unknown'; }
        return (j && j.streamState === 'live') ? 'live' : 'off';
      } catch (e) { return 'unknown'; } // CORS/ネットワーク: 判定不能(m3u8 probeを優先)
    }

    /* サーバー負荷配慮: プレイリスト取得間隔はTARGETDURATION基準(公式プレイヤー級) */
    pollInterval(changed=true) { return recHlsReloadMs(this.targetDur,changed); }
    standbyInterval() {
      return Math.round(REC_STANDBY_MS * (1 - REC_POLL_JITTER + Math.random() * REC_POLL_JITTER * 2));
    }

    /* ---- v1.7.0: 新旧基盤の源フォールバック ---- */
    /* 単一源の生存確認(#EXTM3U/#EXTINF/#EXT-X-STREAM-INFのいずれか) */
    async probeSourceOk(base) {
      if(!base)return false;
      return (await this.probePlaylist(base)) === 'live';
    }
    /* 源の再探査: live/playを最新化し、採用源を除く候補を試して切替する。
     BytePlus→IVS等の基盤変更(突然の切替)への追従用。60秒節流。 */
    async refreshLiveSource(reason) {
      if (this.urlMode()) return false; /* v2.40.0: URL録画はRPLAY APIで源を探査しない */
      if (this._srcRefrAt && Date.now() - this._srcRefrAt < 60000) return false;
      this._srcRefrAt = Date.now();
      try {
        const q = new URLSearchParams({ creatorOid: this.id });
        RspAuth.probe();
        for (const k in RspAuth.requestorQuery()) q.set(k, RspAuth.requestorQuery()[k]);
        const r = await authedJson(this.apiBase + '/live/play?' + q.toString(), { timeoutMs: 8000 });
        this.liveInfo = (r && r.ok && r.json) ? r.json : null;
        if (this.liveInfo) this.noteStreamStart(this.liveInfo);
      } catch (e) { /* 詮索失敗 → 旧情報のまま候補を試す */ }
      const cur = this.playlistUrl();
      const cands = rspSourceCandidates(this.liveInfo, CDN_BASE + this.id + '.m3u8');
      for (const base of cands) {
        if (base === cur || base === this.memberPlaylist || base === (this.getCustomM3u8 ? this.getCustomM3u8() : '')) continue;
        if (await this.probeSourceOk(base)) {
          this.liveM3u8 = base;
          this.resetQualityState(); // v1.9.0: 基盤切替時は画質状態を引き継がない
          this.sourceKind = base === (this.liveInfo && this.liveInfo.playUrl) ? 'ivs' :
            (base === (this.liveInfo && this.liveInfo.bytePlusPlaybackUrl) ? 'abr' : 'legacy');
          // v1.10.0: 基盤切替の統計
          this.sourceSwitches++;
          this.sourceHistory.push({ at: new Date().toISOString(), to: this.sourceKind });
          if (this.sourceHistory.length > 20) this.sourceHistory.shift();
          this.log('HLS源を切替(' + (reason || '探査') + '): ' + this.sourceKind.toUpperCase() + ' ' + base);
          return true;
        }
      }
      return false;
    }

    /* v1.7.0: master playlist(#EXT-X-STREAM-INF付き)→最高画質variant(media playlist)の解決。
     BytePlusのabr.m3u8はmaster一覧で、variant(/live/<id>_abrhd/index.m3u8等)を
     セグメントとして扱ってしまう旧実装のバグを修正。解決結果はキャッシュ。
     v1.9.0: 選択基準を「解像度→fps→帯域」の最高に更新(qualityFrom経由)。
     副作用: this.variants/selVariant/qualityTxtを更新する。 */
    resolveVariantUrl(txt, base) {
      const best = this.qualityFrom(txt, base);
      return best ? best.url : null;
    }
    /* プレイリスト1件fetch(200:text / その他: status) — pollPlaylistとvariant降下で共用 */
    async fetchPlaylistOnce(base) {
      const url=base;
      const startedAt=Date.now(),generation=this._hlsGeneration||0;
      if(!this._hlsPlaylistTransfer)this._hlsPlaylistTransfer=HLS.createTransfer(fetch,REC_API_TIMEOUT_MS);
      let r=await this._hlsPlaylistTransfer.request({uri:url},2*1048576);
      if(!HLS.alive(this,generation))return {status:0};
      if(r.status===403 && !this.urlMode() && typeof RECENV.butterToken==='function'){ /* v2.40.0: URL録画は外部ホストへ資格を送らない */
        this.noteErrKind('AUTH');
        try{
          const bt=await RECENV.butterToken();
          if(bt && HLS.alive(this,generation)){
            r=await this._hlsPlaylistTransfer.request({uri:url,butter:bt},2*1048576);
            if(!HLS.alive(this,generation))return {status:0};
          }
        }catch(e){}
      }
      if(r.bytes){
        const txt=new TextDecoder().decode(r.bytes);
        if(txt.indexOf('#EXT-X-STREAM-INF')<0&&txt.indexOf('#EXT-X-TARGETDURATION:')>=0){this._lastMediaRequestStart=startedAt;this._lastMediaRequestUri=base;}
        return {status:r.status,txt};
      }
      if(r.status>=500)this.noteErrKind('SOURCE');
      else if(r.status===0)this.noteErrKind('NETWORK');
      else if(r.status===401||r.status===403)this.noteErrKind('AUTH');
      return {status:r.status,retryAfter:recRetryAfterMs(r.retryAfter)};
    }

    /* ---- v1.9.0: 画質選択(最高画質) ----
     master playlistから最高variant(解像度→fps→帯域)を選び、録画中も定期
     再走査で昇格/消失フォールバックする(streamlink/N_m3u8DL-RE踏襲)。 */
    resetQualityState() {
      this.masterUrl = ''; this._variantOf = ''; this.variants = [];
      this.selVariant = null; this.qualityTxt = '';
      this.deadVariants.clear();
      this._qUpAt = 0; this._qFbAt = 0;
    }
    qualityFrom(txt, base) {
      this._masterTxt = String(txt || ''); // v1.10.0: 音声グループ解析用に原文を保持
      const vars = parseVariants(txt, base);
      if (!vars.length) return null;
      const best = this.bestQ() ? pickBestVariant(vars, this.deadVariants) : vars[0];
      if (!best) return null;
      this.variants = vars;
      this.selVariant = best;
      this.qualityTxt = qualityLabel(best);
      return best;
    }
    qualityCandidatesText() {
      const labs = [];
      for (let i = 0; i < this.variants.length && i < 6; i++) labs.push(qualityLabel(this.variants[i]));
      return labs.join(' / ');
    }
    /* variantの切替(画質昇格/消失フォールバック共通):
     現パートを区切って保存(画質が混在するファイルを作らない)し、
     新variantのライブエッジから継続(既存ウィンドウは重複防止で除外) */
    applyVariantSwitch(nextUrl, why) {
      if (this.partOpen && this.bytes > 0) this.closePart();
      this._variantOf = nextUrl;
      this._skipBacklog = true;
      this.lastMediaSeq = -1;
      this.log(why);
      if (this.audio) this.audio.sync('variant切替'); // v1.11.0: AUDIO属性が変わったら音声も追従再解決
    }
    /* master再走査: より高い画質が出現していれば昇格(下げはしない) */
    async maybeQualityUpgrade() {
      if (!this.masterUrl || !this.bestQ() || this._qUpRunning) return;
      if(this.bytesTotal>0)return; // 録画開始後は画質昇格による不要な分割を抑える。消失時fallbackは維持。
      if (Date.now() - this._qUpAt < REC_QUALITY_RESCAN_MS) return;
      this._qUpAt = Date.now();
      this._qUpRunning = true;
      try {
        const r = await this.fetchPlaylistOnce(this.masterUrl);
        if (r.status !== 200 || !r.txt) return;
        this._masterTxt = r.txt; // v1.11.0: 音声解析用の原文も更新
        const vars = parseVariants(r.txt, this.masterUrl);
        if (!vars.length) return;
        this.variants = vars;
        const best = pickBestVariant(vars, this.deadVariants);
        if (!best || !this.selVariant) return;
        if (best.url !== this._variantOf && isBetterVariant(best, this.selVariant)) {
          const from = this.qualityTxt;
          this.selVariant = best;
          this.qualityTxt = qualityLabel(best);
          this.qualityUpgrades++;
          this.qualityHistory.push({ at: new Date().toISOString(), from: from || '', to: this.qualityTxt, why: 'upgrade' }); // v1.10.0
          if (this.qualityHistory.length > 20) this.qualityHistory.shift();
          this.deadVariants.clear();
          this.applyVariantSwitch(best.url,
            '画質を昇格: ' + (from || '不明') + ' → ' + this.qualityTxt + ' — パートを区切って新しい画質で録画を続行します');
        }
      } catch (e) { /* 再走査失敗 → 次回 */ }
      finally { this._qUpRunning = false; }
    }
    /* variant消失(404/410)時: masterから次の画質へフォールバック。
     戻り値: 切替先のvariant(切替不可ならnull) */
    async fallbackVariant(deadUrl) {
      if (!this.masterUrl || !this.bestQ()) return null;
      if (Date.now() - this._qFbAt < REC_QUALITY_FALLBACK_MS) return null;
      this._qFbAt = Date.now();
      try {
        const r = await this.fetchPlaylistOnce(this.masterUrl);
        if (r.status !== 200 || !r.txt) return null;
        this._masterTxt = r.txt; // v1.11.0: 音声解析用の原文も更新
        this.deadVariants.add(deadUrl);
        const vars = parseVariants(r.txt, this.masterUrl);
        if (!vars.length) return null;
        this.variants = vars;
        const best = pickBestVariant(vars, this.deadVariants);
        if (!best || best.url === deadUrl) return null;
        const from = this.qualityTxt;
        this.selVariant = best;
        this.qualityTxt = qualityLabel(best);
        this.qualityFallbacks++; // v1.10.0: フォールバック統計
        this.qualityHistory.push({ at: new Date().toISOString(), from: from || '', to: this.qualityTxt, why: 'fallback' });
        if (this.qualityHistory.length > 20) this.qualityHistory.shift();
        this.applyVariantSwitch(best.url,
          'variantが消失(404) → 次の画質へフォールバック: ' + (from || '不明') + ' → ' + this.qualityTxt + ' — 録画を継続します');
        return best;
      } catch (e) { return null; }
    }

    async pollPlaylist() {
      if (Date.now() < this.plBackoffUntil) return; // 403/429バックオフ中は静かに待機
      const base = this.playlistUrl();
      let effBase = base;
      let txt = null;
      let saw404 = false;
      let saw403 = false;
      let saw401 = false;
      let saw429 = false;
      let saw429RA = 0; // v1.12.0: Retry-After(サーバー指定待機)
      this.lastPollAt = Date.now();
      this.pollCount++; // v1.10.0: 統計
      // v1.9.0: 解決済みvariantの直接ポーリング(master再取得を省略 — リクエスト数を
      // 半減。masterは画質昇格チェック(maybeQualityUpgrade)でのみ定期再走査する。
      // streamlink/N_m3u8DL-REと同じ「lock→定期再走査」モデル)
      const cachedVariant = this.bestQ() && this.masterUrl === base && this._variantOf;
      try {
        if (cachedVariant) {
          effBase = this._variantOf;
          const rv = await this.fetchPlaylistOnce(effBase);
          if (rv.status === 200) txt = rv.txt;
          else if (rv.status === 404 || rv.status === 410) {
            // variant消失 → 次の画質へフォールバックを試す
            const fb = await this.fallbackVariant(effBase);
            if (fb) {
              effBase = fb.url;
              const r3 = await this.fetchPlaylistOnce(effBase);
              if (r3.status === 200) txt = r3.txt; else { saw404 = true; txt = null; }
            } else { saw404 = true; txt = null; }
          }
          else if (rv.status === 403 || rv.status === 401) { saw403 = true; txt = null; }
          else if (rv.status === 429) { saw429 = true; saw429RA = rv.retryAfter || saw429RA; txt = null; } // v1.12.0
          else txt = null;
        } else {
          const r1 = await this.fetchPlaylistOnce(base);
          if (r1.status === 200) {
            txt = r1.txt;
            /* master playlistなら最高画質variantへ一段降りて即再取得
             (abr.m3u8等。源がmasterのまま録画に回る旧バグはv1.7.0で修正、
              v1.9.0で選択基準を「解像度→fps→帯域」の最高に更新) */
            if (txt.indexOf('#EXT-X-STREAM-INF') >= 0) {
              this.masterUrl = base;
              const v = this.resolveVariantUrl(txt, base);
              if (v) {
                if (this._variantOf !== v) {
                  this._variantOf = v;
                  this.log('master playlist → variant解決: ' + v);
                  this.log('画質: ' + this.qualityTxt + ' を選択' +
                    (this.variants.length > 1 ? '(最高・候補' + this.variants.length + '件: ' + this.qualityCandidatesText() + ')' : ''));
                  this.logAudioInfo(); // v1.10.0: 音声レンディションの表示
                  if (this.audio) this.audio.sync('variant解決'); // v1.11.0: 音声源の解決/再解決
                }
                effBase = v;
                const r2 = await this.fetchPlaylistOnce(v);
                if (r2.status === 200) txt = r2.txt;
                else if (r2.status === 404 || r2.status === 410) {
                  const fb = await this.fallbackVariant(v);
                  if (fb) {
                    effBase = fb.url;
                    const r3 = await this.fetchPlaylistOnce(effBase);
                    if (r3.status === 200) txt = r3.txt; else { saw404 = true; txt = null; }
                  } else { if (rspDetectPaywallBlocked(200, r2.status)) { this.noteErrKind('AUTH'); this.log('master 200 / variant ' + r2.status + ' (paywall_blocked: 有料壁/権限不足の可能性)'); } saw404 = true; txt = null; }
                }
                else if (r2.status === 403 || r2.status === 401) { saw403 = true; txt = null; }
                else if (r2.status === 429) { saw429 = true; saw429RA = r2.retryAfter || saw429RA; txt = null; } // v1.12.0
                else txt = null;
              } else {
                this.log('master playlistだがvariantが解決できません — 次tickで再確認');
                txt = null;
              }
            } else if (this.masterUrl === base) {
              // 源がmedia playlistに戻った(基盤切替後など) → 画質状態をリセット
              this.resetQualityState();
            }
          }
          else if (r1.status === 404 || r1.status === 410) saw404 = true;
          else if (r1.status === 403 || r1.status === 401) saw403 = true;
          else if (r1.status === 429) { saw429 = true; saw429RA = r1.retryAfter || saw429RA; } // v1.12.0
          // 5xx/タイムアウトは一時障害扱い(次tickで再試行)
        }
      } catch (e) { /* 次tickで再試行 */ }
      if (this.stopped) return;

      const dirBase = effBase.slice(0, effBase.lastIndexOf('/') + 1);
      if (saw403 || saw401) {
        const code = saw401 ? '401' : '403';
        // アクセス制限 — 連打せず待機(サーバー配慮)。404とは区別(終了扱いにしない)
        this.plBackoffUntil = Date.now() + REC_403_COOLDOWN_MS;
        this.log('プレイリスト' + code + ' — アクセス制限の可能性。' +
          Math.round(REC_403_COOLDOWN_MS / 1000) + '秒待機して再確認します');
        if (this.accessMode === 'member') {
          // v1.8.0: 録画中の限定playlist 401/403 → key2/トークンを更新して再解決
          // (JWT短命化(約4分)・key2失効への追従。90秒節流でサーバーに優しく)
          if (Date.now() - (this.memberReResolveAt || 0) > 90000) {
            this.memberReResolveAt = Date.now();
            this.log('限定プレイリストが制限されました(' + code + ') — 鍵(key2)とトークンを更新して再解決します');
            try {
              _memberResolveCache.result = null; // キャッシュを無効化して強制再取得
              const r = await this._fResolveMember(this.id, (m) => this.log(m));
              if (r && r.ok) {
                this.memberPlaylist = r.playlist;
                this.consecutive404 = 0;
                this.plBackoffUntil = 0;
                this.log('限定配信を再解決(鍵更新) → 同じplaylistで録画を継続します');
              } else {
                this.log(this._fMemberHint(r));
              }
            } catch (e) { /* 解決失敗 → 次の節流で再試行 */ }
          }
          return;
        }
        // 限定配信(会員限定)の可能性: 自分のログイン会話で解決を試みる
        // (5分節流 — サーバーに優しく)
        if (Date.now() - this.memberResolveAt > 300000) {
          this.memberResolveAt = Date.now();
          try {
            const r = await this._fResolveMember(this.id, (m) => this.log(m));
            if (r && r.ok) {
              this.memberPlaylist = r.playlist;
              this.accessMode = 'member';
              this.consecutive404 = 0;
              this.log('限定配信を解決(key2認証) → このプレイリストで録画を継続します');
              this.plBackoffUntil = 0;
            } else {
              this.log(this._fMemberHint(r));
            }
          } catch (e) { /* 解決失敗 → 通常の退避継続 */ }
        }
        return;
      }
      if (saw429) {
        this.consecutive429++;
        /* v1.12.0: Retry-After優先(サーバー指定があれば指数バックオフの代わりに使う) */
        const ms = saw429RA ||
          Math.min(REC_429_BASE_MS * Math.pow(2, this.consecutive429 - 1), REC_429_MAX_MS);
        this.plBackoffUntil = Date.now() + ms;
        this.log('レート制限(429) — サーバー負荷配慮で' + Math.round(ms / 1000) + '秒待機します' +
          (saw429RA ? '(Retry-After指定)' : ''));
        return;
      }
      this.consecutive429 = 0;

      if (saw404) {
        this.consecutive404++;
        if (this.consecutive404 === 2) {
          this.log('プレイリスト404 — 配信終了/切替の可能性、確認中');
          // 基盤切替(BytePlus→IVS等)の可能性: 源の再探査を一度だけ試す
          try {
            const switched = await this.refreshLiveSource('404確認');
            if (switched && !this.stopped) {
              this.consecutive404 = 0;      // 新源で継続(配信終了ではない)
              this.pendingEnd = null;
              return;                        // 次tickで新源のplaylistを取りに行く
            }
          } catch (e) { /* 探査失敗 → 通常の終了判定へ */ }
        }
        const limit = this.follow() ? REC_404_STANDBY : REC_404_GIVE_UP;
        if (this.consecutive404 >= limit) this.pendingEnd = 'プレイリスト404×' + this.consecutive404;
        return;
      }
      this.consecutive404 = 0;
      if (txt == null) return;

      let parsed,queued;
      try{parsed=HLS.parse(txt,effBase,this.extinfMode(),this.inheritQuery());queued=HLS.enqueue(this,parsed,effBase);}
      catch(e){
        const code=String(e&&e.message||'');
        if(this.segTotal>0&&['HLS_BAD_PLAYLIST','HLS_BAD_TARGET','HLS_DANGLING_TAG','HLS_DANGLING_RANGE','HLS_BAD_EXTINF'].includes(code)){
          this._badPlaylistConsec=(this._badPlaylistConsec||0)+1;
          this._badPlaylistTotal=(this._badPlaylistTotal||0)+1;
          if(this._badPlaylistConsec<=2){
            this.log('プレイリスト一時破損('+code+') — 録画を中断せず次回ポーリングで再確認します('+this._badPlaylistConsec+'/2)');
            return;
          }
        }
        this.log('HLSを安全に処理できません: '+code);await this.stop(false);return;
      }
      if(this._badPlaylistConsec>0){this._badPlaylistRecovered=(this._badPlaylistRecovered||0)+1;this._badPlaylistConsec=0;}
      if(parsed.target>0)this.targetDur=parsed.target;
      const changed=this._playlistBody!==txt||this._playlistUri!==effBase;
      this._playlistBody=txt;this._playlistUri=effBase;
      if(this._lastMediaRequestUri===effBase)this.lastPollAt=this._lastMediaRequestStart;
      this.curPollMs=this.pollInterval(changed);this.lastMediaSeq=parsed.sequence;
      this.gapCount+=queued.missing;
      if(queued.added||queued.skipped)this.lastNewSegAt=Date.now();
      if(queued.added){const now=Date.now();if(this._lastSegAddedAt){this.segIntervalSum+=now-this._lastSegAddedAt;this.segIntervalN++;}this._lastSegAddedAt=now;}
      if(parsed.endList)this.pendingEnd='ENDLIST(正常終了)';
    }

    async drain() {
      // v1.10.0: キュー滞留の可視化(退避中などに肥大化したら警告・60秒節流)
      if (this.queue.length > 1500 && Date.now() - this._queueWarnAt > REC_QUEUE_WARN_MS) {
        this._queueWarnAt = Date.now();
        this.log('注意: 未取得セグメントのキューが' + this.queue.length + '件に滞留しています(退避/回線の可能性)');
      }
      while (this.queue.length && !this.stopped && this.state === 'RUN') {
        if (Date.now() < this.segBackoffUntil) return; // 403/429バックオフ中は静かに待機
        const item = this.queue.shift();
        const generation=this._hlsGeneration||0;
        const r = await this.fetchSeg(item);
        if (this.stopped || (this.rec && this.rec.stopped)) return;
        if (r.data) {
          if(!await HLS.append(this,item,r,generation))return;
          this.segCount++;
          this.segTotal++;
        }
        if (r.retry) {
          // 順序厳密保証: 再試行は必ずキュー先頭に戻し、後続を書かない
          // (旧実装の「末尾再キュー」は失敗中に後続segを先に書く順序反転の潜在バグがあった)
          if (item.tries < REC_SEG_MAX_TRIES) { this.queue.unshift(item); return; }
          HLS.noteTerminal(this,item);this.segFails++;
          this.log('セグメント取得断念(' + item.tries + '回): ...' + item.name.slice(-28));
        }
      }
    }

    /* セグメント1件取得。ステータスで挙動を厳密に分類(サーバー配慮):
       200=検証して返す / 404,410=廃棄済み→即断念(再試行しない) /
       403=アクセス制限→全体で60秒待機 / 429=レート制限→指数バックオフ /
       5xx・ネットワーク・タイムアウト=時間差で再試行 */
    async fetchSeg(item) { return recFetchDescriptor(this,item); }

    /* v1.10.0: TS検証(Worker並列・同期フォールバック) */
    async verifyTs(u8) {
      if (!this._verifier) this._verifier = createTsVerifier();
      return this._verifier.check(u8);
    }
    verifyStats() {
      return {
        usingWorker: this._verifier ? this._verifier.usingWorker() : false,
        checked: this.verifyChecked
      };
    }
    /* v1.10.0: メモリ統計(長時間録画の監視フック — window.__RSP.memStats) */
    memStats() {
      const heap = RECENV.perfHeap(); // v2.0 Step1: RECENV経由
      return {
        seen: this.seen.size, queue: this.queue.length,
        chunks: this.chunks.length, partBytes: this.bytes,
        bytesTotal: this.bytesTotal, partsLog: this.partsLog.length,
        jsHeapBytes: heap
      };
    }
    /* v1.10.0: 音声レンディション表示(選択variantのAUDIO groupを表示/JSONへ) */
    logAudioInfo() {
      try {
        const g = parseAudioGroups(this._masterTxt || '', this.masterUrl || '');
        const lab = this.selVariant ? audioLabelFor(this.selVariant.audioGroup, g) : '';
        this.audioTxt = lab || '';
        if (lab) this.log('音声: ' + lab);
      } catch (e) { /* 解析失敗は表示のみスキップ */ }
    }

    /* ---- 追跡待機: 次の配信を探す(20秒間隔・ジッタ付き) ---- */
    async standbyProbe() {
      this.lastStandbyAt = Date.now();
      // 1) 同一URLのプレイリストが生き返ったか(最優先・一番確実な信号)
      const cls = await this.probePlaylist();
      if (this.stopped || !this.recording || this.state !== 'STANDBY') return;
      if (cls === 'live') { await this.resume('ts', '配信の復帰を検出'); return; }
      if (this.urlMode()) return;
      // 基盤切替(旧源が死んで新基盤で再開する)の追従: 探査で新源が生きていれば切替
      if ((cls === 'offline') && Date.now() - (this._srcRefrAt || 0) > 60000) {
        try {
          if (await this.refreshLiveSource('待機中探査')) {
            this.lastMediaSeq = -1;
            await this.resume('ts', '配信基盤の切替を検出(新源で再開)');
            return;
          }
        } catch (e) { /* 次回再試行 */ }
      }
      if (cls === 'token' && this.accessMode !== 'member' && Date.now() - this.memberResolveAt > 180000) {
        // 403が続く → 限定配信が始まった可能性(次配信が会員限定のケース)
        this.memberResolveAt = Date.now();
        try {
          const r = await this._fResolveMember(this.id, (m) => this.log(m));
          if (this.stopped || !this.recording || this.state !== 'STANDBY') return;
          if (r && r.ok) {
            this.memberPlaylist = r.playlist;
            this.accessMode = 'member';
            this.sourceKind = 'member';
            await this.resume('ts', '限定配信(会員限定)の開始を検出');
            return;
          } else {
            this.log(this._fMemberHint(r));
          }
        } catch (e) { /* 次回再試行 */ }
      }

      // 2) RPLAY API(creatorOid基準) — プレイリスト公開より早く「live」を返すことがある
      const st = await this.apiStreamState();
      if (this.stopped || !this.recording || this.state !== 'STANDBY') return;
      if (st === 'live') {
        // APIはliveだがプレイリストは無し → 限定配信の可能性(会員 playlist は公開probeに映らない)
        // または基盤切替の可能性 → 先に源探査を試す(60秒節流)
        try {
          if (await this.refreshLiveSource('API検出')) {
            this.lastMediaSeq = -1;
            await this.resume('ts', 'API検出+配信基盤の切替に成功');
            return;
          }
        } catch (e) { /* 次の限定解決へ */ }
        if (this.accessMode !== 'member' && Date.now() - this.memberResolveAt > 180000) {
          this.memberResolveAt = Date.now();
          try {
            const r = await this._fResolveMember(this.id, (m) => this.log(m));
            if (this.stopped || !this.recording || this.state !== 'STANDBY') return;
            if (r && r.ok) {
              this.memberPlaylist = r.playlist;
              this.accessMode = 'member';
              this.sourceKind = 'member';
              await this.resume('ts', 'API検出+限定配信の解決に成功');
              return;
            } else {
              this.log(this._fMemberHint(r));
            }
          } catch (e) { /* 次回再試行 */ }
        }
        this.lastStandbyAt = 0; // 次のtick(3秒後)に再探索
        return;
      }

      // 2.5) 配信予約(v1.8.0): 予約時刻の接近/到来で通知と探索強化
      //      (live/schedulesはログイン会話が必要。未ログイン/404等は静かにスキップ)
      try {
        const item = await this._fResolveSched(this.id);
        if (this.stopped || !this.recording || this.state !== 'STANDBY') return;
        if (item) {
          this.schedItem = item;
          const remainMs = item.scheduledAt - Date.now();
          const hm = new Date(item.scheduledAt).toTimeString().slice(0, 5);
          const label = '📡 予約「' + (item.title || '無題') + '」' + hm + '開始予定';
          // v1.10.0: 開始前リマインド(10分前/5分前・設定で選択・試験フックで閾値短縮可)
          const mode = this.remindMode();
          const t10 = (function () { try { const v = Number(RECENV.testHooks().remind10Ms); return v > 0 ? v : REC_REMIND10_MS; } catch (e) { return REC_REMIND10_MS; } })();
          const t5 = (function () { try { const v = Number(RECENV.testHooks().remind5Ms); return v > 0 ? v : REC_REMIND5_MS; } catch (e) { return REC_REMIND5_MS; } })();
          if (remainMs > 0 && mode !== 'off' && (mode === 'both' || mode === '10') &&
              remainMs <= t10 && remainMs > t5 && !this.schedNotified10) {
            this.schedNotified10 = true;
            this.log(label + ' — リマインド(10分前): 残り' + Math.ceil(remainMs / 60000) + '分');
            this.notify('RPLAY録画 — 予約リマインド(10分前)', label + ' 残り' + Math.ceil(remainMs / 60000) + '分');
          }
          if (remainMs > 0) {
            const remainMin = Math.ceil(remainMs / 60000);
            const key = label + '#' + remainMin;
            if (remainMin <= 5 && key !== this.schedLastLog) {
              this.schedLastLog = key;
              this.log(label + ' — 残り' + remainMin + '分');
              // v1.10.0: リマインド設定(both/5)のとき5分前通知
              if (!this.schedNotified5 && (mode === 'both' || mode === '5')) {
                this.schedNotified5 = true;
                this.log(label + ' — リマインド(5分前): 残り' + remainMin + '分');
                this.notify('RPLAY録画 — 予約配信まもなく', label + '(残り' + remainMin + '分)');
              }
            }
          } else {
            if (this.schedNotifyAt !== item.scheduledAt) {
              this.schedNotifyAt = item.scheduledAt;
              this.notify('RPLAY録画 — 予約配信の開始時刻', label + ' — 探索を強化します');
              this.log(label + ' — 開始時刻を過ぎました。探索を強化します');
            }
            this.lastStandbyAt = 0; // 次のtick(3秒後)に即時探索 → 予約配信を素早く検出
          }
        }
      } catch (e) { /* 予約なし/取得失敗 → 何もしない */ }

      // 3) FLV代替(HLS系が全滅している間の受け皿)
      //    限定配信(会員限定)ではFLV代替は使えない(公開CDNのため403) → スキップ
      if (this.accessMode === 'member') return;
      if (this.flvFallback() && !this.flvRunning && Date.now() - this.flvLastFail > REC_FLV_COOLDOWN_MS) {
        await this.tryFlv();
      }
    }

    async resume(medium, why) {
      if (!this.recording || this.stopped) return;
      /* v2.39.0: 追跡再開(全開始経路のpolicy統一)。保存済み設定が自動開始を
         禁止しているときは再開せず追跡待機を続ける(追跡自体は止めない —
         許可に戻すと次の探索で再開する)。設定が読めない場合は再開しない
         (fail-closed — BG開始のSTART_SETTINGS_UNAVAILABLEと同じ安全側)。 */
      const _policy = (typeof RECENV.autoPolicy === 'function') ? await RECENV.autoPolicy() : { verdict: 'allowed' };
      if (this.stopped || !this.recording) return; /* 判定中に状態が変わった */
      if (_policy.verdict === 'denied') {
        if (this._autoDenyKey !== 'denied') {
          this._autoDenyKey = 'denied';
          this.log('保存済み設定により自動再開は禁止されています(追跡待機は継続 — 許可すると次の探索で再開)');
          this.notify('RPLAY録画 — 自動再開を禁止', '保存済み設定により自動再開を禁止しています(' + this.creatorName() + ')');
        }
        return;
      }
      if (_policy.verdict === 'unavailable') {
        if (this._autoDenyKey !== 'unavailable') {
          this._autoDenyKey = 'unavailable';
          this.log('開始設定を確認できないため自動再開しません(次の探索で再確認します)');
        }
        return;
      }
      this._autoDenyKey = '';
      HLS.reset(this, true); /* v2.5.0: 追跡再開は録画済みpath記録を保持(復帰windowの重複防止) */
      this.medium = medium;
      this.state = 'RUN';
      this.consecutive404 = 0;
      this.lastMediaSeq = -1;
      this.resetQualityState(); // v1.9.0: 新セッションの画質を取り直す
      if (this.audio) this.audio.onNewSession(); // v1.11.0: 音声も新セッション扱い(404等の最終停止を解除)
      this._skipBacklog = false; // 再開時は新セッションの内容を全て取得
      this.lastNewSegAt = Date.now();
      this.pendingEnd = null;
      this.resumes++;
      // Reauthorize this session before any member playlist request.
      if (this.accessMode === 'member' && medium === 'ts') {
        const generation=this._hlsGeneration||0;
        this.memberPlaylist='';
        try {
          const r=await this._fResolveMember(this.id,m=>this.log(m));
          if(!HLS.alive(this,generation))return;
          if(!r||!r.ok){this.log('再開時の視聴権限を確認できませんでした');await this.stop(false);return;}
          this.memberPlaylist=r.playlist;this.sourceKind='member';
        }catch(e){if(!this.stopped){this.log('再開の認証処理に失敗しました');await this.stop(false);}return;}
      }
      if(this.stopped)return;
      this.log(why + ' → 録画を再開(' + medium.toUpperCase() +
        (this.accessMode === 'member' ? ' / 限定配信' : '') +
        ' / セッション' + (this.resumes + 1) + ')');
      this.notify('RPLAY録画 — 再開', why + '(' + this.creatorName() + ')');
      this.persistSession();
      this.ui.recState(true, 'RUN', this.medium);
      if (medium === 'ts') {
        await this.pollPlaylist();
        await this.drain();
      }
    }

    /* 再生エンジンが先にLIVEを検出したときの即時復帰確認 */
    nudgeResume() {
      if (this.recording && this.state === 'STANDBY' && !this.busy) {
        this.log('再生側がLIVEを検出 → 録画復帰を即時確認');
        this.standbyProbe().catch(function () {});
      }
    }

    /* ---- FLV代替録画(fetchストリームを無劣化保存) ---- */
    tryFlv() {
      const self = this;
      return new Promise(function (resolve) {
        let settled = false;
        const done = function (ok) { if (!settled) { settled = true; resolve(!!ok); } };
        if (!self.recording || self.stopped || self.state !== 'STANDBY' || self.flvRunning) return done(false);
        if (self.urlMode()) return done(false); /* v2.40.0: FLV代替URLはRPLAY CDN固有 — URL録画では使わない */
        /* v2.39.0: FLV代替開始も共通policyに従う(拒否/不明なら開始しない) */
        const _policy = (typeof RECENV.autoPolicy === 'function') ? RECENV.autoPolicy() : Promise.resolve({ verdict: 'allowed' });
        _policy.then(function (p) {
          if (!self.recording || self.stopped || self.state !== 'STANDBY' || self.flvRunning) return done(false);
          if (p && p.verdict === 'denied') {
            if (self._autoDenyKey !== 'flv-denied') { self._autoDenyKey = 'flv-denied'; self.log('保存済み設定によりFLV代替の自動開始は禁止されています'); }
            return done(false);
          }
          if (!p || p.verdict !== 'allowed') {
            if (self._autoDenyKey !== 'flv-unavailable') { self._autoDenyKey = 'flv-unavailable'; self.log('開始設定を確認できないためFLV代替を開始しません'); }
            return done(false);
          }
          const ctl = new AbortController();
          self.flvAbort = ctl;
          self.flvGotData = false;
          self.flvRunning = true;
          self.medium = 'flv';
          self.log('HLS不通 → FLVストリームへ代替録画を試行…');
          fetch(self.flvUrl(), { cache: 'no-store', signal: ctl.signal }).then(function (res) {
          if (!res.ok || !res.body) throw new Error('HTTP ' + res.status);
          const reader = res.body.getReader();
          let head = new Uint8Array(0);
          let headerOk = false;
          function pump() {
            return reader.read().then(async function (r) {
              if (self.stopped || !self.recording) { try { reader.cancel(); } catch (e2) {} return done(true); }
              if (r.done) throw new Error('ストリーム終端');
              const u8 = r.value;
              if (!headerOk) {
                head = u8Concat(head, u8);
                if (head.length < 9) return pump();
                if (!(head[0] === 0x46 && head[1] === 0x4c && head[2] === 0x56)) throw new Error('FLVヘッダ不一致');
                headerOk = true;
                await self.pushData(head);
                head = null;
              } else {
                await self.pushData(u8);
              }
              self.lastNewSegAt = Date.now();
              if (!self.flvGotData) {
                self.flvGotData = true;
                self.state = 'RUN';
                self.fileStartedAt = Date.now();
                if (self.audio) self.audio.onFlvStart(); // v1.11.0: FLVは音声多重 → 音声個別録画は停止
                self.log('FLV受信を確認 — FLV無劣化のまま録画を継続します');
                self.ui.recState(true, 'RUN', 'flv');
                done(true); // Promiseを解決するのみ(受信ループは継続)
              }
              return pump();
            });
          }
          pump().catch(function (e) { self.flvFailed(e, done); });
        }).catch(function (e) { self.flvFailed(e, done); });
        }).catch(function () { done(false); }); /* policy問い合わせ自体の失敗は開始しない */
      });
    }

    flvFailed(e, done) {
      const had = this.flvGotData;
      const tiny = had && this.bytes > 0 && this.bytes < 512 * 1024; // すぐ切れた小さな断片は頻発防止のため猶予
      this.flvRunning = false;
      this.flvGotData = false;
      if (this.flvAbort) { try { this.flvAbort.abort(); } catch (e2) {} this.flvAbort = null; }
      if (had) this.closePart();
      this.medium = 'ts';
      this.flvLastFail = Date.now() + (tiny ? 90000 : 0);
      if (this.recording && !this.stopped && this.state === 'RUN') {
        this.state = 'STANDBY';
        this.standbySince = Date.now();
        this.ui.recState(true, 'STANDBY', 'ts');
        this.log('FLV切断(' + (e && e.message || e) + ') → 追跡待機へ戻る');
      }
      if (done) done(had);
    }

    abortFlv() {
      if (this.flvAbort) { try { this.flvAbort.abort(); } catch (e) {} this.flvAbort = null; }
      this.flvRunning = false;
    }

    /* ---- 保存先フォルダ(File System Access API) ---- */
    async pickFolder() {
      if (this.dirHandle) {
        this.dirHandle = null;
        this.dirLabel = '';
        return null; // 解除
      }
      if (!window.showDirectoryPicker) {
        throw new Error('このブラウザは保存先フォルダ機能に非対応です(Chrome/Edge推奨)');
      }
      const dh = await window.showDirectoryPicker({ mode: 'readwrite' });
      this.dirHandle = dh;
      this.dirLabel = dh.name || 'folder';
      return this.dirLabel;
    }

    /* ---- 統計 / タイトル ---- */
    stats() {
      return {
        recording: this.recording,
        state: this.state,
        medium: this.medium,
        elapsedMs: this.recording ? Date.now() - this.startedAt : 0,
        standbyMs: this.state === 'STANDBY' ? Date.now() - this.standbySince : 0,
        partMb: this.bytes / 1048576,
        totalMb: this.bytesTotal / 1048576,
        seg: this.segCount,
        total: this.segTotal,
        speedMBs: this.speedMBs(),
        fails: this.segFails,
        gap: this.gapCount,
        files: this.filesSaved, saveRequests:this.saveRequests||0, failedSaves:this.failedSaves||0,
        filesTs: this.filesByExt.ts || 0,
        filesFlv: this.filesByExt.flv || 0,
        pending: this.queue.length,
        part: this.partIndex + (this.partOpen ? 1 : 0),
        resumes: this.resumes,
        schedMs: (this.schedItem && this.schedItem.scheduledAt > Date.now())
          ? this.schedItem.scheduledAt - Date.now() : 0,
        schedTitle: this.schedItem ? this.schedItem.title : '',
        quality: this.qualityTxt || '',
        audio: this.audioTxt || '',          // v1.10.0
        audioRec: this.audio ? this.audio.running : false, // v1.11.0: 音声併録中はREC表示に+audio
        audioSt: this.audio ? this.audio.stats() : null,   // v1.11.0: 音声録画の詳細統計
        pollCount: this.pollCount,           // v1.10.0
        sourceSwitches: this.sourceSwitches, // v1.10.0
        qualityFallbacks: this.qualityFallbacks, // v1.10.0
        adFiltered: this._hlsAdFilteredSegments || 0, // v2.48.0
        scte35: this._hlsScte35Indicators || 0,       // v2.48.0
        verify: this.verifyStats()           // v1.10.0
      };
    }

    /* 直近約30秒の平均転送速度(MB/s) */
    speedMBs() {
      const sp = this._spd;
      if (sp.length < 2) return 0;
      const a = sp[0], b = sp[sp.length - 1];
      const dt = (b[0] - a[0]) / 1000;
      if (dt <= 0) return 0;
      return Math.max(0, (b[1] - a[1]) / 1048576 / dt);
    }

    updateTitle(force) {
      if (!this.recording) return;
      const min = Math.floor((Date.now() - this.startedAt) / 60000);
      if (force || min !== this._titleMin) {
        this._titleMin = min;
        try {
          if (this._titleBase == null) this._titleBase = RECENV.getTitle();
          const tag = (this.state === 'STANDBY') ? '⏸追跡中' : '●REC';
          RECENV.setTitle(tag + ' ' + fmtDur(Date.now() - this.startedAt) + ' - ' + this._titleBase);
        } catch (e) {}
      }
    }

    restoreTitle() {
      const base = this._titleBase;
      if (base != null) RECENV.setTitle(base); // v2.0 Step1: RECENV経由
      this._titleBase = null;
      this._titleMin = -1;
    }
  }
  /* ==== RSP RECORDING CORE — v2.0 Step1 切出し(END) ==== */
  /* ===== user.js同期コアここまで ===== */

  /* =====================================================================
     offscreenホスト側: UIシム + メッセージプロトコル(表5) + 試験ブリッジ
     ===================================================================== */

  /* UIシム: コアが参照するUIアクセサを設定値(rec.startで受領)で実装し、
     表示更新は rec.event としてUIタブへ送る(節流: stats 1秒1回・log末尾120行) */
  let _lastStatsAt = 0;
  function makeUiShim(binding) {
    const emit=obj=>MSG.send({...obj,sessionId:binding.sessionId,epoch:binding.epoch,oid:binding.oid});
    return {
      el: null,
      log: function (m) {
        const line = '[' + new Date().toTimeString().slice(0, 8) + '] ' + String(m).replace(/https?:\/\/\S+/g,'[URL]');
        LOGTAIL.push(line);
        if (LOGTAIL.length > 120) LOGTAIL.shift();
        emit({ type: 'rec.event', kind: 'log', line: line });
      },
      recState: function (on, state, medium) {
        if(state==='DRAINING' && CONTROL_GATE.binding()===binding)CONTROL_GATE.draining(binding);
        emit({ type: 'rec.event', kind: 'state', on: !!on, state: state, medium: medium });
        if (!on && state === 'IDLE') {emit({ type: 'rec.stopped' });CONTROL_GATE.end(binding);}
      },
      recUpdate: function (s) {
        const now = Date.now();
        if (now - _lastStatsAt < 900) return;
        _lastStatsAt = now;
        emit({ type: 'rec.event', kind: 'stats', stats: s });
      },
      followChecked: function () { return SET.follow; },
      flvFallbackChecked: function () { return SET.flv; },
      backlogChecked: function () { return SET.backlog; },
      infoJsonChecked: function () { return SET.infoJson; },
      notifyChecked: function () { return SET.notify; },
      bestQualityChecked: function () { return SET.bestQ; },
      recAudioChecked: function () { return SET.recAudio; },
      nameTplValue: function () { return SET.nameTpl; },
      csvChecked: function () { return SET.csv; },
      remindValue: function () { return SET.remind; },
      inheritQueryChecked: function () { return SET.inheritQuery === true; },
      splitMinutes: function () { return SET.splitMin; },
      autoStopChecked: function () { return false; },
      autoRecChecked: function () { return false; }
    };
  }

  /* ---- v2.48.0(統合): BG停止後MP4自動引渡し(既定OFF・非破壊) ----
     録画停止・異常終了後にrsp_recへ残ったTSパートをMP4へ自動変換し
     保存台帳(export journal)へ引き渡す。元TSは削除・変更しない。
     変換は録画が無い場合のみ単発で実行し、URL等は記録しない。
     変換ライブラリ(sha256/mp4_codec_core/mp4_convert_core/mux/mp4_browser_io)
     はoffscreen.html・Firefox BGページで事前読み込み済みの前提。 */
  const HOST_BOOT_AT = Date.now();
  const MP4_HANDOFF = (typeof RspMp4Handoff === 'object' && RspMp4Handoff) ? RspMp4Handoff.create({
    now: function () { return Date.now(); },
    crypto: typeof crypto !== 'undefined' ? crypto : undefined,
    bootAt: HOST_BOOT_AT,
    settings: function () { return { enabled: SET.mp4AutoHandoff === true }; },
    isRecording: function () { return !!(STATE.recorder && STATE.recorder.recording); },
    listParts: async function () {
      const root = await navigator.storage.getDirectory();
      let dir;
      try { dir = await root.getDirectoryHandle('rsp_rec'); } catch (e) { return []; }
      const out = [];
      for await (const [name, h] of dir.entries()) {
        if (h.kind !== 'file' || !/\.ts$/i.test(name)) continue;
        try { const f = await h.getFile(); out.push({ name: name, size: f.size, lastModified: f.lastModified }); } catch (e2) {}
        if (out.length >= 5000) break;
      }
      return out;
    },
    openInputs: async function (names) {
      const root = await navigator.storage.getDirectory();
      const dir = await root.getDirectoryHandle('rsp_rec');
      const inputs = []; let missing = 0; const seen = new Set();
      for (const name of (Array.isArray(names) ? names : [])) {
        if (seen.has(name)) continue; seen.add(name);
        let fh;
        try { fh = await dir.getFileHandle(name); } catch (e) { missing++; continue; }
        let file;
        try { file = await fh.getFile(); } catch (e2) { missing++; continue; }
        if (!file || file.size < 1) { missing++; continue; }
        const entry = { name: name, size: file.size,
          getFile: async function () { return file; },
          isSameEntry: async function (other) { return other === entry; } };
        inputs.push(entry);
      }
      return { inputs: inputs, missing: missing };
    },
    createDestination: async function (p) {
      if (!RspMp4BrowserIO || typeof RspMp4BrowserIO.createStage !== 'function') throw Error('DESTINATION_UNAVAILABLE');
      const stage = await RspMp4BrowserIO.createStage({ id: crypto.randomUUID().replace(/-/g, ''), inputBytes: (p && p.inputBytes) || 0 });
      return { destination: stage.destination, finalize: stage.finalize, destroy: stage.destroy,
        file: function () { return stage.destination.getFile(); } };
    },
    convert: async function (p) {
      if (typeof RspMp4Convert !== 'object' || !RspMp4Convert || typeof RspMp4Convert.convertStreamed !== 'function') throw Error('CONVERTER_UNAVAILABLE');
      return RspMp4Convert.convertStreamed({ inputs: p.inputs, destination: p.destination,
        muxjs: globalThis.muxjs, hashing: RspSha256, signal: p.signal, onProgress: p.onProgress });
    },
    handoff: function (file, name) { return EXPORT_HOST.save(file, name); },
    excludeNames: function () { try { return EXPORT_HOST.inFlightNames(); } catch (e) { return []; } },
    notify: function (title, body) { if (SET.notify) MSG.send({ type: 'rec.notify', title: String(title).slice(0, 120), body: String(body).slice(0, 200) }); },
    emit: function (e) {
      const out = { type: 'rec.event', kind: 'mp4-handoff', phase: String(e && e.phase || '').slice(0, 32) };
      if (e && e.errorCode) out.errorCode = String(e.errorCode).slice(0, 64);
      if (e && e.reason) out.reason = String(e.reason).slice(0, 64);
      if (e && e.outputName) out.outputName = String(e.outputName).slice(0, 120);
      MSG.send(out);
    }
  }) : null;

  /* ---- rec.start: UIタブから録画開始(保存先handleはIndexedDB共有済みの前提) ---- */
  /* 相対URLの絶対化: ページでは暗黙にページ起点で解決されるが、offscreen文書は
     chrome-extension://起点になるため、UIタブのURL(pageUrl)基準で明示的に解決する */
  function offAbsUrl(u) {
    if (!u || /^[a-z]+:\/\//i.test(u) || u.indexOf('//') === 0) return u || '';
    try { return new URL(u, STATE.pageUrl || 'https://rplay.live/').href; } catch (e) { return u; }
  }
  /* v2.40.0: URL録画の表示用ラベル(origin+pathのみ — 署名/tokenクエリを出さない) */
  function rspUrlSourceLabel(u) {
    try { const x = new URL(u); return String(x.origin + x.pathname).slice(0, 500); } catch (e) { return ''; }
  }
  /* v2.40.0: URL録画セッションの合成ID — sha256(正規化URL)先頭24桁(16-40桁hex
     のゲート書式に一致)。同一URLで安定し、実在RPLAY配信者IDとの衝突は
     無視できる確率。衝突時はBG側がbusyとして排他するため暴走しない。 */
  function rspUrlOid(u) {
    return crypto.subtle.digest('SHA-256', new TextEncoder().encode(u)).then(function (b) {
      let s = ''; const a = new Uint8Array(b);
      for (let i = 0; i < 12; i++) s += ('0' + a[i].toString(16)).slice(-2);
      return s;
    });
  }
  /* ---- v2.40.0: url.start — 任意HLS URL録画(dashboard経由・RPLAYに非依存) ----
     https:// のHLSプレイリストURLを共通コアで録画する。追跡(follow)とFLV代替は
     強制OFF(配信終了で停止する・RPLAY CDNのFLV URLは無関係のため)。合成oidは
     URLから決定的に導出し、同一URLの再開始でクラッシュ復帰(rec.startと同じ
     resume経路)が働く。 */
  async function handleUrlStart(p, owner) {
    p = p || {};
    const raw = String(p.url || '');
    if (!raw || raw.length > 2048) return { ok: false, error: 'bad-url' };
    let u;
    try { u = new URL(raw); } catch (e) { return { ok: false, error: 'bad-url' }; }
    if (u.protocol !== 'https:') return { ok: false, error: 'https-only' };
    const label = String(p.label || '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80);
    let oid;
    try { oid = await rspUrlOid(u.href); } catch (e) { return { ok: false, error: 'oid-unavailable' }; }
    const who = label || u.hostname;
    const r = await handleStart({
      oid: oid,
      customM3u8: u.href,
      pageUrl: u.href,
      creatorName: who,
      titleBase: label || ('URL録画 ' + u.hostname),
      settings: Object.assign({}, p.settings || {}, { follow: false, flv: false }),
      urlMode: true,
      automatic: false
    }, owner);
    if (r && r.ok) return Object.assign({}, r, { oid: oid, urlSession: true });
    return r;
  }
  async function handleStart(p, owner) {
    p = p || {};
    if (stopPromise || STATE.recorder && STATE.recorder.isDraining) return {ok:false,error:'draining'};
    const oid = typeof p.oid==='string'?p.oid.toLowerCase():'';
    if (!oid) return { ok: false, error: 'no-oid' };
    if (STATE.recorder && STATE.recorder.recording) {
      return { ok: false, error: 'busy', oid: STATE.recorder.id };
    }
    const admission=CONTROL_GATE.begin(owner,oid);
    if(!admission.ok)return admission;
    if(admission.existing)return {ok:true,existing:true,...CONTROL_GATE.status(owner,oid)};
    const binding=admission.binding;
    try {
    STATE.pageUrl = p.pageUrl || ('https://rplay.live/live/' + oid);
    /* v2.40.0: URL録画セッションの状態(rec.startでは常にfalseへ戻す) */
    STATE.urlMode = p.urlMode === true;
    STATE.urlSource = STATE.urlMode ? rspUrlSourceLabel(p.customM3u8 || '') : '';
    AUTH._401Classes = {}; AUTH._key2Resolutions = 0; AUTH._butterSends = 0; AUTH.relayedStats = null;
    STATE.authStats = undefined; STATE.canaryEvidence = undefined;
    applySettings(p.settings || {});
    applyAuth(p);
    if (!HAS_EXT && p.testHooks) { try { window.__RSP_TEST = p.testHooks; } catch (e) {} }
    STATE.creatorName = p.creatorName || '';
    STATE.customM3u8 = offAbsUrl(p.customM3u8);
    STATE.customFlv = offAbsUrl(p.customFlv);
    TITLEC.base = p.titleBase || '';
    checkBackupRecovery();
    await restoreHandle();
    { // Each new control session receives a fresh recorder and event identity.
      const deps = {
        resolveMemberLive: resolveMemberLive,
        resolveScheduleInfo: resolveScheduleInfo,
        fetchSchedulesFor: fetchSchedulesFor,
        memberFailHint: memberFailHint,
        liveBaseLabel: liveBaseLabel
      };
      STATE.recorder = new Recorder(oid, makeUiShim(binding), deps);
      STATE.recorder.getCreatorName = function () { return STATE.creatorName; };
      STATE.recorder.getCustomM3u8 = function () { return STATE.customM3u8; };
      STATE.recorder.getFlvUrl = function () { return STATE.customFlv; };
      STATE.recorder.getUrlMode = function () { return STATE.urlMode === true; }; /* v2.40.0 */
      await restoreHandle(); /* インスタンス生成後に再度ハンドルへ反映 */
    }
    /* クラッシュ/破棄前のセッションがあれば自動復帰(設計§4.3: 復旧記録) */
    let saved = null;
    try { saved = loadSavedSession(oid); } catch (e) {}
    if (saved && p.resume !== false) {
      try {
        STATE.recorder.resumeFromCrash(saved);
        CONTROL_GATE.activate(binding);
        return { ok: true, resumed: true, ...CONTROL_GATE.status(owner,oid) };
      } catch (e) { /* 復帰失敗は通常開始へフォールバック */ }
    }
    STATE.recorder.start();
    CONTROL_GATE.activate(binding);
    return { ok: true, ...CONTROL_GATE.status(owner,oid) };
    } catch(e) {
      if(STATE.recorder && STATE.recorder.recording) {try{await STATE.recorder.stop(false);}catch(ignored){}}
      CONTROL_GATE.end(binding);return {ok:false,error:'recording-start-failed'};
    }
  }

  /* ---- rec.stop: 最終パートを閉じて情報JSON/CSV/履歴を書出し ---- */
  let controlQueue=Promise.resolve();
  function controlTask(fn,reply){const p=controlQueue.then(fn);controlQueue=p.catch(()=>{});p.then(reply,()=>reply({ok:false,error:'control-failed'}));return true;}
  let stopPromise = null;
  let lastParts = [];
  function recordingParts(rec) {
    if (!rec) return lastParts;
    const collect = (r, track) => !r ? [] : (r.partsLog || []).slice(-100).map(p => ({name:String(p.file || '').slice(0,180),size:Number(p.bytes)||0,status:p.saveState || 'pending',at:Date.parse(p.startedAt)||0,track})).concat(r.partOpen ? [{name:String(r.partName || '').slice(0,180),size:Number(r.bytes)||0,status:'recording',at:Date.now(),track}] : []);
    return collect(rec,'video').concat(collect(rec.audio,'audio')).sort((a,b)=>a.at-b.at).slice(-100);
  }
  async function handleStop(p,owner) {
    if(!CONTROL_GATE.authorize(owner,p))return {ok:false,error:'not-session-owner'};
    const binding=CONTROL_GATE.binding();CONTROL_GATE.draining(binding);
    if (stopPromise) return stopPromise;
    stopPromise = stopAndDrain().finally(() => { CONTROL_GATE.end(binding); stopPromise = null; });
    return stopPromise;
  }
  async function stopAndDrain() {
    const rec = STATE.recorder;
    if (!rec) return {ok:true,idle:true};
    if(rec.recording) await rec.stop(false);
    else if(rec._stopTask) await rec._stopTask;
    if (rec.waitForSaves) await rec.waitForSaves();
    if (rec.audio && rec.audio.waitForSaves) await rec.audio.waitForSaves();
    await EXPORT_HOST.drain();
    lastParts = recordingParts(rec);
    /* v2.48.0(統合): BG停止後MP4自動引渡し(既定OFF) — 停止済みTSパートを変換キューへ */
    if (MP4_HANDOFF && SET.mp4AutoHandoff) {
      try {
        const handoffNames = lastParts.filter(function (p) { return /\.ts$/i.test(p.name) && p.status !== 'recording'; }).map(function (p) { return p.name; });
        if (handoffNames.length) MP4_HANDOFF.enqueue({ trigger: 'bg-stop', parts: handoffNames });
      } catch (e) {}
    }
    STATE.recorder = null; /* 次回開始は新規インスタンス(セッションは正常停止で消去済み) */
    if (!rec.failedSaves && !(rec.audio && rec.audio.failedSaves) && !EXPORT_HOST.status().stageFailed) markBackupClean();
    STATE.recoveredParts = [];
    return { ok: true };
  }

  /* ---- rec.status: state/画質/パート/統計/ログ末尾を返す(再オープン時の復元) ---- */
  function handleStatus(p,owner) {
    p = p || {};
    const rec = STATE.recorder;
    const oid = p.oid || (rec ? rec.id : '');
    const out = { recording: !!(rec && rec.recording), oid: rec ? rec.id : '', handleName: STATE.handleName,
      ...CONTROL_GATE.status(owner,oid), authVersion: AUTH.exp || 0, draining: !!stopPromise || !!(rec && rec.isDraining), exportHost: EXPORT_HOST.status() };
    if (rec) {
      out.creatorName=String(STATE.creatorName||'').slice(0,200);out.title=String(TITLEC.base||'').slice(0,200);
      out.state = rec.state;
      out.medium = rec.medium;
      try { out.stats = rec.stats(); } catch (e) {}
      try { out.dirLabel = rec.dirLabel || ''; } catch (e) {}
    }
    out.urlSession = STATE.urlMode === true; /* v2.40.0 */
    out.urlSource = STATE.urlSource || '';
    out.parts = recordingParts(rec);
    out.mp4Handoff = MP4_HANDOFF ? MP4_HANDOFF.status() : null; /* v2.48.0(統合) */
    out.session = null;
    out.logs = out.canControl ? LOGTAIL.slice(-30).map(line=>String(line).replace(/https?:\/\/\S+/g,'[URL]')) : [];
    return out;
  }

  /* ---- token.update: UIタブが再取得した自分のトークンを受け取る ---- */
  function handleTokenUpdate(p,owner) {
    if(!CONTROL_GATE.authorize(owner,p))return {ok:false,error:'not-session-owner'};
    if(p.jwt && (typeof p.jwt!=='string'||p.jwt.length>16384))return {ok:false,error:'bad-auth'};
    applyAuth(p||{});return {ok:true};
  }

  /* ---- pick.stored: picker.htmlが保存先を IndexedDB へ書き込んだ通知 ---- */
  async function handlePickStored() {
    await restoreHandle();
    if (STATE.handleOk && STATE.recorder) {
      try { STATE.recorder.log('保存先フォルダを反映: ' + STATE.handleName); } catch (e) {}
    }
  }

  /* ---- v2.42.0: schedules.scan — dashboard外部予約閲覧(BG経由のschedules巡回) ----
     登録一覧の予約をこのホストで巡回する(読取専用・録画制御へは干渉しない)。
     トークンはUIタブからrec.start/token.updateで受け渡された自分の会話のみ使用
     (未保持ならnologin — ライブページを開くと受け渡る)。controlQueueへは
     入れない(最悪数分かかる巡回でrec.stop等の制御を遅延させないため)。
     巡回間隔はページ側と同じ400ms・再実行は60秒制限(forceで10秒)。 */
  let _bgSchedBusy = false, _bgSchedAt = 0;
  let _bgSchedJob=null;
  const _bgSchedCanceled=new Map();
  const bgSchedId=id=>typeof id==='string'&&/^[a-f0-9]{32}$/.test(id);
  function bgSchedLease(job){
    if(!job.id)return;
    if(job.timer)clearTimeout(job.timer);
    job.timer=setTimeout(()=>job.ctl.abort(),10000);
  }
  function handleBgSchedControl(p,cancel){
    const id=p&&p.requestId;if(!bgSchedId(id))return {ok:false,error:'bad-request'};
    if(cancel){
      for(const [key,at] of _bgSchedCanceled)if(at<=Date.now())_bgSchedCanceled.delete(key);
      if(_bgSchedCanceled.size>=100)_bgSchedCanceled.delete(_bgSchedCanceled.keys().next().value);
      _bgSchedCanceled.set(id,Date.now()+60000);
    }
    const job=_bgSchedJob;
    if(!job||job.id!==id)return {ok:cancel,error:cancel?'canceled':'not-found'};
    if(cancel)job.ctl.abort();else if(!job.ctl.signal.aborted)bgSchedLease(job);
    return {ok:true,completed:job.completed,total:job.total,canceled:job.ctl.signal.aborted};
  }
  function bgSchedWait(signal){return new Promise(resolve=>{
    let timer;
    const done=()=>{if(timer)clearTimeout(timer);signal.removeEventListener('abort',done);resolve();};
    if(signal.aborted)return resolve();
    signal.addEventListener('abort',done,{once:true});timer=setTimeout(done,400);
  });}
  async function handleBgSchedScan(p) {
    p = p || {};
    if(p.requestId!==undefined&&!bgSchedId(p.requestId))return {ok:false,error:'bad-request'};
    if((_bgSchedCanceled.get(p.requestId)||0)>Date.now())return {ok:false,error:'canceled'};
    if (_bgSchedBusy) return { ok: false, error: 'busy' };
    const ids = Array.isArray(p.ids) ? [...new Set(p.ids.filter(x => typeof x === 'string' && /^[a-f0-9]{24}$/i.test(x)).map(x=>x.toLowerCase()))].slice(0, 100) : [];
    if (!ids.length) return { ok: false, error: 'no-ids' };
    if (!RspAuth.jwt) return { ok: false, error: 'nologin' };
    const now = Date.now(), gap = p.force === true ? 10000 : 60000;
    if (now - _bgSchedAt < gap) return { ok: false, error: 'rate-limited', retryInMs: gap - (now - _bgSchedAt) };
    _bgSchedAt = now; _bgSchedBusy = true;
    const job={id:p.requestId||'',ctl:new AbortController(),completed:0,total:ids.length,timer:null};
    _bgSchedJob=job;bgSchedLease(job);
    const canceled=()=>({ok:false,error:'canceled',completed:job.completed,total:job.total});
    try {
      const rows = [], errors = {};
      for (let i = 0; i < ids.length; i++) {
        if(job.ctl.signal.aborted)return canceled();
        const oid = ids[i];
        const r = await fetchSchedulesFor(oid,job.ctl.signal);
        if(job.ctl.signal.aborted)return canceled();
        job.completed++;
        if (!r || r.err) { const c = String(r && r.err || 'error'); errors[c] = (errors[c] || 0) + 1; }
        else if (r.items) for (const it of r.items) {
          const t = Number(it.scheduledAt);
          if (Number.isFinite(t) && t > 0 && t <= 8640000000000000) {
            rows.push({ oid: oid, title: String(it.title || '').slice(0, 200), scheduledAt: t });
            rows.sort((a,b)=>a.scheduledAt-b.scheduledAt);
            if(rows.length>500)rows.pop();
          }
        }
        if (i < ids.length - 1) await bgSchedWait(job.ctl.signal);
      }
      if(job.ctl.signal.aborted)return canceled();
      rows.sort((a, b) => a.scheduledAt - b.scheduledAt);
      return { ok: true, rows: rows.slice(0, 500), errors: errors, checkedAt: Date.now(), count: ids.length };
    } finally { if(job.timer)clearTimeout(job.timer);if(_bgSchedJob===job)_bgSchedJob=null;_bgSchedBusy = false; }
  }

  /* ---- メッセージディスパッチ(拡張: chrome.runtime / ページ: 試験ブリッジ) ---- */
  function dispatch(msg, reply) {
    if (!msg || typeof msg !== 'object') { if (reply) reply({ ok: false, error: 'bad-msg' }); return false; }
    switch (msg.type) {
      case 'export.finish':
        EXPORT_HOST.finish(msg).then(reply, () => reply({ok:false})); return true;
      case 'export.sweep':
        EXPORT_HOST.sweep(msg.retry === true).then(reply, () => reply({ok:false})); return true;
      case 'rec.start':
        return controlTask(()=>handleStart(msg.payload||{},msg.control),reply);
      case 'url.start':
        return controlTask(()=>handleUrlStart(msg.payload||{},msg.control),reply);
      case 'mp4-handoff.status':
        /* v2.48.0(統合): 自動引渡しの状態照会(証拠は境界付き・URL等は含まない) */
        if (reply) reply(MP4_HANDOFF ? { ok: true, ...MP4_HANDOFF.status() } : { ok: false, error: 'unavailable' });
        return false;
      case 'mp4-handoff.sweep':
        /* v2.48.0(統合): 起動時の取り残しTSパートの自動引渡し(BGのrecoverExportsから呼ばれる。
        設定・録画状態の両ガードはホスト側で行う) */
        (MP4_HANDOFF ? MP4_HANDOFF.sweep() : Promise.resolve({ ok: false, error: 'unavailable' }))
          .then(function (r) { if (reply) reply(r); }, function () { if (reply) reply({ ok: false, error: 'sweep-failed' }); });
        return true;
      case 'rec.stop':
        return controlTask(()=>handleStop(msg.payload||{},msg.control),reply);
      case 'rec.claim':
        return controlTask(()=>CONTROL_GATE.claim(msg.control,msg.payload||{}),reply);
      case 'rec.status':
        if (reply) reply(handleStatus(msg.payload || {},msg.control));
        return false;
      case 'token.update':
        return controlTask(()=>handleTokenUpdate(msg.payload||{},msg.control),reply);
      case 'pick.stored':
        handlePickStored().then(function () { if (reply) reply({ ok: true }); });
        return true;
      case 'schedules.status':
      case 'schedules.cancel':
        if(reply)reply(handleBgSchedControl(msg.payload||{},msg.type==='schedules.cancel'));return false;
      case 'schedules.scan':
        handleBgSchedScan(msg.payload || {}).then(function (r) { if (reply) reply(r); }, function () { if (reply) reply({ ok: false, error: 'scan-failed' }); });
        return true;
      case 'test.set':
        try { window.__RSP_TEST = msg.payload || {}; } catch (e) {}
        if (reply) reply({ ok: true });
        return false;
      case 'dbg.worker':
        /* 診断: この文書でWorker/fetchが動くか実証する(E2E/障害切り分け用) */
        (async function () {
          const out = { hasExt: HAS_EXT, blob: null, file: null, interval: null, fetchApi: null, fetchM3u8: null,
            href: null, apiBase: null, ov: null, lsv: null };
          try { out.href = location.href; } catch (e) {}
          try { out.apiBase = API_BASE; } catch (e) { out.apiBase = 'ERR'; }
          try { out.ov = typeof window.__RSP_API_BASE === 'string' ? window.__RSP_API_BASE : String(typeof window.__RSP_API_BASE); } catch (e) { out.ov = 'ERR'; }
          try { out.lsv = localStorage.getItem('rsp_api_base'); } catch (e) { out.lsv = 'ERR'; }
          function tryWorker(url) {
            return new Promise(function (res) {
              let w = null, got = false;
              try {
                w = new Worker(url);
                w.onmessage = function () { got = true; };
                w.postMessage({ cmd: 'start', ms: 80 });
                setTimeout(function () {
                  try { w.terminate(); } catch (e) {}
                  res(got);
                }, 900);
              } catch (e) { res(false); }
            });
          }
          try { out.blob = await tryWorker(URL.createObjectURL(new Blob([REC_TICK_WORKER_SRC], { type: 'application/javascript' }))); } catch (e) { out.blob = 'ERR'; }
          if (HAS_EXT) {
            try { out.file = await tryWorker(chrome.runtime.getURL('rec_worker.js')); } catch (e) { out.file = 'ERR'; }
          }
          out.interval = await new Promise(function (res) { let n = 0; const t = setInterval(function () { n++; if (n >= 3) { clearInterval(t); res(true); } }, 100); });
          /* fetch診断: API/live/play とカスタムm3u8(在れば)への到達性 */
          try {
            const r = await fetch(API_BASE + '/live/play?creatorOid=a1b2c3d4e5f60718293a4b5c6d7e8f90', { cache: 'no-store' });
            out.fetchApi = r.status + ':' + (await r.text()).slice(0, 40);
          } catch (e) { out.fetchApi = 'ERR:' + (e && e.message || e); }
          if (STATE.customM3u8) {
            try {
              const u = new URL(STATE.customM3u8, RECENV.pageUrl()).href;
              const r2 = await fetch(u, { cache: 'no-store' });
              out.fetchM3u8 = u + ' → ' + r2.status;
            } catch (e) { out.fetchM3u8 = 'ERR:' + (e && e.message || e); }
          }
          if (reply) reply(out);
        })();
        return true;
      default:
        if (reply) reply({ ok: false, error: 'unknown-type' });
        return false;
    }
  }

  /* v2.1.0 Step3: Firefox Event Page等のインプロセス背景ホスト向けにディスパッチャを公開 */
  if (typeof window !== 'undefined') {
    window.__RSP_BG_HOST__ = {
      dispatch: dispatch,
      isRecording: function () { return !!(STATE.recorder && STATE.recorder.recording); },
      recoveredParts: function () { return STATE.recoveredParts ? STATE.recoveredParts.slice() : []; },
      authStats: function () { return RSP_RECENV_HOOK.authStats(); },
      canaryEvidence: function () { return RSP_RECENV_HOOK.canaryEvidence(); }
    };
  }
  const IS_OFFSCREEN_DOC = typeof location !== 'undefined' && location.pathname && location.pathname.indexOf('offscreen.html') >= 0;
  if (HAS_EXT && IS_OFFSCREEN_DOC) {
    chrome.runtime.onMessage.addListener(function (msg, sender, reply) {
      if (msg.target !== 'rsp-host' || sender.id !== chrome.runtime.id || sender.tab) return false;
      return dispatch(msg, reply);
    });
  } else if (!HAS_EXT) {
    /* 試験ブリッジ(拡張なしページ読み込み時): E2Eから直接ハンドルを呼ぶ。
       実コア・実RECENV・実メッセージ生成をそのまま検証できる */
    window.__RSP_OFFSCREEN_TEST__ = {
      exportHost: EXPORT_HOST,
      start: function (p) { return handleStart(p,p&&p.testOwner); },
      stop: function () { return handleStop({},null); },
      status: function (oid) { return Promise.resolve(handleStatus({ oid: oid })); },
      tokenUpdate: function (p) { handleTokenUpdate(p); return Promise.resolve({ ok: true }); },
      pickStored: function () { return handlePickStored(); },
      events: EVT_LOG,
      logs: LOGTAIL,
      mp4Handoff: MP4_HANDOFF, /* v2.48.0(統合) */
      set: function (p) { try { window.__RSP_TEST = p || {}; } catch (e) {} },
      opfsList: async function () {
        const root = await navigator.storage.getDirectory();
        const dir = await root.getDirectoryHandle('rsp_rec');
        const out = [];
        for await (const [name, h] of dir.entries()) { if (h.kind === 'file') out.push(name); }
        return out;
      },
      opfsRead: async function (name) {
        const root = await navigator.storage.getDirectory();
        const dir = await root.getDirectoryHandle('rsp_rec');
        const fh = await dir.getFileHandle(name);
        const f = await fh.getFile();
        return await f.arrayBuffer();
      },
      storageGet: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
      auth: function () { return { jwt: AUTH.jwt, userOid: AUTH.userOid, nick: AUTH.nick }; },
      state: function () { return { hasExt: HAS_EXT, pageUrl: STATE.pageUrl, handleOk: STATE.handleOk, handleName: STATE.handleName }; }
    };
    /* ページ内メッセージブリッジ(window.postMessage)にも対応 */
    window.addEventListener('message', function (e) {
      if (e.source !== window || !e.data || !e.data.rspOffscreenReq) return;
      dispatch(e.data.msg, function (r) {
        try { window.postMessage({ rspOffscreenRep: true, rid: e.data.rid, reply: r }, '*'); } catch (e2) {}
      });
    });
  }
})();
