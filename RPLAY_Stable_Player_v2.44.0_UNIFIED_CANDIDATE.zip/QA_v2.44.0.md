# QA Report — RPLAY Stable Player v2.44.0 (UNIFIED CANDIDATE)

- **Version**: `2.44.0`
- **Status**: `CANDIDATE_NO_GO` (local automated Node + Python + FFmpeg/ffprobe E2E verification passed; real RPLAY live stream, real Windows environment, and long-hour browser endurance remain untested)
- **Date (JST)**: `2026-10-27`
- **Shared Core SHA-256**: `801e194d0e167d31cb55d768f894cb7e6554511d2c30a10bcd81f253fc934bdc` (5 copies byte-identical across `src/player.user.js`, `rplay-stable-player.user.js`, Chrome/Firefox `content.js`, and Chrome/Firefox `offscreen.js`)
- **Automated Test Counts**: **970 / 970 PASS** (**803 Node.js tests** + **167 Python unittest tests**)

## 1. Input Package Hashes (SHA-256)

| Input Archive | SHA-256 |
|---|---|
| `RPLAY_Stable_Player_v2.42.4_EXISTING_TOOL_INTEGRATION_CANDIDATE.zip` | `af677891e115b2ed0f3573e5d3086c91e684cbd76611a2b6f1cfd4942219cfa7` |
| `RPLAY_Stable_Player_v2.40.0_UNIFIED_CANDIDATE.zip` | `14d4a77f789aeaa24d0228062079c580bd651615b0bbc94d8f826d4a55448945` |
| `RPLAY_Stable_Player_v2.43.0_UNIFIED_CANDIDATE.zip` | `2ea4c03b7115eea38075fa9fa0fde6a271388df57836621cc856165d0264e716` |

## 2. Key Unifications & Anti-Error / Anti-Interruption Improvements in v2.44.0

1. **Transient Corrupted/Truncated Playlist Grace (`_badPlaylistConsec` / `playlistParseGraceEvidence`)**:
   - In `Recorder.pollPlaylist()` and `AudioRecorder.poll()`, if `segTotal > 0` (active recording is already underway) and `HLS.parse` throws a transient truncation/syntax error (`HLS_BAD_PLAYLIST`, `HLS_BAD_TARGET`, `HLS_DANGLING_TAG`, `HLS_DANGLING_RANGE`, `HLS_BAD_EXTINF`), up to 2 consecutive failures are tolerated and retried on the next poll instead of immediately stopping the recording (`await this.stop(false)` / `this.stopFinal('unsupported', ...)`).
   - Initial playlists (`segTotal === 0`) and unsupported stream types (`HLS_ENCRYPTED_UNSUPPORTED`, `HLS_IFRAMES_UNSUPPORTED`, `HLS_LLHLS_SKIP`, `HLS_EXPECT_MEDIA`, `HLS_EXTINF_REQUIRED`) still fail closed immediately.
2. **Transient Segment Truncation / Empty Body Retry (`HLS_BODY_LENGTH`, `HLS_RANGE_LENGTH`, `HLS_EMPTY_BODY`)**:
   - In `recFetchDescriptor(owner, item)`, truncated HTTP responses (`HLS_BODY_LENGTH`, `HLS_RANGE_LENGTH`) or empty 200 responses during CDN edge cache fill (`HLS_EMPTY_BODY`) are retried up to 2 times (`item.tries < 3`) with a 500ms backoff while keeping the segment at the head of the FIFO queue (`this.queue.unshift(item)`), preventing mid-stream segment drops and recording `segmentTransferRetryEvidence` in `_info.json`.
3. **Audio Recorder Request Pacing Fix & Active-Stream 404 Grace**:
   - Removed the duplicate `REC_REQ_MIN_GAP_MS` pre-wait in `AudioRecorder.drain()` so audio segment fetches do not incur a double 250ms delay before `recFetchDescriptor`.
   - In `AudioRecorder.poll()`, a single HTTP 404 while `segTotal > 0` is retried once on the next poll before declaring terminal rendition loss (`stopFinal('404', ...)`).
4. **Exact Per-Part Segment Sequence Binding (`startPartAudit` / `takePartAudit` / `partSequenceRange`)**:
   - Implemented `HLS.startPartAudit(owner)` and `HLS.takePartAudit(owner)` in `src/hls_transport.js` and integrated with `rspPartCommit.correlate` in `src/part_commit_core.js`, attaching `partSequenceRange` (`attribution: 'exact_pushData_part_binding'`, `segments`, `mediaBytes`, `initBytes`, `firstSequence`, `lastSequence`, `sequenceGaps`, `discontinuities`, zero URLs/secrets) to each closed part's `partIntegrity`.
5. **Full Unification of `v2.42.4` + `v2.40.0` + `v2.43.0`**:
   - Preserves all `v2.42.4` capabilities (`src/cross_site_core.js` with `parseDASH` / `loadDASH`, `writeEvidence` / `segmentWriteEvidence`, `src/part_commit_core.js` / `partIntegrity`), all `v2.40.0` capabilities (`RECENV.autoPolicy` unified auto-start gate, `src/creator_meta.js` page/BG creator name harvest, `RECENV.sessionEnded` + `maybeOpenConverter` MP4 handover, and arbitrary HTTPS HLS URL recording `url.start`/`url.stop`), and all `v2.43.0` capabilities (`src/cross_site_compat.js`, `src/cross-site/*.mjs`, `normalizeInitHeaderDurations`, `verifyTs` recovery option, WebVTT validation/merge).

## 3. Standalone E2E Verification Results

- `tests/check_request_context_http.py`: **PASS** (`anonymous_policy_request: HTTP_403`, `explicit_cookie_policy: PASS`, `raw_query_preserved: true`, `parent_query_inheritance: PASS`)
- `tests/check_cdn404_decode.py`: **PASS** (`local_http_cdn404: PASS`, `byte_identity: PASS`, `full_decode: PASS`, `audio_and_video: PASS`)
- `tests/check_recording_during_scan.cjs`: **PASS** (2/2 subtests pass for Chrome and Firefox production hosts)
