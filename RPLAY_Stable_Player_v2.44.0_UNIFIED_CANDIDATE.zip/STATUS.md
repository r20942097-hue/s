# v2.44.0 状況 — 2026-10-27 JST

CANDIDATE_NO_GO / remote_published=false
完了:
- CrossSite Compatibility v0.1.0 の Phase 1 統合（`src/cross_site_compat.js` 共通UMD化 + `src/cross-site/*.mjs` + 合成fixture 5種・新規Node 61件/Python 2件）
- 親クエリ継承の改善: 既に非署名クエリ（`?a=own&quality=high`等）を持つ同一origin子URLにも不足する親クエリだけを順序・重複・escape保持のまま付加（署名済み子URLと別originは不変）
- 視聴ページURL（NicoVideo / NicoLive / YouTube / Twitch / RPLAY）と直接メディアURLの分類・案内表示、HTTPステータス別診断（401/403・404/410・429・5xx）
- 断片化MP4初期ヘッダ（`mvhd`/`tkhd`/`mdhd`）の `0xFFFFFFFF` 継続時間正規化（`normalizeInitHeaderDurations` 統合・FFmpeg 5.1系で24.8時間と誤認される不具合の解消）
- Node 18 / VM環境での `crypto.randomUUID` フォールバック、ローカル変換サーバー (`scripts/serve_mp4.py`) の `hls_transport.js` / `media_catalog.js` / `cross_site_compat.js` 配信漏れ修正と `BrokenPipeError` 保護
- チェックポイント復旧の任意TS同期バイト検査 (`verifyTs`)、WebVTT字幕検証・重複境界キュー結合 (`validateWebVtt` / `mergeWebVttSegments`) のJS/Python鏡像統合

維持: v2.42のページ通信文脈（Referer/Origin/UA allowlist・Cookie明示モード）、v2.41の録画連続性改善（404猶予・quality lock）と候補リスト、v2.40の予約取消。
未完: 汎用ブラウザ内動画DL、全サービスの認証再現、BG停止後自動MP4。
未受入: 実ブラウザCookie条件/実RPLAY/実Nico/Windows/2GiB/長時間/native preview進行。
