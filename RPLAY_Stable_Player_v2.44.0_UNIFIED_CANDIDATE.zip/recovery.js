'use strict';
const choose=document.getElementById('choose'),items=document.getElementById('items'),status=document.getElementById('status');
if(!window.showDirectoryPicker||!window.showSaveFilePicker){choose.disabled=true;status.textContent='このブラウザはフォルダ選択による復旧に対応していません。対応するブラウザで開いてください。';}
let recovering=false;
choose.addEventListener('click',async()=>{
 try{
  const root=await window.showDirectoryPicker({mode:'read'});choose.disabled=true;items.replaceChildren();let found=0,skipped=0;
  const base=await root.getDirectoryHandle('rsp-recovery');
  for await(const [name,dir] of base.entries()){
   if(dir.kind!=='directory'||!name.endsWith('.checkpoint'))continue;
   try{
    const snap=await RspRecovery.inspect(dir,{verify:false});const j=snap.journal;found++;
    const row=document.createElement('li'),label=document.createElement('span'),button=document.createElement('button');
    label.textContent=j.file+' — 確定済み '+(j.committedBytes/1048576).toFixed(1)+' MiB / '+(j.schema===2?'ハッシュ付き（復元時に照合）':'旧台帳・サイズ確認のみ');button.textContent='別ファイルへ復元';row.append(label,button);items.append(row);
    button.addEventListener('click',async()=>{
     if(recovering)return;recovering=true;choose.disabled=true;
     let busy=false;
     try{
      const target=await window.showSaveFilePicker({suggestedName:'recovered_'+j.file});button.disabled=true;choose.disabled=true;busy=true;
      let original;try{original=await root.getFileHandle(j.file);}catch(e){if(e.name!=='NotFoundError')throw e;}
      const result=await RspRecovery.recover(dir,target,original,(n,total)=>status.textContent='復元中 '+Math.floor(n/total*100)+'%');
      status.textContent='復元ファイルの保存完了: '+result.bytes+' bytes / 入力検証: '+result.sourceIntegrity+'。再生・音声・欠損の確認は未実施です。元データは保持しています。';
     }catch(e){status.textContent=e.name==='AbortError'?'保存をキャンセルしました。':'復元失敗: '+e.message;}
     finally{recovering=false;button.disabled=false;choose.disabled=false;}
    });
   }catch(e){skipped++;}
  }
  status.textContent=found+'件の復旧候補。完了済み・不正・不足のある記録 '+skipped+'件は候補から除外しました。';
 }catch(e){status.textContent=e.name==='AbortError'?'選択をキャンセルしました。':'検索できません: '+e.message;}
 finally{choose.disabled=false;}
});
