# RPLAY v2.44.0 UNIFIED CANDIDATE

添付された5つの候補アーカイブ（`v2.42.0`, `CrossSite_Compatibility_v0.1.0`, `v2.23.0`, `v2.37.0`, `v2.38.0`）を監査・統合し、検出された改善点と不具合修正を反映した v2.44.0 統合候補版です。

## v2.44.0 の主な改善・統合内容

1. **Cross-Site Compatibility v0.1.0 の統合 (`src/cross_site_compat.js` / `src/cross-site/*.mjs`)**:
   - URL署名保持と親クエリ継承の精密化（`resolveMediaURI` / `isSigned` / `redactMediaURL`）: 同一originかつ未署名の子URLに対して、既存の非署名クエリ（`?a=own&quality=high`等）を上書きせず不足する親クエリだけを元の順序・重複・パーセントエンコードのまま付加します。独自署名を持つ子URLや別originには一切付加しません。
   - サイト・視聴ページ判定とHTTP応答診断（`classifySite` / `diagnoseResponse` / `siteRequirements`）: ニコニコ動画・ニコニコ生放送・YouTube・Twitch・RPLAYの視聴ページURLが入力された場合、直接のメディアストリームURLではないことを判別して案内します。また 401/403・404/410・429・5xx の診断メッセージを統合しました。
   - ライブセグメント台帳（`LiveSegmentLedger` / `suggestedReloadMs`）、受動セッション観測（`NicoLiveSessionObserver`）、候補レジストリ（`MediaCandidateRegistry`）および5種の合成HLS fixtureを統合しました。
2. **断片化MP4変換の継続時間正規化 (`src/mp4_convert_core.js`)**:
   - `mux.js` 6.3.0 が `moov`（`mvhd`/`tkhd`/`mdhd`）へ書き込む未知継続時間 `0xFFFFFFFF` により、FFmpeg 5.1系 / `ffprobe` 等で48kHz音声のMP4長が約24.8時間（`89478.485313s`）と誤算出される問題を `normalizeInitHeaderDurations` の統合により解消しました。
3. **Node 18 / VM環境互換性とローカル変換サーバー (`scripts/serve_mp4.py`) の改善**:
   - `src/media_catalog.js` のデフォルトID生成に安全な `crypto.randomUUID` フォールバックを追加し、Node 18 CommonJS / VM実行時の `ReferenceError: crypto is not defined` を修正しました。
   - `scripts/serve_mp4.py` の許可リスト（`ALLOWED`）で漏れていた `hls_transport.js`, `media_catalog.js`, `cross_site_compat.js` を追加し、ローカルサーバー経由で `media_inspect.html` を開いた際の404エラーとクライアント切断時の `BrokenPipeError` を修正しました。
4. **復旧時のTSパケット検証 (`src/recovery_core.js`) と WebVTT 検証・重複結合 (`src/hls_transport.js`, `src/hls_transport.py`)**:
   - `v2.23.0` 系統から非破壊のオプション機能（チェックポイント復旧時の `verifyTs: true` 188バイト/0x47同期検査、WebVTTセグメント検証と境界重複キュー除去、Python側 `hls_audit_psi`）を統合しました。

詳細は `CROSS_SITE_INTEGRATION_v2.44.0.md`、`DEVELOPMENT_HANDOFF_v2.44.0.md`、`QA_v2.44.0.md` を参照してください。実RPLAY・実ブラウザ・Windows・2GiB・長時間は未受入のため `CANDIDATE_NO_GO` を維持します。
