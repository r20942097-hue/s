'use strict';
const {test}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const root=path.join(__dirname,'..');
const H=require('../src/hls_transport.js');
const code=fs.readFileSync(path.join(root,'src/part_commit_core.js'),'utf8');
const P=vm.runInNewContext(code+'\nrspPartCommit',{});
const fakeHash='ab'.repeat(32);
function evidence(queued,accepted,opts={}){const r={tail:[],queued,accepted,terminal:0,acceptedMediaBytes:accepted*188,acceptedInitBytes:0,suspectedManifestMissing:0,declaredGaps:0,backlogSkipped:0,sequenceDiscontinuities:0,suspectedAcceptedSequenceGaps:0,...opts};return { _hlsWriteAudit:{...r} };}
test('snapshot only bounded counters, no secrets, no tail',()=>{
 const owner=evidence(2,1);owner._hlsWriteAudit.tail=[{uri:'https://secret.invalid/?sig=SECRET'}];
 const s=P.snapshot(owner,H);a.equal(s.accepted,1);a.equal(JSON.stringify(s).includes('SECRET'),false);a.ok(Object.isFrozen(s));
});
test('interval is independent of queued moment and marks uncertain attribution',()=>{
 const before=P.snapshot(evidence(4,0),H),after=P.snapshot(evidence(4,3),H);
 const v=P.interval(before,after);a.equal(v.accepted,3);a.equal(v.queued,0);a.equal(v.acceptedMediaBytes,564);a.match(v.attribution,/approximate/);a.equal(v.fileCommitted,false);
});
test('counter resets do not produce negative or false measurements',()=>{
 const v=P.interval(P.snapshot(evidence(10,9),H),P.snapshot(evidence(1,1),H));
 a.equal(v.countersAvailable,false);a.equal(v.fileCommitted,false);a.equal(v.accepted,undefined);
});
test('part committed after file readback and hash gets explicit provenance',()=>{
 const part={bytes:376,file:'part.ts'},receipt={confirmed:true,stage:'FILE_CLOSED',hashHex:fakeHash,checkpoint:{status:'complete',chunks:2,committedBytes:376}};
 const v=P.correlate(part,P.snapshot(evidence(3,0),H),P.snapshot(evidence(3,2),H),receipt,'video');
 a.equal(v.fileCommitted,true);a.equal(v.sha256,fakeHash);a.equal(v.sha256Provenance,'saved_file_readback');a.equal(v.checkpoint.chunks,2);a.equal(v.avDecoded,false);a.equal(part.partIntegrity,v);
});
test('a browser-reported save is not file-closed',()=>{
 const v=P.correlate({bytes:2},null,null,{confirmed:true,stage:'OPFS_STAGED',hashHex:fakeHash},'audio');
 a.equal(v.track,'audio');a.equal(v.fileCommitted,false);a.equal(v.browserReportedComplete,true);a.equal(v.sha256Provenance,'pre_download_blob');
});
test('unconfirmed download may have blob hash, but never file commit',()=>{
 const v=P.correlate({bytes:2},null,null,{confirmed:false,stage:'DOWNLOAD_REQUESTED',hashHex:fakeHash},'video');
 a.equal(v.fileCommitted,false);a.equal(v.sinkReceipt,'not_confirmed');a.equal(v.sha256Provenance,'pre_download_blob');
});
test('checkpoint disagreement does not become completed checkpoint evidence',()=>{
 const v=P.correlate({bytes:500},null,null,{confirmed:true,stage:'FILE_CLOSED',hashHex:fakeHash,checkpoint:{status:'complete',chunks:1,committedBytes:499}});
 a.equal(v.checkpoint,undefined);
});
test('injected URLs/credentials and invalid hash are rejected from metadata',()=>{
 const part={bytes:1};const v=P.correlate(part,null,null,{confirmed:true,stage:'FILE_CLOSED',hashHex:'https://secret.test/?auth=SENSITIVE',checkpoint:{status:'complete',chunks:1,committedBytes:1}},'audio');
 a.equal(v.sha256,null);a.equal(JSON.stringify(part).includes('SENSITIVE'),false);
});
test('failed write never advertises commit or hash',()=>{
 const v=P.correlate({bytes:123},null,null,{confirmed:false,stage:'ERROR'},'video');a.equal(v.sinkReceipt,'write_failed');a.equal(v.fileCommitted,false);a.equal(v.sha256,null);
});
test('both recorder paths snapshot and correlate, and distribution bundles match',()=>{
 const source=fs.readFileSync(path.join(root,'src/player.user.js'),'utf8');
 a.equal((source.match(/rspPartCommit\.snapshot\(this,HLS\)/g)||[]).length,4);
 a.equal((source.match(/rspPartCommit\.correlate\(entry,auditFrom,auditTo/g)||[]).length,4);
 for(const e of ['rplay-stable-player-extension','rplay-stable-player-extension-firefox']){
   const content=fs.readFileSync(path.join(root,e,'content.js'),'utf8'),offscreen=fs.readFileSync(path.join(root,e,'offscreen.js'),'utf8');
   a.match(content,/rspPartCommit=\(function\(\)/);a.match(offscreen,/rspPartCommit=\(function\(\)/);
   a.equal(JSON.parse(fs.readFileSync(path.join(root,e,'manifest.json'),'utf8')).version,'2.44.0');
 }
});
