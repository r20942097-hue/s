'use strict';
/* v2.6.0 core features: fMP4 MAP declaration evidence, LL-HLS safe-side policy
   (dedicated SKIP rejection + counted indicator tags), evidence accumulation in
   enqueue, and browser info-JSON evidence blocks (generationRecovery/fmp4/llhls). */
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),vm=require('vm'),{webcrypto}=require('node:crypto');
const H=require('../src/hls_transport.js');
const source=fs.readFileSync(path.join(__dirname,'../rplay-stable-player-extension/content.js'),'utf8');
function world(env={}){
 const code=source.slice(source.indexOf('  function recTrackSave'),source.indexOf('  /* ================= v1.11.0: AudioRecorder'));
 const classes=source.slice(source.indexOf('  class AudioRecorder'),source.indexOf('  /* ==== RSP RECORDING CORE',source.indexOf('  class AudioRecorder')));
 /* saveInfoJson references v1.10.0 filename helpers defined before the injected
    part_io module — provide matching stubs so the VM slice stays self-contained. */
 const stubs={safeName:s=>String(s==null?'':s).replace(/[^A-Za-z0-9_-]+/g,'_').slice(0,64),stampNow:()=>'20261025_120000'};
 const c=vm.createContext({Blob,crypto:webcrypto,Date,Set,Map,Promise,console,HLS:H,...stubs,RECENV:{download:async()=>undefined,backupPart:async()=>{},...env},REC_REQ_MIN_GAP_MS:0,REC_QUEUE_WARN_MS:60000});
 vm.runInContext(code+classes+';globalThis.api={RecPartSink,Recorder,AudioRecorder,recTrackSave,recWaitSaves,recRedactUrl,recLedgerStage,recLedgerStatus,recSha256Hex,recRecoveryEvidence};',c);return c.api;
}
const base='https://fixture/live.m3u8',playlist=s=>'#EXTM3U\n#EXT-X-TARGETDURATION:1\n'+s;
const owner=()=>({seen:new Set(),queue:[]});

test('v2.6.0 fmp4 MAP evidence: switch counts and discontinuity classification',()=>{
 // two different MAP URIs with an intervening EXT-X-DISCONTINUITY: switch, no risk
 const good=H.parse(playlist('#EXT-X-MAP:URI="init1.mp4"\na.m4s\n#EXT-X-DISCONTINUITY\n#EXT-X-MAP:URI="init2.mp4"\nb.m4s'),base);
 assert.deepEqual(good.fmp4,{mapDeclarations:2,mapSwitches:1,mapSwitchesWithoutDiscontinuity:0});
 // same switch without a discontinuity between the segments: counted as risk evidence
 const risky=H.parse(playlist('#EXT-X-MAP:URI="init1.mp4"\na.m4s\n#EXT-X-MAP:URI="init2.mp4"\nb.m4s'),base);
 assert.deepEqual(risky.fmp4,{mapDeclarations:2,mapSwitches:1,mapSwitchesWithoutDiscontinuity:1});
 // identical re-declaration is not a switch
 const again=H.parse(playlist('#EXT-X-MAP:URI="init1.mp4"\na.m4s\n#EXT-X-MAP:URI="init1.mp4"\nb.m4s'),base);
 assert.deepEqual(again.fmp4,{mapDeclarations:2,mapSwitches:0,mapSwitchesWithoutDiscontinuity:0});
 // single declaration: no switch, and segments reference the map
 const one=H.parse(playlist('#EXT-X-MAP:URI="init1.mp4"\na.m4s'),base);
 assert.deepEqual(one.fmp4,{mapDeclarations:1,mapSwitches:0,mapSwitchesWithoutDiscontinuity:0});
 assert.equal(one.segments[0].map.uri,'https://fixture/init1.mp4');
});
test('v2.6.0 LL-HLS safe-side: SKIP rejects with dedicated code, indicator tags counted only',()=>{
 assert.throws(()=>H.parse(playlist('#EXT-X-SKIP:SKIPPED-SEGMENTS=2\na.ts'),base),/HLS_LLHLS_SKIP/);
 // PRELOAD-HINT / SERVER-CONTROL are counted as evidence but never fetched/rejected
 const p=H.parse(playlist('#EXT-X-SERVER-CONTROL:CAN-BLOCK-RELOAD=YES,PART-HOLD-BACK=1.5\n#EXT-X-PRELOAD-HINT:URI="seg1.ts",TYPE=PART\n#EXT-X-RENDITION-REPORT:URI="../lo/manifest.m3u8"\n#EXT-X-PART-INF:PART-TARGET=0.5\n#EXTINF:1,\nseg1.ts'),base);
 assert.equal(p.llhls.indicatorTags,4);
 assert.equal(p.segments.length,1); // the real segment is still recorded
 assert.equal(p.segments[0].uri,'https://fixture/seg1.ts');
 // absent tags → zero
 assert.equal(H.parse(playlist('#EXTINF:1,\na.ts'),base).llhls.indicatorTags,0);
});
test('v2.6.0 enqueue accumulates fmp4 and llhls evidence across polls',()=>{
 const o=owner();
 H.enqueue(o,H.parse(playlist('#EXT-X-MAP:URI="init1.mp4"\na.m4s'),base),base);
 H.enqueue(o,H.parse(playlist('#EXT-X-SERVER-CONTROL:CAN-BLOCK-RELOAD=YES\n#EXT-X-MEDIA-SEQUENCE:1\n#EXT-X-MAP:URI="init1.mp4"\nb.m4s'),base),base);
 assert.deepEqual(o._hlsFmp4,{mapDeclarations:2,mapSwitches:0,mapSwitchesWithoutDiscontinuity:0,crossPollMapSwitches:0,crossPollMapSwitchesWithoutDiscontinuity:0});
 assert.equal(o._hlsLlhlsIndicators,1);
 // a switch visible only across polls (same generation, new init): cross-poll evidence
 H.enqueue(o,H.parse(playlist('#EXT-X-MEDIA-SEQUENCE:2\n#EXT-X-MAP:URI="init2.mp4"\nc.m4s'),base),base);
 assert.deepEqual(o._hlsFmp4,{mapDeclarations:3,mapSwitches:0,mapSwitchesWithoutDiscontinuity:0,crossPollMapSwitches:1,crossPollMapSwitchesWithoutDiscontinuity:1});
 assert.equal(o._hlsRecovery.lastKind,'progress');
});
test('v2.6.0 recRecoveryEvidence shapes blocks and never fakes zero evidence',()=>{
 const a=world();
 assert.equal(a.recRecoveryEvidence({},{}),undefined);
 const vid={_hlsRecovery:{staleResponses:1},_hlsFmp4:{mapDeclarations:2,mapSwitches:1,mapSwitchesWithoutDiscontinuity:0},_hlsLlhlsIndicators:3};
 const aud={_hlsLlhlsIndicators:1};
 const evd=JSON.parse(JSON.stringify(a.recRecoveryEvidence(vid,aud))); // VM realm → JSON round-trip (undefined keys drop)
 assert.deepEqual(evd.generationRecovery,{video:{staleResponses:1},provenance:'manifest_sequence_and_uri_classification'});
 assert.deepEqual(evd.fmp4Evidence.video,{mapDeclarations:2,mapSwitches:1,mapSwitchesWithoutDiscontinuity:0});
 assert.equal(evd.llhlsEvidence.video.indicatorTags,3);
 assert.equal(evd.llhlsEvidence.audio.indicatorTags,1);
 assert.equal(evd.llhlsEvidence.policy.includes('HLS_LLHLS_SKIP'),true);
 // llhls-only owner still produces a block without fake zeros elsewhere
 const solo=JSON.parse(JSON.stringify(a.recRecoveryEvidence({_hlsLlhlsIndicators:2},null)));
 assert.equal(solo.generationRecovery.video,undefined);
 assert.equal(solo.llhlsEvidence.video.indicatorTags,2);
});
test('v2.6.0 saveInfoJson embeds recovery/fmp4/llhls evidence and redacts playlist',async()=>{
 const blobs=[];
 const a=world({download:async(b,n)=>{blobs.push({b,n});return {confirmed:true,stage:'DOWNLOAD_REQUESTED'};}});
 const r=Object.create(a.Recorder.prototype);
 Object.assign(r,{
  id:'testoid',partsLog:[{file:'x.ts',ext:'ts',bytes:5,segments:1}],startedAt:Date.now()-2000,
  bytesTotal:5,segTotal:1,segFails:0,gapCount:0,resumes:0,byerangeSkipped:0,
  audioTxt:'',audio:null,selVariant:null,variants:[],liveInfo:null,schedItem:null,
  sourceKind:'legacy',accessMode:'legacy',log:()=>{},
  _hlsRecovery:{staleResponses:1,sequenceResets:0,uriRotations:0,contextSwitches:0,lastKind:'stale',lastSequence:4},
  _hlsFmp4:{mapDeclarations:2,mapSwitches:1,mapSwitchesWithoutDiscontinuity:0,crossPollMapSwitches:0,crossPollMapSwitchesWithoutDiscontinuity:0},
  _hlsLlhlsIndicators:2,
  creatorName:()=>'creator A',playlistUrl:()=>'https://x.example/hls/live.m3u8?sig=SECRET',
  recTitle:()=>'t',nameTpl:()=>'',csvOut:()=>false,statsBlock:()=>({missingRate:0}),
 });
 r.saveInfoJson();
 await new Promise(res=>setTimeout(res,20));
 assert.equal(blobs.length,1);
 const info=JSON.parse(await blobs[0].b.text());
 assert.match(info.tool,/^RPLAY Stable Player v2\.(?:[89]|10|11|12|13|36|37|38|39|40|41|42|43|44)\.0$/); // 版表記は範囲ピン(版ずれ防止はtest_v290_core.cjsの版ピン試験が担う)
 assert.equal(info.playlist,'https://x.example/hls/live.m3u8'); // no signature
 assert.deepEqual(info.generationRecovery.video,{staleResponses:1,sequenceResets:0,uriRotations:0,contextSwitches:0,lastKind:'stale',lastSequence:4});
 assert.deepEqual(info.fmp4Evidence.video,{mapDeclarations:2,mapSwitches:1,mapSwitchesWithoutDiscontinuity:0,crossPollMapSwitches:0,crossPollMapSwitchesWithoutDiscontinuity:0});
 assert.deepEqual(info.llhlsEvidence.video,{indicatorTags:2});
 assert.equal(JSON.stringify(info).includes('SECRET'),false);
});
test('v2.6.0 browser MAP switch splits the part boundary (init segments never mix)',async()=>{
 const {recording}=require('./helpers_hls.cjs');
 const box=(type,payload)=>{const h=Buffer.concat([Buffer.alloc(4),Buffer.from(type)]);h.writeUInt32BE(8+(payload?payload.length:0),0);return payload?Buffer.concat([h,payload]):h;};
 const init1=Buffer.concat([box('ftyp'),box('moov',Buffer.from([1]))]);
 const init2=Buffer.concat([box('ftyp'),box('moov',Buffer.from([2]))]);
 const frag=Buffer.concat([box('moof'),box('mdat')]);
 const list='#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:0\n'
  +'#EXT-X-MAP:URI="init1.mp4"\n#EXTINF:1,\na.m4s\n'
  +'#EXT-X-DISCONTINUITY\n#EXT-X-MAP:URI="init2.mp4"\n#EXTINF:1,\nb.m4s\n#EXT-X-ENDLIST\n';
 const w=recording(base,async u=>{
  const p=u.split('/').pop().split('?')[0];
  if(p==='live.m3u8')return new Response(list);
  if(p==='init1.mp4')return new Response(init1);
  if(p==='init2.mp4')return new Response(init2);
  return new Response(frag);
 });
 const r=w.video;
 await r.pollPlaylist();
 await r.drain();
 await r.closePart();
 assert.equal(r.segTotal,2);
 assert.deepEqual(r._hlsFmp4,{mapDeclarations:2,mapSwitches:1,mapSwitchesWithoutDiscontinuity:0,crossPollMapSwitches:0,crossPollMapSwitchesWithoutDiscontinuity:0});
 // two parts: each starts with exactly its own init segment (never mixed)
 assert.equal(r.parts.length,2);
 assert.ok(r.parts[0].subarray(0,init1.length).equals(init1));
 assert.ok(r.parts[1].subarray(0,init2.length).equals(init2));
 assert.equal(r.mediaFormat,'mp4');
});
