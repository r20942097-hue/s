from pathlib import Path
import shutil,hashlib,json
R=Path(__file__).resolve().parents[1]
s=(R/'src/player.user.js').read_text().replace('  /* RSP_PART_IO_MODULE */\n\n',(R/'src/part_io.js').read_text().replace('  /* RSP_SHA256_MODULE */',(R/'src/sha256.js').read_text()).replace('  /* RSP_PART_COMMIT_MODULE */',(R/'src/part_commit_core.js').read_text())+'\n')
s=s.replace('  /* RSP_JSON_FETCH_MODULE */',(R/'src/json_fetch.js').read_text())
s=s.replace('  function rspLiveRouteId(', (R/'src/creator_registry.js').read_text()+(R/'src/creator_meta.js').read_text()+'\n  function rspLiveRouteId(')
s=s.replace('  /* RSP_HLS_TRANSPORT_MODULE */',(R/'src/hls_transport.js').read_text())
a=s.index('/* ============================================================\n     ==== RSP RECORDING CORE');b=s.index('  /* ==== RSP RECORDING CORE',a)
b=s.index('\n',b)+1
core=s[a:b]
off=(R/'src/offscreen_pre.js').read_text().replace('  /* RSP_JSON_FETCH_MODULE */',(R/'src/json_fetch.js').read_text())+core+(R/'src/offscreen_post.js').read_text()
(R/'rplay-stable-player.user.js').write_text(s)
for ext in ['rplay-stable-player-extension','rplay-stable-player-extension-firefox']:
 (R/ext/'content.js').write_text(s);(R/ext/'offscreen.js').write_text(off)
 for n in ['export_host.js','export_manager.js','session_gate.js','hls_transport.js','background.js','ext_glue.js','recovery_core.js','recovery.js','recovery.html','sha256.js','mp4_convert.html','mp4_convert.js','mp4_convert_core.js','mp4_codec_core.js','mp4_browser_io.js','mp4_convert_worker.js','media_inspect.html','media_inspect.js','media_inspect_core.js','dashboard.html','dashboard.js','creator_registry.js','creator_meta.js','dashboard_settings.js','media_catalog.js','cross_site_compat.js','cross_site_core.js']:shutil.copy2(R/'src'/n,R/ext/n)
print(json.dumps({'shared_core_sha256':hashlib.sha256(core.encode()).hexdigest(),'version':'2.44.0'}))

(R/'rplay_dl.py').write_text((R/'src/cli.py').read_text().replace('# RSP_HLS_PY_MODULE',(R/'src/hls_transport.py').read_text()))

for n in ['recovery_core.js','recovery.js','recovery.html','sha256.js','mp4_convert.html','mp4_convert.js','mp4_convert_core.js','mp4_codec_core.js','mp4_browser_io.js','mp4_convert_worker.js','media_inspect.html','media_inspect.js','media_inspect_core.js','dashboard.html','dashboard.js','creator_registry.js','creator_meta.js','dashboard_settings.js','media_catalog.js','cross_site_compat.js','cross_site_core.js']:shutil.copy2(R/'src'/n,R/n)

for dest in [R/'libs',R/'rplay-stable-player-extension/libs',R/'rplay-stable-player-extension-firefox/libs']:
 dest.mkdir(exist_ok=True);shutil.copy2(R/'src/vendor/mux.min.js',dest/'mux.min.js')
for dest in [R/'rplay-stable-player-extension/licenses',R/'rplay-stable-player-extension-firefox/licenses']:
 dest.mkdir(exist_ok=True)
 shutil.copy2(R/'licenses/mux.js-LICENSE.txt',dest/'mux.js-LICENSE.txt')
 shutil.copy2(R/'licenses/mux.js-SOURCE.json',dest/'mux.js-SOURCE.json')
shutil.copy2(R/'src/join_parts.py',R/'rplay_join.py')

shutil.copy2(R/'src/hls_transport.js',R/'hls_transport.js')
