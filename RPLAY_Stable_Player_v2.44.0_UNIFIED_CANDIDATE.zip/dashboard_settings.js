(function(root){'use strict';
const key='rsp_dashboard_defaults',flags=['autoStartAllowed','enabled','follow','recAudio','inheritQuery','mp4Handover'];
function normalize(value){
 if(value===undefined)return {autoStartAllowed:true,enabled:false,follow:true,recAudio:false,inheritQuery:false,mp4Handover:false,splitMin:0};
 if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).some(k=>!flags.includes(k)&&k!=='splitMin'))throw Error('保存済み設定の形式が不正です。上書きせず確認してください');
 const d={};for(const k of flags){if(value[k]!==undefined&&typeof value[k]!=='boolean')throw Error('設定のON/OFFが不正です');d[k]=k==='autoStartAllowed'?value[k]!==false:value[k]===true;}
 const n=value.splitMin===undefined?0:value.splitMin;if(typeof n!=='number'||!Number.isFinite(n)||n<0||n>1440)throw Error('分割は0〜1440分で入力してください');d.splitMin=n;return d;
}
function snapshot(value){return JSON.stringify(normalize(value));}
async function commit(value,expected,storage,locks){
 const next=normalize(value);if(typeof expected!=='string')throw Error('保存済み設定を読み込んでから保存してください');
 if(!locks||typeof locks.request!=='function')throw Error('この環境は排他保存に非対応です');
 return locks.request('rsp-dashboard-settings-save-v1',async()=>{const v=await storage.get(key);if(snapshot(v[key])!==expected)throw Error('別の画面で設定が更新されました。保存済みに戻してから編集し直してください');await storage.set({[key]:next});return snapshot(next);});
}
const api={normalize,snapshot,commit};if(typeof module!=='undefined')module.exports=api;root.RspDashboardSettings=api;
})(globalThis);
