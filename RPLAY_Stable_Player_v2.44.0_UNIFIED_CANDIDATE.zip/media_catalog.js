/* Bounded, session-only HLS/DASH/MP4 candidates. Request context is allowlisted; no Cookie/Authorization values or persistence. */
(function(root){'use strict';
const SIGNED_RE=/^(?:token|sig|signature|expires?|expiry|exp|policy|key-pair-id|x-amz-(?:signature|credential|security-token|date|expires|algorithm|signedheaders)|x-goog-(?:signature|credential|date|expires|algorithm|signedheaders)|hdnts|hdnea|auth|jwt|session(?:_?id)?|access[_-]?key|access[_-]?token|e|hmac|key2)$/i;
function defaultUuid(){
 if(root&&root.crypto&&typeof root.crypto.randomUUID==='function')return root.crypto.randomUUID();
 if(typeof crypto!=='undefined'&&crypto&&typeof crypto.randomUUID==='function')return crypto.randomUUID();
 if(typeof require==='function'){try{return require('node:crypto').randomUUID();}catch{}}
 return 'rsp-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10);
}
function http(value){if(typeof value!=='string'||value.length>16384||/[\x00-\x20\x7f]/.test(value))throw Error('INVALID_HTTP_URL');const u=new URL(value);if(!['http:','https:'].includes(u.protocol)||u.username||u.password)throw Error('INVALID_HTTP_URL');return u;}
function isSigned(urlString){const u=http(urlString);return [...u.searchParams.keys()].some(k=>SIGNED_RE.test(k));}
function decodeKey(rawKey){const s=String(rawKey||'').replace(/\+/g,' ');try{return decodeURIComponent(s);}catch{return s;}}
function resolveMediaURI(base,raw,{inheritParentQuery=false}={}){
 const parent=http(base),val=String(raw??'').trim();
 if(!val||/[\x00-\x20\x7f]/.test(val))throw Error('INVALID_HTTP_URL');
 const u=new URL(val,parent);http(u.href);
 if(/^https?:\/\//i.test(val)&&isSigned(u.href))return val;
 if(!inheritParentQuery||u.origin!==parent.origin||!parent.search||isSigned(u.href))return u.href;
 if(!u.search){u.search=parent.search;return u.href;}
 const existing=new Set([...u.searchParams.keys()]);
 const rawChild=u.search.replace(/^\?/,'');
 const append=parent.search.replace(/^\?/,'').split('&').filter(Boolean).filter(p=>!existing.has(decodeKey(p.split('=')[0])));
 if(append.length)u.search=[rawChild,...append].filter(Boolean).join('&');
 return u.href;
}
function create({now=()=>Date.now(),id=defaultUuid,max=100,ttl=900000}={}){const entries=new Map(),requests=new Map();
 function sweep(){for(const [k,v] of entries)if(now()-v.at>=ttl)entries.delete(k);for(const [k,v] of requests)if(now()-v.at>=60000)requests.delete(k);}
 function requestKey(d){return String(d.requestId||d.url)+'|'+d.tabId;}
 function captureRequest(d){sweep();if(!d||!Number.isInteger(d.tabId)||d.tabId<0)return;try{http(d.url);}catch{return;}const headers=Array.isArray(d.requestHeaders)?d.requestHeaders:[],context={referer:'',origin:'',userAgent:'',cookieObserved:false,authorizationObserved:false};
  for(const h of headers){const name=String(h&&h.name||'').toLowerCase(),val=String(h&&h.value||'');if(/^[\x20-\x7e]{1,1024}$/.test(val)){if(name==='referer')try{context.referer=http(val).href;}catch{}if(name==='origin')try{context.origin=http(val).origin;}catch{}if(name==='user-agent')context.userAgent=val;}if(name==='cookie')context.cookieObserved=true;if(name==='authorization')context.authorizationObserved=true;}
  try{if(d.initiator)context.origin=context.origin||http(d.initiator).origin;if(d.documentUrl)context.pageUrl=http(d.documentUrl).href;}catch{}
  while(requests.size>=200)requests.delete(requests.keys().next().value);
  requests.set(requestKey(d),{url:d.url,tabId:d.tabId,at:now(),context});
 }
 function forgetRequest(d){if(d)requests.delete(requestKey(d));}
 function add(d){sweep();const req=d&&requests.get(requestKey(d));if(d)forgetRequest(d);const context=req&&req.url===d.url?req.context:{};if(!d||!Number.isInteger(d.tabId)||d.tabId<0||![200,206].includes(d.statusCode))return;let u;try{u=http(d.url);}catch{return;}const mime=(d.responseHeaders||[]).find(h=>String(h.name).toLowerCase()==='content-type');const type=String(mime&&mime.value||'').split(';')[0].trim().toLowerCase();const mediaType=/\.m3u8$/i.test(u.pathname)||['application/vnd.apple.mpegurl','application/x-mpegurl','audio/mpegurl','audio/x-mpegurl'].includes(type)?'hls':(/\.mpd$/i.test(u.pathname)||type==='application/dash+xml'?'dash':(/\.(?:mp4|m4a)$/i.test(u.pathname)||['video/mp4','audio/mp4'].includes(type)?'mp4':null));if(!mediaType||(d.statusCode===206&&mediaType!=='mp4'))return;
  const key=d.tabId+'|'+d.url,old=entries.get(key);if(old){old.at=now();old.updates=(old.updates||1)+1;old.state='observed';if(req&&req.url===d.url)old.context=context;return;}const per=[...entries].filter(x=>x[1].tabId===d.tabId);if(per.length>=20)entries.delete(per[0][0]);while(entries.size>=max)entries.delete(entries.keys().next().value);entries.set(key,{id:id(),tabId:d.tabId,url:d.url,origin:u.origin,at:now(),mime:type,mediaType,context,updates:1,state:'observed'});}
 function markFailure(targetId,status){sweep();const e=[...entries.values()].find(x=>x.id===targetId);if(!e)return false;e.state=status===401||status===403?'auth-required':status===404||status===410?'possibly-expired':'http-error';e.lastStatus=Number.isInteger(status)?status:0;return true;}
 function list(){sweep();return [...entries.values()].map(({id,tabId,origin,at,mime,mediaType,updates,state})=>({id,tabId,origin,at,mime,mediaType,updates:updates||1,state:state||'observed',candidateOnly:true})).reverse();}
 return {add,list,captureRequest,forgetRequest,markFailure,get(key){sweep();return [...entries.values()].find(e=>e.id===key)||null;},clear(tabId){for(const [k,v] of requests)if(tabId===undefined||v.tabId===tabId)requests.delete(k);for(const [k,v] of entries)if(tabId===undefined||v.tabId===tabId)entries.delete(k);}};
}
function manifest(text,base,HLS=root.RspHlsTransport,inheritQuery=false){http(base);if(typeof text!=='string'||new TextEncoder().encode(text).length>2097152||!/^\uFEFF?#EXTM3U(?:\r?\n|$)/.test(text))throw Error('INVALID_OR_LARGE_HLS');const rows=[],seen=new Set();let pending=null;
 const resolve=raw=>resolveMediaURI(base,raw,{inheritParentQuery:!!inheritQuery});
 const add=row=>{const key=row.kind+'|'+row.url;if(seen.has(key))return;if(rows.length>=100)throw Error('HLS_LIST_LIMIT_100');seen.add(key);rows.push(row);};
 for(const raw of text.replace(/^\uFEFF/,'').split(/\r?\n/)){const line=raw.trim();if(!line)continue;
  if(line.startsWith('#EXT-X-STREAM-INF:')){if(pending)throw Error('HLS_MISSING_VARIANT_URI');pending=HLS.attrs(line.slice(18));continue;}
  if(line.startsWith('#EXT-X-MEDIA:')){const a=HLS.attrs(line.slice(13));if(a.TYPE==='AUDIO'&&a.URI)add({kind:'audio',url:resolve(a.URI),groupId:a['GROUP-ID']||'',name:a.NAME||a.LANGUAGE||'audio',label:'音声 '+(a['GROUP-ID']?a['GROUP-ID']+' / ':'')+(a.NAME||a.LANGUAGE||'別トラック')});continue;}
  if(line.startsWith('#'))continue;
  if(pending){const bw=Number(pending['AVERAGE-BANDWIDTH']||pending.BANDWIDTH||0);add({kind:'variant',url:resolve(line),bandwidth:Number.isFinite(bw)?bw:0,resolution:pending.RESOLUTION||'',audioGroup:pending.AUDIO||'',label:'映像 '+(pending.RESOLUTION||'画質不明')+(bw>0?' / '+Math.round(bw/1000)+'kbps':'')});pending=null;}
 }
 if(pending)throw Error('HLS_MISSING_VARIANT_URI');
 return rows;
}
async function load(url,{fetchImpl=fetch,signal,HLS=root.RspHlsTransport,useCookies=false,inheritQuery=false}={}){http(url);if(typeof useCookies!=='boolean'||typeof inheritQuery!=='boolean')throw Error('INVALID_REQUEST_OPTIONS');const transport=HLS.createTransfer((u,o)=>fetchImpl(u,{...o,credentials:useCookies?'include':'omit',redirect:'error'}),8000),cancel=()=>transport.abort();if(signal){signal.addEventListener('abort',cancel,{once:true});if(signal.aborted)cancel();}
 try{const r=await transport.request({uri:url},2097152);if(!r.bytes)throw Error(r.error||'HTTP_'+r.status);const body=new TextDecoder('utf-8',{fatal:true}).decode(r.bytes);return {body,rows:manifest(body,url,HLS,inheritQuery),requestMode:useCookies?'browser_cookies':'anonymous'};}finally{if(signal)signal.removeEventListener('abort',cancel);transport.abort();}}
async function loadDASH(url,{fetchImpl=fetch,signal,HLS=root.RspHlsTransport,DASH=root.RspCrossSite,useCookies=false}={}){
 http(url);if(typeof useCookies!=='boolean'||!HLS||!DASH||typeof DASH.parseDASH!=='function')throw Error('DASH_PARSER_UNAVAILABLE');
 const transport=HLS.createTransfer((u,o)=>fetchImpl(u,{...o,credentials:useCookies?'include':'omit',redirect:'error'}),8000),cancel=()=>transport.abort();
 if(signal){signal.addEventListener('abort',cancel,{once:true});if(signal.aborted)cancel();}
 try{const r=await transport.request({uri:url},2097152);if(!r.bytes)throw Error(r.error||'HTTP_'+r.status);
  if(r.status!==200)throw Error('DASH_EXPECT_FULL_200');
  const body=new TextDecoder('utf-8',{fatal:true}).decode(r.bytes),report=DASH.parseDASH(body);
  return {body,report,rows:[],requestMode:useCookies?'browser_cookies':'anonymous'};
 }finally{if(signal)signal.removeEventListener('abort',cancel);transport.abort();}
}
const api={create,manifest,load,loadDASH,http,isSigned,resolveMediaURI};if(typeof module!=='undefined')module.exports=api;root.RspMediaCatalog=api;
})(globalThis);
